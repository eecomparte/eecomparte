http://es5dx02bsab.bancsabadell.com:8880/micro/
http://es5dx02bsab.bancsabadell.com:8880/ccr/
http://es5dx02bsab.bancsabadell.com:8880/rbp/
http://es5dx02bsab.bancsabadell.com:8880/garantias/


CAS-DES
http://devsso.bancsabadell.com/aas/login





UPDATE CCR_CONF_MODULE SET MODULE_URL = 'http://es5dx02bsab.bancsabadell.com:8880/micro/' WHERE ID_MODULE='MICRO';
UPDATE CCR_CONF_MODULE SET MODULE_URL = 'http://es5dx02bsab.bancsabadell.com:8880/appccr/' WHERE ID_MODULE='CCR';
UPDATE CCR_CONF_MODULE SET MODULE_URL = 'http://es5dx02bsab.bancsabadell.com:8880/rbp/' WHERE ID_MODULE='RBP';
UPDATE CCR_CONF_MODULE SET MODULE_URL = 'http://es5dx02bsab.bancsabadell.com:8880/garantias/' WHERE ID_MODULE='GARAN';
COMMIT;