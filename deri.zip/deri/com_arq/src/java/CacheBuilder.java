import java.io.File;
import java.text.SimpleDateFormat;
import java.util.Date;

public class CacheBuilder {

	private static String baseDir = "C:\\DERI\\workspace_deri_ok\\deri_per\\src\\java\\com\\atosorigin\\deri\\model";

	static void Process(File aFile, String carpeta) {

		if (aFile.isFile() && aFile.getName().endsWith(".java") && !aFile.getName().endsWith("Id.java")) {
			System.out.print("<class>");
			System.out.print(carpeta +aFile.getName().replace(".java", ""));
			System.out.print("</class>\n");
		} else if (aFile.isDirectory()) {
			File[] listOfFiles = aFile.listFiles();
			if (listOfFiles != null) {
				for (int i = 0; i < listOfFiles.length; i++)
					Process(listOfFiles[i], carpeta + aFile.getName() + ".");
			} else {
				System.out.println("[ACCESS DENIED]");
			}
		}

	}

	public static void main(String[] args) {

		String nam = baseDir;
		File aFile = new File(nam);
		System.out.println("INICIO --->");
		Process(aFile, "com.atosorigin.deri.model.");

	}

}
