package com.atosorigin.common.action;

import java.io.IOException;
import java.io.InputStream;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.Properties;
import java.util.Set;

import org.jboss.seam.annotations.In;
import org.jboss.seam.annotations.Logger;
import org.jboss.seam.core.Conversation;
import org.jboss.seam.faces.Redirect;
import org.jboss.seam.international.StatusMessages;
import org.jboss.seam.log.Log;

import com.atosorigin.common.constantes.Constantes;


/**
 * Clase genética de action listener con los elementos básicos iyectados.
 */
public class GenericAction implements Serializable{

	/** Inyección de los mansajes de estado de SEAM */
	@In protected StatusMessages statusMessages;
	
	/** Inyección de logger de SEAM */
	@Logger protected Log log;
	
	/** Modo de Pantalla */	
	protected ModoPantalla modoPantalla = ModoPantalla.EDICION;
	
	/**
	 * Para diferenciar entre el primer acceso a la pantalla y el resto
	 */
	protected boolean primerAcceso = true;
	
	/**
	 * Archivo por defecto de propiedades. Configurable si se desea
	 */
	private String configurationFilePath = Constantes.NOMBRE_PROYECTO_DERI + ".properties";

	/**
	 * Propiedades del proyecto DERI
	 */
	private Properties props = null;
	
	/**
	 * Property prefix
	 */
	private String prefix = "deri.agenda.";

	public Set<String> cjtoCamposError = new HashSet<String>();
	
	/**
	 * Acción necesaria para los botones de salir.
	 * En realidad no hace nada porque los cierres de conversación
	 * y el control de la navegación se define en los .pages.xml
	 */
	public void salir() {
//		statusMessages.add("#{messages['status.salir']}");
	}

	public ModoPantalla getModoPantalla() {
		return modoPantalla;
	}

	public void setModoPantalla(ModoPantalla modoPantalla) {
		this.modoPantalla = modoPantalla;
	}

	public boolean isDisabled(boolean creacion, boolean edicion, boolean inspeccion) {
		if (modoPantalla.equals(ModoPantalla.CREACION)) {
			return creacion;
		} else if (modoPantalla.equals(ModoPantalla.EDICION)) {
			return edicion;
		} else if (modoPantalla.equals(ModoPantalla.INSPECCION)) {
			return inspeccion;
		} else {
			return false;
		}
	}
	
	public boolean isRendered(boolean creacion, boolean edicion, boolean inspeccion) {
		if (modoPantalla.equals(ModoPantalla.CREACION)) {
			return creacion;
		} else if (modoPantalla.equals(ModoPantalla.EDICION)) {
			return edicion;
		} else if (modoPantalla.equals(ModoPantalla.INSPECCION)) {
			return inspeccion;
		} else {
			return false;
		}		
	}
	
	public String getMessageByMode(String creacion, String edicion, String inspeccion) {
		if (modoPantalla.equals(ModoPantalla.CREACION)) {
			return creacion;
		} else if (modoPantalla.equals(ModoPantalla.EDICION)) {
			return edicion;
		} else if (modoPantalla.equals(ModoPantalla.INSPECCION)) {
			return inspeccion;
		} else {
			return Constantes.CADENA_VACIA;
		}		
	}

	public boolean isPrimerAcceso() {
		return primerAcceso;
	}

	public void setPrimerAcceso(boolean primerAcceso) {
		this.primerAcceso = primerAcceso;
	}
	
	private Properties loadFromResource() {
		props = new Properties();
		InputStream stream = Thread.currentThread().getContextClassLoader().getResourceAsStream(configurationFilePath);
		if(stream != null) {
			try {
				props.load(stream);
			} catch (IOException ioe) {
				props = null;
			} finally {
				try {
					stream.close();
				} catch (IOException ioe) {
					props = null;
				}
			}
		}
		return props;
	}
	
	public String getProperty(String key) {
		if(props == null) {
			props = loadFromResource();
		}
		return props.getProperty(prefix + key);
	}
	
	public void redirect(String screenCode) {
		Conversation conversation = Conversation.instance();
		conversation.beginNested();
		
		String url = getProperty(screenCode);
		Redirect redirect = new Redirect();
		redirect.setConversationPropagationEnabled(true);
		redirect.setViewId(url);
		//redirect.setParameter(name, value);
		redirect.execute();
	}
	
	public void redirectToURL(String URL, ArrayList<String> params, ArrayList<String> values){
		String url = URL;
		Redirect redirect = new Redirect();
		redirect.setConversationPropagationEnabled(true);
		redirect.setViewId(url);
		if(params != null && values !=null){
			if(!(params.isEmpty()) && !(values.isEmpty())){
				for(int i = 0; i< params.size(); i++){
					redirect.setParameter(params.get(i),values.get(i));
				}
			}
		}
		//redirect.setParameter(name, value);
		redirect.execute();
	}
	
	public void redirectToURL(String URL) {
		redirectToURL(URL,null,null);
	}

	public String getConfigurationFilePath() {
		return configurationFilePath;
	}

	public void setConfigurationFilePath(String configurationFilePath) {
		this.configurationFilePath = configurationFilePath;
	}

	public Properties getProps() {
		return props;
	}

	public void setProps(Properties props) {
		this.props = props;
	}

	public String getPrefix() {
		return prefix;
	}

	public void setPrefix(String prefix) {
		this.prefix = prefix;
	}

	public Set<String> getCjtoCamposError() {
		return cjtoCamposError;
	}

	public void setCjtoCamposError(Set<String> cjtoCamposError) {
		this.cjtoCamposError = cjtoCamposError;
	}

	public boolean isCjtoCamposError(String id){
		return cjtoCamposError.contains(id);
	}
}
