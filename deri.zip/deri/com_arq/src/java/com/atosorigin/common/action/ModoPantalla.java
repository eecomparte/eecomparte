package com.atosorigin.common.action;

public enum ModoPantalla { CREACION, EDICION, INSPECCION };
