package com.atosorigin.common.action;

import java.util.Collections;
import java.util.List;



/**
 * Clase genética de action listener que sirve para manejar pantallas con grid paginada en base de datos.
 */
public abstract class PaginatedListAction extends GenericAction {
	
	/** Los datos de paginación del grid que maneja */
	protected PaginationData paginationData = new PaginationData();
	
	protected boolean exportExcel = false;
	
	/**
	 * Obtiene los datos de paginación.
	 * 
	 * @return Datos de paginación.
	 */
	public PaginationData getPaginationData() {
		return paginationData;
	}

	/**
	 * Establece los datos de paginación.
	 * 
	 * @param paginationData Los datos de paginación. 
	 */
	public void setPaginationData(PaginationData paginationData) {
		this.paginationData = paginationData;
	}
	
	/**
	 * Comprueba que hay una página anterior a la que se está mostrando actualmente.
	 * 
	 * @return true si hay página anterior.
	 */
	public boolean isPreviousExists() {
		return paginationData.getFirstResult() > 1;
	}

	/**
	 * Comprueba si hay página siguiente a la que se está mostrando actualmente.
	 * 
	 * @return true, Si hay página siguiente
	 */
	public boolean isNextExists() {
		return getDataTableList() != null && paginationData.getMaxResults() != null
				&& getDataTableList().size() > paginationData.getMaxResults();
	}
	
	/**
	 * Actualiza la lista de datos del grid con la siguiente página de base de datos,
	 */
	public void next() {
		paginationData.setFirstResult(paginationData.getFirstResult() + paginationData.getMaxResults());
		this.refrescarLista();
	}

	public void goLast(Integer nombreRegistres){
		Integer inicial = nombreRegistres - (nombreRegistres%10);
		
		paginationData.setFirstResult(inicial);
		this.refrescarLista();
	}
	
	/**
	 * Actualiza la lista de datos del grid con la anterior página de base de datos,
	 */
	public void previous() {
		int firstResult = paginationData.getFirstResult() - paginationData.getMaxResults();
		if(firstResult<0){
			firstResult=0;
		}
		paginationData.setFirstResult(firstResult);
		this.refrescarLista();
	}

	/**
	 * Actualiza la lista de datos del grid con la primera página de base de datos,
	 */
	public void first() {
		paginationData.setFirstResult(0);
		this.refrescarLista();
	}

	
	public boolean isLastExists() {
		return false;
	}

	
	/**
	 * Establece el criterio de ordenación
	 * 
	 * @param orderKey El criterio de ordenación.
	 */
	public void setOrderKey(String orderKey) {
		paginationData.setOrderKey(orderKey);
		this.refrescarLista();
	}

	public final void refrescarLista(){
		refreshListInternal();
		List<?> compruebaLista = compruebaLista(getDataTableList());
		setDataTableList(compruebaLista);
	}
	/**
	 * Refresca la lista de elementos del grid con los filtros de pantalla que correspondan.
	 */
	protected abstract void refreshListInternal();

	/**
	 * Refresca la lista de elementos del grid para el excel.
	 * Lo que tiene que hacer es poner el first a 0 y el maxresults a la constante
	 * que indica el número máximo de registros para sacar en el excel. (unos 65500)
	 */
	public abstract void refrescarListaExcel();

	/**
	 * Obtiene la lista de elementos del grid. No va a por ella, sólo la obtiene.
	 * 
	 * @return La lista de elementos del grid.
	 */
	public abstract List<?> getDataTableList();

	/**
	 * Establece la lista de elementos del grid. No la calcula, sólo la 'setea'
	 * 
	 * @param dataTableList La lista de elementos del grid.
	 */
	public abstract void setDataTableList(List<?> dataTableList);

	public boolean isExportExcel() {
		return exportExcel;
	}

	public void setExportExcel(boolean exportExcel) {
		this.exportExcel = exportExcel;
	}

	/**
	 * Metodo de utilidad que debe usarse desde refrescarLista para asegurarse de que
	 * no caemos en una pagina vacia (intenta retroceder a la anterior)
	 * 
	 * @param ql
	 * @param clazz
	 * @return
	 */
	protected <E>  List<E> compruebaLista(List<E> ql) {
		if(ql==null){
			return Collections.EMPTY_LIST;
		}
		if(ql.size()>0){
			return ql;
		}
		else{
			if(paginationData.getActivePage()>1){
				previous();
				return (List<E>) getDataTableList();
			}
			else{
				return ql;
			}
		}
	}

}
