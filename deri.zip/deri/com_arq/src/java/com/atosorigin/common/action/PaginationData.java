package com.atosorigin.common.action;

import java.lang.UnsupportedOperationException;

import com.atosorigin.common.constantes.Constantes;

/**
 * Clase que encapsula los datos de paginación en base de datos de un PaginatedListAction
 */
public class PaginationData {
	
	/** La clave de ordenación. */
	protected String orderKey;
	
	/** El sentido de la ordenación. */
	protected boolean ascending;
	
	/** Primer registro a recuperar de la base de datos. Al principio siempre es 0. */
	protected Integer firstResult = 0;
	
	/** Número máximo de resultados por página a traer de la base de datos. */
	protected Integer maxResults = 10;


	/**
	 * Obtiene el primer registro a recuperar de la base de datos.
	 * 
	 * @return El primer registro.
	 */
	public Integer getFirstResult() {
		return firstResult;
	}

	/**
	 * Establece el primer registro a recuperar de la base de datos.
	 * 
	 * @param fisrtResult El primer registro.
	 */
	public void setFirstResult(Integer fisrtResult) {
		this.firstResult = fisrtResult;
	}

	/**
	 * Establece el tamaño de página a traer de la base de datos.
	 * 
	 * @return El tamaño de página
	 */
	public Integer getMaxResults() {
		return maxResults;
	}

	/**
	 * Obtiene el tamaño de página a traer de la base de datos.
	 * 
	 * @param maxResults El tamaño de página.
	 */
	public void setMaxResults(Integer maxResults) {
		this.maxResults = maxResults;
	}

	/**
	 * Obtiene el criterio de ordenación.
	 * 
	 * @return El criterio de ordenación.
	 */
	public String getOrderKey() {
		return this.orderKey;
	}

	/**
	 * Establece el criterio de ordenación.
	 * 
	 * @param orderKey El criterio de ordenación.
	 */
	public void setOrderKey(String orderKey) {
		// Si el valor ya es la clave de ordenación le invierto la dirección
		if (orderKey != null && orderKey.equals(this.orderKey)) {
			ascending = !ascending;
		} else {
			// En caso contrario ponemos un nuevo criterio de ordenación,
			this.orderKey = orderKey;
			ascending = true;
		}
		// se refresca la lista
	}

	/**
	 * Compruaba si el sentido de la ordenación es ascendente.
	 * 
	 * @return true, si el sentido de la ordenación es ascendente.
	 */
	public boolean isAscending() {
		return ascending;
	}

	/**
	 * Establece el sentido de la ordenación.
	 * 
	 * @param ascending El nuevo sentido de ordenación.
	 */
	public void setAscending(boolean ascending) {
		this.ascending = ascending;
	}
	
	/**
	 * Calcula y devuelve el número de página actual basado en el valor del primer registro a recuperar.
	 *
	 * @return El número de página actual.
	 */
	public int getActivePage() {
		Integer fr = this.getFirstResult();
		Integer mr = getMaxResults();
		if (fr != null && mr != null) {
			return 1 + (fr / mr);
		}
		return 0;
	}

	/**
 	 * No lo implemento por motivos de rendimiento. Si una tabla tiene muchos
	 * registros puede ser que el acceso al Last deje la petición colgada.
	 */
	public void last() {
		throw new UnsupportedOperationException();

	}


	
	/**
	 * Obtiene los datos de paginación para sacar los registros de la base de datos para montar el excel. 
	 * 
	 * @return Los datos de paginación para el excel.
	 */
	public PaginationData getPaginationDataForExcel()  {
		// TODO Auto-generated method stub
		PaginationData pd = new PaginationData();
		pd.setFirstResult(0);
		pd.setMaxResults(Constantes.MAX_RESULTS_EXCEL);
		pd.setOrderKey(this.orderKey);
		pd.setAscending(this.ascending);
		return pd;
	}

	/**
	 * Resetea los resultados.
	 * 
	 */
	public void reset() {
		this.firstResult = 0;
	}

}
