package com.atosorigin.common.auditdata;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Embeddable;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;


/**
 * Bean que implementa los datos de auditoría de las tablas.
 */
@Embeddable
public class AuditData {
	

	/** fecha de la última modeificación. */
	protected Date fechaUltimaModi; 

	/** Usuario de la última modificación. */
	protected String usuarioUltimaModi; 
	

	/**
	 * Obtiene la fecha de la última modificación.
	 * 
	 * @return Fecha de la última modificación.
	 */
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "FEULTACT", nullable=false)
	public Date getFechaUltimaModi() {
		return fechaUltimaModi;
	}
	
	/**
	 * Establece la fecha de la última modificación.
	 * 
	 * @param fechaUltimaModi fecha de la última modificación.
	 */
	public void setFechaUltimaModi(Date fechaUltimaModi) {
		this.fechaUltimaModi = fechaUltimaModi;
	}


	/**
	 * Obtiene el usuario de la última modificación.
	 * 
	 * @return El usuario de la última modificación.
	 */
	@Column(name = "USULTACT", length = 30, nullable=false)
	public String getUsuarioUltimaModi() {
		return usuarioUltimaModi;
	}
	
	/**
	 * Establece el usuario de la última modificación.
	 * 
	 * @param usuarioUltimaModi El usuario de la última modificación.
	 */
	public void setUsuarioUltimaModi(String usuarioUltimaModi) {
		this.usuarioUltimaModi = usuarioUltimaModi;
	}

	
}
