package com.atosorigin.common.auditdata;

import java.io.Serializable;
import java.util.Date;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.hibernate.EmptyInterceptor;
import org.hibernate.type.Type;
import org.jboss.seam.security.Identity;


/**
 * Interceptor de hibernate que maneja los datos de auditoría de las  tablas que
 * implementan TablaAuditable.
 */
public class HibernateAuditInterceptor extends EmptyInterceptor{
	
	private static final Log LOG = LogFactory.getLog( HibernateAuditInterceptor.class );

	
	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = -5871631308602068606L;
	
	/** The Constant AUDIT_DATA. */
	private static final String AUDIT_DATA= "auditData";
	
	/**
	 * Constructor.
	 */
	public HibernateAuditInterceptor() {
		super();
	}

	/* (non-Javadoc)
	 * @see org.hibernate.EmptyInterceptor#onDelete(java.lang.Object, java.io.Serializable, java.lang.Object[], java.lang.String[], org.hibernate.type.Type[])
	 */
	public void onDelete(Object entity, Serializable id, 
			Object[] state, String[] propertyNames, Type[] types)
	{
		if(entity instanceof TablaAuditable) {
			creaAuditoria(propertyNames, state);
		}
	}

	/* (non-Javadoc)
	 * @see org.hibernate.EmptyInterceptor#onSave(java.lang.Object, java.io.Serializable, java.lang.Object[], java.lang.String[], org.hibernate.type.Type[])
	 */
	public boolean onSave(Object entity, Serializable id, 
			Object[] state, String[] propertyNames, Type[] types)
	{
		if(entity instanceof TablaAuditable) {
			creaAuditoria(propertyNames, state);
		}
		return true;
	}

	/* (non-Javadoc)
	 * @see org.hibernate.EmptyInterceptor#onFlushDirty(java.lang.Object, java.io.Serializable, java.lang.Object[], java.lang.Object[], java.lang.String[], org.hibernate.type.Type[])
	 */
	public boolean onFlushDirty(Object entity, Serializable id, Object[] currentState, 
			Object[] previousState, String[] propertyNames, Type[] types)
	{
		if(entity instanceof TablaAuditable) {
			creaAuditoria(propertyNames, currentState);
		}
		return true;
	}
	
	/**
	 * Crea los datos de auditoría que irán a parar a campos de la tabla.
	 * 
	 * @param propertyNames Array con los nombes de las propiedades de la entity a persistit.
	 * @param currentState Estado actual del objeto.
	 */
	private void creaAuditoria(String[] propertyNames, Object[] currentState)
	{
		String name = Identity.instance().getCredentials().getUsername();
		
		if(name ==null) {
			name="test";
			if(LOG.isDebugEnabled()){
				LOG.debug("No existe un principal (un usuario conectado), se registra como usuario 'test'");
			}
		}
		
        for ( int i=0; i < propertyNames.length; i++ ) {
            if ( AUDIT_DATA.equals( propertyNames[i] ) ) {
            	AuditData td = (AuditData) currentState[i];
            	if(td == null)
            		td = new AuditData();
				td.setUsuarioUltimaModi(name);
            	td.setFechaUltimaModi(new Date());
            	currentState[i] = td;
            	return;
            }
        }
	}

}
