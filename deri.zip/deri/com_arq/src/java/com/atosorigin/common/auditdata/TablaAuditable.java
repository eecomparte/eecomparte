package com.atosorigin.common.auditdata;




/**
 * Interfaz que deben implementar las entities que tienen datos de auditoría.
 */
public interface TablaAuditable {
	
	/**
	 * Obtiene los datos de auditoría del entity.
	 * 
	 * @return Dataos de auditoría.
	 */
	public AuditData getAuditData() ;

	/**
	 * Establece los datos de auditoría del entity.
	 * 
	 * @param auditData Datos de auditoría. 
	 */
	public void setAuditData(AuditData auditData) ;

	
}
