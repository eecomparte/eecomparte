package com.atosorigin.common.bulkload;

import java.io.Closeable;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

/**
 * Contenedor de tamaño fijo que puede serializar (persistir en disco) los
 * objetos que contiene.
 * 
 * @author alejandro.torras@atosorigin.com
 */
public class Bucket<T> implements Iterable<T> {

	@SuppressWarnings("unchecked")
	public static final Bucket EMPTY_BUCKET = new Bucket<Object>(false, 0);

	protected static Log log = LogFactory.getLog(Bucket.class);

	public static final int SIZE = 250;

	/**
	 * Cierra un objeto de manera limpia.
	 * 
	 * @param closeable
	 */
	protected static void quietClose(Closeable closeable) {

		if (closeable == null)
			return;

		try {
			closeable.close();
		} catch (IOException e) {
			log.debug(e);
		}
	}

	protected List<T> data;

	protected int dataSize;

	protected File serializedFile;

	protected boolean serializeWhenFilled;

	public Bucket() {
		this(false);
	}

	protected Bucket(boolean serializeWhenFilled, int size) {
		this.serializeWhenFilled = serializeWhenFilled;
		serializedFile = null;
		data = new ArrayList<T>(size);
	}

	public Bucket(boolean serializeWhenFilled) {
		this(serializeWhenFilled, SIZE);
	}

	/**
	 * Añade el objeto especificado.
	 * 
	 * @param object
	 * @return <code>false</code> en el caso que el contenedor esté lleno.
	 */
	public boolean add(T object) {

		if (isFull()) {
			if (serializeWhenFilled && !serialized())
				serialize();

			return false;
		}

		if (serialized())
			unserialize();

		data.add(object);
		return true;
	}

	@Override
	protected void finalize() throws Throwable {

		data = null;

		if (serialized())
			serializedFile.delete();
	}

	public List<T> getData() {
		return data;
	}

	public boolean isEmpty() {
		return size() == 0;
	}

	public boolean isFull() {
		return size() == SIZE;
	}

	/**
	 * Devuelve un iterador para los objetos contenidos.
	 * 
	 * En el caso que los objetos estén serializados, se deserializan
	 * automáticamente.
	 */
	public Iterator<T> iterator() {

		if (serialized())
			unserialize();

		return data.iterator();
	}

	/**
	 * Escribe en disco los objetos contenidos.
	 */
	public void serialize() {

		if (serialized() || isEmpty())
			return;

		FileOutputStream fos = null;
		ObjectOutputStream oos = null;

		try {
			serializedFile = File.createTempFile("bulkload", "bucket");
			serializedFile.deleteOnExit();

			// Serialize
			fos = new FileOutputStream(serializedFile);
			oos = new ObjectOutputStream(fos);

			log.debug("serialize:: fase1");

			oos.writeObject(data);

			log.debug("serialize:: fase2");

			dataSize = data.size();
			data = null;

		} catch (IOException e) {
			log.debug(e);
		} finally {
			quietClose(oos);
			quietClose(fos);
		}
	}

	/**
	 * Comprueba si se han serializado los objetos.
	 * 
	 * @return <code>true</code> en caso que se hayan serializado.
	 */
	public boolean serialized() {
		return serializedFile != null;
	}

	public int size() {
		return !serialized() ? data.size() : dataSize;
	}

	/**
	 * Carga desde disco los objetos serializados previamente.
	 */
	@SuppressWarnings("unchecked")
	public void unserialize() {

		if (!serialized())
			return;

		// Unserialize
		FileInputStream fis = null;
		ObjectInputStream ois = null;

		try {
			fis = new FileInputStream(serializedFile);
			ois = new ObjectInputStream(fis);

			log.debug("unserialize:: fase1");

			data = (List<T>) ois.readObject();
			serializedFile.delete();
			serializedFile = null;

			log.debug("unserialize:: fase2");

		} catch (IOException e) {
			log.debug(e);
		} catch (ClassNotFoundException e) {
			log.debug(e);
		} finally {
			quietClose(ois);
			quietClose(fis);
		}
	}
}
