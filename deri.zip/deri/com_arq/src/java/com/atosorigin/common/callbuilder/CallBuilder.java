package com.atosorigin.common.callbuilder;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import javax.persistence.EntityManager;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.springframework.util.StringUtils;

/**
 * Clase para simplificar la interacción con procedimientos y funciones de
 * Oracle.
 * 
 * @author alejandro.torras@atosorigin.com
 */
public class CallBuilder {

	protected static final String FULL_DATE = "dd/MM/yyyy HH:mm:ss";

	protected Log log = LogFactory.getLog(CallBuilder.class);

	protected Connection connection;

	protected CallableStatement cstmt;

	private boolean isClosed = false;

	protected List<String> parametros;

	protected List<Integer> parametrosOutType = new ArrayList<Integer>(3);

	protected Session session;

	protected StringBuilder sql;

	public CallBuilder(EntityManager em) {
		this((Session) em.getDelegate());
	}

	@SuppressWarnings("deprecation")
	public CallBuilder(Session session) {

		if (session == null)
			throw new IllegalArgumentException();

		this.session = session;
		this.connection = session.connection();
		this.parametros = new ArrayList<String>();
	}

	protected String _toString(Date date) {

		return new StringBuilder().append("TO_DATE('").append(
				new SimpleDateFormat(FULL_DATE).format(date)).append(
				"', 'DD/MM/YYYY HH24:MI:SS')").toString();
	}

	public CallBuilder addOutputParameter(int sqlType) throws SQLException {

		parametros.add("?");
		parametrosOutType.add(sqlType);

		log.debug("sqlType:: " + sqlType);

		return this;
	}

	/**
	 * Añade un parámetro a la llamada. Están soportados todos los objetos
	 * básicos de Java, a excepción de entidades, arrays y colecciones.
	 * 
	 * @param parameterValue
	 * @return
	 */
	public CallBuilder addParameter(Object parameterValue) {

		log.debug("parameterValue:: " + parameterValue);

		if (parameterValue == null) {
			parametros.add("null");
		} else if (parameterValue instanceof Date) {
			parametros.add(_toString((Date) parameterValue));
		} else if (parameterValue instanceof Calendar) {
			parametros.add(_toString(((Calendar) parameterValue).getTime()));
		} else if (parameterValue instanceof Number) {
			parametros.add(parameterValue.toString());
		} else {
			parametros.add("'"
					+ parameterValue.toString().replaceAll("'", "''") + "'");
		}

		return this;
	}

	/**
	 * Cierra los recursos utilizados.
	 */
	public void close() {

		if (isClosed)
			return;

		try {
			if (cstmt != null)
				cstmt.close();
		} catch (SQLException e) {
			log.error(e);
		}

		try {
			if (connection != null)
				connection.close();
		} catch (SQLException e) {
			log.error(e);
		}

		try {
			if (session != null)
				session.disconnect();
		} catch (HibernateException e) {
			log.error(e);
		}

		isClosed = true;
	}

	/**
	 * @see CallableStatement#execute()
	 * @return
	 * @throws SQLException
	 */
	public boolean execute() throws SQLException {

		//
		// Generación SQL
		//

		if (!parametros.isEmpty()) {

			sql.append(StringUtils.collectionToDelimitedString(parametros,
					" , "));
		}

		sql.append(" )}");

		//
		// Registrar parámetros OUT
		//

		final String sqlString = sql.toString();

		log.info("sql:: " + sqlString);

		try {
			cstmt = connection.prepareCall(sqlString);

			int i = 1;
			for (Integer j : parametrosOutType)
				cstmt.registerOutParameter(i++, j);

			// EXEC

			return cstmt.execute();

		} catch (SQLException e) {

			log.error(e);

			throw e;
		}
	}

	/**
	 * Finalizador que libera recursos.
	 * 
	 * @see #close()
	 */
	@Override
	protected void finalize() throws Throwable {

		if (!isClosed) {

			log.warn("Cerrando llamada no cerrada previamente: " + sql);

			close();
		}

		super.finalize();
	}

	public CallableStatement getCstmt() {
		return cstmt;
	}

	public Session getSession() {
		return session;
	}

	/**
	 * Prepara el objeto para hacer una llamada de tipo <i>function</i>.
	 * 
	 * @param functionName
	 * @throws SQLException
	 */
	public void setFunctionName(String functionName, int outputParameterType)
			throws SQLException {

		//
		// Limpieza
		//

		parametros.clear();
		parametrosOutType.clear();

		sql = new StringBuilder().append("{ ? = call ").append(functionName)
				.append("(");

		parametrosOutType.add(outputParameterType);
	}

	/**
	 * Prepara el objeto para hacer una llamada de tipo <i>procedure</i>.
	 * 
	 * @param procedureName
	 * @throws SQLException
	 */
	public void setProcedureName(String procedureName) throws SQLException {

		//
		// Limpieza
		//

		parametros.clear();
		parametrosOutType.clear();

		sql = new StringBuilder().append("{ call ").append(procedureName)
				.append("(");
	}

	public void setSession(Session session) {
		this.session = session;
	}
}
