package com.atosorigin.common.constantes;

import java.math.BigDecimal;

import org.jboss.seam.core.ResourceBundle;

/**
 * The Class Constantes.
 */
public class Constantes {
	
	/** String que representa la cadena vac�a. */
	public static final String CADENA_VACIA = "";
	
	/** Mensaje de error por defecto. Extraido del bundle gen�rico. */
	public static final String DEFAULT_MESSAGE_TEMPLATE = "#{messages['errores.errorgenerico']}";
	
	/** N�mero m�ximo de registros que se pueden incluir en una exportaci�n a Excel. */
	//public static final Integer MAX_RESULTS_EXCEL = 65500;
	//FLM: m�ximo 32000
	public static final Integer MAX_RESULTS_EXCEL = 32500;

	//N�mero de registros m�ximos a seleccionar con Seleccionar todos
	public static final Integer MAX_RESULTS_SELECCION_TOTAL = 500;

	//N�mero de registros m�ximos (2000) a seleccionar con Seleccionar todos
	public static final Integer MAX_RESULTS_SELECCION_TOTAL_2000 = 2000;

	/** Nombre del proyecto DERI. */
	public static final String NOMBRE_PROYECTO_DERI = "DERI";
	public static final String NOMBRE_PROYECTO_COLAT = "COLAT";
	public static final String NOMBRE_PROYECTO_DERI2 = "DERI2";
	public static final String NOMBRE_PROYECTO_COLAT2 = "COLAT2";
	
	/** C�digo Periodicidad "Unico". */
	public static final String COD_PERIODICIDAD_UNICO = "U";
	
	/** C�digo Periodicidad "Diaria". */
	public static final String COD_PERIODICIDAD_DIARIA = "D";

	/** Nivel Urgencia B". */
	public static final String NIVEL_URGENCIA_B = "B";

	/** No */
	public static final String CONSTANTE_NO = "N";

	/** SI */
	public static final String CONSTANTE_SI = "S";

	/** % */
	public static final String CONSTANTE_PERCENT = "%";

	/** SEPARADOR FECHA */
	public static final String SEPARADOR_FECHA = "/";
	public static final String PATTERN_FECHA = "yyyyMMdd";

	/** TIPOS DE ENVIO */

	public static final String TIPOENVIO_R = "R";
	public static final String TIPOENVIO_O = "O";
	public static final String TIPOENVIO_F = "F";
	public static final String TIPOENVIO_M = "M";

	public static final String TIPOENVIO_R_DESC = "Rec.de Red";
	public static final String TIPOENVIO_O_DESC = "Oracle";
	public static final String TIPOENVIO_F_DESC = "Fax";
	public static final String TIPOENVIO_M_DESC = "Mail";
	public static final String SUSCRIPCIONID_IND ="1";

	/** SUCCESS */
	public static final String CONSTANTE_SUCCESS = "success";
	public static final String SUCCESS = Constantes.CONSTANTE_SUCCESS;
	public static final String CONSTANTE_FAIL = "fail";
	public static final String FAIL = Constantes.CONSTANTE_FAIL;

	/** DIVISAS */
	public static final String DIVISA_COTIZABLE = "X";
	public static final String DIVISA_TIPO_B = "B";
	public static final Short DIVISA_BASECALC_360 = 360;
	public static final Short DIVISA_BASECALC_365 = 365;
	public static final BigDecimal DIVISA_MARGEN_5 = BigDecimal.valueOf(5, 0);
	public static final BigDecimal DIVISA_MARGEN_10 = BigDecimal.valueOf(10, 0);
	public static final BigDecimal DIVISA_MARGEN_20 = BigDecimal.valueOf(20, 0);
	public static final String DIVISA_EUR = "EUR";


	/** INFORMES */
	public static final Short INFORME_SERVIDOR = 1;

	/** ESTADO DE PETICION */
	public static final String PE = "PE";
	public static final String CO = "CO";



	/** ID DE LISTADOS */
	public static final Short UNO = 1;
	public static final Short SIETE = 7;
	public static final Short OCHO = 8;
	public static final Short NUEVE = 9;
	public static final Short DIEZ = 10;
	public static final Short ONCE = 11;
	public static final Short DOCE = 12;
	public static final Short TRECE = 13;
	public static final Short CATORCE = 14;
	public static final Short QUINCE = 15;
	public static final Short DIECISEIS = 16;
	public static final Short DIECISIETE = 17;
	public static final Short DIECIOCHO = 18;

	/** MODOS DOCUMENTOS POR CONTRAPARTIDA */
	public static final String MODO_MC = "MC";
	public static final String MODO_AGE = "AGE";
	public static final String MODO_OPE = "OPE";
	public static final String MODO_OPM = "OPM";
	public static final String MODO_CAM = "CAM";


	/** ESTADOS DOCUMENTOS CONTRAPARTIDA */
	public static final String ESTADOCO_C = "C";
	public static final String ESTADOCO_F = "F";
	public static final String ESTADOCO_T = "T";

	/** ESTADO DOCUMENTO */
	public static final String EST_DOC_COD_INICIO = "I";
	public static final String EST_DOC_DESCR_INICIO = "Inicio";
	public static final String EST_DOC_COD_PRESCRITO = "P";
	public static final String EST_DOC_DESCR_PRESCRITO = "Prescrito";
	public static final String EST_DOC_COD_VIGOR = "V";
	public static final String EST_DOC_DESCR_VIGOR = "Vigor";

	//SMM BUG HPQC 25
	/** INDICADOR ACTIVA */
	public static final String COD_IND_INACTIVO = "N";
	public static final String DESC_IND_INACTIVO = "No";
	
	/** TIPOS DE PAR�METRO DE INFORME */
	public static final String PARAM_TIPO_DATE_COD = "D";
	public static final String PARAM_TIPO_CHAR_COD = "C";
	public static final String PARAM_TIPO_NUMBER_COD = "N";
	public static final String PARAM_TIPO_DATE_DESC = "DATE";
	public static final String PARAM_TIPO_CHAR_DESC = "CHAR";
	public static final String PARAM_TIPO_NUMBER_DESC = "NUMBER";

	/** TIPOS DE PARAMETROS PARA CONSULTAS CUSTOMIZADAS */
	public static final String NUMERICO = "NU";
	public static final String FECHA = "FE";
	public static final String LONGITUD = "CH";

	/** DATE FORMATS */
	public static final String DDMMYYYY = "dd/MM/yyyy";
	public static final String MMDDYYYY = "MM/dd/yyyy";
	public static final String DDMMYYYYHHMMSS = "dd/MM/yyyy HH:mm:ss";
	public static final String YYYYMMDD = "yyyyMMdd";
	public static final String DDMMRRRR = "dd/MM/rrrr";
	public static final String DDMMRRRRHHMMSS = "dd/MM/rrrr HH24:mi:ss";
	public static final String YYYYMMDD10 = "yyyy-MM-dd";

	/** REGISTROS A RECUPERAR EN PARAMETROS CONCILIACION*/

	public static final String FECHA1 = "FECHA";
	public static final String MARGEN = "MARGEN";

	/** CONCEPTO PRIMA */
	public static final String CONCEPTO_PRIMA = "PRI";

	/** OPCION INDIFERENTE */
	public static final String INDIFERENTE = "Indiferente";

	/** TOTALES DE CLIENTE Y MERCADO	 */
	public static final String TOTCLI = "TotalCliente";
	public static final String TOTMERC = "TotalMercado";

	/** ESTADOS SWIFT*/
	public static final String VALIDADO = "VA";
	public static final String DESCARTADO = "DE";
	public static final String ENVIADO = "EN";

	public static final String LIQ_ENVIADA = "ENV";

	/** ESTADOS TIPOS POR INDICE */
	public static final String TIPOINDICE_ESTADO_PV = "PV";
	public static final String TIPOINDICE_ESTADO_VA = "VA";
	public static final String TIPOINDICE_ESTADO_PI = "PI";

	/** ESTADO MOVIMIENTO */
	public static final String EST_MOV_PEN = "PEN";
	public static final String EST_MOV_CRC = "CRC";
	public static final String EST_MOV_ANU = "ANU";

	/** INDIC AUX */
	public static final String IND_AUX_CN = "CN";
	public static final String IND_AUX_NN = "NN";

	/** OPERACIONES ORIGEN */
	public static final String OPERACION_NO_CASADA = "NO_CASADAS";

	/**COPIA DE OPERACIONES**/
	public static final String OPER_NO_EXIST = "OPER. NO EXISTE / F�RM. <> 1022";
	public static final String PRODUCT_DIFF = "PRODUCTO OPER. <> IRS";
	public static final String PRODUCT_DIFF_OPC = "PRODUCTO OPER. <> OPC";
	public static final String OPER_EXIST = "OPERACI�N ENCONTRADA";
	public static final String OPER_NO_FECHAS = "OPER. NO TIENE FECHAS LIQUIDACION";
	public static final String OPER_PRODUCT = "751201";
	public static final String MODELO_OPCION= "OPC";
	public static final String COND_FIJACION = "C";
	public static final String FLUJOS = "F";
	public static final String FECHAS_LIQUIDACION = "L";
	public static final String DATOS_OPCION = "O";
	public static final String CRUZADAS = "S";
	public static final String NO_CRUZADAS = "N";
	public static final String COPIARPRIMA = "S";
	public static final String NO_COPIARPRIMA = "N";
	public static final String PATA_PAGO="P";
	public static final String PATA_RECIBO="R";

	/** OPERACIONES CLASE */
	public static final String OPERACION_CLASE_CL = "Cliente";
	public static final String OPERACION_CLASE_ME = "Mercado";

	/** BLOQUEOS */
	public static final String SISTEMA_BLOQUEO_GUI   = "O";
	public static final String SISTEMA_BLOQUEO_BATCH = "B";
	public static final String SISTEMA_BLOQUEO_DATEFORMAT = "yyyyMMddHHmmss";
	public static final String SISTEMA_BLOQUEO_DATEFORMAT_SHORT = "yyyyMMdd";
	
	public static final String CAMP_NO_DISTRIBUIDAS = "L";	
	
	/** CAMPA�AS */
	public static final String CAMPANYA_ESTADO_VA = "VA";
	public static final String CAMPANYA_ESTADO_PV = "PV";
	public static final String CAMPANYA_ESTADO_CA = "CA";
	public static final String CAMPANYA_ESTADO_VE = "VE";
	public static final String CAMPANYA_ESTADO_AN = "AN";
	public static final String CAMPANYA_ESTADO_FI = "FI";

	/** ERRORES CAPTURA MUREX **/
	public static final String OPERACIONES = "Operaciones";
	public static final String ESTRUCTURAS = "Estructuras";
	public static final String TODOS = "Todos";

	/** TIPO INFORME */
	public static final String TIPO_INFORME_USUARIO = "U";
	public static final String TIPO_INFORME_TODOS = "T";

	/** ESTADO INFORME */
	public static final String INDICADOR_INFORME_FINALIZADO = "Z";
	public static final String ESTADO_INFORME_FINALIZADO = "FINALIZADO";
	public static final String INDICADOR_INFORME_IMPRESION = "I";
	public static final String ESTADO_INFORME_IMPRESION = "IMPRESION";

	/** PARAMETROS INFORME */
	public static final String SEPARADOR_PARAMETRO_VALOR = "@";
	public static final String SEPARADOR_PARAMETROS = "/";

	/** GRUPOS CONTABLES */
	public static final String GRUPO_CONTABLE_CA = "CA";
	public static final String GRUPO_CONTABLE_CE = "CE";
	
	/** TIPOS C�DIGOS LISTADOS*/
	public static final String TIPO_LISTADO_DERIVISI = "DERIVISI";
	public static final String TIPO_LISTADO_DERIVIS2 = "DERIVIS2";
	public static final String TIPO_LISTADO_DERIVIS3 = "DERIVIS3";
	public static final String TIPO_LISTADO_DERIVIS4 = "DERIVIS4";
	public static final String TIPO_LISTADO_DERIVIS5 = "DERIVIS5";
	public static final String TIPO_LISTADO_DERIVIS6 = "DERIVIS6";
	public static final String TIPO_LISTADO_DERIVIS7 = "DERIVIS7";
	public static final String TIPO_LISTADO_DERIVIS8 = "DERIVIS8";
	public static final String TIPO_LISTADO_DERIVIS9 = "DERIVIS9";
	public static final String TIPO_LISTADO_DERIVISC = "DERIVISC";
	public static final String TIPO_LISTADO_DERIVISD = "DERIVISD";
	public static final String TIPO_LISTADO_DERIVISA = "DERIVISA";
	public static final String TIPO_LISTADO_DERIVISB = "DERIVISB";


	/** TIPOS REPORT */
	public static final String TIPO_REPORT_81 = "81";
	public static final String TIPO_REPORT_01 = "01";
	public static final String TIPO_REPORT_185 = "185";
	public static final String TIPO_REPORT_05 = "05";
	public static final String TIPO_REPORT_42 = "42";
	public static final String TIPO_REPORT_BG = "BG";

	/** PARAMETROS LIQUIDACION */
	public static final String CONSTANTE_SWIFT = "SWIFT";
	public static final String CONSTANTE_CUENTA = "CUENTA";
	public static final String CONSTANTE_CLIENTE = "CLIENTE";
	public static final String CONSTANTE_TARGET = "TARGET";
	public static final String ENTIDAD_SWIFT_TARGET = "0081";
	public static final String OFICINA_SWIFT_TARGET = "901";
	public static final String ESTADO_EVENTO_P = "P";



	public static final String AUTOMATICO = "A";
	public static final String MANUAL = "M";

	public static final String MODELIZADA = "M";

	public static final String ACCION_A = "A";
	public static final String ACCION_M = "M";

	public static final String RIESGO_S = "S";
	
	/** INFORMACI�N ANEXA */
	public static final String TIPOANEXO_OPERACION = "O";
	public static final String TIPOANEXO_CONFIRMACION = "C";
	public static final String TIPOANEXO_PRECONFIRMACION = "P";
	public static final String TIPOANEXO_CUENTA = "T";
	public static final String TIPOANEXO_LIQUIDACION = "L";
	public static final String TIPOANEXO_RECLAMACION= "R";

	public static final String TIPOANEXO_MODO_A = "A";
	public static final String TIPOANEXO_MODO_C = "C";
	public static final String TIPOANEXO_MODO_E = "E";
	public static final String TIPOANEXO_DESCR_OPERACION = "Operaci�n";
	public static final String TIPOANEXO_DESCR_CONFIRMACION = "Confirmaci�n";
	public static final String TIPOANEXO_DESCR_RECLAMACION = "Reclamaci�n";
	public static final String TIPOANEXO_DESCR_CUENTA = "Cuenta";
	public static final String TIPOANEXO_DESCR_PRECONFIRMACION = "PreConfirmaci�n";
	public static final String TIPOANEXO_DESCR_LIQUIDACION = "Liquidaci�n";
	
	
	/** CIRCULARIZACION **/
	public static final String APLICACION_COLAT="COLAT";
	public static final String APLICACION_DERI="DERI";
	public static final String APLICACION_DEDALO="DEDALO";
	public static final String APLICACION_MMOO="MMOO";
	
	/** TIPOS MODELO CAMPA�A*/
	public static final String TIPO_MODELO_DD000002 = "DD000002";
	public static final String TIPO_MODELO_DD000002_PROD = "751411";
	public static final String TIPO_MODELO_DD000001 = "DD000001";
	public static final String TIPO_MODELO_DD000001_PROD = "751201";	
	
	
	
	/** TIPOS PRIMA CAMPA�A*/
	public static final String TIPO_PRIMA_FIJA = "F";
	public static final String TIPO_PRIMA_PERIODICA = "T";
	public static final String TIPO_PRIMA_PORCENTAJE = "P";

	public static final String TIPO_PRIMA_N = "N";
	
	/** TIPOS ESTILO CAMPA�A*/
	public static final String TIPO_ESTILO_CUSTOMIZADA= "C"; 
	public static final String TIPO_ESTILO_MODELIZADA = "M";


	/** TIPOS OPERACIONES COBERTURA*/
	public static final String TIPO_COBERTURA_SI= "S";
	public static final String TIPO_COBERTURA_NO= "N";
	public static final String TIPO_COBERTURA_PARCIAL= "P";
	
	
	/** TIPOS CAMPA�A*/
	public static final String TIPO_CAMPANYA_DISTRIBUIDA= "D";
	public static final String TIPO_CAMPANYA_LOCAL= "L";
	
	
	/** ESTADOS CAMPA�A*/
	public static final String TIPO_ESTADO_IN= "IN";
	public static final String TIPO_ESTADO_PV= "PV";
	
	/** ALTA CAMPA�A*/
	
	public static final Short ALTA_CAMPANYA_OFICINA= Short.parseShort("0901");
	public static final Short ALTA_CAMPANYA_CORREO_POSTAL_INTERNO= Short.parseShort("0022");
	public static final String ALTA_CAMPANYA_SUS_VIGENTES_NO= "N";
	public static final String ALTA_CAMPANYA_SUS_VIGENTES_SI= "S";
	
	/** ACCIIONES MANTENIMIENTO CAMPA�AS*/
	
	public static final String MANT_CAMPANYAS_ALTA = "A";
	public static final String MANT_CAMPANYAS_MODIFICACION= "M";
	public static final String MANT_CAMPANYAS_CONSULATA= "C";
	
	/** ORIGEN MANTENIMIENTO CAMPA�AS*/
	
	public static final String ORIGEN_ALTA="ORIGEN_ALTA";
	public static final String ORIGEN_MODIFICACION="ORIGEN_MODIFICACION";
	public static final String ORIGEN_CONSULTA_LIST_COMAPANYAS="ORIGEN_CONSULTA_LIST_COMAPANYAS";
	public static final String ORIGEN_CONSULTA_MANTENIMIENTO_SUSCRIPCIONES="ORIGEN_CONSULTA_MANTENIMIENTO_SUSCRIPCIONES";


	public static final String MANT_CAMPANYAS_CAMPO_NO_INFORMADO="-1";

	/** TIPOS STRIKE */
	public static final String TIPOSTRI_F = "F";
	public static final String TIPOSTRI_V = "V";
	public static final String TIPOSTRI_N = "N";
	public static final String TIPOSTRI_I = "I";

	/** ESTADO RECHAZOSCONTABLES */
	public static final String EST_RC_PDTE_CORREGIR = "PC";
	public static final String EST_RC_PDTE_ENVIAR = "PE";
	public static final String EST_RC_ENVIADO = "EN";
	public static final String EST_RC_DESCARTADO = "DE";

	/** MODO MANTENIMIENTO DE FECHAS */
	public static final String MODO_EJERCICIO="EJ";
	public static final String MODO_STRIKE="FS";
	public static final String MODO_SELECCION="SE";
	public static final String MODO_LIQUIDACION="LI";
	public static final String MODO_RANGO="RA";
	public static final String MODO_PAY_OFF="PO";

	/** CONDFIJA */
	public static final String ESPACIO = " ";
	public static final String CODINDICE_E = "E";
	public static final String CODINDICE_F = "F";
	public static final String CODINDICE_V = "V";
	public static final String ECUACION = "Ecuaci�n";
	public static final String FIJO = "Fijo";
	public static final String VARIABLE = "Variable";
	public static final String DESCONOCIDO = "Desconocido";

	/** LISTA SUSCRIPCIONES*/
	public static final int MAX_ROWS=10;
	public static final String ORDEN_ESTADO_VA = "VA";
	public static final String ORDEN_ESTADO_PV = "PV";
	public static final String ORDEN_ESTADO_CA = "CA";
	public static final String ORDEN_ESTADO_VE = "VE";
	public static final String ORDEN_ESTADO_AN = "AN";
	public static final String ORDEN_ESTADO_IN = "IN";
	public static final String ORDEN_ESTADO_ER = "ER";
	public static final String ORDEN_VALIDAR = "validar";
	public static final String ORDEN_ANULAR = "anular";
	public static final String ORDEN_CANCELAR = "cancelar";
	public static final String ORDEN_MODIFICAR = "modificar";

	/** EVENTO AGENDA */
	public static final int MAX_ROWSAGENDA=500;
	public static final Short EVENTO_3610 = Short.parseShort("3610");
	public static final Short EVENTO_3611 = Short.parseShort("3611");
	public static final Short EVENTO_3612 = Short.parseShort("3612");
	public static final Short EVENTO_3772 = Short.parseShort("3772");
	public static final Short EVENTO_3774 = Short.parseShort("3774");
	public static final Short EVENTO_3776 = Short.parseShort("3776");
	public static final Short EVENTO_4013 = Short.parseShort("4013");

	public static final String EVENTO_1800 = "1800";
	public static final String EVENTO_37 = new String("37");
	public static final String EVENTO_71 = new String("71");
	public static final String EVENTO_72 = new String("72");

	public static final Short EVENTO_2004 = Short.parseShort("2004");

	public static final String EVENTO_PDTE_Si = ResourceBundle.instance().getString("evento.pdte.si");
	public static final String EVENTO_PDTE_No = ResourceBundle.instance().getString("evento.pdte.no");
	public static final String EVENTO_TIPO_ACCION = ResourceBundle.instance().getString("evento.accion");
	public static final String EVENTO_TIPO_AVISO = ResourceBundle.instance().getString("evento.aviso");
	public static final String EVENTO_TIPO_AGRUPADO = ResourceBundle.instance().getString("evento.agrupado");

	public static final int EVENTO_TIEMPORE_2030 = 2030;
	public static final String STOP = "STOP";

	/** OPERPROLI */
	public static final String  LIQUIDACION_PDTE_VALIDAR = "PV";
	public static final String  LIQUIDACION_VALIDADA = "VA";
	public static final String  LIQUIDACION_TIPOPERA_P = "P";
	public static final String  LIQUIDACION_TIPOPERA_C = "C";
	public static final String  LIQUIDACION_TIPOPERA_PAGO = "Pago";
	public static final String  LIQUIDACION_TIPOPERA_COBRO = "Cobro";
	public static final String  LIQUIDACION_ACCION_DESCARTAR = "DESCARTAR";
	public static final String  LIQUIDACION_ACCION_VALIDAR = "VALIDAR";
	public static final String  LIQUIDACION_ACCION_DESVALIDAR = "DESVALIDAR";
	public static final String  LIQUIDACION_ACCION_LIQUIDAR = "LIQUIDAR";
    public static final String  LIQUIDACION_LIQUIDADA = "LI";
    public static final String  LIQUIDACION_ERROR = "ER";
	
	/** TIPOS BARRERA */
	public static final String  BARRERAS_TIPOBARRERA_IN = "I";
	public static final String  BARRERAS_TIPOBARRERA_OUT = "O";

	/**COMBOS DETALLE BARRERA*/
	public static final String  BARRERAS_TIPOBARRERA_NULL = "NULL";

	/**TIPO REVISION*/
	public static final String  BARRERAS_TIPOREVISION_AMERICANA = "I";
	public static final String  BARRERAS_TIPOREVISION_EUROPEA = "E";


	/** TIPOS IND. REBATE */
	public static final String  BARRERAS_TIPO_INDREBATE_SI = "S";
	public static final String  BARRERAS_TIPO_INDREBATE_NO = "N";

	/** BARRERAS MODOBARR*/
	public static final String  BARRERAS_MODOBARR_IN = "IN";

	/** TIPO REBATE */
	public static final String  BARRERAS_TIPOREBATE_IMPORTE = "I";
	public static final String  BARRERAS_TIPOREBATE_PORCENTAJE = "P";


	/** Subyacente */
	public static final String  DESCRIPCIONCORTA_SIN_INFORMAR = "SIN INFORMAR";
	
	/** CANALES DE LIQUIDACI�N */
	public static final String CANAL_SWIFT = "SWF";
	public static final String CANAL_CLIENTE = "CTA";
	public static final String CANAL_TARGET = "TAR";
	public static final String CANAL_SWIFT_DESCR = "SWIFT";
	public static final String CANAL_CLIENTE_DESCR = "CLIENTE";
	public static final String CANAL_TARGET_DESCR = "TARGET";

	public static final String CONTRAPA_GRUPOBAN_CLIENTE = "CLIENTES";

	/** CODIGOS PANTALLA */
	public static final String PANT_MANTOPER = "MANTOPER";
	public static final String PANT_OPEPROLI = "OPEPROLI";
	public static final String PANT_MANTIPIN = "MANTIPIN";
	public static final String PANT_MANCONTR = "MANCONTR";
	public static final String PANT_MANTESTR = "MANTESTR";
	public static final String PANT_ERRINTMX = "ERRINTMX";

	/** TIPOS DE EVENTO */
	public static final String TIPO_EVENTO_BARRERA = "TBARRERA";
	public static final String TIPO_EVENTO_EJERCICIO = "EJERCICIO";

	/** EVENTOS de GRUPO DE DATOS CONFIRMACIONES PROD COMPS*/
	public static final String EVENTO_CONTRATACION = "A";
	public static final String EVENTO_MODIFICACION = "M";
	public static final String EVENTO_CANCELACION = "C";
	public static final String EVENTO_CANCPARCIAL = "P";
	public static final String EVENTO_LIQUIDACION = "X";
	public static final String EVENTO_FIJTIPOS = "L";

	public static final String CANAL_MANUAL = "MM";
	public static final String SENTIDO_ENVIAR = "E";
	public static final String SENTIDO_RECIBIR = "R";

	/** TIPOS DE MODELOS */
	public static final String MODELO_OPC = "OPC";
	public static final String MODELO_EQU = "EQU";

	/** TIPOS DE ESTADO */
	public static final String ESTADO_VA = "VA";
	public static final String ESTADO_EX = "EX";
	public static final String ESTADO_VE = "VE";
	public static final String ESTADO_AN = "AN";

	/** ORIGENES DE PANTALLAS */
	public static final String ORIGEN_OPE = "OPE";
	public static final String ORIGEN_PRODCOM = "PRODCOM";

	/** TOQUE BARRERA - MANTOQE **/
	public static final String MANTOQE_TIPO_P = "P";
	public static final String MANTOQE_PAGO = "Pago";
	public static final String MANTOQE_COBRO = "Cobro";
	public static final String MANTOQE_S = "S";
	public static final String MANTOQE_N = "N";
	public static final String MANTOQE_O = "O";
	public static final String MANTOQE_I = "I";
	public static final String MANTOQE_D = "D";
	public static final String MANTOQE_U = "U";
	public static final String MANTOQE_INT = "INT";
	public static final String MANTOQE_OPC = "OPC";
	public static final String MANTOQE_PATA_P = "P";
	public static final String MANTOQE_SIGNO_MAS = "+";
	public static final String MANTOQE_SIGNO_MENOS = "-";
	public static final String MANTOQE_TIPO_E = "E";
	public static final String MANTOQE_ORIGEN_OPE = "OPE";

	/** EVENTOS ACEPTAR OPERACIONES */
	public static final String EVENTO_6001 = "6001";
	public static final String EVENTO_6002 = "6002";
	public static final String EVENTO_6005 = "6005";

	public static final String COD_XXX = "XXX";

	public static final String IDIOMA_ES = "8";

	public static final String MASCARA_SEPARADOR_MILES = "####.###.###.###,00";
	public static final String MASCARA_PORCENTAJES = "#############,0000";

	/**
	 * Fecha usada por el contador asociado de CODCONFI.
	 */
	public static final String FECHA_CONTADOR_CODCONFI = "31/10/2005";

	/**
	 * C�digos de idioma: 
	 * <code>SELECT * FROM gestio_tressoreria.desccodi WHERE nomtabla = 'MODECONF' AND nomcampo = 'IDIOMACO'</code>
	 */
	public static final String IDIOMA_CASTELLANO = "08";
	public static final String IDIOMA_CATALAN = "01";
	public static final String IDIOMA_INGLES = "13";
	public static final String IDIOMA_CASTELLANO_ABREVIADO = "8";
	public static final String IDIOMA_CATALAN_ABREVIADO = "1";
	public static final String IDIOMA_INGLES_ABREVIADO = "3";

	public static final String I18N_IDIOMA_CASTELLANO_FD = "es_ES";
	public static final String I18N_IDIOMA_CATALAN_FD = "ca_ES";
	public static final String I18N_IDIOMA_INGLES_FD = "en_EN";

	/**
	 * DERI.CONFIOPE.MODELCON
	 */
	public static final String MODELCON_MIGRADO = "MIGRADO";

	public static final Long PRODUCTO_SWAPTION = 904L;
	public static final Long PRODUCTO_SWAPTION2 = 905L;

	public static final String TIPO_EXPEDIENTE = "ContratoDD";
	public static final String TIPO_DOCUMENTO = "ConfirmacionesTS";

	public static final String DESCRIPCION_INACTIVA_ORDEN = "80";

	public static final String FECHA_CONTADOR_PETICION = "01/01/2012";
	public static final String CONCEPTO_CONTADOR_PETICION = "PETICION";
	public static final Integer CONTADOR_PETICION = 1;
	public static final String DESCRIPCION_CONTADOR_PETICION = "N�mero de Petici�n";	
	
	public static final String PETICION_VALIDAR_LIQUIDACION = "LIQVALIDAR";
	public static final String PETICION_EXCEL_LIQUIDACION = "LIQEXCEL";
	public static final String PETICION_VALIDAR_OPERACION = "MTOVALIDAR";
	public static final String PETICION_EXCEL_OPERACION = "MTOEXCEL";
	public static final String PETICION_EXCEL_CONFIRMACION = "CONEXCEL";
	public static final String PETICION_ENVIAR_CONFIRMACION = "CONENVIAR";
	public static final String PETICION_LISTADO_RECLAMACION = "LISTRECLAM";
	public static final String PETICION_EXCEL_MIGRABMN = "BMNEXCEL";
	public static final String PETICION_EXCEL_MIGRACIO = "MIGRAEXCEL";
	public static final String PETICION_EXCEL_AJUSTESMANUALES = "AJUMEXCEL";
	public static final String PETICION_EXCEL_LIBNOTIF= "LINOEXCEL";

	public static final String PETICION_EXCEL_CONSCUST= "CUSTOEXCEL";


	public static final String PETICION_EN_ESPERA = "ES";

	public static final String CONCEPTO_CONTADOR_SWIFT = "NUMSWIFT";
	public static final Integer CONTADOR_SWIFT = 1;
	public static final String DESCRIPCION_CONTADOR_SWIFT = "Numerador mensajes Swift.";

	public static final String BANCSABADELL_LEI= "BSABESBBXXX";

	public static final String DOCUCONT_CMOF= "CMOF";
}
