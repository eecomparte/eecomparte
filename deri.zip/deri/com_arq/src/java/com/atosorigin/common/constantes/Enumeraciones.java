package com.atosorigin.common.constantes;

/**
 * Enumeraciones para asociar el ámbito o dominio de los valores, una
 * descripción clara y el código asociado.
 * 
 * @author alejandro.torras@atosorigin.com
 */
public interface Enumeraciones {

	public static enum ClasificacionOperacion implements Enumeraciones {
		CLIENTE("CL"), MERCADO("ME");

		private String value;

		private ClasificacionOperacion(String value) {
			this.value = value;
		}

		@Override
		public String toString() {
			return value;
		}

		public boolean equals(String other) {

			if (other == null)
				return false;

			return name().equals(other.toUpperCase().replaceAll(" ", "_"))
					|| value.equals(other);
		}

		public boolean equals(Number other) {
			if (other == null)
				return false;

			return equals(other.toString());
		}
	}

	public static enum PantallaOrigenCasarOperacion implements Enumeraciones {
		CASADAS, NO_CASADAS;

		public boolean equals(String other) {
			return name().equals(other.toUpperCase().replaceAll(" ", "_"));
		}

		public boolean equals(Number other) {
			if (other == null)
				return false;

			return equals(other.toString());
		}
	}

	public static enum EstadoOperacion implements Enumeraciones {
		ANULADA("AN"), CANCELADA("CA"), EJERCIDA("EJ"), EXPIRADA("EX"), INCOMPLETA(
				"IN"), PENDIENTE_VALIDAR("PV"), VALIDADA("VA"), VENCIDA("VE");

		private String value;

		private EstadoOperacion(String value) {
			this.value = value;
		}

		@Override
		public String toString() {
			return value;
		}

		public boolean equals(String other) {

			if (other == null)
				return false;

			return value.equals(other)
					|| name().equals(other.toUpperCase().replaceAll(" ", "_"));
		}

		public boolean equals(Number other) {
			if (other == null)
				return false;

			return equals(other.toString());
		}
	}

	public static enum CanalOperacion implements Enumeraciones {
		BATCH_EMAIL("BE"), BATCH_FAX("BF"), BATCH_MANUAL("BM"), CORREO_INTEGRADO(
				"CI"), MANUAL_MANUAL("MM"), ON_LINE_EMAIL("OE"), ON_LINE_FAX(
				"OF"), ON_LINE_LOGALTY("OL"), ON_LINE_MANUAL("OM"), URGENTE("UR"), SWIFT("SW");

		private String value;

		private CanalOperacion(String value) {
			this.value = value;
		}

		@Override
		public String toString() {
			return value;
		}

		public boolean equals(String other) {

			if (other == null)
				return false;

			return value.equals(other)
					|| name().equals(other.toUpperCase().replaceAll(" ", "_"));
		}

		public boolean equals(Number other) {
			if (other == null)
				return false;

			return equals(other.toString());
		}
	}

	public static enum SentidoConfirmacion implements Enumeraciones {
		ENVIAR("E"), RECIBIR("R");

		private String value;

		private SentidoConfirmacion(String value) {
			this.value = value;
		}

		@Override
		public String toString() {
			return value;
		}

		public boolean equals(String other) {

			if (other == null)
				return false;

			return value.equals(other)
					|| name().equals(other.toUpperCase().replaceAll(" ", "_"));
		}

		public boolean equals(Number other) {
			if (other == null)
				return false;

			return equals(other.toString());
		}
	}

	/**
	 * <pre>
	 * SELECT *
	 *   FROM gestio_tressoreria.desccodi
	 *  WHERE nomcampo = 'ESTADOCO'
	 *    AND nomtabla = 'CONFIOPE'
	 * </pre>
	 */
	public static enum EstadoConfirmacion implements Enumeraciones {
		ANULADA("AN"), PROCESADA("PR"), DESCARTADO("DE"), // 
		IRRECUPERABLE("IR"), IRRECUPERABLE_DESCARTADA("IV"), // 
		PENDIENTE_BATCH("PB"), PENDIENTE_CONFIRMAR("PC"), // 
		PDTE_RECIBIR_CONFIRMACION("RP"), RECIBIDA("RE"), NO_VISIBLE("NV"), RECEPCIONADA("RC");

		private String value;

		private EstadoConfirmacion(String value) {
			this.value = value;
		}

		@Override
		public String toString() {
			return value;
		}

		public boolean equals(String other) {

			if (other == null)
				return false;

			return value.equals(other)
					|| name().equals(other.toUpperCase().replaceAll(" ", "_"));
		}

		public boolean equals(Number other) {
			if (other == null)
				return false;

			return equals(other.toString());
		}
	}

	public static enum MarcaDeAgua implements Enumeraciones {
		// Códigos especificados en HPQC 1701
		DUPLICADO("C"), ANULADO("D"), ORIGINAL("O");

		private String value;

		private MarcaDeAgua(String value) {
			this.value = value;
		}

		@Override
		public String toString() {
			return value;
		}

		public boolean equals(String other) {

			if (other == null)
				return false;

			return name().equals(other.toUpperCase().replaceAll(" ", "_"))
					|| value.equals(other);
		}

		public boolean equals(Number other) {
			if (other == null)
				return false;

			return equals(other.toString());
		}
	}

	/**
	 * <pre>
	 * SELECT *
	 *   FROM gestio_tressoreria.desccodi
	 *  WHERE propieta = 'DERI'
	 *    AND nomcampo = 'EVENCONF'
	 * </pre>
	 */
	public static enum EventoConfirmacion implements Enumeraciones {
		ALTA("A"), ANULACION("N"), CANCEL_PARCIAL("P"), CANCELACION("C"), EJERCICIO(
				"J"), EJERC_PARCIAL("K"), FIJACION("L"), LIQUIDACION("X"), RECTIFICACION(
				"M"), TOQUE_BARRERA("T");

		private String value;

		private EventoConfirmacion(String value) {
			this.value = value;
		}

		@Override
		public String toString() {
			return value;
		}

		public boolean equals(String other) {

			if (other == null)
				return false;

			return value.equals(other)
					|| name().equals(other.toUpperCase().replaceAll(" ", "_"));
		}

		public boolean equals(Number other) {
			if (other == null)
				return false;

			return equals(other.toString());
		}
	}

	/**
	 * <code>SELECT * FROM gestio_tressoreria.grupoban</code>.
	 */
	public static enum GrupoBancario implements Enumeraciones {
		CLIENTES_EXTERNOS("CLIENTES");

		private String value;

		private GrupoBancario(String value) {
			this.value = value;
		}

		@Override
		public String toString() {
			return value;
		}

		public boolean equals(String other) {

			if (other == null)
				return false;

			return name().equals(other.toUpperCase().replaceAll(" ", "_"))
					|| value.equals(other);
		}

		public boolean equals(Number other) {
			if (other == null)
				return false;

			return equals(other.toString());
		}
	}

	/**
	 * <code>SELECT * FROM gestio_tressoreria.tipocont</code>
	 */
	public static enum TipoContrapartida implements Enumeraciones {
		ENTIDAD_FINANCIERA("E"), CLIENTES_TESORERIA("C"), BANCOS("B");

		private String value;

		private TipoContrapartida(String value) {
			this.value = value;
		}

		@Override
		public String toString() {
			return value;
		}

		public boolean equals(String other) {

			if (other == null)
				return false;

			return value.equals(other)
					|| name().equals(other.toUpperCase().replaceAll(" ", "_"));
		}

		public boolean equals(Number other) {
			if (other == null)
				return false;

			return equals(other.toString());
		}
	}

	public static enum TipoReclamacion implements Enumeraciones {
		NO_RECIBIDA("R"), ERRONEA("E"),MODIFICADA("M"), F("F"), C("C"), R("R");

		private String value;

		private TipoReclamacion(String value) {
			this.value = value;
		}

		@Override
		public String toString() {
			return value;
		}

		public boolean equals(String other) {

			if (other == null)
				return false;

			return value.equals(other)
					|| name().equals(other.toUpperCase().replaceAll(" ", "_"));
		}

		public boolean equals(Number other) {
			if (other == null)
				return false;

			return equals(other.toString());
		}
	}

	public static enum TipoDesglose implements Enumeraciones {
		DERI("1"), OTROS("2");

		private String value;

		private TipoDesglose(String value) {
			this.value = value;
		}

		@Override
		public String toString() {
			return value;
		}

		public boolean equals(String other) {

			if (other == null)
				return false;

			return name().equals(other.toUpperCase().replaceAll(" ", "_"))
					|| (value).equals(other);
		}

		public boolean equals(Number other) {
			if (other == null)
				return false;

			return equals(other.toString());
		}
		
		public Short toShort(){
			return Short.parseShort(this.value);	
		}
	}
	
	public boolean equals(String other);

	public boolean equals(Number other);
}
