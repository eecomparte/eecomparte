package com.atosorigin.common.dao;

import java.io.Serializable;
import java.lang.reflect.ParameterizedType;
import java.lang.reflect.Type;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.PersistenceContextType;
import javax.persistence.PersistenceException;

import org.hibernate.Session;
import org.hibernate.TransientObjectException;
import org.springframework.transaction.annotation.Transactional;

// TODO: Auto-generated Javadoc
/**
 * DAO Genérico con mecanismos genéricos de manipulación de objetos persistentes. 
 */
@Transactional
public class GenericDao<VOClass, PK extends Serializable> {
	
	/** Contexto de persistencia. */
	@PersistenceContext(type=PersistenceContextType.EXTENDED)
	protected EntityManager em;
	

	
	/**
	 * Carga un objeto de la base de datos a partir de su Clave primaria.
	 * 
	 * @param id LA clave primaria del objeto a recuperar de base de datos.
	 * 
	 * @return LA entidad cargada de base de datos. Nulo si no la encuentra.
	 */
	@SuppressWarnings("unchecked")
	public VOClass cargar(PK id) {
		
		VOClass object = (VOClass)em.find(getTipo(), id);
		if (object != null) {
			try {
				em.refresh(object);
			} catch (PersistenceException e) {
				//La obvio porque lo que pasa es que no existe,
				object = null;
			}
		}
		
		return object;
	}

	/**
	 * Obtiene el tipo concreto de la parametrización de tipos de Generics.
	 * 
	 * @return El tipo concreto del objeto.
	 */
	@SuppressWarnings("unchecked")
	private Class<?> getTipo() {
		Type genericSuperclass = getClass().getGenericSuperclass();
		while(genericSuperclass instanceof Class<?>) 
			genericSuperclass = ((Class<?>)genericSuperclass).getGenericSuperclass();
		if(genericSuperclass instanceof ParameterizedType) {
			ParameterizedType pType = (ParameterizedType) genericSuperclass;
			return (Class)pType.getActualTypeArguments()[0];
		}
		
		return null;
	}
	
	/**
	 * Guarda el objeto en la base de datos.
	 * 
	 * @param obj El Entity a guardar
	 */
	public void guardar(VOClass obj) {
		em.merge(obj);
	}

	/**
	 * Guarda el objeto en la base de datos.
	 * 
	 * @param obj El Entity a guardar
	 */
	public VOClass guardarRet(VOClass obj) {
		return em.merge(obj);
	}
	
	/**
	 * Guarda el objeto en la base de datos como uno nuevo. Si este existe lanzará una excepción
	 * 
	 * @param obj El Entity a guardar
	 */
	public void guardarNuevo(VOClass obj) {
		em.persist(obj);
	}


	/**
	 * Borra el objeto de la base de datos.
	 * 
	 * @param obj EL Entity a borrar
	 */
	public void borrar(VOClass obj) {
		em.remove(obj);
	}

	
//	public void recargar(VOClass obj){
//		PK identificador = getIdentificador(obj);
//		if(identificador==null){
//			throw new PersistenceException("No se puede recargar el objecto, el identificador es nulo");
//		}
//		VOClass boundObj = obj;
//		if(!em.contains(boundObj)){
//			boundObj = (VOClass) em.find(obj.getClass(), identificador);
//		}
//		em.refresh(boundObj);
//	}

//	public PK getIdentificador(VOClass obj){
//		Session session = (Session) em.getDelegate();
//		return (PK) session.getIdentifier(obj);
//	}
	
	public void recargar(VOClass obj){
		PK identificador = getIdentificador(obj);
		if(identificador==null){
			//log.debug("No se puede recargar el objecto, el identificador es nulo");
			return;
		}
		VOClass boundObj = obj;
		if(!em.contains(boundObj)){
			boundObj = (VOClass) em.find(obj.getClass(), identificador);
		}
		if(em.contains(boundObj)){
			em.refresh(boundObj);
		}
	}

	public PK getIdentificador(VOClass obj){
		Session session = (Session) em.getDelegate();
		try {
		return (PK) session.getIdentifier(obj);
		} catch (TransientObjectException e) {
		return null;
		}
	}


	public void detach(VOClass obj){
        ((Session)em.getDelegate()).evict(obj);
  }
		
		
		
}
