package com.atosorigin.common.excelexporter;

import java.util.List;

import org.jboss.seam.annotations.Name;

import com.atosorigin.common.action.PaginatedListAction;

/**
 * Extensión de la Exportación a Excel de Seam. Arregla el número de registros
 * traido de la base de datos para generar el Excel, característica que se habúia 
 * roto al incluir la paginación den base de datos.
 */
@Name("customExcelExporter")
public class CustomExcelExporter extends ExcelExporterEngine{

	
	/**
   	 * Proxy para la generación de excel. Consiste en cambiar los datos de paginación
   	 * del grid actual por unos adecuados para el excel (los primeros 65000.
   	 * 
   	 * @param dataTableId Identificador del dataTable a exportar.
   	 * @param action ActionListener que contiene la lista paginable.
   	 */
   	public void generarExcel(String dataTableId, PaginatedListAction action){
		  List<?> resultadosActuales = action.getDataTableList();
		  action.refrescarListaExcel();
	      export(dataTableId);
	      action.setDataTableList(resultadosActuales);
	      action.setExportExcel(false);
	   }
}
