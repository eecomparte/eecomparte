package com.atosorigin.common.formvalidator;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

import org.jboss.seam.annotations.intercept.Interceptors;

/**
 * Anotación para activar validaciones cruzadas y de negocio en un bean.
 * Antes de realizarse la llamada al método del bean se busca un método del bean
 * con el mismo nombre y acabado en "Validator" que se ejecuta. 
 * Es el que realiza las validaciones
 */
@Target(ElementType.TYPE)
@Retention(RetentionPolicy.RUNTIME)
@Interceptors(ValidationInterceptor.class)
public @interface FormValidator {
	boolean doRollback() default false; //FLM: cuando falla la validación no hacemos un rollback , sólo si se fuerza
}
