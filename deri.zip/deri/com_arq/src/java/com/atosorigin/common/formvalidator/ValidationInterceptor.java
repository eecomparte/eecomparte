package com.atosorigin.common.formvalidator;

import java.lang.reflect.Method;

import org.jboss.seam.annotations.intercept.AroundInvoke;
import org.jboss.seam.annotations.intercept.Interceptor;
import org.jboss.seam.intercept.InvocationContext;

// TODO: Auto-generated Javadoc
/**
 * Interceptor de Seam para activar validaciones cruzadas y de negocio en un bean.
 * Antes de realizarse la llamada al método del bean se busca un método del bean
 * con el mismo nombre y acabado en "Validator" que se ejecuta. 
 * Es el que realiza las validaciones.
 */
@Interceptor()
public class ValidationInterceptor {

	/** The Constant SUFIJO_METODO_VALIDACION. */
	private static final String SUFIJO_METODO_VALIDACION = "Validator";
    
    /**
     * Método interceptor para validaciones cruzadas y de negocio.
     * 
     * @param Contexto de invocación de los interceptores Seam. 
     * 
     * @return Objeto que devuelve el método target,
     * 
     * @throws Exception Cualquier error que haya podido ocurrir en la validación o en la cadena de interceptores posterior.
     */
    @AroundInvoke
    public Object invokeValidator(InvocationContext invocation) throws Exception {
    	Method invokedMethod = invocation.getMethod();
    	Class<?> clazz = invocation.getTarget().getClass();
    	Method validationMethod = null;
    	try {
    		validationMethod = clazz.getMethod(invokedMethod.getName() + SUFIJO_METODO_VALIDACION);
    	} catch (NoSuchMethodException e) {
    		return invocation.proceed();
    	}
    	
    	Object ret = validationMethod.invoke(invocation.getTarget());
    	if (ret instanceof Boolean ) {
    		if (((Boolean)ret)==true)  {
    			return invocation.proceed();
    		}
    	}
    	if(clazz.isAnnotationPresent(FormValidator.class) && clazz.getAnnotation(FormValidator.class).doRollback()){
        	org.jboss.seam.transaction.Transaction.instance().rollback();
    	}
    	return "errors";
    	
    	
    }


}
