package com.atosorigin.common.querybuilder;

import java.lang.reflect.InvocationTargetException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.persistence.EntityManager;
import javax.persistence.Query;

import org.apache.commons.beanutils.BeanUtils;
import org.apache.commons.beanutils.NestedNullException;

/**
 * Helper para construir consultas eql/hql dinámicas.
 */
public class QueryBuilder {

	/** Query con la consulta construida. */
	Query query = null;
	
	/** Query con la consulta que cuenta los registros. */
	Query countQuery = null;
	
	/** Hql con el que se ejecutará la query. */
	StringBuilder hql = new StringBuilder();
	
	/** Mapa con los parámetros para la query. */
	Map<String, Object> parameterMap = new HashMap<String, Object>();
	
	/**
	 * Añade un trozo de Hql a la Query
	 * 
	 * @param hqlClause El trozo de Hql.
	 */
	public void addHql(String hqlClause) {
		hql.append(" ").append(hqlClause);
	}

	/**
	 * Constructor que parte de una hql inicial.
	 * 
	 * @param hqlInicial La sentencia hql inicial
	 */
	public QueryBuilder(String hqlInicial) {
		hql.append(hqlInicial);
	}
	
	/**
	 * Añade un parámetro para la consulta.
	 * 
	 * @param paramName Nombre del parámetro.
	 * @param paramValue Valor del parámetro.
	 */
	public void addParameter(String paramName, Object paramValue) {
		parameterMap.put(paramName, paramValue);
	}
	
	/**
	 * Añade una cláusula hql condicional. Crea una nueva condición en la sentencia hql
	 * con el parámetro.
	 * 
	 * @param hqlClause Cláusula hql a aplicar condicionalmente.
	 * @param paramName Nombre del parámetro.
	 * @param paramValue Valor del parámetro.
	 */
	public void addHqlClause(String hqlClause, String paramName, Object paramValue) {
		addHql(hqlClause);
		addParameter(paramName, paramValue);
	}

	/**
	 * Añade una cláusula hql condicional. Crea una nueva condición en la sentencia hql
	 * con el parámetro si éste es no nulo.
	 * 
	 * @param hqlClause Cláusula hql a aplicar condicionalmente.
	 * @param paramName Nombre del parámetro.
	 * @param paramValue Valor del parámetro.
	 */
	public void addConditionalHqlClause(String hqlClause, String paramName, Object paramValue) {
		if (paramValue != null) {
			addHqlClause(hqlClause, paramName, paramValue);
		}
	}

	/**
	 * Añade una cláusula hql condicional. Crea una nueva condición en la sentencia hql
	 * con el parámetro si éste es no nulo. Hace throw de 3 excepciones que son las que
	 * implican un error al escribir la property.
	 * 
	 * @param hqlClause Cláusula hql a aplicar condicionalmente.
	 * @param paramName Nombre del parámetro.
	 * @param criteriaBean Objeto que contiene la propiedad a incluir como 
	 *        parámetro en alguno de sus atributos.
	 * @param property String que contiene la propiedad dentro de criteriaBean para ser
	 * 		  incluida como parámetro.
	 * @throws NoSuchMethodException 
	 * @throws InvocationTargetException 
	 * @throws IllegalAccessException 
	 */
	public void addConditionalHqlClause(String hqlClause, String paramName, Object criteriaBean, String property) throws RuntimeException, IllegalAccessException, InvocationTargetException, NoSuchMethodException{
		if (criteriaBean != null) {
			Object paramValue = null;
			try {
				paramValue = BeanUtils.getProperty(criteriaBean, property);
			} catch (NestedNullException e) {
				return;
			}
			if (paramValue != null) {
				addHqlClause(hqlClause, paramName, paramValue);
			}
		}
	}

	
	/**
	 * Obtiene la query a partir del hql construido.
	 * 
	 * @param em El contexto de persistencia Seam.
	 * @param firstResult Primer resultado a traer de la base de datos.
	 * @param maxResults Número máximo de registros a traer de la base de datos.
	 * 
	 * @return La query.
	 */
	public Query getQuery(EntityManager em, Integer firstResult, Integer maxResults) {
		query = em.createQuery(hql.toString());
		if (firstResult != null) {
			query.setFirstResult(firstResult);
		}
		if (maxResults != null) {
			query.setMaxResults(maxResults + 1); // Para saber si hay más registros en la base de datos.
		}
		for (String paramName : parameterMap.keySet()) {
			query.setParameter(paramName, parameterMap.get(paramName));
		}
		return query;
	}
	
	/**
	 * Obtiene la query.
	 * 
	 * @param em El contexto de persistencia de Seam.
	 * 
	 * @return La query.
	 */
	public Query getQuery(EntityManager em) {
		return getQuery(em, null, null);
	}

	
	/**
	 * Obtiene el número total de registros que devolvería la query (sin paginar).
	 * 
	 * @param em El contexto de persistencia de Seam.
	 * 
	 * @return El número total real de registros.
	 */
	public Long getRealCount(EntityManager em) {
		int fromPosition = hql.indexOf("from ");
		String restoQuery = hql.substring(fromPosition).replaceAll("fetch", "");
		countQuery = em.createQuery("select count(" + "*" + ") " + restoQuery);
		for (String paramName : parameterMap.keySet()) {
			countQuery.setParameter(paramName, parameterMap.get(paramName));
		}
		return (Long)countQuery.getSingleResult();
	}
	
	/**
	 * Ejecuta la query calculando además el número total de registros que deviolvería. 
	 * Puede ser peligroso ejecutarlo para tablas muy grandes o con criterios muy complejos.
	 * Es responsabilidad del programador elegir si ejecutar la query con count automático o no. 
	 * 
	 * @param em El contexto de persistencia de Seam.
	 * @param firstResult El primer resultado a traer de la base de datos.
	 * @param maxResult El número máximo de resultados.
	 * 
	 * @return La página de resultados con el número total de registros.
	 */
	public QueryList executeQueryWithCount2(EntityManager em, Integer firstResult, Integer maxResult) {
		QueryList<?> ql = new QueryList();
		ql.setNumFilas(getRealCount(em));
		ql.setResultList(getQuery(em, firstResult, maxResult).getResultList());
		return ql;
	}
	
	/**
	 * Ejecuta la query y devuelve los resultados
	 * 
	 * @param em El contexto de persistencia de Seam.
	 * @param firstResult El primer resultado a traer de la base de datos.
	 * @param maxResult El número máximo de resultados.
	 * 
	 * @return La página de resultados con el número total de registros.
	 */
	public List executeQuery(EntityManager em, Integer firstResult, Integer maxResult) {
		return getQuery(em, firstResult, maxResult).getResultList();
	}
	


	

	
}
