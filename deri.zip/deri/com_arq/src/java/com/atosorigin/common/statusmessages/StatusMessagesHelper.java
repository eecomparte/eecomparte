package com.atosorigin.common.statusmessages;

import java.util.Collection;
import java.util.Iterator;
import java.util.List;

import javax.faces.application.FacesMessage;
import javax.faces.component.UIComponent;
import javax.faces.component.html.HtmlOutputText;
import javax.faces.context.FacesContext;
import javax.print.attribute.standard.Severity;

import org.jboss.seam.annotations.In;
import org.jboss.seam.annotations.Name;
import org.jboss.seam.international.StatusMessages;
import org.jboss.seam.ui.component.html.HtmlDecorate;
import org.jboss.seam.ui.component.html.HtmlLabel;

/**
 * Helper de los mensajes de estado de Seam para adaptarlo a las necesidades concretas del proyecto.
 */
@Name("statusMessagesHelper")
public class StatusMessagesHelper {
    
    /** Inyección de los mensajes de estado. */
    protected @In StatusMessages statusMessages;
    private static final String ETIQUETA_CAMPO_DEFECTO = "El Campo";
    /**
     * Indica si alguno de los mensajes de estado es un error.
     * 
     * @param mensajes Colección de mensajes de estado actuales.
     * 
     * @return true, si alguno de los mensajes es un error.
     */
    public boolean hayErrores(Collection<FacesMessage> mensajes) {
    	for (FacesMessage mensaje : mensajes) {
    		if (Severity.ERROR.getValue() == mensaje.getSeverity().getOrdinal()) {
    			return true;
    		}
    	}
    	return false;
    	
    }
    
    /**
     * Indica si hay mensajes.
     * 
     * @param mensajes Colección de mensajes de estado actuales.
     * 
     * @return true, si statusMessages no está vacío.
     */
    public boolean hayMensajes(Collection<FacesMessage> mensajes) {
    	return (!mensajes.isEmpty());
    }
    
    /**
     * Modifica los mensajes de error asociados a un control para añadirles el 
     * texto de la etiqueta del control al que corresponden.
     * 
     * @return true.
     */
    public boolean obtenerEtiquetasMensajes() {
    	
    	Iterator<String> componentIdsConMens = FacesContext.getCurrentInstance().getClientIdsWithMessages();
    	while (componentIdsConMens.hasNext()) {
    		String componentId = componentIdsConMens.next();
    		if (componentId != null) {
	    		try {
					UIComponent component = FacesContext.getCurrentInstance().getViewRoot().findComponent(componentId);
					UIComponent parentComponent = component.getParent();
					while (!(parentComponent instanceof HtmlDecorate) && parentComponent != null) {
						parentComponent = parentComponent.getParent();
					}
					
					String etiquetaCampo = findLabelText(parentComponent); 
					
					//tengo la etiqueta del caompo con error y ahora añado un mensaje global 
					Iterator<FacesMessage> mensajesIt = FacesContext.getCurrentInstance().getMessages(componentId);
					while (mensajesIt.hasNext()) {
						FacesMessage mensajeConErrorDeCampo = mensajesIt.next();
						mensajeConErrorDeCampo.setDetail(etiquetaCampo + " " + mensajeConErrorDeCampo.getDetail());
						mensajeConErrorDeCampo.setSummary(etiquetaCampo + " " + mensajeConErrorDeCampo.getSummary());
					}
				} catch (Exception e) {
					continue;
				}
	    		
    		}
    		
    	}
    			
    	return true;
    }
    
    
	private String findLabelText(UIComponent rootComponent) {
		String etiquetaCampo = ETIQUETA_CAMPO_DEFECTO;
		HtmlLabel etiqueta = findLabel(rootComponent);
		if (etiqueta != null) {
			List<UIComponent> labelChildren = etiqueta.getChildren();
			for (Iterator<UIComponent> iterator2 = labelChildren.iterator(); iterator2.hasNext();) {
				UIComponent component3 = (UIComponent) iterator2.next();
				if (component3 instanceof HtmlOutputText) {
					etiquetaCampo = (String) ((HtmlOutputText) component3).getValue();
					break;
				}

			}
		}
		return etiquetaCampo;
	}
    
    private HtmlLabel findLabel(UIComponent rootComponent ) {
    	if (rootComponent instanceof HtmlLabel) {
    		return (HtmlLabel)rootComponent;
    	} 
    	List<UIComponent> children = rootComponent.getChildren();
		for (Iterator<UIComponent> iterator2 = children.iterator(); iterator2.hasNext();) {
			UIComponent child = iterator2.next();
			HtmlLabel etiqueta = findLabel(child);
			if (etiqueta != null) {
				return etiqueta;
			}
			
		}
		
    	return null;
    }
    
    
}
