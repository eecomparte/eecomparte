package com.atosorigin.common.utils;

import java.util.Calendar;
import java.util.Date;
import java.util.Iterator;

/**
 * Class to iterate through a Date interval day by day.
 * @author Sergi Castillo (A163607)
 *
 */
public class DateIterator implements Iterator<Date>,Iterable<Date> {

	private Calendar start = Calendar.getInstance();
	private Calendar end = Calendar.getInstance();
	private Calendar current = Calendar.getInstance();
	
	private boolean first = true;
	private int interval = Calendar.DATE;
	
	/**
	 * Constructor with params
	 * @param start start date
	 * @param end end date
	 */
	public DateIterator(Date start, Date end) {
		this.start.setTime(start);
		this.end.setTime(end);
		this.current = this.start;
	}
	
	/**
	 * Constructor with params
	 * @param start start date
	 * @param end end date
	 * @param first boolean flag to show the start date in the next() method. Default: true
	 */
	public DateIterator(Date start, Date end, boolean first) {
		this.start.setTime(start);
		this.end.setTime(end);
		this.current = this.start;
		this.first = first;
	}
	
	/**
	 * Constructor with params
	 * @param start start date
	 * @param end end date
	 * @param first boolean flag to show the start date in the next() method. Default: true
	 * @param interval int to indicate the interval of the next Date. Default: Calendar.DATE
	 */
	public DateIterator(Date start, Date end, boolean first, int interval) {
		this.start.setTime(start);
		this.end.setTime(end);
		this.current = this.start;
		this.first = first;
		this.interval = interval;
	}

	public boolean hasNext() {
		return !current.after(end);
	}

	public Date next() {
		if(first) {
			first = false;
			return start.getTime();
		}
		current.add(this.interval,1);
		return current.getTime();
	}

	public void remove() {
		throw new UnsupportedOperationException("Cannot remove");
	}

	public Iterator<Date> iterator() {
		return this;
	}

}
