package com.atosorigin.common.utils;


import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;

import org.apache.poi.hssf.eventusermodel.HSSFEventFactory;
import org.apache.poi.hssf.eventusermodel.HSSFListener;
import org.apache.poi.hssf.eventusermodel.HSSFRequest;
import org.apache.poi.hssf.record.BOFRecord;
import org.apache.poi.hssf.record.BoundSheetRecord;
import org.apache.poi.hssf.record.ExtendedFormatRecord;
import org.apache.poi.hssf.record.FormatRecord;
import org.apache.poi.hssf.record.LabelSSTRecord;
import org.apache.poi.hssf.record.NumberRecord;
import org.apache.poi.hssf.record.Record;
import org.apache.poi.hssf.record.RowRecord;
import org.apache.poi.hssf.record.SSTRecord;
import org.apache.poi.hssf.record.StyleRecord;
import org.apache.poi.hssf.usermodel.HSSFDateUtil;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.poifs.filesystem.POIFSFileSystem;

import com.atosorigin.common.constantes.Constantes;


/**
 * Class to read Excel files using Poi librarys
 * @author Salvador Moragues (S236338)
 *
 */
public class ExcelImporter {

	public ExcelImporter() {
		super();
	}

	public static String read(String fichero, String workbook) throws FileNotFoundException{
		   // create a new file input stream with the input file specified
        // at the command line
        FileInputStream fin;
	
		fin = new FileInputStream(fichero);
	
        // create a new org.apache.poi.poifs.filesystem.Filesystem
        POIFSFileSystem poifs;
		try {
			poifs = new POIFSFileSystem(fin);
			// get the Workbook (excel part) stream in a InputStream
	        InputStream din;
			din = poifs.createDocumentInputStream(workbook);
			
	        // construct out HSSFRequest object
	        HSSFRequest req = new HSSFRequest();
	        // lazy listen for ALL records with the listener shown above
	        req.addListenerForAllRecords(new EventExample());
	        // create our event factory
	        HSSFEventFactory factory = new HSSFEventFactory();
	        // process our events based on the document input stream
	        factory.processEvents(req, din);
	        // once all the events are processed close our file input stream
					
			fin.close();
	        // and our document input stream (don't want to leak these!)
			din.close();
		
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();			
			return "ERROR";
		}
        

        return Constantes.SUCCESS;
	}

	
	/**
	 * This example shows how to use the event API for reading a file.
	 */

	public static class EventExample
	        implements HSSFListener
	{
	    private SSTRecord sstrec;

	    /**
	     * This method listens for incoming records and handles them as required.
	     * @param record    The record that was found while reading.
	     */

 	    public void processRecord(Record record)
	    {
 	    	System.out.println(record.getClass().toString());
 	    	switch (record.getSid())
	        { 
	            // the BOFRecord can represent either the beginning of a sheet or the workbook
	            case BOFRecord.sid:
	                BOFRecord bof = (BOFRecord) record;
	                if (bof.getType() == bof.TYPE_WORKBOOK)
	                {
	                    System.out.println("Encountered workbook");
	                    // assigned to the class level member
	                } else if (bof.getType() == bof.TYPE_WORKSHEET)
	                {
	                    System.out.println("Encountered sheet reference");
	                }
	                break;
	            case BoundSheetRecord.sid:
	                BoundSheetRecord bsr = (BoundSheetRecord) record;
	                System.out.println("New sheet named: " + bsr.getSheetname());
	                break;
	            case RowRecord.sid:
	                RowRecord rowrec = (RowRecord) record;
	                System.out.println("Row found, first column at "
	                        + rowrec.getFirstCol() + " last column at " + rowrec.getLastCol());
	                break;
	      
	            case FormatRecord.sid:
	            	FormatRecord forec = (FormatRecord) record;
	                System.out.println("Cell found with value " + forec.getFormatString()
	                        + " at row " + forec.getIndexCode());
	            	break;
	            case ExtendedFormatRecord.sid:
	            	ExtendedFormatRecord eforec = (ExtendedFormatRecord) record;
	                System.out.println("Cell found with value " + eforec.getXFType()
	                        + " at row " );
	            	break;
	            
	            case StyleRecord.sid:
	            	StyleRecord stilrec = (StyleRecord) record;
	                System.out.println("Cell found with value " + stilrec.getXFIndex()
	                        + " at row " );
	            	break;

	            case NumberRecord.sid:
	            	NumberRecord numrec = (NumberRecord) record;
	                System.out.println("Cell found with value " + numrec.getValue()
	                        + " at row " + numrec.getRow() + " and column " + numrec.getColumn());
	                if (Short.valueOf("21").equals(numrec.getXFIndex())){
	                	System.out.println("Cell found with value " + HSSFDateUtil.getJavaDate(numrec.getValue()).toString());
	                }
	                break;
	                // SSTRecords store a array of unique strings used in Excel.
	            case SSTRecord.sid:
	                sstrec = (SSTRecord) record;
	                for (int k = 0; k < sstrec.getNumUniqueStrings(); k++)
	                {
	                    System.out.println("String table value " + k + " = " + sstrec.getString(k));
	                }
	                break;
	            case LabelSSTRecord.sid:
	                LabelSSTRecord lrec = (LabelSSTRecord) record;
	                System.out.println("String cell found with value "
	                        + sstrec.getString(lrec.getSSTIndex()));
	                break;
	        }
	    }

	
	}
	
	public static void comprobarDate(double celda){
	         // test if a date!
		
//	         if (HSSFDateUtil.isCellDateFormatted(celda)) {
	           // format in form of M/D/YY
//	           cal.setTime(HSSFDateUtil.getJavaDate(celda));
//	           cellText =
//	             (String.valueOf(cal.get(Calendar.YEAR))).substring(2);
//	           cellText = cal.get(Calendar.MONTH)+1 + "/" +
//	                      cal.get(Calendar.DAY_OF_MONTH) + "/" +
//	                      cellText;
	         }
	      
	


	public static String excelExtractor(String fichero) throws IOException{
		InputStream inp = new FileInputStream(fichero);
		HSSFWorkbook wb = new HSSFWorkbook(new POIFSFileSystem(inp));
		ExcelExtractorOwn extractor = new ExcelExtractorOwn(wb);
		
		//SMM 15/02/20013
		extractor.setIncludeBlankCells(true);
		
		extractor.setFormulasNotResults(false);
		extractor.setIncludeSheetNames(false);
		String text = extractor.getText();
		return text;
	}



}
