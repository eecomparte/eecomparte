package com.atosorigin.common.utils;

import java.io.PrintWriter;
import java.io.StringWriter;
import java.math.BigDecimal;
import java.text.DecimalFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collection;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.TreeSet;
import java.util.Map.Entry;

import org.apache.commons.collections.CollectionUtils;
import org.jboss.seam.log.Log;

import com.atosorigin.common.constantes.Constantes;
import com.atosorigin.common.constantes.Enumeraciones;

/**
 * Clase de utilidades genéricas.
 */
public class GenericUtils {

	public final static String DATEPATTERN_DEFAULT = "dd/MM/yyyy";
	public final static String NUMBERPATTERN_DEFAULT = "0.##";
	public final static Locale LOCALE_DEFAULT = Locale.getDefault();
	
//	@In("org.jboss.seam.core.locale")
//	private org.jboss.seam.core.Locale locale;

	public final static String PAD_DEFAULT = " ";

	/**
	 * Comprueba si un objeto es nulo o blanco.
	 * 
	 * @param obj
	 *            El objeto a comprobar.
	 * 
	 * @return true, Si el objeto es nulo o su valor en String es blanco.
	 */
	public static boolean isNullOrBlank(Object obj) {

		try {
			return obj == null || obj.toString().length() == 0;
		} catch (Exception e) {
			return false;
		}
	}

	/**
	 * Comprueba si una lista es nula o vacía.
	 * 
	 * @param obj
	 *            La lista a comprobar.
	 * 
	 * @return <code>true</code> en caso afirmativo.
	 */
	public static boolean isNullOrEmpty(Collection<?> col) {
		return col == null || col.isEmpty();
	}

	/**
	 * Comprueba si el array es <code>null</code> o vacío.
	 * 
	 * @param objs
	 *            El array a comprobar.
	 * 
	 * @return <code>true</code> en caso afirmativo.
	 */
	public static boolean isNullOrEmpty(Object[] objs) {
		return objs == null || objs.length == 0;
	}

	/**
	 * Comprueba si el array es <code>null</code> o vacío.
	 * 
	 * @param objs
	 *            El array a comprobar.
	 * @return <code>true</code> en caso afirmativo.
	 * @see #isNullOrEmpty(Object[]) 
	 */
	public static boolean isNullOrEmpty(byte[] bs) {
		return bs == null || bs.length == 0;
	}

	/**
	 * Comprueba si un map es nulo o vacío.
	 * 
	 * @param obj
	 *            El map a comprobar.
	 * 
	 * @return <code>true</code> en caso afirmativo.
	 */
	public static boolean isNullOrEmpty(Map<?, ?> map) {
		return map == null || map.isEmpty();
	}

	/**
	 * Verifica que la colección pasada como parámetro no sea <code>null</code>,
	 * y en tal caso se devuelve. En caso contrario se devuelve una nueva
	 * colección <u>vacía</u> y <u>no modificable</u> con la cual poder iterar. El
	 * problema es que el bucle <code>for</code> mejorado de Java 5 da un
	 * {@link NullPointerException} en el caso que el objeto sea
	 * <code>null</code>.
	 * 
	 * @param <T>
	 * @param col
	 *            Colección a comprobar.
	 * @return Una colección vacía en el caso que col sea <code>null</code>.
	 */
	@SuppressWarnings("unchecked")
	public static <T> Collection<T> getSafeCollection(final Collection<T> col) {
		return (col != null) ? col : CollectionUtils.EMPTY_COLLECTION;
	}

	/**
	 * Comprueba si un objeto es numérico
	 * 
	 * @param obj
	 *            El objeto a comprobar.
	 * 
	 * @return true, Si el objeto es numerico
	 */
	public static boolean isNumeric(String obj) {
		if (obj == null) {
			return false;
		}
		try {
			Integer.parseInt(obj);
			return true;
		} catch (NumberFormatException nfe) {
			return false;
		}
	}

	/**
	 * Función que valida números decimales (BigDecimal) en formato. Comprueba
	 * si la cantidad de cifras enteras y decimales es la correcta.
	 * 
	 * @param numeroValidar
	 *            : Número (BigDecimal) sobre el que se realiza la validación
	 * @param maxEnteros
	 *            : cantidad máxima de cifras enteras que debe tener el número a
	 *            validar
	 * @param maxDecimales
	 *            : cantidad máxima de cifras decimales que debe tener el número
	 *            a validar
	 * @return true si el número cumple el formato requerido, false en caso
	 *         contrario.
	 */
	public static boolean validaFormatoDecimal(BigDecimal numeroValidar, int maxEnteros, int maxDecimales) {

		boolean formatoCorrecto = false;

		if (!GenericUtils.isNullOrBlank(numeroValidar)) {

			boolean decimales = numeroValidar.scale() <= maxDecimales;
			// SMM BUG HPQC ID 48
			boolean enteros = (numeroValidar.precision() - numeroValidar.scale()) <= maxEnteros;
			formatoCorrecto = decimales && enteros;
		}

		return formatoCorrecto;
	}

	/*****************************************************/
	/* to_char */
	/*****************************************************/
	/**
	 * TO_CHAR converts d of DATE datatype to a value of VARCHAR2 datatype in
	 * the format specified by the date format fmt. If you omit fmt, d is
	 * converted to a VARCHAR2 value in the default date format. The ?nlsparams?
	 * specifies the language in which month and day names and abbreviations are
	 * returned. This argument can have this form: ?NLS_DATE_LANGUAGE =
	 * language? If you omit nlsparams, this function uses the default date
	 * language for your session.
	 * 
	 * @param date
	 * @return
	 */
	public static String to_char(Date date, String pattern, Locale locale) {
		SimpleDateFormat simpleDateFormat = new SimpleDateFormat(pattern, locale);
		String to_char = simpleDateFormat.format(date);
		return to_char;
	}

	public static String to_char(Date date, String pattern) {
		return to_char(date, pattern, LOCALE_DEFAULT);
	}

	public static String to_char(Date date) {
		return to_char(date, DATEPATTERN_DEFAULT, LOCALE_DEFAULT);
	}

	/**
	 * TO_CHAR converts n of NUMBER datatype to a value of VARCHAR2 datatype,
	 * using the optional number format fmt. If you omit fmt, n is converted to
	 * a VARCHAR2 value exactly long enough to hold its significant digits.
	 */
	public static String to_char(Number number, String pattern, Locale locale) {
		DecimalFormat decimalFormat = (DecimalFormat) DecimalFormat.getInstance(locale);
		decimalFormat.applyPattern(pattern);
		String to_char = decimalFormat.format(number);
		return to_char;
	}

	public static String to_char(Number number, String pattern) {

		return to_char(number, pattern, LOCALE_DEFAULT);
	}

	public static String to_char(Number number) {

		return to_char(number, NUMBERPATTERN_DEFAULT, LOCALE_DEFAULT);
	}

	/**
	 * REPLACE returns char with every occurrence of search_string replaced with
	 * replacement_string. If replacement_string is omitted or null, all
	 * occurrences of search_string are removed. If search_string is null, char
	 * is returned. This function provides a superset of the functionality
	 * provided by the TRANSLATE function. TRANSLATE provides single-character,
	 * one-to-one substitution. REPLACE lets you substitute one string for
	 * another as well as to remove character strings.
	 * 
	 * @return
	 */
	public static String replace(String source, String ori, String des) {
		int lastIndex = 0;
		int index;
		String resultSource = source;
		StringBuffer sb = new StringBuffer(resultSource);
		index = resultSource.indexOf(ori);
		while (index > -1 && index >= lastIndex) {
			sb = new StringBuffer(resultSource.substring(0, index));
			sb.append(des);
			sb.append(resultSource.substring(index + ori.length()));
			resultSource = sb.toString();
			lastIndex = index + des.length();
			index = resultSource.indexOf(ori, lastIndex);
		}
		return resultSource;
	}

	/*****************************************************/
	/* ltrim */
	/*****************************************************/
	/**
	 * LTRIM removes characters from the left of char, with all the leftmost
	 * characters that appear in set removed; set defaults to a single blank. If
	 * char is a character literal, you must enclose it in single quotes. Oracle
	 * begins scanning char from its first character and removes all characters
	 * that appear in set until reaching a character not in set and then returns
	 * the result.
	 */
	public static String ltrim(String source) {
		final String LTRIM_AUX = "~";
		String jobStream = source + LTRIM_AUX;
		jobStream = jobStream.trim();
		jobStream = jobStream.substring(0, jobStream.length() - LTRIM_AUX.length());
		return jobStream;
	}

	public static String rtrim(String source) {
		final String LTRIM_AUX = "~";
		String jobStream = LTRIM_AUX + source;
		jobStream = jobStream.trim();
		jobStream = jobStream.substring(LTRIM_AUX.length(), jobStream.length());
		return jobStream;
	}

	/**
	 * TO_CHAR converts d of DATE datatype to a value of VARCHAR2 datatype in
	 * the format specified by the date format fmt. If you omit fmt, d is
	 * converted to a VARCHAR2 value in the default date format. The �nlsparams�
	 * specifies the language in which month and day names and abbreviations are
	 * returned. This argument can have this form: �NLS_DATE_LANGUAGE =
	 * language� If you omit nlsparams, this function uses the default date
	 * language for your session.
	 * 
	 * @param date
	 * @return
	 */
	public static String to_char(Date date, SimpleDateFormat simpleDateFormat) {
		String to_char = simpleDateFormat.format(date);
		return to_char;
	}

	/**
	 * Retorna el primer objecte que no sigui <code>null</code>.
	 * 
	 * @param <T>
	 * @param objects
	 * @return <code>null</code> en el cas que no s'hagin passat els paràmetres
	 *         o quan tots els paràmetres són <code>null</code>.
	 */
	public static <T> T nvl(T... objects) {

		if (isNullOrEmpty(objects))
			return null;

		for (T obj : objects) {
			if (obj != null)
				return obj;
		}

		return null;
	}

	/**
	 * LPAD returns char1, left-padded to length n with the sequence of
	 * characters in char2; char2 defaults to a single blank. If char1 is longer
	 * than n, this function returns the portion of char1 that fits in n. The
	 * argument n is the total length of the return value as it is displayed on
	 * your terminal screen. In most character sets, this is also the number of
	 * characters in the return value. However, in some multibyte character
	 * sets, the display length of a character string can differ from the number
	 * of characters in the string.
	 * 
	 * @param source
	 * @param length
	 * @param pad
	 * @return
	 */
	public static String lpad(String padSource, int padLength) {
		return lpad(padSource, padLength, null);
	}

	/**
	 * @param padSource
	 * @param padLength
	 * @return
	 * @see #lpad(String, int)
	 */
	public static String lpad(Number padSource, int padLength) {
		return lpad(padSource.toString(), padLength);
	}

	public static String lpad(String padSource, int padLength, String padStream) {
		String lpad = null;
		if (padStream == null) {
			padStream = PAD_DEFAULT;
		}
		int sourceLength = padSource.length();
		if (padLength <= sourceLength) {
			lpad = padSource.substring(0, padLength);
		} else {
			StringBuffer sb = new StringBuffer();
			char[] padCharArray = padStream.toCharArray();
			int padCharArrayLength = padCharArray.length;
			int i = 0;
			int j = 0;
			while (i < padLength - sourceLength) {
				if (j == padCharArrayLength) {
					j = 0;
				}
				sb.append(padCharArray[j]);
				j++;
				i++;
			}
			sb.append(padSource);
			lpad = sb.toString();
		}
		return lpad;
	}

	/**
	 * 
	 * @param padSource
	 * @param padLength
	 * @param padStream
	 * @return
	 * @see #lpad(String, int, String)
	 */
	public static String lpad(Number padSource, int padLength, String padStream) {
		return lpad(padSource.toString(), padLength, padStream);
	}

	/**
	 * Función que añade caracteres a la izquierda de un string recibido como
	 * argumento. Añade tantos caracteres como sean necesarios para que la
	 * longitud del string finals ea igual a la recibida como argumento. El
	 * caracter a añadir también se recibe como argumento.
	 * 
	 * @param origen
	 *            : string original
	 * @param longitud
	 *            : longitud final del string
	 * @param caracter
	 *            : caracter a añadir a la izquierda del string
	 * @return String modificado
	 */
	public static String lpad(String origen, int longitud, char caracter) {

		String aux = origen;

		if (aux.length() >= longitud) {
			return aux.substring(0, longitud);
		} else {

			while (aux.length() < longitud) {
				aux = caracter + aux;
			}

			return aux;
		}
	}

	/**
	 * RPAD returns char1, right-padded to length n with char2, replicated as
	 * many times as necessary; char2 defaults to a single blank. If char1 is
	 * longer than n, this function returns the portion of char1 that fits in n.
	 * The argument n is the total length of the return value as it is displayed
	 * on your terminal screen. In most character sets, this is also the number
	 * of characters in the return value. However, in some multibyte character
	 * sets, the display length of a character string can differ from the number
	 * of characters in the string.
	 * 
	 * @param padSource
	 * @param padLength
	 * @return
	 */
	public static String rpad(String padSource, int padLength) {
		return rpad(padSource, padLength, null);
	}

	/**
	 * 
	 * @param padSource
	 * @param padLength
	 * @return
	 * @see #rpad(String, int)
	 */
	public static String rpad(Number padSource, int padLength) {
		return rpad(padSource.toString(), padLength);
	}

	public static String rpad(String padSource, int padLength, String padStream) {
		String rpad = null;
		if (padStream == null) {
			padStream = PAD_DEFAULT;
		}
		int sourceLength = padSource.length();
		if (padLength <= sourceLength) {
			rpad = padSource.substring(0, padLength);
		} else {
			StringBuffer sb = new StringBuffer();
			sb.append(padSource);
			char[] padCharArray = padStream.toCharArray();
			int padCharArrayLength = padCharArray.length;
			int i = 0;
			int j = 0;
			while (i < padLength - sourceLength) {
				if (j == padCharArrayLength) {
					j = 0;
				}
				sb.append(padCharArray[j]);
				j++;
				i++;
			}
			rpad = sb.toString();
		}
		return rpad;
	}

	/**
	 * 
	 * @param padSource
	 * @param padLength
	 * @param padStream
	 * @return
	 * @see #rpad(String, int, String)
	 */
	public static String rpad(Number padSource, int padLength, String padStream) {
		return rpad(padSource.toString(), padLength, padStream);
	}

	/**
	 * Función que añade caracteres a la derecha de un string recibido como
	 * argumento. Añade tantos caracteres como sean necesarios para que la
	 * longitud del string finals ea igual a la recibida como argumento. Si la
	 * longitud es mayor que la requerida, trunca el string al número de
	 * caracteres requerido, descartando los sobrantes. El caracter a añadir
	 * también se recibe como argumento.
	 * 
	 * @param origen
	 *            : string original
	 * @param longitud
	 *            : longitud final del string
	 * @param caracter
	 *            : caracter a añadir a la derecha del string
	 * @return String modificado
	 */
	public static String rpad(String origen, int longitud, char caracter) {

		String aux = origen;

		if (aux.length() >= longitud) {
			return aux.substring(0, longitud);
		} else {
			while (aux.length() < longitud) {
				aux = aux + caracter;
			}

			return aux;
		}

	}

	/**
	 * Función para traducir los valores boolean
	 * 
	 * @param value
	 *            : recibe un booleano y devolvera el equivalente en la BD
	 * @return devuelve S/N en función del booleano true/false
	 */
	public static String SNBooleanNotNull(Boolean value) {
		if (value == null)
			return SNBoolean(Boolean.FALSE);
		else
			return SNBoolean(value);
	}

	public static String SNBoolean(Boolean value) {
		if (value != null) {
			if (value.equals(Boolean.TRUE))
				return "S";
			else if (value.equals(Boolean.FALSE))
				return "N";
			else
				return null;
		} else
			return null;
	}

	/**
	 * Función para traducir los valores String a Boolean
	 * 
	 * @param value
	 *            : recibe una String y devolvera el equivalente en Boolean
	 * @return devuelve true/false en función del booleano S/N
	 */
	public static Boolean SNBoolean(String value) {
		if (!isNullOrBlank(value)) {
			if (value.equals("S"))
				return Boolean.TRUE;
			else if (value.equals("N"))
				return Boolean.FALSE;
			else
				return null;
		} else
			return null;
	}

	/**
	 * Valida si el valor recibido es un long, sino devuelve un null
	 * 
	 * @param value
	 *            : recibe una String y devolvera el equivalente en Boolean
	 * @return devuelve true/false en función del booleano S/N
	 */
	public static Long isLong(Object obj) {
		if (obj == null) {
			return null;
		}
		try {
			Long.parseLong(obj.toString());
			return (Long) obj;
		} catch (NumberFormatException nfe) {
			return null;
		}
	}

	/**
	 * Función para traducir los valores boolean
	 * 
	 * @param value
	 *            : recibe un booleano y devolvera el equivalente en la BD
	 * @return devuelve S/N en función del booleano true/false
	 */
	public static String PNBoolean(Boolean value) {
		if (value != null) {
			if (value.equals(Boolean.TRUE))
				return "P";
			else if (value.equals(Boolean.FALSE))
				return "N";
			else
				return null;
		} else
			return null;
	}

	/**
	 * Función para traducir los valores String a Boolean
	 * 
	 * @param value
	 *            : recibe una String y devolvera el equivalente en Boolean
	 * @return devuelve true/false en función del booleano S/N
	 */
	public static Boolean PNBoolean(String value) {
		if (value != null) {
			if (value == "P")
				return Boolean.TRUE;
			else if (value == "N")
				return Boolean.FALSE;
			else
				return null;
		} else
			return null;
	}
	
	/**
	 * Función que mira si un objeto "obj" no es nulo y es igual a otro objeto
	 * "compara"
	 * 
	 * @param obj
	 *            : objeto que queremos saber si es igual a otro
	 * @param compara
	 *            : objeto con el que comparamos
	 * @return true si "obj" no es nulo y es igual a "compara"
	 */
	public static Boolean notNullAndEquals(Object obj, Object compara) {

		boolean retorno = true;

		if (isNullOrBlank(obj)) {
			retorno = false;
		} else if (!obj.equals(compara)) {
			retorno = false;
		}

		return retorno;

	}

	/**
	 * Compara la representación <code>toString()</code> de los objetos.
	 * 
	 * <pre>
	 * GenericUtils.equals(<b>null</b>, <b>null</b>) == true
	 * GenericUtils.equals(<b>null</b>, <b>null</b>, <b>null</b>...) == true
	 * GenericUtils.equals("abc", <b>null</b>) == false
	 * GenericUtils.equals(<b>null</b>, "abc") == false
	 * GenericUtils.equals("abc", "abc") == true
	 * GenericUtils.equals("1", 1) == true
	 * GenericUtils.equals(" 1022 ", 1022) == false
	 * GenericUtils.equals("abc", "Abc") == false
	 * GenericUtils.equals(new Date(109, 10, 29), "29/10/2009") == true
	 * </pre>
	 * 
	 * @see <a
	 *      href="http://commons.apache.org/lang/api-release/org/apache/commons/lang/StringUtils.html">StringUtils&nbsp;(Commons&nbsp;Lang&nbsp;2.5&nbsp;API)</a>
	 * @param o1
	 * @param o2
	 * @param objects
	 * @return <code>true</code> en el caso que sean iguales (ver ejemplos de arriba).
	 */
	public static boolean equals(Object o1, Object o2, Object... objects) {

		if (objects == null)
			return equals(o1, o2);

		if (o1 == null) {
			if (o2 != null)
				return false;

			for (Object obj : objects) {
				if (obj != null)
					return false;
			}

			return true;
		}

		if (o2 == null)
			return false;

		if (!equals(o1, o2))
			return false;

		for (Object obj : objects) {
			if (obj == null)
				return false;

			if (!equals(o1, obj))
				return false;
		}

		return true;
	}

	/**
	 * Busca la primera aparición de <code>object</code> en la lista de objetos
	 * pasados. La semántica es parecida a la palabra clave <code>IN</code> de
	 * SQL.
	 * 
	 * <pre>
	 * GenericUtils.in(<b>null</b>) == true
	 * GenericUtils.in(<b>null</b>, <b>null</b>) == true
	 * GenericUtils.in(<b>null</b>, <b>null</b>, <b>null</b>) == true
	 * GenericUtils.in(<b>null</b>, <b>3</b>, <b>null</b>) == true
	 * GenericUtils.in(3) == false
	 * GenericUtils.in("3", <b>null</b>) == false
	 * GenericUtils.in(5, <b>null</b>, "5") == true
	 * </pre>
	 * 
	 * @see #equals(Object, Object)
	 * @see #isNullOrEmpty(Object[])
	 * @param object
	 *            Objeto a buscar.
	 * @param objects
	 *            Lista de objetos donde buscar.
	 * @return <code>true</code> si encuentra un objeto que sea igual.
	 */
	public static boolean in(final Object object, final Object... objects) {

		if (object == null && isNullOrEmpty(objects))
			return true;

		for (Object obj : objects) {
			if (equals(object, obj))
				return true;
		}

		return false;
	}

	/**
	 * Busca la primera aparición de <code>object</code> en la lista de objetos
	 * pasados. La semántica es parecida a la palabra clave <code>IN</code> de
	 * SQL.
	 * 
	 * <pre>
	 * GenericUtils.in(<b>null</b>) == true
	 * GenericUtils.in(<b>null</b>, <b>null</b>) == true
	 * GenericUtils.in(<b>null</b>, new {@link ArrayList}()) == true
	 * GenericUtils.in(<b>null</b>, new {@link TreeSet}()) == true
	 * GenericUtils.in(3) == false
	 * GenericUtils.in("3", new {@link ArrayList}()) == false
	 * GenericUtils.in(5, new {@link TreeSet}()) == false
	 * </pre>
	 * 
	 * @see #in(Object, Object...)
	 * @see #isNullOrEmpty(Collection)
	 * @param object
	 *            Objeto a buscar.
	 * @param collection
	 *            Colección de objetos donde buscar.
	 * @return<code>true</code> si encuentra un objeto que sea igual.
	 */
	public static boolean in(final Object object,
			final Collection<Object> collection) {

		if (object == null && isNullOrEmpty(collection))
			return true;

		return in(object, collection.toArray());
	}

	/**
	 * Compara dos objetos.
	 * 
	 * @param o1
	 * @param o2
	 * @return
	 * @see #_equals(Object, Object)
	 */
	public static boolean equals(Object o1, Object o2) {

		if (o1 == null && o2 == null)
			return true;

		if (o1 == null || o2 == null)
			return false;

		Boolean bool = _equals64(o1, o2);
		if (bool != null)
			return bool;

		bool = _equals64(o2, o1);
		// Comparación mediante toString() por defecto
		return bool != null ? bool : o1.toString().equals(o2.toString());
	}

	/**
	 * Compara los objetos y devuelve la comparación.
	 * 
	 * La comparación implementada no cumple con la propiedad conmutativa, por
	 * lo que <b>no se garantiza</b>:
	 * <code>equals(o1, o2) == equals(o2, o1)</code>.
	 *
	 * @param o1
	 * @param o2
	 * @return <code>null</code> en el caso que el <i>o1</i> no sea reconocido.
	 * @see #equals(Object, Object)
	 */
	private static Boolean _equals(Object o1, Object o2) {

		if (o1 instanceof Date) {
			final Date d1 = (Date) o1;
			if (o2 instanceof String) {
				final String s2 = (String) o2;
				try {
					return new SimpleDateFormat(Constantes.DDMMYYYY).parse(s2)
							.compareTo(d1) == 0;
				} catch (ParseException e) {
				}
				try {
					return new SimpleDateFormat(Constantes.DDMMYYYYHHMMSS)
							.parse(s2).compareTo(d1) == 0;
				} catch (ParseException e) {
				}
			} else if (o2 instanceof Date) {
				return d1.compareTo((Date) o2) == 0;
			}

			return false;
		} else if (o1 instanceof Enumeraciones) {
			Enumeraciones en1 = (Enumeraciones) o1;
			if (o2 instanceof String) {
				return en1.equals((String) o2);
			} else if (o2 instanceof Number) {
				return en1.equals((Number) o2);
			}

			return o1.equals(o2);
		} else if (o1 instanceof Enum<?>) {
			return o1.equals(o2) || 
				((o2 instanceof String) ? o1.toString().equals(o2) : false);
		}

		// o1 no reconocido
		return null;
	}

	
	private static Boolean _equals64(Object o1, Object o2) {

		if (o1 instanceof Date) {
			final Date d1 = (Date) o1;
			if (o2 instanceof String) {
				final String s2 = (String) o2;
				try {
					return new SimpleDateFormat(Constantes.DDMMYYYY).parse(s2)
							.compareTo(d1) == 0;
				} catch (ParseException e) {
				}
				try {
					return new SimpleDateFormat(Constantes.DDMMYYYYHHMMSS)
							.parse(s2).compareTo(d1) == 0;
				} catch (ParseException e) {
				}
			} else if (o2 instanceof Date) {
				return d1.compareTo((Date) o2) == 0;
			}

			return false;
		} else if (o1 instanceof Enumeraciones) {
			Enumeraciones en1 = (Enumeraciones) o1;
			if (o2 instanceof String) {
				return en1.equals((String) o2);
			} else if (o2 instanceof Number) {
				return en1.equals((Number) o2);
			}

			return o1.equals(o2);
		} else if (o1 instanceof Enum<?>) {
			return o1.equals(o2) || 
				((o2 instanceof String) ? o1.toString().equals(o2) : false);
		}else if (o1 instanceof BigDecimal && o2 instanceof BigDecimal){
			BigDecimal bd1 = (BigDecimal) o1;
			BigDecimal bd2 = (BigDecimal) o2;
			
			return (bd1.compareTo(bd2)==0);
			
		}

		// o1 no reconocido
		return null;
	}

	
	/**
	 * Devuelve la lista de elementos que han sido seleccionados por un grupo de
	 * checkboxes.
	 * 
	 * @param <T>
	 * @param seleccionMap
	 *            Mapa que asocia un objeto T con el estado de la selección (
	 *            <code>true</code> significa seleccionado).
	 * @return Lista vacía en el caso que no haya ningún elemento.
	 */
	public static <T> List<T> getSeleccionCheckbox(final Map<T, Boolean> seleccionMap) {

		if (seleccionMap == null)
			return new ArrayList<T>();

		final List<T> seleccion = new ArrayList<T>();

		for (final Entry<T, Boolean> entry : seleccionMap.entrySet()) {

			final Boolean b = entry.getValue();
			if (b != null && b)
				seleccion.add(entry.getKey());
		}

		return seleccion;
	}
	
	/**
	 * Función que aplica una máscara numérica al valor introducido por el usuario
	 * o recogido de la base de datos
	 */
	public static String aplicarMascaraNumerica(String valor, String mascara) {
		DecimalFormat df = (DecimalFormat) DecimalFormat.getInstance();
		df.applyLocalizedPattern(mascara);
		BigDecimal decimalValue;
		
		if(!GenericUtils.isNullOrBlank(valor)){
			try {
				decimalValue = new BigDecimal(valor);
				valor = df.format(decimalValue).toString();
			} catch (NumberFormatException e) {
				valor = valor.replace(".", "");
				valor = valor.replace(",", ".");
				decimalValue = new BigDecimal(valor);
				valor = df.format(decimalValue).toString();
			}
		}
		
		return valor;
	}

	public static Short toShort(Object obj) {
		return obj == null ? null : ((Number) obj).shortValue();
	}

	public static Long toLong(Object obj) {
		return obj == null ? null : ((Number) obj).longValue();
	}

	public static Date toDate(Object obj) {
		
		if (obj == null)
			return null;

		if (obj instanceof Date) {
			return (Date) obj;
		} else if (obj instanceof Calendar) {
			return ((Calendar)obj).getTime();
		}

		throw new IllegalArgumentException();
	}

	public static Double toDouble(Object obj) {
		return obj == null ? null : ((Number) obj).doubleValue();
	}

	/**
	 * Logging de la excepción. <br />
	 * Filosofía: Hay que sacar las trazas, en el lugar que corresponda
	 * preferiblemente.
	 * 
	 * @param log
	 *            Logger donde escribir los logs. En el caso que sea
	 *            <code>null</code> se escribirá por STDERR.
	 * @param ex
	 *            Excepción a informar.
	 * @param message
	 *            Mensaje de la excepción. En el caso que no sea
	 *            <code>null</code> se creará una nueva {@link RuntimeException}
	 *            .
	 */
	public static void logException(final Log log, final Exception ex,
			final String message) {

		final Exception ex2;

		if (!isNullOrBlank(message)) {

			ex2 = new RuntimeException(message, ex);
		} else {
			ex2 = ex != null ? ex : new RuntimeException();
		}

		if (log == null || !log.isErrorEnabled()) {

			ex2.printStackTrace();

			return;
		}

		final StringWriter sw = new StringWriter();
		ex2.printStackTrace(new PrintWriter(sw));

		log.error(sw.toString());

//		En el caso que todo vaya bien...
//		if (!log.isDebugEnabled()) {
//
//			log.error(sw.toString());
//
//			return;
//		}
//
//		log.error(ex2);
//		log.debug(sw.toString());
	}

	/**
	 * Logging de la excepción.
	 * 
	 * @param log
	 * @param ex
	 * @see #logException(Log, Exception, String)
	 */
	public static void logException(final Log log, final Exception ex) {
		logException(log, ex, null);
	}


	public static boolean isNullOrZero(Object obj) {
		
		try {
			
			if (obj == null || obj.toString().length() == 0) {
				return true;
			} else if (BigDecimal.class.equals(obj.getClass())){
				return (BigDecimal.ZERO.compareTo((BigDecimal) obj) == 0);
			}else if (Integer.class.equals(obj.getClass())){
				return ((Integer) obj == 0);
			}else if (Long.class.equals(obj.getClass())){
				return ((Long) obj == 0L);
			}
		} catch (Exception e) {
			return false;
		}
		return false;
	}
	
	/**
	 * Comprueba que el parametro fecha es la fecha actual
	 * @param fecha
	 * @return
	 */
	public static boolean esHoy(Date fecha){
		Calendar cal = Calendar.getInstance();
		cal.setTime(fecha);
		
		Calendar hoy = Calendar.getInstance();
		
		return(cal.get(Calendar.YEAR)==hoy.get(Calendar.YEAR) && cal.get(Calendar.MONTH) == hoy.get(Calendar.MONTH) && cal.get(Calendar.DAY_OF_MONTH) == hoy.get(Calendar.DAY_OF_MONTH));

	}
	
    /**
     * devuelve en formato date la fecha
     * @param fecha
     * @return
     */
	public static synchronized java.util.Date deStringToDate(String fecha) {
        SimpleDateFormat formatoDelTexto = new SimpleDateFormat("dd/MM/yyyy");
        Date fechaEnviar = null;
        try {
            fechaEnviar = formatoDelTexto.parse(fecha);
            return fechaEnviar;
        } catch (ParseException ex) {
            ex.printStackTrace();
            return null;
        }
    }
	
	/**
	 * Devuelve el año de una Date
	 * @param fecha
	 * @return
	 */
	public static int getYear(Date fecha){
		Calendar cal = Calendar.getInstance();
		cal.setTime(fecha);
		return cal.get(Calendar.YEAR);
	}

	/**
	 * Devuelve el mes de una Date
	 * Enero = 0 !!!!
	 * @param fecha
	 * @return
	 */
	public static int getMonth(Date fecha){
		Calendar cal = Calendar.getInstance();
		cal.setTime(fecha);
		return cal.get(Calendar.MONTH);
	}

	/**
	 * Devuelve el día del mes de una Date
	 * @param fecha
	 * @return
	 */
	public int getDay(Date fecha){
		Calendar cal = Calendar.getInstance();
		cal.setTime(fecha);
		return cal.get(Calendar.DAY_OF_MONTH);
	}

	public static Date ajustarFecha(Date fecha, int dias){
		Calendar cal = Calendar.getInstance();
		cal.setTime(fecha);
		cal.add(Calendar.DATE, dias);
	   return cal.getTime();
		
	}
}
