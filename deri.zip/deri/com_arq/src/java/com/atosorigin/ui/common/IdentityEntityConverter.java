package com.atosorigin.ui.common;
import java.io.Serializable;
import java.util.Collection;
import java.util.HashSet;
import java.util.Set;

import javax.faces.component.UIComponent;
import javax.faces.component.UISelectItems;
import javax.faces.context.FacesContext;
import javax.faces.convert.ConverterException;
import javax.faces.model.SelectItem;
import javax.persistence.Id;

import org.jboss.seam.ScopeType;
import org.jboss.seam.annotations.Install;
import org.jboss.seam.annotations.Name;
import org.jboss.seam.annotations.Scope;
import org.jboss.seam.annotations.Transactional;
import org.jboss.seam.annotations.faces.Converter;
import org.jboss.seam.annotations.intercept.BypassInterceptors;
import org.jboss.seam.log.LogProvider;
import org.jboss.seam.log.Logging;
import org.jboss.seam.ui.AbstractEntityLoader;
import org.jboss.seam.util.AnnotatedBeanProperty;

@Name("identityEntityConverter")
@Scope(ScopeType.CONVERSATION)
@Install(precedence = Install.APPLICATION)
@Converter
@BypassInterceptors
public class IdentityEntityConverter implements javax.faces.convert.Converter, Serializable {
	private static final long serialVersionUID = 5291805316838074880L;
	
	private static final LogProvider LOG = Logging.getLogProvider(IdentityEntityConverter.class);
	
    
    public AbstractEntityLoader<?> getEntityLoader() {
    	//FLM: bug EM is closed
        //if (entityLoader == null)
        return AbstractEntityLoader.instance();
    }
    
    @Transactional
    public String getAsString(FacesContext facesContext, UIComponent component, Object value) throws ConverterException {
        if (value == null)
            return null;
        
        if (value instanceof String)
            return (String) value;
        
        
        return getEntityLoader().put(value);
    }

    @Transactional
    public Object getAsObject(FacesContext facesContext, UIComponent component, String value) throws ConverterException {
        if (value == null)
            return null;

        Object loaded = getEntityLoader().get(value);
        if (loaded == null) {
        	LOG.error("The Entity loader returned a null object");
        	throw new ConverterException("The Entity loader returned a null object.");
        }
        
        Class<?> clazz = loaded.getClass();
        AnnotatedBeanProperty<Id> idProperty;

        /* 
         * Look backwards in the entity inheritance hierarchy for a property annotated with @Id. 
         * Note: The class of a managed entity is a java assist descendant of the entity class.
        */
        do {
        	idProperty = new AnnotatedBeanProperty<Id>(clazz, Id.class);
        	clazz = clazz.getSuperclass();
        } while (!idProperty.isSet() && clazz != null);

        /* If the @Id property cannot be found then there is nothing to do but raise an error */
    	if (!idProperty.isSet()) {
    		LOG.error("Cannot find a property annotated with @Id on entity");
    		throw new ConverterException("Cannot find a property annotated with @Id on entity");
    	}
    	
        Object loadedId = idProperty.getValue(loaded);
        if (loadedId == null) {
        	LOG.error("The loaded entity must have a not-null value for its identifier (@Id)");
        	throw new ConverterException("The loaded entity must have a not-null value for its identifier (@Id)");
        }
        
        Set<Object> originalList = getOriginalSelectItems(component);
        for (Object original : originalList) {
            Object originalId = idProperty.getValue(original);
            
            if (originalId != null && loadedId.equals(originalId))
                return original;
        }

        /* If the item was not found in the list fall back to the default provided by the EntityLoader */
        return loaded;
    }

    /**
     * Get a list of objects from the component's select items
     * 
     * @param component
     * @return
     */
    protected Set<Object> getOriginalSelectItems(UIComponent component) {
        Set<Object> items = new HashSet<Object>();
        
        for (UIComponent child : component.getChildren()) {
            if (child instanceof UISelectItems) {
                UISelectItems selectItems = (UISelectItems) child;
                for (Object selectItemsValue : (Collection<?>) selectItems.getValue()) {
                    SelectItem selectItem = (SelectItem) selectItemsValue;
                    if (selectItem.getValue() == null) 
                    	continue;
                    
                    items.add(selectItem.getValue());
                }
                break;
            }
        }
        return items;
    }
}