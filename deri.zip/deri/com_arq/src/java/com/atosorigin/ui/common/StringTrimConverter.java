package com.atosorigin.ui.common;
import javax.faces.component.UIComponent;
import javax.faces.context.FacesContext;

import org.jboss.seam.annotations.Name;
import org.jboss.seam.annotations.faces.Converter;
import org.jboss.seam.annotations.intercept.BypassInterceptors;

@Name("stringTrimConverter")
@BypassInterceptors
@Converter
public class StringTrimConverter implements javax.faces.convert.Converter {
	
  public Object getAsObject(FacesContext context, UIComponent cmp, String value) {
	  String result = null;
	  if( value != null && 
			  value.length( ) > 0 && 
			    !value.trim( ).equals("") ) {
		  		result = value.trim( );
			}
    return result;
  }
  
  public String getAsString(FacesContext context, UIComponent cmp, Object value) {
    if(value != null) {
      return value.toString().trim();
    } 
    return null;
  }
}
