package com.atosorigin.confirmaciones.edicion.actions; 

import javax.ejb.Local;

@Local
public interface Download
{
	public String pdf();
}