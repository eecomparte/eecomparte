package com.atosorigin.confirmaciones.edicion.actions;

import java.sql.SQLException;

import javax.faces.context.ExternalContext;
import javax.faces.context.FacesContext;
import javax.persistence.EntityManager;
import javax.servlet.http.HttpServletResponse;

import org.jboss.seam.annotations.In;
import org.jboss.seam.annotations.Logger;
import org.jboss.seam.annotations.Name;
import org.jboss.seam.log.Log;

import com.atosorigin.common.utils.GenericUtils;
import com.atosorigin.confirmaciones.edicion.database.BaseDBAccess;
import com.atosorigin.confirmaciones.edicion.entities.User;
import com.atosorigin.confirmaciones.edicion.entities.base.ExtendedPDF;
import com.atosorigin.confirmaciones.edicion.tools.ProjectConfig;
import com.atosorigin.confirmaciones.negocio.ResponseFiller;
import com.atosorigin.deri.model.gestionoperaciones.ParamPDFConfirmaciones;

@Name("download")
public class DownloadAction implements Download
{
	private static final String PDF_PREFIX = 
		ProjectConfig.getProperty("outFileName");
	private static final String PDF_CONTENT_TYPE = 
		ProjectConfig.getProperty("outContentType"); 

	@In(value="#{facesContext}")
	FacesContext facesContext;

	@In
	private User user;

	@Logger
	private static Log log;

	@In(value="#{facesContext.externalContext}")
	private ExternalContext extCtx;
	
	@In
	private EntityManager entityManager;

	public String pdf() {
		String pdfName = PDF_PREFIX + user.getCodConfi() + ".pdf";
		log.info("This should have started the pdf download of " + pdfName );
		ExtendedPDF extendedPDF = user.getExtendedPDF();
		HttpServletResponse response = (HttpServletResponse)extCtx.getResponse();

		String codi = "" + user.getCodConfi()+ "";
		Boolean barcode = false;
		Boolean indicadorFirmaDigital = false;
		Boolean indicadorViaSegura = false;
		
		BaseDBAccess db =null;
		try { 
			db = new BaseDBAccess("VISOR",entityManager);
		} catch (Exception e) {
			barcode = false;
			indicadorFirmaDigital  = false;

		}			

		if (!GenericUtils.isNullOrBlank(db)){
			try { 
				barcode = db.activarOsp(codi);
			} catch (SQLException e) {
				barcode = false;
			}	
			try { 
				indicadorFirmaDigital = db.indicadorFirmaDigital(codi);
			} catch (SQLException e) {
				indicadorFirmaDigital  = false;
			}
			try { 
				indicadorViaSegura = db.indicadorViaSegura(codi);
			} catch (SQLException e) {
				indicadorViaSegura  = false;
			}	
		}
		
		ParamPDFConfirmaciones paramPDF = 
			new ParamPDFConfirmaciones(barcode, indicadorFirmaDigital, indicadorViaSegura);
		
		
		try {
			char watermarkChar = user.getWatermark();
			log.info("Watermark is <" + watermarkChar + '>');
			ResponseFiller.populate(response, pdfName, extendedPDF, watermarkChar, paramPDF);
			facesContext.responseComplete();
		} catch(Exception e) {
			log.error("Failure to download PDF" , e);
		}
		return null;
	}

}
