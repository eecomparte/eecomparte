package com.atosorigin.confirmaciones.edicion.actions;

import javax.ejb.Local;

@Local
public interface Edit
{
	public String editArea() ;
	public String saveTag() ; 
	public String deleteTag() ; 
}