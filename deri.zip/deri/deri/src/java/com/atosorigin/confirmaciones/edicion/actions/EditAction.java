package com.atosorigin.confirmaciones.edicion.actions;

import java.awt.geom.Rectangle2D;
import java.io.InputStream;
import java.util.List;
import java.util.Map.Entry;

import javax.faces.context.FacesContext;
import javax.persistence.EntityManager;
import javax.servlet.http.HttpSession;
import javax.xml.transform.URIResolver;

import org.jboss.seam.ScopeType;
import org.jboss.seam.annotations.In;
import org.jboss.seam.annotations.Logger;
import org.jboss.seam.annotations.Name;
import org.jboss.seam.annotations.Out;
import org.jboss.seam.faces.FacesMessages;
import org.jboss.seam.log.Log;

import com.atosorigin.confirmaciones.edicion.entities.User;
import com.atosorigin.confirmaciones.edicion.entities.base.Area;
import com.atosorigin.confirmaciones.edicion.entities.base.ExtendedPDF;
import com.atosorigin.confirmaciones.edicion.entities.base.ExtendedViewPDF;
import com.atosorigin.confirmaciones.edicion.tools.Transform;
import com.atosorigin.confirmaciones.edicion.tools.XMLParsing;
import com.atosorigin.confirmaciones.servlet.JarServletContextURIResolver;
import com.atosorigin.deri.util.ConfiguracionDeri;
import com.atosorigin.fop.render.pdf.Boundaries;

@Name("edit")
@SuppressWarnings("unused")
public class EditAction implements Edit
{

	private static final int SDT_HEIGHT = 600; 

	@In(create = true, required = false)
	@Out(scope = ScopeType.SESSION, required = false)
	private Area area;

	@In("#{pdfAction}")
	private RegisterAction pdfAction;
//	private Picture imageEntity;

	@In
	private User user;

	@Logger
	private static Log log;
	
	@In
	private EntityManager entityManager;

	@In(value="org.jboss.seam.faces.facesContext")
	private FacesContext facesContext;

	
	@In
	private ConfiguracionDeri configuracionDeri;



	private URIResolver getUriResolver() {
		URIResolver uriResolver=null;
		if(facesContext!=null){
			HttpSession session = (HttpSession) facesContext.getExternalContext().getSession(false);
			uriResolver = new JarServletContextURIResolver(session.getServletContext());
		}
		return uriResolver;
	}



	public String editArea() {

		int pageNB = pdfAction.getImageEntity().getPageNB();
		String position = "Point x=" + area.getX() + ", y=" + area.getY();

		log.info(position + " has been selected, in page " + pageNB);

		ExtendedPDF extendedPDF = user.getExtendedPDF();
		Boundaries boundaries = extendedPDF.getBoundaries(pageNB);

		log.info("     Number of boundary on page " + pageNB + ": "
				+ boundaries.size());

		try {
			String tagID = retrieveXmlTagId(area.getX(), area.getY(),
					boundaries, pdfAction.getImageEntity().getHeight());

			if (tagID.startsWith("#currentdate-")) {
				String warning = "Text in region " + position
						+ " is the current date - Not editable";

				log.warn(warning);

				// FacesMessages.instance().add(longError);
				return null;
			}

			String fo = extendedPDF.getFO();
			XMLParsing p = new XMLParsing();
			InputStream stream = Transform.xmlStringToStream(fo);
			String text = p.getTextOfId(stream, tagID);

			log.info("Found the selected text: <" + text + ">");

			area.setTagText(text);
			area.setTagId(tagID);

		} catch (Exception e) {
			String error = "Problem finding the associated text region to "
					+ position;
			String longError = error + ": " + e.getMessage();
			// FIXME : should I log the Exception stacktrace? log.error(error,
			// e);
			log.warn(longError);
			// FacesMessages.instance().add(longError);
		}

		return null;
		// return "/pages/pdf/editTag.xhtml";
	}

	// FIXME this is the same code as saveTag!! REFACTOR!
	public String deleteTag() {
		String newText = area.getTagText();
		String id = area.getTagId();

		ExtendedPDF extendedPDF = user.getExtendedPDF();
		String fo1 = extendedPDF.getFO();
		String fo2;
		try {
			XMLParsing tool = new XMLParsing(); 
			fo2 = tool.removeId(fo1, id);
		} catch (Exception e) {
			String error = "Can't modify the intermediary format: "
				+ e.getMessage();
			FacesMessages.instance().add(error);
			log.error(error, e);
			return null;
		}

		// 3. Allow access from the view to the generated objects 
		try { 
			extendedPDF = new ExtendedViewPDF ( fo2, getUriResolver() , configuracionDeri.getPdfSubstitutionFont()); 
			user.setExtendedPDF(extendedPDF);
		} catch (Exception e) {
			String error = "Can't recreate the PDF based on the new input (" 
				+ newText + "). More information: " + e.getMessage();
			FacesMessages.instance().add(error);
			log.error(error, e);
			return null;
		}

		area = new Area(); // This clears the values that have been entered by the user, 
		// returning a fresh object for the JSF pages

		Integer debugOld = pdfAction.getImageEntity().getId();
		int pageNB = pdfAction.getImageEntity().getPageNB();

		pdfAction.setImageEntity(extendedPDF.getPage(pageNB));

//		try {
//			BeanUtils.copyProperties(pdfAction.getImageEntity(), extendedPDF.getPage(pageNB));
//		} catch (Exception e) {
//
//			log.error(e);
//		}

		return "/pages/pdf/showSingleImage.xhtml";
	}

	public String saveTag() {
		String newText = area.getTagText();
		String id = area.getTagId();

		ExtendedPDF extendedPDF = user.getExtendedPDF();
		String fo1 = extendedPDF.getFO();
		String fo2;
		try {
			XMLParsing tool = new XMLParsing(); 

			String NL = "\n";
			if (!newText.contains(NL)) {
				// that's easy, not creating new paragraphs
				fo2 = tool.replaceIdText(fo1, id, newText);
			}
			else {
				// a new paragraph is created for each newline character 
				String[] array = newText.split(NL);
				log.debug("Newtext contained " + array.length + "new lines" );
				fo2 = tool.replaceIdText(fo1, id, array[0]);
				for (int i= array.length -1; i > 0 ; i--)
					fo2 = tool.addBlockAfter(fo2, id, array[i]);
			}			
			
		} catch (Exception e) {
			String error = "Can't modify the intermediary format: "
				+ e.getMessage();
			FacesMessages.instance().add(error);
			log.error(error, e);
			return null;
		}

		// 3. Allow access from the view to the generated objects 
		try { 
			extendedPDF = new ExtendedViewPDF ( fo2, getUriResolver(),configuracionDeri.getPdfSubstitutionFont() ); 
			user.setExtendedPDF(extendedPDF);
		} catch (Exception e) {
			String error = "Can't recreate the PDF based on the new input (" 
				+ newText + "). More information: " + e.getMessage();
			FacesMessages.instance().add(error);
			log.error(error, e);
			return null;
		}

		area = new Area(); // This clears the values that have been entered by the user, 
		// returning a fresh object for the JSF pages

		Integer debugOld = pdfAction.getImageEntity().getId();
		int pageNB = pdfAction.getImageEntity().getPageNB();

		pdfAction.setImageEntity(extendedPDF.getPage(pageNB));

//		try {
//			BeanUtils.copyProperties(pdfAction.getImageEntity(), extendedPDF.getPage(pageNB));
//		} catch (Exception e) {
//
//			log.error(e);
//		}

		log.info("Created new image entity: " + pdfAction.getImageEntity().getId() + "(old was " + debugOld +")" );
		return "/pages/pdf/showSingleImage.xhtml";
	}

	/**
	 * @param x the X position of the mouse click
	 * @param y the Y position of the mouse click
	 * @param boundaries the list of bounding boxes that appear in the image 
	 * @param imageHeight the Height of the image shown to the user, relative to params x and y
	 */
	private String retrieveXmlTagId(int x, int y, Boundaries boundaries, int imageHeight) {
		// FIXME: how does the scale get computed?  
		// I think we are doing the inverse transformation of something done earlier... 
		// @see PDFRenderer.printAbsolutePosition
		
		if (imageHeight != SDT_HEIGHT){
			x = x * SDT_HEIGHT / imageHeight ;
			y = y * SDT_HEIGHT / imageHeight ;
		}
		float scale = 1.4f ; 
		x = (int) (x * scale) ; 
		y = (int) ((SDT_HEIGHT - y) * scale); // y also requires a flip!

		//log.error("..... First thing is to revert to the image coordinates: x=" + x + " y=" + y);
		List<Entry<String, Rectangle2D>> matches = 
			boundaries.entriesContaining(x, y);
		for (Entry<String, Rectangle2D> m : matches){
			log.info("..... Match!! in page " + boundaries.pageNumber+ " id="+m.getKey()+" "+ m.getValue());
			return m.getKey();
		}
		//log.error("..... DONE Trying to match point x="+x+" y="+y +" into boundaries");
		// FIXME maybe I should make some approximation instead... and return the closest block!
		throw new ArrayIndexOutOfBoundsException("Point x="+x+" y="+y + " not recognised as text in the image!");
	}



	public Area getArea() {

		return area != null ? area : (area = new Area());
	}


}
