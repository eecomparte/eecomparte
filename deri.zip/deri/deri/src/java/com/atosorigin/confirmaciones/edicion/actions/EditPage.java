package com.atosorigin.confirmaciones.edicion.actions;

import javax.ejb.Local;

@Local
public interface EditPage
{
	public String showSinglePage() ;
	public String prevArea() ;
	public String nextArea() ;

}