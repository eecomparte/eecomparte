package com.atosorigin.confirmaciones.edicion.actions;

import org.jboss.seam.annotations.In;
import org.jboss.seam.annotations.Logger;
import org.jboss.seam.annotations.Name;
import org.jboss.seam.log.Log;

import com.atosorigin.confirmaciones.edicion.entities.User;
import com.atosorigin.confirmaciones.edicion.entities.base.ExtendedPDF;

@Name("editpage")
public class EditPageAction implements EditPage
{
	@In
	private User user;

	@In("#{pdfAction}")
	private RegisterAction pdfAction;
//	private Picture imageEntity;

	@Logger
	private static Log log;

	public String showSinglePage() {
		log.debug("Showing one single page, as " + pdfAction.getImageEntity());
		return "/pages/pdf/showSingleImage.xhtml";
	}

	/** 
	 * Set the imageEntity to be the previous element in the User page list
	 * @return
	 */
	public String prevArea() {
		int prevIndex = pdfAction.getImageEntity().getPageNB() - 1 ; 
		ExtendedPDF extendedPDF = user.getExtendedPDF();

		pdfAction.setImageEntity(extendedPDF.getPage(prevIndex));

//		try {
//			BeanUtils.copyProperties(pdfAction.getImageEntity(), extendedPDF.getPage(prevIndex));
//		} catch (Exception e) {
//
//			log.error(e);
//		}

		log.debug("Showing previous page, as " + pdfAction.getImageEntity());
		return "/pages/pdf/showSingleImage.xhtml";
	}

	/** 
	 * Set the imageEntity to be the previous element in the User page list
	 * @return
	 */
	public String nextArea() {
		int nextIndex = pdfAction.getImageEntity().getPageNB() +1 ;
		ExtendedPDF extendedPDF = user.getExtendedPDF();

		pdfAction.setImageEntity(extendedPDF.getPage(nextIndex));

//		try {
//			BeanUtils.copyProperties(pdfAction.getImageEntity(), extendedPDF.getPage(nextIndex));
//		} catch (Exception e) {
//
//			log.error(e);
//		}

		log.debug("Showing next page, as " + pdfAction.getImageEntity());
		return "/pages/pdf/showSingleImage.xhtml";
	}

}
