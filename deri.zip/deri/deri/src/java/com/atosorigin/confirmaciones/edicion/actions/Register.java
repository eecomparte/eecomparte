package com.atosorigin.confirmaciones.edicion.actions;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.sql.SQLException;

import javax.ejb.Local;
import javax.xml.transform.TransformerException;

import org.apache.fop.apps.FOPException;

@Local
public interface Register
{
	   public String showPDF() 
	   throws UnsupportedEncodingException, FileNotFoundException, 
	   	FOPException, SQLException, TransformerException, IOException;
	   public String saveAndQuit() ;
	   public String quit() ;
}