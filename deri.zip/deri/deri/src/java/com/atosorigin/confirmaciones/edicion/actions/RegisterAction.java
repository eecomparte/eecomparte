package com.atosorigin.confirmaciones.edicion.actions;

import java.sql.SQLException;

import javax.faces.context.FacesContext;
import javax.persistence.EntityManager;
import javax.servlet.http.HttpSession;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.URIResolver;

import org.jboss.seam.ScopeType;
import org.jboss.seam.annotations.In;
import org.jboss.seam.annotations.Logger;
import org.jboss.seam.annotations.Name;
import org.jboss.seam.annotations.Scope;
import org.jboss.seam.annotations.web.RequestParameter;
import org.jboss.seam.faces.FacesMessages;
import org.jboss.seam.international.StatusMessages;
import org.jboss.seam.international.StatusMessage.Severity;
import org.jboss.seam.log.Log;

import com.atosorigin.common.utils.GenericUtils;
import com.atosorigin.confirmaciones.edicion.database.BaseDBAccess;
import com.atosorigin.confirmaciones.edicion.entities.User;
import com.atosorigin.confirmaciones.edicion.entities.base.ExtendedPDF;
import com.atosorigin.confirmaciones.edicion.entities.base.Picture;
import com.atosorigin.confirmaciones.edicion.tools.ExtendedPDFFactory;
import com.atosorigin.confirmaciones.edicion.tools.ProjectConfig;
import com.atosorigin.confirmaciones.negocio.ResponseFiller;
import com.atosorigin.confirmaciones.servlet.JarServletContextURIResolver;
import com.atosorigin.deri.model.gestionoperaciones.ParamPDFConfirmaciones;
import com.atosorigin.deri.util.ConfiguracionDeri;
import com.atosorigin.deri.util.InterceptExceptions;
import com.atosorigin.fop.render.pdf.TransformerFactorySingleton;


@Name("pdfAction")
@Scope(ScopeType.CONVERSATION)
@InterceptExceptions
public class RegisterAction implements Register
{

	@RequestParameter("subject")  // same value as the 'codConfi' in f:param
	private String subject;		  // used to retrieve the url parameter	

	@RequestParameter("subject2")   // same value as the 'watermark' in f:param
	private String subject2;		// used to retrieve the url parameter	

  
	@In
	private User user;

//	@Out(required=false, scope=ScopeType.SESSION)
	private Picture imageEntity;

	@Logger
	private static Log log;

	public RegisterAction() {}

	/* Mensajes de estado de SEAM */
	@In 
	protected StatusMessages statusMessages;
	
	@In
	private EntityManager entityManager;

	@In(value="org.jboss.seam.faces.facesContext")
	private FacesContext facesContext;
	
	@In
	private ConfiguracionDeri configuracionDeri;

	
	public String showPDF() 
	{
		String version = ProjectConfig.getProperty("appVersion");
		log.debug("Executing pdfEdition version " + version );
		
		// make sure entry values are correct  
		if (!passwordCheck(user.getPassword())) {
			// return inputError("Wrong password");
        	statusMessages.add("Wrong password");
			statusMessages.addToControl(
					"error", 
					Severity.ERROR, 
					"Wrong password CAS?");

    		imageEntity=new Picture(); 
			return null;
			
		}

		// FIXME Am I properly retrieving the web app parameters?
		if (this.subject!=null) {
			long longVal = 0;
			try {
				longVal = Long.parseLong(subject); 
				user.setCodConfi(longVal);
			} catch (NumberFormatException e) {
				log.error("Codconfi passed in parameter could not be read: " + subject);
				log.error("Maintaining previous value " + user.getCodConfi() );}
		}

		if (this.subject2!=null) {
			char watermark = 0;
			watermark = 
					(subject2 != null && subject2.length()==1 ? 
							subject2.charAt(0) : 
								0);
			user.setWatermark(watermark);
		}
		
		// make sure entry values are correct  
		if (user.getCodConfi() == 0) 
			return inputError("Please set confirmation number ");

		log.info("Authorized user, asking for codconfi=" + user.getCodConfi());

		// create the PDF and associated objects
		ExtendedPDF extendedPDF;
		try {
			
			TransformerFactory factory = TransformerFactorySingleton.getFactory();
			URIResolver uriResolver=null;
			if(facesContext!=null){
				HttpSession session = (HttpSession) facesContext.getExternalContext().getSession(false);
				uriResolver = new JarServletContextURIResolver(session.getServletContext());
			}
			extendedPDF = ExtendedPDFFactory.generate(entityManager, user.getCodConfi(), this, null, uriResolver,configuracionDeri.getPdfSubstitutionFont());
			// throws UnsupportedEncodingException, FileNotFoundException, 
		   	// FOPException, SQLException, TransformerException, IOException;
		} catch (SQLException e) {
			String error = "Problem while accessing the document in database";
			log.error (error, e);
			return inputError(error + ": " + e.getMessage());
		} catch (Exception e) {
			String error = "Problem while creating the PDF from the document in database";
			log.error (error, e);
			return inputError(error + ": " + e.getMessage());
		}
		// Allow access from the view to the generated objects 
		user.setExtendedPDF(extendedPDF);

		imageEntity = user.getExtendedPDF().getPage(1);

		return "/pages/pdf/showSingleImage.xhtml";
	}


	private String inputError(String error) {
		FacesMessages.instance().clear();
		FacesMessages.instance().add(error);
		imageEntity=new Picture(); 
		return null;
	}

	public String saveAndQuit() {
		imageEntity = new Picture(); // needed with the @out property. 
		ExtendedPDF extendedPDF = user.getExtendedPDF();
		String fo = extendedPDF.getFO();
		byte[] pdf = extendedPDF.getPdfByteArray();
		
		
		String codi = "" + user.getCodConfi()+ "";
		Boolean barcode = false;
		Boolean indicadorFirmaDigital = false;
		Boolean indicadorViaSegura = false;
		
		BaseDBAccess db =null;
		try { 
			db = new BaseDBAccess("VISOR",entityManager);
		} catch (Exception e) {
			barcode = false;
			indicadorFirmaDigital  = false;

		}			

		if (!GenericUtils.isNullOrBlank(db)){
			try { 
				barcode = db.activarOsp(codi);
			} catch (SQLException e) {
				barcode = false;
			}	
			try { 
				indicadorFirmaDigital = db.indicadorFirmaDigital(codi);
			} catch (SQLException e) {
				indicadorFirmaDigital  = false;
			}
			try { 
				indicadorViaSegura = db.indicadorViaSegura(codi);
			} catch (SQLException e) {
				indicadorViaSegura  = false;
			}	
		}
		
		ParamPDFConfirmaciones paramPDF = 
			new ParamPDFConfirmaciones(barcode, indicadorFirmaDigital, indicadorViaSegura);
		
		
		try {
			pdf = ResponseFiller.getPDFBytes(extendedPDF,paramPDF);
		} catch (Exception e) {
			String error = "Failed getting PDFbytes";
			log.error (error, e);
			FacesMessages.instance().add(error + ": " + e.getMessage());
			return null;
		}
		long codconfi = user.getCodConfi();
		try { 
			BaseDBAccess db2 = new BaseDBAccess(null, entityManager);
			boolean insertFO = db2.saveFO(fo, codconfi);
			boolean insertPDF = db2.savePDF(pdf, codconfi);
			log.info("Saved "+codconfi+" data in database: insertFO=" + insertFO + " insertPDF=" + insertPDF);
		} catch (SQLException e) {
			String error = "Failed inserting into database";
			log.error (error, e);
			FacesMessages.instance().add(error + ": " + e.getMessage());
			return null;
		}
		return "/pages/pdf/quit.xhtml";
	}

	public String quit() {
		// log.error(new NullPointerException("How do I call the Javascript now?"));
		return "/pages/pdf/quit.xhtml";
	}

	private boolean passwordCheck(String password) {
		String target = ProjectConfig.getProperty("password"); 
		// log.debug("Password received: <" + password + "> target=<" + target + ">");
		return password.equals(target);
	}


	public Picture getImageEntity() {
		return imageEntity;
	}


	public void setImageEntity(Picture imageEntity) {
		this.imageEntity = imageEntity;
	}

}
