package com.atosorigin.confirmaciones.edicion.database;

import javax.persistence.EntityManager;

import org.jboss.seam.ScopeType;
import org.jboss.seam.annotations.AutoCreate;
import org.jboss.seam.annotations.In;
import org.jboss.seam.annotations.Name;
import org.jboss.seam.annotations.Scope;


@Name("dbAccess")
@Scope(ScopeType.CONVERSATION)
@AutoCreate
@SuppressWarnings({"unchecked", "static-access", "unused"})

public class DBAccess extends BaseDBAccess{

	@In
	private EntityManager entityManager;
	
	public EntityManager getEntityManager() {
		return entityManager;
	}

	public DBAccess(String user, EntityManager entityManager) {
		super(user, entityManager);
	}

	public DBAccess(String user) {
		super(user);
	}

}