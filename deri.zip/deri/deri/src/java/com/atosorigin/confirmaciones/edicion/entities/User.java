//$Id: User.java,v 1.3 2010-10-13 17:50:26 angela.gutierrez Exp $
package com.atosorigin.confirmaciones.edicion.entities;

import static org.jboss.seam.ScopeType.SESSION;

import java.io.Serializable;
import java.util.List;

import org.jboss.seam.annotations.Name;
import org.jboss.seam.annotations.Scope;

import com.atosorigin.confirmaciones.edicion.entities.base.ExtendedPDF;
import com.atosorigin.confirmaciones.edicion.entities.base.Picture;

/**
 * Trivial class just to make sure the password typed by the user is kept somewhere. 
 * This could, later on, be used to do proper password checking. 
 */

@Name("user")
@Scope(SESSION)
public class User implements Serializable
{
	private static final long serialVersionUID = 1881413500711441951L;

	private long id; 
	private String password;
	private List<Picture> pageList;

	private long codConfi;
	private char water;
	private ExtendedPDF extendedPDF;

	public long getId() { return id;}
	public void setId(long id) { this.id = id; }

	public User() {}

	public User(long id, String password, String pdfpath /*, List<String> pageList*/)
	{
		this.id = id; 
		this.password = password;
	}

	// @NotNull 
	// @Length(min=2, max=15)
	public String getPassword()
	{
		return password;
	}

	public void setPassword(String password)
	{
		this.password = password;
	}

	public void setPageList(List<Picture> pageList) {
		this.pageList = pageList; 
	}

	public List<Picture>  getPageList() {
		return pageList; 
	}
	
	public void setExtendedPDF(ExtendedPDF extendedPDF) {
		this.extendedPDF = extendedPDF;		
	}

	public ExtendedPDF getExtendedPDF() {
		return this.extendedPDF;		
	}

	public long getCodConfi() {
		 return this.codConfi;  
	}

	public void setCodConfi(long cod) {
		this.codConfi = cod; 
	}

	public char getWatermark() {
		return this.water;
	}

	public void setWatermark(char watermark) {
		this.water = watermark ;
	}

}
