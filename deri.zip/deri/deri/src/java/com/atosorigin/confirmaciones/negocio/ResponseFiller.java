package com.atosorigin.confirmaciones.negocio;

import java.awt.geom.Rectangle2D;
import java.io.IOException;

import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServletResponse;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.TransformerException;
import javax.xml.xpath.XPathExpressionException;

import org.apache.fop.apps.FOPException;
import org.xml.sax.SAXException;

import com.atosorigin.confirmaciones.edicion.entities.base.ExtendedPDF;
import com.atosorigin.confirmaciones.edicion.tools.ModifyBinaryPDF;
import com.atosorigin.confirmaciones.edicion.tools.ProjectConfig;
import com.atosorigin.deri.model.gestionoperaciones.ParamPDFConfirmaciones;
import com.itextpdf.text.DocumentException;

public class ResponseFiller {

	private static final String PDF_CONTENT_TYPE = 
		ProjectConfig.getProperty("outContentType"); 
	
	/**
	 * Decorate an HTTP response stream with the PDF, triggering the download
	 * @param indicadorFirmaDigital 
	 * @throws IOException
	 * @throws DocumentException
	 * @throws SAXException 
	 * @throws ParserConfigurationException 
	 * @throws XPathExpressionException 
	 * @throws TransformerException 
	 * @throws DocumentException 
	 */
	public static void populate(HttpServletResponse response, String pdfName,
			ExtendedPDF extendedPDF, char watermarkChar, ParamPDFConfirmaciones paramPDF) 
	throws IOException, XPathExpressionException, ParserConfigurationException, SAXException, TransformerException, DocumentException {
		
		response.setContentType(PDF_CONTENT_TYPE);
		response.addHeader("Content-disposition", "filename=\"" + pdfName +"\"");

		//ystem.out.println("***DEBUG: populate: " + pdfName);		

		byte[] pdfByteArray = getPDFBytes(extendedPDF, watermarkChar, paramPDF);
		
		// push bytes on stream
		ServletOutputStream stream = response.getOutputStream();
		stream.write(pdfByteArray);
		stream.flush();
		stream.close();
		//ystem.out.println("***DEBUG: populate close & exit");		
	}

	public static void populate(HttpServletResponse response, String pdfName,
			byte[] pdfByteArray, char watermarkChar, Boolean barcode) 
	throws IOException, XPathExpressionException, ParserConfigurationException, SAXException, TransformerException, DocumentException {
		
		response.setContentType(PDF_CONTENT_TYPE);
		response.addHeader("Content-disposition", "filename=\"" + pdfName +"\"");

		//ystem.out.println("***DEBUG: populate: " + pdfName);		

		//byte[] pdfByteArray = getPDFBytes(extendedPDF, watermarkChar);
		
		// push bytes on stream
		ServletOutputStream stream = response.getOutputStream();
		stream.write(pdfByteArray);
		stream.flush();
		stream.close();
		//ystem.out.println("***DEBUG: populate close & exit");		
	}

	public static byte[] getPDFBytes(ExtendedPDF extendedPDF,
			char watermarkChar, ParamPDFConfirmaciones paramPDF) throws XPathExpressionException,
			ParserConfigurationException, SAXException, IOException,
			TransformerException, FOPException, DocumentException {
		// for the dynamic date creation, it is necessary to remove the previous date
		String fo = extendedPDF.getFO();
		
		String id = extendedPDF.getDateID();
		// TOD MJD 21/4 fo = new XMLParsing().replaceIdText(fo, id, " ");
		ExtendedPDF xpdf = new ExtendedPDF(fo, extendedPDF.getUriResolver());
		byte[] pdfByteArray = xpdf.getPdfByteArray();

		// PdfAdd dynamic date
		ModifyBinaryPDF modifyBinaryPDF = new ModifyBinaryPDF();
		Rectangle2D rect = extendedPDF.getDateBoundary();
		
		//--fixeItextRectangle(rect);
		String prefix = ""; //extendedPDF.getDatePrefix();
		String suffix = ""; //extendedPDF.getDateSuffix();
		String locale = extendedPDF.getDateLocale();
		
		
		System.out.println("***DEBUG: populate locale:" + locale);
		
		//SMM Fecha Condicional 07/04/2015
		byte[] withDate;
		withDate = pdfByteArray;
//		if (paramPDF.getIndicadorFirmaDigital()){
//			withDate = pdfByteArray;
//		}else{
//			withDate = modifyBinaryPDF.addDateJavaScript(pdfByteArray, rect, prefix, suffix, locale);
//		}
//		pdfByteArray = withDate;
		//ystem.out.println("***DEBUG: populate withDate");		

		// PdfAdd watermark
		//if (watermarkChar == 'C' || watermarkChar == 'D') {
			byte[] withWatermark = modifyBinaryPDF.addWatermark(withDate, watermarkChar, locale);
			//pdfByteArray = withWatermark;
			//ystem.out.println("***DEBUG: populate withWatermark");		
		//}
			
		// -->> addPeuSenseFirmes - 7 oct 2010 - mjd
		withDate = modifyBinaryPDF.addPeuSenseFirmes(withWatermark, locale);
		pdfByteArray = withDate;
		// <<-- addPeuSenseFirmes - 7 oct 2010 - mjd			

		withDate = modifyBinaryPDF.addPeuClientSenseFirmes(pdfByteArray, locale);
		pdfByteArray = withDate;

// DESCOMENTAR BLOQUE CUANDO SE QUIERAN BARCODES DE NUEVO		
		if (paramPDF.getBarcode()){
//		// -->> provaBarcodes - 12 jul 2011 - smm
		
			if (!paramPDF.getIndicadorFirmaDigital()){
				withDate = modifyBinaryPDF.addBarcode(pdfByteArray, locale, fo);
				pdfByteArray = withDate;
			}

			if (!paramPDF.getIndicadorFirmaDigital() && paramPDF.getIndicadorViaSegura()){
				withDate = modifyBinaryPDF.addBarcodeIdeDocum(pdfByteArray, locale, fo );
				pdfByteArray = withDate;			
			}
			
//		// <<-- provaBarcodes - 12 jul 2011 - smm
//		}
//		withDate = modifyBinaryPDF.addBlackSquare(pdfByteArray, locale);		
//		pdfByteArray = withDate;
		
		//Creamos el código de barras correspondiente al primer dígito del código que 
		//aparece en el lateral derecho del pdf
//		withDate = modifyBinaryPDF.addBarcode39(pdfByteArray, locale, fo );
		if (!paramPDF.getIndicadorFirmaDigital() && paramPDF.getIndicadorViaSegura()){
			withDate = modifyBinaryPDF.addBarcode128(pdfByteArray, locale, fo );
		}else if (!paramPDF.getIndicadorFirmaDigital()){
			withDate = modifyBinaryPDF.addBarcode39(pdfByteArray, locale, fo );	
		}
			
		pdfByteArray = withDate;
		}
	

		
		return pdfByteArray;
	}

	public static byte[] getPDFBytes(ExtendedPDF extendedPDF, ParamPDFConfirmaciones paramPDF) throws XPathExpressionException,
			ParserConfigurationException, SAXException, IOException,
			TransformerException, FOPException, DocumentException {
		// for the dynamic date creation, it is necessary to remove the previous date
		String fo = extendedPDF.getFO();
		
		String id = extendedPDF.getDateID();
		// TOD MJD 21/4 fo = new XMLParsing().replaceIdText(fo, id, " ");
		ExtendedPDF xpdf = new ExtendedPDF(fo, extendedPDF.getUriResolver());
		byte[] pdfByteArray = xpdf.getPdfByteArray();

		// PdfAdd dynamic date
		ModifyBinaryPDF modifyBinaryPDF = new ModifyBinaryPDF();
		Rectangle2D rect = extendedPDF.getDateBoundary();
		
		//--fixeItextRectangle(rect);
		String prefix = ""; //extendedPDF.getDatePrefix();
		String suffix = ""; //extendedPDF.getDateSuffix();
		String locale = extendedPDF.getDateLocale();
		
		
		System.out.println("***DEBUG: populate locale:" + locale);
		
		//SMM Fecha Condicional 07/04/2015
		byte[] withDate;
		withDate = pdfByteArray;
//		if (paramPDF.getIndicadorFirmaDigital()){
//			withDate = pdfByteArray;		
//		}else{
//			withDate = modifyBinaryPDF.addDateJavaScript(pdfByteArray, rect, prefix, suffix, locale);
//		}
//		
//		pdfByteArray = withDate;
		//ystem.out.println("***DEBUG: populate withDate");		


		// -->> addPeuSenseFirmes - 7 oct 2010 - mjd
		withDate = modifyBinaryPDF.addPeuSenseFirmes(withDate, locale);
		pdfByteArray = withDate;
		
		withDate = modifyBinaryPDF.addPeuClientSenseFirmes(withDate, locale);
//		pdfByteArray = withDate;	
		
		// -->> provaBarcodes - 12 jul 2011 - smm
// DESCOMENTAR LINEA CUANDO SE QUIERAN DE NUEVO BARCODES
		if (paramPDF.getBarcode()){

			if (!paramPDF.getIndicadorFirmaDigital()){
				withDate = modifyBinaryPDF.addBarcode(pdfByteArray, locale, fo);
				pdfByteArray = withDate;
			}
			
			if (!paramPDF.getIndicadorFirmaDigital() && paramPDF.getIndicadorViaSegura()){
				withDate = modifyBinaryPDF.addBarcodeIdeDocum(pdfByteArray, locale, fo );
				pdfByteArray = withDate;			
			}
//		withDate = modifyBinaryPDF.addBlackSquare(pdfByteArray, locale);
//		pdfByteArray = withDate;
		// <<-- provaBarcodes - 12 jul 2011 - smm

		//Creamos el código de barras correspondiente al primer dígito del código que 
		//aparece en el lateral derecho del pdf
//		withDate = modifyBinaryPDF.addBarcode39(pdfByteArray, locale, fo );
			if (!paramPDF.getIndicadorFirmaDigital() && paramPDF.getIndicadorViaSegura()){
				withDate = modifyBinaryPDF.addBarcode128(pdfByteArray, locale, fo );
			}else if (!paramPDF.getIndicadorFirmaDigital()){
				withDate = modifyBinaryPDF.addBarcode39(pdfByteArray, locale, fo );	
			}

			pdfByteArray = withDate;	
		}
		return pdfByteArray;
	}

	private static void fixeItextRectangle(Rectangle2D rect) {
		int fixedPaddingX = 7; //ProjectConfig.getIntProperty("fixedItextPaddingX");
		int fixedPaddingY = 7; //ProjectConfig.getIntProperty("fixedItextPaddingY");
		double x = rect.getMinX();
		double y = rect.getMinY();
		double w = rect.getWidth();
		double h = rect.getHeight();
		rect.setRect(x + fixedPaddingX, y + fixedPaddingY, w, h);		
	}

}
