package com.atosorigin.confirmaciones.visualisation;

import java.sql.SQLException;

import javax.faces.context.ExternalContext;
import javax.faces.context.FacesContext;
import javax.persistence.EntityManager;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import javax.xml.transform.URIResolver;

import org.jboss.seam.annotations.In;
import org.jboss.seam.annotations.Name;
import org.jboss.seam.faces.FacesMessages;
import org.jboss.seam.international.StatusMessages;
import org.jboss.seam.international.StatusMessage.Severity;

import com.atosorigin.common.constantes.Constantes;
import com.atosorigin.common.utils.GenericUtils;
import com.atosorigin.confirmaciones.edicion.database.BaseDBAccess;
import com.atosorigin.confirmaciones.edicion.entities.base.ExtendedPDF;
import com.atosorigin.confirmaciones.edicion.tools.ExtendedPDFFactory;
import com.atosorigin.confirmaciones.edicion.tools.ProjectConfig;
import com.atosorigin.confirmaciones.negocio.ResponseFiller;
import com.atosorigin.confirmaciones.servlet.JarServletContextURIResolver;
import com.atosorigin.deri.model.gestionoperaciones.ParamPDFConfirmaciones;
import com.atosorigin.deri.util.ConfiguracionDeri;
import com.atosorigin.deri.util.InterceptExceptions;


@Name("generatePDF")
@InterceptExceptions
public class GeneratePDFAction {

	public GeneratePDFAction() {
		super();
	}

	private static final String PDF_PREFIX = 
		ProjectConfig.getProperty("outFileName");
	private final String SERVLET_PARAM = 
		ProjectConfig.getProperty("servletParam");
	private final String WATERMARK_PARAM = 
		ProjectConfig.getProperty("watermarkParam");
	
	@In(value="#{facesContext.externalContext}")
	private ExternalContext extCtx;

	@In
	private EntityManager entityManager;

	private String codConfi;
	
	@In 
	protected StatusMessages statusMessages;

	@In
	private ConfiguracionDeri configuracionDeri;

	public String getCodConfi() {
		return codConfi;
	}

	public void setCodConfi(String codConfi) {
		this.codConfi = codConfi;
	}

	public String getWatermark() {
		return watermark;
	}

	public void setWatermark(String watermark) {
		this.watermark = watermark;
	}

	private String watermark;
	
	public String generate(){

		HttpServletRequest request= (HttpServletRequest)extCtx.getRequest();
		HttpServletResponse response = (HttpServletResponse)extCtx.getResponse();
		FacesContext facesContext = FacesContext.getCurrentInstance();

		// Read the parameters
		try {
			if (codConfi == null) {
				throw new ServletException("No " + SERVLET_PARAM + " specified");
			}
			long codCondfiLong ;
			try {
				codCondfiLong= Long.parseLong(codConfi);
			} catch (NumberFormatException e) {
				throw new ServletException(SERVLET_PARAM + " is not a number: " + codConfi);
			}

			Boolean barcode = false;
			Boolean indicadorFirmaDigital = false;
			Boolean indicadorViaSegura = false;
			
//			try { 
//				BaseDBAccess db = new BaseDBAccess("VISOR",entityManager);
//				barcode = db.loadIdeDocum(codCondfiLong);
//			} catch (SQLException e) {
//				String error = "...Failed retireving idedocum field from database";
//				System.out.println(error +  e.toString());
//				FacesMessages.instance().add(error + ": " + e.getMessage());
//			}			
//			
			BaseDBAccess db =null;
			try { 
				db = new BaseDBAccess("VISOR",entityManager);
			} catch (Exception e) {
				barcode = false;
				indicadorFirmaDigital  = false;

			}			

			if (!GenericUtils.isNullOrBlank(db)){
				try { 
					barcode = db.activarOsp(codConfi);
				} catch (SQLException e) {
					barcode = false;
				}	
				try { 
					indicadorFirmaDigital = db.indicadorFirmaDigital(codConfi);
				} catch (SQLException e) {
					indicadorFirmaDigital  = false;
				}	
				try { 
					indicadorViaSegura = db.indicadorViaSegura(codConfi);
				} catch (SQLException e) {
					indicadorViaSegura  = false;
				}	
			}
			
			ParamPDFConfirmaciones paramPDF = 
				new ParamPDFConfirmaciones(barcode, indicadorFirmaDigital, indicadorViaSegura);
			
			String water = watermark;
			char watermarkChar = 
				(water!=null && water.length()==1 ? water.charAt(0) : 0);
			
			// add decoration to http stream to trigger download menu
			String pdfName = PDF_PREFIX + codConfi + ".pdf";


			URIResolver uriResolver=null;
			if(facesContext!=null){
				HttpSession session = (HttpSession) facesContext.getExternalContext().getSession(false);
				uriResolver = new JarServletContextURIResolver(session.getServletContext());
			}

			ExtendedPDF extendedPDF = ExtendedPDFFactory.generate(entityManager,codCondfiLong, this, getServletUSerName(), uriResolver, null);
			byte[] pdf = null;
			/* Gravem el pdf en binari dins de la bbdd - mjd 3 juny 2010 */
			try { 
				BaseDBAccess db2 = new BaseDBAccess("VISOR",entityManager);
				pdf = extendedPDF.getPdfByteArray();
				// Añadimos la fecha, marcas de agua y las firmas en blanco	
				pdf = ResponseFiller.getPDFBytes(extendedPDF, watermarkChar, paramPDF);			
				db2.savePDFwithoutUser(pdf, Long.parseLong(codConfi));
				System.out.println("...Codconfi " + codConfi + " saved blob pdf field in database");
			} catch (SQLException e) {
				String error = "...Failed inserting into blob pdf field database";
				System.out.println(error +  e.toString());
				FacesMessages.instance().add(error + ": " + e.getMessage());
			}			
			ResponseFiller.populate(response, pdfName, pdf, watermarkChar,barcode);
			facesContext.responseComplete();

		} catch (Exception e) {
			//throw new RuntimeException(e);
			statusMessages.add(Severity.ERROR, e.getMessage() );
			return Constantes.FAIL;

		} 
		return null;
	}

	private String getServletUSerName() {
		// FIXME: can I get the CAS username for the servlet? 
		return "read-only";
	}

}
