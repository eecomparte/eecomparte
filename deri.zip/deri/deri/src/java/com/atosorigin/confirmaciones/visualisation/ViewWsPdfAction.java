package com.atosorigin.confirmaciones.visualisation;

import java.io.File;
import java.io.FileInputStream;
import java.util.concurrent.atomic.AtomicInteger;

import javax.faces.context.ExternalContext;
import javax.faces.context.FacesContext;
import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.io.FileUtils;
import org.apache.commons.io.IOUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.jboss.seam.annotations.In;
import org.jboss.seam.annotations.Name;
import org.jboss.seam.international.StatusMessages;
import org.jboss.seam.international.StatusMessage.Severity;

import com.atosorigin.common.constantes.Constantes;
import com.atosorigin.deri.util.ConfiguracionDeri;
import com.atosorigin.deri.util.InterceptExceptions;
import com.neoris.ejemploUsoGestorDocumental.Principal;

@Name("viewWsPdfAction")
@InterceptExceptions
public class ViewWsPdfAction {

	private static final AtomicInteger aInteger = new AtomicInteger();

	@In
	private ConfiguracionDeri configuracionDeri;

	private String documentoId;

	@In(value = "#{facesContext.externalContext}")
	private ExternalContext extCtx;

	private Log log = LogFactory.getLog(ViewWsPdfAction.class);

	@In
	protected StatusMessages statusMessages;

	@In(value = "principalDMS", create = true)
	protected Principal principalDMS;

	public ViewWsPdfAction() {
		super();
	}

	public String getDocumentoId() {
		return documentoId;
	}

	public void setDocumentoId(String documentoId) {
		this.documentoId = documentoId;
	}

	public String view() {

		final HttpServletResponse response = (HttpServletResponse) extCtx
				.getResponse();
		final FacesContext facesContext = FacesContext.getCurrentInstance();

		// Read the parameters
		try {

			log.debug("view():: " + documentoId);

			final String fileName = String.format("admconfi-%1$d-%2$d.pdf",
					System.currentTimeMillis(), aInteger.incrementAndGet());

			response.setContentType("application/pdf");
			response.addHeader("Content-disposition", "filename=\"" + fileName
					+ "\"");

			final File pdfFile = principalDMS.obtenerDocumento(fileName, Long
					.parseLong(documentoId), configuracionDeri.getPdfs());

			FileInputStream is = null;
			ServletOutputStream os = null;

			try {
				is = new FileInputStream(pdfFile);
				os = response.getOutputStream();

				IOUtils.copy(is, os);
			} finally {

				IOUtils.closeQuietly(is);
				IOUtils.closeQuietly(os);

				pdfFile.delete();
			}

			facesContext.responseComplete();

		} catch (Exception e) {
			// throw new RuntimeException(e);

			log.error(e);

			statusMessages.add(Severity.ERROR, e.getMessage());

			return Constantes.FAIL;
		}

		return null;
	}
}
