package com.atosorigin.deri.adminoper.boletas.action;

import java.io.Serializable;
import java.lang.reflect.Field;
import java.math.BigDecimal;
import java.math.BigInteger;
import java.text.DateFormat;
import java.text.NumberFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.el.ValueExpression;
import javax.faces.component.UIComponent;
import javax.faces.component.UIViewRoot;
import javax.persistence.EntityManager;
import javax.persistence.EntityNotFoundException;
import javax.persistence.NoResultException;

import org.apache.commons.beanutils.PropertyUtils;
import org.hibernate.annotations.Type;
import org.jasig.cas.client.util.AssertionHolder;
import org.jasig.cas.client.validation.Assertion;
import org.jboss.seam.ScopeType;
import org.jboss.seam.annotations.Factory;
import org.jboss.seam.annotations.In;
import org.jboss.seam.annotations.Logger;
import org.jboss.seam.annotations.Name;
import org.jboss.seam.annotations.Out;
import org.jboss.seam.annotations.Scope;
import org.jboss.seam.annotations.TransactionPropagationType;
import org.jboss.seam.annotations.Transactional;
import org.jboss.seam.annotations.datamodel.DataModel;
import org.jboss.seam.annotations.datamodel.DataModelSelection;
import org.jboss.seam.core.Conversation;
import org.jboss.seam.core.Events;
import org.jboss.seam.core.Expressions;
import org.jboss.seam.core.Init;
import org.jboss.seam.international.Messages;
import org.jboss.seam.international.StatusMessages;
import org.jboss.seam.international.StatusMessage.Severity;
import org.jboss.seam.log.Log;
import org.jboss.seam.security.Identity;

import com.ConstantesFD;
import com.atos.firmaDigital.FirmaDigital;
import com.atos.mifidWS.MifidWS;
import com.atos.validacionFD.ValidacionFD;
import com.atosorigin.common.constantes.Constantes;
import com.atosorigin.common.utils.GenericUtils;
import com.atosorigin.deri.adminoper.boletas.business.BoletasBo;
import com.atosorigin.deri.adminoper.boletas.business.BoletasBusinessException;
import com.atosorigin.deri.adminoper.infoProfit.screen.InfoProfitPantalla;
import com.atosorigin.deri.adminoper.mantoper.business.MantOperBo;
import com.atosorigin.deri.apuntescontables.oficina.business.OficinaBo;
import com.atosorigin.deri.common.dbLock.DbLockService;
import com.atosorigin.deri.common.parametrosPantalla.ParametrosMantdata;
import com.atosorigin.deri.contrapartida.business.ContrapartidaBo;
import com.atosorigin.deri.dao.mercado.DescripcionFormula;
import com.atosorigin.deri.gestionoperaciones.productocompuesto.business.BoletaProdCompuestoBo;
import com.atosorigin.deri.mercado.mantsubyacente.business.SubyacenteBo;
import com.atosorigin.deri.model.adminoper.Autoriza;
import com.atosorigin.deri.model.adminoper.Broker;
import com.atosorigin.deri.model.adminoper.CanalConfDefecto;
import com.atosorigin.deri.model.adminoper.CanalConfDefectoId;
import com.atosorigin.deri.model.adminoper.CanalConfirmacion;
import com.atosorigin.deri.model.adminoper.DatosAdicionales;
import com.atosorigin.deri.model.adminoper.DescripcionClaseInt;
import com.atosorigin.deri.model.adminoper.DescripcionEntidadOperacion;
import com.atosorigin.deri.model.adminoper.DescripcionEstiloOpcion;
import com.atosorigin.deri.model.adminoper.DescripcionModoEjercicio;
import com.atosorigin.deri.model.adminoper.DescripcionOpcionBarrera;
import com.atosorigin.deri.model.adminoper.DescripcionOpcionNivel;
import com.atosorigin.deri.model.adminoper.DescripcionTipoBarreraKnock;
import com.atosorigin.deri.model.adminoper.DescripcionTipoOpcion;
import com.atosorigin.deri.model.adminoper.DescripcionTiposTri;
import com.atosorigin.deri.model.adminoper.DescripcionTradeOnTv;
import com.atosorigin.deri.model.adminoper.DescripcionTranAcum;
import com.atosorigin.deri.model.adminoper.Histdcds;
import com.atosorigin.deri.model.adminoper.HistoricoBarrera;
import com.atosorigin.deri.model.adminoper.HistoricoDatosAdicionales;
import com.atosorigin.deri.model.adminoper.HistoricoDatosAdicionalesId;
import com.atosorigin.deri.model.adminoper.HistoricoOpcion;
import com.atosorigin.deri.model.adminoper.HistoricoSubyacente;
import com.atosorigin.deri.model.adminoper.IndicadorConfirmacion;
import com.atosorigin.deri.model.adminoper.InformacionTexto;
import com.atosorigin.deri.model.adminoper.InformacionTextoId;
import com.atosorigin.deri.model.adminoper.NormaIVParam;
import com.atosorigin.deri.model.adminoper.PlantillasConfirmacion;
import com.atosorigin.deri.model.adminoper.ProductoTgr;
import com.atosorigin.deri.model.adminoper.RelProductoTransaccion;
import com.atosorigin.deri.model.adminoper.VistaMantEje;
import com.atosorigin.deri.model.apuntesContables.Oficina;
import com.atosorigin.deri.model.catalogo.DescripcionSituacion;
import com.atosorigin.deri.model.catalogo.Producto;
import com.atosorigin.deri.model.catalogo.RelProductoAtributo;
import com.atosorigin.deri.model.catalogo.RelProductoDatosAtributo;
import com.atosorigin.deri.model.catalogo.RelProductoDatosAtributoId;
import com.atosorigin.deri.model.common.Descripcion;
import com.atosorigin.deri.model.common.Idioma;
import com.atosorigin.deri.model.contabilidad.GrupoContable;
import com.atosorigin.deri.model.contabilidad.GrupoContableId;
import com.atosorigin.deri.model.contrapartida.AbstractContrapartida;
import com.atosorigin.deri.model.contrapartida.AgrupContrapartida;
import com.atosorigin.deri.model.contrapartida.Contrapartida;
import com.atosorigin.deri.model.contrapartida.UnidadNegocio;
import com.atosorigin.deri.model.contrapartida.UnidadNegocioContrapa;
import com.atosorigin.deri.model.gestionoperaciones.Apoderado;
import com.atosorigin.deri.model.gestionoperaciones.DescripcionAutorizaIndiforza;
import com.atosorigin.deri.model.gestionoperaciones.DescripcionAutorizaIndiserv;
import com.atosorigin.deri.model.gestionoperaciones.DescripcionAutorizaInditipo;
import com.atosorigin.deri.model.gestionoperaciones.DescripcionAutorizaPerfilbs;
import com.atosorigin.deri.model.gestionoperaciones.DescripcionAutorizaTestconv;
import com.atosorigin.deri.model.gestionoperaciones.DescripcionAutorizaTipoCliente;
import com.atosorigin.deri.model.gestionoperaciones.DescripcionAutorizaTipopers;
import com.atosorigin.deri.model.gestionoperaciones.DescripcionCobAp;
import com.atosorigin.deri.model.gestionoperaciones.DescripcionEntidadSibis;
import com.atosorigin.deri.model.gestionoperaciones.DescripcionEstadoOperacion;
import com.atosorigin.deri.model.gestionoperaciones.DescripcionEventoCDS;
import com.atosorigin.deri.model.gestionoperaciones.DescripcionIntercNom;
import com.atosorigin.deri.model.gestionoperaciones.DescripcionTipoCobertura;
import com.atosorigin.deri.model.gestionoperaciones.DescripcionTipoIdentCDS;
import com.atosorigin.deri.model.gestionoperaciones.DescripcionTipoRiesgo;
import com.atosorigin.deri.model.gestionoperaciones.DescripcionTransaccionOperacion;
import com.atosorigin.deri.model.gestionoperaciones.HistoricoFechaFormula;
import com.atosorigin.deri.model.gestionoperaciones.HistoricoFechaFormulaId;
import com.atosorigin.deri.model.gestionoperaciones.HistoricoOperacion;
import com.atosorigin.deri.model.gestionoperaciones.HistoricoOperacionId;
import com.atosorigin.deri.model.gestionoperaciones.Operacion;
import com.atosorigin.deri.model.gestionoperaciones.OperacionId;
import com.atosorigin.deri.model.gestionoperaciones.HistoricoOperacion.Ajustes;
import com.atosorigin.deri.model.gestiontesoreria.BaseCalculo;
import com.atosorigin.deri.model.gestiontesoreria.UnidadNegocioMist;
import com.atosorigin.deri.model.liquidaciones.DescripcionCanalLiquidacion;
import com.atosorigin.deri.model.mercado.DescripcionIndice;
import com.atosorigin.deri.model.mercado.HistoricoIndice;
import com.atosorigin.deri.model.mercado.HistoricoTramos;
import com.atosorigin.deri.model.mercado.IndicesPantalla;
import com.atosorigin.deri.model.mercado.Subyacente;
import com.atosorigin.deri.model.mercado.TipoSubyacente;
import com.atosorigin.deri.model.mercado.TiposPorIndice;
import com.atosorigin.deri.model.mercado.TramosTable;
import com.atosorigin.deri.model.murex.DatosAdicionalesProducto;
import com.atosorigin.deri.model.murex.ProductoCatalogo;
import com.atosorigin.deri.model.murex.RelProductoFormula;
import com.atosorigin.deri.model.parametrizacion.DescripcionEsquemaContables;
import com.atosorigin.deri.model.parametrizacion.Divisa;
import com.atosorigin.deri.util.ConfiguracionDeri;
import com.atosorigin.deri.util.ContrapartidaUtil;
import com.atosorigin.deri.util.EntityUtil;
import com.atosorigin.deri.util.ErrorMessageBoxAction;
import com.atosorigin.deri.util.FechaSistemaComponent;
import com.atosorigin.deri.util.FormatUtil;
import com.atosorigin.deri.util.InterceptExceptions;
import com.atosorigin.deri.util.MessageBoxAction;
import com.atosorigin.deri.util.MsgBoxAction;
import com.bs.proteo.soa.service.mifid.mf7232.svmifidmf7232.domain.message.MIFIDMF7232Response;
import com.bs.proteo.soa.service.teso.valid.validacionfirmante.domain.Fp7005I;
import com.bs.proteo.soa.service.teso.valid.validacionfirmante.domain.message.ExecuteResponse;

/**
 * Clase action listener para el caso de uso de consulta operaciones asociadas
 * en datos de mercado.
 */
@Transactional(TransactionPropagationType.SUPPORTS)
@Name("boletasAction")
@Scope(ScopeType.CONVERSATION)
@InterceptExceptions
public class BoletasAction implements java.io.Serializable {
	private static final BigDecimal ONE_HUNDRED = new BigDecimal(100);
	private static final String TIPO_COBERTURA_IN = "IN";
	private static final String EUR = "EUR";
	private static final String CODIGO_UNIDAD_NEGOCIO_CONTRAPARTIDA = "EEE";
	private static final String CODIGO_UNIDAD_NEGOCIO_SERVIBAN = "SSS";
	private static final String FLU = "FLU";
	private static final String BREAK_CLAUSES = "BC";
	private static Set<String> accesibleEnConsulta = new HashSet<String>();

	static {
		accesibleEnConsulta.add("36022"); // cobrosFx
		accesibleEnConsulta.add("21022"); // pagosfx
		accesibleEnConsulta.add("35022"); // //cobros/PagosFx Simple

		accesibleEnConsulta.add("39022"); // //cobrosFX Commodities
		accesibleEnConsulta.add("40022"); // //PagosFx Commodities

		accesibleEnConsulta.add("23"); // Condiciones Fijacion
		accesibleEnConsulta.add("15"); // F.Ejercicio
		accesibleEnConsulta.add("11"); // barreras
		accesibleEnConsulta.add("34"); // fPayoff
		accesibleEnConsulta.add("16"); // fObserv
		accesibleEnConsulta.add("33"); // fFijStrike
		accesibleEnConsulta.add("25"); // fLiquid
		accesibleEnConsulta.add("17"); // fSelec
		accesibleEnConsulta.add("18"); // fRangos
		accesibleEnConsulta.add("19"); // fWedding
		accesibleEnConsulta.add("42"); // Swaption
	}

	public enum BoletasStates {
		ALTA_BOLETA("A"), MODI_BOLETA("M"), CONSULTA_BOLETA("C"), CONFIRMAR_BOLETA(
				"CB");
		private String codigo;

		private BoletasStates(String codigo) {
			this.codigo = codigo;
		}

		public String getCodigo() {
			return codigo;
		}
	};

	public enum PagoCobroType {
		ES_PAGO("P"), ES_COBRO("R"), PAGO_Y_COBRO("PC"), INDEFINIDO("I");
		private String codigo;

		private PagoCobroType(String codigo) {
			this.codigo = codigo;
		}

		public String getCodigo() {
			return codigo;
		}
	}

	public enum Signo {
		MAS("+"), MENOS("-");
		private String literal;

		Signo(String literal) {
			this.literal = literal;
		}

		public String getLiteral() {
			return literal;
		}

		public void setLiteral(String literal) {
			this.literal = literal;
		}
	}

	/**
	 * SMM NOVEMBRE 2013 - CANVIS EN CAMPS OPCIONS INI
	 */

	private List<CopiaSubyacentes> listaSubyacentes;
	private List<CopiaFechasFormula> listaFechasFormula;

	public class CopiaFechasFormula implements Serializable {

		private Date fechaInicio;
		private Date fechaFin;
		private Short pesobsfe;
		private Date fechaLiquidacion;
		private Date fechaFixing;
		private String tipoInformacionPrecio;
		private BigDecimal rateLiquidacion;
		private String factorLiquidacion;
		private String tipoFecha;

		public CopiaFechasFormula(Date fechaInicio, Date fechaFin,
				Short pesobsfe, Date fechaLiquidacion, Date fechaFixing,
				String tipoInformacionPrecio, BigDecimal rateLiquidacion,
				String factorLiquidacion, String tipoFecha) {
			super();
			this.fechaInicio = fechaInicio;
			this.fechaFin = fechaFin;
			this.pesobsfe = pesobsfe;
			this.fechaLiquidacion = fechaLiquidacion;
			this.fechaFixing = fechaFixing;
			this.tipoInformacionPrecio = tipoInformacionPrecio;
			this.rateLiquidacion = rateLiquidacion;
			this.factorLiquidacion = factorLiquidacion;
			this.tipoFecha = tipoFecha;
		}

		public CopiaFechasFormula(HistoricoFechaFormula fecha) {
			super();
			this.fechaInicio = fecha.getId().getFechaInicio();
			this.fechaFin = fecha.getId().getFechaFin();
			this.pesobsfe = fecha.getPesobsfe();
			this.fechaLiquidacion = fecha.getFechaLiquidacion();
			this.fechaFixing = fecha.getFechaFixing();
			this.tipoInformacionPrecio = fecha.getTipoInformacionPrecio();
			this.rateLiquidacion = fecha.getRateLiquidacion();
			this.factorLiquidacion = fecha.getFactorLiquidacion();
			this.tipoFecha = fecha.getId().getTipoFecha();
		}

		public Date getFechaInicio() {
			return fechaInicio;
		}

		public void setFechaInicio(Date fechaInicio) {
			this.fechaInicio = fechaInicio;
		}

		public Date getFechaFin() {
			return fechaFin;
		}

		public void setFechaFin(Date fechaFin) {
			this.fechaFin = fechaFin;
		}

		public Short getPesobsfe() {
			return pesobsfe;
		}

		public void setPesobsfe(Short pesobsfe) {
			this.pesobsfe = pesobsfe;
		}

		public Date getFechaLiquidacion() {
			return fechaLiquidacion;
		}

		public void setFechaLiquidacion(Date fechaLiquidacion) {
			this.fechaLiquidacion = fechaLiquidacion;
		}

		public Date getFechaFixing() {
			return fechaFixing;
		}

		public void setFechaFixing(Date fechaFixing) {
			this.fechaFixing = fechaFixing;
		}

		public String getTipoInformacionPrecio() {
			return tipoInformacionPrecio;
		}

		public void setTipoInformacionPrecio(String tipoInformacionPrecio) {
			this.tipoInformacionPrecio = tipoInformacionPrecio;
		}

		public BigDecimal getRateLiquidacion() {
			return rateLiquidacion;
		}

		public void setRateLiquidacion(BigDecimal rateLiquidacion) {
			this.rateLiquidacion = rateLiquidacion;
		}

		public String getFactorLiquidacion() {
			return factorLiquidacion;
		}

		public void setFactorLiquidacion(String factorLiquidacion) {
			this.factorLiquidacion = factorLiquidacion;
		}

		public String getTipoFecha() {
			return tipoFecha;
		}

		public void setTipoFecha(String tipoFecha) {
			this.tipoFecha = tipoFecha;
		}

	}

	public class CopiaSubyacentes implements Serializable {
		/**
		 * 
		 */
		private static final long serialVersionUID = -5980558655846836850L;
		private long codindic;
		private String tiposuby;
		private BigDecimal pesoSubyacente;

		public CopiaSubyacentes(long codindic, String tiposuby,
				BigDecimal pesoSubyacente) {
			super();
			this.codindic = codindic;
			this.tiposuby = tiposuby;
			this.pesoSubyacente = pesoSubyacente;
		}

		public CopiaSubyacentes(HistoricoSubyacente subyacente) {
			super();
			this.codindic = subyacente.getId().getCodindic();
			this.tiposuby = subyacente.getId().getTiposuby();
			this.pesoSubyacente = subyacente.getPesoSubyacente();
		}

		public long getCodindic() {
			return codindic;
		}

		public void setCodindic(long codindic) {
			this.codindic = codindic;
		}

		public String getTiposuby() {
			return tiposuby;
		}

		public void setTiposuby(String tiposuby) {
			this.tiposuby = tiposuby;
		}

		public BigDecimal getPesoSubyacente() {
			return pesoSubyacente;
		}

		public void setPesoSubyacente(BigDecimal pesoSubyacente) {
			this.pesoSubyacente = pesoSubyacente;
		}

	}

	public List<CopiaSubyacentes> getListaSubyacentes() {
		return listaSubyacentes;
	}

	public void setListaSubyacentes(List<CopiaSubyacentes> listaSubyacentes) {
		this.listaSubyacentes = listaSubyacentes;
	}

	public List<CopiaFechasFormula> getListaFechasFormula() {
		return listaFechasFormula;
	}

	public void setListaFechasFormula(
			List<CopiaFechasFormula> listaFechasFormula) {
		this.listaFechasFormula = listaFechasFormula;
	}

	/**
	 * SMM NOVEMBRE 2013 - CANVIS EN CAMPS OPCIONS FI
	 */

	public class Bloqueos implements Serializable {
		private Boolean pagos;
		private Boolean cobros;
		private Boolean confirmaciones;
		private Boolean transaccion;
		private Boolean fechaEjercicio;
		private Boolean fechaObserv;
		private Boolean fechaLiq;
		private Boolean fechaSelecc;
		private Boolean fechaRangos;
		private Boolean fechaFijStrike;
		private Boolean fechaWedding;
		private Boolean fechaCondFija;
		private Boolean fechaPayoff;
		private Boolean altaCompleta;
		private Boolean altaIncompleta;
		private Boolean guardar;

		private Boolean importePago;
		private Boolean importeCobro;
		private Boolean tipoIntCobro;
		private Boolean tipoIntPago;
		private Boolean strikeCobro;
		private Boolean strikePago;
		private Boolean sigCobro;
		private Boolean sigPago;
		private Boolean spreadCobro;
		private Boolean spreadPago;
		private Boolean formulaCobro;
		private Boolean formulaPago;
		private Boolean datosOpcion;
		private Boolean formulaOpcion;

		private Boolean cobrosPagosSimple;

		private Boolean modelo2;
		private Boolean modelo3;
		private Boolean modeloRad;
		private Boolean modeloNoRad;

		private Boolean upFrontCobroPago;
		private Boolean periodicaCobroPago;

		private Boolean diasFixingPago;
		private Boolean diasFixingCobro;
		private Boolean frecuenciaFixingPago;
		private Boolean frecuenciaFixingCobro;
		private Boolean fxCobro;
		private Boolean fxPago;
		private Boolean claseCobro = true;
		private Boolean clasePago = true;
		private Boolean rateFactorCobro;
		private Boolean rateFactorPago;

		private Boolean indBSAgent = false;

		private Boolean infoProfit = true;
		private Boolean infTextoKTB = true;

		public Boolean getIndBSAgent() {
			return indBSAgent;
		}

		public void setIndBSAgent(Boolean indBSAgent) {
			this.indBSAgent = indBSAgent;
		}

		public Boolean getDiasFixingPago() {
			return diasFixingPago;
		}

		public void setDiasFixingPago(Boolean diasFixingPago) {
			this.diasFixingPago = diasFixingPago;
		}

		public Boolean getDiasFixingCobro() {
			return diasFixingCobro;
		}

		public void setDiasFixingCobro(Boolean diasFixingCobro) {
			this.diasFixingCobro = diasFixingCobro;
		}

		public Boolean getUpFrontCobroPago() {
			return upFrontCobroPago;
		}

		public void setUpFrontCobroPago(Boolean upFrontCobroPago) {
			this.upFrontCobroPago = upFrontCobroPago;
		}

		public Boolean getPeriodicaCobroPago() {
			return periodicaCobroPago;
		}

		public void setPeriodicaCobroPago(Boolean periodicaCobroPago) {
			this.periodicaCobroPago = periodicaCobroPago;
		}

		public Boolean getFechaPayoff() {
			return fechaPayoff;
		}

		public void setFechaPayoff(Boolean fechaPayoff) {
			this.fechaPayoff = fechaPayoff;
		}

		public Boolean getModeloRad() {
			return modeloRad;
		}

		public void setModeloRad(Boolean modeloRad) {
			this.modeloRad = modeloRad;
		}

		public Boolean getModeloNoRad() {
			return modeloNoRad;
		}

		public void setModeloNoRad(Boolean modeloNoRad) {
			this.modeloNoRad = modeloNoRad;
		}

		public Boolean getModelo2() {
			return modelo2;
		}

		public void setModelo2(Boolean modelo2) {
			this.modelo2 = modelo2;
		}

		public Boolean getModelo3() {
			return modelo3;
		}

		public void setModelo3(Boolean modelo3) {
			this.modelo3 = modelo3;
		}

		public Boolean getStrikeCobro() {
			return strikeCobro;
		}

		public void setStrikeCobro(Boolean strikeCobro) {
			this.strikeCobro = strikeCobro;
		}

		public Boolean getStrikePago() {
			return strikePago;
		}

		public void setStrikePago(Boolean strikePago) {
			this.strikePago = strikePago;
		}

		public Boolean getCobrosPagosSimple() {
			return cobrosPagosSimple;
		}

		public void setCobrosPagosSimple(Boolean cobrosPagosSimple) {
			this.cobrosPagosSimple = cobrosPagosSimple;
		}

		public Boolean getDatosOpcion() {
			return datosOpcion;
		}

		public void setDatosOpcion(Boolean datosOpcion) {
			this.datosOpcion = datosOpcion;
		}

		public Boolean getImportePago() {
			return importePago;
		}

		public void setImportePago(Boolean importePago) {
			this.importePago = importePago;
		}

		public Boolean getImporteCobro() {
			return importeCobro;
		}

		public void setImporteCobro(Boolean importeCobro) {
			this.importeCobro = importeCobro;
		}

		public Boolean getTipoIntCobro() {
			return tipoIntCobro;
		}

		public void setTipoIntCobro(Boolean tipoIntCobro) {
			this.tipoIntCobro = tipoIntCobro;
		}

		public Boolean getTipoIntPago() {
			return tipoIntPago;
		}

		public void setTipoIntPago(Boolean tipoIntPago) {
			this.tipoIntPago = tipoIntPago;
		}

		public Boolean getSigCobro() {
			return sigCobro;
		}

		public void setSigCobro(Boolean sigCobro) {
			this.sigCobro = sigCobro;
		}

		public Boolean getSigPago() {
			return sigPago;
		}

		public void setSigPago(Boolean sigPago) {
			this.sigPago = sigPago;
		}

		public Boolean getSpreadCobro() {
			return spreadCobro;
		}

		public void setSpreadCobro(Boolean spreadCobro) {
			this.spreadCobro = spreadCobro;
		}

		public Boolean getSpreadPago() {
			return spreadPago;
		}

		public void setSpreadPago(Boolean spreadPago) {
			this.spreadPago = spreadPago;
		}

		public Boolean getFormulaCobro() {
			return formulaCobro;
		}

		public void setFormulaCobro(Boolean formulaCobro) {
			this.formulaCobro = formulaCobro;
		}

		public Boolean getFormulaPago() {
			return formulaPago;
		}

		public void setFormulaPago(Boolean formulaPago) {
			this.formulaPago = formulaPago;
		}

		public Boolean getFxCobro() {
			return fxCobro;
		}

		public void setFxCobro(Boolean fxCobro) {
			this.fxCobro = fxCobro;
		}

		public Boolean getFxPago() {
			return fxPago;
		}

		public void setFxPago(Boolean fxPago) {
			this.fxPago = fxPago;
		}

		public Boolean getAltaCompleta() {
			return altaCompleta;
		}

		public void setAltaCompleta(Boolean altaCompleta) {
			this.altaCompleta = altaCompleta;
		}

		public Boolean getTransaccion() {
			return transaccion;
		}

		public void setTransaccion(Boolean transaccion) {
			this.transaccion = transaccion;
		}

		public Boolean getConfirmaciones() {
			return confirmaciones;
		}

		public void setConfirmaciones(Boolean confirmaciones) {
			this.confirmaciones = confirmaciones;
		}

		public Boolean getClaseCobro() {
			return claseCobro;
		}

		public void setClaseCobro(Boolean claseCobro) {
			this.claseCobro = claseCobro;
		}

		public Boolean getClasePago() {
			return clasePago;
		}

		public void setClasePago(Boolean clasePago) {
			this.clasePago = clasePago;
		}

		public Boolean getPagos() {
			return pagos;
		}

		public void setPagos(Boolean pagos) {
			this.pagos = pagos;

		}

		public Boolean getCobros() {
			return cobros;
		}

		public void setCobros(Boolean cobros) {
			this.cobros = cobros;
		}

		public Bloqueos(Boolean pagos, Boolean cobros) {
			super();
			this.pagos = pagos;
			this.cobros = cobros;
		}

		public Boolean getFechaEjercicio() {
			return fechaEjercicio;
		}

		public void setFechaEjercicio(Boolean fechaEjercicio) {
			this.fechaEjercicio = fechaEjercicio;
		}

		public Boolean getFechaObserv() {
			return fechaObserv;
		}

		public void setFechaObserv(Boolean fechaObserv) {
			this.fechaObserv = fechaObserv;
		}

		public Boolean getFechaLiq() {
			return fechaLiq;
		}

		public void setFechaLiq(Boolean fechaLiq) {
			this.fechaLiq = fechaLiq;
		}

		public Boolean getFechaSelecc() {
			return fechaSelecc;
		}

		public void setFechaSelecc(Boolean fechaSelecc) {
			this.fechaSelecc = fechaSelecc;
		}

		public Boolean getFechaRangos() {
			return fechaRangos;
		}

		public void setFechaRangos(Boolean fechaRangos) {
			this.fechaRangos = fechaRangos;
		}

		public Boolean getFechaFijStrike() {
			return fechaFijStrike;
		}

		public void setFechaFijStrike(Boolean fechaFijStrike) {
			this.fechaFijStrike = fechaFijStrike;
		}

		public Boolean getFechaWedding() {
			return fechaWedding;
		}

		public void setFechaWedding(Boolean fechaWedding) {
			this.fechaWedding = fechaWedding;
		}

		public Boolean getFechaCondFija() {
			return fechaCondFija;
		}

		public void setFechaCondFija(Boolean fechaCondFija) {
			this.fechaCondFija = fechaCondFija;
		}

		public Boolean getAltaIncompleta() {
			return altaIncompleta;
		}

		public void setAltaIncompleta(Boolean altaIncompleta) {
			this.altaIncompleta = altaIncompleta;
		}

		public Boolean getGuardar() {
			return guardar;
		}

		public void setGuardar(Boolean guardar) {
			this.guardar = guardar;
		}

		public Boolean getFormulaOpcion() {
			return formulaOpcion;
		}

		public void setFormulaOpcion(Boolean formulaOpcion) {
			this.formulaOpcion = formulaOpcion;
		}

		public Boolean getFrecuenciaFixingPago() {
			return frecuenciaFixingPago;
		}

		public void setFrecuenciaFixingPago(Boolean frecuenciaFixingPago) {
			this.frecuenciaFixingPago = frecuenciaFixingPago;
		}

		public Boolean getFrecuenciaFixingCobro() {
			return frecuenciaFixingCobro;
		}

		public void setFrecuenciaFixingCobro(Boolean frecuenciaFixingCobro) {
			this.frecuenciaFixingCobro = frecuenciaFixingCobro;
		}

		public Boolean getRateFactorCobro() {
			return rateFactorCobro;
		}

		public void setRateFactorCobro(Boolean rateFactorCobro) {
			this.rateFactorCobro = rateFactorCobro;
		}

		public Boolean getRateFactorPago() {
			return rateFactorPago;
		}

		public void setRateFactorPago(Boolean rateFactorPago) {
			this.rateFactorPago = rateFactorPago;
		}

		public Boolean getInfoProfit() {
			return infoProfit;
		}

		public void setInfoProfit(Boolean infoProfit) {
			this.infoProfit = infoProfit;
		}

		public Boolean getInfTextoKTB() {
			return infTextoKTB;
		}

		public void setInfTextoKTB(Boolean infTextoKTB) {
			this.infTextoKTB = infTextoKTB;
		}

	}

	private Boolean primeraEjecucionInit = null;
	private String ModoActuacion; // FLM: I Incompleta, A Alta, M Guardar

	// Variables para las validaciones de alta completa
	boolean retDadesValides = true;
	boolean retDadesAmbWarnings = false;
	String retWarnings = "";

	@Out(required = false)
	private PagosCobrosB pagosCobrosB;
	@In
	protected StatusMessages statusMessages;

	@In("EntityUtil")
	private EntityUtil entityUtil;

	@In
	private EntityManager entityManager;
	@Logger
	private Log log;

	@In("#{boletasBo}")
	protected BoletasBo boletasBo;

	@In("#{mantOperBo}")
	private MantOperBo mantOperBo;

	@In(value = "dbLockService", create = true)
	private DbLockService dbLockService;

	@In("#{contrapartidaBo}")
	private ContrapartidaBo contrapartidaBo;

	@In("#{oficinaBo}")
	private OficinaBo oficinaBo;

	@In("#{subyacenteBo}")
	private SubyacenteBo subyacenteBo;

	@In(value = "#{boletaProdCompuestoBo}")
	protected BoletaProdCompuestoBo boletaProdCompuestoBo;

	@In(required = true)
	private BoletasStates boletaState;

	@In
	private ConfiguracionDeri configuracionDeri;

	@Out(value = "origenPantalla")
	private String origen = "OP";

	// FLM: Ojo, para Wedding, existe un caso en que se le pasa estado consulta
	// y no el actual
	@Out(required = false)
	private BoletasStates boletaStateWedd;

	@Out(value = "parametrosMantData", required = false)
	private ParametrosMantdata parametrosMantdata = new ParametrosMantdata();

	@In
	private FormatUtil formatUtil;

	@In(required = false)
	@Out(required = false, scope = ScopeType.SESSION)
	private String sessionId = "";

	private String proxyGrantingTicket = getTicket();

	@In(value = "firmaDigital", create = true)
	protected FirmaDigital firmaDigital;

	private static final Pattern idPattern = Pattern
			.compile("[a-zA-Z][a-zA-Z0-9]*__([0-9]*)__");
	private static final Pattern attributePattern = Pattern
			.compile("([0-9]*)([0-9][0-9][0-9])");

	@In
	HistoricoOperacion historicoOperacion;
	@In(required = false)
	HistoricoOperacionId historicoOperacionBloqueadoId;

	private Map<Short, Set<RelProductoAtributo>> relProductoAtributoMap = null;

	/**
	 * Tipo por indice seleccionado en la pantalla de mantenimiento de datos de
	 * mercado
	 */
	@In(required = false)
	protected TiposPorIndice tipoIndiceSelec;

	private List<DescripcionClaseInt> descripcionClaseInts;

	@Out(required = false)
	private Bloqueos panelesBloqueados;

	// Para el popup de Unidades de Negocio Mist
	@Out(required = false)
	private ListOfValuesAction<UnidadNegocioMist> unidadNegocioMistAction;

	@Out(required = false)
	private DatosOpcionDelegate datosOpcionDelegate;

	@DataModel
	private List<UnidadNegocioMist> listaUnidadNegocioMist;

	@DataModelSelection("listaUnidadNegocioMist")
	private UnidadNegocioMist selectedUnidadNegocioMist;

	@In(required = false)
	private String filtroMist;
	// FIN: Para el popup de Unidades de Negocio Mist

	// Para el popup de Subyacentes (atributo 35)
	@Out(required = false)
	private ListOfValuesAction<Subyacente> suyacentePopupAction;

	// Para el popup de Subyacentes de la pestana CDS
	@Out(required = false)
	private ListOfValuesAction<Subyacente> subyacPopupAction;

	// Para el popup de Subyacentes de los comodities
	@Out(required = false)
	private ListOfValuesAction<Subyacente> subyacenteReciboPopupAction;
	@Out(required = false)
	private ListOfValuesAction<Subyacente> subyacentePagoPopupAction;

	@Out(required = false)
	private ListOfValuesAction<AbstractContrapartida> contrapartidasPopupAction;

	@Out(required = false)
	private ListOfValuesAction<Oficina> oficinasPopupAction;

	@Out(required = false)
	private ListOfValuesAction<Oficina> oficinasEntPopupAction;

	@Out(required = false)
	private PropertyWrapper<Short> codigoOficinaMargen;

	@Out(required = false)
	private ContrapartidasDelegate contrapaDelegate;

	@Out(required = false)
	private IndicadorConfirmacionDelegate indicadorConfirmacion;

	@Out(required = false)
	private Autoriza autorizaOperacion;

	@Out(required = false)
	private Histdcds histdcds;

	@DataModel("listaPopupSubyacentes")
	private List<Subyacente> listaPopupSubyacentes;

	@DataModelSelection("listaPopupSubyacentes")
	private Subyacente selectedSubyacente;

	@DataModel("listaPopupSubyacenCds")
	private List<Subyacente> listaPopupSubyacenCds;

	@DataModelSelection("listaPopupSubyacenCds")
	private Subyacente selectedSubyacenteCds;

	@DataModel("listaPopupSubyReciboCom")
	private List<Subyacente> listaPopupSubyReciboCom;

	@DataModelSelection("listaPopupSubyReciboCom")
	private Subyacente selectedSubyReciboCom;
	
	@DataModel("listaPopupSubyPagoCom")
	private List<Subyacente> listaPopupSubyPagoCom;

	@DataModelSelection("listaPopupSubyPagoCom")
	private Subyacente selectedSubyPagoCom;
	
	
	@DataModel("listaPopupContrapartidas")
	private List<AbstractContrapartida> listaPopupContrapartidas;

	@DataModel("listaPopupOficinas")
	private List<Oficina> listaPopupOficinas;

	@DataModelSelection("listaPopupOficinas")
	private Oficina selectedOficina;

	@DataModel("listaPopupOficinasEnt")
	private List<Oficina> listaPopupOficinasEnt;

	@DataModelSelection("listaPopupOficinasEnt")
	private Oficina selectedOficinaEnt;

	// DATOS ADICIONALES TEST
	@DataModel("listaDtDatosAdicionales")
	private List<HistoricoDatosAdicionales> listaDatosAdicionales;

	@DataModelSelection("listaDtDatosAdicionales")
	private HistoricoDatosAdicionales selectedDatoAdicional;

	// DATOS ADICIONALES TEST

	@In(required = false)
	private String filtroContrapartidasCodigo;
	@In(required = false)
	private String filtroContrapartidas;

	@In(required = false)
	private String filtroSubyacente;

	@In(required = false)
	private String filtroOficinas;

	// FIN: Para el popup de Unidades de Negocio Mist

	@Out(required = false)
	private TramosTableComponent tramosTableComponent;

	@Out(required = false)
	List<IndicesPantalla> indicesFxCobroList;

	@Out(required = false)
	List<IndicesPantalla> indicesFxPagoList;

	private boolean irManttram = false;

	@In(value = "fechaSistemaComponent", create = true)
	private FechaSistemaComponent fechaSistemaComponent;

	@In(required = false)
	private Date fechaSistema;

	@Out(required = false)
	private PagoCobroType pagoCobroType;

	@Out(required = false)
	private InformacionTexto informacionTexto;

	@Out(required = false)
	private InfoProfitPantalla infoProfitPantalla;

	@Out(required = false)
	private List<TipoSubyacente> listaTipoSubyacenteProducat;

	@Out(required = false)
	private List<DescripcionTranAcum> listaTranAcum;

	@In(value = "mifidWS", create = true)
	protected MifidWS mifidWS;

	@In(value = "validacionFD", create = true)
	protected ValidacionFD validacionFD;

	@In
	private ErrorMessageBoxAction errorMessageBoxAction;

	@In(required = false)
	private String forcedReturnView;

	@In
	private ContrapartidaUtil contrapartidaUtil;

	private Boolean enableBreakClauses = false;

	@Type(type = "SNNull")
	private Boolean checkBreakClauses = false;

	/** Inyección del objeto para la union con MANTPROD */
	@In(required = false)
	@Out(required = false)
	String varModif;

	private DescripcionClaseInt tipoClaseVariable;
	private DescripcionClaseInt tipoClaseFijo;
	private DescripcionClaseInt tipoClaseCupon;

	private Signo signoCobro;
	private Signo signoPago;

	private Boolean esPrimaImplicita;

	private Boolean esPrimaCancelacion;
	private Integer codigoFormulaActual;

	// SMM 04/10/2017
	private DescripcionAutorizaInditipo finalidadOperacion;

	private BigDecimal datosGestionImporteTotal;
	private PropertyWrapper<DescripcionFormula> formulaRecibo;
	private PropertyWrapper<DescripcionFormula> formulaPago;
	private PropertyWrapper<DescripcionFormula> formulaB;
	private PropertyWrapper<DescripcionFormula> formulaDatosOpcion;
	// private PropertyWrapper<DescripcionTransaccionOperacion> transaccion;
	private PropertyWrapper<DescripcionEstiloOpcion> estiloOpcion;
	private PropertyWrapper<DescripcionTipoOpcion> tipoOpcion;
	private PropertyWrapper<DescripcionOpcionBarrera> modobarrera;

	// guardamos el valor inicial del indFlooring para mostrar los avisos en el
	// caso de q cambie su valor
	private Boolean indFlooracionInicial;

	public PropertyWrapper<DescripcionOpcionBarrera> getModobarrera() {
		return modobarrera;
	}

	public void setModobarrera(
			PropertyWrapper<DescripcionOpcionBarrera> modobarrera) {
		this.modobarrera = modobarrera;
	}

	public PropertyWrapper<DescripcionTipoOpcion> getTipoOpcion() {
		return tipoOpcion;
	}

	public void setTipoOpcion(PropertyWrapper<DescripcionTipoOpcion> tipoOpcion) {
		this.tipoOpcion = tipoOpcion;
	}

	private String selectedTab;

	public String getSelectedTab() {
		return selectedTab;
	}

	public void setSelectedTab(String selectedTab) {
		this.selectedTab = selectedTab;
	}

	@Out(required = false, scope = ScopeType.EVENT)
	private String primasRerenderList;

	// public PropertyWrapper<DescripcionTransaccionOperacion> getTransaccion()
	// {
	// checkTransaccion();
	// return transaccion;
	// }

	// private void checkTransaccion() {
	// if (transaccion == null && historicoOperacion != null) {
	// transaccion = new
	// PropertyWrapper<DescripcionTransaccionOperacion>(historicoOperacion,
	// "transaccion") {
	// };
	// } else {
	// transaccion.setDelegate(historicoOperacion) ;
	// }
	// }

	// public void
	// setTransaccion(PropertyWrapper<DescripcionTransaccionOperacion>
	// transaccion) {
	// this.transaccion = transaccion;
	// }

	@Out(required = false, value = "boletasMessageBoxAction")
	private MessageBoxAction messageBoxAction;

	@Out(required = false, value = "boletas2MessageBoxAction")
	private MessageBoxAction messageBoxAction2;

	@In(create = true)
	MsgBoxAction msgBoxAction;

	@Out(value = "modoTratamiento", required = false)
	protected String modoTratamientoAnexo; // A alta, E edicion C Consulta
	@Out(required = false)
	protected String tipoAnexo;

	@Out(required = false, value = "boletasContrapaMessageBoxAction")
	private MessageBoxAction messageBoxBoletasAction;

	private GrupoContable grupoContableXX;
	private AbstractContrapartida contrapartidaModelo;

	private Boolean forceValidation;
	private HashMap<String, Object> valoresIniciales;
	private HashMap<String, Object> valoresInicialesOpciones;
	private IndicadorConfirmacion confirmacion;

	private boolean tradeInformado;
	private String preutiOld;
	private Date fechaCorteEmir;
	private Boolean infoProfitActivado;

	public PropertyWrapper<DescripcionFormula> getFormulaRecibo() {
		return formulaRecibo;
	}

	public void setFormulaRecibo(
			PropertyWrapper<DescripcionFormula> formulaRecibo) {
		this.formulaRecibo = formulaRecibo;
	}

	public PropertyWrapper<DescripcionFormula> getFormulaPago() {
		return formulaPago;
	}

	public void setFormulaPago(PropertyWrapper<DescripcionFormula> formulaPago) {
		this.formulaPago = formulaPago;
	}

	public BigDecimal getDatosGestionImporteTotal() {
		return datosGestionImporteTotal;
	}

	public void setDatosGestionImporteTotal(BigDecimal datosGestionImporteTotal) {
		this.datosGestionImporteTotal = datosGestionImporteTotal;
	}

	public Boolean getEsPrimaCancelacion() {
		return esPrimaCancelacion;
	}

	public void setEsPrimaCancelacion(Boolean esPrimaCancelacion) {
		this.esPrimaCancelacion = esPrimaCancelacion;
	}

	public Boolean getEsPrimaImplicita() {
		return esPrimaImplicita;
	}

	public void setEsPrimaImplicita(Boolean esPrimaImplicita) {
		this.esPrimaImplicita = esPrimaImplicita;
	}

	public Signo getSignoPago() {
		return signoPago;
	}

	public PropertyWrapper<DescripcionFormula> getFormulaB() {
		return formulaB;
	}

	public void setFormulaB(PropertyWrapper<DescripcionFormula> formulaB) {
		this.formulaB = formulaB;
	}

	public PropertyWrapper<DescripcionFormula> getFormulaDatosOpcion() {
		return formulaDatosOpcion;
	}

	public void setFormulaDatosOpcion(
			PropertyWrapper<DescripcionFormula> formulaDatosOpcion) {
		this.formulaDatosOpcion = formulaDatosOpcion;
	}

	public boolean esPagoTipoB() {
		RelProductoTransaccion currentRelProductoTransaccion = getRelProductoTransaccion();
		return currentRelProductoTransaccion != null
				&& "FLU".equals(currentRelProductoTransaccion.getTppapago());
	}

	public boolean esCobroTipoB() {
		RelProductoTransaccion currentRelProductoTransaccion = getRelProductoTransaccion();
		return currentRelProductoTransaccion != null
				&& "FLU".equals(currentRelProductoTransaccion.getTppareci());
	}

	public Boolean esDatosOpcionCobro() {
		RelProductoTransaccion currentRelProductoTransaccion = getRelProductoTransaccion();
		return currentRelProductoTransaccion != null
				&& "OPC".equals(currentRelProductoTransaccion.getTppareci());
	}

	public Boolean esDatosOpcionPago() {
		RelProductoTransaccion currentRelProductoTransaccion = getRelProductoTransaccion();
		return currentRelProductoTransaccion != null
				&& "OPC".equals(currentRelProductoTransaccion.getTppapago());
	}

	public void setSignoPago(Signo signoPago) {
		this.signoPago = signoPago;
	}

	public Signo getSignoCobro() {
		return signoCobro;
	}

	public void setSignoCobro(Signo signoCobro) {
		this.signoCobro = signoCobro;
	}

	@Factory("signos")
	public Signo[] getSignos() {
		return Signo.values();
	}

	private void checkProductoAtributoMap() {
		checkProductoAtributoMap(false);
	}

	private void checkProductoAtributoMap(Boolean forced) {
		if (relProductoAtributoMap == null || forced) {
			// Boolean hadAttribute23 = false;
			// if (forced && relProductoAtributoMap != null &&
			// relProductoAtributoMap.containsKey(new Integer(23).shortValue()))
			// {
			// hadAttribute23 = true;
			// }
			Integer codigoFormulaPago = 0;
			Integer codigoFormulaCobro = 0;
			if (historicoOperacion.getFormulaPago() != null)
				codigoFormulaPago = historicoOperacion.getFormulaPago()
						.getCodigoFormula(); // getCodigoFormulaPago();
			if (historicoOperacion.getFormulaRecibo() != null)
				codigoFormulaCobro = historicoOperacion.getFormulaRecibo()
						.getCodigoFormula(); // getCodigoFormulaCobro();

			Map<Short, Set<RelProductoAtributo>> tmpProductoAtributoMap = getAtributeMap(
					codigoFormulaPago, codigoFormulaCobro);
			relProductoAtributoMap = new HashMap<Short, Set<RelProductoAtributo>>();
			relProductoAtributoMap.putAll(tmpProductoAtributoMap);

			// if (hadAttribute23 && !tmpProductoAtributoMap.containsKey(new
			// Integer(23).shortValue())) {
			// messageBoxAction.init("boletas.messageBox.cambio.formula",
			// "boletasAction.onMessageBoxOk()",
			// "boletasAction.onMessageBoxKo()");
			// } else {
			// relProductoAtributoMap = new HashMap<Short,
			// Set<RelProductoAtributo>>();
			// relProductoAtributoMap.putAll(tmpProductoAtributoMap);
			// if (formulaPago != null) {
			// formulaPago.setChanged(false);
			// }
			// if (formulaRecibo != null) {
			// formulaRecibo.setChanged(false);
			// }
			// if (formulaB != null) {
			// formulaB.setChanged(false);
			// }
			// if (formulaDatosOpcion != null) {
			// formulaDatosOpcion.setChanged(false);
			// }
			// }
		}
	}

	private Integer getCodigoFormulaPago() {

		Integer codigoFormulaPago = 0; // Si no está seleccionado es 0 por
										// defecto
		if (pagoCobroType == PagoCobroType.ES_COBRO)
			return codigoFormulaPago;
		if (formulaPago != null && formulaPago.getValue() != null) {
			codigoFormulaPago = formulaPago.getValue().getCodigoFormula();
			return codigoFormulaPago;
		}
		// Que viene de historicoOperacion.getPagoCobroType()
		if (formulaB != null && formulaB.getValue() != null) {
			// indiferente uno u otro
			codigoFormulaPago = formulaB.getValue().getCodigoFormula();
			return codigoFormulaPago;
		}
		if (formulaDatosOpcion != null && formulaDatosOpcion.getValue() != null) {
			codigoFormulaPago = formulaDatosOpcion.getValue()
					.getCodigoFormula();
			return codigoFormulaPago;
		}

		return codigoFormulaPago;
	}

	private Integer getCodigoFormulaCobro() {
		Integer codigoFormulaCobro = 0;
		if (pagoCobroType == PagoCobroType.ES_PAGO)
			return codigoFormulaCobro;

		if (formulaRecibo != null && formulaRecibo.getValue() != null) {
			codigoFormulaCobro = formulaRecibo.getValue().getCodigoFormula();
			return codigoFormulaCobro;
		}
		// Que viene de historicoOperacion.getPagoCobroType()
		if (formulaB != null && formulaB.getValue() != null) {
			// indiferente uno u otro
			codigoFormulaCobro = formulaB.getValue().getCodigoFormula();
			return codigoFormulaCobro;
		}
		if (formulaDatosOpcion != null && formulaDatosOpcion.getValue() != null) {
			// indiferente uno u otro
			codigoFormulaCobro = formulaDatosOpcion.getValue()
					.getCodigoFormula();
			return codigoFormulaCobro;
		}
		return codigoFormulaCobro;
	}

	private boolean hasFormulaCobroOPagoChanged() {
		if (formulaRecibo != null && formulaRecibo.getChanged())
			return true;
		if (formulaPago != null && formulaPago.getChanged())
			return true;
		if (this.formulaB != null && this.formulaB.getChanged())
			return true;
		if (this.formulaDatosOpcion != null
				&& this.formulaDatosOpcion.getChanged())
			return true;
		return false;
	}

	private Map<Short, Set<RelProductoAtributo>> getAtributeMap(
			Integer codigoFormulaPago, Integer codigoFormulaCobro) {
		List<RelProductoAtributo> result = boletasBo.getProductoAtributos(
				historicoOperacion.getProductoCatalogo(), codigoFormulaPago,
				codigoFormulaCobro);
		Map<Short, Set<RelProductoAtributo>> tmpProductoAtributoMap = new HashMap<Short, Set<RelProductoAtributo>>();
		for (RelProductoAtributo relProductoAtributo : result) {
			putAtributo(tmpProductoAtributoMap, relProductoAtributo);
		}
		return tmpProductoAtributoMap;
	}

	private void putAtributo(Map<Short, Set<RelProductoAtributo>> atributoMap,
			RelProductoAtributo relProductoAtributo) {

		short codigoAtributo = relProductoAtributo.getId().getCodigoAtributo();

		Set<RelProductoAtributo> atributos = new HashSet<RelProductoAtributo>(3);

		if (!atributoMap.containsKey(codigoAtributo)) {
			atributoMap.put(codigoAtributo, atributos);
		} else {
			atributos = atributoMap.get(codigoAtributo);
		}
		atributos.add(relProductoAtributo);
	}

	// FLM: Esta función es sólo para cuando tenemos dos patas y queremos saber
	// que pata activa el atributo 23
	// retornamos un Map, pero, sólo con saber si existe o no tenemos suficiente
	private Map<Short, Set<RelProductoAtributo>> getAtributeMapById(
			Short codigoAtributo, Integer codigoFormula) {
		List<RelProductoAtributo> result = boletasBo.getProductoAtributosById(
				codigoAtributo, historicoOperacion.getProductoCatalogo(),
				codigoFormula);
		Map<Short, Set<RelProductoAtributo>> tmpProductoAtributoMap = new HashMap<Short, Set<RelProductoAtributo>>();
		for (RelProductoAtributo relProductoAtributo : result) {
			putAtributo(tmpProductoAtributoMap, relProductoAtributo);
		}
		return tmpProductoAtributoMap;
	}

	public Boolean hasDatosMist() {
		return hasAttribute(1);
	}

	public Boolean hasDatosInflacion() {
		return hasProductoTgr(51);
	}
	
	public Boolean hasDatosKondor() {
		return hasAttribute(2);
	}

	public Boolean hasDatosMurex() {
		return hasAttribute(3);
	}

	public Boolean hasDatosContables() {
		return hasAttribute(4);
	}

	public Boolean hasDatosOpcionTab() {
		return hasAttribute(24);
	}

	public Boolean hasPrimasTab() {
		return hasAttribute(6) || hasAttribute(7) || hasAttribute(8);
	}

	public Boolean hasBarrerasTab() {
		return hasAttribute(32);
	}

	public Boolean hasContrapartidasTab() {
		return hasAttribute(30);
	}

	public Boolean hasComisionesTab() {
		return hasAttribute(31);
	}

	public Boolean hasDatosGestionTab() {
		return hasAttribute(5);
	}

	public Boolean hasConfirmacionesTab() {
		// return false;
		// TODO
		return hasAttribute(27);
	}

	public Boolean hasRegulatorioTab() {
		return true;// hasAttribute(36);
	}

	public Boolean hasAttribute(int attributeNum) {
		// FLM: Por si acaso, pero no debiera pasar nunca puesto que lo hacemos
		// en el Init
		if (relProductoAtributoMap == null) {
			// La primera vez tomamos el codigo de formula 0
			Map<Short, Set<RelProductoAtributo>> tmpProductoAtributoMap = getAtributeMap(
					new Integer(0), new Integer(0));
			relProductoAtributoMap = new HashMap<Short, Set<RelProductoAtributo>>();
			relProductoAtributoMap.putAll(tmpProductoAtributoMap);
		} else {
			checkProductoAtributoMap();
		}
		return relProductoAtributoMap.containsKey(new Integer(attributeNum)
				.shortValue());
	}

	// FLM: Función para saber si un campo es o no obligatorio
	public Boolean hasAttributeAndIsObligated(int attributeNum) {
		checkProductoAtributoMap();
		if (relProductoAtributoMap.containsKey(new Integer(attributeNum)
				.shortValue())) {
			String obligado = "";
			try {
				Set<RelProductoAtributo> set = relProductoAtributoMap
						.get(new Integer(attributeNum).shortValue());
				for (RelProductoAtributo relProductoAtributo : set) {
					if ("S".equalsIgnoreCase(relProductoAtributo
							.getIndicadorAtributo())) {
						return true;
					}
				}
			} catch (Exception e) {
				;
			}
			return false;
		} else
			return false;
	}

	public Boolean hasProductoTgr(int prodTgr){
		
		if (!GenericUtils.isNullOrBlank(historicoOperacion) && !GenericUtils.isNullOrBlank(historicoOperacion.getProductoTgr())
				&& historicoOperacion.getProductoTgr().equals(prodTgr)){
			return true;	
		}
		return false;
	}
	
	public Boolean hasDatosCobrosTab() {
		return hasAttribute(21) || hasAttribute(22) || hasAttribute(36)
				|| hasAttribute(37);

	}

	public Boolean hasSimpleDatosCobrosTab() {
		checkProductoAtributoMap();
		return hasAttribute(35) || hasAttribute(38);
	}

	public Boolean hasCommoditiesDatosCobrosTab() {
		checkProductoAtributoMap();
		return hasAttribute(39);
	}

	public Boolean hasMifidTab() {
		return hasAttribute(20) && esContrapaCliente();
	}

	public Boolean hasDatosCDS() {
		return hasAttribute(9);
	}

	public Boolean hasSibis() {
		return hasAttribute(26);
	}

	public interface UIComponentVisitor {
		public boolean visit(UIComponent uiComponent);
	}

	public boolean visit(UIComponent uiComponent, UIComponentVisitor visitor) {
		for (UIComponent child : uiComponent.getChildren()) {
			if (visit(child, visitor)) {
				return true;
			}
		}
		return visitor.visit(uiComponent);
	}

	public boolean configureComponent(UIComponent uiComponent) {
		String id = uiComponent.getId();
		if (id != null) {
			Matcher matcher = idPattern.matcher(id);
			if (matcher.matches()) {
				id = matcher.group(1);
				Object disabledAttr = uiComponent.getAttributes().get(
						"disabled");
				// valor de desabilitado a partir de la tabla de atributos
				Boolean disabled = isDisabled(id);
				// Comprobamos si tiene una expresion disabled en el tag. Si
				// esta evalua a true,
				// deshabilitamos aunque en la tabla de atributos diga que no
				if (!disabled) {
					ValueExpression tagDisabledExpression = uiComponent
							.getValueExpression("disabled");
					if (tagDisabledExpression != null) {
						org.jboss.seam.core.Expressions.ValueExpression<Boolean> tmp = Expressions
								.instance().createValueExpression(
										tagDisabledExpression
												.getExpressionString(),
										Boolean.class);
						if (tmp.getValue()) {
							disabled = true;
						}
					}
				}
				uiComponent.getAttributes().put("disabled", disabled);
				// }

				// FLM: Hablado con Nati.
				// Si esta deshabilitado no es obligatorio nunca.
				// primero se aplica siempre la regla general y despues se
				// aplican las excepciones en la funcion
				// dadesvalides
				if (disabled)
					uiComponent.getAttributes().put("required", false);
				else
					uiComponent.getAttributes().put("required", isRequired(id));
				return true;
			}
		}
		return false;

	}

	public void onCompleteContrapartida() {
		String a = "";
		return;
	}

	public void init() {
		// historicoOperacion = (HistoricoOperacion)
		// Contexts.getConversationContext().get("historicoOperacion");
		// boletasBo=(BoletasBo)
		// Contexts.getConversationContext().get("boletasBo");
		// //FLM: Evitar la reentrada por el init, Ojo los ajax ejecutan esto
		// cada vez
		boolean primera = false;
		if (primeraEjecucionInit == null) {
			primera = true;
			primeraEjecucionInit = true;
			checkSignoSpread();
		} else {
			primeraEjecucionInit = false;
		}

		// FLM: Siempre debemos tener paneles bloqueado inicializada. Creamos
		// únicamente la variable
		// se habilita en su sitio de check correspondiente
		if (getPanelesBloqueados() == null) {
			panelesBloqueados = new Bloqueos(true, true);
		}

		// FLM: esto solo lo podemos hacer despues de tener inicializadas las
		// formulas
		if (primera)
			checkProductoAtributoMap(true);
		else
			checkProductoAtributoMap();

		// FLM: Esto se tiene que hacer siempre y al principio de todo, o al
		// menos cada vez que se modifiquen las formulas
		// La primera vez se carga todo con formula 0
		// FLM: Esto se tiene que hacer siempre y al principio de todo, o al
		// menos cada vez que se modifiquen las formulas
		// if( hasFormulaCobroOPagoChanged()){
		// }

		// Operacion operacion = historicoOperacion.getOperacion();
		// if (operacion==null)
		// log.error("Sin historico operación no puede funcionar el init, conversacion cerrada?")
		// ;

		Date dateInit = new Date();
		checkGrupoContable();
		if (codigoFormulaActual == null) {
			codigoFormulaActual = 0;
		}
		String eventType = "com.atosorigin.seam.jsf.viewBuilt."
				+ Conversation.instance().getId();
		if (compruebaNuevoListener(eventType)) {
			Events.instance().addListener(eventType,
					"#{boletasAction.onCreateView}", UIViewRoot.class);
		}
		initClaseInts();
		if (unidadNegocioMistAction == null) {
			unidadNegocioMistAction = new ListOfValuesAction<UnidadNegocioMist>(
					"listaUnidadNegocioMist", "filtroMist", "unidnego",
					"descunid", "boletasAction.onUnidadNegocioSelect()") {
				@Override
				protected void refrescaDataModel() {
					listaUnidadNegocioMist = null;
				}

				@Override
				public void setDataTableList(List<?> dataTableList) {
					listaUnidadNegocioMist = (List<UnidadNegocioMist>) dataTableList;
				}
			};
			unidadNegocioMistAction.setInitialized(true);
		}
		if (suyacentePopupAction == null) {
			// filtroSubyacente = "";
			suyacentePopupAction = new ListOfValuesAction<Subyacente>(
					"listaPopupSubyacentes", "filtroSubyacente", "codigo",
					"descripcionLarga", "boletasAction.onSubyacenteSelect()") {
				@Override
				protected void refrescaDataModel() {
					listaPopupSubyacentes = null;
				}

				@Override
				public void setDataTableList(List<?> dataTableList) {
					listaPopupSubyacentes = (List<Subyacente>) dataTableList;
				}
			};
			suyacentePopupAction.setInitialized(true);
		}

		if (subyacPopupAction == null) {
			subyacPopupAction = new ListOfValuesAction<Subyacente>(
					"listaPopupSubyacenCds", "filtroSubyacente", "codigo",
					"descripcionLarga", "boletasAction.onSubyacCdsSelect()") {
				@Override
				protected void refrescaDataModel() {
					listaPopupSubyacenCds = null;
				}

				@Override
				public void setDataTableList(List<?> dataTableList) {
					listaPopupSubyacenCds = (List<Subyacente>) dataTableList;
				}
			};
			subyacPopupAction.setInitialized(true);
		}

		if (subyacenteReciboPopupAction == null) {
			// filtroSubyacente = "";
			subyacenteReciboPopupAction = new ListOfValuesAction<Subyacente>(
					"listaPopupSubyReciboCom", "filtroSubyacente", "codigo",
					"descripcionLarga",
					"boletasAction.onSubyacenteReciboSelect()") {
				@Override
				protected void refrescaDataModel() {
					listaPopupSubyReciboCom = null;
				}

				@Override
				public void setDataTableList(List<?> dataTableList) {
					listaPopupSubyReciboCom = (List<Subyacente>) dataTableList;
				}
			};
			subyacenteReciboPopupAction.setInitialized(true);
		}

		if (subyacentePagoPopupAction == null) {
			// filtroSubyacente = "";
			subyacentePagoPopupAction = new ListOfValuesAction<Subyacente>(
					"listaPopupSubyPagoCom", "filtroSubyacente", "codigo",
					"descripcionLarga",
					"boletasAction.onSubyacentePagoSelect()") {
				@Override
				protected void refrescaDataModel() {
					listaPopupSubyPagoCom = null;
				}

				@Override
				public void setDataTableList(List<?> dataTableList) {
					listaPopupSubyPagoCom = (List<Subyacente>) dataTableList;
				}
			};
			subyacentePagoPopupAction.setInitialized(true);
		}

		if (contrapartidasPopupAction == null) {
			contrapartidasPopupAction = new ListOfValuesAction<AbstractContrapartida>(
					"listaPopupContrapartidas", "filtroContrapartidasCodigo",
					"filtroContrapartidas", "id", "descCorta",
					"boletasAction.onContrapartidasLookupSelect()") {
				@Override
				protected void refrescaDataModel() {
					listaPopupContrapartidas = null;
				}

				@Override
				public void setDataTableList(List<?> dataTableList) {
					listaPopupContrapartidas = (List<AbstractContrapartida>) dataTableList;
				}

				@Override
				public void setOnSelectAction(String onSelectAction) {
					listaPopupContrapartidas = null;
					setVisible(true);
					super.setOnSelectAction(onSelectAction);
				}
			};
			contrapartidasPopupAction.setInitialized(true);
		}
		if (oficinasPopupAction == null) {
			oficinasPopupAction = new ListOfValuesAction<Oficina>(
					"listaPopupOficinas", "filtroOficinas", "codigo", "nombre",
					"boletasAction.onOficinasLookupSelect()") {
				@Override
				protected void refrescaDataModel() {
					listaPopupOficinas = null;
				}

				@Override
				public void setDataTableList(List<?> dataTableList) {
					listaPopupOficinas = (List<Oficina>) dataTableList;
				}
			};
			oficinasPopupAction.setInitialized(true);
		}

		if (oficinasEntPopupAction == null) {
			oficinasEntPopupAction = new ListOfValuesAction<Oficina>(
					"listaPopupOficinasEnt", "filtroOficinas", "codigo",
					"nombre",
					"boletasAction.onOficinaBlurDatosContablesSelect()") {
				@Override
				protected void refrescaDataModel() {
					listaPopupOficinasEnt = null;
				}

				@Override
				public void setDataTableList(List<?> dataTableList) {
					listaPopupOficinasEnt = (List<Oficina>) dataTableList;
				}
			};
			oficinasEntPopupAction.setInitialized(true);
		}

		if (boletaState == BoletasStates.ALTA_BOLETA) {
			if (hasDatosOpcionTab()
					&& historicoOperacion.getHistoricoOpcion() == null) {
				HistoricoOpcion historicoOpcion = new HistoricoOpcion(
						historicoOperacion.getId());
				historicoOperacion.setHistoricoOpcion(historicoOpcion);
			}
			if (hasDatosCDS() && historicoOperacion.getHistdcds() == null) {
				histdcds = new Histdcds(historicoOperacion.getId());
				historicoOperacion.setHistdcds(histdcds);
			}
		}
		if (hasContrapartidasTab() && contrapaDelegate == null) {
			contrapaDelegate = new ContrapartidasDelegate(historicoOperacion);
		}
		contrapaDelegate.setDelegate(historicoOperacion);
		if (hasMifidTab()) {
			OperacionId id = new OperacionId(historicoOperacion.getId()
					.getFechaContratacion(), historicoOperacion.getId()
					.getNumeroOperacion());
			if (autorizaOperacion == null) { // Este valor lo tenemos que buscar
												// siempre de bbdd, y si no lo
												// tiene lo creamos !!!
				autorizaOperacion = entityManager.find(Autoriza.class, id);
				if (autorizaOperacion != null) {
					entityManager.refresh(autorizaOperacion);
				}

			}
			if (autorizaOperacion == null) {
				autorizaOperacion = new Autoriza(id);
			}
		}
		if (hasDatosCDS() && histdcds == null) {
			histdcds = historicoOperacion.getHistdcds();
		}
		checkConfirmaciones();
		// SMM 1690 Proteger campo BsAgent en caso de contrapartida FDI o
		// MODELO.
		// SMM incidencia 1897 O bien Grupo Contable XX
		if ((historicoOperacion.getContrapartida() != null && ("FDI"
				.equalsIgnoreCase(historicoOperacion.getContrapartida().getId()) || "MODELO"
				.equalsIgnoreCase(historicoOperacion.getContrapartida().getId())))
				|| (historicoOperacion.getGrupoContable() != null && "XX"
						.equalsIgnoreCase(historicoOperacion.getGrupoContable()
								.getId().getGrupoContable()))) {
			historicoOperacion.setIndicadorBSAgente(false);
			panelesBloqueados.setIndBSAgent(true);
			if (hasConfirmacionesTab()) {
				setBloqueoConfirmaciones(true);
				if (indicadorConfirmacion != null)
					resetConfirmaciones();
			}
		}

		if (codigoOficinaMargen == null) {
			codigoOficinaMargen = new PropertyWrapper<Short>(
					historicoOperacion, "oficinaMargen.codigo") {
			};
		} else {
			codigoOficinaMargen.setDelegate(historicoOperacion);
		}

		try {
			if (euroDivisa == null) {
				euroDivisa = entityManager.find(Divisa.class, EUR);
			}
		} catch (Exception e) {
			// FLM: Esto ha fallado en pre, pero no es posible que euro no este
			// en pre
			log.error(e);
		}

		if (formulaPago == null) {
			formulaPago = new PropertyWrapper<DescripcionFormula>(
					historicoOperacion, "formulaPago") {
			};// historicoOperacion.getFormulaPago();
		} else {
			formulaPago.setDelegate(historicoOperacion);
		}
		if (formulaRecibo == null) {
			formulaRecibo = new PropertyWrapper<DescripcionFormula>(
					historicoOperacion, "formulaRecibo") {
			};
		} else {
			formulaRecibo.setDelegate(historicoOperacion);
		}
		// Cargamos los productos y sus grupos contables por defecto
		if (primera) {
			listaGrupoContable = null;
			initListaProducto();
		}

		checkBloqueoPaneles();
		checkTipoCobroPago();
		// el bloqueo de primas depende del tipo pago/cobro
		checkBloqueosPrimas();

		// despues del calculo de paneles podemos instanciar los delegates que
		// dependen de pago/cobro
		if (hasDatosCobrosTab() && primera) {
			initListaFormulas();
			initRateFactor();
		}
		if (hasDatosOpcionTab()) {
			PagoCobroType datosOpcionCobroPagoType = getDatosOpcionCobroPagoType();
			if (datosOpcionDelegate == null) {
				datosOpcionDelegate = new DatosOpcionDelegate(
						historicoOperacion, datosOpcionCobroPagoType);
			} else {
				datosOpcionDelegate.setHistoricoOperacion(historicoOperacion);
				datosOpcionDelegate.setPagoCobroType(datosOpcionCobroPagoType);
			}
			// FLM: esto no se tendria que hacer siempre?
			if (datosOpcionCobroPagoType == PagoCobroType.ES_COBRO) {
				if (historicoOperacion.getHistoricoOpcion() != null) {
					historicoOperacion.getHistoricoOpcion().setTipoOperacion(
							"R");
				}
				historicoOperacion.setIndicadorTipoRecibo(tipoClaseVariable);
				// 1934

				if (historicoOperacion.getHistoricoOpcion() != null
						&& historicoOperacion.getHistoricoOpcion()
								.getStrikeOpcion() != null) {

					historicoOperacion.setStrikeRecibo(historicoOperacion
							.getHistoricoOpcion().getStrikeOpcion());
				}

			} else {
				if (datosOpcionCobroPagoType == PagoCobroType.ES_PAGO) {
					if (historicoOperacion.getHistoricoOpcion() != null) {
						historicoOperacion.getHistoricoOpcion()
								.setTipoOperacion("P");
					}
					historicoOperacion.setIndicadorTipoPago(tipoClaseVariable);

					// 1934

					if (historicoOperacion.getHistoricoOpcion() != null
							&& historicoOperacion.getHistoricoOpcion()
									.getStrikeOpcion() != null) {
						historicoOperacion.setStrikePago(historicoOperacion
								.getHistoricoOpcion().getStrikeOpcion());
					}

				} else {
					if (historicoOperacion.getHistoricoOpcion() != null) {
						historicoOperacion.getHistoricoOpcion()
								.setTipoOperacion("");
					}
				}
			}
			//

			if (formulaDatosOpcion == null) {
				formulaDatosOpcion = new PropertyWrapper<DescripcionFormula>(
						datosOpcionDelegate, "formula") {
				};
				initListaDatosOpcionFormulas();
			} else {
				formulaDatosOpcion.setDelegate(datosOpcionDelegate);
			}
			if (estiloOpcion == null) {
				estiloOpcion = new PropertyWrapper<DescripcionEstiloOpcion>(
						historicoOperacion.getHistoricoOpcion(), "estiloOpcion") {
				};
			} else {
				estiloOpcion.setDelegate(historicoOperacion
						.getHistoricoOpcion());
			}

			if (modobarrera == null) {
				modobarrera = new PropertyWrapper<DescripcionOpcionBarrera>(
						historicoOperacion.getHistoricoOpcion(), "modobarr") {
				};
			} else {
				modobarrera
						.setDelegate(historicoOperacion.getHistoricoOpcion());
			}

			if (tipoOpcion == null) {
				tipoOpcion = new PropertyWrapper<DescripcionTipoOpcion>(
						historicoOperacion.getHistoricoOpcion(), "tipoOpcion") {
				};
			} else {
				tipoOpcion.setDelegate(historicoOperacion.getHistoricoOpcion());
			}
			if (selectedTab == null) {
				selectedTab = "datosOpcionTab";
			}

			// INCIDENCIA 1721
			// Comprobacion incial Strike Promedio y F. Fij. Strike:
			// if (isRequired(Short.parseShort("24"),Short.parseShort("20"))){
			// historicoOperacion.getHistoricoOpcion().setIndstrpr(true);
			// panelesBloqueados.setFechaFijStrike(false);
			//				
			// }else if
			// (!isDisabled(Short.parseShort("24"),Integer.parseInt("20"))){
			// panelesBloqueados.setFechaFijStrike(false);
			// }else{
			// panelesBloqueados.setFechaFijStrike(true);
			// historicoOperacion.getHistoricoOpcion().setIndstrpr(false);
			// //borrar fechas
			//				
			// }

			// volvemos a calcular los bloqueos de datosOpcion.
			checkBloqueoDatosOpcion();
		}
		if (hasAttribute(35) || hasAttribute(38)) {
			if (pagosCobrosB == null) {
				pagosCobrosB = new PagosCobrosB(this);
				pagosCobrosB.setPagoCobroType(pagoCobroType);
			} else {
				pagosCobrosB.setHistoricoOperacion(historicoOperacion);
				pagosCobrosB.setPagoCobroType(pagoCobroType);
			}
			if (formulaB == null) {
				formulaB = new PropertyWrapper<DescripcionFormula>(
						pagosCobrosB, "formula") {
				};
				initListaFormulas();

			} else {
				formulaB.setDelegate(pagosCobrosB);
				formulaB.refresh();
			}
		}
		if (messageBoxAction == null) {
			messageBoxAction = new MessageBoxAction();
		}

		if (indicesFxPagoList == null && indicesFxCobroList != null) {
			indicesFxPagoList = new ArrayList<IndicesPantalla>();
		}
		if (indicesFxCobroList == null && indicesFxPagoList != null) {
			indicesFxCobroList = new ArrayList<IndicesPantalla>();
		}
		if (indicesFxPagoList == null && indicesFxCobroList == null) {
			indicesFxPagoList = new ArrayList<IndicesPantalla>();
			indicesFxCobroList = new ArrayList<IndicesPantalla>();
			initIndicesPantalla();
		}

		if (primera) {
			initListaTipoSubyacenteProducat();
		}

		if (primera) {
			botonesAltaCompleta();
			// AGM: recalcular margen en modificación
			recalcularMargenTotal();
			botonProfit();
		}

		// Habilitar botón break clauses o no
		if (primera) {
			if (existenFechasFormulaBC()) {
				checkBreakClauses = true;
				enableBreakClauses = checkBreakClauses;
			}
		}

		// FLM: Ponemos los valores por defecto de modelos, sólo cuando entramos
		if (primera)
			initModelo();

		preparaCheckBoxesPrimasEnModificacionOConsulta(primera);

		checkBloqueoConfirmaciones(primera);

		// SMM DERI113 Activar BSabadell y Confirmaciones según contrapartida
		if (primera
				&& boletaState != BoletasStates.CONSULTA_BOLETA
				&& (confirmacion == null || boletasBo
						.esNuloIndconal(confirmacion.getId()))
				&& historicoOperacion.getContrapartida() != null
				&& !"FDI".equalsIgnoreCase(historicoOperacion
						.getContrapartida().getId())
				&& !"MODELO".equalsIgnoreCase(historicoOperacion
						.getContrapartida().getId())
				&& (historicoOperacion.getGrupoContable() == null || (historicoOperacion
						.getGrupoContable() != null && !"XX"
						.equalsIgnoreCase(historicoOperacion.getGrupoContable()
								.getId().getGrupoContable())))
				&& (historicoOperacion.getCodigoCobertura() == null || (historicoOperacion
						.getCodigoCobertura() != null && !"IN"
						.equalsIgnoreCase(historicoOperacion
								.getCodigoCobertura().getCodigo())))) {
			if (getTipoContr().equalsIgnoreCase("C")) {
				// Clientes. marcar check BS Agent, y en la pestaña de
				// Confirmaciones, los checks enviar, y desmarcar los de
				// recibir.
				historicoOperacion.setIndicadorBSAgente(true);
				onBSAgentChange();
			} else {
				// desmarcar check BS Agent, desmarcar los checks de enviar
				// (confirmaciones) y marcar los de recibir.
				historicoOperacion.setIndicadorBSAgente(false);
				onBSAgentChange();
			}
		}

		// FLM:995 el nominal = 0 es equivalente a null
		fijarNominales0();
		// inicializamos los valores que se comparan en el calendario después de
		// haber inicializado todos los valores posibles
		if (boletaState != BoletasStates.CONSULTA_BOLETA
				&& valoresIniciales == null) {
			valoresIniciales = new HashMap<String, Object>();
			obtenerValoresIniciales();
		}

		if (boletaState != BoletasStates.CONSULTA_BOLETA
				&& valoresInicialesOpciones == null) {
			valoresInicialesOpciones = new HashMap<String, Object>();
			obtenerValoresInicialesOpciones();
		}

		if (primera) {
			if (!GenericUtils.isNullOrBlank(historicoOperacion.getTradeId())) {
				tradeInformado = true;
			} else {
				tradeInformado = false;
				preutiOld = historicoOperacion.getInternalTradeId();
			}
			// fechaCorteEmir = boletasBo.recuperarFechaEmir();

		}

		//SMM  Swaps Inflacion 19/12/2018
		if (primera && hasDatosInflacion() && boletaState != BoletasStates.CONSULTA_BOLETA){
			if (!GenericUtils.isNullOrBlank(historicoOperacion.getIsinBonoInflac()) && GenericUtils.isNullOrBlank(historicoOperacion.getTipoFijoBono())){
				BigDecimal tipoBonofij = boletasBo.getObtenerTipoFijoBono(historicoOperacion.getIsinBonoInflac());
				if (!GenericUtils.isNullOrBlank(tipoBonofij)){
					historicoOperacion.setTipoFijoBono(tipoBonofij);
				}else{
					statusMessages.add(Severity.WARN,
					"#{messages['boletas.messages.inflacion.sinporcentaje']");

//					messageBoxBoletasAction = new MessageBoxAction();
//					messageBoxBoletasAction.init(
//							"boletas.messages.inflacion.sinporcentaje",
//							"boletasAction.voidFunction()", null,
//							"messageBoxPanelContrapa");
				}
			}
		
		}
		//SMM  Swaps Inflacion 19/12/2018 Fi
		
		
		// guardamos el valor de indFlooreado al entrar
		if (primera &&
		// boletaState == BoletasStates.MODI_BOLETA)
				boletaState != BoletasStates.CONSULTA_BOLETA)
			indFlooracionInicial = historicoOperacion.getIndFlooreado();

		if (log.isDebugEnabled())
			log.debug("BoletasAction.init() Tiempo {0}", (new Date()).getTime()
					- dateInit.getTime());
		if (hasConfirmacionesTab()) {
			errorMessageBoxAction
					.setReRender("operacionesForm,breadBoleta,confirmacionesContenidoPanel");
		} else {
			errorMessageBoxAction.setReRender("operacionesForm,breadBoleta");
		}
		errorMessageBoxAction
				.setOnComplete("try{doForceBloqueos();setMessageActive(false);}catch(e){alert(e);}");

		if (null == messageBoxAction2)
			messageBoxAction2 = new MessageBoxAction();

		if (primeraEjecucionInit) {
			if (null != historicoOperacion
					&& historicoOperacion.getContrapartida() instanceof Contrapartida) {
				Contrapartida contrapartida = (Contrapartida) historicoOperacion
						.getContrapartida();
				if (null != contrapartida
						&& !GenericUtils.isNullOrBlank(contrapartida
								.getIndBloqueo())
						&& "S".equalsIgnoreCase(contrapartida.getIndBloqueo())) {
					messageBoxBoletasAction = new MessageBoxAction();
					messageBoxBoletasAction.init(
							"boletas.messages.contrapartida.bloqueada.texto",
							"boletasAction.voidFunction()", null,
							"messageBoxPanelContrapa");
				}
			}
		}

		if (primeraEjecucionInit
				&& boletaState != BoletasStates.CONSULTA_BOLETA
				&& historicoOperacion.getUltimaAccion() != null
				&& "A".equalsIgnoreCase(historicoOperacion.getUltimaAccion()
						.getCodigo())
				&& historicoOperacion.getEstado() != null
				&& "IN".equalsIgnoreCase(historicoOperacion.getEstado()
						.getCodigo())) {

			calculoNormaIV();
		}

		if (primera	&& boletaState != BoletasStates.CONSULTA_BOLETA
				&& hasCommoditiesDatosCobrosTab()) {
			inicializarCommodities();
		}

	}

	public Integer esPagoCobroCommodity(){
		 if
		 ("COM".equalsIgnoreCase(historicoOperacion.getTransaccion().getCodigo())){
					return 1;
		 }else if
		 ("VEN".equalsIgnoreCase(historicoOperacion.getTransaccion().getCodigo())){
			 return 2;
		 }
		 return 0;
	}
	
	private void inicializarCommodities() {

//		try {
//			if (GenericUtils.isNullOrBlank(historicoOperacion.getIndicePago().getCodigo())) {
//
//			}
//		
//		} catch (EntityNotFoundException ex) {
//			historicoOperacion.setIndicePago(null);
//		} catch (Exception e) {
//			historicoOperacion.setIndicePago(null);
//		}
//
//		try {
//			if (GenericUtils.isNullOrBlank(historicoOperacion.getIndiceRecibo().getCodigo())) {
//
//			}
//		} catch (Exception e) {
//			historicoOperacion.setIndiceRecibo(null);
//		}
		
		// //Compra --> Cobro
		 if
		 ("COM".equalsIgnoreCase(historicoOperacion.getTransaccion().getCodigo())){
					
		 historicoOperacion.setIndicadorTipoRecibo(tipoClaseVariable);
		 historicoOperacion.setIndicadorTipoPago(tipoClaseFijo);
					
		 }else if
		 ("VEN".equalsIgnoreCase(historicoOperacion.getTransaccion().getCodigo())){
					
		 historicoOperacion.setIndicadorTipoRecibo(tipoClaseFijo);
		 historicoOperacion.setIndicadorTipoPago(tipoClaseVariable);
					
					
		 }
	}

	public void voidFunction() {
		msgBoxAction.voidFunction();
	}

	private void botonProfit() {
		// //COnectar al DBLINK para ver si existe el registro.
		if (GenericUtils.isNullOrBlank(historicoOperacion.getClaveExternaBDU())) {
			panelesBloqueados.setInfoProfit(true);
			panelesBloqueados.setInfTextoKTB(true);
		} else {
			if (!boletasBo.obtenerBotonProfit()) {

				panelesBloqueados.setInfoProfit(true);
			} else {
				if (boletasBo.comprobarExociticidad(historicoOperacion
						.getClaveExternaBDU(), configuracionDeri
						.getTablaProfit())) {
					panelesBloqueados.setInfoProfit(false);
				} else {
					panelesBloqueados.setInfoProfit(true);
				}
			

			if (boletasBo.comprobarInfoTextKTB(historicoOperacion
					.getClaveExternaBDU(), configuracionDeri.getTablaProfit())) {
				panelesBloqueados.setInfTextoKTB(false);
			} else {
				panelesBloqueados.setInfTextoKTB(true);
			}

			}
		}
		// if (GenericUtils.isNullOrBlank(infoProfitActivado)){
		// infoProfitActivado = boletasBo.obtenerBotonProfit();
		// }
		// panelesBloqueados.setInfoProfit(!infoProfitActivado);
	}

	
	
	public void onIsinInflacChange(){
		
		if (!GenericUtils.isNullOrBlank(historicoOperacion.getIsinBonoInflac())){
			
			BigDecimal tipoBono = boletasBo.getObtenerTipoFijoBono(historicoOperacion.getIsinBonoInflac());
			
			if (!GenericUtils.isNullOrBlank(tipoBono)){
				
				historicoOperacion.setTipoFijoBono(tipoBono);
				
			}else{
//				historicoOperacion.setTipoFijoBono(BigDecimal.ZERO);
				statusMessages.add(Severity.WARN,
				"#{messages['boletas.edicion.tipo.noEncontrado']");
		
//				statusMessages.addToControl("unidadNegocio__1001__", Severity.WARN,
//						"#{messages['boletas.edicion.tipo.noEncontrado']");
			}
		}
	}
	
	private boolean existenFechasFormulaBC() {
		Iterator it = historicoOperacion.getHistoricoFechasFormulas()
				.iterator();
		while (it.hasNext()) {
			HistoricoFechaFormula actual = (HistoricoFechaFormula) it.next();
			if (actual.getId().getTipoFecha().equals(BREAK_CLAUSES))
				return true;
		}
		return false;
	}

	private void initClaseInts() {
		if (descripcionClaseInts == null) {
			descripcionClaseInts = boletasBo.getDescripcionClaseInt();
		}
		for (DescripcionClaseInt descripcionClaseInt : descripcionClaseInts) {
			if ("F".equals(descripcionClaseInt.getCodigo())) {
				tipoClaseFijo = descripcionClaseInt;
			}
			if ("V".equals(descripcionClaseInt.getCodigo())) {
				tipoClaseVariable = descripcionClaseInt;
			}
			if ("C".equals(descripcionClaseInt.getCodigo())) {
				tipoClaseCupon = descripcionClaseInt;
			}

		}
	}

	public Boolean getPrimeraEjecucionInit() {
		return primeraEjecucionInit;
	}

	public void setPrimeraEjecucionInit(Boolean primeraEjecucionInit) {
		this.primeraEjecucionInit = primeraEjecucionInit;
	}

	private void initListaFormulas() {
		if (pagoCobroType == PagoCobroType.ES_COBRO) {
			initListaFormulaCobro();
		}
		if (pagoCobroType == PagoCobroType.ES_PAGO) {
			initListaFormulaPago();
		}
	}

	private void initRateFactor() {
		if (pagoCobroType == PagoCobroType.ES_COBRO
				&& historicoOperacion.getRateFactorRecibo() == null
				&& tipoClaseVariable.equals(historicoOperacion
						.getIndicadorTipoRecibo()) && !isDisabled("43001")) {
			historicoOperacion.setRateFactorRecibo(new BigDecimal(1));
		}
		if (pagoCobroType == PagoCobroType.ES_PAGO
				&& historicoOperacion.getRateFactorPago() == null
				&& tipoClaseVariable.equals(historicoOperacion
						.getIndicadorTipoPago()) && !isDisabled("43001")) {
			historicoOperacion.setRateFactorPago(new BigDecimal(1));
		}

		if (pagoCobroType == PagoCobroType.PAGO_Y_COBRO) {

			if (historicoOperacion.getRateFactorPago() == null
					&& tipoClaseVariable.equals(historicoOperacion
							.getIndicadorTipoPago()) && !isDisabled("43001")) {
				historicoOperacion.setRateFactorPago(new BigDecimal(1));
			}

			if (historicoOperacion.getRateFactorRecibo() == null
					&& tipoClaseVariable.equals(historicoOperacion
							.getIndicadorTipoRecibo()) && !isDisabled("43001")) {
				historicoOperacion.setRateFactorRecibo(new BigDecimal(1));
			}

		}

	}

	private void fijarNominales0() {
		if (historicoOperacion.getNominalPago() != null
				&& historicoOperacion.getNominalPago().compareTo(
						new BigDecimal(0)) == 0)
			historicoOperacion.setNominalPago(null);
		if (historicoOperacion.getNominalRecibo() != null
				&& historicoOperacion.getNominalRecibo().compareTo(
						new BigDecimal(0)) == 0)
			historicoOperacion.setNominalRecibo(null);
	}

	private void preparaCheckBoxesPrimasEnModificacionOConsulta(boolean primera) {
		if (primera && hasPrimasTab()
				&& boletaState != BoletasStates.ALTA_BOLETA) {
			onPrimasImplicitaFieldBlur();
			onPrimasCancelacionFieldBlur();
		}
	}

	private void botonesAltaCompleta() {
		// TODO Auto-generated method stub
		// modoactua
		// A: si deri.histeri.indsitua = ‘A’ y (deri.histderi.estadoco= ‘IN’ o
		// ‘PV’)
		// M: si deri.histderi.estadoco = ‘VA’ o deri.histderi.indsitua = ‘M’
		//  C: si varaccion = ‘C’

		if (BoletasStates.CONSULTA_BOLETA.equals(this.boletaState)) {
			panelesBloqueados.setAltaIncompleta(true);
			panelesBloqueados.setGuardar(true);
			panelesBloqueados.setAltaCompleta(true);
		} else {
			if ("A".equalsIgnoreCase(historicoOperacion.getUltimaAccion()
					.getCodigo())
					&& "IN".equals(historicoOperacion.getEstado().getCodigo())) {
				panelesBloqueados.setAltaIncompleta(false);
			} else {
				panelesBloqueados.setAltaIncompleta(true);
			}

			if (esModoActuaAlta()) {
				panelesBloqueados.setAltaCompleta(false);
			} else {
				panelesBloqueados.setAltaCompleta(true);
			}

			if (esModoActuaModi()) {
				panelesBloqueados.setGuardar(false);
			} else {
				panelesBloqueados.setGuardar(true);
			}
		}

	}

	private boolean esModoActuaModi() {
		return "M".equalsIgnoreCase(historicoOperacion.getUltimaAccion()
				.getCodigo())
				|| "VA".equals(historicoOperacion.getEstado().getCodigo());
	}

	private boolean esModoActuaAlta() {
		return "A".equalsIgnoreCase(historicoOperacion.getUltimaAccion()
				.getCodigo())
				&& ("IN".equals(historicoOperacion.getEstado().getCodigo()) || "PV"
						.equals(historicoOperacion.getEstado().getCodigo()));
	}

	private void checkSignoSpread() {
		if (historicoOperacion.getSpreadPago() != null
				&& historicoOperacion.getSpreadPago().signum() == -1) {
			signoPago = Signo.MENOS;
			historicoOperacion.setSpreadPago(historicoOperacion.getSpreadPago()
					.negate());
		} else {
			signoPago = Signo.MAS;
		}
		if (historicoOperacion.getSpreadRecibo() != null
				&& historicoOperacion.getSpreadRecibo().signum() == -1) {
			signoCobro = Signo.MENOS;
			historicoOperacion.setSpreadRecibo(historicoOperacion
					.getSpreadRecibo().negate());
		} else {
			signoCobro = Signo.MAS;
		}
	}

	public void clearMessages() {

	}

	private void initIndicesPantalla() {

		indicesFxPagoList.clear();
		indicesFxCobroList.clear();

		List<DescripcionIndice> tiposIndice = new ArrayList<DescripcionIndice>();
		if (historicoOperacion.getFormulaPago() != null) {
			tiposIndice.addAll(boletasBo.getDescIndice(historicoOperacion
					.getFormulaPago().getCodigoFormula()));

			for (int i = 0; i < tiposIndice.size(); i++) {

				IndicesPantalla h = new IndicesPantalla();

				h.setLiteralIndice(tiposIndice.get(i).getId()
						.getLiteralIndice());
				h.setTipoValorIndice(null);
				h.setCodigoSubyacente(null);
				h.setTipoFechaInicio(tiposIndice.get(i).getTipoFechaInicio());
				h.setTipoFechaFin(tiposIndice.get(i).getTipoFechaFin());

				indicesFxPagoList.add(h);
			}
			if (!GenericUtils.isNullOrBlank(historicoOperacion.getIndicePago())) {
				if (!(indicesFxPagoList == null
						|| indicesFxPagoList.size() == 0 || indicesFxPagoList
						.isEmpty())) {
					// FLM, en alta incompleta puede que esta campo no este
					// informado
					if (historicoOperacion.getIndicePago() != null
							&& entityUtil.checkEntityExists(historicoOperacion
									.getIndicePago())) {
						indicesFxPagoList.get(0).setCodigoSubyacente(
								historicoOperacion.getIndicePago().getCodigo());
						indicesFxPagoList.get(0).setDescripcionCorta(
								historicoOperacion.getIndicePago()
										.getDescripcionCorta());
						if (historicoOperacion.getIndicePago()
								.getDescripcionLarga() != null)
							indicesFxPagoList.get(0).setDescripcionLarga(
									historicoOperacion.getIndicePago()
											.getDescripcionLarga());
					}
				}
			}
		}
		if (historicoOperacion.getFormulaRecibo() != null) {
			tiposIndice.clear();
			tiposIndice.addAll(boletasBo.getDescIndice(historicoOperacion
					.getFormulaRecibo().getCodigoFormula()));

			for (int i = 0; i < tiposIndice.size(); i++) {

				IndicesPantalla h = new IndicesPantalla();

				h.setLiteralIndice(tiposIndice.get(i).getId()
						.getLiteralIndice());
				h.setTipoValorIndice(null);
				h.setCodigoSubyacente(null);
				h.setTipoFechaInicio(tiposIndice.get(i).getTipoFechaInicio());
				h.setTipoFechaFin(tiposIndice.get(i).getTipoFechaFin());

				indicesFxCobroList.add(h);
			}
			if (!GenericUtils.isNullOrBlank(historicoOperacion
					.getIndiceRecibo())) {
				if (!(indicesFxCobroList == null
						|| indicesFxCobroList.size() == 0 || indicesFxCobroList
						.isEmpty())) {
					// FLM, en alta incompleta puede que esta campo no este
					// informado
					if (historicoOperacion.getIndiceRecibo() != null
							&& entityUtil.checkEntityExists(historicoOperacion
									.getIndiceRecibo())) {
						indicesFxCobroList.get(0).setCodigoSubyacente(
								historicoOperacion.getIndiceRecibo()
										.getCodigo());
						indicesFxCobroList.get(0).setDescripcionCorta(
								historicoOperacion.getIndiceRecibo()
										.getDescripcionCorta());
						// FLM: es opcional
						if (historicoOperacion.getIndiceRecibo()
								.getDescripcionLarga() != null)
							indicesFxCobroList.get(0).setDescripcionLarga(
									historicoOperacion.getIndiceRecibo()
											.getDescripcionLarga());
					}
				}
			}

		}

	}

	private void obtenerValoresIniciales() {
		// TRANOPER Transacción Datos contratación
		valoresIniciales.put("historicoOperacion.getTransaccion().getCodigo()",
				historicoOperacion.getTransaccion() == null ? null
						: historicoOperacion.getTransaccion().getCodigo());
		// INTENOMI Interc. Nominal Datos contratación
		valoresIniciales.put(
				"historicoOperacion.getIntercambioNominales().getCodigo()",
				historicoOperacion.getIntercambioNominales() == null ? null
						: historicoOperacion.getIntercambioNominales()
								.getCodigo());
		// NOMINAPA Nominal Pago Datos Cobros/Pagos A Datos Cobros/Pagos B –
		// Datos Opción
		valoresIniciales.put("historicoOperacion.getNominalPago()",
				historicoOperacion.getNominalPago());
		// DIVISAPA Divisa Pago Datos Cobros/Pagos A- Datos Cobros/Pagos B –
		// Datos Opción
		valoresIniciales.put("historicoOperacion.getDivisaPago().getId()",
				historicoOperacion.getDivisaPago() == null ? null
						: historicoOperacion.getDivisaPago().getId());
		// TIPOAMOP Amortiz Pago Datos Cobros/Pagos A
		valoresIniciales.put("historicoOperacion.getTipoAmortizacionPago()",
				historicoOperacion.getTipoAmortizacionPago());
		// INLIAMPA Liq.Pago Datos Cobros/Pagos A
		valoresIniciales.put(
				"historicoOperacion.getIndicadorLiqAmortizacionPago()",
				historicoOperacion.getIndicadorLiqAmortizacionPago());
		// historicoOperacion.getIndicadorLiqAmortizacionPago()
		// AJUSTEPA Lab. Pago Datos Cobros/Pagos A- Datos Cobros/Pagos B – Datos
		// Opción
		valoresIniciales.put(
				"historicoOperacion.getAjusteDiasPago().getCodigo()",
				historicoOperacion.getAjusteDiasPago() == null ? null
						: historicoOperacion.getAjusteDiasPago().getCodigo());
		// AJUSTEP2 Adj. Pago Datos Cobros/Pagos A- Datos Cobros/Pagos B – Datos
		// Opción
		valoresIniciales.put("historicoOperacion.getIndicadorAjustePago()",
				historicoOperacion.getIndicadorAjustePago());
		// INPAFIVA Clase Pago Datos Cobros/Pagos A
		valoresIniciales
				.put(
						"historicoOperacion.getIndicadorTipoPago().getCodigo()",
						historicoOperacion.getIndicadorTipoPago() == null ? null
								: historicoOperacion.getIndicadorTipoPago()
										.getCodigo());
		// INPAFICR Cre Pago Datos Cobros/Pagos A
		valoresIniciales.put(
				"historicoOperacion.getIndPagoTipoFijoCreciente()",
				historicoOperacion.getIndPagoTipoFijoCreciente());
		// INFIXARP Arr Pago Datos Cobros/Pagos A
		valoresIniciales.put("historicoOperacion.getIndFixingInArrearsPago()",
				historicoOperacion.getIndFixingInArrearsPago());
		// BASECAPA Base Calculo Pago Datos Cobros/Pagos A- Datos Cobros/Pagos B
		// – Datos Opción
		valoresIniciales.put(
				"historicoOperacion.getBaseCalculoPago().getCodigo()",
				historicoOperacion.getBaseCalculoPago() == null ? null
						: historicoOperacion.getBaseCalculoPago().getCodigo());
		// TIPOCUPA Tipo Curva Pago Datos Cobros/Pagos A- Datos Cobros/Pagos B –
		// Datos Opción
		valoresIniciales.put(
				"historicoOperacion.getTipoCurvaPago().getTipocurv()",
				historicoOperacion.getTipoCurvaPago() == null ? null
						: historicoOperacion.getTipoCurvaPago().getTipocurv());
		// INDTIRPA 1 er Tr Pago – Datos Cobros/Pagos A
		valoresIniciales.put("historicoOperacion.getIndTramoIrregularPago()",
				historicoOperacion.getIndTramoIrregularPago());
		// NOMINARE Nominal Cobro Datos Cobros/Pagos A- Datos Cobros/Pagos B –
		// Datos Opción
		valoresIniciales.put("historicoOperacion.getNominalRecibo()",
				historicoOperacion.getNominalRecibo());
		// DIVISARE Divisa Cobro Datos Cobros/Pagos A- Datos Cobros/Pagos B –
		// Datos Opción
		valoresIniciales.put("historicoOperacion.getDivisaRecibo().getId()",
				historicoOperacion.getDivisaRecibo() == null ? null
						: historicoOperacion.getDivisaRecibo().getId());
		// TIPOAMOR Amortiz Cobro Datos Cobros/Pagos A
		valoresIniciales.put("historicoOperacion.getTipoAmortizacionRecibo()",
				historicoOperacion.getTipoAmortizacionRecibo());
		// INLIAMRE Liq. Cobro Datos Cobros/Pagos A
		valoresIniciales.put(
				"historicoOperacion.getIndicadorLiqAmortizacionRecibo()",
				historicoOperacion.getIndicadorLiqAmortizacionRecibo());
		// AJUSTERE Lab. Cobro Datos Cobros/Pagos A- Datos Cobros/Pagos B –
		// Datos Opción
		valoresIniciales.put(
				"historicoOperacion.getAjusteDiasRecibo().getCodigo()",
				historicoOperacion.getAjusteDiasRecibo() == null ? null
						: historicoOperacion.getAjusteDiasRecibo().getCodigo());
		// AJUSTER2 Adj. Cobro Datos Cobros/Pagos A- Datos Cobros/Pagos B –
		// Datos Opción
		valoresIniciales.put("historicoOperacion.getIndicadorAjusteRecibo()",
				historicoOperacion.getIndicadorAjusteRecibo());
		// INREFIVA Clase Cobro Datos Cobros/Pagos A
		valoresIniciales.put(
				"historicoOperacion.getIndicadorTipoRecibo().getCodigo()",
				historicoOperacion.getIndicadorTipoRecibo() == null ? null
						: historicoOperacion.getIndicadorTipoRecibo()
								.getCodigo());
		// INFIXARR Arr Cobro Datos Cobros/Pagos A
		valoresIniciales.put(
				"historicoOperacion.getIndFixingInArrearsRecibo()",
				historicoOperacion.getIndFixingInArrearsRecibo());
		// BASECARE Base Calculo Cobro Datos Cobros/Pagos A- Datos Cobros/Pagos
		// B – Datos Opción
		valoresIniciales
				.put(
						"historicoOperacion.getBaseCalculoRecibo().getCodigo()",
						historicoOperacion.getBaseCalculoRecibo() == null ? null
								: historicoOperacion.getBaseCalculoRecibo()
										.getCodigo());
		// TIPOCURE Tipo Curva Cobro Datos Cobros/Pagos A- Datos Cobros/Pagos B
		// – Datos Opción
		valoresIniciales
				.put("historicoOperacion.getTipoCurvaRecibo().getTipocurv()",
						historicoOperacion.getTipoCurvaRecibo() == null ? null
								: historicoOperacion.getTipoCurvaRecibo()
										.getTipocurv());
		// INDTIRRE 1 er Tr Cobro Datos Cobros/Pagos A
		valoresIniciales.put("historicoOperacion.getIndTramoIrregularRecibo()",
				historicoOperacion.getIndTramoIrregularRecibo());
		// TIPPRIUP Cobro/Pago Prima Up-front Primas
		valoresIniciales.put("historicoOperacion.getTipoPrimaUpFront()",
				historicoOperacion.getTipoPrimaUpFront());
		// TIPPRIPE Cobro/Pago Prima Periodica Primas
		valoresIniciales.put("historicoOperacion.getTipoPrimaPeriodica()",
				historicoOperacion.getTipoPrimaPeriodica());
		// PORPRIUP % Prima Up-front Primas
		// valoresIniciales.put("historicoOperacion.getPorcentajePrimaUpFront()",
		// historicoOperacion.getPorcentajePrimaUpFront() );
		// PORPRIPE % Prima periodica Primas
		valoresIniciales.put(
				"historicoOperacion.getPorcentajePrimaPeriodica()",
				historicoOperacion.getPorcentajePrimaPeriodica());
		// IMPPRIUP Importe prima Up-front Primas
		valoresIniciales.put("historicoOperacion.getImportePrimaUpFront()",
				historicoOperacion.getImportePrimaUpFront());
		// IMPPRIEP Importe prima Periodica Primas
		valoresIniciales.put("historicoOperacion.getImportePrimaPeriodica()",
				historicoOperacion.getImportePrimaPeriodica());
		// DIVPRIUP Divisa prima Up-front Primas
		valoresIniciales.put(
				"historicoOperacion.getDivisaPrimaUpFront().getId()",
				historicoOperacion.getDivisaPrimaUpFront() == null ? null
						: historicoOperacion.getDivisaPrimaUpFront().getId());
		// DIVPRIPE Divisa prima periodica Primas
		valoresIniciales.put(
				"historicoOperacion.getDivisaPrimaPeriodica().getId()",
				historicoOperacion.getDivisaPrimaPeriodica() == null ? null
						: historicoOperacion.getDivisaPrimaPeriodica().getId());
		// IMPRIIMP Importe prima implícita Primas
		valoresIniciales.put("historicoOperacion.getImportePrimaImplicita()",
				historicoOperacion.getImportePrimaImplicita());
		// DIPRIIMP Divisa prima implícita Primas
		valoresIniciales.put(
				"historicoOperacion.getDivisaPrimaImplicita().getId()",
				historicoOperacion.getDivisaPrimaImplicita() == null ? null
						: historicoOperacion.getDivisaPrimaImplicita().getId());
		// FREQUEPA Per Liq. Pago Datos Cobros/Pagos A- Datos Cobros/Pagos B
		valoresIniciales.put(
				"historicoOperacion.getFrecuenciaPago().getCodigo()",
				historicoOperacion.getFrecuenciaPago() == null ? null
						: historicoOperacion.getFrecuenciaPago().getCodigo());
		// FREQUERE Per Liq. Cobro Datos Cobros/Pagos A- Datos Cobros/Pagos B
		valoresIniciales.put(
				"historicoOperacion.getFrecuenciaRecibo().getCodigo()",
				historicoOperacion.getFrecuenciaRecibo() == null ? null
						: historicoOperacion.getFrecuenciaRecibo().getCodigo());
		// INDICAPA Cap Pago Datos Cobros/Pagos A
		valoresIniciales.put("historicoOperacion.getIndCapitalizacionPago()",
				historicoOperacion.getIndCapitalizacionPago());
		// INDICARE Cap Cobro Datos Cobros/Pagos A
		valoresIniciales.put("historicoOperacion.getIndCapitalizacionRecibo()",
				historicoOperacion.getIndCapitalizacionRecibo());
		// Producto
		valoresIniciales.put("historicoOperacion.getProducto().getId()",
				historicoOperacion.getProducto() == null ? null
						: historicoOperacion.getProducto().getId());
		// Fecha Vencimiento
		valoresIniciales.put("historicoOperacion.getFechaVencimiento()",
				historicoOperacion.getFechaVencimiento() == null ? null
						: historicoOperacion.getFechaVencimiento());
		// Fecha Valor
		valoresIniciales.put("historicoOperacion.getFechaValor()",
				historicoOperacion.getFechaValor() == null ? null
						: historicoOperacion.getFechaValor());
		// frecuencia periodicidad fixing pago
		valoresIniciales.put("historicoOperacion.getFrecuenciaFixingPago()",
				historicoOperacion.getFrecuenciaFixingPago() == null ? null
						: historicoOperacion.getFrecuenciaFixingPago());
		// frecuencia periodicidad fixing cobor
		valoresIniciales.put("historicoOperacion.getFrecuenciaFixingRecibo()",
				historicoOperacion.getFrecuenciaFixingRecibo() == null ? null
						: historicoOperacion.getFrecuenciaFixingRecibo());
		// Rate Factor pago
		valoresIniciales.put("historicoOperacion.getRateFactorPago()",
				historicoOperacion.getRateFactorPago() == null ? null
						: historicoOperacion.getRateFactorPago());
		// Rate Factor cobro
		valoresIniciales.put("historicoOperacion.getRateFactorRecibo()",
				historicoOperacion.getRateFactorRecibo() == null ? null
						: historicoOperacion.getRateFactorRecibo());

		/*
		 * valoresIniciales.put("", );
		 * valoresIniciales.put("historicoOperacion", historicoOperacion. );
		 */

		// :CONTINUAR: ver tabla en F_CALENDARIO_VALIDO de DT boletas
		/*
		 * Campo tabla (deri.histderi) Campo Pantalla Pestaña o grupo datos Pant
		 * 
		 * INPAFIVA Clase Pago Datos Cobros/Pagos A INPAFICR Cre Pago Datos
		 * Cobros/Pagos A INFIXARP Arr Pago Datos Cobros/Pagos A BASECAPA Base
		 * Calculo Pago Datos Cobros/Pagos A- Datos Cobros/Pagos B – Datos
		 * Opción TIPOCUPA Tipo Curva Pago Datos Cobros/Pagos A- Datos
		 * Cobros/Pagos B – Datos Opción INDTIRPA 1 er Tr Pago – Datos
		 * Cobros/Pagos A NOMINARE Nominal Cobro Datos Cobros/Pagos A- Datos
		 * Cobros/Pagos B – Datos Opción DIVISARE Divisa Cobro Datos
		 * Cobros/Pagos A- Datos Cobros/Pagos B – Datos Opción TIPOAMOR Amortiz
		 * Cobro Datos Cobros/Pagos A INLIAMRE Liq. Cobro Datos Cobros/Pagos A
		 * AJUSTERE Lab. Cobro Datos Cobros/Pagos A- Datos Cobros/Pagos B –
		 * Datos Opción AJUSTER2 Adj. Cobro Datos Cobros/Pagos A- Datos
		 * Cobros/Pagos B – Datos Opción INREFIVA Clase Cobro Datos Cobros/Pagos
		 * A INFIXARR Arr Cobro Datos Cobros/Pagos A BASECARE Base Calculo Cobro
		 * Datos Cobros/Pagos A- Datos Cobros/Pagos B – Datos Opción TIPOCURE
		 * Tipo Curva Cobro Datos Cobros/Pagos A- Datos Cobros/Pagos B – Datos
		 * Opción INDTIRRE 1 er Tr Cobro Datos Cobros/Pagos A TIPPRIUP
		 * Cobro/Pago Prima Up-front Primas TIPPRIPE Cobro/Pago Prima Periodica
		 * Primas PORPRIUP % Prima Up-front Primas PORPRIPE % Prima periodica
		 * Primas IMPPRIUP Importe prima Up-front Primas IMPPRIEP Importe prima
		 * Periodica Primas DIVPRIUP Divisa prima Up-front Primas DIVPRIPE
		 * Divisa prima periodica Primas IMPRIIMP Importe prima implícita Primas
		 * DIPRIIMP Divisa prima implícita Primas FREQUEPA Per Liq. Pago Datos
		 * Cobros/Pagos A- Datos Cobros/Pagos B FREQUERE Per Liq. Cobro Datos
		 * Cobros/Pagos A- Datos Cobros/Pagos B INDICAPA Cap Pago Datos
		 * Cobros/Pagos A INDICARE Cap Cobro Datos Cobros/Pagos A PRODUCTO
		 * Producto
		 */

	}

	private void obtenerValoresInicialesOpciones() {
		/*
		 * Campos a comprobar: Nominal de la opción Divisas de la opción Fórmula
		 * de la opción Subyacentes asociados a la opción Fechas de ejercicio
		 * Fechas de observación Fechas de liquidación Prima Up Front
		 * 
		 * CAMPOS Prima Up Front INDPRIUP TIPPRIUP DIVPRIUP DILPRIUP IMPPRIUP
		 * FECLQPUP
		 * 
		 * HISTPARM FECHAS OBSERVACION - EJERCICIO FECHAINI FECHAFIN PESOBSFE
		 * 
		 * FECHAS LIQUIDACION FECHAINI FECHAFIN FECHALIQ FECFIXIN TIPINPRE
		 * FACTORLI RATELIQI
		 * 
		 * SUBYACENTES HISTSUBY tiposuby = OP codindic pesosuby
		 */

		// NOMINARE Nominal Cobro Datos Cobros/Pagos A- Datos Cobros/Pagos B –
		// Datos Opción
		valoresInicialesOpciones.put("historicoOperacion.getNominalRecibo()",
				historicoOperacion.getNominalRecibo());
		// DIVISARE Divisa Cobro Datos Cobros/Pagos A- Datos Cobros/Pagos B –
		// Datos Opción
		valoresInicialesOpciones.put(
				"historicoOperacion.getDivisaRecibo().getId()",
				historicoOperacion.getDivisaRecibo() == null ? null
						: historicoOperacion.getDivisaRecibo().getId());
		// NOMINAPA Nominal Pago Datos Cobros/Pagos A Datos Cobros/Pagos B –
		// Datos Opción
		valoresInicialesOpciones.put("historicoOperacion.getNominalPago()",
				historicoOperacion.getNominalPago());
		// DIVISAPA Divisa Pago Datos Cobros/Pagos A- Datos Cobros/Pagos B –
		// Datos Opción
		valoresInicialesOpciones.put(
				"historicoOperacion.getDivisaPago().getId()",
				historicoOperacion.getDivisaPago() == null ? null
						: historicoOperacion.getDivisaPago().getId());
		// CODFORRE Formula Cobro Datos Cobros/Pagos A- Datos Cobros/Pagos B –
		// Datos Opción
		valoresInicialesOpciones.put(
				"historicoOperacion.getFormulaRecibo().getCodigoFormula()",
				historicoOperacion.getFormulaRecibo() == null ? null
						: historicoOperacion.getFormulaRecibo()
								.getCodigoFormula());
		// CODFORPA Formula Pago Datos Cobros/Pagos A- Datos Cobros/Pagos B –
		// Datos Opción
		valoresInicialesOpciones.put(
				"historicoOperacion.getFormulaPago().getCodigoFormula()",
				historicoOperacion.getFormulaPago() == null ? null
						: historicoOperacion.getFormulaPago()
								.getCodigoFormula());
		// Fechas Formula
		listaFechasFormula = creaListaFechasFormula(historicoOperacion
				.getHistoricoFechasFormulas());
		valoresInicialesOpciones.put("listaFechasFormula", listaFechasFormula);
		// Prima Up Front
		valoresInicialesOpciones.put(
				"historicoOperacion.getIndicadorPrimaUpFront()",
				historicoOperacion.getIndicadorPrimaUpFront());
		valoresInicialesOpciones.put(
				"historicoOperacion.getTipoPrimaUpFront()", historicoOperacion
						.getTipoPrimaUpFront());
		// valoresInicialesOpciones.put("historicoOperacion.getPorcentajePrimaUpFront()",
		// historicoOperacion.getPorcentajePrimaUpFront());
		valoresInicialesOpciones.put(
				"historicoOperacion.getDivisaPrimaUpFront().getId()",
				historicoOperacion.getDivisaPrimaUpFront() == null ? null
						: historicoOperacion.getDivisaPrimaUpFront().getId());
		valoresInicialesOpciones.put(
				"historicoOperacion.getDivisaLiquidacionUpFront().getId()",
				historicoOperacion.getDivisaLiquidacionUpFront() == null ? null
						: historicoOperacion.getDivisaLiquidacionUpFront()
								.getId());
		valoresInicialesOpciones.put(
				"historicoOperacion.getImportePrimaUpFront()",
				historicoOperacion.getImportePrimaUpFront());
		valoresInicialesOpciones.put(
				"historicoOperacion.getFechaLiquidacionUpFront()",
				historicoOperacion.getFechaLiquidacionUpFront());
		// SUBYACENTES HISTSUBY tiposuby = OP
		listaSubyacentes = creaListaSubyacentes(historicoOperacion
				.getHistoricoSubyacentes());
		valoresInicialesOpciones.put("listaSubyacentes", listaSubyacentes);

		// if (historicoOperacion.getHistoricoFechasFormulas()!=null &&
		// historicoOperacion.getHistoricoFechasFormulas().size()>0){
		// for (HistoricoFechaFormula fechas :
		// historicoOperacion.getHistoricoFechasFormulas()) {
		//				
		// }
		// }

	}

	private List<CopiaSubyacentes> creaListaSubyacentes(
			Set<HistoricoSubyacente> set) {
		// TODO Auto-generated method stub
		List<CopiaSubyacentes> lista = new ArrayList<CopiaSubyacentes>();
		Iterator<HistoricoSubyacente> it = set.iterator();

		while (it.hasNext()) {
			HistoricoSubyacente subyacente = it.next();
			if ("OP".equalsIgnoreCase(subyacente.getId().getTiposuby())) {
				lista.add(new CopiaSubyacentes(subyacente));
			}
		}

		return lista;
	}

	private List<CopiaFechasFormula> creaListaFechasFormula(
			Set<HistoricoFechaFormula> set) {
		// TODO Auto-generated method stub
		List<CopiaFechasFormula> lista = new ArrayList<CopiaFechasFormula>();
		Iterator<HistoricoFechaFormula> it = set.iterator();

		while (it.hasNext()) {
			HistoricoFechaFormula fecha = it.next();
			if (GenericUtils.in(fecha.getId().getTipoFecha(), "FO", "LI", "EJ")) {
				lista.add(new CopiaFechasFormula(fecha));
			}
		}

		return lista;
	}

	/**
	 * Solo valida Opciones, sino retorna 1.
	 * 
	 * Campos a comprobar: Nominal de la opción Divisas de la opción Fórmula de
	 * la opción Subyacentes asociados a la opción Fechas de ejercicio Fechas de
	 * observación Fechas de liquidación
	 * 
	 * 
	 * Codigos retorno 1.- No se ha modificado ningun dato o no es una opcion.
	 * Seguir flujo normal. 2.- No se puede rehacer el calendario 3.- Se rehace
	 * el Calendario. No llamamos a la funcion calendarioValido y proseguimos
	 * con la grabacion. continuarAltaCompleta(); 4.- Error al rehacer
	 * calendario. 5.- Existen tramos con índices sin informar correctamente.
	 * tras regenerar el calendario 6.- Los indices/fechas del tramo interpolado
	 * son incorrectos tras regenerar el calendario
	 * 
	 * 
	 * @return
	 */
	private Integer calendarioOpcionValido() {

		// CALENDARIO REGENERABLE????

		if (hasDatosOpcionTab()) {

			if (calendarioValoresOpciones())
				return 1;
			else if (esCalendarioRegenerable()) {
				// No controlo día festivo
				tramosTableComponent = new TramosTableComponent();
				if ("TO_MANTRAM".equalsIgnoreCase(llamarCalendarioCrear(true))) {

					return dadesValidesCalendari(true);

				} else
					return 4;
			} else {
				return 2;
			}
		} else {
			return 1;
		}

	}

	/**
	 * Si devuelve true es que no ha encontrado ningun dato cambiado o que no
	 * debe regenerar el calendario
	 * 
	 * @return
	 */
	@SuppressWarnings("unchecked")
	private boolean calendarioValoresOpciones() {

		// Miramos que no tenga fechas de Liquidacion si tiene no regeneramos
		// calendario
		if (historicoOperacion.getHistoricoFechasFormulas() != null) {

			Iterator<HistoricoFechaFormula> itNuevo = historicoOperacion
					.getHistoricoFechasFormulas().iterator();
			while (itNuevo.hasNext()) {
				HistoricoFechaFormula fechaNueva = itNuevo.next();
				if ("LI".equals(fechaNueva.getId().getTipoFecha()))
					return true;
			}
		}

		Set<String> expresiones = valoresInicialesOpciones.keySet();
		for (String expression : expresiones) {
			Object newValue = Expressions.instance().createValueExpression(
					"#{" + expression + "}").getValue();
			Object oldValue = valoresInicialesOpciones.get(expression);

			if (expression.equals("listaFechasFormula")) {

				if (!compararFechas(
						(List<CopiaFechasFormula>) creaListaFechasFormula(historicoOperacion
								.getHistoricoFechasFormulas()),
						(List<CopiaFechasFormula>) oldValue)) {
					return false;
				}

			} else if (expression.equals("listaSubyacentes")) {

				if (!compararSubyacentes(
						(List<CopiaSubyacentes>) creaListaSubyacentes(historicoOperacion
								.getHistoricoSubyacentes()),
						(List<CopiaSubyacentes>) oldValue)) {
					return false;
				}

			} else if (!GenericUtils.equals(newValue, oldValue)) {
				return false;
			}
		}
		return true;
	}

	/**
	 * SUBYACENTES HISTSUBY tiposuby = OP codindic pesosuby
	 * 
	 * @param cjtoSubyacentesNuevos
	 * @param cjtoSubyacentesViejos
	 * @return
	 */
	private Boolean compararSubyacentes(
			List<CopiaSubyacentes> cjtoSubyacentesNuevos,
			List<CopiaSubyacentes> cjtoSubyacentesViejos) {

		if (cjtoSubyacentesNuevos == null && cjtoSubyacentesViejos == null)
			return true;

		// Solo miramos los cambios en los tipos de subyacente OP.

		// if (cjtoSubyacentesNuevos != null){
		//			
		//		
		// Iterator<HistoricoSubyacente> it = cjtoSubyacentesNuevos.iterator();
		// while (it.hasNext()) {
		// HistoricoSubyacente subyacente = it.next();
		// if (!"OP".equalsIgnoreCase(subyacente.getId().getTiposuby())){
		// it.remove(); // avoids a ConcurrentModificationException
		// }
		// }
		//		
		// for (HistoricoSubyacente subyacenteNuevo : cjtoSubyacentesNuevos) {
		// if (!"OP".equalsIgnoreCase(subyacenteNuevo.getId().getTiposuby()))
		// cjtoSubyacentesNuevos.remove(subyacenteNuevo);
		// }

		// }

		// if (cjtoSubyacentesViejos != null){
		//			
		//		
		// Iterator<HistoricoSubyacente> itViejo =
		// cjtoSubyacentesViejos.iterator();
		// while (itViejo.hasNext()) {
		// HistoricoSubyacente subyacente = itViejo.next();
		// if (!"OP".equalsIgnoreCase(subyacente.getId().getTiposuby())){
		// itViejo.remove(); // avoids a ConcurrentModificationException
		// }
		// }
		//
		//
		// // for (HistoricoSubyacente subyacenteViejo : cjtoSubyacentesViejos)
		// {
		// // if (!"OP".equalsIgnoreCase(subyacenteViejo.getId().getTiposuby()))
		// // cjtoSubyacentesViejos.remove(subyacenteViejo);
		// // }
		// }

		if ((cjtoSubyacentesNuevos != null && cjtoSubyacentesViejos == null)
				|| (cjtoSubyacentesViejos != null && cjtoSubyacentesNuevos == null)
				|| (cjtoSubyacentesNuevos.size() != cjtoSubyacentesViejos
						.size())) {
			return false;
		}

		for (CopiaSubyacentes nuevo : cjtoSubyacentesNuevos) {
			boolean encontradoNuevo = false;
			for (CopiaSubyacentes viejo : cjtoSubyacentesViejos) {

				if ((nuevo.getCodindic() == viejo.getCodindic())
						|| (nuevo.getPesoSubyacente() == viejo
								.getPesoSubyacente())) {
					encontradoNuevo = true;
					break;
				}

			}

			if (!encontradoNuevo)
				return false;

		}

		for (CopiaSubyacentes viejo : cjtoSubyacentesViejos) {
			boolean encontradoViejo = false;
			for (CopiaSubyacentes nuevo : cjtoSubyacentesNuevos) {

				if ((nuevo.getCodindic() == viejo.getCodindic())
						|| (nuevo.getPesoSubyacente() == viejo
								.getPesoSubyacente())) {
					encontradoViejo = true;
					break;
				}

			}

			if (!encontradoViejo)
				return false;

		}

		return true;
	}

	/**
	 * 
	 * FECHAS OBSERVACION - EJERCICIO FECHAINI FECHAFIN PESOBSFE
	 * 
	 * FECHAS LIQUIDACION FECHAINI FECHAFIN FECHALIQ FECFIXIN TIPINPRE FACTORLI
	 * RATELIQI
	 * 
	 * @param cjtoFechasNuevas
	 * @param cjtoFechasViejas
	 * @return
	 */
	private Boolean compararFechas(List<CopiaFechasFormula> cjtoFechasNuevas,
			List<CopiaFechasFormula> cjtoFechasViejas) {

		if (cjtoFechasNuevas == null && cjtoFechasViejas == null)
			return true;

		// if (cjtoFechasNuevas != null){
		//
		// Iterator<HistoricoFechaFormula> itNuevo =
		// cjtoFechasNuevas.iterator();
		// while (itNuevo.hasNext()) {
		// HistoricoFechaFormula fechaNueva = itNuevo.next();
		// if
		// (!GenericUtils.in(fechaNueva.getId().getTipoFecha(),"FO","LI","EJ")){
		// itNuevo.remove(); // avoids a ConcurrentModificationException
		// }
		// }
		//		
		// for (HistoricoFechaFormula fechaNueva : (Set<HistoricoFechaFormula>)
		// cjtoFechasNuevas) {
		// if
		// (!GenericUtils.in(fechaNueva.getId().getTipoFecha(),"FO","LI","EJ")){
		// cjtoFechasNuevas.remove(fechaNueva);
		// }
		// }
		// }

		// for (HistoricoFechaFormula fechaVieja : (Set<HistoricoFechaFormula>)
		// cjtoFechasViejas) {
		// if
		// (!GenericUtils.in(fechaVieja.getId().getTipoFecha(),"FO","LI","EJ")){
		// cjtoFechasViejas.remove(fechaVieja);
		// }
		// }

		if ((cjtoFechasNuevas != null && cjtoFechasViejas == null)
				|| (cjtoFechasViejas != null && cjtoFechasNuevas == null)
				|| (cjtoFechasNuevas.size() != cjtoFechasViejas.size())) {
			return false;
		}

		for (CopiaFechasFormula nuevo : cjtoFechasNuevas) {
			boolean encontradoNuevo = false;
			for (CopiaFechasFormula viejo : cjtoFechasViejas) {

				if (nuevo.getTipoFecha().equals(viejo.getTipoFecha())) {
					if ("FO".equals(nuevo.getTipoFecha())
							|| "EJ".equals(nuevo.getTipoFecha())) {
						// * FECHAINI
						// * FECHAFIN
						// * PESOBSFE
						if ((nuevo.getFechaInicio().equals(viejo
								.getFechaInicio()))
								&& (nuevo.getFechaFin().equals(viejo
										.getFechaFin()))
								&& (nuevo.getPesobsfe() == viejo.getPesobsfe())) {
							encontradoNuevo = true;
							break;
						}

					} else {
						// Fecha Liquidacion
						// * FECHAINI
						// * FECHAFIN
						// * FECHALIQ
						// * FECFIXIN
						// * TIPINPRE
						// * FACTORLI
						// * RATELIQI
						if ((nuevo.getFechaInicio().equals(viejo
								.getFechaInicio()))
								&& (nuevo.getFechaFin().equals(viejo
										.getFechaFin()))
								&& (nuevo.getFechaLiquidacion().equals(viejo
										.getFechaLiquidacion()))
								&& (nuevo.getFechaFixing().equals(viejo
										.getFechaFixing()))
								&& (nuevo.getTipoInformacionPrecio()
										.equals(viejo
												.getTipoInformacionPrecio()))
								&& (nuevo.getFactorLiquidacion().equals(viejo
										.getFactorLiquidacion()))
								&& (nuevo.getRateLiquidacion().compareTo(viejo
										.getRateLiquidacion())==0)) {
							encontradoNuevo = true;
							break;
						}

					}
				}

			}

			if (!encontradoNuevo)
				return false;

		}

		for (CopiaFechasFormula vieja : cjtoFechasViejas) {
			boolean encontradoViejo = false;
			for (CopiaFechasFormula nueva : cjtoFechasNuevas) {

				if (vieja.getTipoFecha().equals(nueva.getTipoFecha())) {
					if ("FO".equals(vieja.getTipoFecha())
							|| "EJ".equals(vieja.getTipoFecha())) {
						// * FECHAINI
						// * FECHAFIN
						// * PESOBSFE
						if ((vieja.getFechaInicio().equals(nueva
								.getFechaInicio()))
								&& (vieja.getFechaFin().equals(nueva
										.getFechaFin()))
								&& (vieja.getPesobsfe() == nueva.getPesobsfe())) {
							encontradoViejo = true;
							break;
						}

					} else {
						// Fecha Liquidacion
						// * FECHAINI
						// * FECHAFIN
						// * FECHALIQ
						// * FECFIXIN
						// * TIPINPRE
						// * FACTORLI
						// * RATELIQI
						if ((vieja.getFechaInicio().equals(nueva
								.getFechaInicio()))
								&& (vieja.getFechaFin().equals(nueva
										.getFechaFin()))
								&& (vieja.getFechaLiquidacion().equals(nueva
										.getFechaLiquidacion()))
								&& (vieja.getFechaFixing().equals(nueva
										.getFechaFixing()))
								&& (vieja.getTipoInformacionPrecio()
										.equals(nueva
												.getTipoInformacionPrecio()))
								&& (vieja.getFactorLiquidacion().equals(nueva
										.getFactorLiquidacion()))
								&& (vieja.getRateLiquidacion().compareTo(nueva.getRateLiquidacion()) == 0)) {
							encontradoViejo = true;
							break;
						}

					}
				}

			}

			if (!encontradoViejo)
				return false;

		}

		return true;
	}

	private boolean calendarioValido() {
		Set<String> expresiones = valoresIniciales.keySet();
		for (String expression : expresiones) {
			Object newValue = Expressions.instance().createValueExpression(
					"#{" + expression + "}").getValue();
			Object oldValue = valoresIniciales.get(expression);
			if (!GenericUtils.equals(newValue, oldValue)) {
				return false;
			}
		}
		return true;
	}

	private OperacionId getOperacionId() {
		OperacionId id = null;
		id = new OperacionId(historicoOperacion.getId().getFechaContratacion(),
				historicoOperacion.getId().getNumeroOperacion());
		return id;
	}

	private void checkGrupoContable() {
		// if (hasAttribute(4003) &&
		// historicoOperacion.getIndicadorOperacionModelo() &&
		// historicoOperacion.getGrupoContable() == null) {
		if (historicoOperacion.getIndicadorOperacionModelo()
				&& historicoOperacion.getGrupoContable() == null) {
			if (grupoContableXX == null) {
				grupoContableXX = entityManager.find(GrupoContable.class,
						new GrupoContableId("XX", historicoOperacion
								.getProducto()));
			}
			historicoOperacion.setGrupoContable(grupoContableXX);
		}
	}

	private void resetBloqueos(boolean pagos, boolean cobros) {
		if (getPanelesBloqueados() == null) {
			panelesBloqueados = new Bloqueos(pagos, cobros);
		} else {
			getPanelesBloqueados().setPagos(pagos);
			getPanelesBloqueados().setCobros(cobros);
		}
	}

	private void checkConfirmaciones() {
		if (hasConfirmacionesTab() && confirmacion == null) {
			confirmacion = null;
			try {
				confirmacion = entityManager.find(IndicadorConfirmacion.class,
						getOperacionId());
				if (confirmacion == null) {
					confirmacion = new IndicadorConfirmacion(getOperacionId());
					confirmacion
							.setAuditData(historicoOperacion.getAuditData());
				}
			} catch (EntityNotFoundException ex) {
				confirmacion = new IndicadorConfirmacion(getOperacionId());
			}
			if (confirmacion != null) {
				initListasConfirmaciones();

				indicadorConfirmacion = new IndicadorConfirmacionDelegate(
						confirmacion);
				CanalConfirmacion canelEmisionConfirmacionAlta = buscaCanal(
						listaCanalConfirmacionEA, confirmacion
								.getCanelEmisionConfirmacionAlta());
				indicadorConfirmacion
						.setCanelEmisionConfirmacionAlta(canelEmisionConfirmacionAlta);
				CanalConfirmacion canelEmisionConfirmacionModificacion = buscaCanal(
						listaCanalConfirmacionEM, confirmacion
								.getCanelEmisionConfirmacionModificacion());
				indicadorConfirmacion
						.setCanelEmisionConfirmacionModificacion(canelEmisionConfirmacionModificacion);
				CanalConfirmacion canelEmisionConfirmacionAnulacion = buscaCanal(
						listaCanalConfirmacionEN, confirmacion
								.getCanelEmisionConfirmacionAnulacion());
				indicadorConfirmacion
						.setCanelEmisionConfirmacionAnulacion(canelEmisionConfirmacionAnulacion);
				CanalConfirmacion canelEmisionConfirmacionCancelacion = buscaCanal(
						listaCanalConfirmacionEC, confirmacion
								.getCanelEmisionConfirmacionCancelacion());
				indicadorConfirmacion
						.setCanelEmisionConfirmacionCancelacion(canelEmisionConfirmacionCancelacion);
				CanalConfirmacion canelEmisionConfirmacionCancelacionParcial = buscaCanal(
						listaCanalConfirmacionEP,
						confirmacion
								.getCanelEmisionConfirmacionCancelacionParcial());
				indicadorConfirmacion
						.setCanelEmisionConfirmacionCancelacionParcial(canelEmisionConfirmacionCancelacionParcial);
				CanalConfirmacion canelEmisionConfirmacionFijacion = buscaCanal(
						listaCanalConfirmacionEL, confirmacion
								.getCanelEmisionConfirmacionFijacion());
				indicadorConfirmacion
						.setCanelEmisionConfirmacionFijacion(canelEmisionConfirmacionFijacion);
				CanalConfirmacion canelEmisionConfirmacionLiquidacion = buscaCanal(
						listaCanalConfirmacionEX, confirmacion
								.getCanelEmisionConfirmacionLiquidacion());
				indicadorConfirmacion
						.setCanelEmisionConfirmacionLiquidacion(canelEmisionConfirmacionLiquidacion);

				CanalConfirmacion canelRecepcionConfirmacionAlta = buscaCanal(
						listaCanalConfirmacionRA, confirmacion
								.getCanelRecepcionConfirmacionAlta());
				indicadorConfirmacion
						.setCanelRecepcionConfirmacionAlta(canelRecepcionConfirmacionAlta);
				CanalConfirmacion canelRecepcionConfirmacionModificacion = buscaCanal(
						listaCanalConfirmacionRM, confirmacion
								.getCanelRecepcionConfirmacionModificacion());
				indicadorConfirmacion
						.setCanelRecepcionConfirmacionModificacion(canelRecepcionConfirmacionModificacion);
				CanalConfirmacion canelRecepcionConfirmacionAnulacion = buscaCanal(
						listaCanalConfirmacionRN, confirmacion
								.getCanelRecepcionConfirmacionAnulacion());
				indicadorConfirmacion
						.setCanelRecepcionConfirmacionAnulacion(canelRecepcionConfirmacionAnulacion);
				CanalConfirmacion canelRecepcionConfirmacionCancelacion = buscaCanal(
						listaCanalConfirmacionRC, confirmacion
								.getCanelRecepcionConfirmacionCancelacion());
				indicadorConfirmacion
						.setCanelRecepcionConfirmacionCancelacion(canelRecepcionConfirmacionCancelacion);
				CanalConfirmacion canelRecepcionConfirmacionCancelacionParcial = buscaCanal(
						listaCanalConfirmacionRP,
						confirmacion
								.getCanelRecepcionConfirmacionCancelacionParcial());
				indicadorConfirmacion
						.setCanelRecepcionConfirmacionCancelacionParcial(canelRecepcionConfirmacionCancelacionParcial);
				CanalConfirmacion canelRecepcionConfirmacionFijacion = buscaCanal(
						listaCanalConfirmacionRL, confirmacion
								.getCanelRecepcionConfirmacionFijacion());
				indicadorConfirmacion
						.setCanelRecepcionConfirmacionFijacion(canelRecepcionConfirmacionFijacion);
				CanalConfirmacion canelRecepcionConfirmacionLiquidacion = buscaCanal(
						listaCanalConfirmacionRX, confirmacion
								.getCanelRecepcionConfirmacionLiquidacion());
				indicadorConfirmacion
						.setCanelRecepcionConfirmacionLiquidacion(canelRecepcionConfirmacionLiquidacion);

			}
		}
	}

	private CanalConfirmacion buscaCanal(
			List<CanalConfirmacion> listaCanalConfirmacionEA2, String id) {
		if (id == null || listaCanalConfirmacionEA2 == null) {
			return null;
		}
		for (CanalConfirmacion canalConfirmacion : listaCanalConfirmacionEA2) {
			if (canalConfirmacion.getId().getCodcanal().equalsIgnoreCase(id)) {
				return canalConfirmacion;
			}
		}
		return null;
	}

	private Idioma buscarIdioma(List<Idioma> listaIdioma, String codigoIdioma) {

		if (listaIdioma != null) {
			for (Iterator<Idioma> iterator = listaIdioma.iterator(); iterator
					.hasNext();) {
				Idioma idioma = (Idioma) iterator.next();
				String codiIdioma = idioma.getCodigo();
				if (codigoIdioma.equalsIgnoreCase(codiIdioma)) {
					return idioma;
				}
			}
		}
		return null;
	}

	private void confirmacionesOpcionDivisas() {

		if (!esContrapaCliente()
				&& historicoOperacion.getProductoCatalogo() != null
				&& historicoOperacion.getProductoCatalogo().getProdtrat() != null
				&& "S".equals(historicoOperacion.getProductoCatalogo()
						.getProdtrat().getChkopcdiv())) {

			if (opcionConfirmable()) {

				Idioma idiomaCastellano = buscarIdioma(
						listaIdiomaConfirmacionAlta,
						Constantes.IDIOMA_CASTELLANO);

				// indicadorConfirmacion = new
				// IndicadorConfirmacionDelegate(confirmacion);
				CanalConfirmacion canelSwiftEmisionAlta = buscaCanal(
						listaCanalConfirmacionEA, "SW");
				indicadorConfirmacion
						.setCanelEmisionConfirmacionAlta(canelSwiftEmisionAlta);
				indicadorConfirmacion.setIndicadorConfirmacionAlta(true);
				// 24/10/2013 SMM Incidencia
				indicadorConfirmacion
						.setIndicadorRecepcionConfirmacionAlta(false);
				indicadorConfirmacion
						.setIdiomaConfirmacionAlta(idiomaCastellano);

				// SMM 28/11/2013 Mail Violeta

				// CanalConfirmacion canelSwiftEmisionModif =
				// buscaCanal(listaCanalConfirmacionEM, "SW");
				// indicadorConfirmacion.setCanelEmisionConfirmacionModificacion(canelSwiftEmisionModif);
				// indicadorConfirmacion.setIndicadorConfirmacionModificacion(true);
				// // 24/10/2013 SMM Incidencia
				// indicadorConfirmacion.setIndicadorRecepcionConfirmacionModificacion(false);

				// idiomaCastellano =
				// buscarIdioma(listaIdiomaConfirmacionC,Constantes.IDIOMA_CASTELLANO);
				// CanalConfirmacion canelSwiftEmisionCancelacion =
				// buscaCanal(listaCanalConfirmacionEC, "SW");
				// indicadorConfirmacion.setCanelEmisionConfirmacionCancelacion(canelSwiftEmisionCancelacion);
				// indicadorConfirmacion.setIndicadorConfirmacionCancelacion(true);
				// indicadorConfirmacion.setIndicadorRecepcionConfirmacionCancelacion(false);
				// indicadorConfirmacion.setIdiomaConfirmacionCancelacion(idiomaCastellano);
				//
				// idiomaCastellano =
				// buscarIdioma(listaIdiomaConfirmacionP,Constantes.IDIOMA_CASTELLANO);
				// CanalConfirmacion canelSwiftEmisionCancelacionParcial =
				// buscaCanal(listaCanalConfirmacionEP, "SW");
				// indicadorConfirmacion.setCanelEmisionConfirmacionCancelacionParcial(canelSwiftEmisionCancelacionParcial);
				// indicadorConfirmacion.setIndicadorConfirmacionCancelacionParcial(true);
				// indicadorConfirmacion.setIndicadorRecepcionConfirmacionCancelacionParcial(false);
				// indicadorConfirmacion.setIdiomaConfirmacionCancelacionParcial(idiomaCastellano);

			} else {
				// indicadorConfirmacion = new
				// IndicadorConfirmacionDelegate(confirmacion);
				indicadorConfirmacion.setIndicadorConfirmacionAlta(false);
				// indicadorConfirmacion.setIndicadorConfirmacionModificacion(false);
				// indicadorConfirmacion.setIndicadorConfirmacionCancelacion(false);
				// indicadorConfirmacion.setIndicadorConfirmacionCancelacionParcial(false);

				CanalConfirmacion canelSwiftRecepAlta = buscaCanal(
						listaCanalConfirmacionRA, "MM");
				indicadorConfirmacion
						.setCanelRecepcionConfirmacionAlta(canelSwiftRecepAlta);
				indicadorConfirmacion
						.setIndicadorRecepcionConfirmacionAlta(true);

				// CanalConfirmacion canelSwiftRecepModif =
				// buscaCanal(listaCanalConfirmacionRM, "MM");
				// indicadorConfirmacion.setCanelRecepcionConfirmacionModificacion(canelSwiftRecepModif);
				// indicadorConfirmacion.setIndicadorRecepcionConfirmacionModificacion(true);

				// CanalConfirmacion canelSwiftRecepCancelacion =
				// buscaCanal(listaCanalConfirmacionRC, "MM");
				// indicadorConfirmacion.setCanelRecepcionConfirmacionCancelacion(canelSwiftRecepCancelacion);
				// indicadorConfirmacion.setIndicadorRecepcionConfirmacionCancelacion(true);
				//
				// CanalConfirmacion canelSwiftRecepCancelacionParcial =
				// buscaCanal(listaCanalConfirmacionRP, "MM");
				// indicadorConfirmacion.setCanelRecepcionConfirmacionCancelacionParcial(canelSwiftRecepCancelacionParcial);
				// indicadorConfirmacion.setIndicadorRecepcionConfirmacionCancelacionParcial(true);

			}

		}

	}

	private boolean compruebaNuevoListener(String eventType) {
		return Init.instance() != null
				&& (Init.instance().getObserverMethodExpressions(eventType) == null || Init
						.instance().getObserverMethodExpressions(eventType)
						.size() == 0);
	}

	// @Observer(create=false, value="com.atosorigin.seam.jsf.viewBuilt")
	public void onCreateView(UIViewRoot root) {
		if (log.isDebugEnabled()) {
			log.debug("Evento createView para la conversacion {0}",
					Conversation.instance().getId());
		}
		visit(root, new UIComponentVisitor() {

			public boolean visit(UIComponent uiComponent) {
				configureComponent(uiComponent);
				return false;
			}
		});
		forceValidation = false;
	}

	public Boolean isRequired(String id) {
		Matcher matcher = attributePattern.matcher(id);
		if (matcher.matches()) {
			return isRequired(Short.parseShort(matcher.group(1)), Short
					.parseShort(matcher.group(2)));
		}
		return false;
	}

	public Boolean isRequired(Short atributo, Short codigoDato) {
		checkProductoAtributoMap();
		Set<RelProductoAtributo> set = relProductoAtributoMap.get(atributo);
		if (set == null) {
			return false;
		}
		for (RelProductoAtributo relProductoAtributo : set) {
			Integer codigoAtributo = atributo * 1000 + codigoDato;
			RelProductoDatosAtributo relProductoDatosAtributo = getRelProductoDatosAtributo(
					relProductoAtributo, codigoAtributo);
			if (relProductoDatosAtributo != null) {
				if ((forceValidation != null && forceValidation)
						&& "S".equals(relProductoDatosAtributo
								.getIndicadorAtributo())) {
					return true;
				}
			}
		}
		return false;
	}

	public RelProductoDatosAtributo getDatosAtributo(String id) {
		Matcher matcher = attributePattern.matcher(id);
		Short attributeId = null;
		Integer codigoDato = null;
		if (matcher.matches()) {
			attributeId = Short.parseShort(matcher.group(1));
			codigoDato = Integer.parseInt(matcher.group(2));
		} else {
			attributeId = Short.parseShort(id);
		}

		Set<RelProductoAtributo> set = relProductoAtributoMap.get(attributeId);
		if (set == null) {
			return null;
		}
		for (RelProductoAtributo relProductoAtributo : set) {
			Integer codigoAtributo = attributeId * 1000 + codigoDato;
			RelProductoDatosAtributo relProductoDatosAtributo = getRelProductoDatosAtributo(
					relProductoAtributo, codigoAtributo);
			if (relProductoDatosAtributo != null) {
				return relProductoDatosAtributo;
			}
		}
		return null;
	}

	public Boolean isVisible(String id) {
		Matcher matcher = attributePattern.matcher(id);
		Short attributeId = null;
		Integer codigoDato = null;
		if (matcher.matches()) {
			attributeId = Short.parseShort(matcher.group(1));
			codigoDato = Integer.parseInt(matcher.group(2));
		} else {
			attributeId = Short.parseShort(id);
		}

		return isDisabled(attributeId, codigoDato);
	}

	private Boolean isDisabled(Short attributeId, Integer codigoDato) {
		if (esPanelBloqueado(attributeId)) {
			return true;
		}
		Set<RelProductoAtributo> set = relProductoAtributoMap.get(attributeId);
		if (set != null) {

			for (RelProductoAtributo relProductoAtributo : set) {
				// if(relProductoAtributo == null && attributeId==35){
				// relProductoAtributo = relProductoAtributoMap.get(new
				// Short("38"));
				// attributeId= 38;
				// }
				if (codigoDato == null) {
					return false;
				}
				Integer codigo = attributeId * 1000 + codigoDato;
				if (getRelProductoDatosAtributo(relProductoAtributo, codigo) != null) {
					return false;
				}
			}
		}
		if (attributeId == 35) {
			attributeId = 38;
			set = relProductoAtributoMap.get(attributeId);
			if (set == null) {
				return true;
			}
			for (RelProductoAtributo relProductoAtributo : set) {
				if (codigoDato == null) {
					return false;
				}
				Integer codigo = attributeId * 1000 + codigoDato;
				if (getRelProductoDatosAtributo(relProductoAtributo, codigo) != null) {
					return false;
				}
			}
		}
		return true;
	}

	private RelProductoDatosAtributo getRelProductoDatosAtributo(
			RelProductoAtributo relProductoAtributo, Integer codigoDato) {
		return entityManager
				.find(RelProductoDatosAtributo.class,
						new RelProductoDatosAtributoId(relProductoAtributo,
								codigoDato));
	}

	public Boolean isDisabled(String id) {
		Matcher matcher = attributePattern.matcher(id);
		Short attributeId = null;
		Integer codigoDato = null;
		if (matcher.matches()) {
			attributeId = Short.parseShort(matcher.group(1));
			codigoDato = Integer.parseInt(matcher.group(2));
		} else {
			attributeId = Short.parseShort(id);
		}

		// FLM en consulta deshabilitado
		if (BoletasStates.CONSULTA_BOLETA.equals(boletaState)
				&& !accesibleEnConsulta.contains(id)) {
			return true;
		} else {

			return isDisabled(attributeId, codigoDato);
		}
	}

	// FLM: Para cobrospago, debemos usar el disabled dependiendo de transaccion
	// Esto se calcula en el checkpanelesbloqueados panelesBloqueados.cobros
	private boolean esPanelBloqueado(Short attributeId) {
		switch (attributeId) {
		case 36:
			return panelesBloqueados.cobros;
		case 21:
			return panelesBloqueados.pagos;
		}
		return false;
	}

	public HashMap<String, RelProductoDatosAtributo> datosMap;

	@Out(required = false)
	private ArrayList<DescripcionTransaccionOperacion> productoTransacciones = null;

	@Out(required = false)
	private ArrayList<DescripcionFormula> productoFormulaCobro;
	@Out(required = false)
	private ArrayList<DescripcionFormula> productoFormulaPago;
	@Out(required = false)
	private ArrayList<DescripcionFormula> datosOpcionFormula;

	@Out(required = false, value = "productoTransaccionSeleccionadaList")
	private ArrayList<Producto> productoList;

	@Out(required = false, value = "ListaGrupoContable")
	private List<GrupoContable> listaGrupoContable;

	private String unidadSubyacente;

	@Out(required = false, scope = ScopeType.EVENT)
	private String codigoValidacionErroneo;
	private Divisa euroDivisa;
	@Out(required = false, scope = ScopeType.EVENT)
	private String codigoValidacionEsquemaErroneo;

	@Out(required = false, value = "ListaProductoTGR")
	private List<ProductoTgr> listaProductoTgrList;

	@Out(required = false, value = "ListaCanalEmisionConfirmacionAlta")
	private List<CanalConfirmacion> listaCanalConfirmacionEA;
	@Out(required = false, value = "ListaCanalEmisionConfirmacionModificacion")
	private List<CanalConfirmacion> listaCanalConfirmacionEM;
	@Out(required = false, value = "ListaCanalEmisionConfirmacionAnulacion")
	private List<CanalConfirmacion> listaCanalConfirmacionEN;
	@Out(required = false, value = "ListaCanalEmisionConfirmacionCancelacion")
	private List<CanalConfirmacion> listaCanalConfirmacionEC;
	@Out(required = false, value = "ListaCanalEmisionConfirmacionCancelacionParcial")
	private List<CanalConfirmacion> listaCanalConfirmacionEP;
	@Out(required = false, value = "ListaCanalEmisionConfirmacionLiquidacion")
	private List<CanalConfirmacion> listaCanalConfirmacionEX;
	@Out(required = false, value = "ListaCanalEmisionConfirmacionFijacion")
	private List<CanalConfirmacion> listaCanalConfirmacionEL;
	@Out(required = false, value = "ListaCanalRecepcionConfirmacionAlta")
	private List<CanalConfirmacion> listaCanalConfirmacionRA;
	@Out(required = false, value = "ListaCanalRecepcionConfirmacionModificacion")
	private List<CanalConfirmacion> listaCanalConfirmacionRM;
	@Out(required = false, value = "ListaCanalRecepcionConfirmacionAnulacion")
	private List<CanalConfirmacion> listaCanalConfirmacionRN;
	@Out(required = false, value = "ListaCanalRecepcionConfirmacionCancelacion")
	private List<CanalConfirmacion> listaCanalConfirmacionRC;
	@Out(required = false, value = "ListaCanalRecepcionConfirmacionCancelacionParcial")
	private List<CanalConfirmacion> listaCanalConfirmacionRP;
	@Out(required = false, value = "ListaCanalRecepcionConfirmacionLiquidacion")
	private List<CanalConfirmacion> listaCanalConfirmacionRX;
	@Out(required = false, value = "ListaCanalRecepcionConfirmacionFijacion")
	private List<CanalConfirmacion> listaCanalConfirmacionRL;

	@Out(required = false)
	private List<Idioma> listaIdiomaConfirmacionAlta;
	@Out(required = false)
	private List<Idioma> listaIdiomaConfirmacionN;
	@Out(required = false)
	private List<Idioma> listaIdiomaConfirmacionM;
	@Out(required = false)
	private List<Idioma> listaIdiomaConfirmacionL;
	@Out(required = false)
	private List<Idioma> listaIdiomaConfirmacionX;
	@Out(required = false)
	private List<Idioma> listaIdiomaConfirmacionP;
	@Out(required = false)
	private List<Idioma> listaIdiomaConfirmacionC;
	@Out(required = false)
	private List<DescripcionCanalLiquidacion> listaCanalLiquidacionPartida;
	@Out(required = false)
	private List<DescripcionCanalLiquidacion> listaCanalLiquidacionContrapartida;

	// tipo para condiciones de fijacion
	@Out(required = false)
	private PagoCobroType fijacionPagoCobroType;
	@Out(value = "ListaTipoOpcion", required = false)
	private List<DescripcionTipoOpcion> listaDescripcionTipoOpcion;

	public String getUnidadSubyacente() {
		return unidadSubyacente;
	}

	public void setUnidadSubyacente(String unidadSubyacente) {
		this.unidadSubyacente = unidadSubyacente;
	}

	public void fRangos() {
	}

	private void checkBloqueoPaneles() {
		// if (boletaState == BoletasStates.CONSULTA_BOLETA) {
		// checkBloqueoConsulta();
		// return;
		// }
		ProductoCatalogo productoCatalogo = historicoOperacion
				.getProductoCatalogo();
		RelProductoTransaccion currentRelProductoTransaccion = getRelProductoTransaccion();
		if (currentRelProductoTransaccion != null) {
			Integer numpatas = productoCatalogo.getNumpatas();
			String tipofluj = productoCatalogo.getTipofluj();
			String tppapago = currentRelProductoTransaccion.getTppapago();
			String tppareci = currentRelProductoTransaccion.getTppareci();
			if (tieneUnGrupo(numpatas, tipofluj)) {
				String flujoV = "V";
				String flujoF = "F";
				String flujoL = "L";
				if (numpatas != 1) {
					flujoV = "OV";
					flujoF = "OF";
					flujoL = "OL";

				}
				if (tipofluj.equals(flujoV)) {
					if (tppapago != null && tppapago.equals(FLU)) {
						// activa 21
						// ClasePago='V' protegido
						setIndicadorTipoPago(tipoClaseVariable);
						resetBloqueos(false, true);
					} else {
						if (tppareci != null && tppareci.equals(FLU)) {
							// activa 36
							// ClasePago='V' protegido
							setIndicadorTipoRecibo(tipoClaseVariable);
							resetBloqueos(true, false);
						}
					}
				}
				if (tipofluj.equals(flujoF)) {
					if (tppapago != null && tppapago.equals(FLU)) {
						// activa 22
						// ClasePago='F' protegido
						setIndicadorTipoPago(tipoClaseFijo);
						resetBloqueos(false, true);

					} else {
						if (tppareci != null && tppareci.equals(FLU)) {
							// activa 37
							// ClasePago='F' protegido
							setIndicadorTipoRecibo(tipoClaseFijo);
							resetBloqueos(true, false);
						}
					}
				}

				if (tipofluj.equals(flujoL)) {
					if (tppapago != null && tppapago.equals(FLU)) {
						// activa 21
						// ClasePago='V' NO protegido
						setIndicadorTipoPago(tipoClaseVariable);
						resetBloqueos(false, true);
						getPanelesBloqueados().setClasePago(false);
					} else {
						if (tppareci != null && tppareci.equals(FLU)) {
							// activa 36
							// ClasePago='V' NO protegido
							setIndicadorTipoRecibo(tipoClaseVariable);
							resetBloqueos(true, false);
							getPanelesBloqueados().setClaseCobro(false);

						}
					}
				}
			} else {
				if (tipofluj.equals("VV")) {
					if (tppapago != null && tppapago.equals(FLU)) {
						setIndicadorTipoPago(tipoClaseVariable);
						resetBloqueos(false, true);
					}
					if (tppareci != null && tppareci.equals(FLU)) {
						setIndicadorTipoRecibo(tipoClaseVariable);
						resetBloqueos(true, false);
					}
				} else {
					Boolean activaPago = true;
					Boolean activaCobro = true;
					if (tppapago != null && tppapago.equals(FLU)) {
						setIndicadorTipoPago(tipoClaseVariable);
						activaPago = false;
					}
					if (tppareci != null && tppareci.equals(FLU)) {
						setIndicadorTipoRecibo(tipoClaseVariable);
						activaCobro = false;
					}
					resetBloqueos(activaPago, activaCobro);
					getPanelesBloqueados().setClasePago(false);
					getPanelesBloqueados().setClaseCobro(false);

				}
			}

		} else {
			resetBloqueos(true, true);
		}
		// return ((esAlta() && ((transaccion.getValue()==null)|| pagos))||
		// (boletaState == BoletasStates.MODI_BOLETA) && pagos);
		// return ((esAlta() && ((transaccion.getValue()==null)|| cobros))||
		// (boletaState == BoletasStates.MODI_BOLETA) && cobros);

		checkBloqueoAlta();
		checkBloqueoModificacion();
		checkBloqueoConfirmaciones(false);
		checkBloqueosClaseCobro();
		checkBloqueosClasePago();
		checkBloqueoDatosOpcion();
		checkCobrosPagosSimple();
		checkBloqueosModelo();

	}

	private void checkBloqueosPrimas() {
		boolean esCFC = "CFC".equals(historicoOperacion.getProductoCatalogo()
				.getModelpro().getModelpro())
				&& (pagoCobroType == PagoCobroType.ES_COBRO || pagoCobroType == PagoCobroType.ES_PAGO);

		boolean esOPCDiv = false;
		if (!GenericUtils.isNullOrBlank(historicoOperacion
				.getProductoCatalogo().getProdtrat()))
			esOPCDiv = "S".equals(GenericUtils.nvl(historicoOperacion
					.getProductoCatalogo().getProdtrat().getChkopcdiv(), "N"))// En
																				// las
																				// FX
																				// Options,
																				// Para
																				// las
																				// COMCALL
																				// y
																				// COMPUT,
																				// las
																				// primas
																				// up
																				// front
																				// deberían
																				// ser
																				// siempre
																				// de
																				// pago
					&& (pagoCobroType == PagoCobroType.ES_COBRO || pagoCobroType == PagoCobroType.ES_PAGO);

		panelesBloqueados.setUpFrontCobroPago(historicoOperacion
				.getIndicadorPrimaUpFront()
				&& (esCFC || esOPCDiv));
		panelesBloqueados.setPeriodicaCobroPago(historicoOperacion
				.getIndicadorPrimaUpPeriodica()
				&& esCFC);
	}

	// FLM:bloqueo e inicialización si la operación es del tipo modelo
	private void checkBloqueosModelo() {
		if ((BoletasStates.ALTA_BOLETA == boletaState || BoletasStates.MODI_BOLETA == boletaState)
				&& historicoOperacion.getIndicadorOperacionModelo()) {
			panelesBloqueados.setConfirmaciones(true);

			if (hasAttribute(2)) {
				panelesBloqueados.setModelo2(true);
			}
			if (hasAttribute(3)) {
				panelesBloqueados.setModelo3(true);
			}

			boolean esRad = false;
			try {
				if (historicoOperacion.getProducto() != null
						&& ("R".equals(historicoOperacion.getProducto()
								.getIndPasarelaRad()) || "M"
								.equals(historicoOperacion.getProducto()
										.getIndPasarelaRad())))
					esRad = true;
			} catch (Exception e) {
				log.error("Error con getproducto nulo en checkmodelo.", e);
			}
			panelesBloqueados.setModeloRad(false);
			panelesBloqueados.setModeloNoRad(false);

			if (esRad) {
				panelesBloqueados.setModeloRad(true);
			} else {
				panelesBloqueados.setModeloNoRad(true);
			}
		}
	}

	private void initModelo() {
		// :Validar que se bloquean los modelos
		if (boletaState == BoletasStates.ALTA_BOLETA
				&& historicoOperacion.getIndicadorOperacionModelo()) {
			boolean esRad = false;
			try {
				if (historicoOperacion.getProducto() != null
						&& ("R".equals(historicoOperacion.getProducto()
								.getIndPasarelaRad()) || "M"
								.equals(historicoOperacion.getProducto()
										.getIndPasarelaRad())))
					esRad = true;
			} catch (Exception e) {
				log.error("Error con getproducto nulo en checkmodelo.", e);
			}

			// Inicializar
			if (hasAttribute(2)) {
				historicoOperacion.setDealNumber(null);
				historicoOperacion.setDealType("XXX");
			}
			if (hasAttribute(3)) {
				historicoOperacion.setComponenteMurex(null);
				historicoOperacion.setClaveMurex(null);
				historicoOperacion.setVersionMurex(null);
			}
			historicoOperacion.setIndicadorBSAgente(false);
			// RAD = Indicador pasarela RAD
			if (!esRad) {
				if (grupoContableXX == null) {
					grupoContableXX = entityManager.find(GrupoContable.class,
							new GrupoContableId("XX", historicoOperacion
									.getProducto()));
				}
				historicoOperacion.setGrupoContable(grupoContableXX);
			} else {

				DescripcionTipoCobertura codigoCoberturaIn = (DescripcionTipoCobertura) entityManager
						.find(DescripcionTipoCobertura.class, "IN");
				historicoOperacion.setCodigoCobertura(codigoCoberturaIn);// TipoCobertura("IN"
																			// )
																			// ;
			}
			if (contrapartidaModelo == null) {
				contrapartidaModelo = entityManager.find(
						AbstractContrapartida.class, "MODELO");
			}
			historicoOperacion.setContrapartida(contrapartidaModelo);
			if (contrapaDelegate != null) {
				contrapaDelegate.refresh();
			}
			// FLM: Esto lo hace el init a posteriori
			// contrapaDelegate.refresh();
			persistir();
		}
	}

	private void checkBloqueoDatosOpcion() {
		panelesBloqueados
				.setDatosOpcion(!(esDatosOpcionCobro() || esDatosOpcionPago()));
		if (historicoOperacion.getHistoricoOpcion() != null
				&& entityUtil.checkEntityExists(historicoOperacion
						.getHistoricoOpcion().getTipoOpcion())
				&& "N".equals(historicoOperacion.getHistoricoOpcion()
						.getTipoOpcion().getCodigo())) {
			panelesBloqueados.setFechaPayoff(true);
		}
		if (estiloOpcion != null && estiloOpcion.getValue() != null
				&& "A".equalsIgnoreCase(estiloOpcion.getValue().getCodigo())) {
			// Proteger botones f. ej y f. obs.
			panelesBloqueados.setFechaEjercicio(true);
			panelesBloqueados.setFechaObserv(true);
		} else {
			panelesBloqueados.setFechaEjercicio(false);
			panelesBloqueados.setFechaObserv(false);
		}
	}

	private void checkCobrosPagosSimple() {
		panelesBloqueados.setCobrosPagosSimple(!entityUtil
				.checkEntityExists(historicoOperacion.getTransaccion()));
	}

	private void checkBloqueoConsulta() {
		resetBloqueos(true, true);
	}

	private void checkBloqueoModificacion() {
		if (boletaState == BoletasStates.MODI_BOLETA) {
			getPanelesBloqueados().setTransaccion(true);
		}
	}

	private void checkBloqueoAlta() {
		// if (esAlta() && getTransaccion().getValue() == null) {
		// getPanelesBloqueados().setPagos(true);
		// getPanelesBloqueados().setCobros(true);
		// }
	}

	private void checkBloqueoConfirmaciones(boolean checkCampos) {
		AbstractContrapartida contrapartida = historicoOperacion
				.getContrapartida();
		if (contrapartida == null) {
			getPanelesBloqueados().setConfirmaciones(true);
		} else {
			// VALOR POR DEFECTO DE IDIOMA
			// Obtenemos la contrapartida
			if (checkCampos) {
				checkCamposConfirmaciones(contrapartida);
			}
		}

	}

	private void checkCamposConfirmaciones(AbstractContrapartida contrapartida) {
		AbstractContrapartida aContrapa = entityUtil.unwrapProxy(contrapartida,
				AbstractContrapartida.class);
		Contrapartida contrapa = null;

		// SMM 1909 Si grupo contable XX no validar

		if (historicoOperacion.getGrupoContable() != null
				&& "XX".equalsIgnoreCase(historicoOperacion.getGrupoContable()
						.getId().getGrupoContable())) {

			return;

		}
		if (historicoOperacion.getCodigoCobertura() != null
				&& "IN".equalsIgnoreCase(historicoOperacion
						.getCodigoCobertura().getCodigo()))
			return;

		if (!(aContrapa instanceof Contrapartida)) {
			statusMessages.add(Severity.ERROR,
					"Esta contrapartida no tiene tipo contrapartida asociado");
			return;
		}

		contrapa = (Contrapartida) aContrapa;
		if (hasConfirmacionesTab()) {
			initListasConfirmaciones();

			setCamposConfirmacion(indicadorConfirmacion
					.getIndicadorConfirmacionAlta(), indicadorConfirmacion
					.getIndicadorRecepcionConfirmacionAlta(), contrapa,
					listaIdiomaConfirmacionAlta, listaCanalConfirmacionEA,
					listaCanalConfirmacionRA, "A");
			setCamposConfirmacion(indicadorConfirmacion
					.getIndicadorConfirmacionModificacion(),
					indicadorConfirmacion
							.getIndicadorRecepcionConfirmacionModificacion(),
					contrapa, listaIdiomaConfirmacionM,
					listaCanalConfirmacionEM, listaCanalConfirmacionRM, "M");
			setCamposConfirmacion(indicadorConfirmacion
					.getIndicadorConfirmacionAnulacion(), indicadorConfirmacion
					.getIndicadorRecepcionConfirmacionAnulacion(), contrapa,
					listaIdiomaConfirmacionN, listaCanalConfirmacionEN,
					listaCanalConfirmacionRN, "N");
			setCamposConfirmacion(indicadorConfirmacion
					.getIndicadorConfirmacionCancelacion(),
					indicadorConfirmacion
							.getIndicadorRecepcionConfirmacionCancelacion(),
					contrapa, listaIdiomaConfirmacionC,
					listaCanalConfirmacionEC, listaCanalConfirmacionRC, "C");
			setCamposConfirmacion(
					indicadorConfirmacion
							.getIndicadorConfirmacionCancelacionParcial(),
					indicadorConfirmacion
							.getIndicadorRecepcionConfirmacionCancelacionParcial(),
					contrapa, listaIdiomaConfirmacionP,
					listaCanalConfirmacionEP, listaCanalConfirmacionRP, "P");
			setCamposConfirmacion(indicadorConfirmacion
					.getIndicadorConfirmacionLiquidacion(),
					indicadorConfirmacion
							.getIndicadorRecepcionConfirmacionLiquidacion(),
					contrapa, listaIdiomaConfirmacionX,
					listaCanalConfirmacionEX, listaCanalConfirmacionRX, "X");
			setCamposConfirmacion(indicadorConfirmacion
					.getIndicadorConfirmacionFijacion(), indicadorConfirmacion
					.getIndicadorRecepcionConfirmacionFijacion(), contrapa,
					listaIdiomaConfirmacionL, listaCanalConfirmacionEL,
					listaCanalConfirmacionRL, "L");

			if (!BoletasStates.CONSULTA_BOLETA.equals(this.boletaState)
					&& historicoOperacion.getUltimaAccion() != null
					&& "A".equalsIgnoreCase(historicoOperacion
							.getUltimaAccion().getCodigo())
					&& historicoOperacion.getEstado() != null
					&& "IN".equalsIgnoreCase(historicoOperacion.getEstado()
							.getCodigo())) {
				confirmacionesOpcionDivisas();
			}

		}
	}

	private void initListasConfirmaciones() {
		if (listaIdiomaConfirmacionAlta == null) {
			initIdiomaConfirmacionAlta();
		}
		if (listaIdiomaConfirmacionM == null) {
			initIdiomaConfirmacionM();
		}
		if (listaIdiomaConfirmacionC == null) {
			initIdiomaConfirmacionC();
		}
		if (listaIdiomaConfirmacionP == null) {
			initIdiomaConfirmacionP();
		}
		if (listaIdiomaConfirmacionX == null) {
			initIdiomaConfirmacionX();
		}
		if (listaIdiomaConfirmacionN == null) {
			initIdiomaConfirmacionN();
		}
		if (listaIdiomaConfirmacionL == null) {
			initIdiomaConfirmacionL();
		}
		if (listaCanalConfirmacionEA == null) {
			initListCanalEmisionConfirmacionAlta();
		}
		if (listaCanalConfirmacionEM == null) {
			initListCanalEmisionConfirmacionModificacion();
		}
		if (listaCanalConfirmacionEN == null) {
			initListCanalEmisionConfirmacionAnulacion();
		}
		if (listaCanalConfirmacionEC == null) {
			initListCanalEmisionConfirmacionCancelacion();
		}
		if (listaCanalConfirmacionEP == null) {
			initListCanalEmisionConfirmacionCancelacionParcial();
		}
		if (listaCanalConfirmacionEX == null) {
			initListCanalEmisionConfirmacionLiquidacion();
		}
		if (listaCanalConfirmacionEL == null) {
			initListCanalEmisionConfirmacionFijacion();
		}
		if (listaCanalConfirmacionRA == null) {
			initListCanalRecepcionConfirmacionAlta();
		}
		if (listaCanalConfirmacionRM == null) {
			initListCanalRecepcionConfirmacionModificacion();
		}
		if (listaCanalConfirmacionRN == null) {
			initListCanalRecepcionConfirmacionAnulacion();
		}
		if (listaCanalConfirmacionRC == null) {
			initListCanalRecepcionConfirmacionCancelacion();
		}
		if (listaCanalConfirmacionRP == null) {
			initListCanalRecepcionConfirmacionCancelacionParcial();
		}
		if (listaCanalConfirmacionRX == null) {
			initListCanalRecepcionConfirmacionLiquidacion();
		}
		if (listaCanalConfirmacionRL == null) {
			initListCanalRecepcionConfirmacionFijacion();
		}
	}

	private void setCamposConfirmacion(Boolean indicadorE, Boolean indicadorR,
			Contrapartida contrapa, List<Idioma> listaIdioma,
			List<CanalConfirmacion> listaCanalEmision,
			List<CanalConfirmacion> listaCanalRecepcion, String modo) {
		// Buscamos el idioma de la contrapa en la lista de idiomas
		String contrapaIdioma = contrapa.getIdioma();
		Idioma idiomaCMOF = boletasBo.recuperarIdiomaCMOF(contrapa,
				historicoOperacion.getEntidad());
		boolean idiomaFound = false;
		Idioma castellano = null;
		Idioma idiomaContrapa = null;
		if (listaIdioma != null) {
			for (Iterator<Idioma> iterator = listaIdioma.iterator(); iterator
					.hasNext();) {
				Idioma idioma = (Idioma) iterator.next();
				String codigoIdioma = idioma.getCodigo();
				if ("08".equalsIgnoreCase(codigoIdioma)) {
					// Guardamos el idioma castellano por ser el valor
					// por defecto en el caso de no encontrar el idioma
					castellano = idioma;
				}

				// SMM 31/03/2017 Idioma CMOF
				if (!GenericUtils.isNullOrBlank(idiomaCMOF)
						&& codigoIdioma
								.equalsIgnoreCase(idiomaCMOF.getCodigo())) {
					setIdiomasConfirmacion(idioma, modo);
					idiomaFound = true;
					break;
				}

				if (codigoIdioma.equalsIgnoreCase(contrapaIdioma)) {
					idiomaContrapa = idioma;
				}
			}
		}

		if (!idiomaFound && indicadorE != null && indicadorE) {
			if (GenericUtils.isNullOrBlank(idiomaContrapa)) {
				setIdiomasConfirmacion(castellano, modo);
			} else {
				setIdiomasConfirmacion(idiomaContrapa, modo);
			}
			// Informamos el canal a MM
		}
		// if(indicadorE!=null && indicadorE){
		// CanalConfirmacion canalMM = buscaCanal(listaCanalEmision, "MM");
		// setCanalesEmisionConfirmacion(canalMM,modo);
		// }
		// : Proteger campo de pantalla canal
		// VALOR POR DEFECTO DE CANAL CONTRATACION (EMISION Y RECEPCION)
		// SMM 31/03/2014 CANAL POR DEFECTO
		String sentido;
		if (indicadorE != null && indicadorE) {
			sentido = "E";
		} else {
			sentido = "R";
		}
		// CanalConfDefecto canalConfDefecto =
		// cargarCanalConfDefecto(contrapa.getId(),
		// historicoOperacion.getProductoCatalogo().getProducat().toString(),
		// modo);
		CanalConfDefecto canalConfDefecto; // =
											// cargarCanalConfDefecto(contrapa.getId(),
											// historicoOperacion.getProductoCatalogo().getProducat().toString(),
											// modo,sentido,getTipoContr());

		// if(canalConfDefecto != null) {
		String codigoCanal; // = canalConfDefecto.getCodcanal();

		// if(idiomaFound && indicadorE!=null && indicadorE) {
		if (indicadorE != null && indicadorE) {

			sentido = "E";

			canalConfDefecto = cargarCanalConfDefecto(contrapa.getId(),
					historicoOperacion.getProductoCatalogo().getProducat()
							.toString(), modo, sentido, getTipoContr());

			if (canalConfDefecto != null) {

				codigoCanal = canalConfDefecto.getCodcanal();

				// Si hemos encontrado idioma, tenemos que setear un canal
				// en caso contrario ya lo hemos seteado a "MM"
				CanalConfirmacion canal = buscaCanal(listaCanalEmision,
						codigoCanal);
				if (canal == null) {
					canal = buscaCanal(listaCanalEmision, "MM");
				}
				setCanalesEmisionConfirmacion(canal, modo);

			} else {
				// No hemos encontrado canal por defecto
				CanalConfirmacion canal = buscaCanal(listaCanalEmision, "MM");
				setCanalesEmisionConfirmacion(canal, modo);
				setIdiomasConfirmacion(null, modo);
			}

		}
		if (indicadorR != null && indicadorR) {
			sentido = "R";

			canalConfDefecto = cargarCanalConfDefecto(contrapa.getId(),
					historicoOperacion.getProductoCatalogo().getProducat()
							.toString(), modo, sentido, getTipoContr());

			if (canalConfDefecto != null) {

				codigoCanal = canalConfDefecto.getCodcanal();

				CanalConfirmacion canal = buscaCanal(listaCanalRecepcion,
						codigoCanal);
				if (canal == null) {
					canal = buscaCanal(listaCanalRecepcion, "MM");
				}
				setCanalesRecepcionConfirmacion(canal, modo);

			} else {
				// No hemos encontrado canal por defecto
				CanalConfirmacion canal = buscaCanal(listaCanalRecepcion, "MM");
				setCanalesRecepcionConfirmacion(canal, modo);
				// setIdiomasConfirmacion(null,modo);
			}

		}
		// } else {
		// if(idiomaFound && indicadorE!=null && indicadorE) {
		// if(indicadorE!=null && indicadorE) {
		// Si hemos encontrado idioma, tenemos que setear un canal
		// en caso contrario ya lo hemos seteado a "MM"
		// CanalConfirmacion canal = buscaCanal(listaCanalEmision, "MM");
		// setCanalesEmisionConfirmacion(canal,modo);
		// }
		// if(indicadorR!=null && indicadorR){
		// CanalConfirmacion canal = buscaCanal(listaCanalRecepcion, "MM");
		// setCanalesRecepcionConfirmacion(canal,modo);
		// }
		// : Proteger campo de pantalla canal

		// setIdiomasConfirmacion(null,modo);
		// : Proteger campo de pantalla idioma
		// }
	}

	private void setCanalesRecepcionConfirmacion(CanalConfirmacion value,
			String modo) {
		if ("A".equalsIgnoreCase(modo)
				&& indicadorConfirmacion.getCanelRecepcionConfirmacionAlta() == null) {
			indicadorConfirmacion.setCanelRecepcionConfirmacionAlta(value);
		} else if ("M".equalsIgnoreCase(modo)
				&& indicadorConfirmacion
						.getCanelRecepcionConfirmacionModificacion() == null) {
			indicadorConfirmacion
					.setCanelRecepcionConfirmacionModificacion(value);
		} else if ("N".equalsIgnoreCase(modo)
				&& indicadorConfirmacion
						.getCanelRecepcionConfirmacionAnulacion() == null) {
			indicadorConfirmacion.setCanelRecepcionConfirmacionAnulacion(value);
		} else if ("C".equalsIgnoreCase(modo)
				&& indicadorConfirmacion
						.getCanelRecepcionConfirmacionCancelacion() == null) {
			indicadorConfirmacion
					.setCanelRecepcionConfirmacionCancelacion(value);
		} else if ("P".equalsIgnoreCase(modo)
				&& indicadorConfirmacion
						.getCanelRecepcionConfirmacionCancelacionParcial() == null) {
			indicadorConfirmacion
					.setCanelRecepcionConfirmacionCancelacionParcial(value);
		} else if ("X".equalsIgnoreCase(modo)
				&& indicadorConfirmacion
						.getCanelRecepcionConfirmacionLiquidacion() == null) {
			indicadorConfirmacion
					.setCanelRecepcionConfirmacionLiquidacion(value);
		} else if ("L".equalsIgnoreCase(modo)
				&& indicadorConfirmacion
						.getCanelRecepcionConfirmacionFijacion() == null) {
			indicadorConfirmacion.setCanelRecepcionConfirmacionFijacion(value);
		}
	}

	private void setCanalesEmisionConfirmacion(CanalConfirmacion value,
			String modo) {
		if ("A".equalsIgnoreCase(modo)
				&& indicadorConfirmacion.getCanelEmisionConfirmacionAlta() == null) {
			indicadorConfirmacion.setCanelEmisionConfirmacionAlta(value);
		} else if ("M".equalsIgnoreCase(modo)
				&& indicadorConfirmacion
						.getCanelEmisionConfirmacionModificacion() == null) {
			indicadorConfirmacion
					.setCanelEmisionConfirmacionModificacion(value);
		} else if ("N".equalsIgnoreCase(modo)
				&& indicadorConfirmacion.getCanelEmisionConfirmacionAnulacion() == null) {
			indicadorConfirmacion.setCanelEmisionConfirmacionAnulacion(value);
		} else if ("C".equalsIgnoreCase(modo)
				&& indicadorConfirmacion
						.getCanelEmisionConfirmacionCancelacion() == null) {
			indicadorConfirmacion.setCanelEmisionConfirmacionCancelacion(value);
		} else if ("P".equalsIgnoreCase(modo)
				&& indicadorConfirmacion
						.getCanelEmisionConfirmacionCancelacionParcial() == null) {
			indicadorConfirmacion
					.setCanelEmisionConfirmacionCancelacionParcial(value);
		} else if ("X".equalsIgnoreCase(modo)
				&& indicadorConfirmacion
						.getCanelEmisionConfirmacionLiquidacion() == null) {
			indicadorConfirmacion.setCanelEmisionConfirmacionLiquidacion(value);
		} else if ("L".equalsIgnoreCase(modo)
				&& indicadorConfirmacion.getCanelEmisionConfirmacionFijacion() == null) {
			indicadorConfirmacion.setCanelEmisionConfirmacionFijacion(value);
		}
	}

	private void setIdiomasConfirmacion(Idioma value, String modo) {
		if ("A".equalsIgnoreCase(modo)
				&& indicadorConfirmacion.getIdiomaConfirmacionAlta() == null) {
			indicadorConfirmacion.setIdiomaConfirmacionAlta(value);
		} else if ("M".equalsIgnoreCase(modo)
				&& indicadorConfirmacion.getIdiomaConfirmacionModificacion() == null) {
			indicadorConfirmacion.setIdiomaConfirmacionModificacion(value);
		} else if ("N".equalsIgnoreCase(modo)
				&& indicadorConfirmacion.getIdiomaConfirmacionAnulacion() == null) {
			indicadorConfirmacion.setIdiomaConfirmacionAnulacion(value);
		} else if ("C".equalsIgnoreCase(modo)
				&& indicadorConfirmacion.getIdiomaConfirmacionCancelacion() == null) {
			indicadorConfirmacion.setIdiomaConfirmacionCancelacion(value);
		} else if ("P".equalsIgnoreCase(modo)
				&& indicadorConfirmacion
						.getIdiomaConfirmacionCancelacionParcial() == null) {
			indicadorConfirmacion
					.setIdiomaConfirmacionCancelacionParcial(value);
		} else if ("X".equalsIgnoreCase(modo)
				&& indicadorConfirmacion.getIdiomaConfirmacionLiquidacion() == null) {
			indicadorConfirmacion.setIdiomaConfirmacionLiquidacion(value);
		} else if ("L".equalsIgnoreCase(modo)
				&& indicadorConfirmacion.getIdiomaConfirmacionFijacion() == null) {
			indicadorConfirmacion.setIdiomaConfirmacionFijacion(value);
		}
	}

	private void setIndicadorTipoRecibo(DescripcionClaseInt tipoClase) {
		if (boletaState == BoletasStates.ALTA_BOLETA
				&& historicoOperacion.getIndicadorTipoRecibo() == null) {
			historicoOperacion.setIndicadorTipoRecibo(tipoClase);
		}
	}

	private void setIndicadorTipoPago(DescripcionClaseInt tipoClase) {
		if (boletaState == BoletasStates.ALTA_BOLETA
				&& historicoOperacion.getIndicadorTipoPago() == null) {
			historicoOperacion.setIndicadorTipoPago(tipoClase);
		}
	}

	private Boolean tieneUnGrupo(Integer numpatas, String tipofluj) {
		return numpatas == 1 || (numpatas == 2 && tipofluj.startsWith("O"));
	}

	private RelProductoTransaccion getRelProductoTransaccion() {
		Set<RelProductoTransaccion> transSet = historicoOperacion
				.getProductoCatalogo().getProductoTransacciones();
		for (RelProductoTransaccion relProductoTransaccion : transSet) {
			if (relProductoTransaccion.getId().getTranoper().equals(
					historicoOperacion.getTransaccion())) { // getTransaccion().getValue()
				return relProductoTransaccion;
			}
		}
		return null;
	}

	/**
	 * Al salir del campo, si check 1 er Tr marcado, poner misma fecha en ‘F.
	 * Inicio’ de la pantalla de Datos 1er Tramo Irregular correspondiente
	 */
	public void onFechaValorBlur() {
		if (historicoOperacion.getIndTramoIrregularRecibo()) {
			historicoOperacion.setInicioTramoIrregularRecibo(historicoOperacion
					.getFechaValor());
		}
		if (historicoOperacion.getIndTramoIrregularPago()) {
			historicoOperacion.setInicioTramoIrregularPago(historicoOperacion
					.getFechaValor());
		}
		// errorMessageBoxAction.setReRender("fValorDecorate");
	}

	public void onTipoCoberturaChange() {
		if (EsTipoCoberturaIn()) {// historicoOperacion.getTipoCobertura() !=
									// null &&
									// TIPO_COBERTURA_IN.equals(historicoOperacion.getTipoCobertura()))
									// {
			doActualizaCanales();
		}
	}

	public void onSibisAplicacionChange() {
		if (GenericUtils.isNullOrBlank(historicoOperacion.getAplicacionSibis())) {
			historicoOperacion.setContratoSibis(null);
			historicoOperacion.setEntidadSibis(null);
		}
	}

	/**
	 * Si seleccionan ‘N’ : Si hay F. Pay Off informadas
	 * (F_NUM_FECHAS_TIPO('PO')>0) se avisa que se van a borrar y si aceptan se
	 * borran (P_BORRAR_FECHAS … ‘PO’), si no aceptan se debe volver a dejar el
	 * valor existente antes del cambio se protege el botón ‘F. Pay Off’ Si
	 * seleccionan ‘D’: si hay más de 1 F.Pay Off informada
	 * (F_NUM_FECHAS_TIPO('PO')>1)se avisa que se van a borrar y si aceptan se
	 * borran (P_BORRAR_FECHAS … ‘PO’), si no aceptan se debe volver a dejar el
	 * valor existente antes del cambio si el botón F. Pay Off está protegido se
	 * desprotege Si seleccionan ‘D’: si el botón F. Pay Off está protegido se
	 * desprotege
	 */
	public void onTipoOpcionChange() {
		if (historicoOperacion.getHistoricoOpcion().getTipoOpcion() == null) {
			if (hayFechasTipo("PO")) {
				messageBoxAction.init(
						"boletas.messageBox.cambio.tipoOpcion.borrar.fechas",
						"boletasAction.onMessageBoxBorrarFechasPayoffOk()",
						"boletasAction.onMessageBoxBorrarFechasPayoffKo()");
				return;
			}
		} else {

			if ("N".equals(historicoOperacion.getHistoricoOpcion()
					.getTipoOpcion().getCodigo())) {
				if (hayFechasTipo("PO")) {
					messageBoxAction
							.init(
									"boletas.messageBox.cambio.tipoOpcion.borrar.fechas",
									"boletasAction.onMessageBoxBorrarFechasPayoffOk()",
									"boletasAction.onMessageBoxBorrarFechasPayoffKo()");
					return;
				}
				panelesBloqueados.setFechaPayoff(true);
				return;
			}
			if ("D".equals(historicoOperacion.getHistoricoOpcion()
					.getTipoOpcion().getCodigo())) {
				if (numeroFechasTipo("PO") > 1) {
					messageBoxAction.init(
							"boletas.messageBox.cambio.estilo.borrar.fechas",
							"boletasAction.onMessageBoxBorrarFechasPayoffOk()",
							"boletasAction.onMessageBoxBorrarFechasPayoffKo()");
					return;
				}

			}
			panelesBloqueados.setFechaPayoff(false);

		}
	}

	public String onMessageBoxBorrarFechasPayoffOk() {
		Set<HistoricoFechaFormula> fechas = historicoOperacion
				.getHistoricoFechasFormulas();
		if (fechas != null) {
			if (borrarFechasTipo(fechas, "PO"))
				persistir();
		}
		if ("N".equals(historicoOperacion.getHistoricoOpcion().getTipoOpcion()
				.getCodigo())) {
			panelesBloqueados.setFechaPayoff(true);
		} else {
			panelesBloqueados.setFechaPayoff(false);
		}
		return "";
	}

	public String onMessageBoxBorrarFechasPayoffKo() {
		tipoOpcion.reset();
		return "";
	}

	/**
	 * Puede generar cambios en la pestaña de Cobros/Pagos (ver anexo
	 * correspondiente), en las asignaciones realizadas en pestaña Datos Opción
	 * y otras. Si ya se ha entrado información de la operación (la selección
	 * anterior <> null), se muestra un aviso ‘Esta acción provocará que se
	 * limpien s los datos de la operación. ¿Desea continuar?’ Si contestan N,
	 * se vuelve a dejar la selección anterior Si contestan S, se limpian s los
	 * datos
	 */
	// DEPRECATED: se informa en el alta
	// public void onTransactionChange() {
	// // : Completar
	// if (getTransaccion().getOldValue() != null &&
	// getTransaccion().getChanged()) {
	// messageBoxAction.init("boletas.messageBox.cambio.transaccion",
	// "boletasAction.onMessageBoxTransaccionOk()",
	// "boletasAction.onMessageBoxTransaccionKo()");
	// // messageBoxAction.init("boletas.messageBox.cambio.formula",
	// // "boletasAction.onMessageBoxOk()",
	// // "boletasAction.onMessageBoxKo()");
	// return;
	// }
	// checkBloqueoPaneles();
	// listaGrupoContable=null;
	// initListaProducto();
	// }

	// FLM: Si se modifica el tipo barrera
	/*
	 * - Al cambiar la selección:  Si seleccionan No aplica (NA) y el producto
	 * tiene el atributo de barreras (11) como obligatorio mostrar error ‘Es
	 * obligatorio seleccionar un tipo de Barrera’  Sino • Si seleccionan No
	 * aplica (NA), y hay barreras entradas mostrar mensaje ‘Esta acción borrará
	 * las barreras ¿desea continuar? S/N. Si contestan N, se vuelve a la
	 * selección anterior. Si contestan S, se borran s las barreras
	 * (deri.histbarr) para la operación (ncorrela, fechaope, fechatra,
	 * feultact) correspondiente
	 */
	public void onTipoBarreraChange() {
		String modo = "";
		if (historicoOperacion.getHistoricoOpcion().getModobarr() != null)
			modo = historicoOperacion.getHistoricoOpcion().getModobarr()
					.getCodigo();
		if (hasAttributeAndIsObligated(11) && "NA".equalsIgnoreCase(modo)) {
			addMessage("boletas.error.tipobarrera.requerido");
		}
		if ("NA".equalsIgnoreCase(modo)) {
			messageBoxAction.init("boletas.error.tipobarrera.borrarbarreras",
					"boletasAction.onTipoBarreraOk()",
					"boletasAction.onTipoBarreraKo()");
		}
		return;
	}

	public void onTipoBarreraOk() {
		// FLM: Ojo, borramos todas las barreras !!!!
		if (historicoOperacion.getHistoricoBarreras() != null
				&& historicoOperacion.getHistoricoBarreras().size() > 0) {

			// for (HistoricoBarrera barrera :
			// historicoOperacion.getHistoricoBarreras()) {
			//				  
			// Iterator<HistoricoSubyacente> it =
			// historicoOperacion.getHistoricoSubyacentes().iterator();
			// while (it.hasNext()) {
			// HistoricoSubyacente subyacente = it.next();
			// if
			// (barrera.getId().getTipbarp1().equalsIgnoreCase(subyacente.getId().getTiposuby())){
			// it.remove(); // avoids a ConcurrentModificationException
			// }
			// }
			// }

			Iterator<HistoricoSubyacente> it = historicoOperacion
					.getHistoricoSubyacentes().iterator();
			while (it.hasNext()) {
				HistoricoSubyacente subyacente = it.next();
				if (!"OP".equalsIgnoreCase(subyacente.getId().getTiposuby())) {
					it.remove(); // avoids a ConcurrentModificationException
				}
			}
			historicoOperacion.getHistoricoBarreras().clear();
			persistir();
		}
	}

	public void onTipoBarreraKo() {
		// El wrapper con el reset vuelve al valor anterior
		modobarrera.reset();
	}

	// DEPRECATED: se informa antes y queda fijo
	// public void onMessageBoxTransaccionOk() {
	// //: comprovar
	// checkBloqueoPaneles();
	// //productoList = null;
	// //Aquí lo tenemos que hacer, puesto que si se selecciona un prod. oper
	// automaticamente
	// //se debe actualiar el grupo cont
	// listaGrupoContable=null;
	// initListaProducto();
	// }
	//
	// public void onMessageBoxTransaccionKo() {
	// getTransaccion().reset();
	// checkBloqueoPaneles();
	// productoList = null;
	// listaGrupoContable=null;
	// }

	/**
	 * Al seleccionar un producto (o si se pone como protegido porque sólo hay
	 * una opción, se debe acceder a la tabla gestio_tressoreria.producto (para
	 * producto = al producto oper. seleccionado, si campo INPASRAS = ‘R’ se
	 * limpia y protege Grupo Cont. y se desprotegen Tipo Cobert., Tipo Riesgo y
	 * Cob A/P; sino debe estar Grupo Cont. desprotegido y Tipo Cobert., Tipo
	 * Riesgo y Cob A/P limpios y protegidos) se restablecerán, si corresponde
	 * (si Grupo Cont desprotegido), los valores permitidos en Grupo Cont.
	 */
	public void onProductoOperChange() {
		listaGrupoContable = null;
		if (historicoOperacion.getProducto() != null)
			if ("R".equalsIgnoreCase(historicoOperacion.getProducto()
					.getIndPasarelaRad())
					|| "M".equalsIgnoreCase(historicoOperacion.getProducto()
							.getIndPasarelaRad())) {
				historicoOperacion.setGrupoContable(null);
			} else {
				// Lo forzamos
				// initListaGrupoContable();

				// historicoOperacion.setTipoCobertura("") ;
				historicoOperacion.setCodigoCobertura(null);
				historicoOperacion.setTipoRiesgo(null);
				historicoOperacion.setIndActivoPasivo(null);
				// CobroAP historicoOperacion.set TipoCobertura("") ;
			}

	}

	public boolean getEsProductoR() {
		// Para mostrar o no los campos de onproductooperchange
		// if(historicoOperacion.getProducto()==null){
		// //hay que invocar por si acaso a la inicializancion de la lista de
		// producto (esta puede seleccionar uno si la lista es de un elemento)
		// initListaProducto();
		// }
		// FLM: según DT la habilitación del grupo cont no depende de op.
		// modelo, pero
		// si su inicialización
		if (historicoOperacion.getProducto() != null)
			if ("R".equalsIgnoreCase(historicoOperacion.getProducto()
					.getIndPasarelaRad())
					|| "M".equalsIgnoreCase(historicoOperacion.getProducto()
							.getIndPasarelaRad())) {
				return true;
			} else {
				return false;
			}
		else
			return true; // FLM: Si no lo ha seleccionado lo ponemos
	}

	public void onCobrosClaseChange() {
		if (historicoOperacion.getIndTramoIrregularRecibo()) {
			historicoOperacion
					.setIndTipoTramoIrregularRecibo(historicoOperacion
							.getIndicadorTipoRecibo());
		}
		historicoOperacion.setDiasFixingRecibo(null);
		checkBloqueosClaseCobro();
		// errorMessageBoxAction.setReRender("cobrosImpFijo__36011__,cobrosTipoInt__36012__,cobrosStrike__36013__,cobrosFormula__36019__,cobrosSig__36015__,cobrosSpread__36015__,cobrosfx__36022__, cobrosAnt__36017__,cobrosBase__36018__,cobrosperFix__36030__");
	}

	private void checkBloqueosClaseCobro() {
		if (hasDatosCobrosTab()) {
			DescripcionClaseInt indicadorTipoRecibo = historicoOperacion
					.getIndicadorTipoRecibo();
			if (tipoClaseFijo.equals(indicadorTipoRecibo)) {
				panelesBloqueados.setImporteCobro(true);
				panelesBloqueados.setTipoIntCobro(false);
				panelesBloqueados.setStrikeCobro(true);
				panelesBloqueados.setSigCobro(true);
				panelesBloqueados.setSpreadCobro(true);
				panelesBloqueados.setFormulaCobro(true);
				panelesBloqueados.setFxCobro(true);
				panelesBloqueados.setDiasFixingCobro(true);
				panelesBloqueados.setFrecuenciaFixingCobro(true);
				panelesBloqueados.setRateFactorCobro(true);
				historicoOperacion.setRateFactorRecibo(null);
				historicoOperacion.setDiasFixingRecibo(new Byte("0"));

				// Salva Incidencia 931
				historicoOperacion.setImporteCuponFijoRecibo(BigDecimal.ZERO);
				historicoOperacion.setStrikeRecibo(BigDecimal.ZERO);
				historicoOperacion.setSpreadRecibo(BigDecimal.ZERO);
				historicoOperacion.setFrecuenciaFixingRecibo(null);
				setFormulaRecibo(null);
				if (indicesFxCobroList != null)
					indicesFxCobroList.clear();
				historicoOperacion.setIndiceRecibo(null);

			}
			if (tipoClaseVariable.equals(indicadorTipoRecibo)) {
				panelesBloqueados.setImporteCobro(true);
				panelesBloqueados.setTipoIntCobro(true);
				panelesBloqueados.setStrikeCobro(false);
				panelesBloqueados.setSigCobro(false);
				panelesBloqueados.setSpreadCobro(false);
				panelesBloqueados.setFormulaCobro(false);
				panelesBloqueados.setFxCobro(false);
				panelesBloqueados.setDiasFixingCobro(false);
				panelesBloqueados.setFrecuenciaFixingCobro(false);
				panelesBloqueados.setRateFactorCobro(false);
				if (historicoOperacion.getRateFactorRecibo() == null
						&& !isDisabled("43001")) {
					historicoOperacion.setRateFactorRecibo(new BigDecimal(1));
				}

				// Salva Incidencia 931
				historicoOperacion.setImporteCuponFijoRecibo(BigDecimal.ZERO);
				historicoOperacion.setPorcentajeTipoFijoRecibo(BigDecimal.ZERO);
				if (historicoOperacion.getDiasFixingRecibo() == null) {
					historicoOperacion
							.setDiasFixingRecibo(getDiasFixingReciboDefaultValue() != null ? getDiasFixingReciboDefaultValue()
									: 0);
				}

			}
			if (tipoClaseCupon.equals(indicadorTipoRecibo)) {
				panelesBloqueados.setImporteCobro(false);
				panelesBloqueados.setTipoIntCobro(true);
				panelesBloqueados.setStrikeCobro(true);
				panelesBloqueados.setSigCobro(true);
				panelesBloqueados.setSpreadCobro(true);
				panelesBloqueados.setFormulaCobro(true);
				panelesBloqueados.setFxCobro(true);
				panelesBloqueados.setDiasFixingCobro(true);
				panelesBloqueados.setFrecuenciaFixingCobro(true);
				panelesBloqueados.setRateFactorCobro(true);
				historicoOperacion.setRateFactorRecibo(null);
				historicoOperacion.setDiasFixingRecibo(new Byte("0"));
				if (historicoOperacion.getBaseCalculoRecibo() == null)
					historicoOperacion.setBaseCalculoRecibo(new BaseCalculo(
							"000"));

				// Salva Incidencia 931
				historicoOperacion.setPorcentajeTipoFijoRecibo(BigDecimal.ZERO);
				historicoOperacion.setStrikeRecibo(BigDecimal.ZERO);
				historicoOperacion.setSpreadRecibo(BigDecimal.ZERO);
				historicoOperacion.setFrecuenciaFixingRecibo(null);
				setFormulaRecibo(null);
				if (indicesFxCobroList != null)
					indicesFxCobroList.clear();
				historicoOperacion.setIndiceRecibo(null);

			}
		}

		if (hasCommoditiesDatosCobrosTab()) {

			DescripcionClaseInt indicadorTipoRecibo = historicoOperacion
					.getIndicadorTipoRecibo();
			if (tipoClaseFijo.equals(indicadorTipoRecibo)) {
				historicoOperacion.setRateFactorRecibo(null);
				historicoOperacion.setDiasFixingRecibo(new Byte("0"));

				// Salva Incidencia 931
				historicoOperacion.setImporteCuponFijoRecibo(BigDecimal.ZERO);
				//SSF 10/09/2018 Comentado para evitar sobreescribir el valor recuperado de BBDD.
//				historicoOperacion.setStrikeRecibo(BigDecimal.ZERO);
				historicoOperacion.setSpreadRecibo(BigDecimal.ZERO);
				historicoOperacion.setFrecuenciaFixingRecibo(null);
				setFormulaRecibo(null);
				if (indicesFxCobroList != null)
					indicesFxCobroList.clear();
				historicoOperacion.setIndiceRecibo(null);

			}
			if (tipoClaseVariable.equals(indicadorTipoRecibo)) {
				if (historicoOperacion.getRateFactorRecibo() == null
						&& !isDisabled("43001")) {
					historicoOperacion.setRateFactorRecibo(new BigDecimal(1));
				}

				// Salva Incidencia 931
				historicoOperacion.setImporteCuponFijoRecibo(BigDecimal.ZERO);
				historicoOperacion.setPorcentajeTipoFijoRecibo(BigDecimal.ZERO);
				if (historicoOperacion.getDiasFixingRecibo() == null) {
					historicoOperacion
							.setDiasFixingRecibo(getDiasFixingReciboDefaultValue() != null ? getDiasFixingReciboDefaultValue()
									: 0);
				}

			}
			if (tipoClaseCupon.equals(indicadorTipoRecibo)) {
				historicoOperacion.setRateFactorRecibo(null);
				historicoOperacion.setDiasFixingRecibo(new Byte("0"));
				if (historicoOperacion.getBaseCalculoRecibo() == null)
					historicoOperacion.setBaseCalculoRecibo(new BaseCalculo(
							"000"));

				// Salva Incidencia 931
				historicoOperacion.setPorcentajeTipoFijoRecibo(BigDecimal.ZERO);
				historicoOperacion.setStrikeRecibo(BigDecimal.ZERO);
				historicoOperacion.setSpreadRecibo(BigDecimal.ZERO);
				historicoOperacion.setFrecuenciaFixingRecibo(null);
				setFormulaRecibo(null);
				if (indicesFxCobroList != null)
					indicesFxCobroList.clear();
				historicoOperacion.setIndiceRecibo(null);

			}

		}

	}

	private Byte getDiasFixingReciboDefaultValue() {
		RelProductoDatosAtributo datosAtributo = getDatosAtributo("36017");
		if (datosAtributo != null && datosAtributo.getValorDefecto() != null) {
			try {
				return Byte.parseByte(datosAtributo.getValorDefecto());
			} catch (NumberFormatException e) {
				return null;
			}
		}
		return null;
	}

	private Byte getDiasFixingPagoDefaultValue() {
		RelProductoDatosAtributo datosAtributo = getDatosAtributo("21017");
		if (datosAtributo != null && datosAtributo.getValorDefecto() != null) {
			try {
				return Byte.parseByte(datosAtributo.getValorDefecto());
			} catch (NumberFormatException e) {
				return null;
			}
		}
		return null;
	}

	public void onPagosClaseChange() {
		if (historicoOperacion.getIndTramoIrregularPago()) {
			historicoOperacion.setIndTipoTramoIrregularPago(historicoOperacion
					.getIndicadorTipoPago());
		}
		historicoOperacion.setDiasFixingPago(null);
		checkBloqueosClasePago();
	}

	private void checkBloqueosClasePago() {
		if (hasDatosCobrosTab()) {
			DescripcionClaseInt indicadorTipoPago = historicoOperacion
					.getIndicadorTipoPago();
			if (tipoClaseFijo.equals(indicadorTipoPago)) {
				panelesBloqueados.setImportePago(true);
				panelesBloqueados.setTipoIntPago(false);
				panelesBloqueados.setStrikePago(true);
				panelesBloqueados.setSigPago(true);
				panelesBloqueados.setSpreadPago(true);
				panelesBloqueados.setFormulaPago(true);
				panelesBloqueados.setFxPago(true);
				panelesBloqueados.setDiasFixingPago(true);
				panelesBloqueados.setFrecuenciaFixingPago(true);
				panelesBloqueados.setRateFactorPago(true);
				historicoOperacion.setRateFactorPago(null);

				historicoOperacion.setDiasFixingPago(new Byte("0"));
				// Salva Incidencia 931
				historicoOperacion.setImporteCuponFijoPago(BigDecimal.ZERO);
				historicoOperacion.setStrikePago(BigDecimal.ZERO);
				historicoOperacion.setSpreadPago(BigDecimal.ZERO);
				historicoOperacion.setFrecuenciaFixingPago(null);
				setFormulaPago(null);
				if (indicesFxPagoList != null)
					indicesFxPagoList.clear();
				historicoOperacion.setIndicePago(null);

			}
			if (tipoClaseVariable.equals(indicadorTipoPago)) {
				panelesBloqueados.setImportePago(true);
				panelesBloqueados.setTipoIntPago(true);
				panelesBloqueados.setStrikePago(false);
				panelesBloqueados.setSigPago(false);
				panelesBloqueados.setSpreadPago(false);
				panelesBloqueados.setFormulaPago(false);
				panelesBloqueados.setFxPago(false);
				panelesBloqueados.setDiasFixingPago(false);
				panelesBloqueados.setFrecuenciaFixingPago(false);
				panelesBloqueados.setRateFactorPago(false);
				if (historicoOperacion.getRateFactorPago() == null
						&& !isDisabled("43001")) {
					historicoOperacion.setRateFactorPago(new BigDecimal(1));
				}

				// Salva Incidencia 931
				historicoOperacion.setImporteCuponFijoPago(BigDecimal.ZERO);
				historicoOperacion.setPorcentajeTipoFijoPago(BigDecimal.ZERO);
				if (historicoOperacion.getDiasFixingPago() == null) {
					historicoOperacion
							.setDiasFixingPago(getDiasFixingPagoDefaultValue() != null ? getDiasFixingPagoDefaultValue()
									: 0);
				}

			}
			if (tipoClaseCupon.equals(indicadorTipoPago)) {
				panelesBloqueados.setImportePago(false);
				panelesBloqueados.setTipoIntPago(true);
				panelesBloqueados.setStrikePago(true);
				panelesBloqueados.setSigPago(true);
				panelesBloqueados.setSpreadPago(true);
				panelesBloqueados.setFormulaPago(true);
				panelesBloqueados.setFxPago(true);
				panelesBloqueados.setFrecuenciaFixingPago(true);
				panelesBloqueados.setDiasFixingPago(true);
				panelesBloqueados.setRateFactorPago(true);
				historicoOperacion.setRateFactorPago(null);
				historicoOperacion.setDiasFixingPago(new Byte("0"));
				if (historicoOperacion.getBaseCalculoPago() == null)
					historicoOperacion
							.setBaseCalculoPago(new BaseCalculo("000"));

				// Salva Incidencia 931
				historicoOperacion.setPorcentajeTipoFijoPago(BigDecimal.ZERO);
				historicoOperacion.setStrikePago(BigDecimal.ZERO);
				historicoOperacion.setSpreadPago(BigDecimal.ZERO);
				historicoOperacion.setFrecuenciaFixingPago(null);
				setFormulaPago(null);
				if (indicesFxPagoList != null)
					indicesFxPagoList.clear();
				historicoOperacion.setIndicePago(null);

			}
		}

		if (hasCommoditiesDatosCobrosTab()) {
			DescripcionClaseInt indicadorTipoPago = historicoOperacion
					.getIndicadorTipoPago();
			if (tipoClaseFijo.equals(indicadorTipoPago)) {
				historicoOperacion.setRateFactorPago(null);

				historicoOperacion.setDiasFixingPago(new Byte("0"));
				// Salva Incidencia 931
				historicoOperacion.setImporteCuponFijoPago(BigDecimal.ZERO);
				//SSF 10/09/2018 Comentado para evitar sobreescribir el valor recuperado de BBDD.
//				historicoOperacion.setStrikePago(BigDecimal.ZERO);
				historicoOperacion.setSpreadPago(BigDecimal.ZERO);
				historicoOperacion.setFrecuenciaFixingPago(null);
				setFormulaPago(null);
				if (indicesFxPagoList != null)
					indicesFxPagoList.clear();
				historicoOperacion.setIndicePago(null);

			}
			if (tipoClaseVariable.equals(indicadorTipoPago)) {
				if (historicoOperacion.getRateFactorPago() == null
						&& !isDisabled("43001")) {
					historicoOperacion.setRateFactorPago(new BigDecimal(1));
				}

				// Salva Incidencia 931
				historicoOperacion.setImporteCuponFijoPago(BigDecimal.ZERO);
				historicoOperacion.setPorcentajeTipoFijoPago(BigDecimal.ZERO);
				if (historicoOperacion.getDiasFixingPago() == null) {
					historicoOperacion
							.setDiasFixingPago(getDiasFixingPagoDefaultValue() != null ? getDiasFixingPagoDefaultValue()
									: 0);
				}

			}
			if (tipoClaseCupon.equals(indicadorTipoPago)) {
				historicoOperacion.setRateFactorPago(null);
				historicoOperacion.setDiasFixingPago(new Byte("0"));
				if (historicoOperacion.getBaseCalculoPago() == null)
					historicoOperacion
							.setBaseCalculoPago(new BaseCalculo("000"));

				// Salva Incidencia 931
				historicoOperacion.setPorcentajeTipoFijoPago(BigDecimal.ZERO);
				historicoOperacion.setStrikePago(BigDecimal.ZERO);
				historicoOperacion.setSpreadPago(BigDecimal.ZERO);
				historicoOperacion.setFrecuenciaFixingPago(null);
				setFormulaPago(null);
				if (indicesFxPagoList != null)
					indicesFxPagoList.clear();
				historicoOperacion.setIndicePago(null);

			}

		}
	}

	public void onDivisaReciboChange() {
		historicoOperacion.setDivisaLiquidacionRecibo(historicoOperacion
				.getDivisaRecibo());
		// errorMessageBoxAction.setReRender("cobrosDivLiqDecorate,contrapartidasFLiqPartidaDecorate,contrapartidasFLiqContrapartidaDecorate");
		calculoNormaIV();
	}

	/**
	 * Si (Grupo Cont. <> ‘XX’ and <> null) and Tipo Cobert <> ‘IN’
	 * 
	 * select distinct decode(TIPODEST, 'CLIENTE', 'CTA','TARGET', 'TAR',
	 * 'SWIFT', 'SWF') from deri.paramcyp where PROYECTO = varProyecto AND
	 * contrapa = Contrapartida AND PRODUCTO = Prod. Oper AND DIVISACP =
	 * NVL(Divisa Pago, Divisa Cobro) AND TIPOPERA = 'P'
	 * 
	 * Si ha encontrado algún registro se desprotege campo Forma Liquidación
	 * Partida (pestaña Contrapartida)
	 * 
	 * Si Grupo Cont = ‘XX’ o Tipo cobert = ‘IN’ o no ha encontrado registros en
	 * la select anterior se protege campo Forma Liquidación Partida (pestaña
	 * Contrapartida)
	 * 
	 * Si (Grupo Cont. <> ‘XX’ and <> null) and Tipo Cobert <> ‘IN’
	 * 
	 * select distinct decode(TIPODEST, 'CLIENTE', 'CTA','TARGET', 'TAR',
	 * 'SWIFT', 'SWF') from deri.paramcyp where PROYECTO = varProyecto AND
	 * contrapa = Contrapartida AND PRODUCTO = Prod. Oper AND DIVISACP =
	 * NVL(Divisa Cobro, Divisa Pago) AND TIPOPERA = 'R'
	 * 
	 * Si ha encontrado algún registro se desprotege campo Forma Liquidación
	 * Contrapartida (pestaña Contrapartida)
	 * 
	 * Si Grupo Cont = ‘XX’ o Tipo cobert = ‘IN’ o no ha encontrado registros en
	 * la select anterior se protege campo Forma Liquidación Contrapartida
	 * (pestaña Contrapartida)
	 * 
	 */
	private void doActualizaCanales() {
		listaCanalLiquidacionPartida = null;
		listaCanalLiquidacionContrapartida = null;
	}

	public void onDivisaPagoChange() {
		historicoOperacion.setDivisaLiquidacionPago(historicoOperacion
				.getDivisaPago());
		calculoNormaIV();
	}

	public void onDivisaChange() {
		if (esCobroTipoB()) {
			onDivisaReciboChange();
		}
		if (esPagoTipoB()) {
			onDivisaPagoChange();
		}
		if (esDatosOpcionCobro() || esDatosOpcionPago()) {
			// pone el valor seleccionado en Div. Camb.
			datosOpcionDelegate.setDivisaLiquidacion(datosOpcionDelegate
					.getDivisa());
		}
		doActualizaCanales();
	}

	public void onCobrosAmortizacionChange() {
		// : Si se ha seleccionado ‘Cantidad Fija’ = F, se desprotegerá el
		// campo siguiente ‘Amort. Fija’, en cualquier otro caso estará
		// protegido

	}

	// FLM: habilitacion campo siguiente de tipoamortizacion
	public boolean DesHabilitarImporteAmortizacionRecibo() {
		if (historicoOperacion.getTipoAmortizacionRecibo() == null
				|| !"F".equalsIgnoreCase(historicoOperacion
						.getTipoAmortizacionRecibo().getCodigo()))
			return true;
		else
			return false;

	}

	public boolean DesHabilitarImporteAmortizacionPago() {
		if (historicoOperacion.getTipoAmortizacionPago() == null
				|| !"F".equalsIgnoreCase(historicoOperacion
						.getTipoAmortizacionPago().getCodigo()))
			return true;
		else
			return false;
	}

	public void onPagosAmortizacionChange() {
		// : Si se ha seleccionado ‘Cantidad Fija’ = F, se desprotegerá el
		// campo siguiente ‘Amort. Fija’, en cualquier otro caso estará
		// protegido

	}

	public void onUnidadNegocioSelect() {
		historicoOperacion.setUnidadNegocio(unidadNegocioMistAction
				.getSelectedRow().getUnidnego());
		// selectedUnidadNegocioMist.getUnidnego());
	}

	/**
	 * Si check desactivado, se deben limpiar el resto de datos de prima
	 * Up-Front Si check activado se deben poner como obligatorios: Cobro/Pago,
	 * Divisa. Poner F. Valor en F.Liquidación
	 */
	public void onSubyacenteSelect() {
		assert pagosCobrosB != null;
		if (suyacentePopupAction.getSelectedRow() != null) {
			selectedSubyacente = suyacentePopupAction.getSelectedRow();
		}
		pagosCobrosB.setIndicePagoCobro(selectedSubyacente);
		pagosCobrosB.setDivisa(selectedSubyacente.getDivisa());
		pagosCobrosB.setDivisaLiquidacion(selectedSubyacente.getDivisa());
		if (selectedSubyacente.getUnidad() != null) {
			pagosCobrosB.setUnidad(selectedSubyacente.getUnidad()
					.getDescripcion());
		} else {
			pagosCobrosB.setUnidad(null);
		}

		if ((historicoOperacion.getIndiceRecibo() != null && historicoOperacion
				.getFormulaRecibo() != null)
				|| (historicoOperacion.getIndicePago() != null && historicoOperacion
						.getFormulaPago() != null)) {
			initIndicesPantalla();
		}

	}

	public void onSubyacenteReciboSelect() {
		if (subyacenteReciboPopupAction.getSelectedRow() != null) {
			selectedSubyReciboCom = subyacenteReciboPopupAction.getSelectedRow();
		}
		historicoOperacion.setIndiceRecibo(selectedSubyReciboCom);
		historicoOperacion.setDivisaRecibo(selectedSubyReciboCom.getDivisa());
		historicoOperacion.setDivisaLiquidacionRecibo(selectedSubyReciboCom
				.getDivisa());
		
		if ( hasCommoditiesDatosCobrosTab()){
			historicoOperacion.setDivisaPago(selectedSubyReciboCom.getDivisa());
			historicoOperacion.setDivisaLiquidacionPago(selectedSubyReciboCom
					.getDivisa());
		}
		// if (selectedSubyacente.getUnidad() != null) {
		// pagosCobrosB.setUnidad(selectedSubyacente.getUnidad().getDescripcion());
		// }else{
		// pagosCobrosB.setUnidad(null);
		// }

		if ((historicoOperacion.getIndiceRecibo() != null && historicoOperacion
				.getFormulaRecibo() != null)
				|| (historicoOperacion.getIndicePago() != null && historicoOperacion
						.getFormulaPago() != null)) {
			initIndicesPantalla();
		}

	}

	public void onSubyacentePagoSelect() {
		if (subyacentePagoPopupAction.getSelectedRow() != null) {
			selectedSubyPagoCom = subyacentePagoPopupAction.getSelectedRow();
		}
		historicoOperacion.setIndicePago(selectedSubyPagoCom);
		historicoOperacion.setDivisaPago(selectedSubyPagoCom.getDivisa());
		historicoOperacion.setDivisaLiquidacionPago(selectedSubyPagoCom
				.getDivisa());
		if ( hasCommoditiesDatosCobrosTab()){
			historicoOperacion.setDivisaRecibo(selectedSubyPagoCom.getDivisa());
			historicoOperacion.setDivisaLiquidacionRecibo(selectedSubyPagoCom
					.getDivisa());
		}
			
		// if (selectedSubyacente.getUnidad() != null) {
		// pagosCobrosB.setUnidad(selectedSubyacente.getUnidad().getDescripcion());
		// }else{
		// pagosCobrosB.setUnidad(null);
		// }

		if ((historicoOperacion.getIndiceRecibo() != null && historicoOperacion
				.getFormulaRecibo() != null)
				|| (historicoOperacion.getIndicePago() != null && historicoOperacion
						.getFormulaPago() != null)) {
			initIndicesPantalla();
		}

	}

	public void onSubyacCdsSelect() {
		if (subyacPopupAction.getSelectedRow() != null) {
			selectedSubyacenteCds = subyacPopupAction.getSelectedRow();
		}
		histdcds.setCodindpa(selectedSubyacenteCds);
	}

	public void onTipoIdentChange() {
		if (histdcds == null || histdcds.getTipidcds() == null) {
			return;
		}
		if ("T".equalsIgnoreCase(histdcds.getTipidcds().getCodigo())) {
			histdcds.setCodiisin("");
		} else {
			histdcds.setCodindpa(null);
		}
	}

	public void onUnidadNegocioMistBlur() {
		// FLM: sólo lo validamos si pone un valor
		if (historicoOperacion.getUnidadNegocio() != null
				&& !"".equalsIgnoreCase(historicoOperacion.getUnidadNegocio())) {
			if (!boletasBo.existeCodigoUnidadNegocioMist(historicoOperacion
					.getUnidadNegocio())) {
				historicoOperacion.setUnidadNegocio(null);
				statusMessages
						.addToControl("unidadNegocio__1001__", Severity.ERROR,
								"#{messages['boletas.edicion.no.existe.unidad.negocio']");
				// errorMessageBoxAction.setReRender("unidadDecorate");
			}
		}
	}

	/**
	 * debe existir en organitzacio.oficines. Si no existe campo erróneo ‘No
	 * existe oficina’ En alta o si no pertenece a campaña
	 * (deri.histderi.codcampa = null) sólo se permite 0901 y 0929. Si no
	 * coincide la entidad asignada (organitzacio.oficines.empresa) con la Ent
	 * introducida (campo anterior), se cambia la introducida con la correcta
	 */
	public void onOficinaBlurDatosContablesSelect() {
		if (selectedOficinaEnt != null) {
			historicoOperacion.setOficina(selectedOficinaEnt.getCodigo());
			onOficinaBlur();
		}
	}

	public void onOficinaBlur() {
		if (historicoOperacion.getOficina() != null) {
			Oficina oficina = null;
			try {
				// errorMessageBoxAction.setReRender("entDecorate,oficinaDecorate");
				oficina = entityManager.find(Oficina.class, historicoOperacion
						.getOficina());
			} catch (EntityNotFoundException e) {
				codigoValidacionErroneo = historicoOperacion.getOficina()
						.toString();
				statusMessages.addToControl("oficina__4002__", Severity.ERROR,
						"#{messages['boletas.edicion.no.existe.oficina']");
				historicoOperacion.setOficina(null);
				return;
			}
			if (boletaState == BoletasStates.ALTA_BOLETA
					|| !EntityUtil.checkEntityExists(entityManager,
							historicoOperacion.getCampanya())) {
				if (!(historicoOperacion.getOficina().intValue() == 901
						|| historicoOperacion.getOficina().intValue() == 929 || historicoOperacion
						.getOficina().intValue() == 905)) {
					codigoValidacionErroneo = historicoOperacion.getOficina()
							.toString();
					statusMessages
							.addToControl("oficina__4002__", Severity.ERROR,
									"#{messages['boletas.edicion.oficina.no.es.valida']");
					historicoOperacion.setOficina(null);
					return;
				}
			}
			if (!esOficinaDeEntidad(oficina)) {
				try {
					DescripcionEntidadOperacion entidad = entityManager.find(
							DescripcionEntidadOperacion.class, new Short(
									oficina.getEmpresa()).toString());
					historicoOperacion.setEntidad(entidad);
				} catch (EntityNotFoundException e) {
					historicoOperacion.setEntidad(null);
					return;
				}
			}
		}
	}

	public void onEntidadOficinaBlur() {
		// TODO: esto esta por decidir, si se hace es un cambio
		if (historicoOperacion.getEntidad() != null) {
			if (boletaState != BoletasStates.CONSULTA_BOLETA) {
				if ("81".equalsIgnoreCase(historicoOperacion.getEntidad()
						.getCodigo())) {
					historicoOperacion.setOficina(Short.valueOf("901"));
				}
				if ("185".equalsIgnoreCase(historicoOperacion.getEntidad()
						.getCodigo())) {
					historicoOperacion.setOficina(Short.valueOf("929"));
				}
				if ("42".equalsIgnoreCase(historicoOperacion.getEntidad()
						.getCodigo())) {
					historicoOperacion.setOficina(Short.valueOf("905"));
				}
			}
		}
	}

	private boolean esOficinaDeEntidad(Oficina oficina) {
		return historicoOperacion.getEntidad() != null
				&& new Short(oficina.getEmpresa()).toString().equals(
						historicoOperacion.getEntidad().getCodigo());
	}

	/**
	 * Si se deja desmarcado: Si hay información en deri.fechcall de la
	 * operación, se mostrará el mensaje ‘Con esta acción se borrarán las fechas
	 * callable ligadas a la operación, ¿desea continuar? S/N. Si contestan N,
	 * se vuelve a marcar el check. Si contestan S, se borran s los registros de
	 * deri.fechcall para la operación (ncorrela, fechaope) correspondiente Se
	 * protege el boton siguiente (F. Cancelación) Si se deja marcado, se
	 * desprotege botón ‘F. Cancelación’ poniéndolo como obligatorio
	 */
	public void onCallableChange() {
		/*
		 * boletas.edit.messageBox.borrar.fechascallables=Con esta acción se
		 * borrarán las fechas callable ligadas a la operación, ¿desea
		 * continuar? S/N
		 */
		if (!historicoOperacion.getIndicadorCallable() && hayFechasCallables()) {
			messageBoxAction.init(
					"boletas.edit.messageBox.borrar.fechascallables",
					"boletasAction.onMessageBoxBorrarCallablesOk()",
					"boletasAction.onMessageBoxBorrarCallablesKo()");
			return;
		}
	}

	public void onMessageBoxBorrarCallablesOk() {
		boletasBo.borraFechasCallables(historicoOperacion);
		persistir();
	}

	public void onMessageBoxBorrarCallablesKo() {
		historicoOperacion.setIndicadorCallable(true);
	}

	// /**
	// * listener para el check de condicionFija en datosOpcion
	// */
	// public void onOpcionCondicionFijaChange() {
	// // : Según DT Nada que hacer, ¿Roma, porque hemos puesto esto?
	// //condicionFija
	// }
	//
	// public void onDivisaQuanChange() {
	// // :Según DT nada que hacer ¿Roma, porque hemos puesto esto?
	// // sólo que se tiene que mirar su valor por defecto
	// //historicoOperacion.historicoOpcion.divisaqu
	// }

	/**
	 * Listeners de checkbox de primas
	 */
	public void onPrimasUpfrontChange() {
		primasRerenderList = "";
		if (!historicoOperacion.getIndicadorPrimaUpFront()) {
			historicoOperacion.setTipoPrimaUpFront(null);
			historicoOperacion.setPorcentajePrimaUpFront(null);
			historicoOperacion.setImportePrimaUpFront(null);
			historicoOperacion.setDivisaPrimaUpFront(null);
			historicoOperacion.setDivisaLiquidacionUpFront(null);
			historicoOperacion.setFechaLiquidacionUpFront(null);
			primasRerenderList = "messagesPanel,optPrimaUpFront__7002__,"
					+ "primasUpFrontPercentDecorate,primasUpFrontImporteDecorate,"
					+ "primasUpFrontDivisaDecorate,primasUpFrontDivLiqDecorate,"
					+ "primasUpFrontFLiquidacionDecorate";
		} else {
			if ("CFC".equals(historicoOperacion.getProductoCatalogo()
					.getModelpro().getModelpro())) {
				if (pagoCobroType == PagoCobroType.ES_COBRO) {
					historicoOperacion.setTipoPrimaUpFront("P");
				}
				if (pagoCobroType == PagoCobroType.ES_PAGO) {
					historicoOperacion.setTipoPrimaUpFront("R");
				}
				primasRerenderList = "primasUpFrontcobroPagoDecorate,";
			}
			if ("S".equals(historicoOperacion.getProductoCatalogo()
					.getProdtrat().getChkopcdiv())) {// En las FX Options, Para
														// las COMCALL y COMPUT,
														// las primas up front
														// deberían ser siempre
														// de pago
				if (pagoCobroType == PagoCobroType.ES_COBRO) {
					historicoOperacion.setTipoPrimaUpFront("P");
				}
				if (pagoCobroType == PagoCobroType.ES_PAGO) {
					historicoOperacion.setTipoPrimaUpFront("R");
				}
				primasRerenderList = "primasUpFrontcobroPagoDecorate,";
			}
			if (!isCapContingente())
				historicoOperacion
						.setFechaLiquidacionUpFront(historicoOperacion
								.getFechaValor());
			primasRerenderList = primasRerenderList
					+ "messagesPanel,optPrimaUpFront__7002__,"
					+ "primasUpFrontDivisaDecorate,primasUpFrontFLiquidacionDecorate";
		}
	}

	public void onIndicadorPrimaPeriodicaChange() {
		primasRerenderList = null;
		if (!historicoOperacion.getIndicadorPrimaUpPeriodica()) {
			historicoOperacion.setTipoPrimaPeriodica(null);
			historicoOperacion.setPorcentajePrimaPeriodica(null);
			historicoOperacion.setImportePrimaPeriodica(null);
			historicoOperacion.setDivisaPrimaPeriodica(null);
			historicoOperacion.setDivisaLiquidacionPeriodica(null);
			historicoOperacion.setFechaLiquidacionPeriodica(null);
			primasRerenderList = "messagesPanel,optPrimaPer__8001__,"
					+ "primasPeriodicaPercentDecorate,primasPeriodicaImporteDecorate,"
					+ "primasPeriodicaDivisaDecorate,primasPeriodicaDivLiqDecorate";
		} else {
			if ("CFC".equals(historicoOperacion.getProductoCatalogo()
					.getModelpro().getModelpro())) {
				if (pagoCobroType == PagoCobroType.ES_COBRO) {
					historicoOperacion.setTipoPrimaPeriodica("P");
				}
				if (pagoCobroType == PagoCobroType.ES_PAGO) {
					historicoOperacion.setTipoPrimaPeriodica("R");
				}
				primasRerenderList = "optPrimaPer__8001__";
			}
		}
	}

	public void onPrimasImplicitaCheckChange() {
		primasRerenderList = null;
		if (!esPrimaImplicita) {
			historicoOperacion.setTipoPrimaImplicita(null);
			historicoOperacion.setImportePrimaImplicita(null);
			historicoOperacion.setDivisaPrimaImplicita(null);
			historicoOperacion.setFechaValorPrimaImplicita(null);
			primasRerenderList = "messagesPanel,optPrimaImplicita__6001__,"
					+ "primasImplicitaImporteDecorate,primasImplicitaDivisaDecorate,"
					+ "primasImplicitafPrImplDecorate";
		} else {
			historicoOperacion.setFechaLiquidacionPeriodica(historicoOperacion
					.getFechaValor());
			primasRerenderList = "messagesPanel,primasImplicitafPrImplDecorate";
		}
	}

	public void onPrimasCancelacionCheckChange() {
		primasRerenderList = null;
		if (!esPrimaCancelacion) {
			historicoOperacion.setTipoPrimaCancelacion(null);
			historicoOperacion.setImportePrimaCancelacion(null);
			historicoOperacion.setDivisaPrimaCancelacion(null);
			historicoOperacion.setDivisaPrimaLiqCancelacion(null);
			primasRerenderList = "messagesPanel,optPrimaCancelac__6001__,"
					+ "primasCancelacImporteDecorate,primasCancelacDivisaDecorate,"
					+ "primasCancelacDivLiqDecorate";
		}
	}

	/**
	 * comprueba el checkbox de primas upfornt
	 */
	public boolean onPrimasUpFrontFieldBlur() {
		primasRerenderList = null;

		Boolean anyNotNull = historicoOperacion.getTipoPrimaUpFront() != null
				|| historicoOperacion.getPorcentajePrimaUpFront() != null
				|| historicoOperacion.getImportePrimaUpFront() != null
				|| historicoOperacion.getDivisaPrimaUpFront() != null
				|| historicoOperacion.getDivisaLiquidacionUpFront() != null
				|| historicoOperacion.getFechaLiquidacionUpFront() != null;
		if (anyNotNull && !historicoOperacion.getIndicadorPrimaUpFront()) {
			historicoOperacion.setIndicadorPrimaUpFront(true);
			primasRerenderList = "messagesPanel,primasUpFrontDecorate";
			return true;
		}
		return false;
	}

	/**
	 * comprueba el checkbox de primas upfornt
	 */
	public boolean onPrimasImplicitaFieldBlur() {
		Boolean anyNotNull = historicoOperacion.getTipoPrimaImplicita() != null
				|| historicoOperacion.getImportePrimaImplicita() != null
				|| historicoOperacion.getDivisaPrimaImplicita() != null;
		if (anyNotNull && (esPrimaImplicita == null || !esPrimaImplicita)) {
			esPrimaImplicita = true;
			primasRerenderList = "messagesPanel,primasImplicitaDecorate";
			return true;
		}
		return false;
	}

	/**
	 * comprueba el checkbox de primas upfornt
	 */
	public boolean onPrimasPeriodicaFieldBlur() {
		Boolean anyNotNull = historicoOperacion.getTipoPrimaPeriodica() != null
				|| historicoOperacion.getPorcentajePrimaPeriodica() != null
				|| historicoOperacion.getImportePrimaPeriodica() != null
				|| historicoOperacion.getDivisaPrimaPeriodica() != null
				|| historicoOperacion.getDivisaLiquidacionPeriodica() != null
				|| historicoOperacion.getFechaLiquidacionPeriodica() != null;
		if (anyNotNull && !historicoOperacion.getIndicadorPrimaUpPeriodica()) {
			historicoOperacion.setIndicadorPrimaUpPeriodica(true);
			primasRerenderList = "messagesPanel,primasPeriodicaDecorate";
			return true;
		}
		return false;
	}

	/**
	 * comprueba el checkbox de primas upfornt
	 */
	public boolean onPrimasCancelacionFieldBlur() {
		Boolean anyNotNull = historicoOperacion.getTipoPrimaCancelacion() != null
				|| historicoOperacion.getImportePrimaCancelacion() != null
				|| historicoOperacion.getDivisaPrimaCancelacion() != null
				|| historicoOperacion.getDivisaPrimaLiqCancelacion() != null;
		// || historicoOperacion.getFechaLiquidacionPeriodica() != null;
		if (anyNotNull && (esPrimaCancelacion == null || !esPrimaCancelacion)) {
			esPrimaCancelacion = true;
			primasRerenderList = "messagesPanel,primasCancelacDecorate";
			return true;
		}
		return false;
	}

	// Listener que calcula el importe a partir del porcentaje en primas upfront
	public void onPorcentajePrimasUpFrontFieldBlur() {
		if (onPrimasUpFrontFieldBlur()) {
			primasRerenderList = "messagesPanel,primasUpFrontDecorate,primasUpFrontImporteDecorate";
		} else {
			primasRerenderList = "messagesPanel,primasUpFrontImporteDecorate";
		}
		calculaPrimaUp();
	}

	// Listener que calcula el importe a partir del porcentaje en primas
	// periodicas
	public void onPorcentajePrimasPeriodicaFieldBlur() {
		if (onPrimasPeriodicaFieldBlur()) {
			primasRerenderList = "messagesPanel,primasPeriodicaDecorate,primasPeriodicaImporteDecorate";
		} else {
			primasRerenderList = "messagesPanel,primasPeriodicaImporteDecorate";
		}
		calculaPrimaPe();
	}

	public void onDivisaPrimaUpFrontChange() {
		primasRerenderList = null;
		historicoOperacion.setDivisaLiquidacionUpFront(historicoOperacion
				.getDivisaPrimaUpFront());
		if (!isCapContingente())
			historicoOperacion.setFechaLiquidacionUpFront(historicoOperacion
					.getFechaValor());
		primasRerenderList = "messagesPanel,primasUpFrontDivLiqDecorate,primasUpFrontFLiquidacionDecorate";
	}

	public void onDivisaPrimaCancelacionChange() {
		primasRerenderList = null;
		historicoOperacion.setDivisaPrimaLiqCancelacion(historicoOperacion
				.getDivisaPrimaCancelacion());
		primasRerenderList = "messagesPanel,primasCancelacDivLiqDecorate";
	}

	public void onDivisaPrimaPeriodicaChange() {
		primasRerenderList = null;
		historicoOperacion.setDivisaLiquidacionPeriodica(historicoOperacion
				.getDivisaPrimaPeriodica());
		primasRerenderList = "messagesPanel,primasPeriodicaDivLiqDecorate";
	}

	public void onDivisaPrimaImplicitaChange() {
		historicoOperacion.setFechaValorPrimaImplicita(historicoOperacion
				.getFechaValor());
		primasRerenderList = "messagesPanel,primasImplicitafPrImplDecorate";
	}

	/**
	 * 
	 * Llamar a procedure P_VALIDAR_CAMBIO_FORM-CP Si no devuelve error: Se
	 * deben restablecer los campos y atributos asociados a la fórmula. Hasta
	 * ahora se habían revisado los atributos y campos asociados a fórmula 0, es
	 * decir los que no cambian si cambia la fórmula, al seleccionar una fórmula
	 * se deben repetir las búsquedas de atributos y datos asociados a esa
	 * fórmula en concreto y visualizar/habilitar los grupos o datos
	 * correspondientes. Se realizaran los pasos a) y c), definidos en Inicio
	 * pero para la fórmula seleccionada.
	 * 
	 */
	// FLM: esta es solo para cuando estamos con cobrospagos, y es la formula de
	// coboros
	public void onFormulaBlurCobro() {

		Integer codigoFormulaCobro = 0;

		// De recibo nos quedamos con la anterior, para ver si antes tenia o no
		// el atributo 23
		if (formulaRecibo != null && formulaRecibo.getOldValue() != null) {
			codigoFormulaCobro = formulaRecibo.getOldValue().getCodigoFormula();
		}
		// Si se ha modificado
		Map<Short, Set<RelProductoAtributo>> tmpProductoAtributoMap = getAtributeMapById(
				new Short((short) 23), codigoFormulaCobro);
		// Si antes lo tenia, tenemos que pedir confirmación
		if (tmpProductoAtributoMap != null
				&& tmpProductoAtributoMap.containsKey(new Integer(23)
						.shortValue())) {
			messageBoxAction.init("boletas.messageBox.cambio.formula",
					"boletasAction.onMessageBoxOkCobro()",
					"boletasAction.onMessageBoxKo()");
		} else {
			limpiarCamposAsociadosAFormulaCobro(false);
		}
		if (formulaRecibo != null) {
			formulaRecibo.setChanged(false);
		}

	}

	public void onFormulaBlurPago() {
		Integer codigoFormulaPago = 0;
		// De recibo nos quedamos con la anterior, para ver si antes tenia o no
		// el atributo 23
		if (formulaPago != null && formulaPago.getOldValue() != null) {
			codigoFormulaPago = formulaPago.getOldValue().getCodigoFormula();
		}
		// Si se ha modificado
		Map<Short, Set<RelProductoAtributo>> tmpProductoAtributoMap = getAtributeMapById(
				new Short((short) 23), codigoFormulaPago);
		// Si antes lo tenia, tenemos que pedir confirmación
		if (tmpProductoAtributoMap != null
				&& tmpProductoAtributoMap.containsKey(new Integer(23)
						.shortValue())) {
			messageBoxAction.init("boletas.messageBox.cambio.formula",
					"boletasAction.onMessageBoxOkPago()",
					"boletasAction.onMessageBoxKo()");
		} else {
			limpiarCamposAsociadosAFormulaPago(false);
		}

		if (formulaPago != null) {
			formulaPago.setChanged(false);
		}
		// errorMessageBoxAction.setReRender("messageBoxPanelFormula");
	}

	// Si cambiamos la formula de datos cobro simples, tenemos que mirar
	// dependiendo si es de cobro o de pago
	public void onFormulaBlurB() {
		Integer codigoFormula = 0;

		if (formulaB != null && formulaB.getOldValue() != null) {
			codigoFormula = formulaB.getOldValue().getCodigoFormula();
		}
		// Si se ha modificado
		Map<Short, Set<RelProductoAtributo>> tmpProductoAtributoMap = getAtributeMapById(
				new Short((short) 23), codigoFormula);
		// Si antes lo tenia, tenemos que pedir confirmación
		if (tmpProductoAtributoMap != null
				&& tmpProductoAtributoMap.containsKey(new Integer(23)
						.shortValue())) {
			if (esCobroTipoB())
				messageBoxAction.init("boletas.messageBox.cambio.formula",
						"boletasAction.onMessageBoxOkCobro()",
						"boletasAction.onMessageBoxKo()");
			else
				messageBoxAction.init("boletas.messageBox.cambio.formula",
						"boletasAction.onMessageBoxOkPago()",
						"boletasAction.onMessageBoxKo()");
		} else {
			checkProductoAtributoMap(true);
		}

		if (formulaB != null) {
			formulaB.setChanged(false);
		}

		if ((historicoOperacion.getIndiceRecibo() != null && historicoOperacion
				.getFormulaRecibo() != null)
				|| (historicoOperacion.getIndicePago() != null && historicoOperacion
						.getFormulaPago() != null)) {
			initIndicesPantalla();
		}

	}

	public void onMessageBoxOkCobro() {
		limpiarCamposAsociadosAFormulaCobro(true);
	}

	private void limpiarCamposAsociadosAFormulaCobro(boolean limpiaIRS) {
		// eliminamos exoticidades (se aplicara con el flush)
		// FLM: ¿Esto no lo pone en ningun sitio, tenemos que quitar condiciones
		// de fijacion y punto ?
		// historicoOperacion.getHistoricoExoticidadesIRSs().clear();
		if (indicesFxCobroList != null)
			indicesFxCobroList.clear();
		historicoOperacion.setIndiceRecibo(null);
		if (limpiaIRS) {
			historicoOperacion.getHistoricoExoticidadesIRSs().clear();
		}
		persistir();
		checkProductoAtributoMap(true);
	}

	private void limpiarCamposAsociadosAFormulaPago(boolean limpiaIRS) {
		// eliminamos exoticidades (se aplicara con el flush)
		// FLM: ¿Esto no lo pone en ningun sitio, tenemos que quitar condiciones
		// de fijacion y punto ?
		// historicoOperacion.getHistoricoExoticidadesIRSs().clear();
		if (indicesFxPagoList != null)
			indicesFxPagoList.clear();
		historicoOperacion.setIndicePago(null);
		if (limpiaIRS) {
			historicoOperacion.getHistoricoExoticidadesIRSs().clear();
		}
		persistir();
		checkProductoAtributoMap(true);
	}

	public void onMessageBoxOkPago() {
		limpiarCamposAsociadosAFormulaCobro(true);
	}

	public void onMessageBoxKo() {
		if (hasDatosCobrosTab()) {
			if (formulaPago != null) {
				formulaPago.setChanged(false);
				formulaPago.reset();
			}
			if (formulaRecibo != null) {
				formulaRecibo.setChanged(false);
				formulaRecibo.reset();
			}
		}
		if (hasSimpleDatosCobrosTab()) {
			if (formulaB != null) {
				formulaB.setChanged(false);
				formulaB.reset();
			}
		}
		if (hasDatosOpcionTab()) {
			if (formulaDatosOpcion != null) {
				formulaDatosOpcion.setChanged(false);
				formulaDatosOpcion.reset();
			}
		}
		// Recalculamos para quedarnos como antes
		checkProductoAtributoMap(true);
	}

	public void onEsquemaContableChange() {
		if (historicoOperacion.getProductoCatalogo() == null
				|| historicoOperacion.getGrupoContable() == null)
			return;

		codigoValidacionErroneo = historicoOperacion.getGrupoContable().getId()
				.getGrupoContable();
		// SMM 1911 SI grupo contable XX no validar esquema
		if ("XX".equalsIgnoreCase(codigoValidacionErroneo)) {
			return;
		}

		if (!boletasBo.esEsquemaContableValido(historicoOperacion)) {
			statusMessages.addToControl("grupoCont4003", Severity.ERROR,
					"#{messages['boletas.edicion.grupocontable.invalido']");
			// errorMessageBoxAction.setReRender("grupoContDecorate,esquemaDecorate");
			return;
		}
	}

	public void onGrupoContableChange() {
		if (historicoOperacion.getProductoCatalogo() == null
				|| historicoOperacion.getGrupoContable() == null)
			return;

		codigoValidacionErroneo = historicoOperacion.getGrupoContable().getId()
				.getGrupoContable();
		// SMM incidencia 1897 i 1911
		if ("XX".equalsIgnoreCase(codigoValidacionErroneo)) {
			historicoOperacion.setIndicadorBSAgente(false);
			panelesBloqueados.setIndBSAgent(true);
			setBloqueoConfirmaciones(true);
			if (indicadorConfirmacion != null)
				resetConfirmaciones();
			doActualizaCanales();
			return;
		}

		if (!boletasBo.esEsquemaContableValido(historicoOperacion)) {
			statusMessages.addToControl("grupoCont4003", Severity.ERROR,
					"#{messages['boletas.edicion.grupocontable.invalido']");
			return;
		}

		boolean esDeCobertura = true;
		String grupoContable = historicoOperacion.getGrupoContable().getId()
				.getGrupoContable();
		try {
			new Integer(grupoContable.substring(0, 1));
		} catch (NumberFormatException e) {
			esDeCobertura = false;
		}
		if (
		// No llegara nunca XX !"XX".equalsIgnoreCase(grupoContable) &&
		historicoOperacion.getFechaValor().before(fechaSistema)
				&& esDeCobertura) {
			statusMessages.addToControl("grupoCont4003", Severity.ERROR,
					"#{messages['boletas.edicion.swapCobertura.invalido']");
			return;
		}
		doActualizaCanales();
	}

	private void resetConfirmaciones() {
		if (hasConfirmacionesTab()) {
			// Se desmarcan los check 'Enviar' de los grupos desprotegidos
			indicadorConfirmacion.setIndicadorConfirmacionAlta(false);
			indicadorConfirmacion.setIndicadorConfirmacionModificacion(false);
			indicadorConfirmacion.setIndicadorConfirmacionAnulacion(false);
			indicadorConfirmacion.setIndicadorConfirmacionCancelacion(false);
			indicadorConfirmacion
					.setIndicadorConfirmacionCancelacionParcial(false);
			indicadorConfirmacion.setIndicadorConfirmacionLiquidacion(false);
			indicadorConfirmacion.setIndicadorConfirmacionFijacion(false);
			// Se desmarcan los check 'Recibir' de los grupos desprotegidos
			indicadorConfirmacion.setIndicadorRecepcionConfirmacionAlta(false);
			indicadorConfirmacion
					.setIndicadorRecepcionConfirmacionModificacion(false);
			indicadorConfirmacion
					.setIndicadorRecepcionConfirmacionAnulacion(false);
			indicadorConfirmacion
					.setIndicadorRecepcionConfirmacionCancelacion(false);
			indicadorConfirmacion
					.setIndicadorRecepcionConfirmacionCancelacionParcial(false);
			indicadorConfirmacion
					.setIndicadorRecepcionConfirmacionLiquidacion(false);
			indicadorConfirmacion
					.setIndicadorRecepcionConfirmacionFijacion(false);
			// Se limpian Canal correspondiente de los grupos desprotegidos
			indicadorConfirmacion
					.setCanelEmisionConfirmacionAlta((CanalConfirmacion) null);
			indicadorConfirmacion
					.setCanelEmisionConfirmacionModificacion((CanalConfirmacion) null);
			indicadorConfirmacion
					.setCanelEmisionConfirmacionAnulacion((CanalConfirmacion) null);
			indicadorConfirmacion
					.setCanelEmisionConfirmacionCancelacion((CanalConfirmacion) null);
			indicadorConfirmacion
					.setCanelEmisionConfirmacionCancelacionParcial((CanalConfirmacion) null);
			indicadorConfirmacion
					.setCanelEmisionConfirmacionLiquidacion((CanalConfirmacion) null);
			indicadorConfirmacion
					.setCanelEmisionConfirmacionFijacion((CanalConfirmacion) null);

			indicadorConfirmacion
					.setCanelRecepcionConfirmacionAlta((CanalConfirmacion) null);
			indicadorConfirmacion
					.setCanelRecepcionConfirmacionModificacion((CanalConfirmacion) null);
			indicadorConfirmacion
					.setCanelRecepcionConfirmacionAnulacion((CanalConfirmacion) null);
			indicadorConfirmacion
					.setCanelRecepcionConfirmacionCancelacion((CanalConfirmacion) null);
			indicadorConfirmacion
					.setCanelRecepcionConfirmacionCancelacionParcial((CanalConfirmacion) null);
			indicadorConfirmacion
					.setCanelRecepcionConfirmacionLiquidacion((CanalConfirmacion) null);
			indicadorConfirmacion
					.setCanelRecepcionConfirmacionFijacion((CanalConfirmacion) null);
		}

	}

	public void onBSAgentChange() {
		/*
		 * RBS Inc 1666: Cuando se llega desde MANTPROD (KONDOR) al dar de alta
		 * operación KONDOR FORWARD - FRA COMPRA y clicar el check bsAgent
		 * panelesBloqueados.getConfirmaciones() es null. Lo solucionamos
		 * controlando que no sea nulo
		 */
		if (hasConfirmacionesTab()
				&& (GenericUtils.isNullOrBlank(panelesBloqueados
						.getConfirmaciones()) || !panelesBloqueados
						.getConfirmaciones())) {
			boolean changed = false;
			if (historicoOperacion.getIndicadorBSAgente()) {
				// Se marcan los check 'Enviar' de los grupos desprotegidos
				// SCM: Falta comprobar que los checks estén desprotegidos
				if (!isDisabled("27001") && !isDisabled("27004")) {
					indicadorConfirmacion.setIndicadorConfirmacionAlta(true);
					indicadorConfirmacion
							.setIndicadorRecepcionConfirmacionAlta(false);
					indicadorConfirmacion
							.setCanelRecepcionConfirmacionAlta((CanalConfirmacion) null);
					changed = true;
				}
				if (!isDisabled("27011") && !isDisabled("27014")) {
					indicadorConfirmacion
							.setIndicadorConfirmacionAnulacion(true);
					indicadorConfirmacion
							.setIndicadorRecepcionConfirmacionAnulacion(false);
					indicadorConfirmacion
							.setCanelRecepcionConfirmacionAnulacion((CanalConfirmacion) null);
					changed = true;
				}
				if (!isDisabled("27016") && !isDisabled("27019")) {
					indicadorConfirmacion
							.setIndicadorConfirmacionCancelacion(true);
					indicadorConfirmacion
							.setIndicadorRecepcionConfirmacionCancelacion(false);
					indicadorConfirmacion
							.setCanelRecepcionConfirmacionCancelacion((CanalConfirmacion) null);
					changed = true;
				}
				if (!isDisabled("27021") && !isDisabled("27024")) {
					indicadorConfirmacion
							.setIndicadorConfirmacionCancelacionParcial(true);
					indicadorConfirmacion
							.setIndicadorRecepcionConfirmacionCancelacionParcial(false);
					indicadorConfirmacion
							.setCanelRecepcionConfirmacionCancelacionParcial((CanalConfirmacion) null);
					changed = true;
				}
				if (!isDisabled("27026") && !isDisabled("27029")) {
					indicadorConfirmacion
							.setIndicadorConfirmacionLiquidacion(true);
					indicadorConfirmacion
							.setIndicadorRecepcionConfirmacionLiquidacion(false);
					indicadorConfirmacion
							.setCanelRecepcionConfirmacionLiquidacion((CanalConfirmacion) null);
					changed = true;
				}
				if (!isDisabled("27031") && !isDisabled("27034")) {
					indicadorConfirmacion
							.setIndicadorConfirmacionFijacion(true);
					indicadorConfirmacion
							.setIndicadorRecepcionConfirmacionFijacion(false);
					indicadorConfirmacion
							.setCanelRecepcionConfirmacionFijacion((CanalConfirmacion) null);
					changed = true;
				}
			} else {
				// Se desmarcan los check 'Enviar' de los grupos desprotegidos
				// SCM: Falta comprobar que los checks estén desprotegidos
				if (!isDisabled("27001") && !isDisabled("27004")) {
					indicadorConfirmacion.setIndicadorConfirmacionAlta(false);
					indicadorConfirmacion
							.setCanelEmisionConfirmacionAlta((CanalConfirmacion) null);
					indicadorConfirmacion.setIdiomaConfirmacionAlta(null);
					indicadorConfirmacion
							.setIndicadorRecepcionConfirmacionAlta(true);
					changed = true;
				}
				if (!isDisabled("27011") && !isDisabled("27014")) {
					indicadorConfirmacion
							.setIndicadorConfirmacionAnulacion(false);
					indicadorConfirmacion
							.setCanelEmisionConfirmacionAnulacion((CanalConfirmacion) null);
					indicadorConfirmacion.setIdiomaConfirmacionAnulacion(null);
					indicadorConfirmacion
							.setIndicadorRecepcionConfirmacionAnulacion(true);
					changed = true;
				}
				if (!isDisabled("27016") && !isDisabled("27019")) {
					indicadorConfirmacion
							.setIndicadorConfirmacionCancelacion(false);
					indicadorConfirmacion
							.setCanelEmisionConfirmacionCancelacion((CanalConfirmacion) null);
					indicadorConfirmacion
							.setIdiomaConfirmacionCancelacion(null);
					indicadorConfirmacion
							.setIndicadorRecepcionConfirmacionCancelacion(true);
					changed = true;
				}
				if (!isDisabled("27021") && !isDisabled("27024")) {
					indicadorConfirmacion
							.setIndicadorConfirmacionCancelacionParcial(false);
					indicadorConfirmacion
							.setCanelEmisionConfirmacionCancelacionParcial((CanalConfirmacion) null);
					indicadorConfirmacion
							.setIdiomaConfirmacionCancelacionParcial(null);
					indicadorConfirmacion
							.setIndicadorRecepcionConfirmacionCancelacionParcial(true);
					changed = true;
				}
				if (!isDisabled("27026") && !isDisabled("27029")) {
					indicadorConfirmacion
							.setIndicadorConfirmacionLiquidacion(false);
					indicadorConfirmacion
							.setIdiomaConfirmacionLiquidacion(null);
					indicadorConfirmacion
							.setCanelEmisionConfirmacionLiquidacion((CanalConfirmacion) null);
					indicadorConfirmacion
							.setIndicadorRecepcionConfirmacionLiquidacion(true);
					changed = true;
				}
				if (!isDisabled("27031") && !isDisabled("27034")) {
					indicadorConfirmacion
							.setIndicadorConfirmacionFijacion(false);
					indicadorConfirmacion
							.setCanelEmisionConfirmacionFijacion((CanalConfirmacion) null);
					indicadorConfirmacion.setIdiomaConfirmacionFijacion(null);
					indicadorConfirmacion
							.setIndicadorRecepcionConfirmacionFijacion(true);
					changed = true;
				}
			}
			if (changed
					&& entityUtil.checkEntityExists(historicoOperacion
							.getContrapartida())) {
				checkCamposConfirmaciones(historicoOperacion.getContrapartida());
			}
		}
	}

	public void onOficinasLookupSelect() {
		historicoOperacion.setOficinaMargen(selectedOficina);
		codigoOficinaMargen.refresh();
	}

	public void onOficinaLookupBlur() {
		Short id = codigoOficinaMargen.getValue();
		if (id != null) {
			Oficina result = entityManager.find(Oficina.class, id);
			if (result == null) {
				codigoValidacionErroneo = id.toString();
				statusMessages.addToControl("datosGestionOficina",
						Severity.ERROR,
						"#{messages['boletas.edicion.no.existe.oficina']");
				return;
			}
			selectedOficina = result;
			onOficinasLookupSelect();
		} else {
			selectedOficina = null;
			onOficinasLookupSelect();
		}
	}

	// public void doValidarCambioFormCP() {
	// if (formulaPago.getChanged() || formulaRecibo.getChanged() || (formulaB
	// != null && formulaB.getChanged())
	// || (formulaDatosOpcion != null && formulaDatosOpcion.getChanged())) {
	// checkProductoAtributoMap(true);
	// }
	//
	// }

	/**
	 * Llamar a procedure P_ASIGNAR_MODELO Llamar a procedure
	 * P_ACTUALIZA_CANALES Llamar a función F_OBTENER_UNIDAD_CONTRAPA y cambiar
	 * campo U.C. con lo que devuelve la función Poner en campo Ent. Matriz la
	 * Contrapartida seleccionada Llamar a procedure P_ACTUALIZA_IMPUTACI Si
	 * Contrapartida seleccionada = ‘FDI’ o ‘MODELO’ proteger pestaña
	 * Confirmaciones (limpiar campos si están informados) y el check BS Agent
	 */
	public void onContrapartidasLookupSelect() {
		AbstractContrapartida selectedContrapartida = contrapartidasPopupAction
				.getSelectedRow();
		doContrapartidaSelected(selectedContrapartida);
	}

	private void doContrapartidaSelected(
			AbstractContrapartida selectedContrapartida) {
		// SMM solo si ha cambiado.
		boolean hasChanged;

		if (historicoOperacion.getContrapartida() == null
				|| !historicoOperacion.getContrapartida().equals(
						selectedContrapartida)) {
			hasChanged = true;
		} else {
			hasChanged = false;
		}

		historicoOperacion.setContrapartida(selectedContrapartida);
		historicoOperacion.setEntidadMatriz(selectedContrapartida);

		// SMM incidencia 1897 Grupo contable XX tampoco se admiten
		// confirmaciones.
		if ((selectedContrapartida != null && ("FDI"
				.equalsIgnoreCase(selectedContrapartida.getId()) || "MODELO"
				.equalsIgnoreCase(selectedContrapartida.getId())))
				|| (historicoOperacion.getGrupoContable() != null && "XX"
						.equalsIgnoreCase(historicoOperacion.getGrupoContable()
								.getId().getGrupoContable()))) {
			selectedContrapartida = null;
			historicoOperacion.setIndicadorBSAgente(false);
			panelesBloqueados.setIndBSAgent(true);
			if (indicadorConfirmacion != null)
				resetConfirmaciones();
			// onBSAgentChange(); Entiendo que esto no es necesario hacerlo.
		} else {
			if (hasChanged
					&& selectedContrapartida != null
					&& !"FDI".equalsIgnoreCase(selectedContrapartida.getId())
					&& !"MODELO"
							.equalsIgnoreCase(selectedContrapartida.getId())
					&& (historicoOperacion.getGrupoContable() == null || (historicoOperacion
							.getGrupoContable() != null && !"XX"
							.equalsIgnoreCase(historicoOperacion
									.getGrupoContable().getId()
									.getGrupoContable())))
					&& (historicoOperacion.getCodigoCobertura() == null || (historicoOperacion
							.getCodigoCobertura() != null && !"IN"
							.equalsIgnoreCase(historicoOperacion
									.getCodigoCobertura().getCodigo())))) {
				if (getTipoContr().equalsIgnoreCase("C")) {
					// Clientes. marcar check BS Agent, y en la pestaña de
					// Confirmaciones, los checks enviar, y desmarcar los de
					// recibir.
					historicoOperacion.setIndicadorBSAgente(true);
					onBSAgentChange();
				} else {
					// desmarcar check BS Agent, desmarcar los checks de enviar
					// (confirmaciones) y marcar los de recibir.
					historicoOperacion.setIndicadorBSAgente(false);
					onBSAgentChange();
				}
			}
			// Lo que ya estaba haciendo
			else {
				panelesBloqueados.setIndBSAgent(false);
			}

		}

		// FLM: si se actualiza la contrapa, se actualiza el tab de
		// contrapartidas
		setBloqueoConfirmaciones(selectedContrapartida == null);

		selectedContrapartida = null;
		listaPopupContrapartidas = null;
		contrapaDelegate.refresh();

		doActualizaCanales();

		doActualizaCanalesConfirmacion();

		obtenerUnidadContrapa(historicoOperacion.getContrapartida());
		actualizaImputacion();
	}

	private void doActualizaCanalesConfirmacion() {
		if (hasConfirmacionesTab()) {
			listaCanalConfirmacionEA = null;
			listaCanalConfirmacionEM = null;
			listaCanalConfirmacionEN = null;
			listaCanalConfirmacionEC = null;
			listaCanalConfirmacionEP = null;
			listaCanalConfirmacionEX = null;
			listaCanalConfirmacionEL = null;
			listaCanalConfirmacionRA = null;
			listaCanalConfirmacionRM = null;
			listaCanalConfirmacionRN = null;
			listaCanalConfirmacionRC = null;
			listaCanalConfirmacionRP = null;
			listaCanalConfirmacionRX = null;
			listaCanalConfirmacionRL = null;

			listaIdiomaConfirmacionAlta = null;
			listaIdiomaConfirmacionN = null;
			listaIdiomaConfirmacionM = null;
			listaIdiomaConfirmacionL = null;
			listaIdiomaConfirmacionX = null;
			listaIdiomaConfirmacionP = null;
			listaIdiomaConfirmacionC = null;

			CanalConfirmacion value = null;
			indicadorConfirmacion.setCanelEmisionConfirmacionAlta(value);
			indicadorConfirmacion
					.setCanelEmisionConfirmacionModificacion(value);
			indicadorConfirmacion.setCanelEmisionConfirmacionAnulacion(value);
			indicadorConfirmacion.setCanelEmisionConfirmacionCancelacion(value);
			indicadorConfirmacion
					.setCanelEmisionConfirmacionCancelacionParcial(value);
			indicadorConfirmacion.setCanelEmisionConfirmacionLiquidacion(value);
			indicadorConfirmacion.setCanelEmisionConfirmacionFijacion(value);

			indicadorConfirmacion.setCanelRecepcionConfirmacionAlta(value);
			indicadorConfirmacion
					.setCanelRecepcionConfirmacionModificacion(value);
			indicadorConfirmacion.setCanelRecepcionConfirmacionAnulacion(value);
			indicadorConfirmacion
					.setCanelRecepcionConfirmacionCancelacion(value);
			indicadorConfirmacion
					.setCanelRecepcionConfirmacionCancelacionParcial(value);
			indicadorConfirmacion
					.setCanelRecepcionConfirmacionLiquidacion(value);
			indicadorConfirmacion.setCanelRecepcionConfirmacionFijacion(value);

			Idioma idioma = null;
			indicadorConfirmacion.setIdiomaConfirmacionAlta(idioma);
			indicadorConfirmacion.setIdiomaConfirmacionModificacion(idioma);
			indicadorConfirmacion.setIdiomaConfirmacionAnulacion(idioma);
			indicadorConfirmacion.setIdiomaConfirmacionCancelacion(idioma);
			indicadorConfirmacion
					.setIdiomaConfirmacionCancelacionParcial(idioma);
			indicadorConfirmacion.setIdiomaConfirmacionLiquidacion(idioma);
			indicadorConfirmacion.setIdiomaConfirmacionFijacion(idioma);

			checkBloqueoConfirmaciones(true);
		}
	}

	private void setBloqueoConfirmaciones(boolean bloqueoConfirmaciones) {
		Boolean estadoBloqueoAntes = getPanelesBloqueados().getConfirmaciones();
		if (estadoBloqueoAntes == null) {
			estadoBloqueoAntes = true;
		}
		getPanelesBloqueados().setConfirmaciones(bloqueoConfirmaciones);
		if (estadoBloqueoAntes && !getPanelesBloqueados().getConfirmaciones()) {
			// se ha desbloqueado el panel de confirmaciones, llamamos a
			// onBSAgentChange para poner los valores por defecto
			onBSAgentChange();
		}
		if (!estadoBloqueoAntes && getPanelesBloqueados().getConfirmaciones()) {
			// se ha bloqueado el panel de confirmaciones, quitamos todos los
			// valores
			resetConfirmaciones();
		}
	}

	public void onContrapartidasLookupBlur() {
		String id = contrapaDelegate.getCodigoContrapa();
		AbstractContrapartida result = null;
		if (id != null && !"".equals(id)) {
			result = contrapartidaUtil.find(id);
			if (result == null) {
				result = contrapartidaUtil.find(id.toUpperCase());
			}
			if (result == null) {
				codigoValidacionErroneo = id;
				statusMessages
						.addToControl("codigoContrapartida", Severity.ERROR,
								"#{messages['boletas.edicion.no.existe.contrapartida']");
				return;
			}
			setBloqueoConfirmaciones(false);
		} else {
			setBloqueoConfirmaciones(true);
		}
		// Salva: Cuando se viene con una operación creada en Batch, con el
		// campo contrapartida informado
		// queremos que recalcule todos los campos asociados a contrapa aunque
		// esta no se cambie.
		// if(contrapaDelegate.hasChanged()){
		doContrapartidaSelected(result);
		// }

		if (null != result) {
			Contrapartida contrapartida = (Contrapartida) result;
			if (null != contrapartida
					&& !GenericUtils.isNullOrBlank(contrapartida
							.getIndBloqueo())
					&& "S".equalsIgnoreCase(contrapartida.getIndBloqueo())) {
				messageBoxAction2.init(
						"liquidaciones.messages.contrapartida.bloqueada.texto",
						"boletasAction.voidFunction()", null,
						"messageBoxPanelContrapa2");
			}
		}

	}

	public void onNominalBlur() {
		fijarNominales0();

		calculaPrimaUp();
		calculaPrimaPe();

		// errorMessageBoxAction.setReRender("primasUpFrontImporteDecorate,cobrosNomTitDecorate");
	}

	public void onEstiloOpcionBlur() {
		validarCambioEstiloOpcion();
	}

	/* EMPIEZA validarCambioEstiloOpcion y eventos asociados */
	private void validarCambioEstiloOpcion() {
		// S
		if (estiloOpcion.getValue() == null) { // Si no selecciona no hacemos
												// nada, no permitimos volver a
												// no selección, es obligatorio
			if (estiloOpcion.getOldValue() != null)
				estiloOpcion.reset();
			return;
		}

		if (historicoOperacion.getFechaVencimiento() == null) {
			statusMessages
					.addToControl("estiloOpcion", Severity.ERROR,
							"#{messages['boletas.edicion.informar.fecha.vencimiento']}");
			estiloOpcion.reset();
			return;
		}
		// FLM: Esto es necesario puesto que al ir a condiciones de fijación, se
		// decide que PC se usa
		checkTipoCobroPago();
		if (historicoOperacion.getHistoricoOpcion().getTipoOperacion().equals(
				PagoCobroType.ES_PAGO)
				&& historicoOperacion.getFormulaPago() == null) {
			statusMessages.addToControl("pagosFormula", Severity.ERROR,
					"#{messages['boletas.edicion.informar.formulaPago']}");
			estiloOpcion.reset();
			return;
		}
		if (historicoOperacion.getHistoricoOpcion().getTipoOperacion().equals(
				PagoCobroType.ES_COBRO)
				&& historicoOperacion.getFormulaRecibo() == null) {
			statusMessages.addToControl("cobrosFormula", Severity.ERROR,
					"#{messages['boletas.edicion.informar.formulaRecibo']}");
			estiloOpcion.reset();
			return;
		}
		if (existeCalendario()) {
			messageBoxAction.init(
					"boletas.messageBox.cambio.estilo.calendario2",
					"boletasAction.onMessageBoxBorrarCalendarioOk()",
					"boletasAction.onMessageBoxBorrarCalendarioKo()");
			// RFA: este reset no es correcto, comentado
			// estiloOpcion.reset();
			return;
		}
		if (numeroFechasTipo("EJ") > 0) {
			messageBoxAction.init(
					"boletas.messageBox.cambio.estilo.fejercicio",
					"boletasAction.onMessageBoxBorrarFEjercicioOk()",
					"boletasAction.onMessageBoxBorrarCalendarioKo()");
			// RFA: este reset no es correcto, comentado
			// estiloOpcion.reset();
			return;
		}
		// FLM: añadimos el resto de la función
		// Persistimos siempre al final del todo
		if (regenerarFechasEjercicioYCalendario()) {
			persistir();
		}
	}

	private boolean regenerarFechasEjercicioYCalendario() {
		if (estiloOpcion.getValue() == null) // Si no selecciona no hacemos nada
			return false;
		if ("A".equalsIgnoreCase(estiloOpcion.getValue().getCodigo())) {
			insertarParametroFecha("EJ", historicoOperacion.getFechaValor(),
					historicoOperacion.getFechaVencimiento());
			insertarParametroFecha("FO", historicoOperacion.getFechaValor(),
					historicoOperacion.getFechaVencimiento());
			// Proteger botones f. ej y f. obs.
			panelesBloqueados.setFechaEjercicio(true);
			panelesBloqueados.setFechaObserv(true);
			return true;
		}
		panelesBloqueados.setFechaEjercicio(false);
		panelesBloqueados.setFechaObserv(false);

		if ("E".equalsIgnoreCase(estiloOpcion.getValue().getCodigo())) {
			insertarParametroFecha("EJ", historicoOperacion
					.getFechaVencimiento(), historicoOperacion
					.getFechaVencimiento());
			insertarParametroFecha("FO", historicoOperacion
					.getFechaVencimiento(), historicoOperacion
					.getFechaVencimiento());
			return true;
		}
		return false;
	}

	// FLM: esta es desde la modificación del estilo de opción
	public void onMessageBoxBorrarCalendarioOk() {
		// FLM: esto lo hacemos en ambos casos, si no es regenerable el
		// calendario no permitimos que se modifique nada
		if (esCalendarioRegenerable()) {
			boolean persistir = false;
			// persistir=borrarCalendario();
			persistir = borrarFechasTipo(historicoOperacion
					.getHistoricoFechasFormulas(), "EJ", "FO")
					|| persistir;
			if (persistir)
				persistir();
			persistir = regenerarFechasEjercicioYCalendario() || persistir;
			if (persistir)
				persistir();

			// SMM 21/12/2011 Regenerar Calendario con Primas Liquidadas
			tramosTableComponent = new TramosTableComponent();
			llamarCalendarioCrear(true);
			// SMM END

		} else {
			// boletas.edicion.no.regenerar.calendario=La regeneración del
			// calendario provocaría la pérdida del histórico de liquidaciones.
			// No es posible realizar esta acción’
			statusMessages.addToControl("estiloOpcion", Severity.ERROR,
					"#{messages['boletas.edicion.no.regenerar.calendario']");
			estiloOpcion.reset();
		}
	}

	// FLM: esta es desde la modificación del estilo de opción
	public void onMessageBoxBorrarFEjercicioOk() {
		// FLM: esto lo hacemos en ambos casos, si no es regenerable el
		// calendario no permitimos que se modifique nada
		if (esCalendarioRegenerable()) {
			boolean persistir = false;
			persistir = borrarCalendario();
			persistir = borrarFechasTipo(historicoOperacion
					.getHistoricoFechasFormulas(), "EJ", "FO")
					|| persistir;
			if (persistir)
				persistir();
			persistir = regenerarFechasEjercicioYCalendario() || persistir;
			if (persistir)
				persistir();
		} else {
			// boletas.edicion.no.regenerar.calendario=La regeneración del
			// calendario provocaría la pérdida del histórico de liquidaciones.
			// No es posible realizar esta acción’
			statusMessages.addToControl("estiloOpcion", Severity.ERROR,
					"#{messages['boletas.edicion.no.regenerar.calendario']");
			estiloOpcion.reset();
		}
	}

	public void onMessageBoxBorrarCalendarioKo() {
		estiloOpcion.reset();
	}

	private boolean borrarFechas(boolean forced) {
		boolean persistir = false;
		if (!forced && hayFechasTipo("EJ")) {
			// boletas.messageBox.cambio.estilo.borrar.fechas=Esta acción
			// borrará las fechas de ejercicio existentes. Desea continuar?
			messageBoxAction.init(
					"boletas.messageBox.cambio.estilo.borrar.fechas",
					"boletasAction.onMessageBoxBorrarFechasCalendarioOk()",
					"boletasAction.onMessageBoxBorrarFechasCalendarioKo()");
			return persistir;
		}
		Set<HistoricoFechaFormula> fechas = historicoOperacion
				.getHistoricoFechasFormulas();
		if (fechas != null) {
			persistir = borrarFechasTipo(fechas, "EJ", "FO");
			// FLM: guardamos los cambios
		}
		getPanelesBloqueados().setFechaEjercicio(false);
		getPanelesBloqueados().setFechaObserv(false);
		if (historicoOperacion.getHistoricoOpcion().getEstiloOpcion() != null) {
			if ("A".equals(historicoOperacion.getHistoricoOpcion()
					.getEstiloOpcion().getCodigo())) {
				insertarParametroFecha("EJ",
						historicoOperacion.getFechaValor(), historicoOperacion
								.getFechaVencimiento());
				insertarParametroFecha("FO",
						historicoOperacion.getFechaValor(), historicoOperacion
								.getFechaVencimiento());
				persistir = true;
				getPanelesBloqueados().setFechaEjercicio(true);
				getPanelesBloqueados().setFechaObserv(true);
			}
			if ("E".equals(historicoOperacion.getHistoricoOpcion()
					.getEstiloOpcion().getCodigo())) {
				insertarParametroFecha("EJ", historicoOperacion
						.getFechaVencimiento(), historicoOperacion
						.getFechaVencimiento());
				insertarParametroFecha("FO", historicoOperacion
						.getFechaVencimiento(), historicoOperacion
						.getFechaVencimiento());
				// disabledFEjercicio.
				persistir = true;
			}
		}
		return persistir;
	}

	// FLM: True si se tiene que persistir
	private boolean borrarFechasTipo(Set<HistoricoFechaFormula> fechas,
			String... tipos) {
		List<String> tiposList = Arrays.asList(tipos);
		Set<HistoricoFechaFormula> fechasABorrar = new HashSet<HistoricoFechaFormula>();
		for (HistoricoFechaFormula historicoFechaFormula : fechas) {
			String tipoFecha = historicoFechaFormula.getId().getTipoFecha();
			if (tiposList.contains(tipoFecha)) {
				fechasABorrar.add(historicoFechaFormula);
			}
		}
		if (fechasABorrar.size() == 0)
			return false;
		else {
			fechas.removeAll(fechasABorrar);
			// FLM: ojo, el persistir se tiene que hacer fuera !!!
			return true;
		}

	}

	private void insertarParametroFecha(String tipoFecha, Date fechaValor,
			Date fechaVencimiento) {
		HistoricoFechaFormulaId historicoFechaFormulaId = new HistoricoFechaFormulaId(
				historicoOperacion, tipoFecha, fechaValor, fechaVencimiento);
		HistoricoFechaFormula fechaFormula = new HistoricoFechaFormula(
				historicoFechaFormulaId);
		// SMM Incidencia 1727
		if (tipoFecha != null && "FO".equalsIgnoreCase(tipoFecha)) {
			fechaFormula.setPesobsfe(Short.valueOf("1"));
		}
		historicoOperacion.getHistoricoFechasFormulas().add(fechaFormula);
	}

	public void onMessageBoxBorrarFechasCalendarioOk() {
		if (borrarFechas(true))
			persistir();
	}

	public void onMessageBoxBorrarFechasCalendarioKo() {
		estiloOpcion.reset();
	}

	private boolean hayFechasTipo(String tipoFecha) {
		Set<HistoricoFechaFormula> fechas = historicoOperacion
				.getHistoricoFechasFormulas();
		if (fechas != null) {
			for (HistoricoFechaFormula historicoFechaFormula : fechas) {
				if (tipoFecha.equals(historicoFechaFormula.getId()
						.getTipoFecha())) {
					return true;
				}
			}
		}
		return false;
	}

	private int numeroFechasTipo(String tipoFecha) {
		int result = 0;
		Set<HistoricoFechaFormula> fechas = historicoOperacion
				.getHistoricoFechasFormulas();
		if (fechas != null) {
			for (HistoricoFechaFormula historicoFechaFormula : fechas) {
				if (tipoFecha.equals(historicoFechaFormula.getId()
						.getTipoFecha())) {
					result++;
				}
			}
		}
		return result;
	}

	// FLM: retorna true si tenemos que persistir al borrar tramos calendario
	private boolean borrarCalendario() {
		// comprobar
		// Los borramos de uno en uno
		if (historicoOperacion.getHistoricoTramoses() != null) {
			for (HistoricoTramos histo : historicoOperacion
					.getHistoricoTramoses()) {
				entityManager.remove(histo);
			}
			historicoOperacion.getHistoricoTramoses().clear();
			return true;
		} else
			return false;
	}

	private boolean esCalendarioRegenerable() {
		return boletasBo.esCalendarioRegenerable(historicoOperacion);
	}

	private boolean existeCalendario() {
		Long size = 0L;
		try {
			size = (Long) entityManager
					.createQuery(
							"select count(a.id.concepto) from HistoricoOperacion h inner join h.historicoTramoses a where h = :operacion ")
					.setParameter("operacion", historicoOperacion)
					.getSingleResult();
		} catch (Exception e) {
			log.error(e);
		}
		return size > 0;
		// return (historicoOperacion.getHistoricoTramoses() !=null &&
		// historicoOperacion.getHistoricoTramoses().size() > 0);
	}

	/* FIN validarCambioEstiloOpcion y eventos asociados */
	public void onFormulaDatosOpcionBlur() {
		// Si no estaba seleccionada la formula antes ya esta bien la cosa
		if (formulaDatosOpcion == null)
			return;
		boolean recalc = true;
		if (formulaDatosOpcion.getOldValue() != null) {
			if (existeCalendario()) {
				messageBoxAction.init(
						"boletas.messageBox.cambio.estilo.calendario",
						"boletasAction.onMessageBoxOkCambioFormula()",
						"boletasAction.onMessageBoxKoCambioFormula()");
				recalc = false;
			}
		}
		if (recalc)
			checkProductoAtributoMap(true);
		formulaDatosOpcion.setChanged(false);
		comprobarFormulaAcumuladores();
	}

	private void comprobarFormulaAcumuladores() {
		if (!GenericUtils.isNullOrBlank(formulaDatosOpcion)
				&& !GenericUtils.isNullOrBlank(formulaDatosOpcion.getValue())
				&& !GenericUtils.isNullOrBlank(formulaDatosOpcion.getValue()
						.getCodigoFormula())
				&& GenericUtils.in(formulaDatosOpcion.getValue()
						.getCodigoFormula(), 1028, 1029, 1030)) {

			List<DescripcionOpcionNivel> listaNivel = listaDescripcionOpcionNivel();
			historicoOperacion.getHistoricoOpcion().setTipoNivelPrincipal(
					listaNivel.get(0));
			historicoOperacion.getHistoricoOpcion().setTipoNivelSecundario(
					listaNivel.get(1));

			if (formulaDatosOpcion.getValue().getCodigoFormula().equals(1028)) {
				DescripcionOpcionBarrera tipoNA = boletasBo
						.obtenerTipoBarr("NA");
				historicoOperacion.getHistoricoOpcion().setModobarr(tipoNA);
				onTipoBarreraOk();
			}

		}
	}

	public void onMessageBoxOkCambioFormula() {
		doValidarCambioFormula();
	}

	public void onMessageBoxKoCambioFormula() {
		// Si calendario no esta generado, borramos fechas
		borrarFechasFormula();
		persistir();
		checkProductoAtributoMap(true);
	}

	private void doValidarCambioFormula() {
		// EN IE8 el changed no está funcionando?
		// Si es regenerable lo regeneramos y borramos fechas
		if (esCalendarioRegenerable()) {
			// SMM 1 - QUITAR COMENTARIO para este check
			checkProductoAtributoMap(true);
			boolean persistir = false;
			// boolean persistir=borrarCalendario();
			if (formulaDatosOpcion.getValue() != null) {
				persistir = persistir || borrarFechasFormula();
			}
			// FLM:
			// SMM 1 - Comentar este if, para que los cambios persistan.
			// if (persistir)
			persistir();

			// SMM 21/12/2011 Regenerar Calendario con Primas Liquidadas
			tramosTableComponent = new TramosTableComponent();
			llamarCalendarioCrear(true);
			// SMM END
			// SMM 1 - Comentar este check, se pone arriba
			// checkProductoAtributoMap(true);
		} else {
			// Si no se puede regenerar no permitimos el cambio
			// boletas.edicion.no.regenerar.calendario=La regeneración del
			// calendario provocaría la pérdida del histórico de
			// liquidaciones. No es posible realizar esta acción’
			statusMessages.addToControl("formulaDatosOpcion", Severity.ERROR,
					"#{messages['boletas.edicion.no.regenerar.calendario']");
			formulaDatosOpcion.reset();
			checkProductoAtributoMap(true);
		}

	}

	private boolean borrarFechasFormula() {
		boolean persistir = false;
		DescripcionFormula formulaAnterior = formulaDatosOpcion.getOldValue();
		DescripcionFormula formulaNueva = formulaDatosOpcion.getValue();
		// Obtenemos los atributos de la formula nueva
		Map<Short, Set<RelProductoAtributo>> antesAtributosMap = getAtributeMap(
				formulaAnterior.getCodigoFormula(), formulaAnterior
						.getCodigoFormula());
		// Si producto/varforant tenían atributo 25 y producto/formula no lo
		// tienen, borrar fechas de Liquidación (P_BORRAR_FECHAS … ‘LI’),
		// proteger botón ‘F.Liquid’
		if (!hasAttribute(25)
				&& antesAtributosMap.containsKey(new Integer(25).shortValue())) {
			persistir = persistir
					|| borrarFechasTipo(historicoOperacion
							.getHistoricoFechasFormulas(), "LI");
			// getPanelesBloqueados().setFechaLiq(true); // en principio es
			// automatico
		}
		// Si producto/formula tiene atributo 25 y producto/varfoant no lo
		// tiene,
		// borrar fechas de ejercicio y fechas de Observación (P_BORRAR_FECHAS …
		// ‘EJ’, (P_BORRAR_FECHAS … ‘FO’), proteger botones ‘F. Ejercicio’ y ‘F.
		// Observ’
		if (hasAttribute(25)
				&& !antesAtributosMap.containsKey(new Integer(25).shortValue())) {
			persistir = persistir
					|| borrarFechasTipo(historicoOperacion
							.getHistoricoFechasFormulas(), "EJ", "FO");
		}
		// Si producto/varforant tenían atributo 17 y producto/formula no lo
		// tienen, borrar fechas de Selección (P_BORRAR_FECHAS … ‘SE’), proteger
		// botón ‘F.Selecc.’
		if (!hasAttribute(17)
				&& antesAtributosMap.containsKey(new Integer(17).shortValue())) {
			persistir = persistir
					|| borrarFechasTipo(historicoOperacion
							.getHistoricoFechasFormulas(), "SE");
		}

		// Si producto/varforant tenían atributo 18 y producto/formula no lo
		// tienen, borrar fechas de Rango (P_BORRAR_FECHAS … ‘RA’), proteger
		// botón ‘F.Rangos’
		if (!hasAttribute(18)
				&& antesAtributosMap.containsKey(new Integer(18).shortValue())) {
			persistir = persistir
					|| borrarFechasTipo(historicoOperacion
							.getHistoricoFechasFormulas(), "RA");
		}

		// FLM: faltaba el 33
		if (!hasAttribute(33)
				&& antesAtributosMap.containsKey(new Integer(33).shortValue())) {
			persistir = persistir
					|| borrarFechasTipo(historicoOperacion
							.getHistoricoFechasFormulas(), "FS");
		}

		// Si producto/varforant tenían atributo 19 y producto/formula no lo
		// tienen, borrar fechas de Wedding (deri.histwedd) , proteger botón
		// ‘F.Wedding’
		if (!hasAttribute(19)
				&& antesAtributosMap.containsKey(new Integer(19).shortValue())) {
			if (historicoOperacion.getHistoricoTramosRangos() != null
					&& historicoOperacion.getHistoricoTramosRangos().size() > 0) {
				historicoOperacion.getHistoricoTramosRangos().clear();
				persistir = true;
			}
		}
		// Si producto/varfoant tenían atributo 23 y producto/formula no lo
		// tienen, borrar Cond Fij. (deri.histircf), proteger botón y check
		// ‘Cond. Fij.’
		if (!hasAttribute(23)
				&& antesAtributosMap.containsKey(new Integer(23).shortValue())) {
			if (historicoOperacion.getHistoricoExoticidadesIRSs() != null
					&& historicoOperacion.getHistoricoExoticidadesIRSs().size() > 0) {
				historicoOperacion.getHistoricoExoticidadesIRSs().clear();
				persistir = true;
			}
		}

		// Aqui faltaria limpiar los indices¿?
		// se decide no borrar los índices al modificar la fórmula
		/*
		 * if (esCobroTipoB()) { if (indicesFxCobroList!=null)
		 * indicesFxCobroList.clear(); historicoOperacion.setIndiceRecibo(null);
		 * } else { if (indicesFxPagoList!=null) indicesFxPagoList.clear();
		 * historicoOperacion.setIndicePago(null); }
		 */

		return persistir;

	}

	private void actualizaImputacion() {
		UnidadNegocio tmpImputacion = null;
		AbstractContrapartida contrapartida = historicoOperacion
				.getContrapartida();
		contrapartida = entityUtil.unwrapProxy(contrapartida,
				AbstractContrapartida.class);
		if (EntityUtil.checkEntityExists(entityManager, contrapartida)
				&& contrapartida instanceof Contrapartida) {
			Contrapartida contrapa = (Contrapartida) contrapartida;
			Long size = (Long) entityManager
					.createQuery(
							"select count(a) from Contrapartida c inner join c.agrupContrapartidas a where c = :contrapa ")
					.setParameter("contrapa", contrapa).getSingleResult();

			if (size == 1) {
				try {
					tmpImputacion = (UnidadNegocio) entityManager
							.createQuery(
									"FROM UnidadNegocio un WHERE un.codigo in("
											+ "SELECT dacu.descripcion "
											+ "FROM DescripcionAgrupContrUnidad dacu "
											+ "WHERE dacu.codigo = (SELECT min(ac.id) "
											+ "FROM Contrapartida con INNER JOIN con.agrupContrapartidas ac "
											+ "WHERE con=:contrapartida" + ")"
											+ ")").setParameter(
									"contrapartida", contrapa)
							.getSingleResult();
				} catch (NoResultException e) {
					// no problem
				}
			}
			if (EntityUtil.checkEntityExists(entityManager, historicoOperacion
					.getImputacionMargenes())) {
				try {
					String tmpCodigGrupo = (String) entityManager
							.createQuery(
									"SELECT dacu.codigo "
											+ "FROM DescripcionAgrupContrUnidad dacu "
											+ "WHERE dacu.descripcion = :codigoImputacion")
							.setParameter(
									"codigoImputacion",
									historicoOperacion.getImputacionMargenes()
											.getCodigo()).getSingleResult();
					if (tmpCodigGrupo != null) {
						Short codi = Short.valueOf(tmpCodigGrupo);
						Boolean found = false;
						for (AgrupContrapartida agrupContrapartida : contrapa
								.getAgrupContrapartidas()) {
							if (agrupContrapartida.getId().equals(codi)) {
								found = true;
								break;
							}
						}
						if (!found && tmpImputacion != null) {
							historicoOperacion
									.setImputacionMargenes(tmpImputacion);
						}
					}
				} catch (NoResultException e) {
					// no problem
				}

			} else {
				historicoOperacion.setImputacionMargenes(tmpImputacion);
			}
		}
		if (!EntityUtil.checkEntityExists(entityManager, historicoOperacion
				.getImputacionMargenes())) {
			try {
				tmpImputacion = (UnidadNegocio) entityManager.createQuery(
						"FROM UnidadNegocio un WHERE un.codigo='OT'")
						.getSingleResult();
				historicoOperacion.setImputacionMargenes(tmpImputacion);
			} catch (NoResultException e) {
				// no problem
			}
		}
	}

	private void calculaPrimaUp() {
		if ("P".equals(historicoOperacion.getTipoPrimaUpFront())) {
			if (historicoOperacion.getPorcentajePrimaUpFront() != null
					&& historicoOperacion.getNominalPago() != null) {
				historicoOperacion
						.setImportePrimaUpFront(calculaImportePorcentaje(
								historicoOperacion.getNominalPago(),
								historicoOperacion.getPorcentajePrimaUpFront()));
			} else {
				if (historicoOperacion.getNominalRecibo() != null) {
					historicoOperacion
							.setImportePrimaUpFront(calculaImportePorcentaje(
									historicoOperacion.getNominalRecibo(),
									historicoOperacion
											.getPorcentajePrimaUpFront()));
				}
			}
		} else {
			if (historicoOperacion.getPorcentajePrimaUpFront() != null
					&& historicoOperacion.getNominalRecibo() != null) {
				historicoOperacion
						.setImportePrimaUpFront(calculaImportePorcentaje(
								historicoOperacion.getNominalRecibo(),
								historicoOperacion.getPorcentajePrimaUpFront()));
			} else {
				if (historicoOperacion.getNominalPago() != null) {
					historicoOperacion
							.setImportePrimaUpFront(calculaImportePorcentaje(
									historicoOperacion.getNominalPago(),
									historicoOperacion
											.getPorcentajePrimaUpFront()));
				}
			}
		}

	}

	private void calculaPrimaPe() {
		if ("P".equals(historicoOperacion.getTipoPrimaPeriodica())) {
			if (historicoOperacion.getPorcentajePrimaPeriodica() != null
					&& historicoOperacion.getNominalPago() != null) {
				historicoOperacion
						.setImportePrimaPeriodica(calculaImportePorcentaje(
								historicoOperacion.getNominalPago(),
								historicoOperacion
										.getPorcentajePrimaPeriodica()));
			} else {
				if (historicoOperacion.getNominalRecibo() != null) {
					historicoOperacion
							.setImportePrimaPeriodica(calculaImportePorcentaje(
									historicoOperacion.getNominalRecibo(),
									historicoOperacion
											.getPorcentajePrimaPeriodica()));
				}
			}
		} else {
			if (historicoOperacion.getPorcentajePrimaPeriodica() != null
					&& historicoOperacion.getNominalRecibo() != null) {
				historicoOperacion
						.setImportePrimaPeriodica(calculaImportePorcentaje(
								historicoOperacion.getNominalRecibo(),
								historicoOperacion
										.getPorcentajePrimaPeriodica()));
			} else {
				if (historicoOperacion.getNominalPago() != null) {
					historicoOperacion
							.setImportePrimaPeriodica(calculaImportePorcentaje(
									historicoOperacion.getNominalPago(),
									historicoOperacion
											.getPorcentajePrimaPeriodica()));
				}
			}
		}

	}

	private BigDecimal calculaImportePorcentaje(BigDecimal nominal,
			BigDecimal porcentaje) {
		if (nominal != null && porcentaje != null) {
			return nominal.multiply(porcentaje).divide(ONE_HUNDRED);
		}
		return null;
	}

	public void onEntidadMatrizLookupBlur() {
		String id = contrapaDelegate.getCodigoEntidadMatriz();
		AbstractContrapartida result = null;
		if (id != null && !"".equals(id)) {
			result = contrapartidaUtil.find(id);
			if (result == null) {
				result = contrapartidaUtil.find(id.toUpperCase());
			}
			if (result == null) {
				codigoValidacionErroneo = id;
				statusMessages
						.addToControl("contrapartidasEntMatriz",
								Severity.ERROR,
								"#{messages['boletas.edicion.no.existe.contrapartida']");
				// errorMessageBoxAction.setReRender("contrapartidasEntMatrizDecorate");
				return;
			}
		}
		historicoOperacion.setEntidadMatriz(result);
		contrapaDelegate.refresh();

		if (null != result) {
			Contrapartida contrapartida = (Contrapartida) result;
			if (null != contrapartida
					&& !GenericUtils.isNullOrBlank(contrapartida
							.getIndBloqueo())
					&& "S".equalsIgnoreCase(contrapartida.getIndBloqueo())) {
				messageBoxAction2.init(
						"liquidaciones.messages.contrapartida.bloqueada.texto",
						"boletasAction.voidFunction()", null,
						"messageBoxPanelContrapa2");
			}
		}
	}

	public void onContrapartidas2LookupBlur() {
		String id = contrapaDelegate.getCodigoContrapa2();
		AbstractContrapartida result = null;
		if (id != null && !"".equals(id)) {
			result = contrapartidaUtil.find(id);
			if (result == null) {
				result = contrapartidaUtil.find(id.toUpperCase());
			}
			if (result == null) {
				codigoValidacionErroneo = id;
				statusMessages
						.addToControl("codigoContrapartida2", Severity.ERROR,
								"#{messages['boletas.edicion.no.existe.contrapartida']");
				// errorMessageBoxAction.setReRender("contrapartidasContrapartida2Decorate");
				return;
			}
		}
		historicoOperacion.setContrapartida2(result);
		contrapaDelegate.refresh();

		if (null != result) {
			Contrapartida contrapartida = (Contrapartida) result;
			if (null != contrapartida
					&& !GenericUtils.isNullOrBlank(contrapartida
							.getIndBloqueo())
					&& "S".equalsIgnoreCase(contrapartida.getIndBloqueo())) {
				messageBoxAction2.init(
						"liquidaciones.messages.contrapartida.bloqueada.texto",
						"boletasAction.voidFunction()", null,
						"messageBoxPanelContrapa2");
			}
		}
	}

	public void onContrapartidasOriginalLookupBlur() {
		String id = contrapaDelegate.getCodigoContrapaOriginal();
		AbstractContrapartida result = null;
		if (id != null && !"".equals(id)) {
			result = contrapartidaUtil.find(id);
			if (result == null) {
				result = contrapartidaUtil.find(id.toUpperCase());
			}
			if (result == null) {
				codigoValidacionErroneo = id;
				statusMessages
						.addToControl("codigoContrapartidaOrig",
								Severity.ERROR,
								"#{messages['boletas.edicion.no.existe.contrapartida']");
				// errorMessageBoxAction.setReRender("contrapartidasContrapartida2Decorate");
				return;
			}
		}
		historicoOperacion.setContrapartidaOriginal(result);
		contrapaDelegate.refresh();

		if (null != result) {
			Contrapartida contrapartida = (Contrapartida) result;
			if (null != contrapartida
					&& !GenericUtils.isNullOrBlank(contrapartida
							.getIndBloqueo())
					&& "S".equalsIgnoreCase(contrapartida.getIndBloqueo())) {
				messageBoxAction2.init(
						"liquidaciones.messages.contrapartida.bloqueada.texto",
						"boletasAction.voidFunction()", null,
						"messageBoxPanelContrapa2");
			}
		}
	}

	/**
	 * si importe informado y Divisa = null, poner Divisa por defecto ‘EUR’ , si
	 * importe no informado poner Divisa a null
	 */
	public void onMargenTesoreriaBlur() {
		recalcularMargenTotal();
		if (historicoOperacion.getMargenTesoreria() != null) {
			historicoOperacion.setDivisaMargenTesoreria(euroDivisa);
		}
	}

	private void recalcularMargenTotal() {
		datosGestionImporteTotal = new BigDecimal(0);
		if (historicoOperacion.getMargenTesoreria() != null) {
			datosGestionImporteTotal = datosGestionImporteTotal
					.add(historicoOperacion.getMargenTesoreria());
		}
		if (historicoOperacion.getImporteMargenOficina() != null) {
			datosGestionImporteTotal = datosGestionImporteTotal
					.add(historicoOperacion.getImporteMargenOficina());
		}
	}

	public void onMargenOficinaBlur() {
		recalcularMargenTotal();
	}

	private void obtenerUnidadContrapa(AbstractContrapartida selected) {
		AbstractContrapartida selectedContrapartida = contrapartidasPopupAction
				.getSelectedRow();

		// Solo estará informada si se ha seleccionado en el popup, anadimos la
		// actual para provocar
		// que funcione correctamente en el onblur
		if (selectedContrapartida == null) {
			if (selected == null) {
				return;
			} else {
				selectedContrapartida = selected;
			}

		}
		UnidadNegocioContrapa unidadNegocioContrapa = null;
		if (selectedContrapartida.getClass()
				.equals(UnidadNegocioContrapa.class)) {
			unidadNegocioContrapa = (UnidadNegocioContrapa) selectedContrapartida;
		} else {
			unidadNegocioContrapa = boletasBo
					.getUnidadNegocioForAbstractContrapa(selectedContrapartida);
		}
		if (unidadNegocioContrapa != null) {
			historicoOperacion.setUnidadContrapartida(unidadNegocioContrapa
					.getId());
		} else {
			if (selectedContrapartida.getClass().equals(Contrapartida.class)) {
				historicoOperacion
						.setUnidadContrapartida(CODIGO_UNIDAD_NEGOCIO_CONTRAPARTIDA);
			} else {
				historicoOperacion
						.setUnidadContrapartida(CODIGO_UNIDAD_NEGOCIO_SERVIBAN);
			}
		}
	}

	public void onEntidadMatrizLookupSelect() {
		AbstractContrapartida selectedContrapartida = contrapartidasPopupAction
				.getSelectedRow();
		historicoOperacion.setEntidadMatriz(selectedContrapartida);
		contrapaDelegate.refresh();
	}

	public void onContrapartidas2LookupSelect() {
		AbstractContrapartida selectedContrapartida = contrapartidasPopupAction
				.getSelectedRow();
		historicoOperacion.setContrapartida2(selectedContrapartida);
		contrapaDelegate.refresh();

		if (null != selectedContrapartida) {
			Contrapartida contrapartida = (Contrapartida) selectedContrapartida;
			if (null != contrapartida
					&& !GenericUtils.isNullOrBlank(contrapartida
							.getIndBloqueo())
					&& "S".equalsIgnoreCase(contrapartida.getIndBloqueo())) {
				messageBoxAction2.init(
						"liquidaciones.messages.contrapartida.bloqueada.texto",
						"boletasAction.voidFunction()", null,
						"messageBoxPanelContrapa2");
			}
		}
	}

	public void onContrapartidasOriginalLookupSelect() {
		AbstractContrapartida selectedContrapartida = contrapartidasPopupAction
				.getSelectedRow();
		historicoOperacion.setContrapartidaOriginal(selectedContrapartida);
		contrapaDelegate.refresh();
	}

	public void onClaveExternaBDUBlur() {
		if (!GenericUtils
				.isNullOrBlank(historicoOperacion.getClaveExternaBDU())
				&& historicoOperacion.getClaveExternaBDU().length() != 18) {
			statusMessages.addToControl("datosGestionClaveBDU__5008__",
					Severity.ERROR,
					"#{messages['boletas.edicion.error.claveBDU.tamano']");
			return;
		}
		if (!"CPD".equalsIgnoreCase(historicoOperacion.getDealType())
				&& !boletasBo.validaClaveBDU(historicoOperacion)) {
			codigoValidacionErroneo = historicoOperacion.getClaveExternaBDU();
			historicoOperacion.setClaveExternaBDU(null);
			statusMessages.addToControl("datosGestionClaveBDU__5008__",
					Severity.ERROR,
					"#{messages['boletas.edicion.error.claveBDU']");
			return;
		}
		botonProfit();
	}

	public void onContratacionEnviarChange() {
		if (!indicadorConfirmacion.getIndicadorConfirmacionAlta()) {
			indicadorConfirmacion.setIdiomaConfirmacionAlta(null);
			indicadorConfirmacion
					.setCanelEmisionConfirmacionAlta((CanalConfirmacion) null);
			// : Proteger campos
		} else {
			// : Desproteger campos
			checkBloqueoConfirmaciones(true);
		}
	}

	public void onContratacionRecibirChange() {
		if (!indicadorConfirmacion.getIndicadorRecepcionConfirmacionAlta()) {
			indicadorConfirmacion
					.setCanelRecepcionConfirmacionAlta((CanalConfirmacion) null);
			// : Proteger campos
		} else {
			// : Desproteger campos
			checkBloqueoConfirmaciones(true);
		}
	}

	public void onModificacionEnviarChange() {
		if (!indicadorConfirmacion.getIndicadorConfirmacionModificacion()) {
			indicadorConfirmacion.setIdiomaConfirmacionModificacion(null);
			indicadorConfirmacion
					.setCanelEmisionConfirmacionModificacion((CanalConfirmacion) null);
			// : Proteger campos
		} else {
			// SMM 26/07/2017 Recalcular Campos
			indicadorConfirmacion.setIdiomaConfirmacionModificacion(null);
			indicadorConfirmacion
					.setCanelEmisionConfirmacionModificacion((CanalConfirmacion) null);

			// : Desproteger campos
			checkBloqueoConfirmaciones(true);
		}
	}

	public void onModificacionRecibirChange() {
		if (!indicadorConfirmacion
				.getIndicadorRecepcionConfirmacionModificacion()) {
			indicadorConfirmacion
					.setCanelRecepcionConfirmacionModificacion((CanalConfirmacion) null);
			// : Proteger campos
		} else {
			// : Desproteger campos
			checkBloqueoConfirmaciones(true);
		}
	}

	public void onAnulacionEnviarChange() {
		if (!indicadorConfirmacion.getIndicadorConfirmacionAnulacion()) {
			indicadorConfirmacion.setIdiomaConfirmacionAnulacion(null);
			indicadorConfirmacion
					.setCanelEmisionConfirmacionAnulacion((CanalConfirmacion) null);
			// : Proteger campos
		} else {
			// : Desproteger campos
			checkBloqueoConfirmaciones(true);
		}
	}

	public void onAnulacionRecibirChange() {
		if (!indicadorConfirmacion.getIndicadorRecepcionConfirmacionAnulacion()) {
			indicadorConfirmacion
					.setCanelRecepcionConfirmacionAnulacion((CanalConfirmacion) null);
			// : Proteger campos
		} else {
			// : Desproteger campos
			checkBloqueoConfirmaciones(true);
		}
	}

	public void onCancelacionEnviarChange() {
		if (!indicadorConfirmacion.getIndicadorConfirmacionCancelacion()) {
			indicadorConfirmacion.setIdiomaConfirmacionCancelacion(null);
			indicadorConfirmacion
					.setCanelEmisionConfirmacionCancelacion((CanalConfirmacion) null);
			// : Proteger campos
		} else {
			// : Desproteger campos
			checkBloqueoConfirmaciones(true);
		}
	}

	public void onCancelacionRecibirChange() {
		if (!indicadorConfirmacion
				.getIndicadorRecepcionConfirmacionCancelacion()) {
			indicadorConfirmacion
					.setCanelRecepcionConfirmacionCancelacion((CanalConfirmacion) null);
			// : Proteger campos
		} else {
			// : Desproteger campos
			checkBloqueoConfirmaciones(true);
		}
	}

	public void onCancelacionParcialEnviarChange() {
		if (!indicadorConfirmacion.getIndicadorConfirmacionCancelacionParcial()) {
			indicadorConfirmacion.setIdiomaConfirmacionCancelacionParcial(null);
			indicadorConfirmacion
					.setCanelEmisionConfirmacionCancelacionParcial((CanalConfirmacion) null);
			// : Proteger campos
		} else {
			// : Desproteger campos
			checkBloqueoConfirmaciones(true);
		}
	}

	public void onCancelacionParcialRecibirChange() {
		if (!indicadorConfirmacion
				.getIndicadorRecepcionConfirmacionCancelacionParcial()) {
			indicadorConfirmacion
					.setCanelRecepcionConfirmacionCancelacionParcial((CanalConfirmacion) null);
			// : Proteger campos
		} else {
			// : Desproteger campos
			checkBloqueoConfirmaciones(true);
		}
	}

	public void onLiquidacionEnviarChange() {
		if (!indicadorConfirmacion.getIndicadorConfirmacionLiquidacion()) {
			indicadorConfirmacion.setIdiomaConfirmacionLiquidacion(null);
			indicadorConfirmacion
					.setCanelEmisionConfirmacionLiquidacion((CanalConfirmacion) null);
			// : Proteger campos
		} else {
			// : Desproteger campos
			checkBloqueoConfirmaciones(true);
		}
	}

	public void onLiquidacionRecibirChange() {
		if (!indicadorConfirmacion
				.getIndicadorRecepcionConfirmacionLiquidacion()) {
			indicadorConfirmacion
					.setCanelRecepcionConfirmacionLiquidacion((CanalConfirmacion) null);
			// : Proteger campos
		} else {
			// : Desproteger campos
			checkBloqueoConfirmaciones(true);
		}
	}

	public void onFijacionEnviarChange() {
		if (!indicadorConfirmacion.getIndicadorConfirmacionFijacion()) {
			indicadorConfirmacion.setIdiomaConfirmacionFijacion(null);
			indicadorConfirmacion
					.setCanelEmisionConfirmacionFijacion((CanalConfirmacion) null);
			// : Proteger campos
		} else {
			// : Desproteger campos
			checkBloqueoConfirmaciones(true);
		}
	}

	public void onFijacionRecibirChange() {
		if (!indicadorConfirmacion.getIndicadorRecepcionConfirmacionFijacion()) {
			indicadorConfirmacion
					.setCanelRecepcionConfirmacionFijacion((CanalConfirmacion) null);
			// : Proteger campos
		} else {
			// : Desproteger campos
			checkBloqueoConfirmaciones(true);
		}
	}

	/**
	 * Devuelve el canal de candefto para el evento, sentido y tipoContrapartida
	 * pasados por parámetro
	 * 
	 * @param contrapartida
	 * @param producat
	 * @param evento
	 * @param tipcontr
	 * @param sentido
	 * @return
	 */
	private CanalConfDefecto cargarCanalConfDefecto(String contrapartida,
			String producat, String evento, String sentido, String tipcontr) {
		CanalConfDefecto canalConfDefecto = null;
		CanalConfDefectoId canalPorDefectoId = new CanalConfDefectoId();
		canalPorDefectoId.setContrapartida(contrapartida);
		canalPorDefectoId.setProducat(producat);
		canalPorDefectoId.setEventoConfirmacion(evento);
		canalPorDefectoId.setSentido(sentido);
		canalPorDefectoId.setTipcontr(tipcontr);

		canalConfDefecto = boletaProdCompuestoBo
				.cargarCanalConfDefecto(canalPorDefectoId);

		if (GenericUtils.isNullOrBlank(canalConfDefecto)) {
			canalPorDefectoId.setContrapartida("ZZZ");
			canalConfDefecto = boletaProdCompuestoBo
					.cargarCanalConfDefecto(canalPorDefectoId);
		}
		return canalConfDefecto;
	}

	private Bloqueos getPanelesBloqueados() {
		if (panelesBloqueados == null) {
			panelesBloqueados = new Bloqueos(true, true);
		}
		return panelesBloqueados;
	}

	/* FACTORIES */

	/*
	 * public void initListaTransacciones() { // checkTransaccion(); // if (
	 * this.transaccion != null && this.transaccion.getChanged() ){
	 * Set<RelProductoTransaccion> transSet = new
	 * HashSet<RelProductoTransaccion>();
	 * if(historicoOperacion.getProductoCatalogo()!=null){ transSet =
	 * historicoOperacion.getProductoCatalogo().getProductoTransacciones(); }
	 * productoTransacciones = new ArrayList<DescripcionTransaccionOperacion>();
	 * for (RelProductoTransaccion relProductoTransaccion : transSet) {
	 * productoTransacciones.add(relProductoTransaccion.getId().getTranoper());
	 * } //FLM: debemos rellenar el wrapper para que el old value funcione
	 * correctamente. //por eso le pasamos boletasaction y usamos
	 * transaccion.value // if (checkListaDeUnElemento(productoTransacciones,
	 * "transaccion.value", DescripcionTransaccionOperacion.class, this)) { //
	 * getPanelesBloqueados().setTransaccion(true); // onTransactionChange(); //
	 * } getPanelesBloqueados().setTransaccion(true); listaGrupoContable=null;
	 * initListaProducto(); // }
	 * 
	 * }
	 */
	@Factory("productoFormulaPago")
	public void initListaFormulaPago() {
		productoFormulaPago = initListaFormula();
		if (checkListaDeUnElemento(productoFormulaPago, "formulaPago",
				DescripcionFormula.class)) {
			panelesBloqueados.setFormulaPago(true);
			if (formulaPago != null) {
				formulaPago.refresh();
			}

		}
		if (esPagoTipoB() && formulaB != null) {
			formulaB.refresh();
		}
	}

	private ArrayList<DescripcionFormula> initListaFormula() {
		ArrayList<DescripcionFormula> listaProductoFormula = new ArrayList<DescripcionFormula>();
		Set<RelProductoFormula> transSet = historicoOperacion
				.getProductoCatalogo().getProductoFormulas();
		listaProductoFormula = new ArrayList<DescripcionFormula>();
		for (RelProductoFormula relProductoFormula : transSet) {
			if (relProductoFormula.getTipoform().equals("LIQ")) {
				listaProductoFormula.add(relProductoFormula.getId()
						.getCodformu());
			}
		}
		Collections.sort(listaProductoFormula,
				new Comparator<DescripcionFormula>() {

					public int compare(DescripcionFormula o1,
							DescripcionFormula o2) {
						return o1.getDescripcion().compareTo(
								o2.getDescripcion());
					}
				});
		return listaProductoFormula;
	}

	@Factory("productoFormulaCobro")
	public void initListaFormulaCobro() {
		productoFormulaCobro = initListaFormula();
		if (checkListaDeUnElemento(productoFormulaCobro, "formulaRecibo",
				DescripcionFormula.class)) {
			panelesBloqueados.setFormulaCobro(true);
			if (formulaRecibo != null) {
				formulaRecibo.refresh();
			}
		}
		if (esCobroTipoB() && formulaB != null) {
			formulaB.refresh();
		}
	}

	@Factory("datosOpcionFormula")
	public void initListaDatosOpcionFormulas() {
		Set<RelProductoFormula> transSet = historicoOperacion
				.getProductoCatalogo().getProductoFormulas();
		datosOpcionFormula = new ArrayList<DescripcionFormula>();
		for (RelProductoFormula relProductoFormula : transSet) {
			String tipoform = relProductoFormula.getTipoform();
			if ("OPE".equals(tipoform) || "OPL".equals(tipoform)) {
				datosOpcionFormula
						.add(relProductoFormula.getId().getCodformu());
			}
		}

		if (checkListaDeUnElemento(datosOpcionFormula,
				"formulaDatosOpcion.value", DescripcionFormula.class, this)) {
			panelesBloqueados.setFormulaOpcion(true);
		} else if (datosOpcionFormula != null) {
			ordenarDatosOpcion();
		}
	}

	public void ordenarDatosOpcion() {

		Collections.sort(datosOpcionFormula,
				new Comparator<DescripcionFormula>() {
					public int compare(DescripcionFormula o1,
							DescripcionFormula o2) {
						int comp = 0;
						try {
							if (GenericUtils.isNullOrBlank(o1.getDescripcion())
									&& GenericUtils.isNullOrBlank(o1
											.getDescripcion())) {
								comp = 0;
							} else if (GenericUtils.isNullOrBlank(o1
									.getDescripcion())) {
								return -1;
							} else if (GenericUtils.isNullOrBlank(o2
									.getDescripcion())) {
								return 1;
							} else {
								comp = o1.getDescripcion().compareTo(
										o2.getDescripcion());
							}

						} catch (Exception e) {

							comp = 0;
						}
						return comp;
					}
				});

	}

	@Factory("listaTipoSubyacenteProducat")
	public void initListaTipoSubyacenteProducat() {
		listaTipoSubyacenteProducat = subyacenteBo
				.obtenerTiposSubyacenteProducatSelect(historicoOperacion
						.getProductoCatalogo());
	}

	@Factory("listaTranAcum")
	public void initListaTranAcum() {
		listaTranAcum = boletasBo.getDescripcionTranAcum();
	}

	@Factory("ListaProductoTGR")
	public void initListaProductoTGR() {
		listaProductoTgrList = boletasBo.getProductosTGR(historicoOperacion
				.getProductoCatalogo());
		checkListaDeUnProductoTgr(listaProductoTgrList, "productoTgr");
	}

	@Factory("productoTransaccionSeleccionadaList")
	public void initListaProducto() {
		RelProductoTransaccion relProdTrans = getRelProductoTransaccion();
		if (relProdTrans != null) {
			productoList = new ArrayList<Producto>(relProdTrans.getProductos());
			Collections.sort(productoList, new Comparator<Producto>() {
				public int compare(Producto o1, Producto o2) {
					return o1.getDescripcion().compareTo(o2.getDescripcion());
				}
			});
			// if(boletaState==BoletasStates.ALTA_BOLETA &&
			// productoList.size()==1 &&
			// historicoOperacion.getProducto()==null){
			// historicoOperacion.setProducto(productoList.get(0));
			// }
			if (checkListaDeUnElemento(productoList, "producto", Producto.class)) {
				// initListaGrupoContable(); Esto se hace en el otro lado
				onProductoOperChange();
			} else {
				listaGrupoContable = null;
				// initListaGrupoContable();
			}
			// Recargar el combo de grupos contables asociado
		} else {
			productoList = new ArrayList<Producto>();
			historicoOperacion.setProducto(null);
			listaGrupoContable = null;
		}
	}

	// FLM:Check de un elemento sobre cualquier objeto, no solo operacion
	private <E> Boolean checkListaDeUnElemento(List<E> lista,
			String nombreCampo, Class<E> clazz, Object bean) {
		if (bean == null) {
			return false;
		}
		try {
			Object value = PropertyUtils.getProperty(bean, nombreCampo);
			if (boletaState == BoletasStates.ALTA_BOLETA && lista.size() == 1
					&& (value == null || lista.get(0).equals(value))) {
				PropertyUtils.setProperty(bean, nombreCampo, lista.get(0));
				return true;
			}
			// en modificacion no es necesario asignar
			// if (boletaState == BoletasStates.MODI_BOLETA && lista.size() == 1
			// && lista.get(0).equals(value) ) {
			// return true;
			// }
		} catch (Exception e) {
			log
					.error(
							"Error de codificacion? posible nombre de campo equivocado",
							e);
		}
		return false;
	}

	private <E> Boolean checkListaDeUnElemento(List<E> lista,
			String nombreCampoHistoricoOperacion, Class<E> clazz) {
		try {
			Object value = PropertyUtils.getProperty(historicoOperacion,
					nombreCampoHistoricoOperacion);

			// esModoActuaAlta
			if (boletaState == BoletasStates.ALTA_BOLETA && lista.size() == 1
					&& value == null) {
				PropertyUtils.setProperty(historicoOperacion,
						nombreCampoHistoricoOperacion, lista.get(0));
				return true;
			}
			if (boletaState == BoletasStates.MODI_BOLETA && lista.size() == 1
					&& value != null) {
				return true;
			}
		} catch (Exception e) {
			log
					.error(
							"Error de codificacion? posible nombre de campo equivocado",
							e);
		}
		return false;
	}

	private Boolean checkListaDeUnProductoTgr(List<ProductoTgr> lista,
			String nombreCampoHistoricoOperacion) {
		try {
			Object value = PropertyUtils.getProperty(historicoOperacion,
					nombreCampoHistoricoOperacion);
			// esModoActuaAlta
			if (boletaState == BoletasStates.ALTA_BOLETA && lista.size() == 1
					&& value == null) {
				PropertyUtils.setProperty(historicoOperacion,
						nombreCampoHistoricoOperacion, lista.get(0).getId()
								.getProductoTgr());
				return true;
			}
			if (boletaState == BoletasStates.MODI_BOLETA && lista.size() == 1
					&& value != null) {
				return true;
			}
		} catch (Exception e) {
			log
					.error(
							"Error de codificacion? posible nombre de campo equivocado",
							e);
		}
		return false;
	}

	@Factory("listaCanalLiquidacionPartida")
	public void initListaCanalLiquidacionPartida() {
		listaCanalLiquidacionPartida = boletasBo
				.getListaCanalesPagoActualizada(historicoOperacion);
		checkListaDeUnElemento(listaCanalLiquidacionPartida,
				"canalLiquidacionPago", DescripcionCanalLiquidacion.class);
	}

	@Factory("listaCanalLiquidacionContrapartida")
	public void initListaCanalLiquidacionContrapartida() {
		listaCanalLiquidacionContrapartida = boletasBo
				.getListaCanalesReciboActualizada(historicoOperacion);
		checkListaDeUnElemento(listaCanalLiquidacionContrapartida,
				"canalLiquidacionRecibo", DescripcionCanalLiquidacion.class);
	}

	@Factory("ListaGrupoContable")
	public void initListaGrupoContable() {
		// listaGrupoContable =
		// boletasBo.getListaGrupoContables(historicoOperacion.getProducto());
		if (historicoOperacion.getProducto() == null)
			listaGrupoContable = new ArrayList<GrupoContable>();
		else
			listaGrupoContable = boletasBo
					.getListaGrupoContables(historicoOperacion.getProducto());
	}

	@Factory("ListaEntidadOperacion")
	public List<DescripcionEntidadOperacion> listaDescripcionEntidadOperacions() {
		if (boletaState == BoletasStates.CONSULTA_BOLETA) {
			return boletasBo.getDescripcionEntidadOperacion(false);
		} else {
			return boletasBo.getDescripcionEntidadOperacion(true);
		}

	}

	@Factory("Listatradetv")
	public List<DescripcionTradeOnTv> listaDescripcionTradeOnTv() {
		return boletasBo.getDescripcionTradeOnTv();
	}

	@Factory("ListaEsquemaContables")
	public List<DescripcionEsquemaContables> listaDescripcionEsquemaContables() {
		return boletasBo.getDescripcionEsquemaContables();
	}

	@Factory("ListaTipoCobertura")
	public List<DescripcionTipoCobertura> listaDescripcionTipoCobertura() {
		return boletasBo.getDescripcionTipoCobertura();
	}

	@Factory("ListaTipoRiesgo")
	public List<DescripcionTipoRiesgo> listaDescripcionTipoRiesgo() {
		return boletasBo.getDescripcionTipoRiesgo();
	}

	@Factory("ListaCobAp")
	public List<DescripcionCobAp> listaDescripcionCobAp() {
		return boletasBo.getDescripcionCobAp();
	}

	@Factory("ListaIntercNom")
	public List<DescripcionIntercNom> listaDescripcionIntercNom() {
		return boletasBo.getDescripcionIntercNom();
	}

	@Factory("ListaEstiloOpcion")
	public List<DescripcionEstiloOpcion> listaDescripcionEstiloOpcion() {
		return boletasBo.getDescripcionEstiloOpcion();
	}

	@Factory("ListaModoEjercicio")
	public List<DescripcionModoEjercicio> listaDescripcionModoEjercicio() {
		return boletasBo.getDescripcionModoEjercicio();
	}

	@Factory("ListaTipoOpcion")
	public void initListaDescripcionTipoOpcion() {
		List<DescripcionTipoOpcion> tmpDescripcionTipoOpcion = boletasBo
				.getDescripcionTipoOpcion();
		if (!hasAttribute(34)) {
			listaDescripcionTipoOpcion = new ArrayList<DescripcionTipoOpcion>();
			for (DescripcionTipoOpcion descripcionTipoOpcion : tmpDescripcionTipoOpcion) {
				if ("N".equals(descripcionTipoOpcion.getCodigo())) {
					listaDescripcionTipoOpcion.add(descripcionTipoOpcion);
					historicoOperacion.getHistoricoOpcion().setTipoOpcion(
							descripcionTipoOpcion);
					break;
				}
			}
		} else {
			// RelProductoAtributo relProductoAtributo =
			// relProductoAtributoMap.get(new Integer(34).shortValue());

			if (!hasAttributeAndIsObligated(34)) {
				// opcional
				listaDescripcionTipoOpcion = tmpDescripcionTipoOpcion;
			} else {
				// obligatorio
				listaDescripcionTipoOpcion = new ArrayList<DescripcionTipoOpcion>();
				for (DescripcionTipoOpcion descripcionTipoOpcion : tmpDescripcionTipoOpcion) {
					if ("N".equals(descripcionTipoOpcion.getCodigo())) {
						continue;
					}
					listaDescripcionTipoOpcion.add(descripcionTipoOpcion);
					panelesBloqueados.setFechaPayoff(false);
				}
			}
		}
		// listaDescripcionTipoOpcion
	}

	@Factory("ListaTiposTri")
	public List<DescripcionTiposTri> listaDescripcionTiposTri() {
		return boletasBo.getDescripcionTiposTri();
	}

	@Factory("ListaOpcionNivel")
	public List<DescripcionOpcionNivel> listaDescripcionOpcionNivel() {
		return boletasBo.getDescripcionOpcionNivel();
	}

	@Factory("ListaOpcionBarrera")
	public List<DescripcionOpcionBarrera> listaDescripcionOpcionBarrera() {
		return boletasBo.getDescripcionOpcionBarrera();
	}

	@Factory("ListaTipoBarreraKnock")
	public List<DescripcionTipoBarreraKnock> listaDescripcionTipoBarreraKnock() {
		return boletasBo.getDescripcionTipoBarreraKnock();
	}

	@Factory("ListaBroker")
	public List<Broker> listaBroker() {
		return boletasBo.getListaBrokers();
	}

	@Factory("ListaUnidadNegocio")
	public List<UnidadNegocio> listaUnidadNegocio() {
		// return boletasBo.getUnidadNegocios();
		if (boletaState == BoletasStates.CONSULTA_BOLETA) {
			return boletasBo.getUnidadNegocios(false);
		} else {
			return boletasBo.getUnidadNegocios(true);
		}
	}

	@Factory("ListaAutorizaIndiserv")
	public List<DescripcionAutorizaIndiserv> listaDescripcionAutorizaIndiserv() {
		return boletasBo.getDescripcionAutorizaIndiserv();
	}

	@Factory("ListaAutorizaInditipo")
	public List<DescripcionAutorizaInditipo> listaDescripcionAutorizaInditipo() {
		return boletasBo.getDescripcionAutorizaInditipo();
	}

	@Factory("ListaAutorizaIndiforza")
	public List<DescripcionAutorizaIndiforza> listaDescripcionAutorizaIndiforza() {
		return boletasBo.getDescripcionAutorizaIndiforza();
	}

	@Factory("ListaAutorizaTipopers")
	public List<DescripcionAutorizaTipopers> listaDescripcionAutorizaTipopers() {
		return boletasBo.getDescripcionAutorizaTipopers();
	}

	@Factory("ListaAutorizaPerfilbs")
	public List<DescripcionAutorizaPerfilbs> listaDescripcionAutorizaPerfilbs() {
		return boletasBo.getDescripcionAutorizaPerfilbs();
	}

	@Factory("ListaAutorizaTestconv")
	public List<DescripcionAutorizaTestconv> listaDescripcionAutorizaTestconv() {
		return boletasBo.getDescripcionAutorizaTestconv();
	}

	@Factory("listaDtDatosAdicionales")
	public void initListaDatosAdicionales() {
		listaDatosAdicionales = new ArrayList<HistoricoDatosAdicionales>(
				historicoOperacion.getHistoricoDatosAdicionales());
		if (listaDatosAdicionales == null || listaDatosAdicionales.size() == 0) {
			listaDatosAdicionales = new ArrayList<HistoricoDatosAdicionales>();
			List<DatosAdicionales> list = obtenerDatosAdicionales();
			for (DatosAdicionales datosAdicionales : list) {
				HistoricoDatosAdicionalesId datosAdicionalesId = new HistoricoDatosAdicionalesId(
						historicoOperacion, datosAdicionales);
				HistoricoDatosAdicionales datosAdicionales2 = new HistoricoDatosAdicionales(
						datosAdicionalesId);
				listaDatosAdicionales.add(datosAdicionales2);
			}
			historicoOperacion.getHistoricoDatosAdicionales().addAll(
					listaDatosAdicionales);
		}
		Collections.sort(listaDatosAdicionales,
				new Comparator<HistoricoDatosAdicionales>() {
					public int compare(HistoricoDatosAdicionales o1,
							HistoricoDatosAdicionales o2) {
						return o1.getId().getDatosAdicionales()
								.getCodigoAdicional().compareTo(
										o2.getId().getDatosAdicionales()
												.getCodigoAdicional());
					}
				});
	}

	public void validaDatosAdicionalesObligatorios() {
		if (hasAttribute(28)) {
			ProductoCatalogo productoCatalogo = historicoOperacion
					.getProductoCatalogo();
			Set<DatosAdicionalesProducto> datosAdicionalesProductos = productoCatalogo
					.getDatosAdicionalesProductos();

			Set<HistoricoDatosAdicionales> historicoDatosAdicionales = historicoOperacion
					.getHistoricoDatosAdicionales();
			for (HistoricoDatosAdicionales historicoDatosAdicionales2 : historicoDatosAdicionales) {
				DatosAdicionales datosAdicionales = historicoDatosAdicionales2
						.getId().getDatosAdicionales();
				for (DatosAdicionalesProducto datosAdicionalesProducto : datosAdicionalesProductos) {
					if (datosAdicionalesProducto.getId().getDatosAdicionales()
							.equals(datosAdicionales)) {
						if (datosAdicionalesProducto.getObligatorio()) {
							if (historicoDatosAdicionales2.getValor() == null
									|| historicoDatosAdicionales2.getValor()
											.length() == 0) {
								codigoValidacionErroneo = historicoDatosAdicionales2
										.getId().getDatosAdicionales()
										.getCodigoAdicional().toString();
								statusMessages
										.add(Severity.ERROR,
												"#{boleta.datos.adicionales.valor.obligatorio}");
								retDadesValides = false;
								continue;
							}
						}
						if (!validaDatoAdicional(historicoDatosAdicionales2)) {
							retDadesValides = false;
						}
					}
				}
			}
		}
	}

	public void validaDatosAdicionales() {
		if (entityUtil.checkEntityExists(selectedDatoAdicional)) {
			validaDatoAdicional(selectedDatoAdicional);
		}
	}

	private boolean validaDatoAdicional(
			HistoricoDatosAdicionales selectedDatoAdicional) {
		DatosAdicionales datosAdicionales = selectedDatoAdicional.getId()
				.getDatosAdicionales();
		if (selectedDatoAdicional.getValor() != null
				&& !"".equals(selectedDatoAdicional.getValor())) {
			if ("D".equals(datosAdicionales.getTipoDatoAdicional())) {
				SimpleDateFormat sdf = (SimpleDateFormat) DateFormat
						.getDateInstance(DateFormat.SHORT);
				try {
					sdf.parse(selectedDatoAdicional.getValor());
				} catch (ParseException e) {
					codigoValidacionErroneo = selectedDatoAdicional.getValor();
					selectedDatoAdicional.setValor(null);
					statusMessages
							.add(Severity.ERROR,
									"#{messages['boleta.datos.adicionales.valor.fecha.erroneo']}");
					return false;
				}
			}
			if ("N".equals(datosAdicionales.getTipoDatoAdicional())) {
				NumberFormat numberFormat = NumberFormat.getNumberInstance();
				try {
					Number parse = numberFormat.parse(selectedDatoAdicional
							.getValor());
					int length = new Long(parse.longValue()).toString()
							.length();
					if (length > datosAdicionales.getLongitud()) {
						codigoValidacionErroneo = selectedDatoAdicional
								.getValor();
						selectedDatoAdicional.setValor(null);
						statusMessages
								.add(Severity.ERROR,
										"#{messages['boleta.datos.adicionales.valor.longitud.erronea']}");
						return false;
					}
				} catch (ParseException e) {
					codigoValidacionErroneo = selectedDatoAdicional.getValor();
					selectedDatoAdicional.setValor(null);
					statusMessages
							.add(Severity.ERROR,
									"#{messages['boleta.datos.adicionales.valor.numerico.erroneo']}");
					return false;
				}
			}
			if ("C".equals(datosAdicionales.getTipoDatoAdicional())) {
				int length = selectedDatoAdicional.getValor().length();
				if (length > datosAdicionales.getLongitud()) {
					codigoValidacionErroneo = selectedDatoAdicional.getValor();
					selectedDatoAdicional.setValor(null);
					statusMessages
							.add(Severity.ERROR,
									"#{messages['boleta.datos.adicionales.valor.longitud.erronea']}");
					return false;
				}
			}
		}
		return true;
	}

	private List<DatosAdicionales> obtenerDatosAdicionales() {
		ProductoCatalogo productoCatalogo = historicoOperacion
				.getProductoCatalogo();
		Set<DatosAdicionalesProducto> datosAdicionalesProductos = productoCatalogo
				.getDatosAdicionalesProductos();
		List<DatosAdicionales> result = new ArrayList<DatosAdicionales>();
		for (DatosAdicionalesProducto datosAdicionalesProducto : datosAdicionalesProductos) {
			result.add(datosAdicionalesProducto.getId().getDatosAdicionales());
		}
		return result;
	}

	// DATOS ADICIONALES TEST

	@Factory("ListaAutorizaTipoCliente")
	public List<DescripcionAutorizaTipoCliente> listaDescripcionAutorizaTipoCliente() {
		return boletasBo.getDescripcionAutorizaTipoCliente();
	}

	@Factory("ListaTipoIdentCDS")
	public List<DescripcionTipoIdentCDS> listaDescripcionTipoIdentCDS() {
		return boletasBo.getDescripcionTipoIdentCDS();
	}

	@Factory("ListaEventoCDS")
	public List<DescripcionEventoCDS> listaDescripcionEventoCDS() {
		return boletasBo.getDescripcionEventoCDS();
	}

	@Factory("ListaEntidadSibis")
	public List<DescripcionEntidadSibis> listaDescripcionEntidadSibis() {
		return boletasBo.getDescripcionEntidadSibis();
	}

	@Factory("tiposAjuste")
	public Ajustes[] getAjustes() {
		return Ajustes.values();
	}

	@Factory("listaUnidadNegocioMist")
	public void initListaUnidadNegocioMist() {
		listaUnidadNegocioMist = boletasBo.buscaUnidadNegocioPorDescripcion(
				filtroMist, unidadNegocioMistAction.getPaginationData());
	}

	@Factory("listaPopupSubyacentes")
	public void initListaSubyacentes() {
		listaPopupSubyacentes = boletasBo
				.getListaSubyacentesParaUnProductoCatalogo(historicoOperacion
						.getProductoCatalogo(), filtroSubyacente,
						suyacentePopupAction.getPaginationData());
	}

	@Factory("listaPopupSubyacenCds")
	public void initListaSubyacenCds() {
		listaPopupSubyacenCds = boletasBo
				.getListaSubyacentesParaUnProductoCatalogo(historicoOperacion
						.getProductoCatalogo(), filtroSubyacente,
						subyacPopupAction.getPaginationData());
	}


	@Factory("listaPopupSubyReciboCom")
	public void initListaSubyReciboCom() {
		listaPopupSubyReciboCom = boletasBo
				.getListaSubyacentesParaUnProductoCatalogo(historicoOperacion
						.getProductoCatalogo(), filtroSubyacente,
						subyacenteReciboPopupAction.getPaginationData());
	}

	
	@Factory("listaPopupSubyPagoCom")
	public void initListaSubyPagoCom() {
		listaPopupSubyPagoCom = boletasBo
				.getListaSubyacentesParaUnProductoCatalogo(historicoOperacion
						.getProductoCatalogo(), filtroSubyacente,
						subyacentePagoPopupAction.getPaginationData());
	}

	
	@Factory("listaPopupContrapartidas")
	public void initListaPopupContrapartidas() {
		listaPopupContrapartidas = boletasBo.getListaContrapartidaLookup(
				filtroContrapartidasCodigo, filtroContrapartidas,
				contrapartidasPopupAction.getPaginationData());
	}

	@Factory("listaPopupOficinas")
	public void initListaPopupOficinas() {
		// FLM: en este caso mostramos todas
		listaPopupOficinas = oficinaBo.buscarOficinasPorNombre(filtroOficinas,
				true, oficinasPopupAction.getPaginationData());
	}

	@Factory("listaPopupOficinasEnt")
	public void initListaPopupOficinasEnt() {
		// FLM: Si no es campanya solo existen 2 valores posibles
		listaPopupOficinasEnt = oficinaBo.buscarOficinasPorNombre(
				filtroOficinas,
				historicoOperacion.getCampanya() == null ? false : true,
				oficinasPopupAction.getPaginationData());
	}

	@Factory("ListaCanalEmisionConfirmacionAlta")
	public void initListCanalEmisionConfirmacionAlta() {
		if (boletasBo.checkPlantillaConfirmacion("A", historicoOperacion
				.getProductoCatalogo())) {
			listaCanalConfirmacionEA = boletasBo.getListaCanalConfirmacion("E",
					getTipoContr(), "A");
		} else {
			listaCanalConfirmacionEA = boletasBo.getCanalConfirmacionMM();
		}
		checkListaDeUnElemento(listaCanalConfirmacionEA,
				"canelEmisionConfirmacionAlta", CanalConfirmacion.class,
				indicadorConfirmacion);
	}

	@Factory("ListaCanalEmisionConfirmacionModificacion")
	public void initListCanalEmisionConfirmacionModificacion() {
		if (boletasBo.checkPlantillaConfirmacion("M", historicoOperacion
				.getProductoCatalogo())) {
			listaCanalConfirmacionEM = boletasBo.getListaCanalConfirmacion("E",
					getTipoContr(), "M");
		} else {
			listaCanalConfirmacionEM = boletasBo.getCanalConfirmacionMM();
		}
		checkListaDeUnElemento(listaCanalConfirmacionEM,
				"canelEmisionConfirmacionModificacion",
				CanalConfirmacion.class, indicadorConfirmacion);
	}

	@Factory("ListaCanalEmisionConfirmacionAnulacion")
	public void initListCanalEmisionConfirmacionAnulacion() {
		if (boletasBo.checkPlantillaConfirmacion("N", historicoOperacion
				.getProductoCatalogo())) {
			listaCanalConfirmacionEN = boletasBo.getListaCanalConfirmacion("E",
					getTipoContr(), "N");
		} else {
			listaCanalConfirmacionEN = boletasBo.getCanalConfirmacionMM();
		}
		checkListaDeUnElemento(listaCanalConfirmacionEN,
				"canelEmisionConfirmacionAnulacion", CanalConfirmacion.class,
				indicadorConfirmacion);
	}

	@Factory("ListaCanalEmisionConfirmacionCancelacion")
	public void initListCanalEmisionConfirmacionCancelacion() {
		if (boletasBo.checkPlantillaConfirmacion("C", historicoOperacion
				.getProductoCatalogo())) {
			listaCanalConfirmacionEC = boletasBo.getListaCanalConfirmacion("E",
					getTipoContr(), "C");
		} else {
			listaCanalConfirmacionEC = boletasBo.getCanalConfirmacionMM();
		}
		checkListaDeUnElemento(listaCanalConfirmacionEC,
				"canelEmisionConfirmacionCancelacion", CanalConfirmacion.class,
				indicadorConfirmacion);
	}

	@Factory("ListaCanalEmisionConfirmacionCancelacionParcial")
	public void initListCanalEmisionConfirmacionCancelacionParcial() {
		if (boletasBo.checkPlantillaConfirmacion("P", historicoOperacion
				.getProductoCatalogo())) {
			listaCanalConfirmacionEP = boletasBo.getListaCanalConfirmacion("E",
					getTipoContr(), "P");
		} else {
			listaCanalConfirmacionEP = boletasBo.getCanalConfirmacionMM();
		}
		checkListaDeUnElemento(listaCanalConfirmacionEP,
				"canelEmisionConfirmacionCancelacionParcial",
				CanalConfirmacion.class, indicadorConfirmacion);
	}

	@Factory("ListaCanalEmisionConfirmacionLiquidacion")
	public void initListCanalEmisionConfirmacionLiquidacion() {
		if (boletasBo.checkPlantillaConfirmacion("X", historicoOperacion
				.getProductoCatalogo())) {
			listaCanalConfirmacionEX = boletasBo.getListaCanalConfirmacion("E",
					getTipoContr(), "X");
		} else {
			listaCanalConfirmacionEX = boletasBo.getCanalConfirmacionMM();
		}
		checkListaDeUnElemento(listaCanalConfirmacionEX,
				"canelEmisionConfirmacionLiquidacion", CanalConfirmacion.class,
				indicadorConfirmacion);
	}

	@Factory("ListaCanalEmisionConfirmacionFijacion")
	public void initListCanalEmisionConfirmacionFijacion() {
		if (boletasBo.checkPlantillaConfirmacion("L", historicoOperacion
				.getProductoCatalogo())) {
			listaCanalConfirmacionEL = boletasBo.getListaCanalConfirmacion("E",
					getTipoContr(), "L");
		} else {
			listaCanalConfirmacionEL = boletasBo.getCanalConfirmacionMM();
		}
		checkListaDeUnElemento(listaCanalConfirmacionEL,
				"canelEmisionConfirmacionFijacion", CanalConfirmacion.class,
				indicadorConfirmacion);
	}

	@Factory("ListaCanalRecepcionConfirmacionAlta")
	public void initListCanalRecepcionConfirmacionAlta() {
		listaCanalConfirmacionRA = boletasBo.getListaCanalConfirmacion("R",
				getTipoContr(), "A");
		checkListaDeUnElemento(listaCanalConfirmacionRA,
				"canelRecepcionConfirmacionAlta", CanalConfirmacion.class,
				indicadorConfirmacion);
	}

	@Factory("ListaCanalRecepcionConfirmacionModificacion")
	public void initListCanalRecepcionConfirmacionModificacion() {
		listaCanalConfirmacionRM = boletasBo.getListaCanalConfirmacion("R",
				getTipoContr(), "M");
		checkListaDeUnElemento(listaCanalConfirmacionRM,
				"canelRecepcionConfirmacionModificacion",
				CanalConfirmacion.class, indicadorConfirmacion);
	}

	@Factory("ListaCanalRecepcionConfirmacionAnulacion")
	public void initListCanalRecepcionConfirmacionAnulacion() {
		listaCanalConfirmacionRN = boletasBo.getListaCanalConfirmacion("R",
				getTipoContr(), "N");
		checkListaDeUnElemento(listaCanalConfirmacionRN,
				"canelRecepcionConfirmacionAnulacion", CanalConfirmacion.class,
				indicadorConfirmacion);
	}

	@Factory("ListaCanalRecepcionConfirmacionCancelacion")
	public void initListCanalRecepcionConfirmacionCancelacion() {
		listaCanalConfirmacionRC = boletasBo.getListaCanalConfirmacion("R",
				getTipoContr(), "C");
		checkListaDeUnElemento(listaCanalConfirmacionRC,
				"canelRecepcionConfirmacionCancelacion",
				CanalConfirmacion.class, indicadorConfirmacion);
	}

	@Factory("ListaCanalRecepcionConfirmacionCancelacionParcial")
	public void initListCanalRecepcionConfirmacionCancelacionParcial() {
		listaCanalConfirmacionRP = boletasBo.getListaCanalConfirmacion("R",
				getTipoContr(), "P");
		checkListaDeUnElemento(listaCanalConfirmacionRP,
				"canelRecepcionConfirmacionCancelacionParcial",
				CanalConfirmacion.class, indicadorConfirmacion);
	}

	@Factory("ListaCanalRecepcionConfirmacionLiquidacion")
	public void initListCanalRecepcionConfirmacionLiquidacion() {
		listaCanalConfirmacionRX = boletasBo.getListaCanalConfirmacion("R",
				getTipoContr(), "X");
		checkListaDeUnElemento(listaCanalConfirmacionRX,
				"canelRecepcionConfirmacionLiquidacion",
				CanalConfirmacion.class, indicadorConfirmacion);
	}

	@Factory("ListaCanalRecepcionConfirmacionFijacion")
	public void initListCanalRecepcionConfirmacionFijacion() {
		listaCanalConfirmacionRL = boletasBo.getListaCanalConfirmacion("R",
				getTipoContr(), "L");
		checkListaDeUnElemento(listaCanalConfirmacionRL,
				"canelRecepcionConfirmacionFijacion", CanalConfirmacion.class,
				indicadorConfirmacion);
	}

	public List<Idioma> getIdiomasConfirmacion(String evento) {
		ProductoCatalogo productoCatalogo = historicoOperacion
				.getProductoCatalogo();

		List<PlantillasConfirmacion> listaPlantillas = entityManager
				.createQuery(
						"SELECT cf " + "FROM ProductoCatalogo pc "
								+ "INNER JOIN pc.plantillasConfirmacions cf "
								+ "LEFT JOIN FETCH cf.idiomaco idioma "
								+ "WHERE pc=:pc").setParameter("pc",
						productoCatalogo).setHint("org.hibernate.cacheable",
						true).setHint("org.hibernate.cacheRegion", "UN_DIA")
				.getResultList();

		List<Idioma> idiomas = new ArrayList<Idioma>();
		for (PlantillasConfirmacion plantillasConfirmacion : listaPlantillas) {
			if (plantillasConfirmacion.getId().getEvenconf().equals(evento)) {
				idiomas.add(plantillasConfirmacion.getIdiomaco());
			}
		}
		if (idiomas.size() == 0) {
			Idioma id = boletaProdCompuestoBo.cargarIdioma("08");
			idiomas.add(id);
		}
		return idiomas;
	}

	@Factory("listaIdiomaConfirmacionAlta")
	public void initIdiomaConfirmacionAlta() {
		listaIdiomaConfirmacionAlta = getIdiomasConfirmacion("A");
	}

	@Factory("listaIdiomaConfirmacionN")
	public void initIdiomaConfirmacionN() {
		listaIdiomaConfirmacionN = getIdiomasConfirmacion("N");
	}

	@Factory("listaIdiomaConfirmacionM")
	public void initIdiomaConfirmacionM() {
		listaIdiomaConfirmacionM = getIdiomasConfirmacion("M");
	}

	@Factory("listaIdiomaConfirmacionL")
	public void initIdiomaConfirmacionL() {
		listaIdiomaConfirmacionL = getIdiomasConfirmacion("L");
	}

	@Factory("listaIdiomaConfirmacionX")
	public void initIdiomaConfirmacionX() {
		listaIdiomaConfirmacionX = getIdiomasConfirmacion("X");
	}

	@Factory("listaIdiomaConfirmacionP")
	public void initIdiomaConfirmacionP() {
		listaIdiomaConfirmacionP = getIdiomasConfirmacion("P");
	}

	@Factory("listaIdiomaConfirmacionC")
	public void initIdiomaConfirmacionC() {
		listaIdiomaConfirmacionC = getIdiomasConfirmacion("C");
	}

	private String getTipoContr() {

		if (entityUtil.checkEntityExists(historicoOperacion.getContrapartida())) {
			AbstractContrapartida abstractContrapartida = entityUtil
					.unwrapProxy(historicoOperacion.getContrapartida(),
							AbstractContrapartida.class);
			if (abstractContrapartida != null
					&& abstractContrapartida instanceof Contrapartida) {
				Contrapartida contrapartida = (Contrapartida) abstractContrapartida;

				if (entityUtil.checkEntityExists(contrapartida
						.getGrupoBancario())
						&& "CLIENTES".equals(contrapartida.getGrupoBancario()
								.getId())) {
					return "C";
				}
			}
		}
		return "B";
	}

	private boolean esAlta() {
		return boletaState == BoletasStates.ALTA_BOLETA;
	}

	public String altaIncompleta() {
		compruebaContrapartida(historicoOperacion.getContrapartida());
		compruebaContrapartida(historicoOperacion.getEntidadMatriz());

		DescripcionEstadoOperacion estado = entityManager.find(
				DescripcionEstadoOperacion.class, "IN");
		historicoOperacion.setEstado(estado);
		ModoActuacion = "I";
		if (altaComun()) {
			// FLM: 1273 debemos poner el ncorrela
			statusMessages.add(Severity.INFO,
					"#{messages['boletas.edicion.alta.incompleta.correcta']} "
							+ historicoOperacion.getId().getNumeroOperacion()
									.toString());

			varModif = Constantes.CONSTANTE_SI;
		}
		// FLM return doRetornar();

		return doCommonRedirect();
	}

	// Antes de llamar persistimos los datos
	private void persistir() {
		// FLM No es necesario !!!
		fijarNominales0();
		preparaSignoSpread();

		if (!entityManager.contains(historicoOperacion)) {
			entityManager.merge(historicoOperacion);
		}
		if (informacionTexto != null) {
			if (!entityManager.contains(informacionTexto)) {
				try {
					entityManager.merge(informacionTexto);
				} catch (EntityNotFoundException e) {
					entityManager.persist(informacionTexto);
				}
			}
		}
		if (hasConfirmacionesTab() && confirmacion != null) {
			if (!entityManager.contains(confirmacion)) {
				try {
					entityManager.merge(confirmacion);
				} catch (EntityNotFoundException e) {
					entityManager.persist(confirmacion);
				}
			}
		}
		if (hasMifidTab() && autorizaOperacion != null) {
			if (!entityManager.contains(autorizaOperacion)) {
				entityManager.merge(autorizaOperacion);
			}
		}

		if (hasDatosOpcionTab() && datosOpcionDelegate != null) {
			HistoricoOpcion historicoOpcion = historicoOperacion
					.getHistoricoOpcion();
			if (esDatosOpcionCobro()) {
				historicoOpcion.setStrikeOpcion(historicoOperacion
						.getStrikeRecibo());
				historicoOpcion.setNocionalFinal(historicoOperacion
						.getNominalRecibo());
			} else if (esDatosOpcionPago()) {
				historicoOpcion.setStrikeOpcion(historicoOperacion
						.getStrikePago());
				historicoOpcion.setNocionalFinal(historicoOperacion
						.getNominalPago());
			}
			if (formulaDatosOpcion != null
					&& formulaDatosOpcion.getValue() != null
					&& formulaDatosOpcion.getValue().getTipoFechasObservacion() != null) {
				historicoOpcion.setTipoFechasObservacion(formulaDatosOpcion
						.getValue().getTipoFechasObservacion());
			} else {
				historicoOpcion.setTipoFechasObservacion(null);
			}

		}

		// SMM 08/10/2015 Eliminamos espacios Campo Su Refer
		if (!GenericUtils.isNullOrBlank(historicoOperacion.getSuReferencia())) {
			historicoOperacion.setSuReferencia(historicoOperacion
					.getSuReferencia().trim());
		}

		// y el resto? opciones
		// fechaspayoff

		//
		entityManager.flush();

		checkSignoSpread();
	}

	private boolean altaComun() {
		Boolean hayException = false;
		try {
			// Para que indinulo se ponga como null y no como N
			/*
			 * IF INDSITUA='A' AND :BLK_MNTO.ESTADOCO = 'IN' THEN -- alta
			 * incompleta Accion='I'; ELSIF INDSITUA='A' AND :BLK_MNTO.ESTADOCO
			 * = 'PV' THEN -- alta completa Accion='A' ELSIF INDSITUA='M' AND
			 * :BLK_MNTO.ESTADOCO = 'PV' THEN -- modificación operación Accion=
			 * 'M' END IF;
			 */
			comprobarSubyacentes();
			persistir();
			if (tramosTableComponent != null) {
				try {
					boletasBo.ajustarLiquidaciones(historicoOperacion,
							tramosTableComponent.getTramosTableList());
				} catch (BoletasBusinessException e) {
					codigoValidacionErroneo = e.getMessage();
					statusMessages
							.add(Severity.ERROR,
									"#{messages['boletas.edicion.error.ajustar.liquidaciones']");
					boletasBo.salirOperacion("R", historicoOperacion, Identity
							.instance().getCredentials().getUsername());
					return false;
				}
			}
			try {
				// FLM: Le paso un valor por defecto, pero por si acaso calculo
				// exactamente el modoactuacion
				// ModoActuacion="";
				if (historicoOperacion.getUltimaAccion() != null
						&& historicoOperacion.getEstado() != null) {
					if ("A".equalsIgnoreCase(historicoOperacion
							.getUltimaAccion().getCodigo())
							&& "IN".equalsIgnoreCase(historicoOperacion
									.getEstado().getCodigo()))
						ModoActuacion = "I";
					else if ("A".equalsIgnoreCase(historicoOperacion
							.getUltimaAccion().getCodigo())
							&& "PV".equalsIgnoreCase(historicoOperacion
									.getEstado().getCodigo()))
						ModoActuacion = "A";
					else if ("M".equalsIgnoreCase(historicoOperacion
							.getUltimaAccion().getCodigo())
							&& "PV".equalsIgnoreCase(historicoOperacion
									.getEstado().getCodigo()))
						ModoActuacion = "M";
				}
				// FLM: Que pasa si no se cumple algo de esto???

				boletasBo.grabarEventosBoleta(historicoOperacion,
						ModoActuacion, Identity.instance().getCredentials()
								.getUsername());
			} catch (BoletasBusinessException e) {
				codigoValidacionErroneo = e.getMessage();
				statusMessages.add(Severity.ERROR,
						"#{messages['boletas.edicion.error.grabar.eventos']");
				boletasBo.salirOperacion("R", historicoOperacion, Identity
						.instance().getCredentials().getUsername());
				return false;
			}
			String result = boletasBo.salirOperacion("C", historicoOperacion,
					Identity.instance().getCredentials().getUsername());
			if (result != null) {
				codigoValidacionErroneo = result;
				statusMessages
						.add(Severity.ERROR,
								"#{messages['boletas.edicion.error.guardar.operacion']");
				return false;
			}
			return true;
		} catch (Throwable thr) {
			hayException = true;
			log.error(thr);
			throw new RuntimeException(thr);
		} finally {
			if (hayException) {
				try {
					boletasBo.salirOperacion("R", historicoOperacion, Identity
							.instance().getCredentials().getUsername());
				} catch (Throwable thr) {
					log.error(thr);
				}
			}
			// boletasBo.salirOperacion("R", historicoOperacion,
			// Identity.instance().getCredentials().getUsername());
			if (boletaState == BoletasStates.MODI_BOLETA) {
				desbloqueo();
			}
		}
	}

	private void comprobarSubyacentes() {
		List<String> listaTipoSubyacentes = new ArrayList<String>();
		listaTipoSubyacentes.add("OP");

		if (historicoOperacion.getHistoricoBarreras() != null
				&& historicoOperacion.getHistoricoBarreras().size() > 0) {

			for (HistoricoBarrera barrera : historicoOperacion
					.getHistoricoBarreras()) {
				listaTipoSubyacentes.add(barrera.getId().getTipbarp1());
			}
		}

		Iterator<HistoricoSubyacente> it = historicoOperacion
				.getHistoricoSubyacentes().iterator();
		while (it.hasNext()) {
			HistoricoSubyacente subyacente = it.next();
			if (!listaTipoSubyacentes
					.contains(subyacente.getId().getTiposuby())) {
				it.remove(); // avoids a ConcurrentModificationException
			}
		}
	}

	private void preparaSignoSpread() {
		if (signoCobro == Signo.MENOS
				&& historicoOperacion.getSpreadRecibo() != null
				&& historicoOperacion.getSpreadRecibo().signum() != -1) {
			historicoOperacion.setSpreadRecibo(historicoOperacion
					.getSpreadRecibo().negate());
		}
		if (signoPago == Signo.MENOS
				&& historicoOperacion.getSpreadPago() != null
				&& historicoOperacion.getSpreadPago().signum() != -1) {
			historicoOperacion.setSpreadPago(historicoOperacion.getSpreadPago()
					.negate());
		}
	}

	private void addMessage(String message) {
		statusMessages.add(Severity.ERROR, "#{messages['" + message + "']}");
		retDadesValides = false;
	}

	private void addWarning(String message) {
		statusMessages.add(Severity.WARN, "#{messages['" + message + "']}");
		retWarnings = retWarnings + " " + Messages.instance().get(message);
		retDadesAmbWarnings = true;
	}

	private boolean isNull(Object obj) {
		return GenericUtils.isNullOrBlank(obj);
	}

	private boolean menorQue(Date d1, Date d2) {
		if (!isNull(d1) && !isNull(d2) && d1.before(d2))
			return true;
		else
			return false;
	}

	private boolean mayorQue(Date d1, Date d2) {
		if (!isNull(d1) && !isNull(d2) && d1.after(d2))
			return true;
		else
			return false;
	}

	private boolean menorIgualQue(Date d1, Date d2) {
		if (!isNull(d1) && !isNull(d2) && (d1.before(d2) || d1.equals(d2)))
			return true;
		else
			return false;
	}

	private boolean mayorIgualQue(Date d1, Date d2) {
		if (!isNull(d1) && !isNull(d2) && (d1.after(d2) || d1.equals(d2)))
			return true;
		else
			return false;
	}

	/**
	 * 
	 * 1. Control campos obligatorios. Se debe comprobar que s los campos
	 * obligatorios estén informados (deri.relproda, campo idoblopc = ‘S) =>El
	 * control de campos obligatorios se realiza en la fase de validacion de
	 * JSF. Previamente se ha invocado al action para poner el flag de
	 * validacion a true (ver en operaciones.xhtml el commandButton de operacion
	 * onclick="doForceValidation(true);". El observer onCreateView recorre
	 * entonces los controles JSF y aplica los required que se han establecido
	 * en RelProductoDatosAtributo.
	 */
	public String altaCompleta() {
		/*
		 * boletas.messageBox.crear.calendario=El calendario no existe, la
		 * operación está incompleta, ¿quiere crearlo ahora?'
		 * boletas.alta.completa.error.sin.calendario=No se puede guardar una
		 * operación sin calendario asociado
		 * boletas.alta.completa.messageBox.calendario.modificado=Se han
		 * modificado datos que afectan al calendario ¿desea crearlo de nuevo?'
		 * 
		 * boletas.alta.completa.messageBox.calendario.fecha.festiva=La fecha de
		 * vencimiento es festiva para alguna de las divisas de liquidación,
		 * ¿quiere generar el calendario con esta fecha?
		 * boletas.alta.completa.error.perdida.historico=La regeneración del
		 * calendario provocaría la perdida del histórico de liquidaciones, se
		 * mostrará el calendario vigente
		 * boletas.alta.completa.aviso.ir.a.mantram=Recuerde que debe pulsar el
		 * boton "Calendario" y volver a grabar
		 * boletas.alta.completa.error.crear.calendario=Error al crear
		 * Calendario (#{codigoValidacionErroneo}) .Contactar con responsable de
		 * tecnología
		 */

		checkTipoCobroPago();
		persistir();
		// Validaciones, las ejecutamos todas y las mostramos
		dadesValides();
		dadesValidesParam();
		dadesValidesProd();
		dadesValidesConfirmaciones();
		canalesValidos();
		dadesValidesSubyacente();
		// Comprovar que per cada tram variable existeixi el seu corresponent
		// index vàlid.
		// SMM Se incluye en package validaciones
		// dadesValidesCalendari(false);
		// validaciones añadidas al grabar
		validaGrupoContable();
		validaClaveExternaBDU();
		// CAM interin
		validaCAM();
		validaDatosEmir();
		validarDatosIndFloor();

		validarDatosMifid();
		validarAutoriza();
		validaReporting();
		validarNormaIV();

		packageValidaciones();

		// TO_DO MOVER LO MAS ABAJO POSIBLE QUE NO SEA POSIBLE QUE HAYA ERRORES
		// YQUE SEAPAMOS QUE ES ALTA COPMPLETA
		validarConfirmaciones();

		if (retDadesValides && !retDadesAmbWarnings) {
			return altaCompletaDo();
		} else {
			if (retDadesValides && retDadesAmbWarnings) {
				// FLM: si solo tenemos warnings los mostramos con un msg
				// decisional
				statusMessages.clear();
				messageBoxAction.init(retWarnings,
						"boletasAction.altaCompletaDo()",
						"boletasAction.onMessageBoxKoNoHacerNada()");
				return Constantes.FAIL;
			} else {
				// Els warnings els mostrem
				// statusMessages.addFromResourceBundle(Severity.WARN,
				// retWarnings);
				return Constantes.FAIL;
			}
		}

	}

	private void dadesValidesSubyacente() {

		if (hasDatosOpcionTab()) {

			if (!GenericUtils.isNullOrBlank(historicoOperacion
					.getHistoricoSubyacentes())) {

				for (HistoricoSubyacente histo : historicoOperacion
						.getHistoricoSubyacentes()) {
					if ("OP".equals(histo.getId().getTiposuby())) {
						return;
					}
				}
			}

			addMessage("boletas.dadesValidades.SubyacenteOpcion");

		}
		return;
	}

	public void packageValidaciones() {

		StringBuffer errorCode = new StringBuffer();
		// SMM 14/06/2018 warn
		StringBuffer warn = new StringBuffer();

		// SMM 14/06/2018 warn
		// if
		// (!mantOperBo.packageValidaciones(historicoOperacion,Identity.instance().getCredentials().getUsername(),Constantes.ORDEN_VALIDAR,errorCode)){
		if (!mantOperBo.packageValidaciones(historicoOperacion, Identity.instance().getCredentials().getUsername(),
				Constantes.ORDEN_VALIDAR, errorCode, warn)) {
			// addMessage(historicoOperacion,
			// ResourceBundle.instance().getString("") + errorCode.toString());
			// SMM 14/06/2018 warn
			if (!GenericUtils.isNullOrBlank(warn)
					&& "99".equals(warn.toString())) {
				statusMessages.add(Severity.WARN,
						"#{messages['boletas.packageValidaciones']}"
								+ errorCode.toString());
				retWarnings = retWarnings
						+ " "
						+ Messages.instance()
								.get("boletas.packageValidaciones")
						+ errorCode.toString();
				retDadesAmbWarnings = true;
			} else {
				statusMessages.add(Severity.ERROR,
						"#{messages['boletas.packageValidaciones']}"
								+ errorCode.toString());
				retDadesValides = false;
			}

			// statusMessages.add(Severity.ERROR,
			// "#{messages['boletas.packageValidaciones']}" +
			// errorCode.toString());
			// statusMessages.add(Severity.ERROR, "#{messages['" + message +
			// "']}");

		}

	}

	public void onTipoClienteChange() {
		if (GenericUtils.isNullOrBlank(autorizaOperacion)
				|| GenericUtils.isNullOrBlank(autorizaOperacion.getTipoclie())
				|| !"MN".equalsIgnoreCase(autorizaOperacion.getTipoclie()
						.getCodigo())) {

			historicoOperacion.setValorActual(null);
			historicoOperacion.setValorAnual(null);
			historicoOperacion.setIndicadorNormaIV(false);
		} else {
			calculoNormaIV();
		}

	}

	public boolean disableNormaIV() {

		if (!hasMifidTab()
				|| GenericUtils.isNullOrBlank(autorizaOperacion)
				|| GenericUtils.isNullOrBlank(autorizaOperacion.getTipoclie())
				|| !"MN".equalsIgnoreCase(autorizaOperacion.getTipoclie()
						.getCodigo())) {

			return true;

		}

		return false;
	}

	public void validarNormaIV() {
		if (GenericUtils.isNullOrBlank(historicoOperacion.getValorActual())
				&& GenericUtils.isNullOrBlank(historicoOperacion
						.getValorAnual())) {
			calculoNormaIV();
		}
	}

	public void calculoNormaIV() {

		if (!hasMifidTab()
				|| GenericUtils.isNullOrBlank(historicoOperacion
						.getCostesEntrada())
				|| GenericUtils.isNullOrBlank(historicoOperacion
						.getDivisaCostes())
				|| (GenericUtils.isNullOrBlank(historicoOperacion
						.getNominalRecibo()) && GenericUtils
						.isNullOrBlank(historicoOperacion.getNominalPago())))
			return;

		if (!GenericUtils.isNullOrBlank(autorizaOperacion)
				&& !GenericUtils.isNullOrBlank(autorizaOperacion.getTipoclie())
				&& "MN".equalsIgnoreCase(autorizaOperacion.getTipoclie()
						.getCodigo())) {

			StringBuffer errorCode = new StringBuffer();
			String tipoCalculo = "B";

			persistir();

			// if (false){
			if (!mantOperBo.calculoNormaIV(historicoOperacion, null,
					tipoCalculo, errorCode)) {
				statusMessages.add(Severity.WARN,
						"#{messages['boletas.packageNormaIV']}"
								+ errorCode.toString());
			} else {
				comprobarAvisoNormaIV();
			}

		}

	}

	public void comprobarAvisoNormaIV() {

		if (!GenericUtils.isNullOrBlank(historicoOperacion.getValorActual())
				&& !GenericUtils.isNullOrBlank(historicoOperacion
						.getValorAnual())) {

			NormaIVParam umbrales = boletasBo.obtenerUmbralesNormaIV();
			if (umbrales != null) {

				// -1, 0, or 1 as this BigDecimal is numerically less than,
				// equal to, or greater than val.
				if (historicoOperacion.getValorActual().compareTo(
						umbrales.getUmbralValorActual()) > 0
						|| historicoOperacion.getValorAnual().compareTo(
								umbrales.getUmbralValorAnual()) > 0) {
					historicoOperacion.setIndicadorNormaIV(true);
				} else {
					historicoOperacion.setIndicadorNormaIV(false);
				}
			} else {
				if (historicoOperacion.getValorActual().compareTo(
						new BigDecimal(5)) > 0
						|| historicoOperacion.getValorAnual().compareTo(
								new BigDecimal(0.6)) > 0) {
					historicoOperacion.setIndicadorNormaIV(true);
				} else {
					historicoOperacion.setIndicadorNormaIV(false);
				}
			}

		}

	}

	public void validarDatosMifid() {
		// obtenerSessionId();
		if (botonMIFID()) {
			// obtenerAutorizacionMIFID(true);
			// String sesionMifid = "9d48a9ae-0a58-4bda-9bba-b2c7996c7c85";

			//SMM 18/10/2018
			String sesionMifid = null;
			if (GenericUtils.isNullOrBlank(sessionId)){
				sesionMifid = obtenerSesionValidacionTesoreria();
				sessionId = sesionMifid;
			}else{
				sesionMifid = sessionId;
			}
			
//			String sesionMifid = obtenerSesionValidacionTesoreria();
			if (!GenericUtils.isNullOrBlank(sesionMifid)) {
				datosMifidWS(sesionMifid, historicoOperacion
						.getClaveExternaBDU());

				// SMM 25/06/2018
				// if (GenericUtils.isNullOrBlank(autorizaOperacion) ||
				// GenericUtils.isNullOrBlank(autorizaOperacion.getTipoclie())
				// ||
				// !"MN".equalsIgnoreCase(autorizaOperacion.getTipoclie().getCodigo())){
				//					
				// historicoOperacion.setValorActual(null);
				// historicoOperacion.setValorAnual(null);
				// historicoOperacion.setIndicadorNormaIV(null);
				// }

			}

		}

	}

	private boolean esFechaValida(String contenidoCampo) {
		if (contenidoCampo == null
				|| !contenidoCampo.matches("\\d{4}-[01]\\d-[0-3]\\d"))
			return false;
		SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd");
		df.setLenient(false);
		try {
			df.parse(contenidoCampo);
			return true;
		} catch (Exception ex) {
			return false;
		}
	}

	private boolean esHoraValida(String contenidoCampo) {
		// if (contenidoCampo == null ||
		// !contenidoCampo.matches("\\d{4}-[01]\\d-[0-3]\\d"))
		// return false;
		//		  
		SimpleDateFormat df = new SimpleDateFormat("HH:mm:ss");
		df.setLenient(false);
		try {
			df.parse(contenidoCampo);
			return true;
		} catch (Exception ex) {
			return false;
		}
	}

	private boolean validarTimeStamp(String fechaCierre) {
		// Ejemplo 1999-09-29T15:12:59.132498

		if (fechaCierre.length() != 26)
			return false;

		if (!esFechaValida(fechaCierre.substring(0, 10)))
			return false;

		if (!"T".equals(fechaCierre.substring(10, 11)))
			return false;

		if (!esHoraValida(fechaCierre.substring(11, 19)))
			return false;

		if (!".".equalsIgnoreCase(fechaCierre.substring(19, 20)))
			return false;

		if (!fechaCierre.substring(20, 26).matches("\\d{6}"))
			return false;

		return true;
	}

	public void validaReporting() {
		String pattern = "dd/mm/yyyy";
		SimpleDateFormat format = new SimpleDateFormat(pattern);
		Date fechaComparacion = null;
 
		try {
			fechaComparacion = format.parse("03/01/2018");
		} catch (ParseException e) {
			fechaComparacion = new Date(2018, 1, 3);
		}
				
		if (hasRegulatorioTab()
				&& !mantOperBo.esOperacionInterna(historicoOperacion)) {

			if (!GenericUtils.isNullOrBlank(historicoOperacion
					.getFechaCierreMicro())
					&& !validarTimeStamp(historicoOperacion
							.getFechaCierreMicro())) {
				addMessage("boletas.validaDatosReporting.formatoFechaCierre");
			}

			if (GenericUtils.isNullOrBlank(historicoOperacion
					.getUsuarioDecisor())
					|| GenericUtils.isNullOrBlank(historicoOperacion
							.getUsuarioEjecutor())
					|| GenericUtils.isNullOrBlank(historicoOperacion
							.getFechaCierreMicro())) {

				if ((!GenericUtils.isNullOrBlank(historicoOperacion
						.getProducto())
						&& !GenericUtils.isNullOrBlank(historicoOperacion
								.getProducto().getIndicadorClase2()) && GenericUtils
						.in(historicoOperacion.getProducto()
								.getIndicadorClase2(), "RF", "EQUI", "CDS",
								"CDI", "RV")
						&& historicoOperacion.getId().getFechaContratacion().compareTo(fechaComparacion)>=0)
						|| (!GenericUtils.isNullOrBlank(historicoOperacion
								.getTradeTv()) && "S"
								.equalsIgnoreCase(historicoOperacion
										.getTradeTv().getCodigo()))
						|| !GenericUtils.isNullOrBlank(historicoOperacion
								.getMicTv())) {

					addMessage("boletas.validaDatosReporting.reporteTR");
				}

			}

			if (GenericUtils.isNullOrBlank(historicoOperacion
					.getFechaCierreMicro())) {
				addMessage("boletas.validaDatosReporting.fechaCierre");
			}

		}

	}

	public void validarAutoriza() {
		// Indicador de servicio
		// Indicador de forzado
		// Tipo de cliente
		if (hasMifidTab()) {
			if (autorizaOperacion.getIndiforza() == null) {
				// DescripcionAutorizaIndiforza indi =
				// (DescripcionAutorizaIndiforza)
				// entityManager.createQuery("from DescripcionAutorizaIndiforza where codigo='N'").getSingleResult();
				// autorizaOperacion.setIndiforza(indi);
				addMessage("boletas.validaDatosAutoriza.Indiforza");
			}
			// if (autorizaOperacion.getIndenvio() == null) {
			// // autorizaOperacion.setIndenvio(false);
			// addMessage("boletas.validaDatosAutoriza.Indenvio");
			// }
			if (autorizaOperacion.getTipoclie() == null) {
				addMessage("boletas.validaDatosAutoriza.TipoCliente");
			}
			if (autorizaOperacion.getIndiserv() == null) {
				addMessage("boletas.validaDatosAutoriza.IndiServ");
			}

			// SMM 04/10/2017
			if (autorizaOperacion.getInditipo() == null
					&& historicoOperacion.getUltimaAccion() != null
					&& "A".equalsIgnoreCase(historicoOperacion
							.getUltimaAccion().getCodigo())
					&& historicoOperacion.getEstado() != null
					&& ("IN".equals(historicoOperacion.getEstado().getCodigo()) || "PV"
							.equals(historicoOperacion.getEstado().getCodigo()))) {

				addMessage("boletas.validaDatosAutoriza.finalidad");

			}

		}

	}

	private Boolean validacionFirmaDigital(String sesionValidarConfirmacion,
			AbstractContrapartida contrapartida) {

		Contrapartida contrapa = obtenerContrapaBase(contrapartida);
		List<Long> numpersonas = new ArrayList<Long>();
		Long numPersoEmpresa = null;

		if (!GenericUtils.isNullOrBlank(contrapa)) {

			if ("S".equalsIgnoreCase(contrapa.getIndFirmaManualForzada())) {
				return false;
			}

			// SMM 01/06/2016 Si no tenemos Tipperso no miramos grabamos errror
			// en tabla
			if (GenericUtils.isNullOrBlank(contrapa.getTipoPersona())) {
				boletasBo.saveResultadoToLog(
						ConstantesFD.VALIDACION_FIRMANTES_APODERA,
						ConstantesFD.VALIDACION_FIRMANTES_APODERATXT,
						historicoOperacion,
						ConstantesFD.VALIDACION_FIRMANTES_BOL,
						ConstantesFD.VALIDACION_FIRMANTES_KO);
				return false;
			}

			if (!"F".equalsIgnoreCase(contrapa.getTipoPersona())) {

				List<Apoderado> apoderados = boletasBo.apoderadosDeContrapa(
						contrapa.getId(), ConstantesFD.IND_MASOL_SOLIDARIA,
						contrapa.getTipoPersona());

				if (GenericUtils.isNullOrBlank(apoderados)
						|| apoderados.isEmpty() || apoderados.size() == 0) {
					boletasBo.saveResultadoToLog(
							ConstantesFD.VALIDACION_FIRMANTES_APODERA2,
							ConstantesFD.VALIDACION_FIRMANTES_APODERA2TXT,
							historicoOperacion,
							ConstantesFD.VALIDACION_FIRMANTES_BOL,
							ConstantesFD.VALIDACION_FIRMANTES_KO);
					return false;
				}

				for (Apoderado apoderado : apoderados) {

					// //SMM 03/12/2015 Mancomunadas NO tienen FD
					// if
					// (ConstantesFD.IND_MASOL_MANCOMUNADA.equalsIgnoreCase(apoderado.getIndMasol())){
					//						
					// boletasBo.saveResultadoToLog(ConstantesFD.VALIDACION_FIRMANTES_APODERA3,
					// ConstantesFD.VALIDACION_FIRMANTES_APODERA3TXT,
					// historicoOperacion,
					// ConstantesFD.VALIDACION_FIRMANTES_BOL,
					// ConstantesFD.VALIDACION_FIRMANTES_KO);
					//						
					// return false;
					// }

					if (!GenericUtils.isNullOrBlank(apoderado.getCapoderado())
							&& !GenericUtils.isNullOrBlank(apoderado
									.getCapoderado().getNumPerso())) {
						numpersonas.add(apoderado.getCapoderado().getNumPerso()
								.longValue());
					} else {
						boletasBo.saveResultadoToLog(
								ConstantesFD.VALIDACION_FIRMANTES_APODERA,
								ConstantesFD.VALIDACION_FIRMANTES_APODERATXT,
								historicoOperacion,
								ConstantesFD.VALIDACION_FIRMANTES_BOL,
								ConstantesFD.VALIDACION_FIRMANTES_KO);
						return false;
					}
				}

				// Se necesita numPersoEmpresa cuando se trata de personas no
				// fisicas
				if (!GenericUtils.isNullOrBlank(contrapa.getNumeroPersona())) {
					numPersoEmpresa = contrapa.getNumeroPersona().longValue();
				} else {
					boletasBo.saveResultadoToLog(
							ConstantesFD.VALIDACION_FIRMANTES_APODERA,
							ConstantesFD.VALIDACION_FIRMANTES_APODERATXT,
							historicoOperacion,
							ConstantesFD.VALIDACION_FIRMANTES_BOL,
							ConstantesFD.VALIDACION_FIRMANTES_KO);
					return false;
				}

			} else if (!GenericUtils.isNullOrBlank(contrapa.getNumeroPersona())) {
				Long numperso = contrapa.getNumeroPersona().longValue();
				numpersonas.add(numperso);
			} else {
				boletasBo.saveResultadoToLog(
						ConstantesFD.VALIDACION_FIRMANTES_APODERA,
						ConstantesFD.VALIDACION_FIRMANTES_APODERATXT,
						historicoOperacion,
						ConstantesFD.VALIDACION_FIRMANTES_BOL,
						ConstantesFD.VALIDACION_FIRMANTES_KO);
				return false;
			}

		} else {
			boletasBo.saveResultadoToLog(
					ConstantesFD.VALIDACION_FIRMANTES_CONTRAPA,
					ConstantesFD.VALIDACION_FIRMANTES_CONTRAPATXT,
					historicoOperacion, ConstantesFD.VALIDACION_FIRMANTES_BOL,
					ConstantesFD.VALIDACION_FIRMANTES_KO);
			return false;
		}

		if (GenericUtils.isNullOrBlank(numpersonas) || numpersonas.isEmpty()
				|| numpersonas.size() == 0) {
			boletasBo.saveResultadoToLog(
					ConstantesFD.VALIDACION_FIRMANTES_APODERA,
					ConstantesFD.VALIDACION_FIRMANTES_APODERATXT,
					historicoOperacion, ConstantesFD.VALIDACION_FIRMANTES_BOL,
					ConstantesFD.VALIDACION_FIRMANTES_KO);
			return false;
		}

		Fp7005I inputdata = null;
		for (Long persona : numpersonas) {

			// CODOPCION : ‘PE’
			// CODCONTRAT: numpersona particular

			// CODOPCION : ‘PJ’
			// CODCONTRAT: numpersona autoritzat
			// TIPEXP: numpersona de l’empresa (completat amb 0 per l’esquerra).
			// 20 caràcters alfanumèrics.

			String opcion, tipExp;
			if (GenericUtils.isNullOrBlank(numPersoEmpresa)) {
				// Persona FISICA
				opcion = ConstantesFD.CODIGO_OPCION_PE;
				tipExp = "0";
			} else {
				opcion = ConstantesFD.CODIGO_OPCION_PJ;
				tipExp = GenericUtils.lpad(numPersoEmpresa.toString(), 20, "0");
			}

			inputdata = new Fp7005I(opcion, ConstantesFD.CODIGO_ENTIDAD_81,
					"0", persona, "0", "0", "0", tipExp, "0", "0", "0", "0");

			try {

				ExecuteResponse resposta = validacionFD.autorizacionTest(
						sesionValidarConfirmacion, inputdata);

				System.out.println("validacionFD OK O NO");
				if (!GenericUtils.isNullOrBlank(resposta)
						&& !GenericUtils
								.isNullOrBlank(resposta.getOutputData())) {

					System.out.println("validacionFD OK =-"
							+ resposta.getOutputData() + "-");
					System.out.println("validacionFD IndFc OK =-"
							+ resposta.getOutputData().getIndFc() + "-");

					if (!"S".equalsIgnoreCase(resposta.getOutputData()
							.getIndFc())) {
						boletasBo.saveResultadoToLog(
								ConstantesFD.VALIDACION_FIRMANTES_CODOK,
								ConstantesFD.VALIDACION_FIRMANTES_FDKO
										+ contrapartida.getId(),
								historicoOperacion,
								ConstantesFD.VALIDACION_FIRMANTES_BOL,
								ConstantesFD.VALIDACION_FIRMANTES_OK);
						return false;
					}

					if (!GenericUtils.isNullOrBlank(resposta.getOutputData()
							.getFp7005Or())
							&& resposta.getOutputData().getFp7005Or().length > 0) {

						System.out.println("validacionFD IndBd OK =-"
								+ resposta.getOutputData().getFp7005Or(0)
										.getIndBd() + "-");
						System.out.println("validacionFD IndMovAa OK =-"
								+ resposta.getOutputData().getFp7005Or(0)
										.getIndMovAa() + "-");

						if (!"S".equalsIgnoreCase(resposta.getOutputData()
								.getFp7005Or(0).getIndBd())
								|| !"S".equalsIgnoreCase(resposta
										.getOutputData().getFp7005Or(0)
										.getIndMovAa())) {

							boletasBo.saveResultadoToLog(
									ConstantesFD.VALIDACION_FIRMANTES_CODOK,
									ConstantesFD.VALIDACION_FIRMANTES_FDKO
											+ contrapartida.getId(),
									historicoOperacion,
									ConstantesFD.VALIDACION_FIRMANTES_BOL,
									ConstantesFD.VALIDACION_FIRMANTES_OK);
							return false;
						}

					} else {
						boletasBo.saveResultadoToLog(
								ConstantesFD.LOG_COD_ERROR_SIN_ACCESO_WS,
								ConstantesFD.VALIDACION_FIRMANTES_VACIA,
								historicoOperacion,
								ConstantesFD.VALIDACION_FIRMANTES_BOL,
								ConstantesFD.VALIDACION_FIRMANTES_KO);
						return false;
					}

				} else {
					boletasBo.saveResultadoToLog(
							ConstantesFD.LOG_COD_ERROR_SIN_ACCESO_WS,
							ConstantesFD.VALIDACION_FIRMANTES_VACIA,
							historicoOperacion,
							ConstantesFD.VALIDACION_FIRMANTES_BOL,
							ConstantesFD.VALIDACION_FIRMANTES_KO);
					return false;
				}

			} catch (Exception e) {
				boletasBo.saveResultadoToLog(
						ConstantesFD.LOG_COD_ERROR_SIN_ACCESO_WS, e
								.getMessage(), historicoOperacion,
						ConstantesFD.VALIDACION_FIRMANTES_BOL,
						ConstantesFD.VALIDACION_FIRMANTES_KO);
				System.out.println("validacionFD=-" + e.getMessage() + "-");
				e.printStackTrace();
				return false;
			}

		}

		boletasBo.saveResultadoToLog(ConstantesFD.VALIDACION_FIRMANTES_CODOK,
				ConstantesFD.VALIDACION_FIRMANTES_FDOK + contrapartida.getId(),
				historicoOperacion, ConstantesFD.VALIDACION_FIRMANTES_BOL,
				ConstantesFD.VALIDACION_FIRMANTES_OK);
		return true;

	}

	private String generarStringLlamada(String sessionId, String globalid) {

		StringBuilder sb = new StringBuilder();
		String retorno = new String("\r\n");

		sb.append("ApplicationId: DERI").append(retorno);
		sb.append("Language: ES").append(retorno);
		sb.append("Step: 1").append(retorno);
		sb.append("TrackingId: DERI:MIFID:").append(retorno);
		sb.append("PROCEDENCIA: DP01").append(retorno);
		sb.append("TIPCONTRATO: 05").append(retorno);
		sb.append("TIP-PERSONA: 99").append(retorno);
		sb.append("CODOPEINF: MF36").append(retorno);
		sb.append("SessionId: " + sessionId).append(retorno);
		sb.append("Globalid: " + globalid);

		return sb.toString();

	}

	private Boolean datosMifidWS(String sesionMifid, String globalId) {

		if (GenericUtils.isNullOrBlank(globalId)) {
			boletasBo.saveResultadoToLog(ConstantesFD.MIFIDWS_GLOBALID_SHORT,
					ConstantesFD.MIFIDWS_GLOBALID_ERROR, historicoOperacion,
					ConstantesFD.MIFIDWS, ConstantesFD.VALIDACION_FIRMANTES_KO);
			return false;
		}

		String llamadaStr = generarStringLlamada(sesionMifid, globalId);

		try {

			MIFIDMF7232Response resposta = mifidWS.mifidWS(sesionMifid,
					globalId);

			//				
			// *Numero de autorización: Número de autorización MIFID
			// *Indicador de servicio: Es el tipo de servicio prestado (EJ:
			// Ejecución, AS: Asesoramiento etc...)
			// *Indicador de forzado: Indicador forzada (S /N)
			// *Tipo de cliente :Es el cod seguimiento de cliente MIFID: (M:
			// minorista, P profesional etc..)
			// Código de autorización: Un código de dos posiciones (05, SE,
			// 02,10,SC..).
			// *Indicador de tipo (tipo de cobertura MIFID) :(ES: Especulativa,
			// CO: Cobertura etc..)

			if (!GenericUtils.isNullOrBlank(resposta)
					&& !GenericUtils.isNullOrBlank(resposta.getOutputData())
					&& !GenericUtils.isNullOrBlank(resposta.getOutputData()
							.getMf7232Output())) {

				/*
				 * Ejemplo Resposta 2015-08-11 14:04:00,060 INFO [STDOUT]
				 * MIFIDWS OK
				 * =-com.bs.proteo.soa.service.mifid.mf7232.svmifidmf7232
				 * .domain.MIFIDMF7232Output@1dd3b27d- 2015-08-11 14:04:00,061
				 * INFO [STDOUT] MIFIDWS OK CodAutoriza =-500409133- 2015-08-11
				 * 14:04:00,061 INFO [STDOUT] MIFIDWS OK Codsegmento =-M-
				 * 2015-08-11 14:04:00,061 INFO [STDOUT] MIFIDWS OK Descerror
				 * =-- 2015-08-11 14:04:00,061 INFO [STDOUT] MIFIDWS OK
				 * Indiforzada =-N- 2015-08-11 14:04:00,061 INFO [STDOUT]
				 * MIFIDWS OK Retsitu =-29- 2015-08-11 14:04:00,061 INFO
				 * [STDOUT] MIFIDWS OK Tipcob =-- 2015-08-11 14:04:00,061 INFO
				 * [STDOUT] MIFIDWS OK Tipservicio =-CO- 2015-08-11 14:04:00,061
				 * INFO [STDOUT] MIFIDWS OK Codretorn =-0- 2015-08-11
				 * 14:04:00,061 INFO [STDOUT] MIFIDWS OK Numpersona =-0-
				 * 2015-08-11 14:04:00,061 INFO [STDOUT] MIFIDWS OK TypeDesc
				 * =-org.apache.axis.description.TypeDesc@2590674d-
				 */

				System.out.println("MIFIDWS OK =-" + resposta.getOutputData()
						+ "-");
				System.out.println("MIFIDWS OK CodAutoriza =-"
						+ resposta.getOutputData().getMf7232Output()
								.getCodautorizacio() + "-");

				System.out.println("MIFIDWS OK Codsegmento =-"
						+ resposta.getOutputData().getMf7232Output()
								.getCodsegmento() + "-");
				System.out.println("MIFIDWS OK Descerror =-"
						+ resposta.getOutputData().getMf7232Output()
								.getDescerror() + "-");
				System.out.println("MIFIDWS OK Indiforzada =-"
						+ resposta.getOutputData().getMf7232Output()
								.getIndiforzada() + "-");
				System.out.println("MIFIDWS OK Retsitu =-"
						+ resposta.getOutputData().getMf7232Output()
								.getRetsitu() + "-");
				System.out.println("MIFIDWS OK Tipcob =-"
						+ resposta.getOutputData().getMf7232Output()
								.getTipcob() + "-");
				System.out.println("MIFIDWS OK Tipservicio =-"
						+ resposta.getOutputData().getMf7232Output()
								.getTipservicio() + "-");

				System.out.println("MIFIDWS OK Codretorn =-"
						+ resposta.getOutputData().getMf7232Output()
								.getCodretorn() + "-");
				System.out.println("MIFIDWS OK Numpersona =-"
						+ resposta.getOutputData().getMf7232Output()
								.getNumpersona() + "-");
				System.out.println("MIFIDWS OK TypeDesc =-"
						+ resposta.getOutputData().getMf7232Output()
								.getTypeDesc() + "-");

				System.out.println("MIFIDWS OK Asesora =-"
						+ resposta.getOutputData().getMf7232Output()
								.getTexasesora() + "-");
				System.out.println("MIFIDWS OK Manuscr =-"
						+ resposta.getOutputData().getMf7232Output()
								.getTexmanuscr() + "-");

				if (!GenericUtils.isNullOrBlank(resposta.getOutputData()
						.getMf7232Output().getCodautorizacio())
						&& BigInteger.ZERO.compareTo(resposta.getOutputData()
								.getMf7232Output().getCodautorizacio()) != 0) {

					autorizaOperacion.setNumautor(resposta.getOutputData()
							.getMf7232Output().getCodautorizacio().longValue());
				} else {
					String errorCodAutor = ConstantesFD.MIFIDWS_CODAUTORIZA_KO;

					if (!GenericUtils.isNullOrBlank(resposta.getOutputData()
							.getMf7232Output().getCodautorizacio())) {
						errorCodAutor = errorCodAutor.concat(resposta
								.getOutputData().getMf7232Output()
								.getCodautorizacio().toString());
					}
					autorizaOperacion.setIndenvio(false);
					boletasBo.saveResultadoToLog(
							ConstantesFD.LOG_COD_ERROR_SIN_ACCESO_WS,
							errorCodAutor, historicoOperacion,
							ConstantesFD.MIFIDWS,
							ConstantesFD.VALIDACION_FIRMANTES_KO, llamadaStr);
					return false;
				}

				if (!GenericUtils.isNullOrBlank(resposta.getOutputData()
						.getMf7232Output().getIndiforzada())) {

					DescripcionAutorizaIndiforza indiforza;
					indiforza = boletasBo
							.getDescripcionAutorizaIndiforza(resposta
									.getOutputData().getMf7232Output()
									.getIndiforzada());

					if (!GenericUtils.isNullOrBlank(indiforza)) {
						autorizaOperacion.setIndiforza(indiforza);
					}

				}

				/*
				 * Código Segmento ‘M’: Minorista ‘P’: Profesional ‘C’:
				 * Contraparte ‘D’: Desclasificado
				 * 
				 * D no se trata,se dejara con el valor que hubiera
				 */
				if (!GenericUtils.isNullOrBlank(resposta.getOutputData()
						.getMf7232Output().getCodsegmento())) {

					DescripcionAutorizaTipoCliente tipoclie = null;

					if ("M".equalsIgnoreCase(resposta.getOutputData()
							.getMf7232Output().getCodsegmento())) {
						tipoclie = boletasBo
								.getDescripcionAutorizaTipoCliente("MN");
					} else if ("P".equalsIgnoreCase(resposta.getOutputData()
							.getMf7232Output().getCodsegmento())) {
						tipoclie = boletasBo
								.getDescripcionAutorizaTipoCliente("PF");
					} else if ("C".equalsIgnoreCase(resposta.getOutputData()
							.getMf7232Output().getCodsegmento())) {
						tipoclie = boletasBo
								.getDescripcionAutorizaTipoCliente("CT");
					}

					if (!GenericUtils.isNullOrBlank(tipoclie)) {
						autorizaOperacion.setTipoclie(tipoclie);
					}

				}

				/*
				 * Tipo de servicio 'SE' (sólo ejecución) 'CO'
				 * (comercialización) 'AS' (asesoramiento) 'VA' (venta
				 * asesorada)
				 */
				if (!GenericUtils.isNullOrBlank(resposta.getOutputData()
						.getMf7232Output().getTipservicio())) {

					DescripcionAutorizaIndiserv indiserv;

					if ("SE".equalsIgnoreCase(resposta.getOutputData()
							.getMf7232Output().getTipservicio())) {
						indiserv = boletasBo
								.getDescripcionAutorizaIndiserv("EJ");
					} else if ("VA".equalsIgnoreCase(resposta.getOutputData()
							.getMf7232Output().getTipservicio())) {
						indiserv = boletasBo
								.getDescripcionAutorizaIndiserv("AS");
					} else {
						indiserv = boletasBo
								.getDescripcionAutorizaIndiserv(resposta
										.getOutputData().getMf7232Output()
										.getTipservicio());
					}

					if (!GenericUtils.isNullOrBlank(indiserv)) {
						autorizaOperacion.setIndiserv(indiserv);
					}

				}
				// SMM 16/11/2017 _Nuevos campos MIFID

				if (!GenericUtils.isNullOrBlank(resposta.getOutputData()
						.getMf7232Output().getTexasesora())) {

					if ("S".equalsIgnoreCase(resposta.getOutputData()
							.getMf7232Output().getTexasesora())) {
						autorizaOperacion.setIndAsesoramiento(true);
					} else {
						autorizaOperacion.setIndAsesoramiento(false);
					}

				}

				if (!GenericUtils.isNullOrBlank(resposta.getOutputData()
						.getMf7232Output().getTexmanuscr())) {

					if ("S".equalsIgnoreCase(resposta.getOutputData()
							.getMf7232Output().getTexmanuscr())) {
						autorizaOperacion.setIndManuscrito(true);
					} else {
						autorizaOperacion.setIndManuscrito(false);
					}

				}

				// SMM 03/07/2017 No se actualiza INDITIPO llegará por
				// integración.
				// DescripcionAutorizaInditipo indiTipo;
				// if
				// (!GenericUtils.isNullOrBlank(resposta.getOutputData().getMf7232Output().getTipcob())){
				// indiTipo =
				// boletasBo.getDescripcionAutorizaInditipo(resposta.getOutputData().getMf7232Output().getTipcob());
				//						
				// if (!GenericUtils.isNullOrBlank(indiTipo)){
				// autorizaOperacion.setInditipo(indiTipo);
				// }else{
				// indiTipo = boletasBo.getDescripcionAutorizaInditipo("CO");
				// autorizaOperacion.setInditipo(indiTipo);
				// }
				//						
				// }else{
				// indiTipo = boletasBo.getDescripcionAutorizaInditipo("CO");
				// autorizaOperacion.setInditipo(indiTipo);
				// }

				// SMM 01/04/2016
				autorizaOperacion.setIndenvio(true);

				// if
				// (!GenericUtils.isNullOrBlank(resposta.getOutputData().getMf7232Output().getTipcob())){
				//						
				// DescripcionAutorizaIndiserv indiserv;
				// indiserv =
				// boletasBo.getDescripcionAutorizaIndiserv(resposta.getOutputData().getMf7232Output().getTipservicio());
				// autorizaOperacion.set(indiserv);
				//					
				// }

				//					
				// !GenericUtils.isNullOrBlank(autorizaOperacion.getTipoclie())
				// &&
				// !GenericUtils.isNullOrBlank(autorizaOperacion.getInditipo())
				//					
				//					
				// resposta.getOutputData().getMf7232Output().getTipcob()
				//					
				// resposta.getOutputData().getMf7232Output().get

				// if (!GenericUtils.isNullOrBlank(resposta.getOutputData())){
				// return false;
				// }
				//					

			} else {
				autorizaOperacion.setIndenvio(false);
				boletasBo.saveResultadoToLog(
						ConstantesFD.LOG_COD_ERROR_SIN_ACCESO_WS,
						ConstantesFD.VALIDACION_FIRMANTES_VACIA + globalId,
						historicoOperacion, ConstantesFD.MIFIDWS,
						ConstantesFD.VALIDACION_FIRMANTES_KO, llamadaStr);
				return false;
			}

		} catch (com.bancsabadell.xmlns.proteo.SharedResources.ErrorSchemav2.FaultInfo fie) {

			// if (!GenericUtils.isNullOrBlank(fie.getFaultCode()) &&
			// !GenericUtils.isNullOrBlank(fie.getFaultCode().getLocalPart()) )
			// System.out.println("faultcode="+fie.getFaultCode().getLocalPart());
			// if (!GenericUtils.isNullOrBlank(fie.getMessage()))
			// System.out.println("Message="+fie.getMessage());
			// if (!GenericUtils.isNullOrBlank(fie.getFaultString()))
			// System.out.println("FaultString="+fie.getFaultString());
			// if (!GenericUtils.isNullOrBlank(fie.getFaultCode()))
			// System.out.println("faultcode=-"+fie.getFaultCode());

			String error = "";
			if (!GenericUtils.isNullOrBlank(fie.getNativeFault())
					&& !GenericUtils.isNullOrBlank(fie.getNativeFault()
							.getFaultCode())
					&& !GenericUtils.isNullOrBlank(fie.getNativeFault()
							.getFaultMessage())) {
				error = fie.getNativeFault().getFaultCode()
						+ fie.getNativeFault().getFaultMessage();
			} else {
				error = fie.getMessage();
			}

			// if (!GenericUtils.isNullOrBlank(fie.getFaultDetails())){
			// System.out.println("FaultDetails=-"+fie.getFaultDetails()[0]);
			// System.out.println("FaultDetails COSAS=-"+fie.getFaultDetails()[1].getElementsByTagName("NativeFault").item(0));
			// System.out.println("FaultDetails COSAS2=-"+fie.getFaultDetails()[0].getElementsByTagName("NativeFault").item(1));
			// }
			//			
			// String faultCode = "";
			// if(fie.getFaultCode()!=null &&
			// fie.getFaultCode().getLocalPart()!=null)
			// faultCode=fie.getFaultCode().getLocalPart();
			// String mensaje = fie.getMessage();
			//					
			autorizaOperacion.setIndenvio(false);
			boletasBo.saveResultadoToLog(
					ConstantesFD.LOG_COD_ERROR_SIN_ACCESO_WS, error,
					historicoOperacion, ConstantesFD.MIFIDWS,
					ConstantesFD.VALIDACION_FIRMANTES_KO, llamadaStr);
			System.out.println("MIFIDWS KO=-" + error + "-");
			// fie.printStackTrace();
			return false;
		} catch (Exception e) {
			autorizaOperacion.setIndenvio(false);
			boletasBo.saveResultadoToLog(
					ConstantesFD.LOG_COD_ERROR_SIN_ACCESO_WS, e.getMessage(),
					historicoOperacion, ConstantesFD.MIFIDWS,
					ConstantesFD.VALIDACION_FIRMANTES_KO, llamadaStr);
			System.out.println("MIFIDWS=-" + e.getMessage() + "-");
			e.printStackTrace();
			return false;
		}

		boletasBo.saveResultadoToLog(ConstantesFD.VALIDACION_FIRMANTES_CODOK,
				ConstantesFD.MIFIDWS_GLOBALID_OK + globalId,
				historicoOperacion, ConstantesFD.MIFIDWS,
				ConstantesFD.VALIDACION_FIRMANTES_OK, llamadaStr);
		return true;

	}

	/*
	 * private String obtenerSesionMIFID(){
	 * 
	 * try { // com.bs.proteo.soa.service.mainframe.UserLogin.domain.InputData
	 * inputData = new
	 * com.bs.proteo.soa.service.mainframe.UserLogin.domain.InputData();
	 * //setusername y password //
	 * firmaDigital.setUsername(Identity.instance().getCredentials
	 * ().getUsername()); String proxyGrantingTicket = getTicket(); String
	 * passTicket = firmaDigital.getPassTicket(proxyGrantingTicket);
	 * System.out.println("passTicket=-"+passTicket+"-"); // String
	 * grantServiceTicket = firmaDigital.getServiceTicket(proxyGrantingTicket);
	 * // System.out.println("grantServiceTicket=-"+grantServiceTicket+"-");
	 * 
	 * String sessionValida =
	 * mifidWS.login(Identity.instance().getCredentials().
	 * getUsername(),passTicket,sessionId);
	 * 
	 * if(sessionValida.equals("-1")|| sessionValida.equals("-2")){
	 * System.out.println("validacionFD KO SESION NO"); return null; }else{
	 * System.out.println("validacionFD sesion2 =-"+sessionValida+"-"); return
	 * sessionValida; } } catch (Exception e) {
	 * System.out.println("validacionFD KO SESION NO:"+e.getLocalizedMessage());
	 * e.printStackTrace(); return null;
	 * 
	 * }
	 * 
	 * 
	 * 
	 * }
	 */

	private String obtenerSesionValidacion() {

		try {
			// com.bs.proteo.soa.service.mainframe.UserLogin.domain.InputData
			// inputData = new
			// com.bs.proteo.soa.service.mainframe.UserLogin.domain.InputData();
			// setusername y password
			// firmaDigital.setUsername(Identity.instance().getCredentials().getUsername());
			String proxyGrantingTicket = getTicket();
			String passTicket = firmaDigital.getPassTicket(proxyGrantingTicket);
			System.out.println("passTicket=-" + passTicket + "-");
			// String grantServiceTicket =
			// firmaDigital.getServiceTicket(proxyGrantingTicket);
			// System.out.println("grantServiceTicket=-"+grantServiceTicket+"-");

			String sessionValida = validacionFD.userLogin(Identity.instance()
					.getCredentials().getUsername(), passTicket, sessionId);

			if (sessionValida.equals("-1") || sessionValida.equals("-2")) {
				System.out.println("validacionFD KO SESION NO");
				return null;
			} else {
				System.out.println("validacionFD sesion2 =-" + sessionValida
						+ "-");
				return sessionValida;
			}
		} catch (Exception e) {
			System.out.println("validacionFD KO SESION NO:"
					+ e.getLocalizedMessage());
			e.printStackTrace();
			return null;

		}

	}

	private String obtenerSesionValidacionTesoreria() {

		try {
			String proxyGrantingTicket = getTicket();
			String passTicket = firmaDigital.getPassTicket(proxyGrantingTicket);
			System.out.println("passTicket=-" + passTicket + "-");

			String sessionValida = validacionFD.userLoginTesoreria(Identity
					.instance().getCredentials().getUsername(), passTicket,
					sessionId);

			if (sessionValida.equals("-1") || sessionValida.equals("-2")) {
				boletasBo.saveResultadoToLog(
						ConstantesFD.LOG_COD_ERROR_SIN_SESION,
						ConstantesFD.LOG_DESC_ERROR_SIN_SESION,
						historicoOperacion, ConstantesFD.MIFIDWS,
						ConstantesFD.VALIDACION_FIRMANTES_KO);
				System.out.println("userLoginTeso KO SESION NO");
				addWarning("boletas.Mifid.errorSesion");
				return null;
			} else {
				System.out.println("userLoginTeso sesion2 =-" + sessionValida
						+ "-");
				return sessionValida;
			}
		} catch (Exception e) {
			boletasBo.saveResultadoToLog(ConstantesFD.LOG_COD_ERROR_SIN_SESION,
					ConstantesFD.LOG_DESC_ERROR_SIN_SESION, historicoOperacion,
					ConstantesFD.MIFIDWS, ConstantesFD.VALIDACION_FIRMANTES_KO);

			System.out.println("userLoginTeso KO SESION NO:"
					+ e.getLocalizedMessage());
			addWarning("boletas.Mifid.errorSesion");
			e.printStackTrace();
			return null;

		}

	}

	private Boolean esCanalUrgente() {
		// Contratación
		// Modificación
		// Cancelación
		// Cancelación Parcial

		if ("UR".equalsIgnoreCase(confirmacion
				.getCanelEmisionConfirmacionAlta())
				|| "UR".equalsIgnoreCase(confirmacion
						.getCanelEmisionConfirmacionModificacion())
				|| "UR".equalsIgnoreCase(confirmacion
						.getCanelEmisionConfirmacionCancelacion())
				|| "UR".equalsIgnoreCase(confirmacion
						.getCanelEmisionConfirmacionCancelacionParcial())) {
			return true;
		}

		return false;
	}

	private void validarConfirmaciones() {
		try {
			if ("A".equalsIgnoreCase(historicoOperacion.getUltimaAccion()
					.getCodigo())
					&& "IN".equals(historicoOperacion.getEstado().getCodigo())
					&& esContrapaCliente() && !esCanalUrgente()) {

				Boolean activarFirmaDigital = boletasBo.activarFirmaDigital();

				if (!activarFirmaDigital) {
					return;
				}

				Boolean validarFirmantes = contraFirmaDigital(historicoOperacion
						.getContrapartida());

				if (GenericUtils.isNullOrBlank(validarFirmantes))
					return;

				if (validarFirmantes) {
					// Informar contrapa a S
					boletasBo.actualizarContrapaFD(historicoOperacion
							.getContrapartida().getId(),
							ConstantesFD.VALIDACION_FIRMANTES_CONTRAPAFD);
				} else {
					// Informar contrapa a N
					boletasBo.actualizarContrapaFD(historicoOperacion
							.getContrapartida().getId(),
							ConstantesFD.VALIDACION_FIRMANTES_CONTRAPANOFD);
				}

			}
		} catch (Exception e) {
			boletasBo.saveResultadoToLog(
					ConstantesFD.LOG_COD_ERROR_SIN_ACCESO_WS, e
							.getLocalizedMessage(), historicoOperacion,
					ConstantesFD.VALIDACION_FIRMANTES_BOL,
					ConstantesFD.VALIDACION_FIRMANTES_KO);
			e.printStackTrace();
		}

	}

	private Boolean contraFirmaDigital(AbstractContrapartida contrapartida) {

		//SMM 18/10/2018
		if (GenericUtils.isNullOrBlank(sessionId)){
		
		
			sessionId = obtenerSesionValidacion();
		if (GenericUtils.isNullOrBlank(sessionId)) {
			boletasBo.saveResultadoToLog(ConstantesFD.LOG_COD_ERROR_SIN_SESION,
					ConstantesFD.LOG_DESC_ERROR_SIN_SESION, historicoOperacion,
					ConstantesFD.VALIDACION_FIRMANTES_BOL,
					ConstantesFD.VALIDACION_FIRMANTES_KO);
			return null;
		}
		
		}
		
		// Llamada WS
		return validacionFirmaDigital(sessionId, contrapartida);

	}

	private void validarDatosIndFloor() {
		// Si se modifica el indFlooreado aviso a los usuarios
		if (boletaState != BoletasStates.CONSULTA_BOLETA) {

			if (indFlooracionInicial != historicoOperacion.getIndFlooreado()) {
				// tiene una liquidación en estado “validada”
				if (mantOperBo
						.validateCampanasAndLiquidaciones(historicoOperacion)) {
					addWarning("boletas.indFlooreado.liquidaciones.validadas");
				} else {
					addWarning("boletas.indFlooreado.liquidaciones.no.validadas");
				}
			}

			// Si está activado (INDFLOOR = S) y la contrapartida no es de tipo
			// CLIENTES
			if (historicoOperacion.getIndFlooreado() && !esContrapaCliente()) {
				addWarning("boletas.indFlooreado.contrapartida.no.cliente");
			}
		}
		// HistoricoOperacion old = entityManager

	}

	private void validaDatosEmir() {
		if ((historicoOperacion.getGrupoContable() == null || !"XX"
				.equals(historicoOperacion.getGrupoContable().getId()
						.getGrupoContable()))
				&& !EsTipoCoberturaIn()) {
			// OPERACION NO INTERNA

			// TODO Validacions actives per FECHAOPE >? 16/08/2012
			// TODO UTI si informado no es pot buidar
			// TODO PREUTI no es pot modificar si UTI esta blanc

			// if
			// (historicoOperacion.getId().getFechaContratacion().compareTo(fechaCorteEmir)<=0){
			// return;
			// }

			// Si PRODUCAT NO ESTA EN EMIRPROD NO VALIDAMOS DATOS
			if (historicoOperacion.getProductoCatalogo() != null
					&& !boletasBo.compruebaProductoEmir(historicoOperacion
							.getProductoCatalogo().getProducat())) {
				return;
			}

			// if
			// (GenericUtils.isNullOrBlank(historicoOperacion.getFechaCierreMicro())){
			// addMessage("boletas.validaDatosEmir.fcierre");
			// }

			if (esContrapaCliente()) {
				if (historicoOperacion.getUltimaAccion() != null
						&& "A".equalsIgnoreCase(historicoOperacion
								.getUltimaAccion().getCodigo())
						&& historicoOperacion.getEstado() != null
						&& "IN".equalsIgnoreCase(historicoOperacion.getEstado()
								.getCodigo())
						&& GenericUtils.isNullOrBlank(historicoOperacion
								.getTradeId())) {

					String codigoLeiBSAB = boletasBo
							.obtenerCodigoLeiBancSabadell();
					String tradeId;
					if (!GenericUtils.isNullOrBlank(codigoLeiBSAB)
							&& codigoLeiBSAB.length() >= 16) {
						// 7 al 16 + 14 0s
						codigoLeiBSAB = codigoLeiBSAB.substring(6, 16).concat(
								"00000000000000");

						tradeId = codigoLeiBSAB.concat(historicoOperacion
								.getClaveExternaBDU());

					} else {

						tradeId = historicoOperacion.getClaveExternaBDU();

					}

					historicoOperacion.setTradeId(tradeId);
				}

			} else {

				if (historicoOperacion.getUltimaAccion() != null
						&& "A".equalsIgnoreCase(historicoOperacion
								.getUltimaAccion().getCodigo())
						&& historicoOperacion.getEstado() != null
						&& "IN".equalsIgnoreCase(historicoOperacion.getEstado()
								.getCodigo())
						&& "A"
								.equalsIgnoreCase(historicoOperacion
										.getTradeId())) {

					String codigoLeiBSAB = boletasBo
							.obtenerCodigoLeiBancSabadell();
					String tradeId;
					if (!GenericUtils.isNullOrBlank(codigoLeiBSAB)
							&& codigoLeiBSAB.length() >= 16) {
						// 7 al 16 + 14 0s
						codigoLeiBSAB = codigoLeiBSAB.substring(6, 16).concat(
								"00000000000000");

						tradeId = codigoLeiBSAB.concat(historicoOperacion
								.getClaveExternaBDU());

					} else {

						tradeId = historicoOperacion.getClaveExternaBDU();

					}

					historicoOperacion.setTradeId(null);
					historicoOperacion.setInternalTradeId(tradeId);

				}

			}

			if (GenericUtils.isNullOrBlank(historicoOperacion.getTradeId())
					&& GenericUtils.isNullOrBlank(historicoOperacion
							.getInternalTradeId())) {
				addMessage("boletas.validaDatosEmir.utiOpreuti");
			}

			if (GenericUtils.isNullOrBlank(historicoOperacion.getTradeId())) {

				if ((historicoOperacion.getUltimaAccion() != null && !"A"
						.equalsIgnoreCase(historicoOperacion.getUltimaAccion()
								.getCodigo()))
						|| (historicoOperacion.getEstado() != null && !"IN"
								.equalsIgnoreCase(historicoOperacion
										.getEstado().getCodigo()))) {

					if (tradeInformado) {
						addMessage("boletas.validaDatosEmir.borrarUti");
					}

					if ((GenericUtils.isNullOrBlank(preutiOld) && !GenericUtils
							.isNullOrBlank(historicoOperacion
									.getInternalTradeId()))
							|| (!GenericUtils.isNullOrBlank(preutiOld) && !preutiOld
									.equals(historicoOperacion
											.getInternalTradeId()))) {
						addMessage("boletas.validaDatosEmir.modificarPreUti");
					}

				}

			} else {
				// comprobar no existe repetido
				if (!boletasBo.validaTradeId(historicoOperacion, "uti")) {
					addMessage("boletas.validaDatosEmir.utiRepetido");
				}
				if (historicoOperacion.getTradeId().length() < 10) {
					addWarning("boletas.validaDatosEmir.utimenor");
				}
			}

			if (!GenericUtils.isNullOrBlank(historicoOperacion
					.getInternalTradeId())) {
				// comprobar no existe repetido
				if (!boletasBo.validaTradeId(historicoOperacion, "preuti")) {
					addMessage("boletas.validaDatosEmir.preutiRepetido");
				}
				if (historicoOperacion.getInternalTradeId().length() < 10) {
					addWarning("boletas.validaDatosEmir.preutimenor");
				}
			}

			// Comprobar caracteres
			// Solo se permitirán los caracteres: ":", "-","_","." No podrán
			// estar ni a principio ni al final.
			// No se permitirán blancos en el campo.
			// Letras sin acentos ,numeros y esos.

			if (!GenericUtils.isNullOrBlank(historicoOperacion
					.getInternalTradeId())) {
				// 18 enters, 2 decimals amb signe +/-18n.2n
				// !Pattern.matches("[-+]?[0-9]{1,18}(\\.[0-9]{1,2})+",campo.getContenidoCampo())
				// \w A word character: [a-zA-Z_0-9]
				// if
				// (!Pattern.matches("[a-zA-Z0-9]+[a-zA-Z:-_.0-9]*[a-zA-Z0-9]+ | [a-zA-Z0-9]+ ",historicoOperacion.getInternalTradeId())
				if (!Pattern.matches(
						"[a-zA-Z0-9]+[a-zA-Z:\\-_\\.0-9]*[a-zA-Z0-9]+",
						historicoOperacion.getInternalTradeId())
						&& !Pattern.matches("[a-zA-Z0-9]+", historicoOperacion
								.getInternalTradeId())) {

					addMessage("boletas.validaDatosEmir.PreUtiCaracteres");
				}
			}

			if (!GenericUtils.isNullOrBlank(historicoOperacion.getTradeId())) {
				if (!Pattern.matches(
						"[a-zA-Z0-9]+[a-zA-Z:\\-_\\.0-9]*[a-zA-Z0-9]+",
						historicoOperacion.getTradeId())
						&& !Pattern.matches("[a-zA-Z0-9]+", historicoOperacion
								.getTradeId())) {

					addMessage("boletas.validaDatosEmir.UtiCaracteres");
				}

			}

		} else {
			// INTERNA
			return;
		}

	}

	private void validaCAM() {
		if (historicoOperacion.getFolderEstrategia() != null
				&& "TMPL".equalsIgnoreCase(historicoOperacion
						.getFolderEstrategia())) {
			addWarning("boletas.avis.camrad");
			return;
		}

		// if (historicoOperacion.getProductoTgr()!=null &&
		// historicoOperacion.getProductoTgr()==107){
		// addWarning("boletas.avis.camrad");
		// }

		if (historicoOperacion.getContrapartida() != null
				&& "CAAMES2AXXX".equals(historicoOperacion.getContrapartida()
						.getId())) {
			addWarning("boletas.avis.camrad");
		}

	}

	/**
	 * Si Grupo Cont <> â€˜XXâ€™, si F. Valor < (sysdate) y F_ES_DE_COBERTURA,
	 * mostrar aviso â€˜AVISO: Swap de Cobertura con F. Valor inferior a hoyâ€™
	 */
	private void validaGrupoContable() {
		if (historicoOperacion.getProductoCatalogo() == null
				|| historicoOperacion.getGrupoContable() == null)
			return;

		boolean esDeCobertura = true;
		Integer numeroGrupoContable = null;
		codigoValidacionEsquemaErroneo = historicoOperacion.getGrupoContable()
				.getId().getGrupoContable();
		try {
			numeroGrupoContable = new Integer(codigoValidacionEsquemaErroneo
					.substring(0, 1));
		} catch (NumberFormatException e) {
			esDeCobertura = false;
		}
		if (!"XX".equalsIgnoreCase(codigoValidacionEsquemaErroneo)
				&& historicoOperacion.getFechaValor().before(fechaSistema)
				&& esDeCobertura) {
			statusMessages.addToControl("grupoCont4003", Severity.WARN,
					"#{messages['boletas.edicion.swapCobertura.invalido']");
			addWarning("boletas.edicion.swapCobertura.invalido");
		}

		// validamos esquema contable SOLO SI:
		// GRUP_CONTABLE <>XX
		// Producte de Pasarela
		if (!"XX".equalsIgnoreCase(codigoValidacionEsquemaErroneo)
				&& "P".equals(historicoOperacion.getProducto()
						.getIndPasarelaRad())) {

			if (!boletasBo.esEsquemaContableValido(historicoOperacion)) {
				// SMM 27/03/2017 ERROR NO WARNING
				// addWarning("boletas.edicion.grupocontable.invalido");
				addMessage("boletas.edicion.grupocontable.invalido");
			}

		}

		// Si es Producto RAD y cobertura
		// Grup Cont. 1, 3, 6 y 7 Cob A/P: ACTIVO
		// Grup Cont. 2, 4, 5 ,8 Cob A/P: PASIVO
		// boletas.edicion.grupocontablerad.invalido
		// boletas.edicion.cobap.invalido

		if (historicoOperacion.getProducto() != null
				&& entityUtil.checkEntityExists(historicoOperacion
						.getCodigoCobertura())
				&& "CO".equals(historicoOperacion.getCodigoCobertura()
						.getCodigo())
				&& ("R".equals(historicoOperacion.getProducto()
						.getIndPasarelaRad()) || "M".equals(historicoOperacion
						.getProducto().getIndPasarelaRad()))) {

			if (numeroGrupoContable == null) {
				addMessage("boletas.edicion.grupocontablerad.invalido");
				return;
			}

			switch (numeroGrupoContable) {
			case 1:
			case 3:
			case 6:
			case 7:
				if (historicoOperacion.getIndActivoPasivo() != null
						&& "P".equals(historicoOperacion.getIndActivoPasivo()
								.getCodigo())) {
					addMessage("boletas.edicion.cobap.invalido");
				}
				break;
			case 2:
			case 4:
			case 5:
			case 8:
				if (historicoOperacion.getIndActivoPasivo() != null
						&& "A".equals(historicoOperacion.getIndActivoPasivo()
								.getCodigo())) {
					addMessage("boletas.edicion.cobap.invalido");
				}
				break;
			default:
				addMessage("boletas.edicion.grupocontablerad.invalido");
				break;
			}
		}

	}

	private void validaClaveExternaBDU() {
		// Eliminamos esta validación: ya se valida en dadesValidesFase3
		// if
		// (!GenericUtils.isNullOrBlank(historicoOperacion.getClaveExternaBDU())
		// && historicoOperacion.getClaveExternaBDU().length() != 18 ){
		// addMessage("boletas.edicion.error.claveBDU.tamano");
		// return;
		// }
		if (!"CPD".equalsIgnoreCase(historicoOperacion.getDealType())
				&& !boletasBo.validaClaveBDU(historicoOperacion)) {
			codigoValidacionErroneo = historicoOperacion.getClaveExternaBDU();
			historicoOperacion.setClaveExternaBDU(null);
			addMessage("boletas.edicion.error.claveBDU");
			return;
		}
	}

	private Integer dadesValidesCalendari(boolean regeneracionAutomatica) {

		// regeneracionAutomatica Nos indicara si se llama esta funcion desde
		// la validacion del alta o tras regenerar el calendario automaticamente
		// Ademas devuelve 5 y 6 como codigos de error
		// Devuelve 3 si todo va bien (aprovechando el codigo que ya se usaba)
		// Devuelve 999 sino va a la regeneracion automatica y que entonces no
		// se necesita valor de retorno.

		// EXemple
		//
		// //F. Fij. Strike Obligatorio si Strike Promedio marcado
		// if (hasDatosOpcionTab() && ho.getHistoricoOpcion()!=null &&
		// ho.getHistoricoOpcion().getIndstrpr() && !hayFechasTipo("FS")){
		//				
		// }
		List<Long> codigoIndiceList;
		List<Date> fechaFinList;

		for (HistoricoTramos tramo : historicoOperacion.getHistoricoTramoses()) {
			if (tramo.getIndicadorTipindiv() != null
					&& "V".equals(tramo.getIndicadorTipindiv().getCodigo())) {
				if (tramo.getHistoricoIndices() == null
						|| tramo.getHistoricoIndices().isEmpty()) {
					if (regeneracionAutomatica) {
						return 5;
					} else {
						addMessage("boletas.dadesValidades.IndicesCalendario");
						return 999;
					}

				}
				codigoIndiceList = new ArrayList<Long>();
				fechaFinList = new ArrayList<Date>();

				for (HistoricoIndice indice : tramo.getHistoricoIndices()) {

					try {
						if (indice.getCodigoIndice() == null
								|| indice.getCodigoIndice().getCodigo() == null
								|| indice.getCodigoIndice()
										.getDescripcionCorta() == null) {
							if (regeneracionAutomatica) {
								return 5;
							} else {
								addMessage("boletas.dadesValidades.IndicesCalendario");
								return 999;
							}

						}
					} catch (Exception e) {
						if (regeneracionAutomatica) {
							return 5;
						} else {
							addMessage("boletas.dadesValidades.IndicesCalendario");
							return 999;
						}
					}

					/**
					 * 1025 Interpolada codindic diferent
					 */

					// Los tramos interpolados no pueden tener el mismo indice.
					if (1025 == tramo.getCodigoFormula().getCodigoFormula()) {

						if (GenericUtils.isNullOrBlank(indice.getFechaInicio())
								|| GenericUtils.isNullOrBlank(indice
										.getFechaFin())) {

							// El codigo Indice ja s'ha comprovat abans.
							if (regeneracionAutomatica) {
								return 5;
							} else {
								addMessage("boletas.dadesValidades.IndicesCalendario");
								return 999;
							}

						}

						if (codigoIndiceList.contains(indice.getCodigoIndice()
								.getCodigo())
								|| fechaFinList.contains(indice.getFechaFin())) {
							if (regeneracionAutomatica) {
								return 6;
							} else {
								addMessage("boletas.dadesValidades.IndicesInterpolado");
								return 999;
							}

						}

						codigoIndiceList.add(indice.getCodigoIndice()
								.getCodigo());
						fechaFinList.add(indice.getFechaFin());
					}

				}

			}
		}

		return 3;
	}

	public void onMessageBoxKoNoHacerNada() {

	}

	public String altaCompletaDoYSalir() {
		return altaCompletaDo();
	}

	/*
	 * Si existen warnings y sólo warnings mostramos un msgbox pididendo
	 * confirmación prévia
	 */
	public String altaCompletaDo() {
		if (!existeCalendario()) {
			messageBoxAction.init("boletas.messageBox.crear.calendario",
					"boletasAction.onMessageBoxCrearCalendarioOk()",
					"boletasAction.onMessageBoxCrearCalendarioKo()");
			return Constantes.FAIL;
		} else {
			Integer opcionRet = calendarioOpcionValido();
			if (2 == opcionRet) {

				// No se puede rehacer el calendario

				addMessage("boletas.rehacer.calendario");
				return Constantes.FAIL;

			} else if (4 == opcionRet) {

				// La función de rehacer el calendario da error
				// Devolvemos código  4 y el error que devuelva la rutina

				addMessage("boletas.rehacerError.calendario");
				return Constantes.FAIL;
			} else if (5 == opcionRet) {
				addMessage("boletas.dadesValidades.IndicesCalendario");
				return Constantes.FAIL;
			} else if (6 == opcionRet) {
				addMessage("boletas.dadesValidades.IndicesInterpolado");
				return Constantes.FAIL;
			} else if (3 == opcionRet) {

				// return "TO_MANTRAM";
			} else if (1 == opcionRet) {

				if (!calendarioValido()) {
					messageBoxAction
							.init(
									"boletas.alta.completa.messageBox.calendario.modificado",
									"boletasAction.onMessageBoxCalendarioModificadoOk()",
									"boletasAction.onMessageBoxCalendarioModificadoKo()");
					return Constantes.FAIL;
				}

			}
		}
		return continuarAltaCompleta();
	}

	public String continuarAltaCompleta() {
		// hay calendario y es valido, pasamos a V_GRABAR
		DescripcionEstadoOperacion estado = entityManager.find(
				DescripcionEstadoOperacion.class, "PV");
		historicoOperacion.setEstado(estado);
		// Se cambia el estado de las barreras para los acumuladores
		barreraAcum();
		// Migraciones CAM y BMN
		validarOperacionCAM(historicoOperacion);
		doControlAutoriza();
		if (boletaState == BoletasStates.ALTA_BOLETA)
			ModoActuacion = "A";
		else
			ModoActuacion = "M";
		if (altaComun()) {
			checkSncorrela();
			// FLM: 1273, añadir el n correla
			if ("M".equalsIgnoreCase(ModoActuacion))
				statusMessages.add(Severity.INFO,
						"#{messages['boletas.edicion.modificacion.completa.correcta']} "
								+ historicoOperacion.getId()
										.getNumeroOperacion().toString());
			else
				statusMessages.add(Severity.INFO,
						"#{messages['boletas.edicion.alta.completa.correcta']} "
								+ historicoOperacion.getId()
										.getNumeroOperacion().toString());
			varModif = Constantes.CONSTANTE_SI;
		} else {
			// Quizas faltaria mostrar el error "raro" que pueda salir
			doCommonRedirect();
			return Constantes.FAIL;
		}
		return doCommonRedirect();

	}

	private void validarOperacionCAM(HistoricoOperacion ho) {
		if (ho.getContrapartida2() != null
				&& "CAM-IN".equals(ho.getContrapartida2().getId())) {
			AbstractContrapartida camContrapa = entityManager.find(
					AbstractContrapartida.class, "CAM-PV");
			ho.setContrapartida2(camContrapa);
		}
		if (ho.getContrapartida2() != null
				&& "BMN-IN".equals(ho.getContrapartida2().getId())) {
			AbstractContrapartida camContrapa = entityManager.find(
					AbstractContrapartida.class, "BMN-PV");
			ho.setContrapartida2(camContrapa);
		}

		if (ho.getContrapartida2() != null
				&& "LBI-IN".equals(ho.getContrapartida2().getId())) {
			AbstractContrapartida camContrapa = entityManager.find(
					AbstractContrapartida.class, "LBI-PV");
			ho.setContrapartida2(camContrapa);
		}

		if (ho.getContrapartida2() != null
				&& "BCG-IN".equals(ho.getContrapartida2().getId())) {
			AbstractContrapartida camContrapa = entityManager.find(
					AbstractContrapartida.class, "BCG-PV");
			ho.setContrapartida2(camContrapa);
		}

	}

	private void barreraAcum() {
		String estadoBarrera;
		if (historicoOperacion.getHistoricoBarreras() != null
				&& historicoOperacion.getHistoricoBarreras().size() > 0) {

			if ((historicoOperacion.getFormulaPago() != null && GenericUtils
					.in(historicoOperacion.getFormulaPago().getCodigoFormula(),
							1029, 1030))
					|| (historicoOperacion.getFormulaRecibo() != null && GenericUtils
							.in(historicoOperacion.getFormulaRecibo()
									.getCodigoFormula(), 1029, 1030))) {
				for (HistoricoBarrera historicoBarrera : historicoOperacion
						.getHistoricoBarreras()) {
					historicoBarrera.setIndsitua("I");
					;
				}
			}
		}

	}

	private String doCommonRedirect() {
		preparaSignoSpread();

		if (forcedReturnView != null) {
			return doSalirRedirect();
		}
		if (boletaState == BoletasStates.ALTA_BOLETA) {
			return "salir";
		}
		Conversation conversacion = Conversation.instance();
		// Volvemos al anterior
		conversacion.redirectToParent();
		return "";
	}

	/*
	 * Comprueba si la contrapartida especificada tiene el CMOF firmado, solo
	 * para tipos de Contrapartida Cliente. Devuelve True o False.
	 * 
	 * FUNCTION F_CMOF_NO_FIRMADO RETURN BOOLEAN IS v_cont number; v_return
	 * boolean := false; BEGIN if Contrapartida is not null AND Contrapartida <>
	 * 'FDI' THEN
	 * 
	 * select count(1) into v_cont from gestio_tressoreria.contrapa where
	 * contrapa = Contrapartida and tipocont = 'C';
	 * 
	 * if v_cont > 0 then select count(1) into v_cont from
	 * gestio_tressoreria.docucont where contrapa = Contrapartida and codidocu =
	 * 'CMOF' and estadoco = 'F';
	 * 
	 * if v_cont=0 then v_return := true; else v_return := false; end if; end
	 * if; end if; return v_return;
	 * 
	 * EXCEPTION WHEN OTHERS THEN mostrar_mensaje('Error al comprobar si la
	 * contrapartida tiene el CMOF firmado: ' || sqlerrm); return (FALSE); END;
	 */
	// FLM
	private Integer CMOFNoFirmado() {
		// 0 - Sin errores
		// 1 - CMOF no firmado
		// 2 - Anexo no firmado

		try {
			HistoricoOperacion ho = historicoOperacion;
			if (!contrapartidaUtil.isInstanceOfContrapartida(ho
					.getContrapartida())) {
				return 0;
			}

			if (ho.getProductoCatalogo() != null
					&& ho.getProductoCatalogo().getModelpro() != null
					&& "DED".equalsIgnoreCase(ho.getProductoCatalogo()
							.getModelpro().getModelpro())) {
				return 0;
			}

			if ((ho.getContrapartida2() != null && ("CAM-MIG".equals(ho
					.getContrapartida2().getId())
					|| "BMN-MIG".equals(ho.getContrapartida2().getId())
					|| "LBI-MIG".equals(ho.getContrapartida2().getId()) || "BCG-MIG"
					.equals(ho.getContrapartida2().getId())))
					|| (ho.getContrapartida() != null && "CAAMES2AXXX"
							.equals(ho.getContrapartida().getId()))) {
				return 0;
			}

			Contrapartida contrapartida = contrapartidaUtil
					.castAsContrapartida(ho.getContrapartida());
			if (contrapartida != null
					&& !"FDI".equalsIgnoreCase(contrapartida.getId())) {
				if (contrapartida.getTipoContrapartida() != null
						&& "C".equalsIgnoreCase(contrapartida
								.getTipoContrapartida().getId())) {
					Integer error = this.boletasBo.CMOFNoFirmadoAnexo(
							contrapartida, ho.getEntidad());
					if (error == 2
							&& !"E".equalsIgnoreCase(contrapartida
									.getTipoPersona())) {
						return 0;
					}
					return error;
				}

			}
		} catch (Exception e) {
			addMessage("Error al comprobar si la contrapartida tiene el CMOF firmado");
			return 0;
		}
		return 0;
	}

	/**
	 * 
	 FUNCTION F_CONTRAPARTIDA_COMPLETA RETURN boolean IS v_cont number;
	 * v_return boolean := true; BEGIN if Contrapartida is not null then select
	 * count(1) into v_cont from gestio_tressoreria.contrapa where contrapa =
	 * Contrapartida and (indresid is null or codipais is null); if v_cont>0
	 * then v_return := false; end if; end if; return v_return; END;
	 */
	// FLM Función de validación de contrapartidas
	private boolean contrapartidaCompleta() {
		HistoricoOperacion ho = historicoOperacion;
		if (ho.getContrapartida() == null)
			return false;
		AbstractContrapartida abstractContrapartida = entityUtil.unwrapProxy(ho
				.getContrapartida(), AbstractContrapartida.class);
		if (abstractContrapartida instanceof Contrapartida) {
			Contrapartida contrapa = (Contrapartida) abstractContrapartida;
			if (contrapa.getIndicadorResidencia() == null
					|| contrapa.getCodigoPais() == null)
				return false;
			else
				return true;
		}
		return true;
	}

	public String onMessageBoxCrearCalendarioOk() {
		return generar(false);
	}

	public void onMessageBoxCrearCalendarioKo() {
		statusMessages.add(Severity.ERROR,
				"#{messages['boletas.alta.completa.error.sin.calendario']}");
	}

	public String onMessageBoxCalendarioModificadoOk() {
		return generar(true);
	}

	private boolean fechaVencimientoFestivo() {
		return boletasBo.validateFestivo(historicoOperacion
				.getFechaVencimiento(), historicoOperacion.getDivisaPago())
				|| boletasBo.validateFestivo(historicoOperacion
						.getFechaVencimiento(), historicoOperacion
						.getDivisaRecibo());

		/*
		 * FUNCTION F_FECHAVEN_FESTIVO RETURN BOOLEAN IS V_RETURN BOOLEAN :=
		 * FALSE; BEGIN V_RETURN := PKG_BOLETA.P_ES_FESTIVO(F. Vto,NVL(Div Liq.
		 * Pago,'0')) OR PKG_BOLETA.P_ES_FESTIVO (F. Vto,NVL(Div Liq.
		 * Cobro,'0')); RETURN V_RETURN; END;
		 */
		// return false;
	}

	public void onMessageBoxCalendarioModificadoKo() {
		// messageBoxAction.init("boletas.messageBox.cambio.formula",
		// "boletasAction.onMessageBoxOkCobro()",
		// "boletasAction.onMessageBoxKo()");
		// statusMessages.add(Severity.INFO,
		// "#{messages['boletas.alta.completa.error.sin.calendario']}");
		continuarAltaCompleta();
	}

	/**
	 * Datos por defecto para pestaña MIFID. Si Ind. Forzaje = null, poner ‘N’
	 * Si Ind Envío = null, poner ‘N’ Si Tipo Cliente = null, poner lo que
	 * devuelva F_OBTENER_TIPOCLIE
	 */
	private void doControlAutoriza() {

		if (hasMifidTab()) {
			// if (autorizaOperacion.getIndiforza() == null) {
			// DescripcionAutorizaIndiforza indi =
			// (DescripcionAutorizaIndiforza)
			// entityManager.createQuery("from DescripcionAutorizaIndiforza where codigo='N'").getSingleResult();
			// autorizaOperacion.setIndiforza(indi);
			// }
			if (autorizaOperacion.getIndenvio() == null) {
				autorizaOperacion.setIndenvio(false);
			}
			// if (autorizaOperacion.getTipoclie() == null) {
			// autorizaOperacion.setTipoclie(getTipoClienteMifid());
			// }
		}
	}

	private DescripcionAutorizaTipoCliente getTipoClienteMifid() {
		String tipoCliente = null;
		String familia = null;

		if (autorizaOperacion != null
				&& autorizaOperacion.getInditipo() != null
				&& "CO".equals(autorizaOperacion.getInditipo().getCodigo())) {
			familia = "OCC";
		} else {
			familia = "OTC";
		}

		try {

			try {
				tipoCliente = (String) entityManager
						.createNativeQuery(
								"SELECT DECODE(C.COD_SEGUIMIENTO_CLIENTE_MIFID, 'M', 'MN', 'P','PF','CT') "
										+ "FROM DERI.MIFID_CLIENTES_FAMILIA C "
										+ "WHERE C.FAMILIA = :familia AND C.NIF = :contrapartida  ")
						.setParameter("contrapartida",
								historicoOperacion.getContrapartida().getId())
						.setParameter("familia", familia).getSingleResult();
			} catch (Exception excep) {
				// tipoCliente = null;
				tipoCliente = (String) entityManager
						.createNativeQuery(
								"SELECT DECODE(C.CLASIFICACION, 'M', 'MN', 'P','PF','CT') FROM DERI.MIFID_CLIENTES C, GESTIO_TRESSORERIA.DESCCODI  D "
										+ "WHERE C.ENTIDAD=D.CODIGOCA AND D.PROPIETA='DERI' AND D.NOMTABLA='ENTIDERI' AND D.NOMCAMPO='ENTISIBI' AND "
										+ "C.NIF = :contrapartida and TO_NUMBER(D.DESCCODI)=:entidad ")
						.setParameter("contrapartida",
								historicoOperacion.getContrapartida().getId())
						.setParameter("entidad",
								historicoOperacion.getEntidad().getCodigo())
						.getSingleResult();
			}

			// tipoCliente = (String) entityManager.createNativeQuery(
			// "SELECT DECODE(C.CLASIFICACION, 'M', 'MN', 'P','PF','CT') FROM DERI.MIFID_CLIENTES C, GESTIO_TRESSORERIA.DESCCODI  D "+
			// "WHERE C.ENTIDAD=D.CODIGOCA AND D.PROPIETA='DERI' AND D.NOMTABLA='ENTIDERI' AND D.NOMCAMPO='ENTISIBI' AND "+
			// "C.NIF = :contrapartida and TO_NUMBER(D.DESCCODI)=:entidad ")
			// .setParameter("contrapartida",
			// historicoOperacion.getContrapartida().getId())
			// .setParameter("entidad",
			// historicoOperacion.getEntidad().getCodigo()).getSingleResult();

			// SELECT DECODE(C.COD_SEGUIMIENTO_CLIENTE_MIFID, 'M', 'MN',
			// 'P','PF','CT')
			// FROM DERI.MIFID_CLIENTES_FAMILIA C
			// WHERE C.NIF = :contrapartida AND C.FAMILIA ='OTC'

			return (DescripcionAutorizaTipoCliente) entityManager.createQuery(
					"from DescripcionAutorizaTipoCliente where codigo=:codigo")
					.setParameter("codigo", tipoCliente).getSingleResult();
		} catch (EntityNotFoundException e) {
			return null;
		} catch (NoResultException f) {
			return null;
		}

	}

	private String generar(boolean hasCalendario) {
		if (fechaVencimientoFestivo()) {
			messageBoxAction
					.init(
							"boletas.alta.completa.messageBox.calendario.fecha.festiva",
							"boletasAction.onMessageBoxGenerarConFechaOk("
									+ hasCalendario + ")",
							"boletasAction.onMessageBoxGenerarConFechaKo()");
			return null;
		} else {
			tramosTableComponent = new TramosTableComponent();
			return llamarCalendarioCrear(hasCalendario);
			// return continuarGenerar(hasCalendario);
		}
	}

	// private String continuarGenerar(boolean hasCalendario) {
	// try {
	// String result = boletasBo.crearCalendario(historicoOperacion,
	// indicesFxCobroList, indicesFxPagoList);
	// if ("00".equals(result) && hasCalendario) {
	// /**
	// * Si retorno=’00’ and v_existe_calendario =’S’ Limpiar
	// * T_ACCIONES_TRAMOS_SALIR (199) Grabar matriz
	// * T_ACCIONES_TRAMOS_SALIR (1) Acción , varchar2(2) ‘C’
	// * Codliqui, number(12) null Fetraliq, date null Fecintr, date
	// * null Fecfintr,date null Tipopera, varchar2(2) null Concepto,
	// * varchar2(3) null Tipconce, varchar2(3) null Importes,
	// * number(17,4) null
	// */
	// tramosTableComponent.getTramosTableList().clear();
	// //
	// boletasBo.ajustarLiquidaciones(historicoOperacion,
	// tramosTableComponent.getTramosTableList());
	// statusMessages.add(Severity.INFO,
	// "#{messages['boletas.alta.completa.aviso.ir.a.mantram']}");
	//
	// }
	// if ("01".equals(result)) {
	// statusMessages.add(Severity.ERROR,
	// "#{messages['boletas.alta.completa.error.perdida.historico']}");
	// }
	// // cargarTramosAction();
	// tramosTableComponent = new TramosTableComponent();
	// //return "TO_MANTRAM";
	// return "";
	// } catch (BoletasBusinessException e) {
	// codigoValidacionErroneo = e.getMessage();
	// statusMessages.add(Severity.ERROR,
	// "#{messages['boletas.alta.completa.error.crear.calendario']}");
	// return Constantes.FAIL;
	// }
	// }

	public String onMessageBoxGenerarConFechaOk(boolean hasCalendario) {
		tramosTableComponent = new TramosTableComponent();
		return llamarCalendarioCrear(hasCalendario);
		// return continuarGenerar(hasCalendario);
	}

	public void onMessageBoxGenerarConFechaKo() {
		// Volver a pantalla
	}

	/*
	 * 
	 * 
	 * FUNCTION F_CANALES_VALIDOS RETURN BOOLEAN IS V_RETURN BOOLEAN := TRUE;
	 * V_CONT NUMBER; BEGIN SELECT COUNT(1) INTO V_CONT FROM (SELECT 1 FROM
	 * DERI.PARAMCYP WHERE PRODUCTO = Producto AND CONTRAPA = Contrapartida AND
	 * DIVISACP = NVL(Divisa Pago, Divisa Cobro) AND TIPOPERA = ‘P’ AND
	 * ((TIPODEST = 'CLIENTE' AND Forma Liquidacion Partida='CTA') OR (TIPODEST
	 * = 'TARGET' AND Forma Liquidacion Partida ='TAR')) UNION SELECT 1 FROM
	 * DERI.PARAMSWT WHERE PRODUCTO = Producto AND CONTRAPA = Contrapartida AND
	 * DIVISASW = NVL Divisa Pago, Divisa Cobro) AND TIPOPERA = ‘P’ AND TIPODEST
	 * = 'SWIFT' AND Forma Liquidacion Partida ='SWF'); IF V_CONT <>1 AND (Grupo
	 * Cont <>'XX' and Tipo Cober <> ‘IN’)THEN MOSTRAR_MENSAJE('El canal de
	 * liquidación de la partida es incorrecto'); V_RETURN := FALSE; GO_ITEM
	 * ('BLK_MNTO.CANALIQP'); ELSE SELECT COUNT(1) INTO V_CONT FROM (SELECT 1
	 * FROM DERI.PARAMCYP WHERE PRODUCTO = Producto AND CONTRAPA = Contrapartida
	 * AND DIVISACP = NVL(Divisa Cobro, Divisa Pago) AND TIPOPERA = ‘R’ AND
	 * ((TIPODEST = 'CLIENTE' AND Forma Liq Contrapartida ='CTA') OR (TIPODEST =
	 * 'TARGET' AND Forma Liq Contrapartida ='TAR')) UNION SELECT 1 FROM
	 * DERI.PARAMSWT WHERE PRODUCTO = Producto AND CONTRAPA = Contrapartida AND
	 * DIVISASW = NVL(Divisa Cobro, Divisa Pago) AND TIPOPERA = ‘R’ AND TIPODEST
	 * = 'SWIFT' AND Forma Liq Contrapartida ='SWF'); IF V_CONT <>1 AND (Grupo
	 * Cont <>'XX' and Tipo Cober <> ‘IN’)THEN MOSTRAR_MENSAJE('El canal de
	 * liquidación de la contrapartida es incorrecto'); V_RETURN := FALSE;
	 * GO_ITEM ('BLK_MNTO.CANALIQr'); END IF; END IF; RETURN V_RETURN; END;
	 */

	private boolean canalesValidos() {
		// FLM
		if (historicoOperacion.getGrupoContable() == null
				|| historicoOperacion.getCodigoCobertura() == null) {
			return false;
		}

		HistoricoOpcion historicoOpcion = historicoOperacion
				.getHistoricoOpcion();

		// if (historicoOperacion.getProductoCatalogo() == null ||
		// historicoOperacion.getProductoCatalogo().getModelpro() == null) {
		// addMessage("boletas.error.no.existeproductocatalogo");
		// return false;
		// }

		if (!boletasBo.compruebaCanalesValidos(historicoOperacion, "P",
				pagoCobroType == PagoCobroType.ES_COBRO)
				&& !"XX".equals(historicoOperacion.getGrupoContable().getId()
						.getGrupoContable()) && EsTipoCoberturaIn()) {
			// boletas.canal.liquidacion.partida.invalido=El canal de
			// liquidación de la partida es incorrecto
			addMessage("boletas.canal.liquidacion.partida.invalido");
			return false;
		} else {
			if (!boletasBo.compruebaCanalesValidos(historicoOperacion, "R",
					pagoCobroType == PagoCobroType.ES_COBRO)
					&& !"XX".equals(historicoOperacion.getGrupoContable()
							.getId().getGrupoContable()) && EsTipoCoberturaIn()) {
				// boletas.canal.liquidacion.contrapartida.invalido=El canal de
				// liquidación de la contrapartida es incorrecto
				addMessage("boletas.canal.liquidacion.contrapartida.invalido");
				return false;
			} else {
				return true;
			}
		}
	}

	// FLM: Funcion de navegacion de retorno
	// Debemos volver al anterior excepto si el anterior es la pantalla de alta
	// que debemos retornar uno más arriba
	private String doRetornar() {

		// if ( BoletasStates.CONSULTA_BOLETA.equals( this.boletaState) ) {
		// // volver al punto forzado
		// //if(forcedReturnView!=null){
		// // return forcedReturnView;
		// //}
		// // volver al anterior
		// Conversation conversacion=Conversation.instance();
		// //Volvemos al anterior
		// conversacion.redirectToParent();
		// return "salir";
		// }

		if (BoletasStates.ALTA_BOLETA.equals(this.boletaState)) {
			// 2 Saltos si hemos pasado por el alta de boletas 1 si es una
			// modificacion en modo alta incompleta !!!
			Conversation nested = Conversation.instance();
			Conversation.instance().pop();
			boolean dosSaltos = ("/pages/adminoper/boletas/alta/altaOper.xhtml"
					.equalsIgnoreCase(Conversation.instance().getViewId()));

			if (!dosSaltos) {
				if (forcedReturnView != null) {
					nested.end(true);
					return forcedReturnView;
				} else {
					nested.redirectToParent();
					nested.end(true);
				}
			} else {
				// Cerramos dos y no uno
				nested.end(true);
				if (forcedReturnView != null) {
					Conversation.instance().end(true);
					return forcedReturnView;
				} else {
					Conversation.instance().redirectToParent();
					Conversation.instance().end(true);
				}

			}
			// Ojo, si tiene punto de retorno, al punto de retorno
			// if(forcedReturnView!=null){
			// return forcedReturnView;
			// }
			// ??????
			// if(EntityUtil.checkEntityExists(entityManager,
			// historicoOperacion.getProductoCompuesto())){
			// return
			// "/pages/gestionoperaciones/productocompuesto/mantProdCompuesto.xhtml";
			// }
			return "";
		} else { // Modificacion y consulta siempre vuelven atras
			Conversation conversacion = Conversation.instance();
			// Volvemos al anterior
			conversacion.redirectToParent();
			conversacion.end(true);
			return "";
		}
	}

	public String salir() {
		if (!BoletasStates.CONSULTA_BOLETA.equals(this.boletaState)) {
			try {
				String result = boletasBo.salirOperacion("R",
						historicoOperacion, Identity.instance()
								.getCredentials().getUsername());
				if (result != null) {
					codigoValidacionErroneo = result;
					statusMessages
							.add(Severity.ERROR,
									"#{messages['boletas.edicion.error.salir.operacion']");
				}
				// FLM: boletas es un caso especial, si estamos en alta tenemos
				// que saltar 2 parents quizas?
				return doCommonRedirect();
				// return doSalirRedirect();
			} finally {
				desbloqueo();
			}
		} else {
			return doCommonRedirect();

			// if(forcedReturnView!=null){
			// return forcedReturnView;
			// }
			// Conversation conversacion=Conversation.instance();
			// //Volvemos al anterior
			// conversacion.redirectToParent();
		}
		// FLM return doSalir();
	}

	private String doSalirRedirect() {
		// FLM: Antes de salir debemos dejar el signo como en BBDD

		if (BoletasStates.ALTA_BOLETA.equals(this.boletaState)) {
			// Cierro esta
			// conversacion.end(true);
			// y la anterior para saltarme la pantalla de alta

			// int pos=conversationStack.size()-2;
			// String retorno=conversationStack.get(pos).getViewId();

			Conversation nested = Conversation.instance();
			Conversation.instance().pop();

			boolean dosSaltos = ("/pages/adminoper/boletas/alta/altaOper.xhtml"
					.equalsIgnoreCase(Conversation.instance().getViewId()));

			// if(dosSaltos){
			// Conversation.instance().end(true);
			// }

			if (forcedReturnView != null) {
				if (dosSaltos) {
					Conversation.instance().redirectToParent();
					return "";
				} else {
					Conversation.instance().redirect();
					return "";

				}
				// conversa.end(true);
				// return forcedReturnView;
			}

			nested.end(true);
			if (EntityUtil.checkEntityExists(entityManager, historicoOperacion
					.getProductoCompuesto())) {
				return "/pages/gestionoperaciones/productocompuesto/mantProdCompuesto.xhtml";
			}
			return "salir";
		} else {
			Conversation conversacion = Conversation.instance();
			// Volvemos al anterior
			conversacion.redirectToParent();
			return "";
		}
	}

	// FLM
	// private String doSalir() {
	// if ( !BoletasStates.CONSULTA_BOLETA.equals( this.boletaState) ) {
	// try {
	// String result = boletasBo.salirOperacion("R", historicoOperacion,
	// Identity.instance().getCredentials().getUsername());
	// if (result != null) {
	// codigoValidacionErroneo = result;
	// statusMessages.add(Severity.ERROR,
	// "#{messages['boletas.edicion.error.salir.operacion']");
	// }
	// // //FLM: boletas es un caso especial, si estamos en alta tenemos que
	// saltar 2 parents quizas?
	// // if ( BoletasStates.ALTA_BOLETA.equals( this.boletaState) ) {
	// // //Cierro esta
	// // //conversacion.end(true);
	// // //y la anterior para saltarme la pantalla de alta
	// //
	// // // int pos=conversationStack.size()-2;
	// // //String retorno=conversationStack.get(pos).getViewId();
	// //
	// // Conversation nested =Conversation.instance();
	// // Conversation.instance().pop();
	// // nested.end(true);
	// // Conversation.instance().end(true);
	// // if(forcedReturnView!=null){
	// // return forcedReturnView;
	// // }
	// // if(EntityUtil.checkEntityExists(entityManager,
	// historicoOperacion.getProductoCompuesto())){
	// // return
	// "/pages/gestionoperaciones/productocompuesto/mantProdCompuesto.xhtml";
	// // }
	// // return "salir";
	// // } else {
	// // Conversation conversacion=Conversation.instance();
	// // //Volvemos al anterior
	// // conversacion.redirectToParent();
	// // }
	//				
	// } finally {
	// desbloqueo();
	// }
	// }
	// // else {
	// // if(forcedReturnView!=null){
	// // return forcedReturnView;
	// // }
	// // Conversation conversacion=Conversation.instance();
	// // //Volvemos al anterior
	// // conversacion.redirectToParent();
	// // }
	// return doRetornar();
	//
	// // return Constantes.SUCCESS;
	// }

	private void desbloqueo() {
		if (boletaState == BoletasStates.MODI_BOLETA) {
			if (historicoOperacionBloqueadoId == null) {
				addMessage("boletas.error.no.existe.historicoOperacionBloqueado");
			}
			dbLockService.desbloqueo(HistoricoOperacion.class,
					historicoOperacionBloqueadoId);
		}
	}

	/**
	 * Definint el perímetre d’opcions no confirmables, aquelles que complexin
	 * algun (OR) dels següents requisits:
	 * 
	 * Que es liquidin per diferències Formula <> «Plain Vanilla-Del.Divisas»
	 * 10022 OR Modo Ejercicio <> «Entrega Subyacente» D Que el seu estil NO
	 * sigui ni «Europea» ni «Americana». Opcions amb una barrera: quan aquesta
	 * (la barrera) NO sigui «I-Americana». Opcions amb dues barreres: aquelles
	 * que NO s’ajustin a la definició d’opcions amb barreres dobles que donem
	 * al punt 2 (veure més avall). Quan es tracti de la confirmació de:
	 * Cancelación o Canc. Parcial.
	 * 
	 * Que liquiden por diferencias (deri.situopci.MODOEJER =C) que no sean
	 * europeas ni americanas select * from deri.situopci where estiloop not in
	 * ('E','A') Que no sea la barrera americana deri.situbarr.tipobarr ='E' Si
	 * hay dos barreras select * from deri.situbarr. las dos
	 * substr(tipobap1,2,1) = 'I' o las dos substr(tipobap1,2,1) = 'O' y la
	 * feciniba y la fecfinba deben ser iguales
	 * 
	 * 
	 */
	@SuppressWarnings("unused")
	private boolean opcionConfirmable() {

		if (historicoOperacion.getHistoricoOpcion() == null
				|| historicoOperacion.getHistoricoOpcion().getModoEjercicio() == null
				|| !"D".equals(historicoOperacion.getHistoricoOpcion()
						.getModoEjercicio().getCodigo())) {
			return false;
		}

		if ((formulaDatosOpcion.getValue() == null || 10022 != formulaDatosOpcion
				.getValue().getCodigoFormula())) {
			return false;
		}

		if (historicoOperacion.getHistoricoOpcion() == null
				|| historicoOperacion.getHistoricoOpcion().getEstiloOpcion() == null
				|| !GenericUtils.in(historicoOperacion.getHistoricoOpcion()
						.getEstiloOpcion().getCodigo(), "E", "A")) {
			return false;
		}

		if (historicoOperacion.getHistoricoBarreras() != null
				&& historicoOperacion.getHistoricoBarreras().size() > 0) {

			int contador = 0;
			String tipBar1 = "";
			Date fechaini1 = null;
			Date fechafin1 = null;

			for (HistoricoBarrera historicoBarrera : historicoOperacion
					.getHistoricoBarreras()) {
				contador++;

				if (!"I".equalsIgnoreCase(historicoBarrera.getTipobarr())) {
					return false;
				}

				if (contador == 1) {
					tipBar1 = historicoBarrera.getId().getTipbarp1().substring(
							1, 2);
					fechaini1 = historicoBarrera.getFeciniba();
					fechafin1 = historicoBarrera.getFecfinba();
				}

				if (contador == 2
						&& (!tipBar1.equalsIgnoreCase(historicoBarrera.getId()
								.getTipbarp1().substring(1, 2))
								|| fechaini1.compareTo(historicoBarrera
										.getFeciniba()) != 0 || fechafin1
								.compareTo(historicoBarrera.getFecfinba()) != 0)) {
					return false;
				}

			}
		}

		return true;

	}

	/**
	 * Dades valides. Enric Calafell & FLM
	 */
	private void dadesValides() {
		retDadesValides = true;
		retDadesAmbWarnings = false;
		retWarnings = "";

		HistoricoOperacion ho = historicoOperacion;
		if (menorQue(ho.getFechaValor(), ho.getId().getFechaContratacion())) {
			// TODO: Validar, no se visualiza este warning
			// addMessage("boletas.dadesValidades.fValorFContr");
			// Aviso
			addWarning("boletas.dadesValidades.fValorFContr");
		}

		// Date fechaInicioMinima = boletasBo.obtenerFechaMinIncio(ho);
		// Date fechaFinMaxima = boletasBo.obtenerFechaMaxFin(ho);

		// if (ho.getFechaVencimiento().compareTo(fechaFinMaxima)!=0){
		// addMessage("boletas.dadesValidades.fechaVencFin");
		// }

		// if (fechaInicioMinima.compareTo(ho.getFechaValor())!=0){
		// addMessage("boletas.dadesValidades.fechaValorIni");
		// }

		if (historicoOperacion.getProductoCatalogo() != null
				&& historicoOperacion.getProductoCatalogo().getProdtrat() != null
				&& "S".equals(historicoOperacion.getProductoCatalogo()
						.getProdtrat().getChkopcdiv())) {
			// Opcion Sobre Divisas INI
			if (mayorQue(ho.getFechaValor(), ho.getFechaVencimiento())) {
				addMessage("boletas.dadesValidades.fVenfValorIgual");
			}

			// if (ho.getHistoricoOpcion()!=null &&
			// ho.getHistoricoOpcion().getModoEjercicio()!=null
			// &&
			// "C".equals(ho.getHistoricoOpcion().getModoEjercicio().getCodigo())){
			// ParamCobroPago paramcyp = null;
			// Short entioper;
			// try {
			// entioper = Short.valueOf(ho.getEntidad().getCodigo());
			// } catch (Exception e) {
			// entioper= 81;
			// }
			// ParamCobroPagoId idParamCobro = null; String canal = null;
			// switch (pagoCobroType) {
			// case ES_PAGO:
			// canal =
			// convertirCanalLiquidacion(ho.getCanalLiquidacionPago().getCodigo());
			// idParamCobro = new
			// ParamCobroPagoId(Constantes.NOMBRE_PROYECTO_DERI,
			// ho.getProducto().getId(),
			// pagoCobroType.getCodigo(),
			// ho.getDivisaLiquidacionPago().getId(),
			// ho.getContrapartida().getId(),
			// canal,
			// entioper);
			// break;
			// case ES_COBRO:
			// canal =
			// convertirCanalLiquidacion(ho.getCanalLiquidacionRecibo().getCodigo());
			// idParamCobro = new
			// ParamCobroPagoId(Constantes.NOMBRE_PROYECTO_DERI,
			// ho.getProducto().getId(),
			// pagoCobroType.getCodigo(),
			// ho.getDivisaLiquidacionRecibo().getId(),
			// ho.getContrapartida().getId(),
			// canal,
			// entioper);
			// break;
			// default:
			// break;
			// }
			//			
			//	
			//	
			//				
			// ParamCobroPago paramCP = null;
			// if (idParamCobro!=null){
			// paramCP = boletasBo.cargarParamCobroPago(idParamCobro);
			// if (paramCP==null){
			// addWarning("boletas.dadesValidades.paramcyp");
			// }
			// }else{
			// addWarning("boletas.dadesValidades.paramcyp");
			// }
			//					
			//					
			//					
			//				
			// }

			// deri.situopci.MODOEJER = 'D' Delivery "Entrega subyacente" 'C'
			// cash "Liquidación por diferencias"
			// Si Formula = «Plain Vanilla-Cash» 1001 aleshores Modo Ejercicio =
			// «Liquidación por diferencias»
			// Si Formula = «Plain Vanilla-Del.Divisas» 10022 aleshores Modo
			// Ejercicio = «Entrega subyacente»
			if (formulaDatosOpcion.getValue() != null
					&& 1001 == formulaDatosOpcion.getValue().getCodigoFormula()
					&& historicoOperacion.getHistoricoOpcion() != null
					&& historicoOperacion.getHistoricoOpcion()
							.getModoEjercicio() != null
					&& !"C".equals(historicoOperacion.getHistoricoOpcion()
							.getModoEjercicio().getCodigo())) {
				addMessage("boletas.dadesValidades.formulaModoEjercicio");
			}

			if (formulaDatosOpcion.getValue() != null
					&& 10022 == formulaDatosOpcion.getValue()
							.getCodigoFormula()
					&& historicoOperacion.getHistoricoOpcion() != null
					&& historicoOperacion.getHistoricoOpcion()
							.getModoEjercicio() != null
					&& !"D".equals(historicoOperacion.getHistoricoOpcion()
							.getModoEjercicio().getCodigo())) {
				addMessage("boletas.dadesValidades.formulaModoEjercicio");
			}

			// Opcion Sobre Divisas FI

		} else if (mayorIgualQue(ho.getFechaValor(), ho.getFechaVencimiento())) {
			addMessage("boletas.dadesValidades.fVenfValor");
		}

		Date fechaTramoIrregular = null;
		switch (pagoCobroType) {
		case ES_PAGO:
			if (!isNull(ho.getFinTramoIrregularPago())) {
				fechaTramoIrregular = ho.getFinTramoIrregularPago();
			}
			break;
		case ES_COBRO:
			if (!isNull(ho.getFinTramoIrregularPago())) {
				fechaTramoIrregular = ho.getFinTramoIrregularRecibo();
			}
			break;
		default:
			break;
		}
		if (menorIgualQue(fechaTramoIrregular, ho.getFechaValor())) {
			addMessage("boletas.dadesValidades.fTramofValor");
		}
		if (mayorQue(fechaTramoIrregular, ho.getFechaVencimiento())) {
			addMessage("boletas.dadesValidades.fTramofen");
		}
		Short nuevedosnueve = new Short((short) 929);
		if ("GWM".equalsIgnoreCase(ho.getUnidadNegocio())
				&& !(nuevedosnueve.equals(ho.getOficina()))) {
			addWarning("boletas.dadesValidades.UnidadOficina");
		}
		/*
		 * RFA: incidencia 1106
		 * 
		 * El campo Cob A/P, debe ser obligatorio si Tipo Cober = 'CO'
		 * (cobertura) y no se hace este control.
		 * 
		 * => Lo comprobamos solo para el alta completa, no en el campo como
		 * dice el DT porque interferiría con el alta incompleta
		 */
		if (entityUtil.checkEntityExists(ho.getCodigoCobertura())
				&& "CO".equals(ho.getCodigoCobertura().getCodigo())
				&& !entityUtil.checkEntityExists(ho.getIndActivoPasivo())) {
			addMessage("boletas.dadesValidades.indactpa.obligatorio");
		}

		// Grupo Contable
		if (GenericUtils.isNullOrBlank(ho.getGrupoContable())
				&& ((entityUtil.checkEntityExists(ho.getCodigoCobertura()) && "CO"
						.equals(ho.getCodigoCobertura().getCodigo())) || !getEsProductoR())) {
			addMessage("boletas.dadesValidades.grupocontable.obligatorio");
		} else {
			/**
			 * En estadoco = 'PV' e indsitua='A'. Grupo contable FB si a.
			 * Producto: 751204 (Equity Swaps) b. Trade Date en mes no
			 * coincidente (MM – n; siendo n=1,2,3,4 …) con el mes de la fecha
			 * valor de la operación. y la fecha valor > fecha de contratación
			 * c. Contrapartida de Mercado (<> 'CLIENTES')
			 */
			// Se añade control para verificar que la contrapartida este en la
			// tabla CONTRAPA.
			if (EntityUtil.checkEntityExists(entityManager, ho
					.getContrapartida())
					&& ho.getContrapartida() instanceof Contrapartida) {

				Contrapartida contrapa = (Contrapartida) ho.getContrapartida();
				String estado = ho.getEstado().getCodigo();
				if (("PV".equals(estado) || "IN".equals(estado))
						&& "A".equals(ho.getUltimaAccion().getCodigo())
						&& ho.getProducto().getId().equals("751204")
						&& GenericUtils.getMonth(ho.getFechaValor()) != GenericUtils
								.getMonth(ho.getId().getFechaContratacion())
						&& ho.getFechaValor().after(
								ho.getId().getFechaContratacion())
						&& entityUtil.checkEntityExists(contrapa
								.getGrupoBancario())
						&& !Constantes.CONTRAPA_GRUPOBAN_CLIENTE
								.equals(contrapa.getGrupoBancario().getId())) {

					if (!ho.getGrupoContable().getId().getGrupoContable()
							.equals("FB")) {
						addWarning("boletas.dadesValidades.grupoContable.FB");
					}
				}

			}
		}

		// F. Fij. Strike Obligatorio si Strike Promedio marcado
		if (hasDatosOpcionTab() && ho.getHistoricoOpcion() != null
				&& ho.getHistoricoOpcion().getIndstrpr()
				&& !hayFechasTipo("FS")) {
			addMessage("boletas.dadesValidades.ffijstrike.obligatorio");
		}

		// SMM 31/01/2018 mecap-33681
		if (hasDatosOpcionTab()
				&& ho.getHistoricoOpcion() != null
				&& !isVisible("24030")
				&& GenericUtils.isNullOrBlank(ho.getHistoricoOpcion()
						.getDescripcionTranAcum())) {
			addMessage("boletas.dadesValidades.tranacum.obligatorio");
		}

		if (ho.getProducto() != null
				&& ("751055".equals(ho.getProducto().getId()) || " 00003"
						.equals(ho.getProducto().getId()))) {
			if (!boletasBo.comprobarCMS(ho)) {

				// La validación consta de una consulta a la tablas
				// DERI.TPFOLDER donde el Where será:
				// Producto = informado por pantalla
				// Carterfo = informado por pantalla
				// Tipcober = informado por pantalla
				// Esquemac = informado por pantalla
				// Grupocon = informado por pantalla

				addWarning("boletas.dadesValidades.datosContaIncoherente");
			}
		}

		// Validacion Primas Implicitas
		if (isProductoEQS() && !existeTramoPrimaImp()) {
			addWarning("boletas.dadesValidades.primasImplicitas");
		}

		dadesValidesFase2(true);
	}

	private String convertirCanalLiquidacion(String codigo) {
		if ("CTA".equals(codigo)) {
			return "CLIENTE";
		} else if ("TAR".equals(codigo)) {
			return "TARGET";
		} else if ("SWF".equals(codigo)) {
			return "SWIFT";
		}

		return "";

	}

	public void dadesValidesFase2(Boolean ret) {
		HistoricoOperacion ho = historicoOperacion;
		Short nuevedosnueve = new Short((short) 929);
		Short nuevecerouno = new Short((short) 901);
		Short nuevecerocinco = new Short((short) 905);

		// FLM : 1635 lo correcto es si es diferente a 929 !
		if (nuevedosnueve.equals(ho.getOficina())
				&& ("UIJOESMMXXX".equalsIgnoreCase(ho.getContrapartida()
						.getId()))) {
			// && ("BSABESBBSBP".equalsIgnoreCase(
			// ho.getContrapartida().getId()) )) {
			// addWarning("boletas.dadesValidades.ContrapaPartida");
			statusMessages.addToControl("codigoContrapartida__30003__",
					Severity.WARN,
					"#{messages['boletas.dadesValidades.ContrapaPartida']");
			retWarnings = retWarnings
					+ " "
					+ Messages.instance().get(
							"boletas.dadesValidades.ContrapaPartida");
			retDadesAmbWarnings = true;
		}
		if (nuevecerouno.equals(ho.getOficina())
				&& ("BSABESBBXXX".equalsIgnoreCase(ho.getContrapartida()
						.getId()))) {
			// addWarning("boletas.dadesValidades.ContrapaPartida");
			statusMessages.addToControl("codigoContrapartida__30003__",
					Severity.WARN,
					"#{messages['boletas.dadesValidades.ContrapaPartida']");
			retWarnings = retWarnings
					+ " "
					+ Messages.instance().get(
							"boletas.dadesValidades.ContrapaPartida");
			retDadesAmbWarnings = true;
		}
		if (nuevecerocinco.equals(ho.getOficina())
				&& ("BGUIES22XXX".equalsIgnoreCase(ho.getContrapartida()
						.getId()))) {
			// addWarning("boletas.dadesValidades.ContrapaPartida");
			statusMessages.addToControl("codigoContrapartida__30003__",
					Severity.WARN,
					"#{messages['boletas.dadesValidades.ContrapaPartida']");
			retWarnings = retWarnings
					+ " "
					+ Messages.instance().get(
							"boletas.dadesValidades.ContrapaPartida");
			retDadesAmbWarnings = true;
		}
		dadesValidesFase3(true);
	}

	private boolean EsTipoCoberturaIn() {
		return (entityUtil.checkEntityExists(historicoOperacion
				.getCodigoCobertura()) && "IN"
				.equalsIgnoreCase(historicoOperacion.getCodigoCobertura()
						.getCodigo()));
	}

	public boolean isProductoEQS() {

		if (historicoOperacion.getProductoCatalogo() != null
				&& historicoOperacion.getProductoCatalogo().getProdtrat() != null
				&& "S".equalsIgnoreCase(historicoOperacion
						.getProductoCatalogo().getProdtrat().getChkequit())
				&& historicoOperacion.getContrapartida() != null
				&& ((GenericUtils.isNullOrBlank(historicoOperacion
						.getCodigoCobertura())
						&& !GenericUtils.isNullOrBlank(historicoOperacion
								.getGrupoContableCode()) && (historicoOperacion
						.getGrupoContableCode().matches("[0-9].*") || "FB"
						.equalsIgnoreCase(historicoOperacion
								.getGrupoContableCode()))) ||

				(!GenericUtils.isNullOrBlank(historicoOperacion
						.getCodigoCobertura()) && "CO"
						.equalsIgnoreCase(historicoOperacion
								.getCodigoCobertura().getCodigo())))) {

			// Se añade control para verificar que la contrapartida este en la
			// tabla CONTRAPA.
			if (EntityUtil.checkEntityExists(entityManager, historicoOperacion
					.getContrapartida())
					&& historicoOperacion.getContrapartida() instanceof Contrapartida) {

				Contrapartida contrapa = (Contrapartida) historicoOperacion
						.getContrapartida();
				if (!GenericUtils
						.isNullOrBlank(contrapa.getTipoContrapartida())
						&& "B".equalsIgnoreCase(contrapa.getTipoContrapartida()
								.getId())) {

					return true;
				}
			}

			return false;
		} else {
			return false;
		}

	}

	public boolean existeTramoPrimaImp() {
		for (HistoricoTramos tramo : historicoOperacion.getHistoricoTramoses()) {
			if ("PRI".equalsIgnoreCase(tramo.getId().getConcepto())
					&& "IMP".equalsIgnoreCase(tramo.getId().getTipoConcepto())) {
				return true;
			}
		}
		return false;
	}

	public void dadesValidesFase3(Boolean ret) {
		HistoricoOperacion ho = historicoOperacion;

		// if (ho.getContrapartida()!=null &&
		// "EUXCDEFFXXX".equalsIgnoreCase(ho.getContrapartida().getId())
		if (ho.getContrapartida() != null
				&& boletasBo.esCamara(ho.getContrapartida().getId())
				&& ho.getContrapartidaOriginal() == null) {

			statusMessages.addToControl("codigoContrapartidaOrig__30007__",
					Severity.ERROR,
					"#{messages['boletas.dadesValidades.contrapaCamara']");
			retDadesValides = false;

		}

		/*
		 * RFA: Incidencia 1084 La validación de la Forma de Liquidación
		 * (Partida/Contrapartida) debería ser:
		 * 
		 * Si (grupo contable no = null y grupo contable <> 'XX' y canaliqp =
		 * null) o (Tipo Cobert <> null y Tipo Cobert <> 'IN' y canaliqp =
		 * null), mostrar error: 'Canal de pago obligatorio'
		 * 
		 * Si (grupo contable no = null y grupo contable <> 'XX' y canaliqr =
		 * null) o (Tipo Cobert <> null y Tipo Cobert <> 'IN' y canaliqr =
		 * null), mostrar error:'Canal de cobro obligatorio'
		 * 
		 * Antes: if(!isNull(ho.getGrupoContable()) &&
		 * isNull(ho.getTipoCobertura()) && !"XX".equals(
		 * ho.getGrupoContable().getDescripcion()) && "IN".equals(
		 * ho.getTipoCobertura())){
		 * if(!isNull(ho.getCanalLiquidacionPago().getCodigo())){
		 * addMessage("boletas.dadesValidades.canalPagoObligatorio"); }
		 * if(!isNull(ho.getCanalLiquidacionRecibo().getCodigo())){
		 * addMessage("boletas.dadesValidades.canalCobroObligatorio"); } }
		 */
		boolean esGrupoContableNoXX = entityUtil.checkEntityExists(ho
				.getGrupoContable())
				&& !"XX".equals(ho.getGrupoContable().getId()
						.getGrupoContable());
		boolean esTipoCoberturaNoIn = entityUtil.checkEntityExists(ho
				.getCodigoCobertura())
				&& !"IN".equalsIgnoreCase(ho.getCodigoCobertura().getCodigo());
		boolean esContrapartidaModelo = ho.getContrapartida() != null
				&& "MODELO".equalsIgnoreCase(ho.getContrapartida().getId());

		// boolean esContrapartidaBancaria = ho.getContrapartida()== null ||
		// !"C".equalsIgnoreCase(getTipoContr());

		// if (esContrapartidaBancaria){
		// if (!GenericUtils.isNullOrZero(ho.getImporteMargenCancelacion())
		// || !GenericUtils.isNullOrZero(ho.getImporteMargenOficina())
		// || !GenericUtils.isNullOrZero(ho.getMargenTesoreria())
		// || !GenericUtils.isNullOrBlank(ho.getOficinaMargen())
		// ){
		// addMessage("boletas.dadesValidades.contrabancaria");
		// }
		// }

		if ((!GenericUtils.isNullOrZero(ho.getImporteMargenCancelacion())
				|| !GenericUtils.isNullOrZero(ho.getImporteMargenOficina()) || !GenericUtils
				.isNullOrZero(ho.getMargenTesoreria()))) {

			if (GenericUtils.isNullOrBlank(ho.getOficinaMargen())) {
				statusMessages
						.addToControl("datosGestionOficina__5001__",
								Severity.ERROR,
								"#{messages['boletas.dadesValidades.oficinamargen.obligatorio']");
				retDadesValides = false;
			} else if (GenericUtils.isNullOrBlank(ho.getDivisaMargenOficina())) {
				statusMessages
						.addToControl("datosGestionDivisa__5003__",
								Severity.ERROR,
								"#{messages['boletas.dadesValidades.divisamargen.obligatorio']");
				retDadesValides = false;
			}

		}

		// ERROR CUANDO NO ES UNA CONTRAPA NORMAL
		// Contrapartida contrapartida =
		// contrapartidaUtil.castAsContrapartida(ho.getContrapartida());
		// if (!GenericUtils.isNullOrBlank(ho.getOficinaMargen()) &&
		// !GenericUtils.isNullOrBlank(contrapartida)){
		// NO INTERNA grupocon XX Ó tipocober = IN

		if ((GenericUtils.isNullOrBlank(ho.getGrupoContable()) || !"XX"
				.equals(ho.getGrupoContable().getId().getGrupoContable()))
				&& (GenericUtils.isNullOrBlank(ho.getCodigoCobertura()) || !"IN"
						.equalsIgnoreCase(ho.getCodigoCobertura().getCodigo()))) {

			if (!GenericUtils.isNullOrBlank(ho.getOficinaMargen())
					&& !GenericUtils.isNullOrBlank(ho.getContrapartida())) {
				Short oficinaCMOF = boletasBo.oficinaCMOF(ho.getContrapartida()
						.getId(), ho.getEntidad());

				if (!GenericUtils.isNullOrBlank(oficinaCMOF)
						&& !oficinaCMOF.equals(ho.getOficinaMargen()
								.getCodigo())) {

					addWarning("boletas.dadesValidades.oficinaMargenCMOF");

				}
			}

		}

		if ((esGrupoContableNoXX || esTipoCoberturaNoIn)
				&& !esContrapartidaModelo) {
			if (!entityUtil.checkEntityExists(ho.getCanalLiquidacionPago())) {
				addMessage("boletas.dadesValidades.canalPagoObligatorio");
			}
			if (!entityUtil.checkEntityExists(ho.getCanalLiquidacionRecibo())) {
				addMessage("boletas.dadesValidades.canalCobroObligatorio");
			}
		}

		// Clave BDU No debe ser obligatoria si la contrapartida = 'MODELO'
		// tampoco es obligatoria si modelo=dedalo
		if (GenericUtils.isNullOrBlank(ho.getClaveExternaBDU())
				&& !esContrapartidaModelo
				&& !ho.getProductoCatalogo().getModelpro().getModelpro()
						.equals("DED")) {
			addMessage("boletas.dadesValidades.clavebdu.obligatorio");
		}
		if (!esContrapartidaModelo
				&& !ho.getProductoCatalogo().getModelpro().getModelpro()
						.equals("DED")
				&& !GenericUtils.isNullOrBlank(ho.getClaveExternaBDU())
				&& historicoOperacion.getClaveExternaBDU().length() != 18) {
			addMessage("boletas.edicion.error.claveBDU.tamano");
		}

		if ("PR".equals(ho.getAplicacionSibis())
				&& isNull(ho.getContratoSibis())) {
			addMessage("boletas.dadesValidades.prestamoSibis");
		}
		switch (pagoCobroType) {
		case ES_PAGO:
			if (mayorQue(ho.getInicioTramoIrregularPago(), ho
					.getFinTramoIrregularPago()))
				addMessage("boletas.dadesValidades.fechaIniFinTramos");
			break;
		case ES_COBRO:
			if (mayorQue(ho.getInicioTramoIrregularRecibo(), ho
					.getFinTramoIrregularRecibo()))
				addMessage("boletas.dadesValidades.fechaIniFinTramos");
			break;
		case INDEFINIDO:
			if (mayorQue(ho.getInicioTramoIrregularPago(), ho
					.getFinTramoIrregularPago()))
				addMessage("boletas.dadesValidades.fechaIniFinTramos");
			else if (mayorQue(ho.getInicioTramoIrregularRecibo(), ho
					.getFinTramoIrregularRecibo()))
				addMessage("boletas.dadesValidades.fechaIniFinTramos");
			break;
		default:
			break;
		}
		if (hasBarrerasTab()) {
			if (ho.getIndicadorRebatePago() && isNull(ho.getTipoRebatePago()))
				addMessage("boletas.dadesValidades.rebateCero");
			else if (ho.getIndicadorRebateRecibo()
					&& isNull(ho.getTipoRebateRecibo()))
				addMessage("boletas.dadesValidades.rebateCero");
		}
		// Primas
		if ((hasPrimasTab())) {
			// if(
			// mayorQue(ho.getFechaLiquidacionUpFront(),ho.getFechaVencimiento()))
			// addMessage("boletas.dadesValidades.fLiqFVto");
			if (menorQue(ho.getFechaLiquidacionUpFront(), ho.getId()
					.getFechaContratacion()))
				addMessage("boletas.dadesValidades.fLiqFContr");
			if (pendienteComprobarPrimaUpfront(ho)) {
				switch (pagoCobroType) {
				case ES_PAGO:
					if (!(ho.getDivisaPrimaUpFront())
							.equals(ho.getDivisaPago()))
						addMessage("boletas.dadesValidades.divisaDivisa");
					break;
				case ES_COBRO:
					if (!(ho.getDivisaPrimaUpFront()).equals(ho
							.getDivisaRecibo()))
						addMessage("boletas.dadesValidades.divisaDivisa");
					break;
				case INDEFINIDO:
					if (!(ho.getDivisaPrimaUpFront())
							.equals(ho.getDivisaPago()))
						addMessage("boletas.dadesValidades.divisaDivisa");
					else if (!(ho.getDivisaPrimaUpFront()).equals(ho
							.getDivisaRecibo()))
						addMessage("boletas.dadesValidades.divisaDivisa");
					break;
				default:
					break;
				}
			}
			// FLM
			// F. Liquidación(prima up-front)/Divisa (prima up-front):Llamar a
			// PKG_BOLETA.P_ES_FESTIVO (fecha, divisa, switch, filler) enviando
			// como parámetros F.Liquidación, Divisa Prima up-front), si
			// devuelve que es festivo (switch=’S’), mostrar error 'La fecha
			// liquidación de prima Up Front no puede ser festivo'
			if (ho.getFechaLiquidacionUpFront() != null
					&& ho.getDivisaPrimaUpFront() != null
					&& boletasBo.validateFestivo(ho
							.getFechaLiquidacionUpFront(), ho
							.getDivisaPrimaUpFront()))
				addMessage("boletas.dadesValidades.fLiqPrimaUpNoFestivo");

			// o F. Vto/F. Pr. Impl (pestaña primas): si F. Pr. Impl <> null, si
			// F. Pr. Impl > F. Valor, mostrar error: 'La fecha liquidación de
			// prima no puede ser posterior a la fecha vencimiento'
			// FLM: : Avisar a francisco que la condición es con fecha
			// vencimiento y no valor
			if (mayorQue(ho.getFechaValorPrimaImplicita(), ho
					.getFechaVencimiento()))
				addMessage("boletas.dadesValidades.fLiqPostfVen");

			// o F. Valor/F. Pr. Impl (pestaña primas): si F. Pr. Impl <> null,
			// si F. Pr. Impl < F. Valor, mostrar error: ‘La F. Liq. Prima no
			// puede ser anterior a fecha Valor’
			if (mayorQue(ho.getFechaValor(), ho.getFechaValorPrimaImplicita()))
				addMessage("boletas.dadesValidades.fLiqPrimaAntfVal");
			// o Divisa (prima periodica)/Divisa (Pago/Cobro): Si Divisa (prima
			// periodica) <> null, (si Divisa (prima periodica) <> Divisa Pago y
			// Divisa (prima periodica) <> Divisa Cobro), mostrar error: 'La
			// divisa de la prima periodica ha de coincidir con la divisa de la
			// operación'
			if (ho.getDivisaPrimaPeriodica() != null
					&& !ho.getDivisaPrimaPeriodica().equals(ho.getDivisaPago())
					&& !ho.getDivisaPrimaPeriodica().equals(
							ho.getDivisaRecibo()))
				addMessage("boletas.dadesValidades.divPrimaPerDifDivOpe");

			// o F. Pr. Impl (prima implicita)/Divisa (prima implicita):Llamar a
			// PKG_BOLETA.P_ES_FESTIVO (fecha, divisa, switch, filler) enviando
			// como parámetros F. Pr. Impl, Divisa prima implicita), si devuelve
			// que es festivo (switch=’S’), mostrar error ‘La fecha liquidación
			// de prima no puede ser festivo'
			// :
			// o Divisa (prima cancelación)/Divisa (Pago/Cobro): Si Divisa
			// (prima cancelación) <> null, (si Divisa (prima cancelación) <>
			// Divisa Pago y Divisa (prima cancelación) <> Divisa Cobro),
			// mostrar error 'La divisa de la prima cancelación ha de coincidir
			// con la divisa de la operación'

			if (pendienteComprobarPrimaCancelacion(ho)
					&& ho.getDivisaPrimaCancelacion() != null
					&& !ho.getDivisaPrimaCancelacion().equals(
							ho.getDivisaPago())
					&& !ho.getDivisaPrimaCancelacion().equals(
							ho.getDivisaRecibo()))
				addMessage("boletas.dadesValidades.divPrimaCancDifDivOpe");

			// Cobro/Pago
			// : Signo
			// o Sig /Spread (pago): Si (Spread <> null y <> 0) y Sig = null,
			// mostrar error ‘Signo es Obligatorio’
			if (ho.getSpreadPago() != null
					&& ho.getSpreadPago().intValue() != 0
					&& getSignoPago() == null)
				addMessage("boletas.dadesValidades.SignoOblig");
			// o Importe (pago): Si Clase = ‘C’ y Importe es null, mostrar
			// error: 'Campo Obligatorio Importe Fijo'
			if (ho.getIndicadorTipoPago() != null
					&& "C".equalsIgnoreCase(ho.getIndicadorTipoPago()
							.getCodigo())
					&& GenericUtils.nvl(ho.getImporteCuponFijoPago(),
							BigDecimal.valueOf(0)) == BigDecimal.valueOf(0))
				addMessage("boletas.dadesValidades.ImporteFijoOblig");
			// o Tipo Int. (pago): Si Clase = ‘F’ y Tipo Int. es null y Strike
			// es null, mostrar error: ‘Campo Obligatorio Tipo Interés, Strike'
			if (ho.getIndicadorTipoPago() != null
					&& "F".equalsIgnoreCase(ho.getIndicadorTipoPago()
							.getCodigo()) && ho.getStrikePago() == null
					&& ho.getPorcentajeTipoFijoPago() == null)
				addMessage("boletas.dadesValidades.TipoIntStrikeOblig");

			// o Sig /Spread (cobro): Si (Spread <> null y <> 0) y Sig = null,
			// mostrar error ‘Signo es Obligatorio’
			// FLM: Es campo visual
			if (ho.getSpreadRecibo() != null
					&& ho.getSpreadRecibo().intValue() != 0
					&& getSignoCobro() == null)
				addMessage("boletas.dadesValidades.SignoOblig");

			// o Importe (Cobro): Si Clase = ‘C’ y Importe es null, mostrar
			// error: 'Campo Obligatorio Importe Fijo'
			if (ho.getIndicadorTipoRecibo() != null
					&& "C".equalsIgnoreCase(ho.getIndicadorTipoRecibo()
							.getCodigo())
					&& GenericUtils.nvl(ho.getImporteCuponFijoRecibo(),
							BigDecimal.valueOf(0)) == (BigDecimal.valueOf(0)))
				addMessage("boletas.dadesValidades.ImporteFijoOblig");
			// o Tipo Int. (Cobro): Si Clase = ‘F’ y Tipo Int. es null y Strike
			// es null, mostrar error: ‘Campo Obligatorio Tipo Interés, Strike'
			if (ho.getIndicadorTipoRecibo() != null
					&& "F".equalsIgnoreCase(ho.getIndicadorTipoRecibo()
							.getCodigo()) && ho.getStrikeRecibo() == null
					&& ho.getPorcentajeTipoFijoRecibo() == null)
				addMessage("boletas.dadesValidades.TipoIntStrikeOblig");
			// o Liq Digital / % Liquidación: si Liq Digital marcado (S) y %
			// Liquidación es null, mostrar error: 'Campo Obligatorio %
			// Liquidación'
			if ((ho.getIndicadorLiqDigital() && ho.getPorcentajeLiqDigital() == null)
					|| (ho.getIndicadorLiqDigitalRecibo() && ho
							.getPorcentajeLiqDigitalRecibo() == null))
				addMessage("boletas.dadesValidades.PctLiqOblig");
			// o Si no F_PERIODO_VALIDO mostrar error: ‘Datos de Periodos no son
			// válidos’
			// : ver función datos periodos
			// SCM: Si check Up-Front activado, 'Divisa' y 'Cobro/Pago'
			// obligatorio
			if (historicoOperacion.getIndicadorPrimaUpFront()) {
				if (GenericUtils.isNullOrBlank(historicoOperacion
						.getTipoPrimaUpFront())) {
					addMessage("boletas.dadesValidades.tipoPrimaUpFront.obligatorio");
				}
				if (GenericUtils.isNullOrBlank(historicoOperacion
						.getDivisaPrimaUpFront())) {
					addMessage("boletas.dadesValidades.divisaPrimaUpFront.obligatorio");
				}
			}
			// SCM: Si check Periodica activado, 'Divisa' y 'Cobro/Pago'
			// obligatorio
			if (historicoOperacion.getIndicadorPrimaUpPeriodica()) {
				if (GenericUtils.isNullOrBlank(historicoOperacion
						.getTipoPrimaPeriodica())) {
					addMessage("boletas.dadesValidades.tipoPrimaPeriodica.obligatorio");
				}
				if (GenericUtils.isNullOrBlank(historicoOperacion
						.getDivisaPrimaPeriodica())) {
					addMessage("boletas.dadesValidades.divisaPrimaPeriodica.obligatorio");
				}
			}
			// SCM: Si check Implicita activado, 'Importe', 'Divisa' y
			// 'Cobro/Pago' obligatorio
			if (esPrimaImplicita) {
				if (GenericUtils.isNullOrBlank(historicoOperacion
						.getTipoPrimaImplicita())) {
					addMessage("boletas.dadesValidades.tipoPrimaImplicita.obligatorio");
				}
				if (GenericUtils.isNullOrBlank(historicoOperacion
						.getImportePrimaImplicita())) {
					addMessage("boletas.dadesValidades.importePrimaImplicita.obligatorio");
				}
				if (GenericUtils.isNullOrBlank(historicoOperacion
						.getDivisaPrimaImplicita())) {
					addMessage("boletas.dadesValidades.divisaPrimaImplicita.obligatorio");
				}
			}
			// SCM: Si check Cancelacion activado, 'Importe', 'Divisa' y
			// 'Cobro/Pago' obligatorio
			if (esPrimaCancelacion) {
				if (GenericUtils.isNullOrBlank(historicoOperacion
						.getTipoPrimaCancelacion())) {
					addMessage("boletas.dadesValidades.tipoPrimaCancelacion.obligatorio");
				}
				if (GenericUtils.isNullOrBlank(historicoOperacion
						.getImportePrimaCancelacion())) {
					addMessage("boletas.dadesValidades.importePrimaCancelacion.obligatorio");
				}
				if (GenericUtils.isNullOrBlank(historicoOperacion
						.getDivisaPrimaCancelacion())) {
					addMessage("boletas.dadesValidades.divisaPrimaCancelacion.obligatorio");
				}
			}
		}

		if (hasDatosMurex()) {
			if (!boletasBo.existeFolderEstrategia(ho.getFolderEstrategia())) {
				addMessage("boletas.dadesValidades.FolderEstrategia");
			}
		}

		if (hasDatosKondor()) {
			// Datos Kondor
			// o Num.Ext/dealtype (si activos): si dealtype='XXX' y Num.Ext <>
			// null, mostrar error: 'Una operación con deal type XXX no puede
			// tener deal number'
			if (!boletasBo.existeFolderEstrategia(ho.getFolderEstrategia())) {
				addMessage("boletas.dadesValidades.FolderEstrategia");
			}

			if ("XXX".equalsIgnoreCase(ho.getDealType())
					&& (ho.getDealNumber() != null))
				addMessage("boletas.dadesValidades.DTypeXXXTieneDNumber");
			// o Num.Ext/dealtype (si activos): si dealtype<>'XXX' y Num.Ext =
			// null, mostrar error: 'Clave kondor nula'
			if (!"XXX".equalsIgnoreCase(ho.getDealType())
					&& ho.getDealNumber() == null)
				addMessage("boletas.dadesValidades.ClaveKondorNula");
			// o Num.Ext/dealtype (si activos): si dealtype<>'XXX' y
			// dealtype<>'CPD' y Num.Ext <> null y F_clave_kondor_existe,
			// mostrar error: ‘Clave kondor duplicada’
			// : Falta la función
			if (!"XXX".equalsIgnoreCase(ho.getDealType())
					&& !"CPD".equalsIgnoreCase(ho.getDealType())
					&& existeClaveKondor())
				addMessage("boletas.dadesValidades.ClaveKondorDupl");
		}
		if ((hasContrapartidasTab())) {

			// Contrapartidas
			// o Contrapa: Si ESTADOCO = ‘IN’ y F_CMOF_NO_FIRMADO, mostrar
			// error: 'La operación no se puede completar si la contrapartida no
			// tiene el CMOF firmado'
			/*
			 * RFA: Incidencia 1068:
			 * 
			 * En un alta completa se debe validar que el CMOF esté firmado para
			 * la contrapartida, esta validación está en
			 * 
			 * F_DADES_VALIDES (en las validaciones de Contrapartida) se debe
			 * realizar siempre que se esté en modoactua 'Alta',
			 * 
			 * en vez de cuando er ESTADOCO = IN
			 * 
			 * Antes: if( "IN".equalsIgnoreCase( ho.getEstado().getCodigo() ) &&
			 * CMOFNoFirmado() )
			 */
			// if(esModoActuaAlta() && CMOFNoFirmado() ){
			// 0 - Sin errores
			// 1 - CMOF no firmado
			// 2 - Anexo no firmado
			Integer cmof = CMOFNoFirmado();
			if (1 == cmof) {
				addMessage("boletas.dadesValidades.CMOFNoFirmado");
			} else if (2 == cmof) {
				if (ho.getUltimaAccion() != null
						&& "A".equalsIgnoreCase(ho.getUltimaAccion()
								.getCodigo())) {
					addMessage("boletas.dadesValidades.AnexoNoFirmadoAlta");
				} else {
					addWarning("boletas.dadesValidades.AnexoNoFirmado");
				}

			}

			// o Contrapa: si no F_CONTRAPARTIDA_COMPLETA, mostrar error: 'La
			// operación no se puede completar si la contrapartida no tiene
			// definido el pais o el indicador de residente'
			if (!contrapartidaCompleta())
				addMessage("boletas.dadesValidades.ContrapaSinPaisResidente");
			// o Contrapartida/Grupo Contable: Si Grupo Cont desprotegido y (
			// contrapartida = ‘FDI’ y SUBSTR(GRUPOCON,1,1) <> 'F'), mostrar
			// error: 'Para la contrapartida FDI el código del grupo contable
			// debe empezar por F',
			if (ho.getGrupoContable() != null
					&& ho.getContrapartida() != null
					&& "FDI".equalsIgnoreCase(ho.getContrapartida().getId())
					&& !ho.getGrupoContable().getId().getGrupoContable()
							.startsWith("F"))
				addMessage("boletas.dadesValidades.GrupoContableContrapaFDI");
		}
		if (hasSibis()) {
			// SIBIS
			// o Ent. Sibis /Aplicación: Si aplicación =’PR’, si Ent. Sibis =
			// null, mostrar error: 'Si es préstamo, entidad SIBIS debe estar
			// informada'
			if ("PR".equalsIgnoreCase(ho.getAplicacionSibis())
					&& ho.getEntidadSibis() == null)
				addMessage("boletas.dadesValidades.EntidadSibisInformPrestamo");
			// o Aplicación /Contrato: Si aplicación =’PR’, si Contrato = null,
			// mostrar error: 'Si es préstamo, contrato SIBIS debe estar
			// informado'
			if ("PR".equalsIgnoreCase(ho.getAplicacionSibis())
					&& ho.getContratoSibis() == null)
				addMessage("boletas.dadesValidades.ContratoSibisInfPrestamo");
			// o Aplicación /Contrato: Si aplicación =’PR’, si longitud (len) de
			// Contrato <> 10, mostrar error: ‘El contrato SIBIS ha de estar
			// informado con 10 digitos para el nº cuenta'
			if ("PR".equalsIgnoreCase(ho.getAplicacionSibis())
					&& ho.getContratoSibis() != null
					&& ho.getContratoSibis().toString().length() != 10)
				addMessage("boletas.dadesValidades.DigitosContratoSibis");
			// o Aplicación /Contrapartida: Si Aplicación null y Contrapartida =
			// ‘FDI’, mostrar error: 'Campos SIBIS obligatorios para
			// contrapartida FDI'
			if (ho.getAplicacionSibis() == null
					&& ho.getContrapartida() != null
					&& "FDI".equalsIgnoreCase(ho.getContrapartida().getId()))
				addMessage("boletas.dadesValidades.SibisObligContrapaFDI");
			// o Ent. Sibis /Aplicación: Si aplicación = null y Contrapartida <>
			// ‘FDI’ y Ent. Sibis <> null, mostrar error: 'Entidad SIBIS no debe
			// estar informada'
			if (ho.getAplicacionSibis() == null
					&& ho.getContrapartida() != null
					&& !"FDI".equalsIgnoreCase(ho.getContrapartida().getId())
					&& ho.getEntidadSibis() != null)
				addMessage("boletas.dadesValidades.EntidadSibisInformada");
			// o Aplicación /Contrato: Si aplicación =null y y Contrapartida <>
			// ‘FDI’ y Contrato <> null, mostrar error: 'Contrato SIBIS no debe
			// estar informado’
			if (ho.getAplicacionSibis() == null
					&& ho.getContrapartida() != null
					&& !"FDI".equalsIgnoreCase(ho.getContrapartida().getId())
					&& ho.getContratoSibis() != null)
				addMessage("boletas.dadesValidades.ContratoSibisInformado");
		}
		if (hasComisionesTab()) {

			// Comisiones
			// o Importe/Broker: Si Importe <> 0 y Broker no informado mostrar
			// error 'El Broker debe estar informado'
			if (ho.getImporteComisionBroker() != null
					&& ho.getImporteComisionBroker().longValue() != 0
					&& ho.getCodigoBroker() == null)
				addMessage("boletas.dadesValidades.BrokerOblig");
			// o Importe/divisa: Si Importe <> 0 y Divisa no informada mostrar
			// error ‘La Divisa debe estar informada'
			if (ho.getImporteComisionBroker() != null
					&& ho.getImporteComisionBroker().longValue() != 0
					&& ho.getDivisaComisionBroker() == null)
				addMessage("boletas.dadesValidades.DivisaOblig");
			// Otros
			// : FLM No hacer. Preguntar o Revisar controles raros sobre
			// BSCAPH?? (F_DADES_VALIDES)

			// SMM 21/02/2018
			// if (GenericUtils.isNullOrBlank(ho.getDivisaCostes()) && (
			// (!GenericUtils.isNullOrBlank(ho.getCostesEntrada()) &&
			// ho.getCostesEntrada().longValue()!=0) ||
			// (!GenericUtils.isNullOrBlank(ho.getCostesSalida()) &&
			// ho.getCostesSalida().longValue()!=0) ||
			// (!GenericUtils.isNullOrBlank(ho.getCostesTransaccionCartera()) &&
			// ho.getCostesTransaccionCartera().longValue()!=0) ||
			// (!GenericUtils.isNullOrBlank(ho.getCostesContinuos()) &&
			// ho.getCostesContinuos().longValue()!=0) ||
			// (!GenericUtils.isNullOrBlank(ho.getComisionRentabilidad()) &&
			// ho.getComisionRentabilidad().longValue()!=0) ||
			// (!GenericUtils.isNullOrBlank(ho.getDiferencialFixing()) &&
			// ho.getDiferencialFixing().longValue()!=0) ||
			// (!GenericUtils.isNullOrBlank(ho.getParticipacionBeneficios()) &&
			// ho.getParticipacionBeneficios().longValue()!=0)
			// )){
			// addMessage("boletas.dadesValidades.DivisaCOblig");
			// }
			//		

		}
		// if (hasMifidTab()){
		// if(( historicoOperacion.getGrupoContable()==null ||
		// !"XX".equals(historicoOperacion.getGrupoContable().getId().getGrupoContable()))
		// && esTipoCoberturaNoIn &&
		// !"FDI".equalsIgnoreCase(historicoOperacion.getContrapartida().getId())&&
		// !"MODELO".equalsIgnoreCase(historicoOperacion.getContrapartida().getId())){
		// if (getTipoClienteMifid()==null && "C".equals(getTipoContr())){
		// int vcontError = 0;
		// if (autorizaOperacion.getTipopers() == null) {
		// vcontError++;
		// //addMessage("boletas.dadesValidades.Mifid.TipopersOblig");
		// }if (autorizaOperacion.getTipoclie() == null) {
		// vcontError++;
		// //addMessage("boletas.dadesValidades.Mifid.TipoclieOblig");
		// }if (autorizaOperacion.getPerfilbs() == null) {
		// vcontError++;
		// //addMessage("boletas.dadesValidades.Mifid.PerfilbsOblig");
		// }if (autorizaOperacion.getTestconv() == null) {
		// vcontError++;
		// //addMessage("boletas.dadesValidades.Mifid.TestconvOblig");
		// }if (GenericUtils.isNullOrBlank(autorizaOperacion.getNombrord())) {
		// vcontError++;
		// //addMessage("boletas.dadesValidades.Mifid.NombreOrdOblig");
		// }if (GenericUtils.isNullOrBlank(autorizaOperacion.getApel1ord())) {
		// vcontError++;
		// //addMessage("boletas.dadesValidades.Mifid.Apellido1Oblig");
		// }if (GenericUtils.isNullOrBlank(autorizaOperacion.getApel2ord())) {
		// vcontError++;
		// //addMessage("boletas.dadesValidades.Mifid.Apellido2Oblig");
		// }if (GenericUtils.isNullOrBlank(autorizaOperacion.getContrord())) {
		// vcontError++;
		// //addMessage("boletas.dadesValidades.Mifid.ContrapartidaOrdOblig");
		// }
		// if (vcontError > 0)
		// addMessage("boletas.dadesValidades.Mifid");
		// }
		// }
		// }
	}

	private void checkSncorrela() {

		if (!GenericUtils.isNullOrBlank(historicoOperacion
				.getIdEnContrapartida())) {
			boletasBo.actualizarSncorrela(historicoOperacion);
		}
	}

	private boolean pendienteComprobarPrimaUpfront(HistoricoOperacion ho) {
		if (!isNull(ho.getDivisaPrimaUpFront())
				&& historicoOperacion.getProductoCatalogo() != null
				&& historicoOperacion.getProductoCatalogo().getProdtrat() != null) {
			return !"S".equals(historicoOperacion.getProductoCatalogo()
					.getProdtrat().getChkopcdiv());
		}
		return false;
	}

	private boolean pendienteComprobarPrimaCancelacion(HistoricoOperacion ho) {
		if (!isNull(ho.getDivisaPrimaCancelacion())
				&& historicoOperacion.getProductoCatalogo() != null
				&& historicoOperacion.getProductoCatalogo().getProdtrat() != null) {
			return !"S".equals(historicoOperacion.getProductoCatalogo()
					.getProdtrat().getChkopcdiv());
		}
		return false;
	}

	/**
	 * FUNCTION F_CLAVE_KONDOR_EXISTE RETURN BOOLEAN IS V_RETURN BOOLEAN :=
	 * FALSE; V_CONT NUMBER; BEGIN IF Num. Ext. IS NOT NULL THEN SELECT COUNT(1)
	 * INTO V_CONT FROM DERI.HISTDERI H WHERE H.DEALTYPE = Dealtype AND
	 * H.DEALNUMB = Num. Ext. AND H.ESTADOCO <> 'AN' AND H.NCORRELA ||
	 * H.FECHAOPE <> Num Oper || F. Contr AND H.FEULTACT = (SELECT max(feultact)
	 * FROM DERI.HISTDERI WHERE NCORRELA =H.NCORRELA AND FECHAOPE=H.FECHAOPE);
	 * IF V_CONT >0 THEN V_RETURN := TRUE; END IF; END IF; RETURN V_RETURN;
	 * EXCEPTION WHEN NO_DATA_FOUND THEN RETURN V_RETURN; END;
	 * 
	 * @return
	 */
	private boolean existeClaveKondor() {
		if (historicoOperacion.getDealNumber() == null) {
			return false;
		}
		String query = "SELECT count(*) FROM HistoricoOperacion ho "
				+ "WHERE ho.dealNumber = :dealNumber "
				+ "AND ho.dealType = :dealType " + "AND ho.estado <> 'AN' "
				+ "AND (ho.id.fechaContratacion <> :fechaContratacion "
				+ "OR ho.id.numeroOperacion <> :numeroOperacion )"
				+ "AND ho.id.fechaModificacion = ("
				+ "SELECT MAX(ho2.id.fechaModificacion) "
				+ "FROM HistoricoOperacion ho2 "
				+ "WHERE ho2.id.fechaContratacion = ho.id.fechaContratacion "
				+ "AND ho2.id.numeroOperacion = ho.id.numeroOperacion	)";
		Long count = (Long) entityManager.createQuery(query).setParameter(
				"dealNumber", historicoOperacion.getDealNumber()).setParameter(
				"dealType", historicoOperacion.getDealType()).setParameter(
				"fechaContratacion",
				historicoOperacion.getId().getFechaContratacion())
				.setParameter("numeroOperacion",
						historicoOperacion.getId().getNumeroOperacion())
				.getSingleResult();

		return count > 0;
	}

	private boolean dadesValidesProd() {
		boolean ret = true;
		HistoricoOpcion historicoOpcion = historicoOperacion
				.getHistoricoOpcion();

		if (historicoOperacion.getProductoCatalogo() == null
				|| historicoOperacion.getProductoCatalogo().getModelpro() == null) {
			addMessage("boletas.error.no.existeproductocatalogo");
			return false;
		}
		if ("OPC".equals(historicoOperacion.getProductoCatalogo().getModelpro()
				.getModelpro())) {
			if (hasDatosOpcionTab()) {
				if (!EntityUtil.checkEntityExists(entityManager,
						historicoOpcion)) {
					addMessage("#{messages['boletas.error.no.existehistoricoopcion']}");
				}
				if (historicoOpcion.getEstiloOpcion() != null
						&& boletasBo.fNumFechasTipo(historicoOperacion, "EJ") == 0L
						&& !hasAttribute(25)) {
					// 'No hay ninguna fecha de ejercicio informada'
					addMessage("#{messages['boletas.error.no.existefechaejercicio']}");
				}
				if (historicoOpcion.getEstiloOpcion() != null
						&& "E".equals(historicoOpcion.getEstiloOpcion()
								.getCodigo())
						&& boletasBo.fNumFechasTipo(historicoOperacion, "EJ") != 1L
						&& !hasAttribute(25)) {
					// ‘Las opciones europeas deben tener una única fecha de
					// ejercicio'
					addMessage("boletas.error.unicafechaejercicio");
				}
				/*
				 * AGM Esta validación ya se hace en dadesValidesParam if
				 * (hasAttribute(34) &&
				 * boletasBo.fNumFechasTipo(historicoOperacion, "PO") == 0L) {
				 * // No hay ninguna fecha de Pay-Off informada'
				 * addMessage("boletas.error.fechapayoff.sininformar"); }
				 */

				if (historicoOpcion.getTipoOpcion() != null
						&& "P".equals(historicoOpcion.getTipoOpcion()
								.getCodigo())
						&& boletasBo.fNumFechasTipo(historicoOperacion, "PO") <= 1L) {
					// ‘Debe informar más fechas de Pay-Off'
					addMessage("boletas.error.fechapayoff.masfechas");
				}
				if ((historicoOpcion.getTipoNivelPrincipal() != null && historicoOpcion
						.getPorcentajeNivelPrincipal() == null)
						|| (historicoOpcion.getTipoNivelPrincipal() == null
								&& historicoOpcion
										.getPorcentajeNivelPrincipal() != null 
						&& BigDecimal.ZERO.compareTo(historicoOpcion.getPorcentajeNivelPrincipal()) != 0 
						)) {
					// 'Incoherencia de los datos para el nivel 1'
					addMessage("boletas.error.nivel1incoherente");
				}
				if ((historicoOpcion.getTipoNivelSecundario() != null && historicoOpcion
						.getPorcentajeNivelSecundario() == null)
						|| (historicoOpcion.getTipoNivelSecundario() == null
								&& historicoOpcion
										.getPorcentajeNivelSecundario() != null 
								&& BigDecimal.ZERO.compareTo(historicoOpcion.getPorcentajeNivelSecundario())!=0 )) {
					// 'Incoherencia de los datos para el nivel 2'
					addMessage("boletas.error.nivel2incoherente");
				}

				List<DescripcionOpcionNivel> listaNivel = listaDescripcionOpcionNivel();

				if ((pagoCobroType == PagoCobroType.ES_COBRO
						&& historicoOperacion.getFormulaRecibo() != null && GenericUtils
						.in(historicoOperacion.getFormulaRecibo()
								.getCodigoFormula(), 1028, 1029, 1030))
						|| (pagoCobroType == PagoCobroType.ES_PAGO
								&& historicoOperacion.getFormulaPago() != null && GenericUtils
								.in(historicoOperacion.getFormulaPago()
										.getCodigoFormula(), 1028, 1029, 1030))) {

					if (!listaNivel.get(0).getCodigo()
							.equalsIgnoreCase(
									historicoOpcion.getTipoNivelPrincipal()
											.getCodigo())
							|| !listaNivel.get(1).getCodigo().equalsIgnoreCase(
									historicoOpcion.getTipoNivelSecundario()
											.getCodigo())) {

						addMessage("boletas.error.nivelmalasignado");

					} else if (historicoOpcion.getPorcentajeNivelPrincipal()
							.compareTo(
									historicoOpcion
											.getPorcentajeNivelSecundario()) < 0) {

						addMessage("boletas.error.nivelmaxmin");

					}

					if ((pagoCobroType == PagoCobroType.ES_COBRO
							&& historicoOperacion.getFormulaRecibo() != null && historicoOperacion
							.getFormulaRecibo().getCodigoFormula().equals(1028))
							|| (pagoCobroType == PagoCobroType.ES_PAGO
									&& historicoOperacion.getFormulaPago() != null && historicoOperacion
									.getFormulaPago().getCodigoFormula()
									.equals(1028))) {

						if ((historicoOperacion.getHistoricoBarreras() != null && historicoOperacion
								.getHistoricoBarreras().size() > 0)
								|| (historicoOperacion.getHistoricoOpcion()
										.getModobarr() != null && !"NA"
										.equals(historicoOperacion
												.getHistoricoOpcion()
												.getModobarr().getCodigo()))) {
							// El Acumulador resurrecting no permite barreras.
							addMessage("boletas.error.acumuladorResurrecting");
						}
					} else {
						// 1029 o 1030
						if (historicoOperacion.getHistoricoBarreras() != null
								&& historicoOperacion.getHistoricoBarreras()
										.size() > 0) {
							for (HistoricoBarrera historicoBarrera : historicoOperacion
									.getHistoricoBarreras()) {

								if (!"DO".equalsIgnoreCase(historicoBarrera
										.getId().getTipbarp1())
										&& !"UO"
												.equalsIgnoreCase(historicoBarrera
														.getId().getTipbarp1())) {

									addMessage("boletas.error.tipobarNovale");

								}

							}
						} else {
							addMessage("boletas.error.Nobarrera");
						}
					}

				}

				String indStrik = "";

				if (pagoCobroType == PagoCobroType.ES_COBRO
						&& historicoOperacion.getFormulaRecibo() != null) {
					indStrik = historicoOperacion.getFormulaRecibo()
							.getIndicadorStrike();
				} else if (pagoCobroType == PagoCobroType.ES_PAGO
						&& historicoOperacion.getFormulaPago() != null) {
					indStrik = historicoOperacion.getFormulaPago()
							.getIndicadorStrike();
				}

				if ("S".equalsIgnoreCase(indStrik)
						&& (historicoOpcion.getTipoStrike() == null || "N"
								.equalsIgnoreCase(historicoOpcion
										.getTipoStrike().getCodigo()))) {
					// ‘Tipo Strike incorrecto’
					addMessage("boletas.error.tipostrikeincorrecto");
				}

				if (!"S".equalsIgnoreCase(indStrik)
						&& (historicoOpcion.getTipoStrike() == null || !"N"
								.equalsIgnoreCase(historicoOpcion
										.getTipoStrike().getCodigo()))) {
					// Tipo Strike incorrecto. Debe ser "No aplica".'
					addMessage("boletas.error.tipostrikeincorrecto2");
				}

			}
		}
		if ("EQU".equals(historicoOperacion.getProductoCatalogo().getModelpro()
				.getModelpro())) {
			if (!historicoOperacion.getDivisaPago().equals(
					historicoOperacion.getDivisaRecibo())) {
				// ‘Las divisas no coinciden'
				addMessage("boletas.error.divisasnocoinciden");
			}
		}

		if (historicoOperacion.getProductoCatalogo().getProdtrat() != null
				&& "S".equalsIgnoreCase(historicoOperacion
						.getProductoCatalogo().getProdtrat().getTratge01())
				&& "IN".equalsIgnoreCase(historicoOperacion.getEstado()
						.getCodigo())
				&& !historicoOperacion.getIndicadorOperacionModelo()
				&& boletasBo.anexoNoFirmado(historicoOperacion
						.getContrapartida().getId())) {
			// ‘La operación no se puede completar si la contrapartida no tiene
			// el anexo firmado'
			addMessage("boletas.error.anexonofirmado");
		}

		return ret;
	}

	private void dadesValidesConfirmaciones() {

		if (hasConfirmacionesTab() && confirmacion != null) {

			if ((confirmacion.getIndicadorConfirmacionAlta() != null
					&& confirmacion.getIndicadorConfirmacionAlta() && (confirmacion
					.getIdiomaConfirmacionAlta() == null || confirmacion
					.getCanelEmisionConfirmacionAlta() == null))
					|| (confirmacion.getIndicadorConfirmacionModificacion() != null
							&& confirmacion
									.getIndicadorConfirmacionModificacion() && (confirmacion
							.getIdiomaConfirmacionModificacion() == null || confirmacion
							.getCanelEmisionConfirmacionModificacion() == null))
					|| (confirmacion.getIndicadorConfirmacionAnulacion() != null
							&& confirmacion.getIndicadorConfirmacionAnulacion() && (confirmacion
							.getIdiomaConfirmacionAnulacion() == null || confirmacion
							.getCanelEmisionConfirmacionAnulacion() == null))
					|| (confirmacion.getIndicadorConfirmacionCancelacion() != null
							&& confirmacion
									.getIndicadorConfirmacionCancelacion() && (confirmacion
							.getIdiomaConfirmacionCancelacion() == null || confirmacion
							.getCanelEmisionConfirmacionCancelacion() == null))
					|| (confirmacion
							.getIndicadorConfirmacionCancelacionParcial() != null
							&& confirmacion
									.getIndicadorConfirmacionCancelacionParcial() && (confirmacion
							.getIdiomaConfirmacionCancelacionParcial() == null || confirmacion
							.getCanelEmisionConfirmacionCancelacionParcial() == null))
					|| (confirmacion.getIndicadorConfirmacionLiquidacion() != null
							&& confirmacion
									.getIndicadorConfirmacionLiquidacion() && (confirmacion
							.getIdiomaConfirmacionLiquidacion() == null || confirmacion
							.getCanelEmisionConfirmacionLiquidacion() == null))
					|| (confirmacion.getIndicadorConfirmacionFijacion() != null
							&& confirmacion.getIndicadorConfirmacionFijacion() && (confirmacion
							.getIdiomaConfirmacionFijacion() == null || confirmacion
							.getCanelEmisionConfirmacionFijacion() == null))) {

				addMessage("boletas.error.confirmacion.enviar");
			}

			if ((confirmacion.getIndicadorRecepcionConfirmacionAlta() != null
					&& confirmacion.getIndicadorRecepcionConfirmacionAlta() && confirmacion
					.getCanelRecepcionConfirmacionAlta() == null)
					|| (confirmacion
							.getIndicadorRecepcionConfirmacionModificacion() != null
							&& confirmacion
									.getIndicadorRecepcionConfirmacionModificacion() && confirmacion
							.getCanelRecepcionConfirmacionModificacion() == null)
					|| (confirmacion
							.getIndicadorRecepcionConfirmacionAnulacion() != null
							&& confirmacion
									.getIndicadorRecepcionConfirmacionAnulacion() && confirmacion
							.getCanelRecepcionConfirmacionAnulacion() == null)
					|| (confirmacion
							.getIndicadorRecepcionConfirmacionCancelacion() != null
							&& confirmacion
									.getIndicadorRecepcionConfirmacionCancelacion() && confirmacion
							.getCanelRecepcionConfirmacionCancelacion() == null)
					|| (confirmacion
							.getIndicadorRecepcionConfirmacionCancelacionParcial() != null
							&& confirmacion
									.getIndicadorRecepcionConfirmacionCancelacionParcial() && confirmacion
							.getCanelRecepcionConfirmacionCancelacionParcial() == null)
					|| (confirmacion
							.getIndicadorRecepcionConfirmacionLiquidacion() != null
							&& confirmacion
									.getIndicadorRecepcionConfirmacionLiquidacion() && confirmacion
							.getCanelRecepcionConfirmacionLiquidacion() == null)
					|| (confirmacion
							.getIndicadorRecepcionConfirmacionFijacion() != null
							&& confirmacion
									.getIndicadorRecepcionConfirmacionFijacion() && confirmacion
							.getCanelRecepcionConfirmacionFijacion() == null)) {

				addMessage("boletas.error.confirmacion.recibir");
			}

			// if (((confirmacion.getIndicadorConfirmacionAlta() !=null &&
			// confirmacion.getIndicadorConfirmacionAlta()
			// && "SW".equals(confirmacion.getCanelEmisionConfirmacionAlta()))
			// ||
			// (confirmacion.getIndicadorConfirmacionModificacion() !=null &&
			// confirmacion.getIndicadorConfirmacionModificacion()
			// &&
			// "SW".equals(confirmacion.getCanelEmisionConfirmacionModificacion())))
			// && historicoOperacion.getProductoCatalogo()!=null &&
			// historicoOperacion.getProductoCatalogo().getProdtrat()!=null &&
			// "S".equals(historicoOperacion.getProductoCatalogo().getProdtrat().getChkopcdiv())){
			//				
			// //Comprobar Barrera
			// if (comprobarBarreraEuropea()){
			// addMessage("boletas.error.confirmacion.enviarfx");
			// }
			// }

			if (!esContrapaCliente()
					&& !opcionConfirmable()
					&& ((confirmacion.getIndicadorConfirmacionAlta() != null
							&& confirmacion.getIndicadorConfirmacionAlta() && "SW"
							.equals(confirmacion
									.getCanelEmisionConfirmacionAlta())) || (confirmacion
							.getIndicadorConfirmacionModificacion() != null
							&& confirmacion
									.getIndicadorConfirmacionModificacion() && "SW"
							.equals(confirmacion
									.getCanelEmisionConfirmacionModificacion())))
					&& historicoOperacion.getProductoCatalogo() != null
					&& historicoOperacion.getProductoCatalogo().getProdtrat() != null
					&& "S".equals(historicoOperacion.getProductoCatalogo()
							.getProdtrat().getChkopcdiv())) {

				addMessage("boletas.dadesValidades.opcionNoConfirmableSwift");
			}

			if (!esContrapaCliente()
					&& opcionConfirmable()
					&& ((confirmacion.getIndicadorConfirmacionAlta() == null
							|| !confirmacion.getIndicadorConfirmacionAlta() || !"SW"
							.equals(confirmacion
									.getCanelEmisionConfirmacionAlta())) || (confirmacion
							.getIndicadorConfirmacionModificacion() == null
							|| !confirmacion
									.getIndicadorConfirmacionModificacion() || !"SW"
							.equals(confirmacion
									.getCanelEmisionConfirmacionModificacion())))
					&& historicoOperacion.getProductoCatalogo() != null
					&& historicoOperacion.getProductoCatalogo().getProdtrat() != null
					&& "S".equals(historicoOperacion.getProductoCatalogo()
							.getProdtrat().getChkopcdiv())) {

				// Solo mostraremso el warning si NO es operacion interna
				if ((historicoOperacion.getGrupoContable() == null || !"XX"
						.equals(historicoOperacion.getGrupoContable().getId()
								.getGrupoContable()))
						&& !EsTipoCoberturaIn()) {

					addWarning("boletas.dadesValidades.opcionConfirmableSwift");
				}
			}

			// Se añadirá una nueva validación en la boleta al pulsar ‘Alta
			// completa’
			// que genere un error/aviso( por prod. Compuestos) si no está
			// activo alguno de los dos check’s
			// de confirmación contratación (Enviar o Recibir).
			if (historicoOperacion.getUltimaAccion() != null
					&& "A".equalsIgnoreCase(historicoOperacion
							.getUltimaAccion().getCodigo())
					&& historicoOperacion.getEstado() != null
					&& "IN".equalsIgnoreCase(historicoOperacion.getEstado()
							.getCodigo())
					&& !mantOperBo.esOperacionInterna(historicoOperacion)) {

				if ((GenericUtils.isNullOrBlank(confirmacion
						.getIndicadorConfirmacionAlta()) || !confirmacion
						.getIndicadorConfirmacionAlta())
						&& (GenericUtils.isNullOrBlank(confirmacion
								.getIndicadorRecepcionConfirmacionAlta()) || !confirmacion
								.getIndicadorRecepcionConfirmacionAlta())) {
					addMessage("boletas.dadesValidades.contratacion");
				}
			}

		}
	}

	// private Boolean esOperacionInterna() {
	// if (historicoOperacion.getContrapartida()!=null &&
	// !"FDI".equalsIgnoreCase(historicoOperacion.getContrapartida().getId()) &&
	// !"MODELO".equalsIgnoreCase(historicoOperacion.getContrapartida().getId())
	// &&
	// (historicoOperacion.getGrupoContable()==null ||
	// (historicoOperacion.getGrupoContable()!=null &&
	// !"XX".equalsIgnoreCase(historicoOperacion.getGrupoContable().getId().getGrupoContable()))
	// )
	// && ( historicoOperacion.getCodigoCobertura() ==null ||
	// ( historicoOperacion.getCodigoCobertura() !=null &&
	// !"IN".equalsIgnoreCase(historicoOperacion.getCodigoCobertura().getCodigo())))
	// ) {
	// return false;
	// }
	// return true;
	// }

	private boolean comprobarBarreraEuropea() {
		Set<HistoricoBarrera> barreras = historicoOperacion
				.getHistoricoBarreras();

		if (barreras == null || barreras.isEmpty() || barreras.size() == 0) {
			return false;
		} else {
			for (HistoricoBarrera historicoBarrera : barreras) {

				if ("E".equalsIgnoreCase(historicoBarrera.getTipobarr())) {
					return true;
				}

			}
			return false;
		}
	}

	/**
	 * Validación datos parametrización del Producto
	 * 
	 * @return Devuelve ‘TRUE’, si está bien o ‘FALSE’ si encuentra algún error.
	 */
	private boolean dadesValidesParam() {
		boolean ret = true;
		Set<HistoricoBarrera> barreras = historicoOperacion
				.getHistoricoBarreras();
		HistoricoOpcion historicoOpcion = historicoOperacion
				.getHistoricoOpcion();

		// FLM: ojo debe ser obligatorio
		// hasAtribute <> obligatorio, usar hasAttributeAndIsObligated
		if (hasAttributeAndIsObligated(11)
				&& historicoOpcion.getModobarr() != null
				&& !"NA".equals(historicoOpcion.getModobarr().getCodigo())
				&& (barreras == null || barreras.isEmpty() || barreras.size() == 0)) {
			// Se debe entrar información de barreras
			addMessage("boletas.error.barrerasnecesarias");
			ret = false;
		} else if (hasAttribute(11)) {

			String tipoBarrera = "";
			// if (pagoCobroType == PagoCobroType.ES_COBRO &&
			// historicoOperacion.getTipoBarreraRecibo() != null) {
			// tipoBarrera =
			// historicoOperacion.getTipoBarreraRecibo().getCodigo();
			// } else if (pagoCobroType == PagoCobroType.ES_PAGO &&
			// historicoOperacion.getTipoBarreraPago() != null) {
			// tipoBarrera =
			// historicoOperacion.getTipoBarreraPago().getCodigo();
			// }
			// else{
			if (historicoOpcion.getModobarr() != null) {
				tipoBarrera = historicoOpcion.getModobarr().getCodigo();
			}
			// }
			if (("DT".equalsIgnoreCase(tipoBarrera) || "DO"
					.equalsIgnoreCase(tipoBarrera))
					&& barreras.size() != 2) {
				// Para el tipo de barrera indicado no existe el número de
				// barreras correcto
				addMessage("boletas.error.barrerasincorrectas");
				ret = false;
			} else if ("SI".equalsIgnoreCase(tipoBarrera)
					&& barreras.size() != 1) {
				// Para el tipo de barrera indicado no existe el número de
				// barreras correcto
				addMessage("boletas.error.barrerasincorrectas");
				ret = false;
				// FLM: change, falta el caso de NA
			} else if (("NA".equalsIgnoreCase(tipoBarrera) || ""
					.equalsIgnoreCase(tipoBarrera))
					&& barreras.size() != 0) {
				// Para el tipo de barrera indicado no existe el número de
				// barreras correcto
				addMessage("boletas.error.barrerasincorrectas");
				ret = false;
			} else if (esOtrasBarreras(tipoBarrera) && barreras.size() < 1) {
				addMessage("boletas.error.barrerasincorrectas");
				ret = false;
			}
		}

		if (hasAttributeAndIsObligated(14)) {
			// Salva validar que exista información en deri.fechcall
			// 'Se deben entrar F. Cancelación’
			if (hayFechasCallables()) {
				addMessage("boletas.error.fechacancelacion");
				// ret = false;
			}
		}

		if (hasAttributeAndIsObligated(18)
				&& !(boletasBo.fNumFechasTipo(historicoOperacion, "RA") > 0)) {
			// 'Se deben entrar F. Rangos’
			addMessage("boletas.error.entrarrangos");
			ret = false;
		}

		if (hasAttributeAndIsObligated(19)) {
			// Salva validar que exista información en deri.histwedd
			// Se debe entrar información de Wedding’
			addMessage("boletas.error.wedding");
			// ret = false;
		}

		if (hasAttributeAndIsObligated(33)
				&& !(boletasBo.fNumFechasTipo(historicoOperacion, "FS") > 0)) {
			// Se deben entrar F. Fij Strike
			addMessage("boletas.error.ffijstrike");
			ret = false;
		}
		if (hasAttributeAndIsObligated(34)
				&& historicoOpcion.getTipoOpcion() != null
				&& !"N".equals(historicoOpcion.getTipoOpcion().getCodigo())
				&& !(boletasBo.fNumFechasTipo(historicoOperacion, "PO") > 0)) {
			// Se deben entrar F. Pay Off
			addMessage("boletas.error.fpayoff");
			ret = false;
		}

		if (historicoOperacion.getProductoCatalogo() != null
				&& historicoOperacion.getProductoCatalogo().getProdtrat() != null
				&& "S".equalsIgnoreCase(historicoOperacion
						.getProductoCatalogo().getProdtrat().getChkequit())
				&& !(boletasBo.fNumFechasTipo(historicoOperacion, "EJ") > 0)
				&& ((!GenericUtils.isNullOrBlank(historicoOperacion
						.getFormulaPago()) && (historicoOperacion
						.getFormulaPago().getCodigoFormula() == 1003 || historicoOperacion
						.getFormulaPago().getCodigoFormula() == 1004)) || (!GenericUtils
						.isNullOrBlank(historicoOperacion.getFormulaRecibo()) && (historicoOperacion
						.getFormulaRecibo().getCodigoFormula() == 1003 || historicoOperacion
						.getFormulaRecibo().getCodigoFormula() == 1004)))) {

			addMessage("boletas.error.fejercicio");
			ret = false;

		}

		if (hasAttributeAndIsObligated(42)
				&& (historicoOpcion.getNumeroOperacionAsociada() == null || historicoOpcion
						.getFechaContratacionAsociada() == null)) {
			// Informar Swaption
			addMessage("boletas.error.swaption");
			ret = false;
		}

		// SMM 03/02/2016 SWAPTION
		if (hasAttributeAndIsObligated(42)
				&& historicoOpcion.getNumeroOperacionAsociada() != null
				&& historicoOpcion.getFechaContratacionAsociada() != null) {
			// Comprobar Swaption Operacion Validada
			OperacionId operSwapId = new OperacionId(historicoOpcion
					.getFechaContratacionAsociada(), historicoOpcion
					.getNumeroOperacionAsociada());
			try {
				Operacion operSwaptionAssoc = entityManager.find(
						Operacion.class, operSwapId);
				if (GenericUtils.isNullOrBlank(operSwaptionAssoc)) {
					addMessage("boletas.error.swaptionError");
					ret = false;
				} else if (GenericUtils.isNullOrBlank(operSwaptionAssoc
						.getEstado())
						|| !"VA"
								.equalsIgnoreCase(operSwaptionAssoc.getEstado())) {
					addMessage("boletas.error.swaptionValidada");
					ret = false;
				}
			} catch (EntityNotFoundException e) {
				addMessage("boletas.error.swaptionError");
				ret = false;
			}
		}

		return ret;
	}

	private boolean esOtrasBarreras(String tipoBarrera) {
		return (!("DT".equalsIgnoreCase(tipoBarrera)
				|| "DO".equalsIgnoreCase(tipoBarrera)
				|| "SI".equalsIgnoreCase(tipoBarrera)
				|| "NA".equalsIgnoreCase(tipoBarrera) || ""
				.equalsIgnoreCase(tipoBarrera)));
	}

	private boolean hayFechasCallables() {
		return boletasBo.hayFechasCallables(historicoOperacion);
	}

	private void compruebaContrapartida(AbstractContrapartida contrapartida) {
		if (contrapartida != null) {
			if (contrapartida.getId() == null) {

			} else {
				if (!entityManager.contains(contrapartida)) {
					contrapartida = contrapartidaBo.cargar(contrapartida
							.getId());
					historicoOperacion.setContrapartida(contrapartida);
				}
			}
		}
	}

	private double equivTipoPlazo(String tipoPlazo) {
		double a = 0;
		if (tipoPlazo.equals("A"))
			return 12;
		else if (tipoPlazo.equals("M"))
			a = 1;
		else if (tipoPlazo.equals("S"))
			a = 0.25;
		else
			a = 0;

		return a;

	}

	// : Finalizar el calendario
	// Funciones del calendario
	public String llamarCalendario() {

		if (historicoOperacion.getFrecuenciaFixingPago() != null) {
			if (historicoOperacion.getFrecuenciaFixingPago() != historicoOperacion
					.getFrecuenciaPago()) {
				double numMesesOperacion = historicoOperacion
						.getFrecuenciaPago().getNumPlazo()
						* equivTipoPlazo(historicoOperacion.getFrecuenciaPago()
								.getUnidad().getCodigo());
				double numMesesFixing = historicoOperacion
						.getFrecuenciaFixingPago().getNumPlazo()
						* equivTipoPlazo(historicoOperacion
								.getFrecuenciaFixingPago().getUnidad()
								.getCodigo());
				if (numMesesFixing % numMesesOperacion != 0) {
					statusMessages
							.addToControl("FrecuenciaFixingPago",
									Severity.ERROR,
									"#{messages['boletas.calendario.pago.periodoFixing.errorMultiplicidad']");
					return null;
				}
			}
		}
		if (historicoOperacion.getFrecuenciaFixingRecibo() != null) {
			if (historicoOperacion.getFrecuenciaFixingRecibo() != historicoOperacion
					.getFrecuenciaRecibo()) {
				double numMesesOperacion = historicoOperacion
						.getFrecuenciaRecibo().getNumPlazo()
						* equivTipoPlazo(historicoOperacion
								.getFrecuenciaRecibo().getUnidad().getCodigo());
				double numMesesFixing = historicoOperacion
						.getFrecuenciaFixingRecibo().getNumPlazo()
						* equivTipoPlazo(historicoOperacion
								.getFrecuenciaFixingRecibo().getUnidad()
								.getCodigo());
				if (numMesesFixing % numMesesOperacion != 0) {
					statusMessages
							.addToControl("FrecuenciaFixingRecibo",
									Severity.ERROR,
									"#{messages['boletas.calendario.recibo.periodoFixing.errorMultiplicidad']");
					return null;
				}
			}
		}
		// Validar si la fecha de vencimiento es festiva
		if (!existeCalendario() && fechaVencimientoFestivo()) {
			messageBoxAction.init(
					"boletas.messageBox.crear.calendario.festivo",
					"boletasAction.llamarCalendarioSiExiste()",
					"boletasAction.onMessageBoxFechaVtoKo()");
			return null;
		} else {
			return llamarCalendarioSiExiste();
		}

	}

	public String llamarCalendarioSiExiste() {
		if (existeCalendario()) {
			// messageBoxAction.init("boletas.messageBox.crear.calendario.siexiste",
			// "boletasAction.llamarCalendarioCrear(true)",
			// "boletasAction.llamarManttram()");
			// return null;
			return llamarManttram();
		} else {
			return llamarCalendarioCrear(false);
		}
	}

	public String llamarManttram() {
		vaciarMsgBox();

		if (!BoletasStates.CONSULTA_BOLETA.equals(this.boletaState)) {
			valoresIniciales = null;
			valoresInicialesOpciones = null;
		}
		return "TO_MANTRAM";
	}

	public String onMessageBoxFechaVtoKo() {
		return null;
	}

	public String llamarCalendarioCrear(boolean hasCalendario) {
		// FLM: VIP, aqui hacemos la llamada al pck de tramos !!
		try {
			String result = boletasBo.crearCalendario(historicoOperacion,
					indicesFxCobroList, indicesFxPagoList);
			if (result != null && result.startsWith("03-")) {
				codigoValidacionErroneo = result.substring(3);
				statusMessages.add(Severity.ERROR,
						"#{messages['boletas.validacion.calendario']}");
				return null;
			}
			if ("00".equals(result) && hasCalendario) {
				/**
				 * Si retorno=’00’ and v_existe_calendario =’S’ Limpiar
				 * T_ACCIONES_TRAMOS_SALIR (199) Grabar matriz
				 * T_ACCIONES_TRAMOS_SALIR (1) Acción , varchar2(2) ‘C’
				 * Codliqui, number(12) null Fetraliq, date null Fecintr, date
				 * null Fecfintr,date null Tipopera, varchar2(2) null Concepto,
				 * varchar2(3) null Tipconce, varchar2(3) null Importes,
				 * number(17,4) null
				 */

				tramosTableComponent.getTramosTableList().clear();
				TramosTable tramoTable = new TramosTable();
				List<TramosTable> tramosTableList = new ArrayList<TramosTable>();
				tramoTable.setAccion("C");
				tramosTableList.add(tramoTable);
				tramosTableComponent.setTramosTableList(tramosTableList);
				//

			}
			if ("01".equals(result)) {
				statusMessages
						.add(Severity.ERROR,
								"#{messages['boletas.alta.completa.error.perdida.historico']}");
			}
			return llamarManttram();
		} catch (BoletasBusinessException e) {
			codigoValidacionErroneo = e.getMessage();
			statusMessages
					.add(Severity.ERROR,
							"#{messages['boletas.alta.completa.error.crear.calendario']}");
			return null;
		}

	}

	private void irAManttram() {
		vaciarMsgBox();
		irManttram = true;
		if (hasDatosOpcionTab()) {
			fijacionPagoCobroType = getDatosOpcionCobroPagoType();
		} else {
			fijacionPagoCobroType = null;
		}
		cargarTramosAction();
	}

	// Llamamos a tramos
	public void llamarCalendarioTramos() {
		tramosTableComponent = new TramosTableComponent();
		;
	}

	public String cargarTramosAction() {

		// FLM : Llamada a calendario VIP
		if (!BoletasStates.CONSULTA_BOLETA.equals(boletaState)) {
			// if (irManttram) {
			// irManttram = false;
			// return llamarManttram();
			// }
			persistir();
			if (tramosTableComponent == null) {
				tramosTableComponent = new TramosTableComponent();
			}
			// tramosTableComponent = new TramosTableComponent();
			return llamarCalendario();
		} else {
			tramosTableComponent = new TramosTableComponent();
			return llamarManttram();
		}
		// return "";
	}

	public void observaciones() {
		persistir();
	}

	public String irInformacionAnexa() {
		persistir();

		modoTratamientoAnexo = boletaState.getCodigo();
		tipoAnexo = Constantes.TIPOANEXO_OPERACION;
		vaciarMsgBox();

		return Constantes.CONSTANTE_SUCCESS;
	}

	public String irMantenimientoCondFijacion() {

		checkTipoCobroPago();

		/*
		 * - Atributos: se protege/desprotege si el producto o producto/fórmula
		 * tienen asociado el atributo 23. - Acción:  Validar que la fórmula
		 * que ha activado el Atributo 23, sólo está en una pata (si es que las
		 * dos están activas).  Validar que se haya informado el indice de la
		 * pata correspondiente, sino mostrar error ‘Ha de informar los índices
		 * de la fórmula’  Si los dos puntos anteriores son correctos: Conectar
		 * con Pantalla ‘Condiciones Fijación’ (MANTSUPU), con los siguientes
		 * datos: • TIPOPERA: ‘P’ o ‘R’, en función de la pata que contiene la
		 * fórmula que ha activado el atributo 23
		 */
		// Calcular TIOPERA

		// pagoCobroType = PagoCobroType.ES_COBRO;
		fijacionPagoCobroType = pagoCobroType;
		if (PagoCobroType.PAGO_Y_COBRO.equals(pagoCobroType)) {
			if (historicoOperacion.getFormulaPago() == null
					&& historicoOperacion.getFormulaRecibo() == null) {
				statusMessages.add(Severity.ERROR,
						"boletas.error.cobrospagos.unaformulaobligatoria");
				return Constantes.CONSTANTE_FAIL;
			}

			// FLM: Esto no puede ser nulo
			if (new Integer(0).equals(historicoOperacion.getFormulaPago())
					&& new Integer(0).equals(historicoOperacion
							.getFormulaRecibo())) {
				statusMessages.add(Severity.ERROR,
						"boletas.error.cobrospagos.unaformulaobligatoria");
				return Constantes.CONSTANTE_FAIL;
			}

			if (historicoOperacion.getFormulaPago() != null
					&& !new Integer(0).equals(historicoOperacion
							.getFormulaPago())
					&& historicoOperacion.getFormulaPago().equals(
							historicoOperacion.getFormulaRecibo())) {
				statusMessages.addFromResourceBundle(Severity.ERROR,
						"boletas.error.cobrospagos.solounaformula");
				return Constantes.CONSTANTE_FAIL;
			}
			boolean tieneFijacionPago = boletasBo
					.esFormulaConCondicionesFijacion(historicoOperacion
							.getProductoCatalogo(), historicoOperacion
							.getFormulaPago());
			boolean tieneFijacionRecibo = boletasBo
					.esFormulaConCondicionesFijacion(historicoOperacion
							.getProductoCatalogo(), historicoOperacion
							.getFormulaRecibo());

			if (!tieneFijacionPago && !tieneFijacionRecibo) {
				statusMessages.addFromResourceBundle(Severity.ERROR,
						"boletas.error.cobrospagos.ningunformulacondfij");
				return Constantes.CONSTANTE_FAIL;
			}

			if (tieneFijacionPago && tieneFijacionRecibo) {
				statusMessages.addFromResourceBundle(Severity.ERROR,
						"boletas.error.cobrospagos.solounaformula");
				return Constantes.CONSTANTE_FAIL;
			}
			// Miramos la misma formula
			if (tieneFijacionPago)
				fijacionPagoCobroType = PagoCobroType.ES_PAGO;
			else
				fijacionPagoCobroType = PagoCobroType.ES_COBRO;
		}
		if (fijacionPagoCobroType == PagoCobroType.ES_PAGO
				&& historicoOperacion.getIndicePago() == null) {
			statusMessages.addFromResourceBundle(Severity.ERROR,
					"boletas.error.condiciones.fijacion.indice.requerido");
			return Constantes.CONSTANTE_FAIL;
		}
		if (fijacionPagoCobroType == PagoCobroType.ES_COBRO
				&& historicoOperacion.getIndiceRecibo() == null) {
			statusMessages.addFromResourceBundle(Severity.ERROR,
					"boletas.error.condiciones.fijacion.indice.requerido");
			return Constantes.CONSTANTE_FAIL;
		}

		if (!existeCalendario()) {
			statusMessages.addFromResourceBundle(Severity.ERROR,
					"boletas.error.condiciones.fijacion.calendario.requerido");
			return Constantes.CONSTANTE_FAIL;
		}

		// Guardamos los tramos para que funcione cond fijación
		persistir();
		vaciarMsgBox();
		return Constantes.CONSTANTE_SUCCESS;
	}

	public String irMantenimientoCondFijacionDatosOpcion() {
		checkTipoCobroPago();
		persistir();
		vaciarMsgBox();
		fijacionPagoCobroType = getDatosOpcionCobroPagoType();
		return Constantes.CONSTANTE_SUCCESS;
	}

	private PagoCobroType getDatosOpcionCobroPagoType() {
		if (esDatosOpcionCobro()) {
			return PagoCobroType.ES_COBRO;
		} else {
			return PagoCobroType.ES_PAGO;
		}
	}

	public String irMantenimientoSubyacentes() {

		// Si no seleccionó el tipo subyacente no le dejamos salir
		if (historicoOperacion.getHistoricoOpcion() == null
				|| historicoOperacion.getHistoricoOpcion().getTipoSubyacente() == null) {
			statusMessages.addFromResourceBundle(Severity.ERROR,
					"historicosubyacente.error.tiposubyacente.obligatorio");
			return Constantes.CONSTANTE_FAIL;
		}
		if (historicoOperacion.getHistoricoOpcion() == null
				|| historicoOperacion.getHistoricoOpcion().getTipoStrike() == null) {
			// log.error("",
			// "historicosubyacente.error.tipostrike.obligatorio");
			statusMessages.addFromResourceBundle(Severity.ERROR,
					"historicosubyacente.error.tipostrike.obligatorio");
			return Constantes.CONSTANTE_FAIL;
		}

		origen = "OP";
		// FLM: Siempre que llamamos a otros mantenimientos persistimos
		persistir();
		vaciarMsgBox();
		return Constantes.CONSTANTE_SUCCESS;
	}

	private void checkTipoCobroPago() {
		pagoCobroType = PagoCobroType.INDEFINIDO;
		if (hasDatosCobrosTab()) {
			if (panelesBloqueados.cobros && panelesBloqueados.pagos) {
				pagoCobroType = PagoCobroType.INDEFINIDO;
			}
			if (!panelesBloqueados.cobros && panelesBloqueados.pagos) {
				pagoCobroType = PagoCobroType.ES_COBRO;
			}
			if (panelesBloqueados.cobros && !panelesBloqueados.pagos) {
				pagoCobroType = PagoCobroType.ES_PAGO;
			}
			if (!panelesBloqueados.cobros && !panelesBloqueados.pagos) {
				pagoCobroType = PagoCobroType.PAGO_Y_COBRO;
			}
		} else {
			if (hasDatosOpcionTab()) {
				if (esDatosOpcionCobro()) {
					pagoCobroType = PagoCobroType.ES_COBRO;
				}
				if (esDatosOpcionPago()) {
					pagoCobroType = PagoCobroType.ES_PAGO;
				}
			} else {
				if (hasSimpleDatosCobrosTab()) {
					if (esCobroTipoB()) {
						pagoCobroType = PagoCobroType.ES_COBRO;
					}
					if (esPagoTipoB()) {
						pagoCobroType = PagoCobroType.ES_PAGO;
					}
				}
			}
		}
		historicoOperacion.setPagoCobroType(pagoCobroType.getCodigo());
	}

	public boolean esContrapaCliente() {

		if (historicoOperacion.getContrapartida() != null
				&& !"FDI".equalsIgnoreCase(historicoOperacion
						.getContrapartida().getId())
				&& !"MODELO".equalsIgnoreCase(historicoOperacion
						.getContrapartida().getId())
				&& (historicoOperacion.getGrupoContable() == null || (historicoOperacion
						.getGrupoContable() != null && !"XX"
						.equalsIgnoreCase(historicoOperacion.getGrupoContable()
								.getId().getGrupoContable())))
				&& (historicoOperacion.getCodigoCobertura() == null || (historicoOperacion
						.getCodigoCobertura() != null && !"IN"
						.equalsIgnoreCase(historicoOperacion
								.getCodigoCobertura().getCodigo())))) {
			if (getTipoContr().equalsIgnoreCase("C")) {
				if (!checkOperacionCAM()) {
					return true;
				}
			}
		}

		return false;
	}

	private boolean checkOperacionCAM() {

		if (historicoOperacion.getContrapartida2() != null
				&& ("CAM-IN".equals(historicoOperacion.getContrapartida2()
						.getId())
						|| "CAM-PV".equals(historicoOperacion
								.getContrapartida2().getId())
						|| "CAM-MIG".equals(historicoOperacion
								.getContrapartida2().getId())
						|| "BMN-IN".equals(historicoOperacion
								.getContrapartida2().getId())
						|| "BMN-PV".equals(historicoOperacion
								.getContrapartida2().getId())
						|| "BMN-MIG".equals(historicoOperacion
								.getContrapartida2().getId())
						|| "LBI-IN".equals(historicoOperacion
								.getContrapartida2().getId())
						|| "LBI-PV".equals(historicoOperacion
								.getContrapartida2().getId())
						|| "LBI-MIG".equals(historicoOperacion
								.getContrapartida2().getId())
						|| "BCG-IN".equals(historicoOperacion
								.getContrapartida2().getId())
						|| "BCG-PV".equals(historicoOperacion
								.getContrapartida2().getId()) || "BCG-MIG"
						.equals(historicoOperacion.getContrapartida2().getId()))) {
			return true;
		}

		return false;

	}

	public String irFechaCallable() {
		// FLM: Siempre que llamamos a otros mantenimientos persistimos
		persistir();
		vaciarMsgBox();
		return Constantes.CONSTANTE_SUCCESS;
	}

	public String irInfoProfit() {
		this.infoProfitPantalla = new InfoProfitPantalla();
		this.infoProfitPantalla.setBdu(historicoOperacion.getClaveExternaBDU());
		return null;
	}

	public String irInfotexto() {
		if (informacionTexto == null) {
			InformacionTextoId informacionTextoId = new InformacionTextoId(
					historicoOperacion.getId().getNumeroOperacion(),
					historicoOperacion.getId().getFechaContratacion());
			try {
				informacionTexto = entityManager.find(InformacionTexto.class,
						informacionTextoId);
			} catch (EntityNotFoundException e) {
				informacionTexto = new InformacionTexto(informacionTextoId);
			}
		}
		// FLM: Siempre que llamamos a otros mantenimientos persistimos
		persistir();
		vaciarMsgBox();
		return Constantes.CONSTANTE_SUCCESS;
	}

	public String irInfotextoKTB() {
		persistir();
		vaciarMsgBox();
		return Constantes.CONSTANTE_SUCCESS;
	}

	public String getOrigen() {
		return origen;
	}

	public void setOrigen(String origen) {
		this.origen = origen;
	}

	/**
	 * • Que se trate de una operación de cliente (Que tenga pestaña de datos
	 * Mifid) • Que esté informado el Global ID • Que esté informada la CLAOPEMX
	 * (Solo las operaciones de Murex tendrán dado de alta el cod autoriza) •
	 * Que falte alguno de los datos de Mifid que nos devuelve el servicio o
	 * Numero de autorización o Indicador de servicio o Indicador de forzado o
	 * Tipo de clienteo Código de autorización o Indicador de tipo (tipo de
	 * cobertura MIFID)
	 * 
	 */
	public boolean botonMIFID() {

		Boolean mifidWS = boletasBo.obtenerMifidWS();

		if (!mifidWS) {
			return false;
		}

		// if
		// (GenericUtils.isNullOrBlank(this.historicoOperacion.getProcedenciaProducto())
		// ||
		// !"K+".equals(this.historicoOperacion.getProcedenciaProducto().getProceden())){
		// //Deshabilitado
		// return true;
		// }
		//	
		if (!hasMifidTab()) {
			// Deshabilitado
			return false;
		}

		if (GenericUtils.isNullOrBlank(this.historicoOperacion
				.getClaveExternaBDU())) {
			return false;
		}

		if (!GenericUtils.isNullOrBlank(autorizaOperacion.getNumautor())
				&& !GenericUtils.isNullOrBlank(autorizaOperacion.getIndiserv())
				&& !GenericUtils
						.isNullOrBlank(autorizaOperacion.getIndiforza())
				&& !GenericUtils.isNullOrBlank(autorizaOperacion.getTipoclie())
				&& !GenericUtils.isNullOrBlank(autorizaOperacion.getInditipo())) {
			return false;
		}

		return true;
	}

	private String getTicket() {
		Assertion assertion = AssertionHolder.getAssertion();
		java.security.Principal principal = assertion.getPrincipal();

		Field[] fields = principal.getClass().getDeclaredFields();
		System.out.println("obtener el proxyGrantingTicket!!!!: ");
		for (Field field : fields) {
			if (field.getName().equals("proxyGrantingTicket")) {
				field.setAccessible(true);
				try {
					String res = (String) field.get(principal);
					System.out.println("proxyGrantingTicket del CAS!!!!: "
							+ res);
					return res;
				} catch (IllegalArgumentException e) {
					e.printStackTrace();
				} catch (IllegalAccessException e) {
					e.printStackTrace();
				}
			}
		}
		return "";
	}

	public String getProxyGrantingTicket() {
		return proxyGrantingTicket;
	}

	public void setProxyGrantingTicket(String proxyGrantingTicket) {
		this.proxyGrantingTicket = proxyGrantingTicket;
	}

	/*
	 * public void obtenerSessionId(){
	 * 
	 * try { //login en el webservice con el usuario de sesión de DERI
	 * com.bs.proteo.soa.service.mainframe.UserLogin.domain.InputData inputData
	 * = new com.bs.proteo.soa.service.mainframe.UserLogin.domain.InputData();
	 * //setusername y password
	 * firmaDigital.setUsername(Identity.instance().getCredentials
	 * ().getUsername());
	 * System.out.println("username: "+Identity.instance().getCredentials
	 * ().getUsername()); String proxyGrantingTicket = getTicket();
	 * System.out.println("proxyGrantingTicket=-"+proxyGrantingTicket+"-");
	 * String grantServiceTicket =
	 * firmaDigital.getServiceTicket(proxyGrantingTicket);
	 * System.out.println("grantServiceTicket=-"+grantServiceTicket+"-");
	 * 
	 * String sessionValida;
	 * 
	 * 
	 * 
	 * 
	 * sessionValida = mifidWS.loginOB(ConstantesFD.MIFID_PROCEDENCIA,
	 * grantServiceTicket).getHeader().getSessionId();
	 * 
	 * sessionId = sessionValida;
	 * System.out.println("sessionValida=-"+sessionValida+"-");
	 * 
	 * } catch (Exception e) {
	 * System.out.println("sessionValida=-Con profit res");
	 * 
	 * // try { // //login en el webservice con el usuario de sesión de DERI //
	 * com.bs.proteo.soa.service.mainframe.UserLogin.domain.InputData inputData
	 * = new com.bs.proteo.soa.service.mainframe.UserLogin.domain.InputData();
	 * // //setusername y password //
	 * firmaDigital.setUsername(Identity.instance(
	 * ).getCredentials().getUsername()); //
	 * System.out.println("username: "+Identity
	 * .instance().getCredentials().getUsername()); // String
	 * proxyGrantingTicket = getTicket(); //
	 * System.out.println("proxyGrantingTicket=-"+proxyGrantingTicket+"-"); //
	 * String grantServiceTicket =
	 * firmaDigital.getServiceTicket(proxyGrantingTicket); //
	 * System.out.println("grantServiceTicket=-"+grantServiceTicket+"-"); // //
	 * String sessionValida; // // sessionValida = mifidWS.loginOB("DERI",
	 * grantServiceTicket).getHeader().getSessionId(); // // sessionId =
	 * sessionValida; //
	 * System.out.println("sessionValida=-"+sessionValida+"-"); // // } catch
	 * (Exception f) { // System.out.println("sessionValida=-Con DERI tampoco");
	 * // f.printStackTrace(); // } // // TODO Auto-generated catch block
	 * e.printStackTrace(); }
	 * 
	 * }
	 */

	private String convertirEntidad(String entidad) {

		if ("81".equals(GenericUtils.lpad(entidad, 2, "0"))) {
			return "01";
		} else if ("42".equals(GenericUtils.lpad(entidad, 2, "0"))) {
			return "BG";
		} else {
			return "05";
		}

	}

	/*
	 * public void obtenerAutorizacionMIFID(Boolean boletas){
	 * 
	 * 
	 * Contrapartida contrapa= null; String indicadorForzada= null; String
	 * resmot= null; String codsegper=null; String familia = null; String
	 * contrato= null;
	 * 
	 * 
	 * // Obtenemos cada vez la session obtenerSessionId();
	 * 
	 * // //Eliminar si no permitimos en caso de emergencia realizar un login
	 * anonimo. // if (GenericUtils.isNullOrBlank(sessionId)){ // //
	 * System.out.println("PEITCION PROFIT NULL : ANONYMOUS PASO"); // try { //
	 * StartResponse response =
	 * mifidWS.autorizacionTest(ConstantesFD.MIFID_PROCEDENCIA,null); //
	 * sessionId=response.getHeader().getSessionId(); //
	 * System.out.println("response DERI: " +
	 * response.getHeader().getSessionId()); // } catch (Exception e) { // //
	 * TODO Auto-generated catch block // e.printStackTrace(); // } // }
	 * 
	 * System.out.println("sessionValida=-"+sessionId+"-");
	 * 
	 * if (GenericUtils.isNullOrBlank(sessionId)){ if (boletas){
	 * addWarning("boletas.Mifid.errorSesion"); }else{
	 * statusMessages.addFromResourceBundle(Severity.WARN ,
	 * "boletas.Mifid.errorSesion"); } return; }
	 * 
	 * try {
	 * 
	 * 
	 * if ( autorizaOperacion!=null && autorizaOperacion.getInditipo()!=null &&
	 * "CO".equals(autorizaOperacion.getInditipo().getCodigo())){ familia =
	 * "OCC"; }else{ familia = "OTC"; } contrapa =
	 * obtenerContrapaBase(historicoOperacion.getContrapartida());
	 * 
	 * if (GenericUtils.isNullOrBlank(contrapa)){ if (boletas){
	 * addWarning("boletas.Mifid.errorContrapa"); }else{
	 * statusMessages.addFromResourceBundle(Severity.WARN ,
	 * "boletas.Mifid.errorContrapa"); } return; }
	 * 
	 * MIFIDKnowledgeQueryInputResponse resposta =
	 * mifidWS.knowledgeQuery(ConstantesFD.MIFID_PROCEDENCIA,sessionId, "",
	 * convertirEntidad(historicoOperacion.getEntidad().getCodigo()), familia,
	 * contrapa.getNumeroPersona().toString()); if
	 * (!GenericUtils.isNullOrBlank(resposta)){
	 * 
	 * System.out.println("CONSULTA Forsazada: " +
	 * resposta.getData().getIndforzada());
	 * System.out.println("CONSULTA getCodsegper: " +
	 * resposta.getData().getCodsegper());
	 * System.out.println("CONSULTA getIndcontexc: " +
	 * resposta.getData().getIndcontexc());
	 * System.out.println("CONSULTA getIndbancap: " +
	 * resposta.getData().getIndbancap());
	 * System.out.println("CONSULTA Indoperativ: " +
	 * resposta.getData().getIndoperativ());
	 * System.out.println("CONSULTA getIndsegprev: " +
	 * resposta.getData().getIndsegprev());
	 * System.out.println("CONSULTA getResmot: " +
	 * resposta.getData().getResmot());
	 * System.out.println("CONSULTA getTipotest: " +
	 * resposta.getData().getTipotest()); //
	 * System.out.println("CONSULTA TODO: " + resposta.getData().toString());
	 * resmot = resposta.getData().getResmot(); codsegper =
	 * resposta.getData().getCodsegper(); indicadorForzada =
	 * resposta.getData().getIndforzada();
	 * 
	 * } } catch (Exception e) { e.printStackTrace();
	 * boletasBo.saveResultadoToLog(ConstantesFD.MIFID_UNKNOWN_ERROR,
	 * e.getMessage(), historicoOperacion, ConstantesFD.MIFID_WS_QUERYKNOW,
	 * ConstantesFD.MIFID_LOG_ESTADOCO_KO); if (boletas){
	 * addWarning("boletas.Mifid.errorQuery"); }else{
	 * statusMessages.add(Severity.WARN , e.getMessage()); } return; }
	 * 
	 * //Sino hay error habrá ido bien
	 * boletasBo.saveResultadoToLog(ConstantesFD.MIFID_QRY_OK, null,
	 * historicoOperacion, ConstantesFD.MIFID_WS_QUERYKNOW,
	 * ConstantesFD.MIFID_LOG_ESTADOCO_OK);
	 * 
	 * try{
	 * 
	 * contrato= obtenerContrato(contrapa); MovilMIFIDTestInputResponse
	 * respostaMifid = null; if (!GenericUtils.isNullOrBlank(contrato)){
	 * 
	 * StartResponse response =
	 * mifidWS.autorizacionTest(ConstantesFD.MIFID_PROCEDENCIA,null);
	 * System.out.println("response DERI: " +
	 * response.getHeader().getSessionId());
	 * 
	 * System.out.println("MIFID PROCEDENCIA: " +
	 * ConstantesFD.MIFID_PROCEDENCIA); System.out.println("MIFID sessionId: " +
	 * sessionId); System.out.println("MIFID contrato: " + contrato);
	 * System.out.println("MIFID entidad: " +
	 * convertirEntidad(historicoOperacion.getEntidad().getCodigo()));
	 * System.out.println("MIFID familia: " + familia);
	 * System.out.println("MIFID indicadorForzada: " + indicadorForzada);
	 * System.out.println("MIFID NUMPERSO: " +
	 * contrapa.getNumeroPersona().toString()); System.out.println("MIFID BDU: "
	 * + historicoOperacion.getClaveExternaBDU());
	 * 
	 * respostaMifid =
	 * mifidWS.movilMIFIDTestInput(ConstantesFD.MIFID_PROCEDENCIA
	 * ,sessionId,null,contrato,
	 * convertirEntidad(historicoOperacion.getEntidad().getCodigo()),
	 * familia,indicadorForzada
	 * ,contrapa.getNumeroPersona().toString(),historicoOperacion
	 * .getClaveExternaBDU());
	 * 
	 * if (!"0".equals(respostaMifid.getData().getCodigoRetorno())){
	 * boletasBo.saveResultadoToLog(ConstantesFD.MIFID_MF_UNKNOWN_ERROR,
	 * respostaMifid.getData().getCodigoRetorno(), historicoOperacion,
	 * ConstantesFD.MIFID_WS_MOVILMIFID, ConstantesFD.MIFID_LOG_ESTADOCO_KO);
	 * statusMessages.addFromResourceBundle(Severity.WARN ,
	 * "boletas.Mifid.errorAutorizacion"); }
	 * 
	 * }else{ if (boletas){ addWarning("boletas.Mifid.sincontrato"); }else{
	 * statusMessages.addFromResourceBundle(Severity.WARN ,
	 * "boletas.Mifid.sincontrato"); }
	 * 
	 * boletasBo.saveResultadoToLog(ConstantesFD.MIFID_MF_CONTRATO_ERROR,
	 * ConstantesFD.MIFID_CONTRATO_ERROR , historicoOperacion,
	 * ConstantesFD.MIFID_WS_MOVILMIFID, ConstantesFD.MIFID_LOG_ESTADOCO_KO); }
	 * 
	 * if (!GenericUtils.isNullOrBlank(respostaMifid)){
	 * System.out.println("CONSULTA Codigo Retorno: " +
	 * respostaMifid.getData().getCodigoRetorno());
	 * System.out.println("CONSULTA Motivo Autorizacion: " +
	 * respostaMifid.getData().getMotivoAutorizacion());
	 * System.out.println("CONSULTA Num Autorizacion: " +
	 * respostaMifid.getData().getNumAutorizacion());
	 * System.out.println("CONSULTA Tipo Autorizacion: " +
	 * respostaMifid.getData().getTipoAutorizacion());
	 * System.out.println("CONSULTA CodigoSegmentoClienteMifid: " +
	 * respostaMifid.getData().getCodigoSegmentoClienteMifid());
	 * System.out.println("CONSULTA Complejidad: " +
	 * respostaMifid.getData().getComplejidad());
	 * System.out.println("CONSULTA Familia Mifid: " +
	 * respostaMifid.getData().getFamiliaMifid());
	 * System.out.println("CONSULTA NumSolicitud: " +
	 * respostaMifid.getData().getNumSolicitud());
	 * System.out.println("CONSULTA Riesgo: " +
	 * respostaMifid.getData().getRiesgo()); //
	 * System.out.println("CONSULTA typedesc: " +
	 * respostaMifid.getData().getTypeDesc().toString());
	 * 
	 * 
	 * if (autorizaOperacion!=null){
	 * 
	 * autorizaOperacion.setNumautor(Long.valueOf(respostaMifid.getData().
	 * getNumAutorizacion()));
	 * autorizaOperacion.setNumsolic(Long.valueOf(respostaMifid
	 * .getData().getNumSolicitud())); autorizaOperacion.setIndenvio(true);
	 * autorizaOperacion.setContrapa(contrapa.getId());
	 * autorizaOperacion.setDealnumb(historicoOperacion.getDealNumber());
	 * autorizaOperacion.setDealtype(historicoOperacion.getDealType());
	 * autorizaOperacion.setProdcomp("S"); autorizaOperacion.setFechalta(new
	 * Date()); autorizaOperacion.setFecharec(new Date());
	 * autorizaOperacion.setCodautor(resmot);
	 * 
	 * autorizaOperacion.setIndiserv(obtenerDescripcionAutorizaIndiserv(
	 * respostaMifid.getData().getTipoAutorizacion()));
	 * autorizaOperacion.setTipoclie
	 * (obtenerDescripcionAutorizaTipoCliente(codsegper));
	 * autorizaOperacion.setIndiforza
	 * (obtenerDescripcionAutorizaIndiforza(indicadorForzada));
	 * //autorizaOperacion
	 * .setCodautor(respostaMifid.getData().getMotivoAutorizacion());
	 * 
	 * 
	 * } }
	 * 
	 * } catch (Exception e) { // TODO Auto-generated catch block
	 * e.printStackTrace();
	 * boletasBo.saveResultadoToLog(ConstantesFD.MIFID_MF_UNKNOWN_ERROR,
	 * e.getMessage(), historicoOperacion, ConstantesFD.MIFID_WS_MOVILMIFID,
	 * ConstantesFD.MIFID_LOG_ESTADOCO_KO); if (boletas){
	 * addWarning("boletas.Mifid.errorAutor"); }else{
	 * statusMessages.add(Severity.WARN , e.getMessage()); } return;
	 * 
	 * } }
	 */

	public DescripcionAutorizaIndiserv obtenerDescripcionAutorizaIndiserv(
			String codigo) {
		DescripcionAutorizaIndiserv indiserv;
		try {
			if ("SE".equalsIgnoreCase(codigo)) {
				indiserv = (DescripcionAutorizaIndiserv) entityManager
						.createQuery(
								"from DescripcionAutorizaIndiserv where codigo='EJ'")
						.getSingleResult();
				return indiserv;
			} else {
				indiserv = (DescripcionAutorizaIndiserv) entityManager
						.createQuery(
								"from DescripcionAutorizaIndiserv where codigo='"
										+ codigo + "'").getSingleResult();
				return indiserv;
			}
		} catch (Exception e) {
			System.out
					.println("DescripcionAutorizaIndiserv: " + e.getMessage());
			return null;
		}

	}

	public DescripcionAutorizaIndiforza obtenerDescripcionAutorizaIndiforza(
			String codigo) {
		try {
			DescripcionAutorizaIndiforza indi = (DescripcionAutorizaIndiforza) entityManager
					.createQuery(
							"from DescripcionAutorizaIndiforza where codigo='"
									+ codigo + "'").getSingleResult();
			return indi;
		} catch (Exception e) {
			System.out.println("DescripcionAutorizaIndiforza: "
					+ e.getMessage());
			return null;
		}

	}

	public DescripcionAutorizaTipoCliente obtenerDescripcionAutorizaTipoCliente(
			String codsegper) {
		// TIPOCLIE En función de CODSEGPER de MIFID:
		// - M  MN - Minorista
		// - P  PF - Profesional
		// - C  CT - Contraparte

		DescripcionAutorizaTipoCliente tipoCliente;

		try {
			if ("M".equalsIgnoreCase(codsegper)) {
				tipoCliente = (DescripcionAutorizaTipoCliente) entityManager
						.createQuery(
								"from DescripcionAutorizaTipoCliente where codigo='MN'")
						.getSingleResult();
				return tipoCliente;
			} else if ("P".equalsIgnoreCase(codsegper)) {
				tipoCliente = (DescripcionAutorizaTipoCliente) entityManager
						.createQuery(
								"from DescripcionAutorizaTipoCliente where codigo='PF'")
						.getSingleResult();
				return tipoCliente;
			} else if ("C".equalsIgnoreCase(codsegper)) {
				tipoCliente = (DescripcionAutorizaTipoCliente) entityManager
						.createQuery(
								"from DescripcionAutorizaTipoCliente where codigo='CT'")
						.getSingleResult();
				return tipoCliente;
			} else {
				return null;
			}
		} catch (Exception e) {
			System.out.println("DescripcionAutorizaTipoCliente: "
					+ e.getMessage());
			return null;
		}
	}

	public String obtenerContrato(Contrapartida contrapa) {
		String contrato = null;

		if (Constantes.CONTRAPA_GRUPOBAN_CLIENTE.equals(contrapa
				.getGrupoBancario().getId())) {
			contrato = boletasBo.obtenerContratoContrapartidaEntidad(contrapa
					.getId(), historicoOperacion.getEntidad().getCodigo());
			if (!GenericUtils.isNullOrBlank(contrato)) {
				contrato = contrato.substring(0, contrato.indexOf("-"));
				contrato = "000000000000000".substring(contrato.length())
						+ contrato;
				contrato = convertirEntidad(
						historicoOperacion.getEntidad().getCodigo()).concat(
						ConstantesFD.MIFID_TIPOPRODUCTO).concat(contrato);
			}

		} else {
			contrato = historicoOperacion.getId().getNumeroOperacion()
					.toString();
			contrato = "000000000000000".substring(contrato.length())
					+ contrato;
			contrato = convertirEntidad(
					historicoOperacion.getEntidad().getCodigo()).concat(
					ConstantesFD.MIFID_TIPOPRODUCTO).concat(contrato);
		}

		return contrato;

	}

	public Contrapartida obtenerContrapaBase(Object contrapartida) {
		AbstractContrapartida aContrapa = entityUtil.unwrapProxy(contrapartida,
				AbstractContrapartida.class);
		Contrapartida contrapa = null;
		if (!(aContrapa instanceof Contrapartida)) {
			return null;
		}
		contrapa = (Contrapartida) aContrapa;
		return contrapa;
	}

	// FLM: VIP, al retornar de subyacentes debemos ejecutar unos procesos !!!
	public void retornarSubyacentes() {
		/*
		 *  Al volver,  si Check Cesta = ‘N’ • llamar a procedure
		 * P_CARGAR_STRIKE_OPCION • Si producto/formula tienen activo el
		 * atributo 25, llamar a procedure P_MODIFICA_STRIKE_TRAMO  Sino (check
		 * cesta <> ‘N’), limpiar (poner al null) Ref. Inicial, Strike y %
		 */
		// :(Done) ACtualizar strike con los datos de los subyacentes
		if (!this.historicoOperacion.getHistoricoOpcion().getIndicadorCesta()) {
			// P_CARGAR_STRIKE_OPCION;
			HistoricoSubyacente Primerhisto = null;
			for (HistoricoSubyacente histo : historicoOperacion
					.getHistoricoSubyacentes()) {
				if ("OP".equals(histo.getId().getTiposuby())) {
					Primerhisto = histo;
					break;
				}
			}
			if (Primerhisto == null) {
				historicoOperacion.getHistoricoOpcion().setReferenciaInicial(
						null);
				historicoOperacion.getHistoricoOpcion().setPorcentajeInicial(
						null);
				datosOpcionDelegate.setStrike(null);
			} else {
				historicoOperacion.getHistoricoOpcion().setReferenciaInicial(
						Primerhisto.getPrecioInicialSubyacente());
				historicoOperacion.getHistoricoOpcion().setPorcentajeInicial(
						Primerhisto.getPorcentajeInicial());
				datosOpcionDelegate
						.setStrike(Primerhisto.getStrikeSubyacente());
			}
			if (!isDisabled("25")) {
				// P_MODIFICA_STRIKE_TRAMO;
				HistoricoTramos histoTram = null;
				for (HistoricoTramos histo : historicoOperacion
						.getHistoricoTramoses()) {
					if ("INT".equals(histo.getId().getConcepto())
							&& "INT".equals(histo.getId().getTipoConcepto())
							&& EsFormula(histo)) {
						// Modificamos el strike
						histo.setStrikeCFC(datosOpcionDelegate.getStrike());
						histoTram = histo;
						break;
					}
				}
				// FLM: Guardamos los cambios realizados
				entityManager.flush();

			}
		} else {
			historicoOperacion.getHistoricoOpcion().setReferenciaInicial(null);
			historicoOperacion.getHistoricoOpcion().setPorcentajeInicial(null);
			// Mejor el inferior
			// historicoOperacion.getHistoricoOpcion().setStrikeOpcion(null) ;
			datosOpcionDelegate.setStrike(null);
		}
	}

	private boolean EsFormula(HistoricoTramos histoTram) {
		if (formulaDatosOpcion.getValue() != null)
			return formulaDatosOpcion.getValue().equals(
					histoTram.getCodigoFormula());
		else
			return histoTram.getCodigoFormula() == null;
	}

	public String prepareMantWedding() {
		// FLM: Siempre que llamamos a otros mantenimientos persistimos
		//  Si F Vto = null, mostrar error ‘Es necesario informar previamente
		// la fecha de vencimiento’
		if (historicoOperacion.getFechaVencimiento() == null) {
			statusMessages.addFromResourceBundle(Severity.ERROR,
					"boletas.error.fechavencimiento.obligatorio");
			return Constantes.FAIL;
		}
		persistir();
		// • OPCION: Si deri.histopci.estadopc = ‘I’ y deri.histopci.fechaexp <>
		// null poner valor ‘C’, sino modoactua
		// if ( "I".equals( historicoOperacion.getHistoricoOpcion().getEstado()
		// ) && historicoOperacion.getHistoricoOpcion().getFechaExpiracion() !=
		// null ) {
		// //Debemos llamar a Wedding en consulta !!!
		// boletaStateWedd=BoletasStates.CONSULTA_BOLETA;
		// } else
		boletaStateWedd = boletaState;

		vaciarMsgBox();

		return Constantes.CONSTANTE_SUCCESS;
	}

	private void vaciarMsgBox() {
		if (errorMessageBoxAction != null) {
			errorMessageBoxAction.setReRender(null);
			errorMessageBoxAction.setOnComplete(null);
		}
	}

	public String prepareSwaption() {
		return Constantes.CONSTANTE_SUCCESS;
	}

	public String prepareBarreras() {
		// : Debemos poner el codigo de antes de la llamada
		/*
		 *  Si Tipo Barr no está informado o está con ‘NA’ mostrar mensaje
		 * ‘Debe seleccionar el tipo de Barrera’  Si no se han informado
		 * Subyacentes mostrar mensaje ‘Se debe informar Subyacente’
		 */
		if (!BoletasStates.CONSULTA_BOLETA.equals(boletaState)) {

			if (historicoOperacion.getHistoricoOpcion().getModobarr() == null
					|| "NA".equalsIgnoreCase(historicoOperacion
							.getHistoricoOpcion().getModobarr().getCodigo())) {
				addMessage("boletas.error.tipobarrera.requerido");
				return Constantes.FAIL;
			}
			if (historicoOperacion.getHistoricoSubyacentes() == null
					|| historicoOperacion.getHistoricoSubyacentes().size() == 0) {
				addMessage("boletas.error.subyacentesbarrera.requerido");
				return Constantes.FAIL;
			}
		}
		vaciarMsgBox();
		return Constantes.CONSTANTE_SUCCESS;
	}

	public String prepareMantdata(String tipoFecha) {

		if (historicoOperacion.getFechaVencimiento() != null) {
			Ajustes indicadorAjuste = datosOpcionDelegate.getIndicadorAjuste();
			Date fechaVenhab = boletasBo.ajustarFecha(historicoOperacion
					.getFechaVencimiento(),
					indicadorAjuste != null ? indicadorAjuste.getCode() : null,
					datosOpcionDelegate.getDivisa());

			String tipoFechasObservacion = null;
			if ("FO".equalsIgnoreCase(tipoFecha)) {
				DescripcionFormula descFormula = formulaDatosOpcion.getValue();
				if (descFormula != null) {
					tipoFechasObservacion = descFormula
							.getTipoFechasObservacion();
				}
			}

			String opcion = null;
			HistoricoOpcion historicoOpcion = historicoOperacion
					.getHistoricoOpcion();
			if (historicoOpcion != null) {
				// if ("I".equalsIgnoreCase(historicoOpcion.getEstado()) &&
				// historicoOpcion.getFechaExpiracion() != null) {
				// opcion = "C";
				// } else {
				DescripcionSituacion ultimaAccion = historicoOperacion
						.getUltimaAccion();
				if (ultimaAccion != null) {
					opcion = ultimaAccion.getCodigo();
				}
				// }
			}

			parametrosMantdata = new ParametrosMantdata(tipoFecha, formatUtil
					.getFormattedDate(fechaVenhab), tipoFechasObservacion,
					opcion, formulaDatosOpcion.getValue());
			// FLM: Siempre que llamamos a otros mantenimientos persistimos
			persistir();
			vaciarMsgBox();
			return Constantes.CONSTANTE_SUCCESS;
		} else {
			statusMessages.addFromResourceBundle(Severity.ERROR,
					"boletas.error.fechavencimiento.obligatorio");
			return Constantes.FAIL;
		}
	}

	public PropertyWrapper<DescripcionEstiloOpcion> getEstiloOpcion() {
		return estiloOpcion;
	}

	public void setEstiloOpcion(
			PropertyWrapper<DescripcionEstiloOpcion> estiloOpcion) {
		this.estiloOpcion = estiloOpcion;
	}

	public Boolean getForceValidation() {
		return forceValidation;
	}

	public void setForceValidation(Boolean forceValidation) {
		this.forceValidation = forceValidation;
	}

	public BoletasStates getBoletaState() {
		return boletaState;
	}

	public void setBoletaState(BoletasStates boletaState) {
		this.boletaState = boletaState;
	}

	public boolean isIrManttram() {
		return irManttram;
	}

	public void setIrManttram(boolean irManttram) {
		this.irManttram = irManttram;
	}

	public String getCobrosPagosSimpleTitle() {
		if (esCobroTipoB()) {
			return Messages.instance().get(
					"boletas.pestanas.cobrosPagos.cobro.titulo");
		}
		if (esPagoTipoB()) {
			return Messages.instance().get(
					"boletas.pestanas.cobrosPagos.pago.titulo");
		}
		return "";
	}

	public void preCargarSubyacentePopup() {
		// filtroSubyacente = "";
		// initListaSubyacentes();
		// suyacentePopupAction.buscar();
		// initListaSubyacentes();
		// Expressions.instance().createMethodExpression("#{" +
		// "suyacentePopupAction"+ ".setInitialized(true)}").invoke();
		// if ("".equalsIgnoreCase(action)) initListaSubyacentes();
		// Expressions.instance().createMethodExpression("#{" +
		// "suyacentePopupAction"+ ".buscar()}").invoke();
	}

	public boolean isCapContingente() {
		return (GenericUtils.nvl(historicoOperacion.getProductoCatalogo()
				.getProdtrat().getTratge03(), "N").equals("S"));
	}

	public String etiquetaPrimaUpFront() {
		if (GenericUtils.nvl(
				historicoOperacion.getProductoCatalogo().getProdtrat()
						.getTratge03(), "N").equals("S"))
			return Messages.instance().get(
					"boletas.pestanas.primas.contingente");
		else
			return Messages.instance().get("boletas.pestanas.primas.upFront");
	}

	public boolean hasAtribSentidoFlujo() {
		return (hasAttribute(21) || hasAttribute(22) || hasAttribute(36) || hasAttribute(37));
	}

	public PropertyWrapper<Short> getCodigoOficinaMargen() {
		return codigoOficinaMargen;
	}

	public void setCodigoOficinaMargen(
			PropertyWrapper<Short> codigoOficinaMargen) {
		this.codigoOficinaMargen = codigoOficinaMargen;
	}

	/**
	 * Estará habilitado para los productos que tengan parametrizado el atributo
	 * 44 – Break Clauses. En modificaciones o consultas se activa el check si
	 * la operación tiene registros en la histparm con tipofech = BC.
	 * 
	 * @return
	 */
	public Boolean getIndicadorBreakClauses() {
		// select * from deri.relproat where codiatri =44
		try {
			return boletasBo.getIndicadorBreakClauses(historicoOperacion);
		} catch (Exception e) {
			return false;
		}
	}

	public void onBreakClausesChange() {
		// si marcado activar botón!
		if (checkBreakClauses) {
			enableBreakClauses = true;
		} else {
			enableBreakClauses = false;
		}
	}

	public String irBreakClauses() {
		persistir();
		vaciarMsgBox();
		return Constantes.CONSTANTE_SUCCESS;
	}

	public Boolean getEnableBreakClauses() {
		return enableBreakClauses;
	}

	public void setEnableBreakClauses(Boolean enableBreakClauses) {
		this.enableBreakClauses = enableBreakClauses;
	}

	public Boolean getCheckBreakClauses() {
		return checkBreakClauses;
	}

	public void setCheckBreakClauses(Boolean checkBreakClauses) {
		this.checkBreakClauses = checkBreakClauses;
	}

	public MantOperBo getMantOperBo() {
		return mantOperBo;
	}

	public void setMantOperBo(MantOperBo mantOperBo) {
		this.mantOperBo = mantOperBo;
	}

	public String getSessionId() {
		return sessionId;
	}

	public void setSessionId(String sessionId) {
		this.sessionId = sessionId;
	}

	public InfoProfitPantalla getInfoProfitPantalla() {
		return infoProfitPantalla;
	}

	public void setInfoProfitPantalla(InfoProfitPantalla infoProfitPantalla) {
		this.infoProfitPantalla = infoProfitPantalla;
	}

	public Boolean isInfoProfitActivado() {
		return infoProfitActivado;
	}

	public void setInfoProfitActivado(Boolean infoProfitActivado) {
		this.infoProfitActivado = infoProfitActivado;
	}

	public DescripcionAutorizaInditipo getFinalidadOperacion() {
		if (!GenericUtils.isNullOrBlank(autorizaOperacion)
				&& !GenericUtils.isNullOrBlank(autorizaOperacion.getInditipo())
				&& (autorizaOperacion.getInditipo().getCodigo()
						.equalsIgnoreCase("CO") || autorizaOperacion
						.getInditipo().getCodigo().equalsIgnoreCase("OT"))) {
			return null;
		}

		if (GenericUtils.isNullOrBlank(autorizaOperacion))
			return null;

		return autorizaOperacion.getInditipo();
	}

	public void setFinalidadOperacion(
			DescripcionAutorizaInditipo finalidadOperacion) {
		if (GenericUtils.isNullOrBlank(finalidadOperacion)
				&& !GenericUtils.isNullOrBlank(autorizaOperacion)
				&& !GenericUtils.isNullOrBlank(autorizaOperacion.getInditipo())
				&& (autorizaOperacion.getInditipo().getCodigo()
						.equalsIgnoreCase("CO") || autorizaOperacion
						.getInditipo().getCodigo().equalsIgnoreCase("OT"))) {

			return;
		}
		if (!GenericUtils.isNullOrBlank(autorizaOperacion)) {
			autorizaOperacion.setInditipo(finalidadOperacion);
		}

	}

	// INCIDENCIA 1721
	/*
	 * Al cambiar la selección: Si se deja desmarcado: Si hay información en
	 * deri.histparm (TIPOFECH = ‘FS’) de la operación, se mostrará el mensaje
	 * ‘Con esta acción se borrarán las fechas Fij. Strike ligadas a la
	 * operación, ¿desea continuar? S/N. Si contestan N, se vuelve a marcar el
	 * check. Si contestan S, se borran todos los registros de deri.histparm
	 * (TIPOFECH = ‘FS’) para la operación (ncorrela, fechaope) correspondiente
	 * Se protege el boton siguiente (F. Fij. Strike) Si se deja marcado, se
	 * desprotege botón ‘F. Fij. Strike’ poniéndolo como obligatorio
	 */
	// public void onStrikePromedioChange(){
	// if (hasDatosOpcionTab() &&
	// historicoOperacion.getHistoricoOpcion()!=null){
	//			
	// if (historicoOperacion.getHistoricoOpcion().getIndstrpr()){
	// panelesBloqueados.setFechaFijStrike(false);
	// }else{
	// if (hayFechasTipo("FS")){
	// messageBoxAction.init("boletas.messageBox.cambio.strikePromedio.borrar.fechas",
	// "boletasAction.onMessageBoxBorrarFechasFFijStrikeOk()",
	// "boletasAction.onMessageBoxBorrarFFijStrikeKo()");
	// }else{
	// panelesBloqueados.setFechaFijStrike(true);
	// }
	//	
	// }
	//			
	// }
	// }
	//
	// public String onMessageBoxBorrarFechasFFijStrikeOk(){
	// Set<HistoricoFechaFormula> fechas =
	// historicoOperacion.getHistoricoFechasFormulas();
	// if (fechas != null) {
	// if (borrarFechasTipo(fechas, "FS"))
	// persistir();
	// }
	// panelesBloqueados.setFechaFijStrike(true);
	// return "";
	// }

	// public String onMessageBoxBorrarFFijStrikeKo(){
	// historicoOperacion.getHistoricoOpcion().setIndstrpr(true);
	// panelesBloqueados.setFechaFijStrike(false);
	// return "";
	// }

}