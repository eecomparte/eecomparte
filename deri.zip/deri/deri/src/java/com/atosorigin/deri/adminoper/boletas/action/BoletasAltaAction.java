package com.atosorigin.deri.adminoper.boletas.action;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.jboss.seam.ScopeType;
import org.jboss.seam.annotations.Factory;
import org.jboss.seam.annotations.In;
import org.jboss.seam.annotations.Name;
import org.jboss.seam.annotations.Out;
import org.jboss.seam.annotations.Scope;
import org.jboss.seam.core.Conversation;
import org.jboss.seam.international.StatusMessages;
import org.jboss.seam.international.StatusMessage.Severity;
import org.jboss.seam.security.Identity;

import com.atosorigin.common.constantes.Constantes;
import com.atosorigin.common.utils.GenericUtils;
import com.atosorigin.deri.adminoper.boletas.action.BoletasAction.BoletasStates;
import com.atosorigin.deri.adminoper.boletas.business.BoletasBo;
import com.atosorigin.deri.dao.adminoper.boletas.AltaCorrelaResult;
import com.atosorigin.deri.model.adminoper.RelProductoTransaccion;
import com.atosorigin.deri.model.catalogo.ProductoCompuesto;
import com.atosorigin.deri.model.gestionoperaciones.DescripcionTransaccionOperacion;
import com.atosorigin.deri.model.gestionoperaciones.HistoricoOperacion;
import com.atosorigin.deri.model.gestionoperaciones.HistoricoOperacionId;
import com.atosorigin.deri.model.murex.ModeloProducto;
import com.atosorigin.deri.model.murex.ProcedenciaProducto;
import com.atosorigin.deri.model.murex.ProductoCatalogo;

/**
 * Clase action listener para el caso de uso de consulta operaciones asociadas en datos de mercado.
 */
@Name("boletasAltaAction")
@Scope(ScopeType.CONVERSATION)
public class BoletasAltaAction implements java.io.Serializable{


	private ProcedenciaProducto procedenciaProducto;
	private ModeloProducto modeloProducto;
	private ProductoCatalogo productoCatalogo;
	private Long numero;
	private Date fechaCOntratacion=new Date();
	private Boolean modelo;
	private DescripcionTransaccionOperacion transaccion;
	
	@Out(required=false) 
	private String boletaAltaError;
	
	
	@In protected StatusMessages statusMessages;

	@In("#{boletasBo}")
	protected BoletasBo boletasBo;

	@In(required=false)
	protected ProductoCompuesto productoCompuesto;

	@In(required=false)
	private String forcedReturnView;

	
	@Out(required=false)
	private HistoricoOperacion historicoOperacion;
	
	@Out(required=false)
	private BoletasStates boletaState;
	
	@Out(required=false)
	private List<ProductoCatalogo> listaProductoCatalogos;

	@Out(required = false)
	private ArrayList<DescripcionTransaccionOperacion> listaProductoTransacciones = null;
	
	private Boolean modeloDisabled;

	public Boolean getModeloDisabled() {
		return this.modeloDisabled;
	}

	public void setModeloDisabled(Boolean modeloDisabled) {
		this.modeloDisabled = modeloDisabled;
	}

	public void init(){
		if(productoCompuesto!=null && "S".equals(productoCompuesto.getIndEstructuraModelo()) || 
				(this.productoCatalogo!=null && (this.productoCatalogo.getProducat().compareTo(Constantes.PRODUCTO_SWAPTION) == 0 
						|| this.productoCatalogo.getProducat().compareTo(Constantes.PRODUCTO_SWAPTION2) == 0))){
			modelo=true;
			modeloDisabled=true;
		}
		else{
			modeloDisabled=false;
		}
		if (productoCompuesto!=null && !GenericUtils.isNullOrBlank(productoCompuesto.getFechaContratacion())){
			setFechaCOntratacion(productoCompuesto.getFechaContratacion());
		}
	}
	
	public String create(){
		if(this.fechaCOntratacion==null || this.fechaCOntratacion.after(new Date())){
			statusMessages.addToControl("fechaContr", Severity.ERROR, "#{messages['boletas.alta.validacionFecha']");
			return "failValidation";
		}
		if(procedenciaProducto==null){
			statusMessages.addToControl("procedencia", Severity.ERROR, "#{messages['boletas.alta.error.procedenciaError']");
			return "failValidation";
		}
		if(productoCatalogo==null){
			statusMessages.addToControl("productoSelect", Severity.ERROR, "#{messages['boletas.alta.error.productoCatalogoError']");
			return "failValidation";
		}
		if(modelo==null){
			statusMessages.addToControl("modelo", Severity.ERROR, "#{messages['boletas.alta.error.modeloError']");
			return "failValidation";
		}
		if(transaccion==null){
			statusMessages.addToControl("transaccion", Severity.ERROR, "#{messages['boletas.alta.error.transaccionError']");
			return "failValidation";
		}
		historicoOperacion = new HistoricoOperacion();
		HistoricoOperacionId id = new HistoricoOperacionId();
		id.setFechaContratacion(fechaCOntratacion);
		historicoOperacion.setId(id);
		id.setFechaContratacion(this.fechaCOntratacion);
		historicoOperacion.setProcedenciaProducto(procedenciaProducto);
		historicoOperacion.setProductoCatalogo(productoCatalogo);
		historicoOperacion.setIndicadorOperacionModelo(modelo);
		historicoOperacion.setUsuarioAlta(Identity.instance().getCredentials().getUsername());
		//FLM :Integracion con prod comp producto compuesto
		if (productoCompuesto != null)
			historicoOperacion.setProductoCompuesto( productoCompuesto);
		historicoOperacion.setTransaccion(transaccion);
			
		AltaCorrelaResult result = boletasBo.prepareAltaCorrela(historicoOperacion);
		if(result==null){
			statusMessages.addToControl("", Severity.ERROR, "#{messages['boletas.alta.error.creacionError']");
			return "failValidation";
		}
		historicoOperacion=result.getHistoricoOperacion();
		//FLM: Parece que se pierde la procedencia del producto. La volvemos a poner y punto
		historicoOperacion.setProcedenciaProducto(procedenciaProducto);
		if (productoCompuesto != null && historicoOperacion.getProductoCompuesto()==null )
			historicoOperacion.setProductoCompuesto( productoCompuesto);
		
		
		String codError = result.getCodError();
		if(result==null || codError!=null & !"".equals(codError)){
			boletaAltaError=result.getCodError();
			statusMessages.addToControl("", Severity.ERROR, "#{messages['boletas.alta.error.fAltaCorrelaError']");
			return "failValidation";
		}
		historicoOperacion.setTransaccion(transaccion);
		boletaState = BoletasStates.ALTA_BOLETA;
//		Operacion operacion = boletasBo.getOperacionByNCorrelaAndFechaOper(result.getnCorrela(), this.fechaCOntratacion);
//		if(operacion==null){
//			boletaAltaError=result.getCodError();
//			statusMessages.addToControl("", Severity.ERROR, "#{messages['boletas.alta.error.fAltaCorrelaError']");
//			return "failValidation";
//		}
//		historicoOperacion.setOperacion(operacion);
		//id.setOperacion(operacion);

		return Constantes.SUCCESS;
	}
	public String createDirecto(){
		historicoOperacion = new HistoricoOperacion();
		HistoricoOperacionId id = new HistoricoOperacionId();
		historicoOperacion.setId(id);
		id.setFechaContratacion(new Date());
		historicoOperacion.setIndicadorOperacionModelo(false);
		historicoOperacion.setUsuarioAlta(Identity.instance().getCredentials().getUsername());
		return "success";
	}
	@Factory("listaProductoCatalogos")
	public void  initProductoList(){
		listaProductoCatalogos = boletasBo.getProductoCatalogos(procedenciaProducto, modeloProducto);
	}
	
	public void refresh(){
		listaProductoCatalogos =null;
		listaProductoTransacciones =null;
		transaccion =null;
	}
	public void refreshTransaccion(){
		listaProductoTransacciones =null;
	}

//	public void refreshProducto(){
//		refreshTransaccion();
//		if (this.productoCatalogo.getProducat().compareTo(Constantes.PRODUCTO_SWAPTION) == 0){
//			modelo=true;
//			this.setModeloDisabled(true);
//		}else{
//			modeloDisabled=false;	
//		}
//	}
	
	public ProcedenciaProducto getProcedenciaProducto() {
		return procedenciaProducto;
	}

	public void setProcedenciaProducto(ProcedenciaProducto procedenciaProducto) {
		this.procedenciaProducto = procedenciaProducto;
	}

	public ModeloProducto getModeloProducto() {
		return modeloProducto;
	}

	public void setModeloProducto(ModeloProducto modeloProducto) {
		this.modeloProducto = modeloProducto;
	}

	public ProductoCatalogo getProductoCatalogo() {
		return productoCatalogo;
	}

	public void setProductoCatalogo(ProductoCatalogo productoCatalogo) {
		this.productoCatalogo = productoCatalogo;
	}

	public Long getNumero() {
		return numero;
	}

	public void setNumero(Long numero) {
		this.numero = numero;
	}

	public Date getFechaCOntratacion() {
		return fechaCOntratacion;
	}

	public void setFechaCOntratacion(Date fechaCOntratacion) {
		this.fechaCOntratacion = fechaCOntratacion;
	}

	public Boolean getModelo() {
		return modelo;
	}

	public void setModelo(Boolean modelo) {
		this.modelo = modelo;
	}
	public DescripcionTransaccionOperacion getTransaccion() {
		return transaccion;
	}
	public void setTransaccion(DescripcionTransaccionOperacion transaccion) {
		this.transaccion = transaccion;
	}
	
	public String salir(){
		
		if(forcedReturnView!=null){
			Conversation nested =Conversation.instance();
			nested.end(true);
			return forcedReturnView;
		}
		
		return Constantes.SUCCESS;
	}
	
	@Factory("listaProductoTransacciones")
	public void initListaTransacciones() {
		if(productoCatalogo!=null){
			Set<RelProductoTransaccion> transSet = new HashSet<RelProductoTransaccion>();
			transSet = productoCatalogo.getProductoTransacciones();	
			listaProductoTransacciones = new ArrayList<DescripcionTransaccionOperacion>();
			for (RelProductoTransaccion relProductoTransaccion : transSet) {
				listaProductoTransacciones.add(relProductoTransaccion.getId().getTranoper());
			}
			if(listaProductoTransacciones.size()==1){
				transaccion = listaProductoTransacciones.get(0);
			}
		}

	}

}
