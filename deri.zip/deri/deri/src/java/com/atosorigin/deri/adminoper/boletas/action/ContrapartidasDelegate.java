package com.atosorigin.deri.adminoper.boletas.action;

import javax.persistence.EntityManager;

import org.jboss.seam.core.Expressions;

import com.atosorigin.deri.model.gestionoperaciones.HistoricoOperacion;
import com.atosorigin.deri.util.EntityUtil;

public class ContrapartidasDelegate {
private HistoricoOperacion delegate;
public HistoricoOperacion getDelegate() {
	return delegate;
}
public void setDelegate(HistoricoOperacion delegate) {
	this.delegate = delegate;
}
private PropertyWrapper<String> codigoContrapa=null;
private String codigoEntidadMatriz=null;
private String codigoContrapaInternal=null;
public String getCodigoContrapaInternal() {
	return codigoContrapaInternal;
}
public void setCodigoContrapaInternal(String codigoContrapaInternal) {
	this.codigoContrapaInternal = codigoContrapaInternal;
}
private String codigoContrapa2=null;
private String codigoContrapaOriginal=null;


public ContrapartidasDelegate(HistoricoOperacion delegate) {
	super();
	this.delegate = delegate;
	codigoContrapa = new PropertyWrapper<String>(this, "codigoContrapaInternal"){};
	refresh();
}
public void refresh() {
	if(checkEntityExists(delegate.getContrapartida())){
		this.codigoContrapa.setValue(delegate.getContrapartida().getId());
	}
	if(checkEntityExists(delegate.getEntidadMatriz())){
		this.codigoEntidadMatriz=delegate.getEntidadMatriz().getId();
	}
	if(checkEntityExists(delegate.getContrapartida2())){
		this.codigoContrapa2=delegate.getContrapartida2().getId();
	}
	if(checkEntityExists(delegate.getContrapartidaOriginal())){
		this.codigoContrapaOriginal=delegate.getContrapartidaOriginal().getId();
	}

}
private Boolean checkEntityExists(Object entity){
	if(entity==null){
		return false;
	}
	
	EntityManager entityManager = getEntityManager();
	return EntityUtil.checkEntityExists(entityManager, entity);
}
private EntityManager getEntityManager() {
	return Expressions.instance().createValueExpression("#{entityManager}", EntityManager.class).getValue();
}
public String getCodigoContrapa() {
	return codigoContrapa.getValue();
}
public void setCodigoContrapa(String codigoContrapa) {
	this.codigoContrapa.setValue(codigoContrapa);
}
public String getCodigoEntidadMatriz() {
	return codigoEntidadMatriz;
}
public void setCodigoEntidadMatriz(String codigoEntidadMatriz) {
	this.codigoEntidadMatriz = codigoEntidadMatriz;
}
public String getCodigoContrapa2() {
	return codigoContrapa2;
}
public void setCodigoContrapa2(String codigoContrapa2) {
	this.codigoContrapa2 = codigoContrapa2;
}
public String getCodigoContrapaOriginal() {
	return codigoContrapaOriginal;
}
public void setCodigoContrapaOriginal(String codigoContrapaOriginal) {
	this.codigoContrapaOriginal = codigoContrapaOriginal;
}

public boolean hasChanged(){
	return codigoContrapa.getChanged();
}

}
