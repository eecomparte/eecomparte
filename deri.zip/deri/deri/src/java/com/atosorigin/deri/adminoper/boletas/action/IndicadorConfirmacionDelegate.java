package com.atosorigin.deri.adminoper.boletas.action;

import com.atosorigin.common.auditdata.AuditData;
import com.atosorigin.deri.model.adminoper.CanalConfirmacion;
import com.atosorigin.deri.model.adminoper.IndicadorConfirmacion;
import com.atosorigin.deri.model.common.Idioma;
import com.atosorigin.deri.model.gestionoperaciones.OperacionId;

public class IndicadorConfirmacionDelegate {
private IndicadorConfirmacion delegate;
private CanalConfirmacion canelEmisionConfirmacionAlta;
private CanalConfirmacion canelEmisionConfirmacionModificacion;
private CanalConfirmacion canelEmisionConfirmacionAnulacion;
private CanalConfirmacion canelEmisionConfirmacionCancelacion;
private CanalConfirmacion canelEmisionConfirmacionCancelacionParcial;
private CanalConfirmacion canelEmisionConfirmacionLiquidacion;
private CanalConfirmacion canelEmisionConfirmacionFijacion;
private CanalConfirmacion canelRecepcionConfirmacionAlta;
private CanalConfirmacion canelRecepcionConfirmacionModificacion;
private CanalConfirmacion canelRecepcionConfirmacionAnulacion;
private CanalConfirmacion canelRecepcionConfirmacionCancelacion;
private CanalConfirmacion canelRecepcionConfirmacionCancelacionParcial;
private CanalConfirmacion canelRecepcionConfirmacionLiquidacion;
private CanalConfirmacion canelRecepcionConfirmacionFijacion;


public void refresh(){
delegate.setCanelEmisionConfirmacionAlta(getCanalCode(canelEmisionConfirmacionAlta));
delegate.setCanelEmisionConfirmacionModificacion(getCanalCode(canelEmisionConfirmacionModificacion));
delegate.setCanelEmisionConfirmacionAnulacion(getCanalCode(canelEmisionConfirmacionAnulacion));
delegate.setCanelEmisionConfirmacionCancelacion(getCanalCode(canelEmisionConfirmacionCancelacion));
delegate.setCanelEmisionConfirmacionCancelacionParcial(getCanalCode(canelEmisionConfirmacionCancelacionParcial));
delegate.setCanelEmisionConfirmacionLiquidacion(getCanalCode(canelEmisionConfirmacionLiquidacion));
delegate.setCanelEmisionConfirmacionFijacion(getCanalCode(canelEmisionConfirmacionFijacion));
delegate.setCanelRecepcionConfirmacionAlta(getCanalCode(canelRecepcionConfirmacionAlta));
delegate.setCanelRecepcionConfirmacionModificacion(getCanalCode(canelRecepcionConfirmacionModificacion));
delegate.setCanelRecepcionConfirmacionAnulacion(getCanalCode(canelRecepcionConfirmacionAnulacion));
delegate.setCanelRecepcionConfirmacionCancelacion(getCanalCode(canelRecepcionConfirmacionCancelacion));
delegate.setCanelRecepcionConfirmacionCancelacionParcial(getCanalCode(canelRecepcionConfirmacionCancelacionParcial));
delegate.setCanelRecepcionConfirmacionLiquidacion(getCanalCode(canelRecepcionConfirmacionLiquidacion));
delegate.setCanelRecepcionConfirmacionFijacion(getCanalCode(canelRecepcionConfirmacionFijacion));
}

private String getCanalCode(CanalConfirmacion canal) {
	return canal==null||canal.getId()==null?null:canal.getId().getCodcanal();
}

public CanalConfirmacion getCanelEmisionConfirmacionAlta() {;
	return canelEmisionConfirmacionAlta;
}

public void setCanelEmisionConfirmacionAlta(
		CanalConfirmacion canelEmisionConfirmacionAlta) {
	
	this.canelEmisionConfirmacionAlta = canelEmisionConfirmacionAlta;
	if(canelEmisionConfirmacionAlta!=null && canelEmisionConfirmacionAlta.getId()!=null){
		delegate.setCanelEmisionConfirmacionAlta(canelEmisionConfirmacionAlta.getId().getCodcanal());
	}
	else{
		delegate.setCanelEmisionConfirmacionAlta(null);
	}
}

public CanalConfirmacion getCanelEmisionConfirmacionModificacion() {
	return canelEmisionConfirmacionModificacion;
}

public void setCanelEmisionConfirmacionModificacion(
		CanalConfirmacion canelEmisionConfirmacionModificacion) {
	this.canelEmisionConfirmacionModificacion = canelEmisionConfirmacionModificacion;
	if(canelEmisionConfirmacionModificacion!=null && canelEmisionConfirmacionModificacion.getId()!=null){
		delegate.setCanelEmisionConfirmacionModificacion(canelEmisionConfirmacionModificacion.getId().getCodcanal());
	}
	else{
		delegate.setCanelEmisionConfirmacionModificacion(null);
	}
}

public CanalConfirmacion getCanelEmisionConfirmacionAnulacion() {
	return canelEmisionConfirmacionAnulacion;
}

public void setCanelEmisionConfirmacionAnulacion(
		CanalConfirmacion canelEmisionConfirmacionAnulacion) {
	this.canelEmisionConfirmacionAnulacion = canelEmisionConfirmacionAnulacion;
	if(canelEmisionConfirmacionAnulacion!=null && canelEmisionConfirmacionAnulacion.getId()!=null){
		delegate.setCanelEmisionConfirmacionAnulacion(canelEmisionConfirmacionAnulacion.getId().getCodcanal());
	}
	else{
		delegate.setCanelEmisionConfirmacionAnulacion(null);
	}
}

public CanalConfirmacion getCanelEmisionConfirmacionCancelacion() {
	return canelEmisionConfirmacionCancelacion;
}

public void setCanelEmisionConfirmacionCancelacion(
		CanalConfirmacion canelEmisionConfirmacionCancelacion) {
	this.canelEmisionConfirmacionCancelacion = canelEmisionConfirmacionCancelacion;
	if(canelEmisionConfirmacionCancelacion!=null && canelEmisionConfirmacionCancelacion.getId()!=null){
		delegate.setCanelEmisionConfirmacionCancelacion(canelEmisionConfirmacionCancelacion.getId().getCodcanal());
	}
	else{
		delegate.setCanelEmisionConfirmacionCancelacion(null);
	}

}

public CanalConfirmacion getCanelEmisionConfirmacionCancelacionParcial() {
	return canelEmisionConfirmacionCancelacionParcial;
}

public void setCanelEmisionConfirmacionCancelacionParcial(
		CanalConfirmacion canelEmisionConfirmacionCancelacionParcial) {
	this.canelEmisionConfirmacionCancelacionParcial = canelEmisionConfirmacionCancelacionParcial;
	if(canelEmisionConfirmacionCancelacionParcial!=null && canelEmisionConfirmacionCancelacionParcial.getId()!=null){
		delegate.setCanelEmisionConfirmacionCancelacionParcial(canelEmisionConfirmacionCancelacionParcial.getId().getCodcanal());
	}
	else{
		delegate.setCanelEmisionConfirmacionCancelacionParcial(null);
	}

}

public CanalConfirmacion getCanelEmisionConfirmacionLiquidacion() {
	return canelEmisionConfirmacionLiquidacion;
}

public void setCanelEmisionConfirmacionLiquidacion(
		CanalConfirmacion canelEmisionConfirmacionLiquidacion) {
	this.canelEmisionConfirmacionLiquidacion = canelEmisionConfirmacionLiquidacion;
	if(canelEmisionConfirmacionLiquidacion!=null && canelEmisionConfirmacionLiquidacion.getId()!=null){
		delegate.setCanelEmisionConfirmacionLiquidacion(canelEmisionConfirmacionLiquidacion.getId().getCodcanal());
	}
	else{
		delegate.setCanelEmisionConfirmacionLiquidacion(null);
	}
}

public CanalConfirmacion getCanelEmisionConfirmacionFijacion() {
	return canelEmisionConfirmacionFijacion;
}

public void setCanelEmisionConfirmacionFijacion(
		CanalConfirmacion canelEmisionConfirmacionFijacion) {
	this.canelEmisionConfirmacionFijacion = canelEmisionConfirmacionFijacion;
	if(canelEmisionConfirmacionFijacion!=null && canelEmisionConfirmacionFijacion.getId()!=null){
		delegate.setCanelEmisionConfirmacionFijacion(canelEmisionConfirmacionFijacion.getId().getCodcanal());
	}
	else{
		delegate.setCanelEmisionConfirmacionFijacion(null);
	}
}

public CanalConfirmacion getCanelRecepcionConfirmacionAlta() {
	return canelRecepcionConfirmacionAlta;
}

public void setCanelRecepcionConfirmacionAlta(
		CanalConfirmacion canelRecepcionConfirmacionAlta) {
	this.canelRecepcionConfirmacionAlta = canelRecepcionConfirmacionAlta;
	if(canelRecepcionConfirmacionAlta!=null && canelRecepcionConfirmacionAlta.getId()!=null){
		delegate.setCanelRecepcionConfirmacionAlta(canelRecepcionConfirmacionAlta.getId().getCodcanal());
	}
	else{
		delegate.setCanelRecepcionConfirmacionAlta(null);
	}
}

public CanalConfirmacion getCanelRecepcionConfirmacionModificacion() {
	return canelRecepcionConfirmacionModificacion;
}

public void setCanelRecepcionConfirmacionModificacion(
		CanalConfirmacion canelRecepcionConfirmacionModificacion) {
	this.canelRecepcionConfirmacionModificacion = canelRecepcionConfirmacionModificacion;
	if(canelRecepcionConfirmacionModificacion!=null && canelRecepcionConfirmacionModificacion.getId()!=null){
		delegate.setCanelRecepcionConfirmacionModificacion(canelRecepcionConfirmacionModificacion.getId().getCodcanal());
	}
	else{
		delegate.setCanelRecepcionConfirmacionModificacion(null);
	}
}

public CanalConfirmacion getCanelRecepcionConfirmacionAnulacion() {
	return canelRecepcionConfirmacionAnulacion;
}

public void setCanelRecepcionConfirmacionAnulacion(
		CanalConfirmacion canelRecepcionConfirmacionAnulacion) {
	this.canelRecepcionConfirmacionAnulacion = canelRecepcionConfirmacionAnulacion;
	if(canelRecepcionConfirmacionAnulacion!=null && canelRecepcionConfirmacionAnulacion.getId()!=null){
		delegate.setCanelRecepcionConfirmacionAnulacion(canelRecepcionConfirmacionAnulacion.getId().getCodcanal());
	}
	else{
		delegate.setCanelRecepcionConfirmacionAnulacion(null);
	}
}

public CanalConfirmacion getCanelRecepcionConfirmacionCancelacion() {
	return canelRecepcionConfirmacionCancelacion;
}

public void setCanelRecepcionConfirmacionCancelacion(
		CanalConfirmacion canelRecepcionConfirmacionCancelacion) {
	this.canelRecepcionConfirmacionCancelacion = canelRecepcionConfirmacionCancelacion;
	if(canelRecepcionConfirmacionCancelacion!=null && canelRecepcionConfirmacionCancelacion.getId()!=null){
		delegate.setCanelRecepcionConfirmacionCancelacion(canelRecepcionConfirmacionCancelacion.getId().getCodcanal());
	}
	else{
		delegate.setCanelRecepcionConfirmacionCancelacion(null);
	}
}

public CanalConfirmacion getCanelRecepcionConfirmacionCancelacionParcial() {
	return canelRecepcionConfirmacionCancelacionParcial;
}

public void setCanelRecepcionConfirmacionCancelacionParcial(
		CanalConfirmacion canelRecepcionConfirmacionCancelacionParcial) {
	this.canelRecepcionConfirmacionCancelacionParcial = canelRecepcionConfirmacionCancelacionParcial;
	if(canelRecepcionConfirmacionCancelacionParcial!=null && canelRecepcionConfirmacionCancelacionParcial.getId()!=null){
		delegate.setCanelRecepcionConfirmacionCancelacionParcial(canelRecepcionConfirmacionCancelacionParcial.getId().getCodcanal());
	}
	else{
		delegate.setCanelRecepcionConfirmacionCancelacionParcial(null);
	}
}

public CanalConfirmacion getCanelRecepcionConfirmacionLiquidacion() {
	return canelRecepcionConfirmacionLiquidacion;
}

public void setCanelRecepcionConfirmacionLiquidacion(
		CanalConfirmacion canelRecepcionConfirmacionLiquidacion) {
	this.canelRecepcionConfirmacionLiquidacion = canelRecepcionConfirmacionLiquidacion;
	if(canelRecepcionConfirmacionLiquidacion!=null && canelRecepcionConfirmacionLiquidacion.getId()!=null){
		delegate.setCanelRecepcionConfirmacionLiquidacion (canelRecepcionConfirmacionLiquidacion.getId().getCodcanal());
	}
	else{
		delegate.setCanelRecepcionConfirmacionLiquidacion(null);
	}
}

public CanalConfirmacion getCanelRecepcionConfirmacionFijacion() {
	return canelRecepcionConfirmacionFijacion;
}

public void setCanelRecepcionConfirmacionFijacion(
		CanalConfirmacion canelRecepcionConfirmacionFijacion) {
	this.canelRecepcionConfirmacionFijacion = canelRecepcionConfirmacionFijacion;
	if(canelRecepcionConfirmacionFijacion!=null && canelRecepcionConfirmacionFijacion.getId()!=null){
		delegate.setCanelRecepcionConfirmacionFijacion (canelRecepcionConfirmacionFijacion.getId().getCodcanal());
	}
	else{
		delegate.setCanelRecepcionConfirmacionFijacion(null);
	}
}

public Long getCodigoEstructura() {
	return delegate.getCodigoEstructura();
}

public Idioma getIdiomaConfirmacionAlta() {
	return delegate.getIdiomaConfirmacionAlta();
}

public Idioma getIdiomaConfirmacionAnulacion() {
	return delegate.getIdiomaConfirmacionAnulacion();
}

public Idioma getIdiomaConfirmacionCancelacion() {
	return delegate.getIdiomaConfirmacionCancelacion();
}

public Idioma getIdiomaConfirmacionCancelacionParcial() {
	return delegate.getIdiomaConfirmacionCancelacionParcial();
}

public Idioma getIdiomaConfirmacionFijacion() {
	return delegate.getIdiomaConfirmacionFijacion();
}

public Idioma getIdiomaConfirmacionLiquidacion() {
	return delegate.getIdiomaConfirmacionLiquidacion();
}

public Idioma getIdiomaConfirmacionModificacion() {
	return delegate.getIdiomaConfirmacionModificacion();
}

public Boolean getIndicadorConfirmacionAlta() {
	return delegate.getIndicadorConfirmacionAlta();
}

public Boolean getIndicadorConfirmacionAnulacion() {
	return delegate.getIndicadorConfirmacionAnulacion();
}

public Boolean getIndicadorConfirmacionCancelacion() {
	return delegate.getIndicadorConfirmacionCancelacion();
}

public Boolean getIndicadorConfirmacionCancelacionParcial() {
	return delegate.getIndicadorConfirmacionCancelacionParcial();
}

public Boolean getIndicadorConfirmacionEjercicio() {
	return delegate.getIndicadorConfirmacionEjercicio();
}

public Boolean getIndicadorConfirmacionEjercicioParcial() {
	return delegate.getIndicadorConfirmacionEjercicioParcial();
}

public Boolean getIndicadorConfirmacionFijacion() {
	return delegate.getIndicadorConfirmacionFijacion();
}

public Boolean getIndicadorConfirmacionLiquidacion() {
	return delegate.getIndicadorConfirmacionLiquidacion();
}

public Boolean getIndicadorConfirmacionModificacion() {
	return delegate.getIndicadorConfirmacionModificacion();
}

public Boolean getIndicadorRecepcionConfirmacionAlta() {
	return delegate.getIndicadorRecepcionConfirmacionAlta();
}

public Boolean getIndicadorRecepcionConfirmacionAnulacion() {
	return delegate.getIndicadorRecepcionConfirmacionAnulacion();
}

public Boolean getIndicadorRecepcionConfirmacionCancelacion() {
	return delegate.getIndicadorRecepcionConfirmacionCancelacion();
}

public Boolean getIndicadorRecepcionConfirmacionCancelacionParcial() {
	return delegate.getIndicadorRecepcionConfirmacionCancelacionParcial();
}

public Boolean getIndicadorRecepcionConfirmacionEjercicio() {
	return delegate.getIndicadorRecepcionConfirmacionEjercicio();
}

public Boolean getIndicadorRecepcionConfirmacionEjercicioParcial() {
	return delegate.getIndicadorRecepcionConfirmacionEjercicioParcial();
}

public Boolean getIndicadorRecepcionConfirmacionFijacion() {
	return delegate.getIndicadorRecepcionConfirmacionFijacion();
}

public Boolean getIndicadorRecepcionConfirmacionLiquidacion() {
	return delegate.getIndicadorRecepcionConfirmacionLiquidacion();
}

public Boolean getIndicadorRecepcionConfirmacionModificacion() {
	return delegate.getIndicadorRecepcionConfirmacionModificacion();
}

public String getModeloConfirmacionAlta() {
	return delegate.getModeloConfirmacionAlta();
}

public String getModeloConfirmacionAnulacion() {
	return delegate.getModeloConfirmacionAnulacion();
}

public String getModeloConfirmacionCancelacion() {
	return delegate.getModeloConfirmacionCancelacion();
}

public String getModeloConfirmacionCancelacionParcial() {
	return delegate.getModeloConfirmacionCancelacionParcial();
}

public String getModeloConfirmacionEjercicio() {
	return delegate.getModeloConfirmacionEjercicio();
}

public String getModeloConfirmacionEjercicioParcial() {
	return delegate.getModeloConfirmacionEjercicioParcial();
}

public String getModeloConfirmacionFijacion() {
	return delegate.getModeloConfirmacionFijacion();
}

public String getModeloConfirmacionLiquidacion() {
	return delegate.getModeloConfirmacionLiquidacion();
}

public String getModeloConfirmacionModificacion() {
	return delegate.getModeloConfirmacionModificacion();
}

public String getTextoConfirmacionFechasPago() {
	return delegate.getTextoConfirmacionFechasPago();
}

public String getTextoConfirmacionRefLiquidacion() {
	return delegate.getTextoConfirmacionRefLiquidacion();
}

public void setAuditData(AuditData auditData) {
	delegate.setAuditData(auditData);
}

public void setCanelEmisionConfirmacionAlta(String canelEmisionConfirmacionAlta) {
	delegate.setCanelEmisionConfirmacionAlta(canelEmisionConfirmacionAlta);
}

public void setCanelEmisionConfirmacionAnulacion(
		String canelEmisionConfirmacionAnulacion) {
	delegate
			.setCanelEmisionConfirmacionAnulacion(canelEmisionConfirmacionAnulacion);
}

public void setCanelEmisionConfirmacionCancelacion(
		String canelEmisionConfirmacionCancelacion) {
	delegate
			.setCanelEmisionConfirmacionCancelacion(canelEmisionConfirmacionCancelacion);
}

public void setCanelEmisionConfirmacionCancelacionParcial(
		String canelEmisionConfirmacionCancelacionParcial) {
	delegate
			.setCanelEmisionConfirmacionCancelacionParcial(canelEmisionConfirmacionCancelacionParcial);
}

public void setCanelEmisionConfirmacionFijacion(
		String canelEmisionConfirmacionFijacion) {
	delegate
			.setCanelEmisionConfirmacionFijacion(canelEmisionConfirmacionFijacion);
}

public void setCanelEmisionConfirmacionLiquidacion(
		String canelEmisionConfirmacionLiquidacion) {
	delegate
			.setCanelEmisionConfirmacionLiquidacion(canelEmisionConfirmacionLiquidacion);
}

public void setCanelEmisionConfirmacionModificacion(
		String canelEmisionConfirmacionModificacion) {
	delegate
			.setCanelEmisionConfirmacionModificacion(canelEmisionConfirmacionModificacion);
}

public void setCanelRecepcionConfirmacionAlta(
		String canelRecepcionConfirmacionAlta) {
	delegate.setCanelRecepcionConfirmacionAlta(canelRecepcionConfirmacionAlta);
}

public void setCanelRecepcionConfirmacionAnulacion(
		String canelRecepcionConfirmacionAnulacion) {
	delegate
			.setCanelRecepcionConfirmacionAnulacion(canelRecepcionConfirmacionAnulacion);
}

public void setCanelRecepcionConfirmacionCancelacion(
		String canelRecepcionConfirmacionCancelacion) {
	delegate
			.setCanelRecepcionConfirmacionCancelacion(canelRecepcionConfirmacionCancelacion);
}

public void setCanelRecepcionConfirmacionCancelacionParcial(
		String canelRecepcionConfirmacionCancelacionParcial) {
	delegate
			.setCanelRecepcionConfirmacionCancelacionParcial(canelRecepcionConfirmacionCancelacionParcial);
}

public void setCanelRecepcionConfirmacionFijacion(
		String canelRecepcionConfirmacionFijacion) {
	delegate
			.setCanelRecepcionConfirmacionFijacion(canelRecepcionConfirmacionFijacion);
}

public void setCanelRecepcionConfirmacionLiquidacion(
		String canelRecepcionConfirmacionLiquidacion) {
	delegate
			.setCanelRecepcionConfirmacionLiquidacion(canelRecepcionConfirmacionLiquidacion);
}

public void setCanelRecepcionConfirmacionModificacion(
		String canelRecepcionConfirmacionModificacion) {
	delegate
			.setCanelRecepcionConfirmacionModificacion(canelRecepcionConfirmacionModificacion);
}

public void setCodigoEstructura(Long codigoEstructura) {
	delegate.setCodigoEstructura(codigoEstructura);
}

public void setId(OperacionId id) {
	delegate.setId(id);
}

public void setIdiomaConfirmacionAlta(Idioma idiomaConfirmacionAlta) {
	delegate.setIdiomaConfirmacionAlta(idiomaConfirmacionAlta);
}

public void setIdiomaConfirmacionAnulacion(Idioma idiomaConfirmacionAnulacion) {
	delegate.setIdiomaConfirmacionAnulacion(idiomaConfirmacionAnulacion);
}

public void setIdiomaConfirmacionCancelacion(
		Idioma idiomaConfirmacionCancelacion) {
	delegate.setIdiomaConfirmacionCancelacion(idiomaConfirmacionCancelacion);
}

public void setIdiomaConfirmacionCancelacionParcial(
		Idioma idiomaConfirmacionCancelacionParcial) {
	delegate
			.setIdiomaConfirmacionCancelacionParcial(idiomaConfirmacionCancelacionParcial);
}

public void setIdiomaConfirmacionFijacion(Idioma idiomaConfirmacionFijacion) {
	delegate.setIdiomaConfirmacionFijacion(idiomaConfirmacionFijacion);
}

public void setIdiomaConfirmacionLiquidacion(
		Idioma idiomaConfirmacionLiquidacion) {
	delegate.setIdiomaConfirmacionLiquidacion(idiomaConfirmacionLiquidacion);
}

public void setIdiomaConfirmacionModificacion(
		Idioma idiomaConfirmacionModificacion) {
	delegate.setIdiomaConfirmacionModificacion(idiomaConfirmacionModificacion);
}

public void setIndicadorConfirmacionAlta(Boolean indicadorConfirmacionAlta) {
	delegate.setIndicadorConfirmacionAlta(indicadorConfirmacionAlta);
}

public void setIndicadorConfirmacionAnulacion(
		Boolean indicadorConfirmacionAnulacion) {
	delegate.setIndicadorConfirmacionAnulacion(indicadorConfirmacionAnulacion);
}

public void setIndicadorConfirmacionCancelacion(
		Boolean indicadorConfirmacionCancelacion) {
	delegate
			.setIndicadorConfirmacionCancelacion(indicadorConfirmacionCancelacion);
}

public void setIndicadorConfirmacionCancelacionParcial(
		Boolean indicadorConfirmacionCancelacionParcial) {
	delegate
			.setIndicadorConfirmacionCancelacionParcial(indicadorConfirmacionCancelacionParcial);
}

public void setIndicadorConfirmacionEjercicio(
		Boolean indicadorConfirmacionEjercicio) {
	delegate.setIndicadorConfirmacionEjercicio(indicadorConfirmacionEjercicio);
}

public void setIndicadorConfirmacionEjercicioParcial(
		Boolean indicadorConfirmacionEjercicioParcial) {
	delegate
			.setIndicadorConfirmacionEjercicioParcial(indicadorConfirmacionEjercicioParcial);
}

public void setIndicadorConfirmacionFijacion(
		Boolean indicadorConfirmacionFijacion) {
	delegate.setIndicadorConfirmacionFijacion(indicadorConfirmacionFijacion);
}

public void setIndicadorConfirmacionLiquidacion(
		Boolean indicadorConfirmacionLiquidacion) {
	delegate
			.setIndicadorConfirmacionLiquidacion(indicadorConfirmacionLiquidacion);
}

public void setIndicadorConfirmacionModificacion(
		Boolean indicadorConfirmacionModificacion) {
	delegate
			.setIndicadorConfirmacionModificacion(indicadorConfirmacionModificacion);
}

public void setIndicadorRecepcionConfirmacionAlta(
		Boolean indicadorRecepcionConfirmacionAlta) {
	delegate
			.setIndicadorRecepcionConfirmacionAlta(indicadorRecepcionConfirmacionAlta);
}

public void setIndicadorRecepcionConfirmacionAnulacion(
		Boolean indicadorRecepcionConfirmacionAnulacion) {
	delegate
			.setIndicadorRecepcionConfirmacionAnulacion(indicadorRecepcionConfirmacionAnulacion);
}

public void setIndicadorRecepcionConfirmacionCancelacion(
		Boolean indicadorRecepcionConfirmacionCancelacion) {
	delegate
			.setIndicadorRecepcionConfirmacionCancelacion(indicadorRecepcionConfirmacionCancelacion);
}

public void setIndicadorRecepcionConfirmacionCancelacionParcial(
		Boolean indicadorRecepcionConfirmacionCancelacionParcial) {
	delegate
			.setIndicadorRecepcionConfirmacionCancelacionParcial(indicadorRecepcionConfirmacionCancelacionParcial);
}

public void setIndicadorRecepcionConfirmacionEjercicio(
		Boolean indicadorRecepcionConfirmacionEjercicio) {
	delegate
			.setIndicadorRecepcionConfirmacionEjercicio(indicadorRecepcionConfirmacionEjercicio);
}

public void setIndicadorRecepcionConfirmacionEjercicioParcial(
		Boolean indicadorRecepcionConfirmacionEjercicioParcial) {
	delegate
			.setIndicadorRecepcionConfirmacionEjercicioParcial(indicadorRecepcionConfirmacionEjercicioParcial);
}

public void setIndicadorRecepcionConfirmacionFijacion(
		Boolean indicadorRecepcionConfirmacionFijacion) {
	delegate
			.setIndicadorRecepcionConfirmacionFijacion(indicadorRecepcionConfirmacionFijacion);
}

public void setIndicadorRecepcionConfirmacionLiquidacion(
		Boolean indicadorRecepcionConfirmacionLiquidacion) {
	delegate
			.setIndicadorRecepcionConfirmacionLiquidacion(indicadorRecepcionConfirmacionLiquidacion);
}

public void setIndicadorRecepcionConfirmacionModificacion(
		Boolean indicadorRecepcionConfirmacionModificacion) {
	delegate
			.setIndicadorRecepcionConfirmacionModificacion(indicadorRecepcionConfirmacionModificacion);
}

public void setModeloConfirmacionAlta(String modeloConfirmacionAlta) {
	delegate.setModeloConfirmacionAlta(modeloConfirmacionAlta);
}

public void setModeloConfirmacionAnulacion(String modeloConfirmacionAnulacion) {
	delegate.setModeloConfirmacionAnulacion(modeloConfirmacionAnulacion);
}

public void setModeloConfirmacionCancelacion(
		String modeloConfirmacionCancelacion) {
	delegate.setModeloConfirmacionCancelacion(modeloConfirmacionCancelacion);
}

public void setModeloConfirmacionCancelacionParcial(
		String modeloConfirmacionCancelacionParcial) {
	delegate
			.setModeloConfirmacionCancelacionParcial(modeloConfirmacionCancelacionParcial);
}

public void setModeloConfirmacionEjercicio(String modeloConfirmacionEjercicio) {
	delegate.setModeloConfirmacionEjercicio(modeloConfirmacionEjercicio);
}

public void setModeloConfirmacionEjercicioParcial(
		String modeloConfirmacionEjercicioParcial) {
	delegate
			.setModeloConfirmacionEjercicioParcial(modeloConfirmacionEjercicioParcial);
}

public IndicadorConfirmacionDelegate(IndicadorConfirmacion delegate) {
	super();
	this.delegate = delegate;
}
public void setModeloConfirmacionFijacion(String modeloConfirmacionFijacion) {
	delegate.setModeloConfirmacionFijacion(modeloConfirmacionFijacion);
}

public void setModeloConfirmacionLiquidacion(
		String modeloConfirmacionLiquidacion) {
	delegate.setModeloConfirmacionLiquidacion(modeloConfirmacionLiquidacion);
}

public void setModeloConfirmacionModificacion(
		String modeloConfirmacionModificacion) {
	delegate.setModeloConfirmacionModificacion(modeloConfirmacionModificacion);
}

public void setTextoConfirmacionFechasPago(String textoConfirmacionFechasPago) {
	delegate.setTextoConfirmacionFechasPago(textoConfirmacionFechasPago);
}

public void setTextoConfirmacionRefLiquidacion(
		String textoConfirmacionRefLiquidacion) {
	delegate
			.setTextoConfirmacionRefLiquidacion(textoConfirmacionRefLiquidacion);
}


}
