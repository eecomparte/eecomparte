package com.atosorigin.deri.adminoper.boletas.action;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;

import org.jboss.seam.ScopeType;
import org.jboss.seam.annotations.Factory;
import org.jboss.seam.annotations.In;
import org.jboss.seam.annotations.Name;
import org.jboss.seam.annotations.Out;
import org.jboss.seam.annotations.Scope;
import org.jboss.seam.annotations.datamodel.DataModel;
import org.jboss.seam.annotations.datamodel.DataModelSelection;
import org.jboss.seam.core.Conversation;
import org.jboss.seam.international.StatusMessage.Severity;
import org.jboss.seam.security.Identity;

import com.atosorigin.common.action.GenericAction;
import com.atosorigin.common.constantes.Constantes;
import com.atosorigin.common.utils.GenericUtils;
import com.atosorigin.deri.adminoper.boletas.action.BoletasAction.BoletasStates;
import com.atosorigin.deri.adminoper.boletas.action.BoletasAction.PagoCobroType;
import com.atosorigin.deri.adminoper.boletas.business.BoletasBo;
import com.atosorigin.deri.adminoper.boletas.business.IndPagoCobroBo;
import com.atosorigin.deri.common.dbLock.DbLockService;
import com.atosorigin.deri.model.gestionoperaciones.HistoricoOperacion;
import com.atosorigin.deri.model.gestionoperaciones.HistoricoOperacionId;
import com.atosorigin.deri.model.mercado.DescripcionIndice;
import com.atosorigin.deri.model.mercado.IndicesPantalla;
import com.atosorigin.deri.model.mercado.Subyacente;
import com.atosorigin.deri.util.EntityUtil;

@Name("indicesPagoCobroAction")
@Scope(ScopeType.CONVERSATION)
public class IndicesPagoCobroAction extends GenericAction implements java.io.Serializable{
	
	private static final long serialVersionUID = 2426210794917224267L;
	
//	@In(required = false)
//	private BoletasStates boletaState;

	@In
	private EntityManager entityManager;

	@In(value = "dbLockService", create = true)
	private DbLockService dbLockService;

	@In(required=false)
	private String forcedReturnView;
	
	@In
	private BoletasStates boletaState;
	
	@In("#{boletasBo}")
	protected BoletasBo boletasBo;


	@In
	private HistoricoOperacion historicoOperacion;
	
	@In(required=false)
	HistoricoOperacionId historicoOperacionBloqueadoId;

	@In("#{indPagoCobroBo}")
	private IndPagoCobroBo indPagoCobroBo;

	@In(required = false)
	private PagosCobrosB pagosCobrosB;
	
	@In
	List <IndicesPantalla> indicesFxCobroList;
	
	@In
	List <IndicesPantalla> indicesFxPagoList;
	
	@In
	private PagoCobroType pagoCobroType;
	
	@DataModel(value ="listaDeIndexs")
	protected List<IndicesPantalla> indicesFormulaList;

	@DataModelSelection(value ="listaDeIndexs")
    protected IndicesPantalla indiceFormulaSel;
	
	private Subyacente indice;
	private String tituloPanel;
	private String cobroPago;
	private List<DescripcionIndice> tiposIndice = new ArrayList<DescripcionIndice>();
	
	private Boolean commodity;
	
	@Out(value="listaIndPagoCobro", required=false)
	private List<Subyacente> listaIndPagoCobro;
	
	public IndicesPagoCobroAction() {
		super();
	}
	public String ini(String pata){
		
		//FLM: guardamos el historico.
		//entityManager.flush();
		
		indicesFormulaList = new ArrayList<IndicesPantalla>();
		indiceFormulaSel = new IndicesPantalla();
		tiposIndice.clear();
		//SMM 02/08/2018
		commodity = false;
		if (!GenericUtils.isNullOrBlank(pata) && "CP".equalsIgnoreCase(pata)){
			pata = "P";
			commodity = true;
		}else if (!GenericUtils.isNullOrBlank(pata) && "CC".equalsIgnoreCase(pata)){
			pata = "C";
			commodity = true;
		}
		
		pata = compruebaCobrosPagosSimple(pata);
		cargaListaIndicador();
		if("P".equalsIgnoreCase(pata)){			

			tituloPanel="�ndices Pago";
			cobroPago = "P";
			if (indicesFxPagoList == null || indicesFxPagoList.size() == 0 || indicesFxPagoList.isEmpty()){
				//FLM: Aqui falla por null pointer exception, mirar que paso
				if ( historicoOperacion.getFormulaPago()!=null){
					tiposIndice.addAll(indPagoCobroBo.getDescIndice(historicoOperacion.getFormulaPago().getCodigoFormula()));
				}else {
					statusMessages.add(Severity.WARN, "La formula de pago es obligatoria");
					return Constantes.FAIL ;
				}
				llenarIndicesFormulaList();
				if(!GenericUtils.isNullOrBlank(historicoOperacion.getIndicePago())){
					if (!(indicesFormulaList == null || indicesFormulaList.size() == 0 || indicesFormulaList.isEmpty())){
						indicesFormulaList.get(0).setCodigoSubyacente(historicoOperacion.getIndicePago().getCodigo());
						indicesFormulaList.get(0).setDescripcionCorta(historicoOperacion.getIndicePago().getDescripcionCorta());
						indicesFormulaList.get(0).setDescripcionLarga(historicoOperacion.getIndicePago().getDescripcionLarga());
					}
				}
			}else {
				indicesFormulaList.addAll(indicesFxPagoList);
			}
		}else if ("C".equalsIgnoreCase(pata)){ 
			tituloPanel="�ndices Cobro";
			cobroPago = "C";
			if (indicesFxCobroList == null || indicesFxCobroList.size() == 0 || indicesFxCobroList.isEmpty()){
				if ( historicoOperacion.getFormulaRecibo()!=null){
					tiposIndice = indPagoCobroBo.getDescIndice(historicoOperacion.getFormulaRecibo().getCodigoFormula());
				}else {
					statusMessages.add(Severity.WARN,"La formula de recibo es obligatoria");
					return Constantes.FAIL ;
				}
				llenarIndicesFormulaList();
				if(!GenericUtils.isNullOrBlank(historicoOperacion.getIndiceRecibo())){
					if (!(indicesFormulaList == null || indicesFormulaList.size() == 0 || indicesFormulaList.isEmpty())){
						indicesFormulaList.get(0).setCodigoSubyacente(historicoOperacion.getIndiceRecibo().getCodigo());
						indicesFormulaList.get(0).setDescripcionCorta(historicoOperacion.getIndiceRecibo().getDescripcionCorta());
						indicesFormulaList.get(0).setDescripcionLarga(historicoOperacion.getIndiceRecibo().getDescripcionLarga());
					}
				}
				
			}else {
			indicesFormulaList.addAll(indicesFxCobroList);
			}
		}
		return Constantes.SUCCESS ;
	}
	private String compruebaCobrosPagosSimple(String pata) {
		if ( "".equalsIgnoreCase( pata ) && pagoCobroType==PagoCobroType.ES_PAGO) {
			pata = "P";
		}else if ("".equalsIgnoreCase( pata ) && pagoCobroType==PagoCobroType.ES_COBRO) {
			pata = "C";
		}
		return pata;
	}
	
	private void llenarIndicesFormulaList() {
		for(int i=0;i<tiposIndice.size();i++){			
		
		IndicesPantalla h = new IndicesPantalla();
		
		h.setLiteralIndice(tiposIndice.get(i).getId().getLiteralIndice());
		h.setTipoValorIndice(null);
		h.setCodigoSubyacente(null);
		h.setTipoFechaInicio(tiposIndice.get(i).getTipoFechaInicio());
		h.setTipoFechaFin(tiposIndice.get(i).getTipoFechaFin());

		indicesFormulaList.add(h);
		}	
	}
	
	
	@Factory(value = "listaIndPagoCobro")
	public void cargaListaIndicador(){
		listaIndPagoCobro = indPagoCobroBo.getListaIndPagoCobro(historicoOperacion.getProductoCatalogo());
		if(listaIndPagoCobro == null){
			
		}
		
	}

	public void guardarInd(){
		if (indicesFormulaList!=null ){
		
			for (IndicesPantalla indice : indicesFormulaList) {
					if (indice.getCodigoSubyacente()!=null){
						Subyacente subya  = indPagoCobroBo.cargarSubyacente(indice.getCodigoSubyacente());
						indice.setDescripcionCorta(subya.getDescripcionCorta());
						indice.setDescripcionLarga(subya.getDescripcionLarga());
					}
				}
		}
		
		if("C".equalsIgnoreCase(cobroPago)){
			indicesFxCobroList.clear();
			indicesFxCobroList.addAll(indicesFormulaList);
			
			if (indicesFormulaList!=null && indicesFormulaList.get(0)!=null && indicesFormulaList.get(0).getCodigoSubyacente() !=null){
				historicoOperacion.setIndiceRecibo(indPagoCobroBo.cargarSubyacente(indicesFormulaList.get(0).getCodigoSubyacente()));
				if (historicoOperacion.getIndiceRecibo()!=null && pagosCobrosB !=null ){
					pagosCobrosB.setIndicePagoCobro(historicoOperacion.getIndiceRecibo());
					pagosCobrosB.setDivisaLiquidacion(historicoOperacion.getIndiceRecibo().getDivisa());
					pagosCobrosB.setDivisa(historicoOperacion.getIndiceRecibo().getDivisa());

					if (historicoOperacion.getIndiceRecibo().getUnidad() != null) {
						pagosCobrosB.setUnidad(historicoOperacion.getIndiceRecibo().getUnidad().getDescripcion());
					}else{
						pagosCobrosB.setUnidad(null);
					}

				
				}
				//SMM 02/08/2018
				else if (historicoOperacion.getIndiceRecibo()!=null && GenericUtils.isNullOrBlank(pagosCobrosB) && commodity ){
					
					
					historicoOperacion.setDivisaRecibo(historicoOperacion.getIndiceRecibo().getDivisa());
					historicoOperacion.setDivisaLiquidacionRecibo(historicoOperacion.getIndiceRecibo().getDivisa());
					historicoOperacion.setDivisaPago(historicoOperacion.getIndiceRecibo().getDivisa());
					historicoOperacion.setDivisaLiquidacionPago(historicoOperacion.getIndiceRecibo().getDivisa());
					
				}
				
			}
			 

		}else if("P".equalsIgnoreCase(cobroPago)){
			indicesFxPagoList.clear();
			indicesFxPagoList.addAll(indicesFormulaList);

			if (indicesFormulaList!=null && indicesFormulaList.get(0)!=null && indicesFormulaList.get(0).getCodigoSubyacente() !=null)
			historicoOperacion.setIndicePago(indPagoCobroBo.cargarSubyacente(indicesFormulaList.get(0).getCodigoSubyacente()));
			if (historicoOperacion.getIndicePago()!=null && pagosCobrosB !=null){
				pagosCobrosB.setIndicePagoCobro(historicoOperacion.getIndicePago());
				pagosCobrosB.setDivisaLiquidacion(historicoOperacion.getIndicePago().getDivisa());
				pagosCobrosB.setDivisa(historicoOperacion.getIndicePago().getDivisa());

				if (historicoOperacion.getIndicePago().getUnidad() != null) {
					pagosCobrosB.setUnidad(historicoOperacion.getIndicePago().getUnidad().getDescripcion());
				}else{
					pagosCobrosB.setUnidad(null);
				}

			
			}
			//SMM 02/08/2018
			else if (historicoOperacion.getIndicePago()!=null && GenericUtils.isNullOrBlank(pagosCobrosB) && commodity ){
				
				
				historicoOperacion.setDivisaRecibo(historicoOperacion.getIndicePago().getDivisa());
				historicoOperacion.setDivisaLiquidacionRecibo(historicoOperacion.getIndicePago().getDivisa());
				historicoOperacion.setDivisaPago(historicoOperacion.getIndicePago().getDivisa());
				historicoOperacion.setDivisaLiquidacionPago(historicoOperacion.getIndicePago().getDivisa());
				
			}

		}		
		Conversation conversacion=Conversation.instance();
		//Volvemos al anterior
		conversacion.redirectToParent();
	}


	
	public IndPagoCobroBo getIndPagoCobroBo() {
		return indPagoCobroBo;
	}


	public void setIndPagoCobroBo(IndPagoCobroBo indPagoCobroBo) {
		this.indPagoCobroBo = indPagoCobroBo;
	}


	public String getTituloPanel() {
		return tituloPanel;
	}

	public void setTituloPanel(String tituloPanel) {
		this.tituloPanel = tituloPanel;
	}
	
	public String getCobroPago() {
		return cobroPago;
	}
	public void setCobroPago(String cobroPago) {
		this.cobroPago = cobroPago;
	}
	public HistoricoOperacion getHistoricoOperacion() {
		return historicoOperacion;
	}
	public void setHistoricoOperacion(HistoricoOperacion historicoOperacion) {
		this.historicoOperacion = historicoOperacion;
	}
	public List<DescripcionIndice> getTiposIndice() {
		return tiposIndice;
	}
	public void setTiposIndice(List<DescripcionIndice> tiposIndice) {
		this.tiposIndice = tiposIndice;
	}
	public List<Subyacente> getListaIndPagoCobro() {
		return listaIndPagoCobro;
	}
	public void setListaIndPagoCobro(
			List<Subyacente> listaIndPagoCobro) {
		this.listaIndPagoCobro = listaIndPagoCobro;
	}
	public Subyacente getIndice() {
		return indice;
	}
	public void setIndice(Subyacente indice) {
		this.indice = indice;
	}
	public List<IndicesPantalla> getIndicesFormulaList() {
		return indicesFormulaList;
	}
	public void setIndicesFormulaList(List<IndicesPantalla> indicesFormulaList) {
		this.indicesFormulaList = indicesFormulaList;
	}
	public IndicesPantalla getIndiceFormulaSel() {
		return indiceFormulaSel;
	}
	public void setIndiceFormulaSel(IndicesPantalla indiceFormulaSel) {
		this.indiceFormulaSel = indiceFormulaSel;
	}
	
	@Override
	public void salir(){
		Conversation conversacion=Conversation.instance();
		//Volvemos al anterior
		conversacion.redirectToParent();
	}

	public String salirDirecto(){

		if ( !BoletasStates.CONSULTA_BOLETA.equals( this.boletaState) ) {
			try {
				String result = boletasBo.salirOperacion("R", historicoOperacion, Identity.instance().getCredentials().getUsername());
				if (result != null) {
					String codigoValidacionErroneo = result;
					statusMessages.add(Severity.ERROR, "#{messages['boletas.edicion.error.salir.operacion']");
				}
				//FLM: boletas es un caso especial, si estamos en alta tenemos que saltar 2 parents quizas?
				return doCommonRedirect();
				//return doSalirRedirect();
			} finally {
				if (boletaState == BoletasStates.MODI_BOLETA) {
					dbLockService.desbloqueo(HistoricoOperacion.class, historicoOperacionBloqueadoId);
				}
			}

		} else { 
			return doCommonRedirect();
		}
		    

		
	}
	
private String doCommonRedirect() {
	
	
	if(forcedReturnView!=null){
		return doSalirRedirect();
	}
	if(boletaState==BoletasStates.ALTA_BOLETA){
		Conversation.instance().pop();
		return "salir";
	}
	
	Conversation conversacion=Conversation.instance();
	Conversation.instance().pop();
//	Conversation conversacion = Conversation.instance();
	//Volvemos al anterior
	conversacion.redirectToParent();
	return "";
}	

private String doSalirRedirect() {

	if ( BoletasStates.ALTA_BOLETA.equals( this.boletaState) ) {
		
    	Conversation nested =Conversation.instance();
    	Conversation.instance().pop();
    	Conversation.instance().pop();
    	
    	boolean dosSaltos= ( "/pages/adminoper/boletas/alta/altaOper.xhtml".equalsIgnoreCase( Conversation.instance().getViewId() ) );
    	
    
    	if(forcedReturnView!=null){
    		if(dosSaltos){
    			Conversation.instance().redirectToParent();
    			return "";
    		}else{
    			Conversation.instance().redirect();
    			return "";

    		}
		}
    	
    	nested.end(true);
    	if(EntityUtil.checkEntityExists(entityManager, historicoOperacion.getProductoCompuesto())){
    		return "/pages/gestionoperaciones/productocompuesto/mantProdCompuesto.xhtml";
    	}
		return "salir";
	} else {
		Conversation conversacion=Conversation.instance();
		Conversation.instance().pop();
		conversacion.redirectToParent();
		return "";
	}
}



}
