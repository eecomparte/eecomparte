package com.atosorigin.deri.adminoper.boletas.action;

import java.lang.reflect.InvocationTargetException;
import java.util.Collections;
import java.util.List;

import javax.faces.model.DataModel;

import org.apache.commons.beanutils.BeanUtils;
import org.jboss.seam.annotations.Logger;
import org.jboss.seam.contexts.Contexts;
import org.jboss.seam.core.Expressions;
import org.jboss.seam.log.Log;

import com.atosorigin.common.action.PaginatedListAction;

public abstract class ListOfValuesAction<E> extends PaginatedListAction {
	
	

	@Logger
	private Log logger;
	
	private String listName;
	private String codeFilterName;
	private String filterName;
	private String keyFieldName;
	private String descFieldName;
	private String onSelectAction;
	private Boolean initialized=false;
	private Boolean visible=false;
	private E selectedRow;
	

	public Boolean getVisible() {
		return visible;
	}

	public void setVisible(Boolean visible) {
		this.visible = visible;
	}

	public E getSelectedRow() {
		return selectedRow;
	}

	public Boolean getInitialized() {
		return initialized;
	}

	public void setInitialized(Boolean initialized) {
		this.initialized = initialized;
	}

	public String getOnSelectAction() {
		return onSelectAction;
	}

	public void setOnSelectAction(String onSelectAction) {
		this.onSelectAction = onSelectAction;
	}

	private String listOfValuesfilter;
	private String listOfValuesCodefilter;

	private DataModel dataModel;
	
	
	public String getFilter() {
		return listOfValuesfilter;
	}

	public void setFilter(String filter) {
		this.listOfValuesfilter = filter;
		Contexts.getConversationContext().set(filterName, listOfValuesfilter);
		getPaginationData().setFirstResult(0);
		refrescarLista();
	}
	public String getCodeFilter() {
		return listOfValuesfilter;
	}

	public void setCodeFilter(String filter) {
		if(hasCodeFilter()){
			this.listOfValuesCodefilter = filter;
			Contexts.getConversationContext().set(codeFilterName, listOfValuesCodefilter);
			getPaginationData().setFirstResult(0);
			refrescarLista();
		}
	}

	public boolean hasCodeFilter(){
		return codeFilterName!=null && !"".equals(codeFilterName);
	}
	@Override
	public List<E> getDataTableList() {
		// TODO Auto-generated method stub
		DataModel dataModel = getDataModel(); 
		if(dataModel==null){
			return Collections.EMPTY_LIST;
		}
		return (List<E>) dataModel.getWrappedData();
	}

	public DataModel getDataModel(){
		if(dataModel==null && initialized){
			 dataModel = (DataModel) Expressions.instance().createValueExpression("#{" + listName + "}").getValue();
		}
		return dataModel;		
	}
	@Override
	protected void refreshListInternal() {
		Contexts.getConversationContext().remove(listName);
		dataModel=null;
		refrescaDataModel();
	}

	protected abstract void refrescaDataModel();

	public ListOfValuesAction(String listName,  String filterName,
			String keyFieldName, String descFieldName, String onSelectAction) {
		this(listName, null, filterName, keyFieldName, descFieldName, onSelectAction);
	}
	public ListOfValuesAction(String listName, String codeFilterName,  String filterName,
			String keyFieldName, String descFieldName, String onSelectAction) {
		super();
		this.listName = listName;
		this.filterName = filterName;
		this.keyFieldName = keyFieldName;
		this.descFieldName = descFieldName;
		this.onSelectAction = onSelectAction;
		this.codeFilterName = codeFilterName;
	}

	@Override
	public void refrescarListaExcel() {
		// TODO Auto-generated method stub

	}

	@Override
	public abstract void setDataTableList(List<?> dataTableList);
	
	
	public void buscar(){
		initialized=true;
		Contexts.getConversationContext().remove(listName);
	}
	public String getKeyValue(E row){
		try {
			//FLM: 1640
			if (row==null)
				return "";
			return BeanUtils.getSimpleProperty(row, keyFieldName).toString();
		} catch (IllegalAccessException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (InvocationTargetException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (NoSuchMethodException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return "";
	}
	public String getDescValue(E row){
		try {
			//FLM: 1640
			if (row==null)
				return "";
			if (BeanUtils.getSimpleProperty(row, descFieldName)==null) return "";
			return BeanUtils.getSimpleProperty(row, descFieldName).toString();
		} catch (IllegalAccessException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (InvocationTargetException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (NoSuchMethodException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return "";
	}

	public void onSelect(){
		if(dataModel.isRowAvailable()){
			selectedRow = (E) dataModel.getRowData();
		}
		else{
			selectedRow=null;
		}
		Expressions.instance().createMethodExpression("#{" + onSelectAction+ "}").invoke();
		visible=false;
		//dataModel = null;
	}
}
