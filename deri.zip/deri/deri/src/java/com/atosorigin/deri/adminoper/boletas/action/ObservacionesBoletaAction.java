package com.atosorigin.deri.adminoper.boletas.action;

import javax.persistence.EntityManager;

import org.jboss.seam.ScopeType;
import org.jboss.seam.annotations.In;
import org.jboss.seam.annotations.Name;
import org.jboss.seam.annotations.Out;
import org.jboss.seam.annotations.Scope;
import org.jboss.seam.core.Conversation;
import org.jboss.seam.international.StatusMessage.Severity;
import org.jboss.seam.security.Identity;

import com.atosorigin.common.action.GenericAction;
import com.atosorigin.deri.adminoper.boletas.action.BoletasAction.BoletasStates;
import com.atosorigin.deri.adminoper.boletas.business.BoletasBo;
import com.atosorigin.deri.common.dbLock.DbLockService;
import com.atosorigin.deri.model.gestionoperaciones.HistoricoOperacion;
import com.atosorigin.deri.model.gestionoperaciones.HistoricoOperacionId;
import com.atosorigin.deri.util.EntityUtil;

@Name("observacionesAction")
@Scope(ScopeType.CONVERSATION)
public class ObservacionesBoletaAction extends GenericAction implements java.io.Serializable{

	private static final long serialVersionUID = -952934366441814856L;
	private String perLiqPago;
	private String tipoFlotantePago;
	private String perLiqCobro;
	private String tipoFlotanteCobro;
	private String observaciones;
	private String notasCanc;
	private boolean inicio = true;
	
	@In
	@Out(value="historicoOperacion")
	private HistoricoOperacion historicoOperacion;

	@In(required=false)
	HistoricoOperacionId historicoOperacionBloqueadoId;

	@In
	private BoletasStates boletaState;
	
	@In(value = "dbLockService", create = true)
	private DbLockService dbLockService;

	@In(required=false)
	private String forcedReturnView;
	
	@In
	private EntityManager entityManager;
	
	@In("#{boletasBo}")
	protected BoletasBo boletasBo;

	public void ini(){
		
		if(inicio){
			perLiqPago = historicoOperacion.getObservacionesPago1();	
			tipoFlotantePago = historicoOperacion.getObservacionesPago2();
			perLiqCobro = historicoOperacion.getObservacionesRecibo1();
			tipoFlotanteCobro = historicoOperacion.getObservacionesRecibo2();
			observaciones = historicoOperacion.getObservacionesOperacion();
			notasCanc = historicoOperacion.getObservacionesCancelacion();
		}
		inicio = false;
	}
	
	
	public void guardarObs(){
		historicoOperacion.setObservacionesPago1(perLiqPago);
		historicoOperacion.setObservacionesPago2(tipoFlotantePago);
		historicoOperacion.setObservacionesRecibo1(perLiqCobro);
		historicoOperacion.setObservacionesRecibo2(tipoFlotanteCobro);
		historicoOperacion.setObservacionesOperacion(observaciones);
		historicoOperacion.setObservacionesCancelacion(notasCanc);
		
		inicio = true;
	}
	
	public boolean fieldIsDisabled(){
		return(boletaState == BoletasStates.CONSULTA_BOLETA);
	}
	
	public String getPerLiqPago() {
		return perLiqPago;

	}
	public void setPerLiqPago(String perLiqPago) {
		this.perLiqPago = perLiqPago;
		
	}
	public String getTipoFlotantePago() {
		return tipoFlotantePago;
		
	}
	public void setTipoFlotantePago(String tipoFlotantePago) {
		this.tipoFlotantePago = tipoFlotantePago;
		
	}
	public String getPerLiqCobro() {
		return perLiqCobro;
		
	}
	public void setPerLiqCobro(String perLiqCobro) {
		this.perLiqCobro = perLiqCobro;
		
	}
	public String getTipoFlotanteCobro() {
		return tipoFlotanteCobro;
	
	}
	public void setTipoFlotanteCobro(String tipoFlotanteCobro) {
		this.tipoFlotanteCobro = tipoFlotanteCobro;
		
	}
	public String getObservaciones() {
		return observaciones;
	}
	public void setObservaciones(String observaciones) {
		this.observaciones = observaciones;
		
	}
	public String getNotasCanc() {
		return notasCanc;
		
	}
	public void setNotasCanc(String notasCanc) {
		this.notasCanc = notasCanc;
		
	}
	public HistoricoOperacion getHistoricoOperacion() {
		return historicoOperacion;
	}
	public void setHistoricoOperacion(HistoricoOperacion historicoOperacion) {
		this.historicoOperacion = historicoOperacion;
	}
	public BoletasStates getBoletaState() {
		return boletaState;
	}
	public void setBoletaState(BoletasStates boletaState) {
		this.boletaState = boletaState;
	}

	public boolean isInicio() {
		return inicio;
	}


	public void setInicio(boolean inicio) {
		this.inicio = inicio;
	}
	


	public String salirDirecto(){

		if ( !BoletasStates.CONSULTA_BOLETA.equals( this.boletaState) ) {
			try {
				String result = boletasBo.salirOperacion("R", historicoOperacion, Identity.instance().getCredentials().getUsername());
				if (result != null) {
					String codigoValidacionErroneo = result;
					statusMessages.add(Severity.ERROR, "#{messages['boletas.edicion.error.salir.operacion']");
				}
				//FLM: boletas es un caso especial, si estamos en alta tenemos que saltar 2 parents quizas?
				return doCommonRedirect();
				//return doSalirRedirect();
			} finally {
				if (boletaState == BoletasStates.MODI_BOLETA) {
					dbLockService.desbloqueo(HistoricoOperacion.class, historicoOperacionBloqueadoId);
				}
			}

		} else { 
			return doCommonRedirect();
		}
		    

		
	}
	
private String doCommonRedirect() {
	
	
	if(forcedReturnView!=null){
		return doSalirRedirect();
	}
	if(boletaState==BoletasStates.ALTA_BOLETA){
		Conversation.instance().pop();
		return "salir";
	}
	
	Conversation conversacion=Conversation.instance();
	Conversation.instance().pop();
//	Conversation conversacion = Conversation.instance();
	//Volvemos al anterior
	conversacion.redirectToParent();
	return "";
}	

private String doSalirRedirect() {

	if ( BoletasStates.ALTA_BOLETA.equals( this.boletaState) ) {
		
    	Conversation nested =Conversation.instance();
    	Conversation.instance().pop();
    	Conversation.instance().pop();
    	
    	boolean dosSaltos= ( "/pages/adminoper/boletas/alta/altaOper.xhtml".equalsIgnoreCase( Conversation.instance().getViewId() ) );
    	
    
    	if(forcedReturnView!=null){
    		if(dosSaltos){
    			Conversation.instance().redirectToParent();
    			return "";
    		}else{
    			Conversation.instance().redirect();
    			return "";

    		}
		}
    	
    	nested.end(true);
    	if(EntityUtil.checkEntityExists(entityManager, historicoOperacion.getProductoCompuesto())){
    		return "/pages/gestionoperaciones/productocompuesto/mantProdCompuesto.xhtml";
    	}
		return "salir";
	} else {
		Conversation conversacion=Conversation.instance();
		Conversation.instance().pop();
		conversacion.redirectToParent();
		return "";
	}
}










}
