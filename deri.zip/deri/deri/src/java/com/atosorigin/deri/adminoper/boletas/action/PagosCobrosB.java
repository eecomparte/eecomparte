/**
 * 
 */
package com.atosorigin.deri.adminoper.boletas.action;

import java.math.BigDecimal;

import org.apache.commons.beanutils.BeanUtils;
import org.apache.commons.beanutils.PropertyUtils;
import org.jboss.seam.log.Log;
import org.jboss.seam.log.Logging;

import com.atosorigin.deri.adminoper.boletas.action.BoletasAction.PagoCobroType;
import com.atosorigin.deri.dao.mercado.DescripcionFormula;
import com.atosorigin.deri.model.catalogo.DescripcionTipoAjuste;
import com.atosorigin.deri.model.gestionoperaciones.HistoricoOperacion;
import com.atosorigin.deri.model.gestionoperaciones.HistoricoOperacion.Ajustes;
import com.atosorigin.deri.model.gestiontesoreria.BaseCalculo;
import com.atosorigin.deri.model.gestiontesoreria.TipoCurva;
import com.atosorigin.deri.model.mercado.Plazo;
import com.atosorigin.deri.model.mercado.Subyacente;
import com.atosorigin.deri.model.parametrizacion.Divisa;

public class PagosCobrosB{
	private Log logger = Logging.getLog(PagosCobrosB.class);
	private HistoricoOperacion historicoOperacion;
	private String unidad;
	private PagoCobroType pagoCobroType;
	public PagoCobroType getPagoCobroType() {
		return pagoCobroType;
	}
	public void setPagoCobroType(PagoCobroType pagoCobroType) {
		this.pagoCobroType = pagoCobroType;
	}	
	public String getUnidad() {
		return unidad;
	}
	public void setUnidad(String unidad) {
		this.unidad = unidad;
	}
	public PagosCobrosB(
			BoletasAction boletasAction) {
		super();
		this.historicoOperacion = boletasAction.historicoOperacion;
	}
	public HistoricoOperacion getHistoricoOperacion() {
		return historicoOperacion;
	}
	public void setHistoricoOperacion(HistoricoOperacion historicoOperacion) {
		this.historicoOperacion = historicoOperacion;
	}
	private Object getPropertyValue(String namePago, String nameCobro){
		if(historicoOperacion==null){
			return null;
		}
		try {
			if(pagoCobroType==PagoCobroType.ES_PAGO){
				return PropertyUtils.getSimpleProperty(historicoOperacion, namePago);
			}
			if(pagoCobroType==PagoCobroType.ES_COBRO){
				return PropertyUtils.getSimpleProperty(historicoOperacion, nameCobro);
			}
		} catch (Exception e) {
			logger.trace("No se ha establecido el tipo de transaccion");
		}
		return null;
		
	}
	private void setPropertyValue(String namePago, String nameCobro, Object value){
		if(historicoOperacion==null){
			return;
		}
		try {
			if(pagoCobroType==PagoCobroType.ES_PAGO){
				BeanUtils.setProperty(historicoOperacion, namePago, value);
			}
			if(pagoCobroType==PagoCobroType.ES_COBRO){
				BeanUtils.setProperty(historicoOperacion, nameCobro, value);
			}
		} catch (Exception e) {
			logger.trace("No se ha establecido el tipo de transaccion");
		}
	}
	private Object getPropertyValue(String name){
		return getPropertyValue(name + "Pago", name + "Recibo");
	}
	private void setPropertyValue(String name, Object value){
		setPropertyValue(name + "Pago", name + "Recibo", value);
	}
	public Subyacente getIndicePagoCobro(){
		return (Subyacente) getPropertyValue("indice");
	}
	public void setIndicePagoCobro(Subyacente subyacente){
		setPropertyValue("indice", subyacente);
	}
	public Divisa getDivisa() {
		return (Divisa) getPropertyValue("divisa");
	}
	public void setDivisa(Divisa divisa) {
		setPropertyValue("divisa", divisa);
	}
	public Plazo getFrecuencia(){
		return (Plazo) getPropertyValue("frecuencia");
	}
	public void setFrecuencia(Plazo plazo){
		setPropertyValue("frecuencia", plazo);
	}
	public Divisa getDivisaLiquidacion() {
		return (Divisa) getPropertyValue("divisaLiquidacion");
	}
	public void setDivisaLiquidacion(Divisa divisa) {
		setPropertyValue("divisaLiquidacion", divisa);
	}
	public BigDecimal getNominal(){
		return (BigDecimal) getPropertyValue("nominal");
	}
	public void setNominal(BigDecimal nominal){
		setPropertyValue("nominal", nominal);
	}
	
	public BigDecimal getStrike(){
		return (BigDecimal) getPropertyValue("strike");
	}
	public void setStrike(BigDecimal strike){
		setPropertyValue("strike", strike);
	}
	public DescripcionFormula getFormula(){
		return (DescripcionFormula) getPropertyValue("formula");
	}
	public void setFormula(DescripcionFormula formula){
		setPropertyValue("formula", formula);
	}
	public BaseCalculo getBaseCalculo(){
		return (BaseCalculo) getPropertyValue("baseCalculo");
	}
	public void setBaseCalculo(BaseCalculo baseCalculo){
		setPropertyValue("baseCalculo", baseCalculo);
	}
	public Byte getDiasFixing(){
		return (Byte) getPropertyValue("diasFixing");
	}
	public void setDiasFixing(Byte diasFixing){
		setPropertyValue("diasFixing", diasFixing);
	}
	public DescripcionTipoAjuste getAjusteDias(){
		return (DescripcionTipoAjuste) getPropertyValue("ajusteDias");
	}
	public void setAjusteDias(DescripcionTipoAjuste descripcionTipoAjuste){
		setPropertyValue("ajusteDias", descripcionTipoAjuste);
	}
	public Ajustes getIndicadorAjuste(){
		return (Ajustes) getPropertyValue("indicadorAjuste");
	}
	public void setIndicadorAjuste(Ajustes ajustes){
		setPropertyValue("indicadorAjuste", ajustes);
	}
	public TipoCurva getTipoCurva(){
		return (TipoCurva) getPropertyValue("tipoCurva");
	}
	public void setTipoCurva(TipoCurva tipoCurva){
		setPropertyValue("tipoCurva", tipoCurva);
	}
}