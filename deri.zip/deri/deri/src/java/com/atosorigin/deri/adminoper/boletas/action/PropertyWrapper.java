package com.atosorigin.deri.adminoper.boletas.action;

import java.lang.reflect.ParameterizedType;
import java.lang.reflect.Type;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.apache.commons.beanutils.ConvertUtils;
import org.apache.commons.beanutils.Converter;
import org.apache.commons.beanutils.PropertyUtils;


public class PropertyWrapper<E> {
	private Object delegate;
	private String propertyName;
	private E value;
	private E oldValue;
	private Boolean changed=false;
	static{
		ConvertUtils.register(new Converter(){
			public Object convert(Class clazz, Object value) {
				if(value instanceof Date){
					return value;
				}
				if(value instanceof String){
					SimpleDateFormat sdf=new SimpleDateFormat("dd/MM/yyyy");
					try {
						return sdf.parse((String)value);
					} catch (ParseException e) {
						System.out.print(e); ;//no problem						
					}
				}
				return null;
			}
			
		}, Date.class);

	}

	public PropertyWrapper(Object delegate, String propertyName) {
		super();
		this.delegate = delegate;
		this.propertyName = propertyName;
		this.changed= true;
		refresh();
	}
	public E getOldValue() {
		return oldValue;
	}
	public Boolean getChanged() {
		return changed;
	}
	public void setChanged(Boolean changed) {
		this.changed = changed;
	}
	public E getValue() {
		return value;
	}
	public Object getDelegate() {
		return delegate;
	}
	public void setDelegate(Object delegate) {
		this.delegate = delegate;
	}
	
	public void setValue(E value) {
		oldValue=this.value;
		this.value=checkValue(value);
		try {
			PropertyUtils.setNestedProperty(delegate, propertyName, value);
		} catch (Exception e) {
			//System.out.print(e); ;//no problem
		}
		changed=hasChanged();
	}
	private E checkValue(E value){
		if(getTipo().equals(String.class)){
			return value;
		}
		if(value==null||"".equals(value)){
			return null;
		}
		if(value instanceof String && value!=null){
			return  parseString((String) value);
		}
		return value;

	}

	private  Boolean hasChanged(){
		if(oldValue==null && value!=null){
			return true;
		}
		if(oldValue!=null && value==null){
			return true;
		}
		if(oldValue==null && value==null){
			return false;
		}
		return !value.equals(oldValue);
	}
	protected E parseString(String value2) {
		Object convert = ConvertUtils.convert(value2, getTipo());
		return (E) convert;
	}
	private Class<?> getTipo() {
		Type genericSuperclass = getClass().getGenericSuperclass();
		while(genericSuperclass instanceof Class<?>) 
			genericSuperclass = ((Class<?>)genericSuperclass).getGenericSuperclass();
		if(genericSuperclass instanceof ParameterizedType) {
			ParameterizedType pType = (ParameterizedType) genericSuperclass;
			return (Class)pType.getActualTypeArguments()[0];
		}
		
		return null;
	}
	public void refresh(){
		try {
			Object propertyValue = PropertyUtils.getNestedProperty(delegate, propertyName);
			if(propertyValue!=null){
				this.value=(E)propertyValue;
			} else
				this.value=null;
		} catch (org.apache.commons.beanutils.NestedNullException nula) {
			this.value=null; //Ok, puede ser nulo 
		} catch (Exception ex){
			System.out.print(ex); ;//no problem
		}
	}
	public void reset(){
		setValue(oldValue);
		this.changed=false;
	}
	

}
