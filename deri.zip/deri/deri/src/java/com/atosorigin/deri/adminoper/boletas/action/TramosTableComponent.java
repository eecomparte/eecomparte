package com.atosorigin.deri.adminoper.boletas.action;

import java.util.ArrayList;
import java.util.List;

import com.atosorigin.deri.model.mercado.TramosTable;

public class TramosTableComponent {
	private List<TramosTable> tramosTableList = new ArrayList<TramosTable>();

	public List<TramosTable> getTramosTableList() {
		return tramosTableList;
	}

	public void setTramosTableList(List<TramosTable> tramosTableList) {
		this.tramosTableList = tramosTableList;
	}	

	
}
