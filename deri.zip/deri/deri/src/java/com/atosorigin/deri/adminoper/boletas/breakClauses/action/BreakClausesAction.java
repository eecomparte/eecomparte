package com.atosorigin.deri.adminoper.boletas.breakClauses.action;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.jboss.seam.ScopeType;
import org.jboss.seam.annotations.In;
import org.jboss.seam.annotations.Logger;
import org.jboss.seam.annotations.Name;
import org.jboss.seam.annotations.Out;
import org.jboss.seam.annotations.Scope;
import org.jboss.seam.annotations.datamodel.DataModel;
import org.jboss.seam.annotations.datamodel.DataModelSelection;
import org.jboss.seam.core.Conversation;
import org.jboss.seam.international.StatusMessage.Severity;
import org.jboss.seam.log.Log;
import org.jboss.seam.security.Credentials;
import org.springframework.beans.BeanUtils;

import com.atosorigin.common.action.PaginatedListAction;
import com.atosorigin.common.constantes.Constantes;
import com.atosorigin.deri.adminoper.boletas.action.BoletasAction.BoletasStates;
import com.atosorigin.deri.adminoper.mantfechas.business.HistoricoFechaFormulaBo;
import com.atosorigin.deri.model.gestionoperaciones.HistoricoFechaFormula;
import com.atosorigin.deri.model.gestionoperaciones.HistoricoFechaFormulaId;
import com.atosorigin.deri.model.gestionoperaciones.HistoricoOperacion;
import com.atosorigin.deri.util.InterceptExceptions;

/**
 * Clase action listener para el caso de uso de consulta operaciones asociadas en datos de mercado.
 */
@Name("breakClausesAction")
@Scope(ScopeType.CONVERSATION)
@InterceptExceptions
public class BreakClausesAction extends PaginatedListAction{
	
	public enum BreakClauseMode{ALTA,MODIF,DETAIL}
	
	public final String TIPO_FECHA_BREAK_CLAUSE = "BC";
	
	@Logger
	private Log log;

	@In("#{historicoFechaFormulaBo}")
	protected HistoricoFechaFormulaBo breakClausesBo;
	
	@In(required=true)
	private BoletasStates boletaState;
	
	@In
	private HistoricoOperacion historicoOperacion;
	
	@In
	private Credentials credentials;
	
	@DataModel(value="listaBreakClausesList")
	private List<HistoricoFechaFormula> listaBreakClauses;
	
	@DataModelSelection(value="listaBreakClausesList")
	private HistoricoFechaFormula breakClauseSelected;
	
	@Out(required=false)
	private HistoricoFechaFormula breakClause;
	
	@Out(required=false)
	private BreakClauseMode breakClauseMode;

	private HistoricoFechaFormula breakClauseCopia;

	
	public BreakClausesAction() {
		//Añadimos una validacion para cargar correctamente el importe los datos
		
	}

	/*public String salirSearch(){
		//Conversation conv= Conversation.instance();
		//conv.redirectToParent();
		return Constantes.CONSTANTE_SUCCESS;
	}*/
	
	public void salir(){
		Conversation conv= Conversation.instance();
		//conv.endBeforeRedirect(); 
		conv.redirectToParent();
	}

	@Override
	public List<?> getDataTableList() {
		// TODO Auto-generated method stub
		return listaBreakClauses;
	}

	@Override
	protected void refreshListInternal() {
		//paginationData.reset();
		setExportExcel(false);
		
		if(listaBreakClauses==null || listaBreakClauses.size()==0){
			listaBreakClauses = new ArrayList<HistoricoFechaFormula>();
		}
		listaBreakClauses.clear();
		listaBreakClauses = breakClausesBo.obtenerFechasSeleccion(historicoOperacion,TIPO_FECHA_BREAK_CLAUSE,paginationData);
		
	}

	@Override
	public void refrescarListaExcel() {
		paginationData.reset();
		setExportExcel(true);
		
		if(listaBreakClauses==null || listaBreakClauses.size()==0){
			listaBreakClauses = new ArrayList<HistoricoFechaFormula>();
		}
		listaBreakClauses.clear();
		listaBreakClauses = breakClausesBo.obtenerFechasSeleccion(historicoOperacion,TIPO_FECHA_BREAK_CLAUSE,paginationData.getPaginationDataForExcel());
		
	}

	@Override
	public void setDataTableList(List<?> dataTableList) {
		// TODO Auto-generated method stub
		
	}
	
	public String modificaBreakClause(){
		breakClauseCopia = breakClauseSelected;
		breakClause = new HistoricoFechaFormula();
		BeanUtils.copyProperties(breakClauseSelected,breakClauseCopia);
		HistoricoFechaFormulaId id = new HistoricoFechaFormulaId();
		
		id.setHistoricoOperacion(breakClauseCopia.getId().getHistoricoOperacion());
		id.setTipoFecha(breakClauseCopia.getId().getTipoFecha());
		id.setFechaInicio(breakClauseCopia.getId().getFechaInicio());
		id.setFechaFin(breakClauseCopia.getId().getFechaFin());
		breakClause.setId(id);
		breakClause.setAuditData(breakClauseCopia.getAuditData());

		// Detach del la còpia
		breakClausesBo.detach(breakClause);

		breakClauseMode = BreakClauseMode.MODIF;
		return Constantes.CONSTANTE_SUCCESS;
	}
	
	public String verBreakClause(){
		breakClause = breakClauseSelected;
		breakClauseMode = BreakClauseMode.DETAIL;
		return Constantes.CONSTANTE_SUCCESS;
	}

	public String createBreakClause(){
		//Creamos una nueva BreakClause en modo ALTA
		breakClause = new HistoricoFechaFormula(new HistoricoFechaFormulaId());
		breakClause.getId().setHistoricoOperacion(historicoOperacion);
		breakClause.getId().setTipoFecha(TIPO_FECHA_BREAK_CLAUSE);
		breakClauseMode = BreakClauseMode.ALTA;
		return Constantes.CONSTANTE_SUCCESS;
	}
	
	//public String borrarRegistro(){
	public void borrarRegistro(){
		breakClausesBo.delete(breakClauseSelected);
		refrescarLista();
		//return Constantes.CONSTANTE_SUCCESS;
	}

	public void prepareBreakClauses(){
		if(!breakClauseMode.equals(BreakClauseMode.ALTA)){

		}else{

		}
	}

	public boolean modeAlta(){
		return breakClauseMode.equals(BreakClauseMode.ALTA); 
	}
	
	public boolean modeEdit(){
		return breakClauseMode.equals(BreakClauseMode.MODIF); 
	}
	
	public boolean modeRead(){
		return breakClauseMode.equals(BreakClauseMode.DETAIL); 
	}
	
	public String alta(){
		//TODO validaciones
		Date fechaEjecucion = breakClause.getId().getFechaInicio();
		Date fechaNotificacion = breakClause.getId().getFechaFin();
		//La fecha de notificación anterior a la fecha de ejecución
		if(null!=fechaNotificacion && fechaNotificacion.after(fechaEjecucion)){
			statusMessages.add(Severity.ERROR, "#{messages['breakClauses.alta.notificacion.anterior.ejecucion']}", Constantes.DEFAULT_MESSAGE_TEMPLATE);
			return Constantes.CONSTANTE_FAIL;
		}
		//fecha ejecucion y notificacion deben estar entre fecha valor y fecha vencimiento
		Date fechaValor= breakClause.getId().getHistoricoOperacion().getFechaValor();
		Date fechaVencimiento= breakClause.getId().getHistoricoOperacion().getFechaVencimiento();
		if(fechaEjecucion.before(fechaValor) || fechaEjecucion.after(fechaVencimiento) ||
				(null!=fechaNotificacion &&fechaNotificacion.before(fechaValor)) || (null!=fechaNotificacion &&fechaNotificacion.after(fechaVencimiento))){

			statusMessages.add(Severity.ERROR, "#{messages['breakClauses.alta.fechas.entre.valor.vencimiento']}", Constantes.DEFAULT_MESSAGE_TEMPLATE);
			return Constantes.CONSTANTE_FAIL;
		}
		
		//No se pueden repetir fechas de ejecucion
		if(breakClausesBo.existenFechasSeleccionRepetidas(historicoOperacion,TIPO_FECHA_BREAK_CLAUSE,fechaEjecucion,fechaNotificacion,breakClauseCopia,breakClauseMode.name())){
			statusMessages.add(Severity.ERROR, "#{messages['breakClauses.alta.fechas.ejecucion.repetidas']}", Constantes.DEFAULT_MESSAGE_TEMPLATE);
			return Constantes.CONSTANTE_FAIL;
		}
		
		String usuario = credentials.getUsername();
		breakClause.getAuditData().setUsuarioUltimaModi(usuario);

		if(!breakClauseMode.equals(BreakClauseMode.ALTA)){
			if(!breakClauseCopia.getId().equals(breakClause.getId())){
				breakClausesBo.deleteOld(breakClauseCopia);
				breakClausesBo.guardarNuevo(breakClause);
			}
		}else{
			breakClausesBo.guardarNuevo(breakClause);
		}
		salir();
		return Constantes.CONSTANTE_SUCCESS;
	}
	
	public String getMessageByMode(String creacion, String edicion, String inspeccion) {
		if (breakClauseMode.equals(BreakClauseMode.ALTA)) {
			return creacion;
		} else if (breakClauseMode.equals(BreakClauseMode.MODIF)) {
			return edicion;
		} else if (breakClauseMode.equals(BreakClauseMode.DETAIL)) {
			return inspeccion;
		} else {
			return Constantes.CADENA_VACIA;
		}		
	}


	
	public Log getLog() {
		return log;
	}

	public void setLog(Log log) {
		this.log = log;
	}

	public HistoricoFechaFormulaBo getBreakClausesBo() {
		return breakClausesBo;
	}

	public void setBreakClausesBo(HistoricoFechaFormulaBo breakClausesBo) {
		this.breakClausesBo = breakClausesBo;
	}

	public BoletasStates getBoletaState() {
		return boletaState;
	}

	public void setBoletaState(BoletasStates boletaState) {
		this.boletaState = boletaState;
	}

	public HistoricoOperacion getHistoricoOperacion() {
		return historicoOperacion;
	}

	public void setHistoricoOperacion(HistoricoOperacion historicoOperacion) {
		this.historicoOperacion = historicoOperacion;
	}

	public List<HistoricoFechaFormula> getListaBreakClauses() {
		return listaBreakClauses;
	}

	public void setListaBreakClauses(List<HistoricoFechaFormula> listaBreakClauses) {
		this.listaBreakClauses = listaBreakClauses;
	}

	public HistoricoFechaFormula getBreakClauseSelected() {
		return breakClauseSelected;
	}

	public void setBreakClauseSelected(HistoricoFechaFormula breakClauseSelected) {
		this.breakClauseSelected = breakClauseSelected;
	}

	public HistoricoFechaFormula getBreakClause() {
		return breakClause;
	}

	public void setBreakClause(HistoricoFechaFormula breakClause) {
		this.breakClause = breakClause;
	}

	public BreakClauseMode getBreakClauseMode() {
		return breakClauseMode;
	}

	public void setBreakClauseMode(BreakClauseMode breakClauseMode) {
		this.breakClauseMode = breakClauseMode;
	}
	
	/*GETTERS Y SETTERS*/

}
