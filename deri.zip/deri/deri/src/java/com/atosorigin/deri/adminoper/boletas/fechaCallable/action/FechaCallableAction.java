package com.atosorigin.deri.adminoper.boletas.fechaCallable.action;

import java.util.ArrayList;
import java.util.List;

import org.jboss.seam.ScopeType;
import org.jboss.seam.annotations.In;
import org.jboss.seam.annotations.Logger;
import org.jboss.seam.annotations.Name;
import org.jboss.seam.annotations.Out;
import org.jboss.seam.annotations.Scope;
import org.jboss.seam.annotations.datamodel.DataModel;
import org.jboss.seam.annotations.datamodel.DataModelSelection;
import org.jboss.seam.core.Conversation;
import org.jboss.seam.log.Log;

import com.atosorigin.common.action.PaginatedListAction;
import com.atosorigin.common.constantes.Constantes;
import com.atosorigin.deri.adminoper.boletas.action.BoletasAction.BoletasStates;
import com.atosorigin.deri.adminoper.boletas.fechaCallable.bussiness.FechaCallableBo;
import com.atosorigin.deri.model.adminoper.FechaCallable;
import com.atosorigin.deri.model.adminoper.FechaCallableId;
import com.atosorigin.deri.model.gestionoperaciones.HistoricoOperacion;
import com.atosorigin.deri.util.InterceptExceptions;

/**
 * Clase action listener para el caso de uso de consulta operaciones asociadas en datos de mercado.
 */
@Name("fechaCallableAction")
@Scope(ScopeType.CONVERSATION)
@InterceptExceptions
public class FechaCallableAction extends PaginatedListAction{
	
	public enum FechaCallableMode{ALTA,MODIF,DETAIL}
	
	@Logger
	private Log log;

	@In("#{fechaCallableBo}")
	protected FechaCallableBo fechaCallableBo;
	
	@In(required=true)
	private BoletasStates boletaState;
	
	@In
	private HistoricoOperacion historicoOperacion;
	
	@DataModel(value="listaFCallableList")
	private List<FechaCallable> listaFechaCallable;
	
	@DataModelSelection(value="listaFCallableList")
	private FechaCallable fCallableSelected;
	
	@Out(required=false)
	private FechaCallable fechaCallable;
	
	@Out(required=false)
	private FechaCallableMode fechaCallableMode;
	
	public FechaCallableAction() {
		//Añadimos una validacion para cargar correctamente el importe los datos
		
	}

	public void salir(){
		Conversation conv= Conversation.instance();
		//conv.endBeforeRedirect(); 
		conv.redirectToParent();
	}
	
	@Override
	public List<?> getDataTableList() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	protected void refreshListInternal() {
		paginationData.reset();
		setExportExcel(false);
		
		if(listaFechaCallable==null){
			listaFechaCallable = new ArrayList<FechaCallable>();
		}
		listaFechaCallable.clear();
		listaFechaCallable = fechaCallableBo.getListFechasCallables(historicoOperacion);
	}

	@Override
	public void refrescarListaExcel() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void setDataTableList(List<?> dataTableList) {
		// TODO Auto-generated method stub
		
	}
	
	public String modificaFCallable(){
		fechaCallable = fCallableSelected;
		fechaCallableMode = FechaCallableMode.MODIF;
		return Constantes.CONSTANTE_SUCCESS;
	}
	
	public String verFCallable(){
		fechaCallable = fCallableSelected;
		fechaCallableMode = FechaCallableMode.DETAIL;
		return Constantes.CONSTANTE_SUCCESS;
	}

	public String createFCallable(){
		//Creamos una nueva FechaCallable para el modo ALTA
		fechaCallable = new FechaCallable(new FechaCallableId());
		fechaCallable.getFechaCallableId().setFechaope(historicoOperacion.getId().getFechaContratacion());
		fechaCallable.getFechaCallableId().setNcorrela(historicoOperacion.getId().getNumeroOperacion());
		fechaCallableMode = FechaCallableMode.ALTA;
		return Constantes.CONSTANTE_SUCCESS;
	}
	
	public void borrarRegistro(){
		fechaCallableBo.delete(fCallableSelected);
	}
	
	/*GETTERS Y SETTERS*/

	public BoletasStates getBoletaState() {
		return boletaState;
	}


	public void setBoletaState(BoletasStates boletaState) {
		this.boletaState = boletaState;
	}

	public List<FechaCallable> getListaFechaCallable() {
		return listaFechaCallable;
	}

	public void setListaFechaCallable(List<FechaCallable> listaFechaCallable) {
		this.listaFechaCallable = listaFechaCallable;
	}

	public FechaCallable getfCallableSelected() {
		return fCallableSelected;
	}

	public void setfCallableSelected(FechaCallable fCallableSelected) {
		this.fCallableSelected = fCallableSelected;
	}

	public Log getLog() {
		return log;
	}

	public void setLog(Log log) {
		this.log = log;
	}

	public HistoricoOperacion getHistoricoOperacion() {
		return historicoOperacion;
	}

	public void setHistoricoOperacion(HistoricoOperacion historicoOperacion) {
		this.historicoOperacion = historicoOperacion;
	}

	public FechaCallable getFechaCallable() {
		return fechaCallable;
	}

	public void setFechaCallable(FechaCallable fechaCallable) {
		this.fechaCallable = fechaCallable;
	}

	public FechaCallableMode getFechaCallableMode() {
		return fechaCallableMode;
	}

	public void setFechaCallableMode(FechaCallableMode fechaCallableMode) {
		this.fechaCallableMode = fechaCallableMode;
	}
}
