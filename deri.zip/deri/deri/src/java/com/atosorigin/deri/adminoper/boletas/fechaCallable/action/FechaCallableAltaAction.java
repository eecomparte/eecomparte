package com.atosorigin.deri.adminoper.boletas.fechaCallable.action;

import java.math.BigDecimal;
import java.util.List;

import org.jboss.seam.ScopeType;
import org.jboss.seam.annotations.Factory;
import org.jboss.seam.annotations.In;
import org.jboss.seam.annotations.Logger;
import org.jboss.seam.annotations.Name;
import org.jboss.seam.annotations.Out;
import org.jboss.seam.annotations.Scope;
import org.jboss.seam.core.Conversation;
import org.jboss.seam.international.StatusMessage.Severity;
import org.jboss.seam.log.Log;

import com.atosorigin.common.action.GenericAction;
import com.atosorigin.common.constantes.Constantes;
import com.atosorigin.common.utils.GenericUtils;
import com.atosorigin.deri.adminoper.boletas.action.BoletasAction.BoletasStates;
import com.atosorigin.deri.adminoper.boletas.business.BoletasBo;
import com.atosorigin.deri.adminoper.boletas.fechaCallable.action.FechaCallableAction.FechaCallableMode;
import com.atosorigin.deri.adminoper.boletas.fechaCallable.bussiness.FechaCallableBo;
import com.atosorigin.deri.model.adminoper.FechaCallable;
import com.atosorigin.deri.model.adminoper.FechaCallable.CobroPago;
import com.atosorigin.deri.model.adminoper.FechaCallable.ObligOpc;
import com.atosorigin.deri.model.adminoper.FechaCallable.SentidoAmort;
import com.atosorigin.deri.model.adminoper.FechaCallable.TipoCanc;
import com.atosorigin.deri.model.gestionoperaciones.HistoricoOperacion;
import com.atosorigin.deri.model.parametrizacion.Divisa;
import com.atosorigin.deri.util.InterceptExceptions;

/**
 * Clase action listener para el caso de uso de consulta operaciones asociadas en datos de mercado.
 */
@Name("fechaCallableAltaAction")
@Scope(ScopeType.CONVERSATION)
@InterceptExceptions
public class FechaCallableAltaAction extends GenericAction{
	
	@Factory(value = "listaTipoCanc", scope = ScopeType.CONVERSATION)
	public TipoCanc[] getTipoCancs(){
		return TipoCanc.values();
	}
	@Factory(value = "listaObligOpc", scope = ScopeType.CONVERSATION)
	public ObligOpc[] getObTipoCancs(){
		return ObligOpc.values();
	}
	@Factory(value = "listaSentidoAmort", scope = ScopeType.CONVERSATION)
	public SentidoAmort[] getSentidoAmorts(){
		return SentidoAmort.values();
	}
	@Factory(value = "listaCobroPago", scope = ScopeType.CONVERSATION)
	public CobroPago[] getCobroPagos(){
		return CobroPago.values();
	}
	@Factory(value = "listaDivisasFCallable", scope = ScopeType.CONVERSATION)
	public List<Divisa> getDivisas(){
		return fechaCallableBo.getListDivisa();
	}
	
	
	@Logger
	private Log log;

	@In("#{boletasBo}")
	protected BoletasBo boletasBo;

	@In("#{fechaCallableBo}")
	protected FechaCallableBo fechaCallableBo;
		
	@In(required=true)
	private BoletasStates boletaState;
	
	@In
	@Out(value="historicoOperacion", required=true)
	private HistoricoOperacion historicoOperacion;
	
	@In(required=true)
	private FechaCallable fechaCallable;
	
	@In(required=true)
	private FechaCallableMode fechaCallableMode;
	
	private String importeAmortizacion;
	
	
	public FechaCallableAltaAction(){
		
	}
	
	public String alta(){
		if(!fechaCallableValida()){
			return Constantes.FAIL; 
		}
		if(GenericUtils.isNullOrBlank(fechaCallable.getFechaCallableId().getFechaCallable())){
			statusMessages.addToControl("fCallable", Severity.ERROR, "#{messages['boletas.fecha.callable.obligatorio']");
			return Constantes.FAIL; 
		}
		if(!GenericUtils.isNullOrBlank(importeAmortizacion) && GenericUtils.isNumeric(importeAmortizacion)){
			if(fechaCallable.getSentidoAmortizacion().equals(SentidoAmort.P)){
				fechaCallable.setAmortizacionPago(new BigDecimal(importeAmortizacion));
			} else if(fechaCallable.getSentidoAmortizacion().equals(SentidoAmort.C)){
				fechaCallable.setAmortizacionRecibo(new BigDecimal(importeAmortizacion));
			} else {
				fechaCallable.setAmortizacionPago(new BigDecimal(importeAmortizacion));
				fechaCallable.setAmortizacionRecibo(new BigDecimal(importeAmortizacion));
			}
		}
		fechaCallableBo.create(fechaCallable);
		salir();
		return Constantes.CONSTANTE_SUCCESS;
	}
	/**
	 * Devuelve ‘TRUE’, si todo está bien o ‘FALSE’ si encuentra algún error.
		1. F. Liquidac/Divisa: 
			Si F.Liquidac not null and Divisa not null, 
			Llamar a PKG_BOLETA.P_ES_FESTIVO (fecha, divisa, switch, filler) 
			enviando como parámetros F.Liquidac, Divisa, si devuelve que es festivo (switch=’S’), 
			mostrar error 'La fecha de liquidación no puede caer en festivo'
		2. Oblig/Opc / F.Observac: Si Oblig/Opc = 1 and F.Observac = null, 
			mostrar error: ‘La fecha de Observación ha de estar informada’ 
		3. Si se trata de un Alta, validar que no exista en deri.fechcall, 
			otro registro para la misma operación (Num. Oper / F. Contr) y fecha Callable,
			 si existe mostrar error ‘Ya existe esta fecha callable para la operación’
	 * @return
	 */
	private boolean fechaCallableValida() {
		if(fechaCallable.getFechaLiquidacion()!=null && fechaCallable.getDivisaPrimaCanc()!=null &&
				boletasBo.validateFestivo(fechaCallable.getFechaLiquidacion(),fechaCallable.getDivisaPrimaCanc()) ){
			//boletas.fecha.callable.no.festivo=La fecha de liquidación no puede caer en festivo
			statusMessages.addToControl("fLiquid", Severity.ERROR, "#{messages['boletas.fecha.callable.no.festivo']");
			return false;
		}
		if("1".equals(fechaCallable.getCancobop()) && fechaCallable.getFechaObs()==null){
			//boletas.fecha.callable.fecha.observacion.informada=La fecha de Observación ha de estar informada
			statusMessages.addToControl("fObservac", Severity.ERROR, "#{messages['boletas.fecha.callable.fecha.observacion.informada']");
			return false;
		}
		if(modeAlta()){
			List<FechaCallable> list = fechaCallableBo.getListFechasCallables(historicoOperacion);
			for (FechaCallable fechaCallableOld : list) {
				if(fechaCallable.getFechaCallableId().getFechaCallable().equals(fechaCallableOld.getFechaCallableId().getFechaCallable())){
					//boletas.fecha.callable.fecha.ya.existe=Ya existe esta fecha callable para la operación
					statusMessages.addToControl("fObservac", Severity.ERROR, "#{messages['boletas.fecha.callable.fecha.ya.existe']");
					return false;
				}
			}
		}
		return true;
	}
	public String update(){
		if(!fechaCallableValida()){
			return Constantes.FAIL; 
		}
		if(!GenericUtils.isNullOrBlank(importeAmortizacion) && GenericUtils.isNumeric(importeAmortizacion)){
			if(fechaCallable.getSentidoAmortizacion().equals(SentidoAmort.P)){
				fechaCallable.setAmortizacionPago(new BigDecimal(importeAmortizacion));
			} else if(fechaCallable.getSentidoAmortizacion().equals(SentidoAmort.C)){
				fechaCallable.setAmortizacionRecibo(new BigDecimal(importeAmortizacion));
			} else {
				fechaCallable.setAmortizacionPago(new BigDecimal(importeAmortizacion));
				fechaCallable.setAmortizacionRecibo(new BigDecimal(importeAmortizacion));
			}
		}
		fechaCallableBo.update(fechaCallable);
		salir();
		return Constantes.CONSTANTE_SUCCESS;
	}
	
	public void prepareFechasCallables(){
		if(!fechaCallableMode.equals(FechaCallableMode.ALTA)){
			if(SentidoAmort.P.equals(fechaCallable.getSentidoAmortizacion()) && fechaCallable.getAmortizacionPago()!=null){
				this.setImporteAmortizacion(fechaCallable.getAmortizacionPago().toString());
			} else if(SentidoAmort.C.equals(fechaCallable.getSentidoAmortizacion()) && fechaCallable.getAmortizacionRecibo()!=null){
				this.setImporteAmortizacion(fechaCallable.getAmortizacionRecibo().toString());
			} else {
				this.setImporteAmortizacion(fechaCallable.getAmortizacionRecibo()==null?"":fechaCallable.getAmortizacionRecibo().toString());
			}
		} else if(this.getImporteAmortizacion()==null) {
			this.setImporteAmortizacion(new String(""));
		}
	}
	
	public boolean modeAlta(){
		return fechaCallableMode.equals(FechaCallableMode.ALTA); 
	}
	
	public boolean modeEdit(){
		return fechaCallableMode.equals(FechaCallableMode.MODIF);
	}
	
	public boolean modeRead(){
		return fechaCallableMode.equals(FechaCallableMode.DETAIL);
	}
	/*GETTERS Y SETTERS*/

	public BoletasStates getBoletaState() {
		return boletaState;
	}

	public void setBoletaState(BoletasStates boletaState) {
		this.boletaState = boletaState;
	}
	

	public FechaCallable getFechaCallable() {
		return fechaCallable;
	}

	public void setFechaCallable(FechaCallable fechaCallable) {
		this.fechaCallable = fechaCallable;
	}
	public String getImporteAmortizacion() {
		return importeAmortizacion;
	}
	public void setImporteAmortizacion(String importeAmortizacion) {
		this.importeAmortizacion = importeAmortizacion;
	}
  
	public void salir(){
		Conversation conv= Conversation.instance();
		//conv.endBeforeRedirect(); 
		conv.redirectToParent();
	}
	
}
