package com.atosorigin.deri.adminoper.boletas.fechasCallable.action;

import java.util.Date;

import org.jboss.seam.ScopeType;
import org.jboss.seam.annotations.In;
import org.jboss.seam.annotations.Logger;
import org.jboss.seam.annotations.Name;
import org.jboss.seam.annotations.Out;
import org.jboss.seam.annotations.Scope;
import org.jboss.seam.log.Log;

import com.atosorigin.deri.adminoper.boletas.action.BoletasAction.BoletasStates;
import com.atosorigin.deri.adminoper.boletas.business.BoletasBo;
import com.atosorigin.deri.model.gestionoperaciones.HistoricoOperacion;

/**
 * Clase action listener para el caso de uso de consulta operaciones asociadas en datos de mercado.
 */
@Name("fechasCallableAction")
@Scope(ScopeType.CONVERSATION)
public class FechasCallableAction{

	@Logger
	private Log log;

	@In("#{boletasBo}")
	protected BoletasBo boletasBo;
	
	@In(required=true)
	private BoletasStates boletaState;
	
	@In
	@Out(value="historicoOperacion", required=true)
	private HistoricoOperacion historicoOperacion;
	
	
	/* Atributs de la pantalla */
	private Date fCallable;
	private String tipoCanc;
	private String obligOpcion;
	private Date fObservac;
	
	private String sentidoAmort;
	private String impAmort;
	private boolean primaCanc;
	private boolean cobroPago;
	private String porcent;
	private String importe;
	private String divisa;
	private Date fLiquidacion;
	

	public FechasCallableAction() {
		
	}


	public BoletasStates getBoletaState() {
		return boletaState;
	}


	public void setBoletaState(BoletasStates boletaState) {
		this.boletaState = boletaState;
	}


	public Date getfCallable() {
		return fCallable;
	}


	public void setfCallable(Date fCallable) {
		this.fCallable = fCallable;
	}


	public String getTipoCanc() {
		return tipoCanc;
	}


	public void setTipoCanc(String tipoCanc) {
		this.tipoCanc = tipoCanc;
	}


	public String getObligOpcion() {
		return obligOpcion;
	}


	public void setObligOpcion(String obligOpcion) {
		this.obligOpcion = obligOpcion;
	}


	public Date getfObservac() {
		return fObservac;
	}


	public void setfObservac(Date fObservac) {
		this.fObservac = fObservac;
	}


	public String getSentidoAmort() {
		return sentidoAmort;
	}


	public void setSentidoAmort(String sentidoAmort) {
		this.sentidoAmort = sentidoAmort;
	}


	public String getImpAmort() {
		return impAmort;
	}


	public void setImpAmort(String impAmort) {
		this.impAmort = impAmort;
	}


	public boolean isPrimaCanc() {
		return primaCanc;
	}


	public void setPrimaCanc(boolean primaCanc) {
		this.primaCanc = primaCanc;
	}


	public boolean isCobroPago() {
		return cobroPago;
	}


	public void setCobroPago(boolean cobroPago) {
		this.cobroPago = cobroPago;
	}


	public String getPorcent() {
		return porcent;
	}


	public void setPorcent(String porcent) {
		this.porcent = porcent;
	}


	public String getImporte() {
		return importe;
	}


	public void setImporte(String importe) {
		this.importe = importe;
	}


	public String getDivisa() {
		return divisa;
	}


	public void setDivisa(String divisa) {
		this.divisa = divisa;
	}


	public Date getfLiquidacion() {
		return fLiquidacion;
	}


	public void setfLiquidacion(Date fLiquidacion) {
		this.fLiquidacion = fLiquidacion;
	}
	
	
}
