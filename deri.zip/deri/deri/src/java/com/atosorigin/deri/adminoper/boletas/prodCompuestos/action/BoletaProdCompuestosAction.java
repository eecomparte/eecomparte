package com.atosorigin.deri.adminoper.boletas.prodCompuestos.action;

import java.math.BigDecimal;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.List;
import java.util.Set;

import javax.persistence.EntityManager;
import javax.persistence.EntityNotFoundException;

import org.jboss.seam.ScopeType;
import org.jboss.seam.annotations.In;
import org.jboss.seam.annotations.Name;
import org.jboss.seam.annotations.Out;
import org.jboss.seam.annotations.Scope;
import org.jboss.seam.annotations.datamodel.DataModel;
import org.jboss.seam.annotations.datamodel.DataModelSelection;
import org.jboss.seam.core.Conversation;
import org.jboss.seam.core.ResourceBundle;
import org.jboss.seam.international.StatusMessage.Severity;
import org.jboss.seam.security.Credentials;
import org.jboss.seam.security.Identity;

import com.atosorigin.common.action.ModoPantalla;
import com.atosorigin.common.action.PaginatedListAction;
import com.atosorigin.common.auditdata.AuditData;
import com.atosorigin.common.constantes.Constantes;
import com.atosorigin.common.formvalidator.FormValidator;
import com.atosorigin.common.utils.GenericUtils;
import com.atosorigin.deri.adminoper.boletas.action.BoletasAction.BoletasStates;
import com.atosorigin.deri.adminoper.boletas.business.BoletasBo;
import com.atosorigin.deri.adminoper.boletas.prodCompuestos.screen.BoletaProdCompuestosPantalla;
import com.atosorigin.deri.adminoper.mantOperaciones.screen.CancelacionPantalla;
import com.atosorigin.deri.adminoper.mantoper.business.CancelacionBo;
import com.atosorigin.deri.adminoper.mantoper.business.MantOperBo;
import com.atosorigin.deri.common.dbLock.DbLockService;
import com.atosorigin.deri.common.parametrosPantalla.ParametrosManteje;
import com.atosorigin.deri.contrapartida.business.ContrapartidaBo;
import com.atosorigin.deri.dao.adminoper.boletas.AltaCorrelaResult;
import com.atosorigin.deri.gestionoperaciones.productocompuesto.business.BoletaProdCompuestoBo;
import com.atosorigin.deri.gestionoperaciones.productocompuesto.business.MantProdCompuestoBo;
import com.atosorigin.deri.model.adminoper.CanalConfDefecto;
import com.atosorigin.deri.model.adminoper.CanalConfDefectoId;
import com.atosorigin.deri.model.adminoper.CanalConfirmacion;
import com.atosorigin.deri.model.adminoper.CanalConfirmacionId;
import com.atosorigin.deri.model.adminoper.CancelacionParcial;
import com.atosorigin.deri.model.adminoper.DescripcionTipoPlantilla;
import com.atosorigin.deri.model.adminoper.HistoricoBarrera;
import com.atosorigin.deri.model.adminoper.HistoricoOpcion;
import com.atosorigin.deri.model.adminoper.IndicadorConfirmacion;
import com.atosorigin.deri.model.adminoper.PlantillasConfirmacion;
import com.atosorigin.deri.model.catalogo.CatalogoProdCompuesto;
import com.atosorigin.deri.model.catalogo.HistoricoProductoCompuesto;
import com.atosorigin.deri.model.catalogo.HistoricoProductoCompuestoId;
import com.atosorigin.deri.model.catalogo.OperacionesProdCompuestos;
import com.atosorigin.deri.model.catalogo.ProductoCompuesto;
import com.atosorigin.deri.model.common.Idioma;
import com.atosorigin.deri.model.common.RetornoFuncion;
import com.atosorigin.deri.model.contrapartida.Contrapartida;
import com.atosorigin.deri.model.gestionoperaciones.DescripcionEstadoOperacion;
import com.atosorigin.deri.model.gestionoperaciones.DescripcionTransaccionOperacion;
import com.atosorigin.deri.model.gestionoperaciones.HistoricoOperacion;
import com.atosorigin.deri.model.gestionoperaciones.HistoricoOperacionId;
import com.atosorigin.deri.model.gestionoperaciones.OperacionId;
import com.atosorigin.deri.model.gestionoperaciones.VistaOperacion;
import com.atosorigin.deri.model.murex.ProductoCatalogo;
import com.atosorigin.deri.util.ErrorMessage;
import com.atosorigin.deri.util.MenuBean;
import com.atosorigin.deri.util.MessageBoxAction;
import com.atosorigin.deri.util.MsgBoxAction;
import com.atosorigin.deri.util.ErrorMessage.TypeError;

/**
 * Clase action listener para el caso de uso de consulta operaciones asociadas en datos de mercado.
 */
@Name("boletaProdCompuestosAction")
@Scope(ScopeType.CONVERSATION)
@FormValidator
public class BoletaProdCompuestosAction extends PaginatedListAction{
	
	@In(create=true)
	protected BoletaProdCompuestosPantalla boletaProdCompuestosPantalla;
	
	@In(value = "#{mantProdCompuestoBo}")
	protected MantProdCompuestoBo mantProdCompuestoBo;
	
	@In(value = "#{boletasBo}")
	protected BoletasBo boletasBo;
	
	@In(value = "#{mantOperBo}")
	protected MantOperBo mantOperBo;
	
	@In(value = "#{boletaProdCompuestoBo}")
	protected BoletaProdCompuestoBo boletaProdCompuestoBo;
	
	@In(value = "#{contrapartidaBo}")
	protected ContrapartidaBo contrapartidaBo;
	
	@In("#{cancelacionBo}")
	private CancelacionBo cancelacionBo;
	
	@In(create = true)
	@Out(required = false)
	private CancelacionPantalla cancelacionPantalla;
	
	@In(create=true)
	protected MenuBean menuBean;
	
	@Out(required = false, value = "ParametrosManteje")
	ParametrosManteje parametrosManteje;

    @In Credentials credentials;
	
	@In
	private EntityManager entityManager;

	@DataModel(value="listaOperacionesProdCompuestos")
	protected List<OperacionesProdCompuestos> listaOperacionesProdCompuestos;
	
	@DataModelSelection(value="listaOperacionesProdCompuestos")
	protected OperacionesProdCompuestos operacionesProdCompuestos;

	private Boolean tipoPlantillaHabilitado = true;
	private Boolean canalContraHabilitado = true;
	private Boolean idiomaContraHabilitado = true;
	private Boolean canalModifHabilitado = true;
	private Boolean idiomaModifHabilitado = true;
	private Boolean canalCanceHabilitado = true;
	private Boolean idiomaCanceHabilitado = true;
	private Boolean canalCanceParHabilitado = true;
	private Boolean idiomaCanceParHabilitado = true;
	private Boolean canalLiquiHabilitado = true;
	private Boolean idiomaLiquiHabilitado = true;
	private Boolean canalFijTipHabilitado = true;
	private Boolean idiomaFijTipHabilitado = true;
	private Boolean canalContraRecHabilitado = true;	
	private Boolean canalModifRecHabilitado = true;	
	private Boolean canalCanceRecHabilitado = true;	
	private Boolean canalCanceRecParHabilitado = true;	
	private Boolean canalLiquiRecHabilitado = true;	
	private Boolean canalFijTipRecHabilitado = true;
	
	/** Inyección del servicio que gestiona los bloqueos de registros en base de datos */
	@In(create = true)
	protected DbLockService dbLockService;

	//para que la pagina de Lista de Operaciones de la boleta sepa quien la ha llamado
	@In(create = true,required=false)
	@Out(required=false)
	protected String pantalla;
	
	@In(required=false)
	@Out(required=false)
	protected Date timestampInicial;
	
	@In(create = true,required=false)
	private Long estructuraId;	
	
	@In(required=false)
	@Out(required=false)
	private Boolean alta;
	
	//Para la union con alta boletas
	@Out(value="productoCompuesto",required=false)
	protected ProductoCompuesto productoCompuesto;
	
	//Para la union con datos generales alta boletas
	@Out(required=false)
	private BoletasStates boletaState;
	
	//Para la union con datos generales alta BOLETAS, MANTOQE
	@Out(required=false)
	HistoricoOperacion historicoOperacion = new HistoricoOperacion();
	
	@Out(required = false)
	private HistoricoOperacionId historicoOperacionBloqueadoId;

	
	//para la union con MANTOQE
	@Out(required=false)
	String origen;
	
	//para la union con MANTEJE, EJECPAR, MANTOQE ,Boletas
	@In(required=false)
	@Out(required=false)
	String varModif;
	
	@In(required=false, create=false)
	@Out(required=false)
	Boolean consulta = false;
	
	//Para la union con modificarBoleta
	@Out(required=false)
	protected VistaOperacion vistaOperacionProdComp;

	@Out(required = false, value = "altaProdCompuestoMessageBoxAction")
	private MessageBoxAction messageBoxAltaProdCompuestoAction;
	
	/*****************************************************/
	/****	VARS PARA MSJES DE ERROR INI			******/
	/*****************************************************/
	/* IN's y OUT's */
	@In(create = true)
	MsgBoxAction msgBoxAction;
	private String msgBoxHeaderListaErrores;
	private String msgBoxNoProcessable;
	private boolean msgBoxFinalStep = false;
	private boolean msgBoxMessageMode = false;
	private String msgBoxWidth = "350";
	
	@DataModel(value = "mantProdComp.listaErrores")
	private List<ErrorMessage> listaErrores = new ArrayList<ErrorMessage>();
	/*****************************************************/
	/****	VARS PARA MSJES DE ERROR FIN			******/
	/*****************************************************/

	
	public void iniciarAlta(){
		HistoricoProductoCompuesto historicoProductoCompuesto = new HistoricoProductoCompuesto();
		HistoricoProductoCompuestoId id = new HistoricoProductoCompuestoId();
		CatalogoProdCompuesto catalogoProdCompuesto = new CatalogoProdCompuesto();
		Contrapartida contrapartida = new Contrapartida();
		historicoProductoCompuesto.setCatalogoProdCompuesto(catalogoProdCompuesto);
		historicoProductoCompuesto.setContrapartida(contrapartida);
		historicoProductoCompuesto.setId(id);
		boletaProdCompuestosPantalla.setHistoricoProductoCompuesto(historicoProductoCompuesto);
	}
	
	
	//DRS SeleccionOperaciones
	
	public String anadirSeleccion(){
		List<HistoricoOperacion> histOperaciones = boletaProdCompuestosPantalla.getSelectedHistOperDataList();
		Integer referencia = null;		
		ProductoCompuesto prodComp = null;
		HistoricoOperacion histderiUltimo = null;
		
		for(HistoricoOperacion histOperacion: histOperaciones){
			
			//Recuperamos el HistoricoOperacion más reciente para estar seguros
			histderiUltimo = boletaProdCompuestoBo.obtenerOperacionDestino(histOperacion.getId());
			
			if(dbLockService.bloqueo(HistoricoOperacion.class, histderiUltimo.getId())){
				try{
					
					//Modificamos el historico operacion
					
					if(!GenericUtils.isNullOrBlank(boletaProdCompuestosPantalla.getHistoricoProductoCompuesto().getReferenciaMurex())){
						referencia = boletaProdCompuestosPantalla.getHistoricoProductoCompuesto().getReferenciaMurex().intValue();
					}
					
					if(!GenericUtils.isNullOrBlank(boletaProdCompuestosPantalla.getHistoricoProductoCompuesto()) && !GenericUtils.isNullOrBlank(boletaProdCompuestosPantalla.getHistoricoProductoCompuesto().getId())){
						prodComp = boletaProdCompuestoBo.obtenerProductoCompuesto(boletaProdCompuestosPantalla.getHistoricoProductoCompuesto().getId().getEstructu());
					}
									
					histderiUltimo.setCatalogoProdCompuesto(boletaProdCompuestosPantalla.getHistoricoProductoCompuesto().getCatalogoProdCompuesto());
					histderiUltimo.setOperProductoCompuestoMurex(referencia);
					histderiUltimo.setProductoCompuesto(prodComp);
					
					//Y después modificamos la operacion
					histderiUltimo.getOperacion().setCatalogoProdCompuesto(boletaProdCompuestosPantalla.getHistoricoProductoCompuesto().getCatalogoProdCompuesto());
					histderiUltimo.getOperacion().setOperProductoCompuestoMurex(referencia);
					histderiUltimo.getOperacion().setProductoCompuesto(prodComp);
					
					boletaProdCompuestoBo.guardarSeleccOperacion(histderiUltimo);
					
				}catch(Exception e){
					statusMessages.add(Severity.ERROR, "#{messages['boletaprodcompuestos.error.noActualizado']}");
					return Constantes.FAIL;
				}finally{
					dbLockService.desbloqueo( HistoricoOperacion.class, histderiUltimo.getId());	
				}
			}
		}
		
		varModif = Constantes.CONSTANTE_SI;
		
		//Vaciamos la lista de seleccionadas
		boletaProdCompuestosPantalla.getSelectedHistOperDataList().clear();
		boletaProdCompuestosPantalla.getSelectedOperIds().clear();
		
		this.refrescarLista(); //refrescamos lista para que aparezca la operación añadida.
		return Constantes.SUCCESS;
		
	}
	
	public boolean anadirSeleccionValidator(){
		
		boolean validado = true;
		
		//Si el producto es definido solamente se puede seleccionar una operación por fila
		//if(!GenericUtils.isNullOrBlank(operacionesProdCompuestos) && !GenericUtils.isNullOrBlank(operacionesProdCompuestos.getProdcat())){
		if("D".equalsIgnoreCase(boletaProdCompuestosPantalla.getVartipo()))	{
			if(boletaProdCompuestosPantalla.getSelectedHistOperDataList().size() > 1){
				validado=false;
				statusMessages.add(Severity.ERROR, "#{messages['boletaprodcompuestos.error.muchasOperaciones']}");
			}
		}
		
		return validado;
	}
	
// ### FUNCIONES PARA GESTIONAR LOS CHECKBOX ###
	
	/**
	 * Cada vez que se selecciona/deselecciona una liquidaciones se actualiza la lista
	 * de las seleccionadas y se comprueba si están habilitados los botones validar y anular
	 */
	public void seleccionarHistOperacion() {
		this.getHistOperacionSeleccionadas();		
	}
	
	public String irDetalle(){
		historicoOperacion = operacionesProdCompuestos.getVistaOperacion().getHistOper();
		boletasBo.prepareConsultaCorrela(historicoOperacion);
		boletaState = BoletasStates.CONSULTA_BOLETA;
		return Constantes.SUCCESS;
	}
	
	/**
	 * Recorre la lista de liquidaciones y carga los elementos seleccionados
	 */
	public void getHistOperacionSeleccionadas() {
		
		//Contiene todas las liquidaciones visibles
		List<HistoricoOperacion> histOperacionesList = boletaProdCompuestosPantalla.getListaHistOperSeleccionOperaciones();
		
		HistoricoOperacion dataItem = null;
		
		int tamanyoLista = histOperacionesList.size();
		
		//Recorremos toda la lista de liquidaciones, verificando cual está y no seleccionada
		//para asignarla a SelectedLiquiDataList
		for (int i = 0; i < tamanyoLista; i++){
			dataItem = histOperacionesList.get(i);
			
			if (!GenericUtils.isNullOrBlank(boletaProdCompuestosPantalla.getSelectedOperIds().get(dataItem.getId()))){
	            	
	        	if (boletaProdCompuestosPantalla.getSelectedOperIds().get(dataItem.getId()).booleanValue() 
	           			&& !boletaProdCompuestosPantalla.getSelectedHistOperDataList().contains(dataItem)) {
	           		
	        		boletaProdCompuestosPantalla.getSelectedHistOperDataList().add(dataItem);
	           		
	           	}else if (!boletaProdCompuestosPantalla.getSelectedOperIds().get(dataItem.getId()).booleanValue() 
            			&& boletaProdCompuestosPantalla.getSelectedHistOperDataList().contains(dataItem)){
	           		boletaProdCompuestosPantalla.getSelectedHistOperDataList().remove(dataItem);
	           		boletaProdCompuestosPantalla.getSelectedOperIds().remove(dataItem.getId());
            	}
            }
			dataItem = null;
		}
    }
	
	//DRS FIN SeleccionOperaciones
	
	
	/**
	 * Pantalla : listaProductosCompuestos
	 * Añade una operacion existente a la lista de Operaciones
	 * va a la pagina seleccion de operaciones	
	 * 
	 */
	public String anadirOperacion(){
		
		OperacionesProdCompuestos operBusqueda = null;
		
		//Solamente le pasamos los datos de oprodcom si vartipo = 'D'
		if("D".equalsIgnoreCase(boletaProdCompuestosPantalla.getVartipo())){
			operBusqueda = operacionesProdCompuestos;
		}
		
		boletaProdCompuestosPantalla.setListaHistOperSeleccionOperaciones(boletaProdCompuestoBo.selectOperacionesProdComp(
				boletaProdCompuestosPantalla.getHistoricoProductoCompuesto(),
				operBusqueda));
//		if ("0".equals(boletaProdCompuestosPantalla.getParamSalir())){
			varModif = Constantes.CONSTANTE_SI;			
//		}
		return Constantes.CONSTANTE_SUCCESS;
	}
	
	public void borrarOperacion(){
		
		
		
		if(("PV".equals(operacionesProdCompuestos.getSit()) && "A".equals(operacionesProdCompuestos.getIndsitua()) ) ||
			("IN".equals(operacionesProdCompuestos.getSit()) && "A".equals(operacionesProdCompuestos.getIndsitua()) ) ){
					boletaProdCompuestoBo.borrarOperacionProd(operacionesProdCompuestos);
					varModif = Constantes.CONSTANTE_SI;		
					refrescarLista();
		}else{
			boletaProdCompuestoBo.quitarOperacionProd(operacionesProdCompuestos);
			varModif = Constantes.CONSTANTE_SI;					
			refrescarLista();
		}
		
	}
	
	/**
	 * Pantalla : listaProductosCompuestos
	 * Crea una nueva operacion y la añade a la lista de Operaciones
	 * 	
	 */
	public String altaOperacion(){
		String retorno = "";
		
		if(GenericUtils.isNullOrBlank(boletaProdCompuestosPantalla.getVartipo())){
			if(boletaProdCompuestoBo.obtenerTipoProductoCompuesto(boletaProdCompuestosPantalla.getHistoricoProductoCompuesto().getCatalogoProdCompuesto().getId())==0){
				boletaProdCompuestosPantalla.setVartipo("L");
			}else{
				boletaProdCompuestosPantalla.setVartipo("D");
			}
		}
		historicoOperacion.setFechaVencimiento(boletaProdCompuestosPantalla.getHistoricoProductoCompuesto().getFechaVencimiento());
		if("D".equals(boletaProdCompuestosPantalla.getVartipo()) ){
			
			retorno = altaNcorrela(boletaProdCompuestosPantalla.getHistoricoProductoCompuesto());	
//			codigo segun viene en el DT faltaria llamar a datos generales de boletas
			
//			retornoFuncionFAltaNcorrela = boletaProdCompuestoBo.llamarpkgBoletaFAltaNcorrela(boletaProdCompuestosPantalla.getHistoricoProductoCompuesto(), operacionesProdCompuestos);	
//				if (GenericUtils.isNullOrBlank(retornoFuncionFAltaNcorrela) && GenericUtils.isNullOrBlank(retornoFuncionFAltaNcorrela.getNumerror())){
//					if (retornoFuncionFAltaNcorrela.getNumerror() != 0 ){
//						statusMessages.add( Severity.WARN,"#{messages['boletaprodcompuestos.listaoperaciones.err.altaOper']}",retornoFuncionFAltaNcorrela.getNumerror());
//					}
//				}else{
//					retorno = Constantes.CONSTANTE_SUCCESS;
//				}
					}
		if("L".equals(boletaProdCompuestosPantalla.getVartipo()) ){
			productoCompuesto = new ProductoCompuesto();
			productoCompuesto.setEstructu(boletaProdCompuestosPantalla.getHistoricoProductoCompuesto().getId().getEstructu());
			productoCompuesto.setIndEstructuraModelo(boletaProdCompuestosPantalla.getHistoricoProductoCompuesto().getIndEstructuraModelo());
			retorno = "altaoper";			
		}
		
//		if ("0".equals(boletaProdCompuestosPantalla.getParamSalir())){
			setVarModif(Constantes.CONSTANTE_SI);
//		}
		
			//Controlar que el número de operaciones del producto no supere las restricciones definidas 
			//en el catálogo (PRODCOMP)
			int maxComponentes = -1;
			if(boletaProdCompuestosPantalla.getHistoricoProductoCompuesto().getCatalogoProdCompuesto()!=null)
				maxComponentes = boletaProdCompuestosPantalla.getHistoricoProductoCompuesto().getCatalogoProdCompuesto().getNumeroComponentes();
			if(maxComponentes!=-1 && listaOperacionesProdCompuestos.size()>=maxComponentes){
				statusMessages.add(Severity.ERROR, "#{messages['boletaprodcompuestos.listaoperaciones.altaOper.maxOper']}");
				return Constantes.FAIL;
			}else{
		return retorno;
	}
	}
		
	public String altaNcorrela(HistoricoProductoCompuesto historicoProductoCompuesto ){		
		
		historicoOperacion = new HistoricoOperacion();
		String retorno = "datosgenerales"; 
		HistoricoOperacionId id = new HistoricoOperacionId();
		
		id.setFechaContratacion(historicoProductoCompuesto.getFechaContratacion());
		
		historicoOperacion.setId(id);
		historicoOperacion.setProcedenciaProducto(historicoProductoCompuesto.getCatalogoProdCompuesto().getProcedenciaProducto());
		VistaOperacion vistaOperacion = new VistaOperacion();
		
		if(!GenericUtils.isNullOrBlank(operacionesProdCompuestos)){
		vistaOperacion.setProducat(BigDecimal.valueOf(operacionesProdCompuestos.getProdcat()));
			try {
				ProductoCatalogo find = entityManager.find(
						ProductoCatalogo.class, operacionesProdCompuestos.getProdcat());
				historicoOperacion.setProductoCatalogo(find);
			} catch (EntityNotFoundException e) { 
				ProductoCatalogo prod = new ProductoCatalogo();
				prod.setProducat(operacionesProdCompuestos.getProdcat());
				historicoOperacion.setProductoCatalogo(prod);
			}
			
			historicoOperacion.setTransaccion(new DescripcionTransaccionOperacion());
			historicoOperacion.getTransaccion().setCodigo(operacionesProdCompuestos.getTran());
		}
//		String modelo = boletaProdCompuestoBo.obtenerModelo(vistaOperacion);
//		ModeloProducto modeloProducto = new ModeloProducto();
//		ProductoCatalogo productoCatalogo = new ProductoCatalogo();
//		historicoOperacion.setProductoCatalogo(productoCatalogo); 
//		historicoOperacion.getProductoCatalogo().setModelpro(modeloProducto);
//		historicoOperacion.getProductoCatalogo().getModelpro().setModelpro(modelo);

		
		//historicoOperacion.setProductoCatalogo(historicoProductoCompuesto.getCatalogoProdCompuesto());
		historicoOperacion.setCatalogoProdCompuesto(historicoProductoCompuesto.getCatalogoProdCompuesto()); 
		
		if("S".equals(historicoProductoCompuesto.getIndEstructuraModelo())){
			historicoOperacion.setIndicadorOperacionModelo(true);
		}
		if("N".equals(historicoProductoCompuesto.getIndEstructuraModelo())){
			historicoOperacion.setIndicadorOperacionModelo(false);
		}
		
		historicoOperacion.setUsuarioAlta(Identity.instance().getCredentials().getUsername());
		
		if (productoCompuesto == null) {
			productoCompuesto = new ProductoCompuesto();
			productoCompuesto.setEstructu(boletaProdCompuestosPantalla.getHistoricoProductoCompuesto().getId().getEstructu());
		}
		
		

        historicoOperacion.setProductoCompuesto( productoCompuesto);

		
		AltaCorrelaResult result = boletasBo.prepareAltaCorrela(historicoOperacion);
		
		if(result==null){
			retorno = "";
			statusMessages.addToControl("", Severity.ERROR, "#{messages['boletas.alta.error.creacionError']");
		}
		historicoOperacion=result.getHistoricoOperacion();
		String codError = result.getCodError();
		if(result==null || codError!=null & !"".equals(codError)){
			statusMessages.addToControl("", Severity.ERROR, "#{messages['boletas.alta.error.fAltaCorrelaError']");
			retorno = "";
		}
		
		boletaState = BoletasStates.ALTA_BOLETA;
		return retorno;
	}
	
	/**
	 *  
	 */
	public void obtenerCatalogoProdCompuesto(){
		if (!GenericUtils.isNullOrBlank(boletaProdCompuestosPantalla.getProcedenciaProductoSelect().getProceden())){
			boletaProdCompuestosPantalla.setListaCatalogoProdCompuestos(mantProdCompuestoBo.getCatalogoProdCompuesto(boletaProdCompuestosPantalla.getProcedenciaProductoSelect().getProceden()));
		}
		boletaProdCompuestosPantalla.setListaTransacciones(null);
	}
	
	public void obtenerTransacciones(){
		if (!GenericUtils.isNullOrBlank(boletaProdCompuestosPantalla.getHistoricoProductoCompuesto().getCatalogoProdCompuesto().getId())){
			boletaProdCompuestosPantalla.setListaTransacciones(boletaProdCompuestoBo.descripTransaccion(boletaProdCompuestosPantalla.getHistoricoProductoCompuesto().getCatalogoProdCompuesto().getId()));
		}
	}
	
	
	public void salirDetalleAlta(){
		menuBean.clickAndKillLastConversation("/home.xhtml");
	}
	
	
	public String salirAltaBoletaProdComp(){
		return Constantes.CONSTANTE_SUCCESS;
	}
	
	public String salirConf(){
		Conversation.instance().redirectToParent();
		return Constantes.CONSTANTE_SUCCESS;
	}

	
	public String irDetalleAlta(){
		timestampInicial = new Date();
		HistoricoProductoCompuestoId id = new HistoricoProductoCompuestoId();
		Contrapartida contrapa = new Contrapartida();
		boletaProdCompuestosPantalla.getHistoricoProductoCompuesto().setContrapartida(contrapa);
		id.setEstructu(boletaProdCompuestoBo.llamarpkgEstructuObtenerEstructu());
		boletaProdCompuestosPantalla.getHistoricoProductoCompuesto().setId(id);
		boletaProdCompuestosPantalla.setListaProductos(boletaProdCompuestoBo.obtenerProducto(boletaProdCompuestosPantalla.getHistoricoProductoCompuesto().getCatalogoProdCompuesto().getId()));	
		if(boletaProdCompuestoBo.obtenerTipoProductoCompuesto(boletaProdCompuestosPantalla.getHistoricoProductoCompuesto().getCatalogoProdCompuesto().getId())==0){
			boletaProdCompuestosPantalla.setVartipo("L");
		}else{
			boletaProdCompuestosPantalla.setVartipo("D");
		}
		
		boletaProdCompuestosPantalla.getHistoricoProductoCompuesto().setFechaContratacion(new Date());
		return Constantes.CONSTANTE_SUCCESS;
	}
	
	
	public boolean altaBoletaProdCompValidator(){
		
		boolean retorno= true;
		if (boletaProdCompuestosPantalla.isNeteoliq() && GenericUtils.isNullOrBlank(boletaProdCompuestosPantalla.getHistoricoProductoCompuesto().getProducto())){
			statusMessages.add(Severity.ERROR, "#{messages['boletaprodcompuestos.error.prodoperobligatorio']}");
			retorno = false;
		}
		if(!existeContrapa()){
			statusMessages.addToControl("contrapartida", Severity.ERROR,"#{messages['boletaprodcompuestos.error.contrapartida']}" );
			retorno = false;
		}
		return retorno;
	}
	
	public String altaBoletaProdComp(){
		
		
		setModoPantalla(ModoPantalla.CREACION);
		setPantalla("ALTAPROD");
		setConsulta(false);
		
		boletaProdCompuestosPantalla.getHistoricoProductoCompuesto().setTransaccion(boletaProdCompuestosPantalla.getDescripcionTransaccionOperacionSelect().getCodigo());
		//SMM  - carga la contrapartida para recuperar en Confirmaciones Productos compuestos su idioma
		if (!GenericUtils.isNullOrBlank(boletaProdCompuestosPantalla.getHistoricoProductoCompuesto().getContrapartida())
				&& !GenericUtils.isNullOrBlank(boletaProdCompuestosPantalla.getHistoricoProductoCompuesto().getContrapartida().getId())){
			boletaProdCompuestosPantalla.getHistoricoProductoCompuesto().setContrapartida(contrapartidaBo.cargar(boletaProdCompuestosPantalla.getHistoricoProductoCompuesto().getContrapartida().getId()));
		}
				
		if (boletaProdCompuestosPantalla.isConfconjunta() ){
			boletaProdCompuestosPantalla.getHistoricoProductoCompuesto().setIndConfirmacionConjunta("S");
		}else{
			boletaProdCompuestosPantalla.getHistoricoProductoCompuesto().setIndConfirmacionConjunta("N");
		}
		if (boletaProdCompuestosPantalla.isEstructmodelo() ){
			boletaProdCompuestosPantalla.getHistoricoProductoCompuesto().setIndEstructuraModelo("S");
		}else{
			boletaProdCompuestosPantalla.getHistoricoProductoCompuesto().setIndEstructuraModelo("N");
		}
		if (boletaProdCompuestosPantalla.isNeteoliq()){
			boletaProdCompuestosPantalla.getHistoricoProductoCompuesto().setIndNeteoLiquidaciones("S");
		}else{
			boletaProdCompuestosPantalla.getHistoricoProductoCompuesto().setIndNeteoLiquidaciones("N");
		}
		if (boletaProdCompuestosPantalla.isConoperexistentes() ){
			
		}
		if(GenericUtils.isNullOrBlank(boletaProdCompuestosPantalla.getHistoricoProductoCompuesto().getId().getFechaModificacion())){
		boletaProdCompuestoBo.obtenerEstructura(boletaProdCompuestosPantalla.getHistoricoProductoCompuesto());
		}
		
		if(!dbLockService.bloqueo( HistoricoProductoCompuesto.class, boletaProdCompuestosPantalla.getHistoricoProductoCompuesto().getId())){
			statusMessages.addFromResourceBundle(Severity.WARN, "errores.registro.bloqueado", boletaProdCompuestosPantalla.getHistoricoProductoCompuesto().getId());
		}
		
		varModif = Constantes.CONSTANTE_NO;
		cargarLista();
		return Constantes.CONSTANTE_SUCCESS;
	}
	
	public VistaOperacion convertOpProdCompToVistaOperacion(OperacionesProdCompuestos operacionesProdCompuestos){
		if (!GenericUtils.isNullOrBlank(operacionesProdCompuestos))
			return boletaProdCompuestoBo.obtenerVistaOperacion(operacionesProdCompuestos.getNumoper(), operacionesProdCompuestos.getFechaope());
		else
			return null;
	}
	
	/********************************************************************/
	/****			BOTONERA LISTA OPERACIONES INI				*********/
	/********************************************************************/
	/***************	ACTIVACION INI 		***************/
	
	public boolean btnTipoCancelacion(String tipo, OperacionesProdCompuestos oper) {
		boolean ret = false;
	
		Long prodCatal = null;
		
		if (!GenericUtils.isNullOrBlank(oper.getVistaOperacion())){
			String estadoco = oper.getVistaOperacion().getHistOper().getEstado().getCodigo();
			String indsitua = oper.getVistaOperacion().getHistOper().getUltimaAccion().getCodigo();
					
			try {
				prodCatal = oper.getVistaOperacion().getHistOper().getProductoCatalogo().getProducat();				
			} finally {
				if (prodCatal==null)
					return false;
			}
			if (prodCatal != 2 && prodCatal != 1751213 && prodCatal != 1751214) {
				try {
					
					if ("VA".equals(estadoco) && (!"E".equals(indsitua))   
//							&& (!"T".equals(indsitua))
							) {
						//Tenemos Cancelacion, validamos si se corresponde por el tipo
						if(tipo.equals("Canc")) ret = true;
					} else if ("PV".equals(estadoco) && ("C".equals(indsitua) || "P".equals(indsitua))) {
						// Tenemos Cancelacion Parcial
						if(tipo.equals("Modif_canc")) ret = true;
					}
				} catch (NullPointerException e) { }
			}	
		}
		
		return ret;
	}
	
	public boolean btnToqueBarreraHabilitado(OperacionesProdCompuestos operacionesProdCompuestos){
		if(GenericUtils.isNullOrBlank(operacionesProdCompuestos.getVistaOperacion())){
			return false;
		}
		String pModelo = null;
		String pInestliq = null;
		VistaOperacion vistaOperacion = null;
		if (!GenericUtils.isNullOrBlank(operacionesProdCompuestos) 
				&& !GenericUtils.isNullOrBlank(operacionesProdCompuestos.getNumoper())){
			pModelo = operacionesProdCompuestos.getpModelo();
			pInestliq = operacionesProdCompuestos.getpInestliq();
			vistaOperacion = operacionesProdCompuestos.getVistaOperacion();			
			if((pModelo.equals(Constantes.MODELO_OPC) || pModelo.equals(Constantes.MODELO_EQU))
					&& vistaOperacion.getEstadoco().equals(Constantes.ESTADO_VA) 						
					&& !pInestliq.equals(Constantes.CONSTANTE_SI)
					&& !vistaOperacion.getHistOper().getUltimaAccion().getCodigo().equals("E")){
				return true;
			}
		}
		return false;	
	}

	public boolean btnEjercicioParcialHabilitado(OperacionesProdCompuestos operacionesProdCompuestos){
//SE QUITA EL BOTON
//		if(GenericUtils.isNullOrBlank(operacionesProdCompuestos.getVistaOperacion())){
//			return false;
//		}
//		String pModelo = null;
//		String pInestliq = null;
//		String pEstilo = null;
//		VistaOperacion vistaOperacion = null;
//		if (!GenericUtils.isNullOrBlank(operacionesProdCompuestos)
//				&& !GenericUtils.isNullOrBlank(operacionesProdCompuestos.getNumoper())){
//			pModelo = operacionesProdCompuestos.getpModelo();
//			pInestliq = operacionesProdCompuestos.getpInestliq();
//			pEstilo = operacionesProdCompuestos.getpEstilo();
//			vistaOperacion = operacionesProdCompuestos.getVistaOperacion();		
//			if(pModelo.equals(Constantes.MODELO_OPC)
//					&& vistaOperacion.getEstadoco().equals(Constantes.ESTADO_VA) 						
//					&& !pInestliq.equals(Constantes.CONSTANTE_SI)
//					&& !vistaOperacion.getHistOper().getUltimaAccion().getCodigo().equals("E")
//					&& !pEstilo.equals("E")){
//				return true;
//			}
//		}
		return false;
	}
	
	public boolean btnModificarHabilitado(OperacionesProdCompuestos operacionesProdCompuestos){
		if(GenericUtils.isNullOrBlank(operacionesProdCompuestos.getVistaOperacion())){
			return false;
		}
		if ((!"CA".equals(operacionesProdCompuestos.getVistaOperacion().getEstadoco())) &&
			(!"AN".equals(operacionesProdCompuestos.getVistaOperacion().getEstadoco())) && 
			(!"VE".equals(operacionesProdCompuestos.getVistaOperacion().getEstadoco())) &&
			(!"EJ".equals(operacionesProdCompuestos.getVistaOperacion().getEstadoco())) &&
			(!"EX".equals(operacionesProdCompuestos.getVistaOperacion().getEstadoco())) &&
			("PV".equals(operacionesProdCompuestos.getVistaOperacion().getEstadoco()) && "M".equals(operacionesProdCompuestos.getVistaOperacion().getSituacion()) ) )
		{			
			return true;
		}else{
			return false;
		}		
	}

	public boolean btnEjercicioHabilitado(OperacionesProdCompuestos operacionesProdCompuestos){
		if(GenericUtils.isNullOrBlank(operacionesProdCompuestos.getVistaOperacion())){
			return false;
		}
		String pModelo = null;
		String pInestliq = null;
		String pEstadoopc = null;
		VistaOperacion vistaOperacion = null;	
		if (!GenericUtils.isNullOrBlank(operacionesProdCompuestos)
				&& !GenericUtils.isNullOrBlank(operacionesProdCompuestos.getNumoper())){
			pModelo = operacionesProdCompuestos.getpModelo();
			pInestliq = operacionesProdCompuestos.getpInestliq();
			pEstadoopc = operacionesProdCompuestos.getpEstadoopc();
			vistaOperacion = operacionesProdCompuestos.getVistaOperacion();		
			if((pModelo.equals(Constantes.MODELO_OPC) || pModelo.equals(Constantes.MODELO_EQU))
					&& (vistaOperacion.getEstadoco().equals(Constantes.ESTADO_VA) 
							|| vistaOperacion.getEstadoco().equals(Constantes.ESTADO_EX)
							|| vistaOperacion.getEstadoco().equals(Constantes.ESTADO_VE))
					&& (!pInestliq.equals(Constantes.CONSTANTE_SI))
					&& (pEstadoopc.equals(Constantes.ACCION_A))){
				return true;
			}
		}		
		return false;
	}
	
	/***************	ACTIVACION FIN 		***************/
	
	public String prepareModificar(){
		listaErrores.clear();
		String ret = Constantes.FAIL;
		if (operacionesProdCompuestos.getVistaOperacion()==null){
			return ret;
		}
		historicoOperacion = operacionesProdCompuestos.getVistaOperacion().getHistOper();

		if (mantOperBo.validatePendAgendaModifCancelAnul(historicoOperacion)) {
			addError(historicoOperacion, ResourceBundle.instance().getString("mantOper.messages.modificar.agenda"));
		} else {
			if (!mantOperBo.validateLastFechaModificacion(historicoOperacion)) {
				addError(historicoOperacion, ResourceBundle.instance().getString("mantOper.messages.modificar.noLastUpdate"));
			} else {
				if (!dbLockService.bloqueo(HistoricoOperacion.class, historicoOperacion.getId())) {
					addError(historicoOperacion, ResourceBundle.instance().getString("mantOper.messages.modificar.blocked"));
				}
			}
		}
		
		if (listaErrores.size() == 0){ // No tenemos ningun error podemos modificar
			ret = modificar();
		}else {
			msgBoxFinalStep();
			prepareMsgBox("modificar");
		}
		return ret;
	}
	public String modificar() {
		historicoOperacionBloqueadoId= historicoOperacion.getId();

		AltaCorrelaResult result = boletasBo.prepareModificacionCorrela(historicoOperacion);
		if(result==null){
			addError(historicoOperacion, ResourceBundle.instance().getString("mantOper.messages.modifica.error"));
		}
		historicoOperacion=result.getHistoricoOperacion();

		boletaState = BoletasStates.MODI_BOLETA;
		return Constantes.SUCCESS;
	}
	
	public String irEjercParc() {
		VistaOperacion vo = operacionesProdCompuestos.getVistaOperacion();
		if (!GenericUtils.isNullOrBlank(vo)) {
			historicoOperacion = vo.getHistOper();
			DescripcionEstadoOperacion estado = historicoOperacion.getEstado();
			if (!GenericUtils.isNullOrBlank(estado)) {
				if (Constantes.ESTADO_VA.equalsIgnoreCase(estado.getCodigo()) || !mantOperBo.validatePendientesAgendaModif(historicoOperacion)) {
					dbLockService.bloqueo(HistoricoOperacion.class, historicoOperacion.getId());					
					return Constantes.SUCCESS;
				} else {
					addWarning(historicoOperacion, ResourceBundle.instance().getString("mantOper.messages.validar.agenda"));
				}
			}
		}
		msgBoxFinalStep();
		prepareMsgBox("voidFunction");
		return Constantes.FAIL;
	}
	
	public String irMantEjercicio(){
		VistaOperacion vo = operacionesProdCompuestos.getVistaOperacion();
		if (vo != null) {
			historicoOperacion = vo.getHistOper();
			DescripcionEstadoOperacion estado = historicoOperacion.getEstado();
			if (estado != null) {
				if (Constantes.ESTADO_VA.equalsIgnoreCase(estado.getCodigo()) || !mantOperBo.validatePendientesAgendaModif(historicoOperacion)) {
					if(dbLockService.bloqueo(HistoricoOperacion.class, historicoOperacion.getId())){
						parametrosManteje = new ParametrosManteje();
						parametrosManteje.setModo(Constantes.ORIGEN_PRODCOM);
						parametrosManteje.setHistoricoOperacion(historicoOperacion);
					return Constantes.SUCCESS;
				} else {
						statusMessages.add(Severity.WARN, "#{messages['mantOper.messages.modificar.blocked']}");
					}
				} else {
					addWarning(historicoOperacion, ResourceBundle.instance().getString("mantOper.messages.validar.agenda"));
				}
			}
		}
		msgBoxFinalStep();
		prepareMsgBox("voidFunction");
		return Constantes.FAIL;		
	}
	
	private boolean operacionOpcPendienteActivarAgenda(HistoricoOperacion historicoOperacion, String tipoEvento) {
		int numeroRegistros = 0;
		if(Constantes.TIPO_EVENTO_BARRERA.equalsIgnoreCase(tipoEvento)) {
			numeroRegistros = mantOperBo.cuantosEventos(historicoOperacion,Constantes.TIPO_EVENTO_BARRERA);
		} else if(Constantes.TIPO_EVENTO_EJERCICIO.equalsIgnoreCase(tipoEvento)) {
			numeroRegistros = mantOperBo.cuantosEventos(historicoOperacion,Constantes.TIPO_EVENTO_EJERCICIO);
		}
		if(numeroRegistros <= 1) {
			return false;
		}
		return true;
	}
	
	private boolean existenFechasValidasTBarr(HistoricoOperacion historicoOperacion) {
		HistoricoOpcion historicoOpcion = historicoOperacion.getHistoricoOpcion();
		if(historicoOpcion != null) {
			String estado = historicoOpcion.getEstado();
			if(estado != null) {
				String tipoBarrera = null;
				Date fechaInicioBarrera = null;
				String tipoOperacion = historicoOpcion.getTipoOperacion();
				if("A".equalsIgnoreCase(estado)) {
					Set<HistoricoBarrera> historicoBarreras = historicoOperacion.getHistoricoBarreras();
					for (HistoricoBarrera historicoBarrera : historicoBarreras) {
						String tipopera = historicoBarrera.getId().getTipopera();
						String tipbarp1 = historicoBarrera.getId().getTipbarp1();
						if(tipoOperacion.equalsIgnoreCase(tipopera) && tipbarp1.endsWith("O") && historicoBarrera.getFevaltoq() == null) {
							tipoBarrera = historicoBarrera.getTipobarr();
							fechaInicioBarrera = historicoBarrera.getFeciniba();
						}
					}
				} else if("I".equalsIgnoreCase(estado)) {
					Set<HistoricoBarrera> historicoBarreras = historicoOperacion.getHistoricoBarreras();
					for (HistoricoBarrera historicoBarrera : historicoBarreras) {
						String tipopera = historicoBarrera.getId().getTipopera();
						String tipbarp1 = historicoBarrera.getId().getTipbarp1();
						if(tipoOperacion.equalsIgnoreCase(tipopera) && tipbarp1.endsWith("I") && historicoBarrera.getFevaltoq() == null) {
							tipoBarrera = historicoBarrera.getTipobarr();
							fechaInicioBarrera = historicoBarrera.getFeciniba();
						}
					}
				}
				Date fechamis = mantOperBo.getFechamis();
				if("I".equalsIgnoreCase(tipoBarrera)) {
					if(fechaInicioBarrera != null) {
						if(fechamis.compareTo(fechaInicioBarrera) >= 0) {
							return true;
						}
					}
				} else if("E".equalsIgnoreCase(tipoBarrera)) {
					int cuantosSituparm = mantOperBo.cuantosSituparm(historicoOperacion,fechamis);
					if(cuantosSituparm > 0) {
						return true;
					}
				}
			}
		}
		return false;
	}
	public String irMantToqe(){
		origen = Constantes.ORIGEN_PRODCOM; //Cuando se va desde se comporta como si viniera de OPE
		
		VistaOperacion vo = operacionesProdCompuestos.getVistaOperacion();
		listaErrores.clear();		
		String ret = Constantes.FAIL;
		if(vo != null) {
			historicoOperacion = vo.getHistOper();
			DescripcionEstadoOperacion estado = historicoOperacion.getEstado();
			if(estado != null) {
				if(Constantes.ESTADO_VA.equalsIgnoreCase(estado.getCodigo()) || !mantOperBo.validatePendientesAgendaModif(historicoOperacion)) {
					if(!operacionOpcPendienteActivarAgenda(historicoOperacion, Constantes.TIPO_EVENTO_BARRERA)) {
						if(existenFechasValidasTBarr(historicoOperacion)) {
							dbLockService.bloqueo(HistoricoOperacion.class, historicoOperacion.getId());							
							ret = Constantes.SUCCESS;
						} else {
							//No existen fechas de ejercicio válidas a fecha de hoy para la operación
							addWarning(historicoOperacion,ResourceBundle.instance().getString("mantOper.messages.toqueBarrera.noFechas"));
						}
					} else {
						//Operación pendiente de procesar por la agenda. Vuelva a intentarlo en unos minutos
						addWarning(historicoOperacion,ResourceBundle.instance().getString("mantOper.messages.toqueBarrera.agenda"));
					}
				}
			}
		}
		if(listaErrores.size() > 0){
			msgBoxFinalStep();
			prepareMsgBox("toqueBarrera");
		}
		return ret;		
		
	}
	
	/**
	 * Desbloquea la estructura y vuelve al home
	 */
	public String salirListaOperaciones(){
		if (timestampInicial!=null && !consulta){
			if (!validarTiempos()){
				statusMessages.add(Severity.WARN, "#{messages['boletaprodcompuestos.salirlistaoperaciones.error']}");
				return Constantes.FAIL;
			} 
		}
		
		//desbloqueamos la estructura
		if(GenericUtils.isNullOrBlank(consulta) || !consulta){
			dbLockService.desbloqueo(HistoricoProductoCompuesto.class,
					boletaProdCompuestosPantalla.getHistoricoProductoCompuesto().getId());
		}else{
			consulta = false;	
		}
		//Redirigimos a la pantalla desde la que se ha llegado
		Conversation conversacion=Conversation.instance();
		
		//Si hemos entrado por mantprod volvemos a la pantalla anterior, si no al menú
		if ("MANTPROD".equalsIgnoreCase(pantalla)){
			conversacion.redirectToParent();
		} else {
			//matamos conversación anidada porque volvemos al home
			menuBean.clickAndKillLastConversation("/home.xhtml");
		}
		return Constantes.SUCCESS;
	}
	
	private boolean validarTiempos() {
		
		IndicadorConfirmacion indicadorConfirmacion =null;
		if (boletaProdCompuestosPantalla.isConfconjunta() && 
			boletaProdCompuestosPantalla.getHistoricoProductoCompuesto().getContrapartida()!=null &&
			!"MODELO".equals(boletaProdCompuestosPantalla.getHistoricoProductoCompuesto().getContrapartida().getId()) && 
			!"FDI".equals(boletaProdCompuestosPantalla.getHistoricoProductoCompuesto().getContrapartida().getId())){
			
			OperacionId operacionId = new OperacionId(boletaProdCompuestosPantalla.getHistoricoProductoCompuesto().getFechaContratacion(),
					boletaProdCompuestosPantalla.getHistoricoProductoCompuesto().getId().getEstructu());
			
			indicadorConfirmacion = 	boletaProdCompuestoBo.cargarIndicadorConfirmacion(operacionId);
		}
		
		if ((boletaProdCompuestosPantalla.getHistoricoProductoCompuesto().getAuditData().getFechaUltimaModi().compareTo(timestampInicial) > 0 )
		||  (indicadorConfirmacion!=null && indicadorConfirmacion.getAuditData().getFechaUltimaModi().compareTo(timestampInicial) > 0)) {
			return false;	
		}
		
		List<OperacionesProdCompuestos> q1 = null; 
		if (listaOperacionesProdCompuestos!=null && listaOperacionesProdCompuestos.size()<11){
			q1 = listaOperacionesProdCompuestos;
		}else{
			q1 = obtenerlistaOperaciones();
		}
	
		if (q1!=null){
			for (OperacionesProdCompuestos element : q1) {
//				if (element.getVistaOperacion()!=null){
//					log.error(element.getVistaOperacion().getHistOper().getId().getFechaModificacion().toString());	
//					log.error("STAMP "+timestampInicial.toString());
//				}
				if (element.getVistaOperacion()!=null && element.getVistaOperacion().getHistOper().getId().getFechaModificacion().compareTo(timestampInicial)> 0){
					return false;
				}
			}	
		}
		
		
		
		return true;
	}


	private List<OperacionesProdCompuestos> obtenerlistaOperaciones() {
		List<OperacionesProdCompuestos> q1 = null; 
		if("MANTPROD".equals(pantalla)){
			q1 = 
				(List<OperacionesProdCompuestos>)boletaProdCompuestoBo.obtenerListaOperacionesProdCompMod(estructuraId.toString(), getPaginationData().getPaginationDataForExcel()) ;
		}else{
			q1 = 
			(List<OperacionesProdCompuestos>)boletaProdCompuestoBo.obtenerListaOperacionesProdComp(boletaProdCompuestosPantalla.getHistoricoProductoCompuesto(), getPaginationData().getPaginationDataForExcel()) ;		
		}
		return q1;
	}


	public String getVarModif() {
		return varModif;
	}
	public void setVarModif(String varModif) {
		this.varModif = varModif;
	}
	
	/********************************************************************/
	/****			BOTONERA LISTA OPERACIONES FIN				*********/
	/********************************************************************/
	public void cargarLista(){
		
		
		if("MANTPROD".equals(pantalla)){
			if("S".equals(boletaProdCompuestosPantalla.getHistoricoProductoCompuesto().getIndConfirmacionConjunta())){
				boletaProdCompuestosPantalla.setConfconjunta(true);
			}else{
				if("N".equals(boletaProdCompuestosPantalla.getHistoricoProductoCompuesto().getIndConfirmacionConjunta())){
					boletaProdCompuestosPantalla.setConfconjunta(false);
				}
			}
			if ("S".equals(boletaProdCompuestosPantalla.getHistoricoProductoCompuesto().getIndEstructuraModelo()) ){
				boletaProdCompuestosPantalla.setEstructmodelo(true);
			}else{
				if ("N".equals(boletaProdCompuestosPantalla.getHistoricoProductoCompuesto().getIndEstructuraModelo()) ){
					boletaProdCompuestosPantalla.setEstructmodelo(false);
				}
			}
			
			if("S".equals(boletaProdCompuestosPantalla.getHistoricoProductoCompuesto().getIndNeteoLiquidaciones()) ){
				boletaProdCompuestosPantalla.setNeteoliq(true);
			}else{
				if("N".equals(boletaProdCompuestosPantalla.getHistoricoProductoCompuesto().getIndNeteoLiquidaciones()) ){
					boletaProdCompuestosPantalla.setNeteoliq(false);
				}
			}
			
			if(!GenericUtils.isNullOrBlank(boletaProdCompuestosPantalla.getHistoricoProductoCompuesto().getCatalogoProdCompuesto())){
				boletaProdCompuestosPantalla.setProcedenciaProductoSelect(boletaProdCompuestosPantalla.getHistoricoProductoCompuesto().getCatalogoProdCompuesto().getProcedenciaProducto());
			}			
			if(!GenericUtils.isNullOrBlank(boletaProdCompuestosPantalla.getHistoricoProductoCompuesto().getTransaccion())){
				boletaProdCompuestosPantalla.setDescripcionTransaccionOperacionSelect(boletaProdCompuestoBo.obtenerTransaccion(boletaProdCompuestosPantalla.getHistoricoProductoCompuesto().getTransaccion()));
			}
			if(!GenericUtils.isNullOrBlank(boletaProdCompuestosPantalla.getHistoricoProductoCompuesto().getProducto())){
				
			}
			
//			if (!alta && !ModoPantalla.CREACION.equals(modoPantalla)){
//				consulta = true;
//			}
		}else if (ModoPantalla.CREACION.equals(modoPantalla)){
			alta = true;
		}else{
			alta = false;
		}
		
		cargaInicialOperacionesProdComp();
		if (isPrimerAcceso()){
			getPaginationData().reset();
		}
		
		if(GenericUtils.isNullOrBlank(varModif)){
			varModif = Constantes.CONSTANTE_NO;
		}
		//Nullpointer
		if (consulta == null) consulta = false;
		
		refrescarLista();
		if (isPrimerAcceso()){
			setPrimerAcceso(false);
	
		}
		
	}
	
	public void cargaInicialOperacionesProdComp() {
				
		if (boletaProdCompuestosPantalla.isConoperexistentes()){
			boletaProdCompuestosPantalla.setBotonAnadir(true);			
		}else{
			boletaProdCompuestosPantalla.setBotonAnadir(false);
		}
		
		if (GenericUtils.isNullOrBlank(boletaProdCompuestosPantalla.getVartipo())){
			if(boletaProdCompuestosPantalla.getHistoricoProductoCompuesto()!=null && boletaProdCompuestosPantalla.getHistoricoProductoCompuesto().getCatalogoProdCompuesto()!=null && boletaProdCompuestoBo.obtenerTipoProductoCompuesto(boletaProdCompuestosPantalla.getHistoricoProductoCompuesto().getCatalogoProdCompuesto().getId())==0){
				boletaProdCompuestosPantalla.setVartipo("L");
			}else{
				boletaProdCompuestosPantalla.setVartipo("D");
			}
		}
		
		if (boletaProdCompuestosPantalla.getVartipo().equals("D")){
			boletaProdCompuestosPantalla.setFilaSelecObligatoria(true);
		}else if (boletaProdCompuestosPantalla.getVartipo().equals("L")){
			boletaProdCompuestosPantalla.setFilaSelecObligatoria(false);
		} 
	}

	/********************************************************/
	/** Pantalla Confirmaciones Productos Compuestos - INI **/
	/********************************************************/
	
	public void limpiarIdiomaAndCanal(){
		
		boletaProdCompuestosPantalla.setCanceEnviar(false);
		boletaProdCompuestosPantalla.setCanceRecibir(false);
		boletaProdCompuestosPantalla.setCanceParEnviar(false);
		boletaProdCompuestosPantalla.setCanceParRecibir(false);
		boletaProdCompuestosPantalla.setContraEnviar(false);
		boletaProdCompuestosPantalla.setContraRecibir(false);
		boletaProdCompuestosPantalla.setFijTipEnviar(false);
		boletaProdCompuestosPantalla.setFijTipRecibir(false);
		boletaProdCompuestosPantalla.setLiquiEnviar(false);
		boletaProdCompuestosPantalla.setLiquiRecibir(false);
		boletaProdCompuestosPantalla.setModifEnviar(false);
		boletaProdCompuestosPantalla.setModifRecibir(false);
		
		
		boletaProdCompuestosPantalla.setIdiomaContraSelect(null);
		boletaProdCompuestosPantalla.setIdiomaModifSelect(null);
		boletaProdCompuestosPantalla.setIdiomaCanceSelect(null);
		boletaProdCompuestosPantalla.setIdiomaCanceParSelect(null);
		boletaProdCompuestosPantalla.setIdiomaLiquiSelect(null);
		boletaProdCompuestosPantalla.setIdiomaFijTipSelect(null);
		boletaProdCompuestosPantalla.setIdiomaContraList(null);
		boletaProdCompuestosPantalla.setIdiomaModifList(null);
		boletaProdCompuestosPantalla.setIdiomaCanceList(null);
		boletaProdCompuestosPantalla.setIdiomaCanceParList(null);
		boletaProdCompuestosPantalla.setIdiomaLiquiList(null);
		boletaProdCompuestosPantalla.setIdiomaFijTipList(null);
		
		boletaProdCompuestosPantalla.setCanalContraESelect(null);
		boletaProdCompuestosPantalla.setCanalContraRSelect(null);
		boletaProdCompuestosPantalla.setCanalModifESelect(null);
		boletaProdCompuestosPantalla.setCanalModifRSelect(null);
		boletaProdCompuestosPantalla.setCanalCanceESelect(null);
		boletaProdCompuestosPantalla.setCanalCanceRSelect(null);
		boletaProdCompuestosPantalla.setCanalCanceParESelect(null);
		boletaProdCompuestosPantalla.setCanalCanceParRSelect(null);
		boletaProdCompuestosPantalla.setCanalLiquiESelect(null);
		boletaProdCompuestosPantalla.setCanalLiquiRSelect(null);
		boletaProdCompuestosPantalla.setCanalFijTipESelect(null);
		boletaProdCompuestosPantalla.setCanalFijTipRSelect(null);
		boletaProdCompuestosPantalla.setCanalContraEList(null);
		boletaProdCompuestosPantalla.setCanalContraRList(null);
		boletaProdCompuestosPantalla.setCanalModifEList(null);
		boletaProdCompuestosPantalla.setCanalModifRList(null);
		boletaProdCompuestosPantalla.setCanalCanceEList(null);;
		boletaProdCompuestosPantalla.setCanalCanceRList(null);
		boletaProdCompuestosPantalla.setCanalCanceParEList(null);
		boletaProdCompuestosPantalla.setCanalCanceParRList(null);
		boletaProdCompuestosPantalla.setCanalLiquiEList(null);
		boletaProdCompuestosPantalla.setCanalLiquiRList(null);
		boletaProdCompuestosPantalla.setCanalFijTipEList(null);
		boletaProdCompuestosPantalla.setCanalFijTipRList(null);	
		
		idiomaContraHabilitado = true;			
		idiomaModifHabilitado = true;
		idiomaCanceHabilitado = true;
		idiomaCanceParHabilitado = true;
		idiomaLiquiHabilitado = true;
		idiomaFijTipHabilitado = true;
	}

	public void buildListaIdiomaPlantilla(){
		List<PlantillasConfirmacion> plantillaList = null;
		Idioma idiomaContrapartida = null;
		Idioma idiomaPorDefecto = null;
		
		//SMM no es producat, sino prodcomp
		String prodcom = boletaProdCompuestosPantalla.getHistoricoProductoCompuesto().getCatalogoProdCompuesto().getId()+"";
		String tipoPlantilla = boletaProdCompuestosPantalla.getTipoPlantillaSelect()==null?null:boletaProdCompuestosPantalla.getTipoPlantillaSelect().getCodigoca();
		//Limpiar los idiomas seleccionados si no seleccionamos tipoPlantilla
		if (tipoPlantillaHabilitado && GenericUtils.isNullOrBlank(tipoPlantilla)){
			limpiarIdiomaAndCanal();			
			return;			
		}
		Contrapartida contrapartida = boletaProdCompuestosPantalla.getHistoricoProductoCompuesto().getContrapartida();
		
		if (!GenericUtils.isNullOrBlank(boletaProdCompuestosPantalla.getHistoricoProductoCompuesto().getContrapartida())){
			if (!GenericUtils.isNullOrBlank(contrapartida.getIdioma())){
				idiomaContrapartida = boletaProdCompuestoBo.cargarIdioma(contrapartida.getIdioma());
				idiomaPorDefecto = idiomaContrapartida;
			}else{
				idiomaContrapartida= null;
				idiomaPorDefecto = boletaProdCompuestoBo.cargarIdioma("08");
			}
		
		
		}
//		if (GenericUtils.isNullOrBlank(idiomaContrapartida))				
//			idiomaPorDefecto = boletaProdCompuestoBo.cargarIdioma("8");
		
		//Contratración
		plantillaList = boletaProdCompuestoBo.obtenerPlantillasConfirmacion(prodcom, Constantes.EVENTO_CONTRATACION, tipoPlantilla);		
		rellenarIdiomaCanal(Constantes.EVENTO_CONTRATACION, plantillaList, idiomaContrapartida, idiomaPorDefecto);
		
		//Modificación
		plantillaList = boletaProdCompuestoBo.obtenerPlantillasConfirmacion(prodcom, Constantes.EVENTO_MODIFICACION, tipoPlantilla);
		rellenarIdiomaCanal(Constantes.EVENTO_MODIFICACION, plantillaList, idiomaContrapartida, idiomaPorDefecto);
		
		//Cancelación
		plantillaList = boletaProdCompuestoBo.obtenerPlantillasConfirmacion(prodcom, Constantes.EVENTO_CANCELACION, tipoPlantilla);
		rellenarIdiomaCanal(Constantes.EVENTO_CANCELACION, plantillaList, idiomaContrapartida, idiomaPorDefecto);
		
		//Canc.Parcial
		plantillaList = boletaProdCompuestoBo.obtenerPlantillasConfirmacion(prodcom, Constantes.EVENTO_CANCPARCIAL, tipoPlantilla);
		rellenarIdiomaCanal(Constantes.EVENTO_CANCPARCIAL, plantillaList, idiomaContrapartida, idiomaPorDefecto);

		//Liquidación
		plantillaList = boletaProdCompuestoBo.obtenerPlantillasConfirmacion(prodcom, Constantes.EVENTO_LIQUIDACION, tipoPlantilla);
		rellenarIdiomaCanal(Constantes.EVENTO_LIQUIDACION, plantillaList, idiomaContrapartida, idiomaPorDefecto);
		
		//Fij.Tipos			
		plantillaList = boletaProdCompuestoBo.obtenerPlantillasConfirmacion(prodcom, Constantes.EVENTO_FIJTIPOS, tipoPlantilla);
		rellenarIdiomaCanal(Constantes.EVENTO_FIJTIPOS, plantillaList, idiomaContrapartida, idiomaPorDefecto);		
	}		

	/**
	 * Devuelve el canal manual para el evento, sentido y tipoContrapartida pasados por parámetro
	 * @param evento
	 * @param sentido
	 * @param tipoContrapartida
	 * @return
	 */
	public CanalConfirmacion cargarCanalManual(String evento, String sentido, String tipoContrapartida){
		CanalConfirmacionId canalPorDefectoId = new CanalConfirmacionId();
		canalPorDefectoId.setCodcanal(Constantes.CANAL_MANUAL);
		canalPorDefectoId.setEvenconf(evento);
		canalPorDefectoId.setSentido(sentido);
		canalPorDefectoId.setTipcontr(tipoContrapartida);
		desHabilitarCanal(evento, sentido);
		return boletaProdCompuestoBo.cargarCanal(canalPorDefectoId);
	}
	
	/**
	 * 
	 * @param contrapartida
	 * @param producat
	 * @param evento
	 * @param sentido
	 * @param tipoContrapartida
	 * @return
	 */
	public CanalConfDefecto cargarCanalConfDefecto(String contrapartida,
			String producat, String evento, String sentido,
			String tipoContrapartida) {

		CanalConfDefecto canalConfDefecto = null;
		CanalConfDefectoId canalPorDefectoId = new CanalConfDefectoId();
		canalPorDefectoId.setContrapartida(contrapartida);
		canalPorDefectoId.setProducat(producat);
		canalPorDefectoId.setEventoConfirmacion(evento);
		canalPorDefectoId.setSentido(sentido);
		canalPorDefectoId.setTipcontr(tipoContrapartida);
		canalConfDefecto = boletaProdCompuestoBo.cargarCanalConfDefecto(canalPorDefectoId);
		if (GenericUtils.isNullOrBlank(canalConfDefecto)) {
			canalPorDefectoId.setContrapartida("ZZZ");
			canalConfDefecto = boletaProdCompuestoBo.cargarCanalConfDefecto(canalPorDefectoId);
		}

		return canalConfDefecto;
	}
	
	public CanalConfirmacion obtenerCanalConfirmacion(List<CanalConfirmacion> canalList, Contrapartida contrapartida, String evento, String prodcom, String sentido){
		CanalConfirmacion canalConfirmacionReturn = null;
		boolean canalExiste = false;
		if (GenericUtils.isNullOrBlank(canalList) || canalList.isEmpty()){
			canalConfirmacionReturn = cargarCanalManual(evento, sentido, contrapartida.getId());			
			desHabilitarIdioma(evento);
		}else{	
			//carga por defecto lo que haya de la tabla deri.candefto
			CanalConfDefecto canalConfDefecto = cargarCanalConfDefecto(contrapartida.getId(), prodcom, evento,sentido, contrapartida.getTipoContrapartida().getId());

			//MERCADO: Si no se encuentra ninguno de los 2 en candefto, mostrar el primero de la lista
			// de canconfi, o si el que se encuentra no existe en canconfi
			if (!GenericUtils.isNullOrBlank(canalConfDefecto)){
				for(CanalConfirmacion canalConfirmacion:canalList){
					if (canalConfirmacion.getId().getCodcanal().equalsIgnoreCase(canalConfDefecto.getCodcanal())){						
						canalConfirmacionReturn = canalConfirmacion;
						canalExiste= true;
						break;
					}
				}
				if (!canalExiste){
					canalConfirmacionReturn = canalList.get(0);
				}
			}else{
				canalConfirmacionReturn = canalList.get(0);
			}	
		}
		return canalConfirmacionReturn;
		
	}
	
	/**
	 * Devuelve el idioma de la lista idiomaList cuyo código es igual al del idiomaPorDefecto
	 * @param idiomaList
	 * @param idiomaPorDefecto
	 * @return
	 */
	public Idioma cargarIdiomaPorDefecto(List<Idioma> idiomaList, Idioma idiomaPorDefecto){
		//Necesario porque idiomaList se carga con ResultTransformer y al compara los objetos no coinciden
		int codigoList;
		int codigoDefecto = Integer.parseInt(idiomaPorDefecto.getCodigo());
		for (Idioma id: idiomaList){
			codigoList = Integer.parseInt(id.getCodigo());
			if (codigoList == codigoDefecto){
				return id;				
			}
		}
		return null;
	}
	
	public Idioma cargarIdiomaContrapartida(List<PlantillasConfirmacion> plantillasList, Idioma idiomaContrapartida){
		//Recorrer la lista de plantillas y ver si existe el idioma contrapartida
		if (!GenericUtils.isNullOrBlank(idiomaContrapartida)){
			for (PlantillasConfirmacion pc: plantillasList){
				if (pc.getIdiomaco().equals(idiomaContrapartida)){
					return idiomaContrapartida;													
				}
			}			
		}
		return null;
	}
	

	public Idioma cargarIdiomaContrapartidaV2(List<Idioma> idiomaList, Idioma idiomaContrapartida){
		//Recorrer la lista de plantillas y ver si existe el idioma contrapartida
		if (!GenericUtils.isNullOrBlank(idiomaContrapartida)){
			for (Idioma pc: idiomaList){
				if (pc.getCodigo().equals(idiomaContrapartida.getCodigo())){
					return (Idioma) idiomaContrapartida;													
				}
			}			
		}
		return null;
	}

	
	
	public void rellenarCanales(String evento, List<CanalConfirmacion> canalEList, List<CanalConfirmacion> canalRList,
			CanalConfirmacion canalE, CanalConfirmacion canalR){
		if (canalEList.isEmpty())
			canalEList.add(canalE);
		if (canalRList.isEmpty())
			canalRList.add(canalR);
		if (evento.equals(Constantes.EVENTO_CONTRATACION)){
			boletaProdCompuestosPantalla.setCanalContraESelect(canalE);
			boletaProdCompuestosPantalla.setCanalContraRSelect(canalR);
			boletaProdCompuestosPantalla.getCanalContraEList().clear();
			boletaProdCompuestosPantalla.getCanalContraEList().addAll(canalEList);
			boletaProdCompuestosPantalla.getCanalContraRList().clear();
			boletaProdCompuestosPantalla.getCanalContraRList().addAll(canalRList);
		}else if(evento.equals(Constantes.EVENTO_MODIFICACION)){
			boletaProdCompuestosPantalla.getCanalModifEList().clear();
			boletaProdCompuestosPantalla.getCanalModifRList().clear();

			boletaProdCompuestosPantalla.getCanalModifEList().addAll(canalEList);
			boletaProdCompuestosPantalla.getCanalModifRList().addAll(canalRList);

			boletaProdCompuestosPantalla.setCanalModifESelect(canalE);
			boletaProdCompuestosPantalla.setCanalModifRSelect(canalR);	
		}else if(evento.equals(Constantes.EVENTO_CANCELACION)){
			
			boletaProdCompuestosPantalla.getCanalCanceEList().clear();
			boletaProdCompuestosPantalla.getCanalCanceRList().clear();

			
			
			boletaProdCompuestosPantalla.getCanalCanceEList().addAll(canalEList);
			boletaProdCompuestosPantalla.getCanalCanceRList().addAll(canalRList);
			boletaProdCompuestosPantalla.setCanalCanceESelect(canalE);
			boletaProdCompuestosPantalla.setCanalCanceRSelect(canalR);	
		}else if(evento.equals(Constantes.EVENTO_CANCPARCIAL)){
			boletaProdCompuestosPantalla.getCanalCanceParEList().clear();
			boletaProdCompuestosPantalla.getCanalCanceParRList().clear();

			
			boletaProdCompuestosPantalla.getCanalCanceParEList().addAll(canalEList);
			boletaProdCompuestosPantalla.getCanalCanceParRList().addAll(canalRList);
			boletaProdCompuestosPantalla.setCanalCanceParESelect(canalE);
			boletaProdCompuestosPantalla.setCanalCanceParRSelect(canalR);	
		}else if(evento.equals(Constantes.EVENTO_LIQUIDACION)){
			boletaProdCompuestosPantalla.getCanalLiquiEList().clear();
			boletaProdCompuestosPantalla.getCanalLiquiRList().clear();

			boletaProdCompuestosPantalla.getCanalLiquiEList().addAll(canalEList);
			boletaProdCompuestosPantalla.getCanalLiquiRList().addAll(canalRList);
			boletaProdCompuestosPantalla.setCanalLiquiESelect(canalE);
			boletaProdCompuestosPantalla.setCanalLiquiRSelect(canalR);	
		}else if(evento.equals(Constantes.EVENTO_FIJTIPOS)){
			boletaProdCompuestosPantalla.getCanalFijTipEList().clear();
			boletaProdCompuestosPantalla.getCanalFijTipRList().clear();

			boletaProdCompuestosPantalla.getCanalFijTipEList().addAll(canalEList);
			boletaProdCompuestosPantalla.getCanalFijTipRList().addAll(canalRList);
			boletaProdCompuestosPantalla.setCanalFijTipESelect(canalE);
			boletaProdCompuestosPantalla.setCanalFijTipRSelect(canalR);	
		}
	}
	
	public void rellenarIdiomas(String evento, List<Idioma> idiomaList, Idioma idioma){
		Idioma idiomaPorDefecto = idioma;
		List<Idioma> idiomaListAux = new ArrayList<Idioma>();
		
		if (idiomaList.isEmpty()){					
			idiomaListAux.add(idiomaPorDefecto);
		}else{
			//Necesario porque idiomaList se carga con ResultTransformer y al compara los objetos no coinciden
			idiomaPorDefecto = cargarIdiomaPorDefecto(idiomaList, idiomaPorDefecto);
			idiomaListAux.addAll(idiomaList);
		}		
		
		if (evento.equals(Constantes.EVENTO_CONTRATACION)){
			boletaProdCompuestosPantalla.setIdiomaContraSelect(idiomaPorDefecto);
			boletaProdCompuestosPantalla.getIdiomaContraList().clear();
			boletaProdCompuestosPantalla.getIdiomaContraList().addAll(idiomaListAux);
		}else if(evento.equals(Constantes.EVENTO_MODIFICACION)){
			boletaProdCompuestosPantalla.setIdiomaModifSelect(idiomaPorDefecto);
			boletaProdCompuestosPantalla.getIdiomaModifList().clear();
			boletaProdCompuestosPantalla.getIdiomaModifList().addAll(idiomaListAux);
		}else if (evento.equals(Constantes.EVENTO_CANCELACION)){
			boletaProdCompuestosPantalla.setIdiomaCanceSelect(idiomaPorDefecto);
			boletaProdCompuestosPantalla.getIdiomaCanceList().clear();
			boletaProdCompuestosPantalla.getIdiomaCanceList().addAll(idiomaListAux);
		}else if(evento.equals(Constantes.EVENTO_CANCPARCIAL)){
			boletaProdCompuestosPantalla.setIdiomaCanceParSelect(idiomaPorDefecto);
			boletaProdCompuestosPantalla.getIdiomaCanceParList().clear();
			boletaProdCompuestosPantalla.getIdiomaCanceParList().addAll(idiomaListAux);
		}else if(evento.equals(Constantes.EVENTO_LIQUIDACION)){
			boletaProdCompuestosPantalla.setIdiomaLiquiSelect(idiomaPorDefecto);
			boletaProdCompuestosPantalla.getIdiomaLiquiList().clear();
			boletaProdCompuestosPantalla.getIdiomaLiquiList().addAll(idiomaListAux);
		}else if(evento.equals(Constantes.EVENTO_FIJTIPOS)){
			boletaProdCompuestosPantalla.setIdiomaFijTipSelect(idiomaPorDefecto);
			boletaProdCompuestosPantalla.getIdiomaFijTipList().clear();
			boletaProdCompuestosPantalla.getIdiomaFijTipList().addAll(idiomaListAux);
		}		
	}	
	
	public void rellenarIdiomaCanal(String evento, List<PlantillasConfirmacion> plantillasList, Idioma idiomaContrapartida, Idioma idiomaPorDefectoIn){
		
		Idioma idiomaPorDefecto = idiomaPorDefectoIn;
		Idioma idiomaAux = null;
		CanalConfirmacion canalE = null;
		CanalConfirmacion canalR = null;
		String tipoPlantilla = null;
		Contrapartida contrapartida = boletaProdCompuestosPantalla.getHistoricoProductoCompuesto().getContrapartida();
		List<CanalConfirmacion> canalEList = new ArrayList<CanalConfirmacion>();
		List<CanalConfirmacion> canalRList = new ArrayList<CanalConfirmacion>();
		
		String prodcom = boletaProdCompuestosPantalla.getHistoricoProductoCompuesto().getCatalogoProdCompuesto().getId()+"";
		tipoPlantilla = boletaProdCompuestosPantalla.getTipoPlantillaSelect()==null?null:boletaProdCompuestosPantalla.getTipoPlantillaSelect().getCodigoca();
		
		List<Idioma> idiomaList = new ArrayList<Idioma>();
		
		if (!GenericUtils.isNullOrBlank(evento)){
//			if (!plantillasList.isEmpty()){
//			if (!GenericUtils.isNullOrBlank(tipoPlantilla)){	
				
				idiomaList.addAll(boletaProdCompuestoBo.buildListaIdiomaPlantilla(tipoPlantilla,
						evento, prodcom));

				if (!idiomaList.isEmpty()){			
					//Verifica que el idioma de la contrapartida exista en la plantilla
	//				idiomaAux = cargarIdiomaContrapartida(plantillasList, idiomaContrapartida);
					idiomaAux = cargarIdiomaContrapartidaV2(idiomaList, idiomaContrapartida);
					if (!GenericUtils.isNullOrBlank(idiomaAux)){
						idiomaPorDefecto = idiomaAux;
					}
					
					canalEList.addAll(boletaProdCompuestoBo.obtenerCanales(evento, Constantes.SENTIDO_ENVIAR, contrapartida.getTipoContrapartida().getId()));
					canalE = obtenerCanalConfirmacion(canalEList, contrapartida, evento, prodcom,Constantes.SENTIDO_ENVIAR);					
	
					canalRList.addAll(boletaProdCompuestoBo.obtenerCanales(evento, Constantes.SENTIDO_RECIBIR, contrapartida.getTipoContrapartida().getId()));
					canalR = obtenerCanalConfirmacion(canalRList, contrapartida, evento, prodcom,Constantes.SENTIDO_RECIBIR);									
					habilitarIdioma(evento);
					habilitarCanal(evento, Constantes.SENTIDO_RECIBIR);
					habilitarCanal(evento, Constantes.SENTIDO_ENVIAR);
				}else{
					//MERCADO: Siempre existirá un canal Manual
					canalE = cargarCanalManual(evento, Constantes.SENTIDO_ENVIAR, boletaProdCompuestosPantalla.getHistoricoProductoCompuesto().getContrapartida().getTipoContrapartida().getId());
					canalR = cargarCanalManual(evento, Constantes.SENTIDO_RECIBIR, boletaProdCompuestosPantalla.getHistoricoProductoCompuesto().getContrapartida().getTipoContrapartida().getId());					
					desHabilitarIdioma(evento);
				}
//			}else{
//				if (!GenericUtils.isNullOrBlank(idiomaContrapartida)){
//					idiomaPorDefecto = idiomaContrapartida;
//				}
//				//MERCADO: Siempre existirá un canal Manual
//				canalE = cargarCanalManual(evento, Constantes.SENTIDO_ENVIAR, boletaProdCompuestosPantalla.getHistoricoProductoCompuesto().getContrapartida().getTipoContrapartida().getId());
//				canalR = cargarCanalManual(evento, Constantes.SENTIDO_RECIBIR, boletaProdCompuestosPantalla.getHistoricoProductoCompuesto().getContrapartida().getTipoContrapartida().getId());
//				//Proteger Canal - no existe placonfi			
//			}
			rellenarIdiomas(evento, idiomaList, idiomaPorDefecto);
			rellenarCanales(evento, canalEList, canalRList, canalE, canalR);
						
		}
	}
	
	public void desHabilitarIdioma(String evento){
		if (evento.equals(Constantes.EVENTO_CONTRATACION)){
			idiomaContraHabilitado = false;			
		}else if(evento.equals(Constantes.EVENTO_MODIFICACION)){
			idiomaModifHabilitado = false;
		}else if (evento.equals(Constantes.EVENTO_CANCELACION)){
			idiomaCanceHabilitado = false;
		}else if(evento.equals(Constantes.EVENTO_CANCPARCIAL)){
			idiomaCanceParHabilitado = false;
		}else if(evento.equals(Constantes.EVENTO_LIQUIDACION)){
			idiomaLiquiHabilitado = false;
		}else if(evento.equals(Constantes.EVENTO_FIJTIPOS)){
			idiomaFijTipHabilitado = false;
		}
	}

	
	public void habilitarIdioma(String evento){
		if (evento.equals(Constantes.EVENTO_CONTRATACION)){
			idiomaContraHabilitado = true;			
		}else if(evento.equals(Constantes.EVENTO_MODIFICACION)){
			idiomaModifHabilitado = true;
		}else if (evento.equals(Constantes.EVENTO_CANCELACION)){
			idiomaCanceHabilitado = true;
		}else if(evento.equals(Constantes.EVENTO_CANCPARCIAL)){
			idiomaCanceParHabilitado = true;
		}else if(evento.equals(Constantes.EVENTO_LIQUIDACION)){
			idiomaLiquiHabilitado = true;
		}else if(evento.equals(Constantes.EVENTO_FIJTIPOS)){
			idiomaFijTipHabilitado = true;
		}
	}
	
	public void desHabilitarCanal(String evento, String sentido){
		if (evento.equals(Constantes.EVENTO_CONTRATACION)){
			if (sentido.equals(Constantes.SENTIDO_ENVIAR))
				canalContraHabilitado = false;
			else
				canalContraRecHabilitado = false;
		}else if(evento.equals(Constantes.EVENTO_MODIFICACION)){
			if (sentido.equals(Constantes.SENTIDO_ENVIAR))
				canalModifHabilitado = false;
			else
				canalModifRecHabilitado = false;
		}else if (evento.equals(Constantes.EVENTO_CANCELACION)){
			if (sentido.equals(Constantes.SENTIDO_ENVIAR))
				canalCanceHabilitado = false;
			else
				canalCanceRecHabilitado = false;
		}else if(evento.equals(Constantes.EVENTO_CANCPARCIAL)){
			if (sentido.equals(Constantes.SENTIDO_ENVIAR))
				canalCanceParHabilitado = false;
			else
				canalCanceRecParHabilitado = false;
		}else if(evento.equals(Constantes.EVENTO_LIQUIDACION)){
			if (sentido.equals(Constantes.SENTIDO_ENVIAR))
				canalLiquiHabilitado = false;
			else
				canalLiquiRecHabilitado = false;
		}else if(evento.equals(Constantes.EVENTO_FIJTIPOS)){
			if (sentido.equals(Constantes.SENTIDO_ENVIAR))
				canalFijTipHabilitado = false;
			else
				canalFijTipRecHabilitado = false;
		}
	}

	public void habilitarCanal(String evento, String sentido){
		if (evento.equals(Constantes.EVENTO_CONTRATACION)){
			if (sentido.equals(Constantes.SENTIDO_ENVIAR))
				canalContraHabilitado = true;
			else
				canalContraRecHabilitado = true;
		}else if(evento.equals(Constantes.EVENTO_MODIFICACION)){
			if (sentido.equals(Constantes.SENTIDO_ENVIAR))
				canalModifHabilitado = true;
			else
				canalModifRecHabilitado = true;
		}else if (evento.equals(Constantes.EVENTO_CANCELACION)){
			if (sentido.equals(Constantes.SENTIDO_ENVIAR))
				canalCanceHabilitado = true;
			else
				canalCanceRecHabilitado = true;
		}else if(evento.equals(Constantes.EVENTO_CANCPARCIAL)){
			if (sentido.equals(Constantes.SENTIDO_ENVIAR))
				canalCanceParHabilitado = true;
			else
				canalCanceRecParHabilitado = true;
		}else if(evento.equals(Constantes.EVENTO_LIQUIDACION)){
			if (sentido.equals(Constantes.SENTIDO_ENVIAR))
				canalLiquiHabilitado = true;
			else
				canalLiquiRecHabilitado = true;
		}else if(evento.equals(Constantes.EVENTO_FIJTIPOS)){
			if (sentido.equals(Constantes.SENTIDO_ENVIAR))
				canalFijTipHabilitado = true;
			else
				canalFijTipRecHabilitado = true;
		}
	}

	
	
	public Boolean getCanalContraHabilitado() {
		return canalContraHabilitado;
	}
	public Boolean getIdiomaContraHabilitado() {
		return idiomaContraHabilitado;
	}
	public Boolean getCanalModifHabilitado() {
		return canalModifHabilitado;
	}
	public Boolean getIdiomaModifHabilitado() {
		return idiomaModifHabilitado;
	}
	public Boolean getCanalCanceHabilitado() {
		return canalCanceHabilitado;
	}
	public Boolean getIdiomaCanceHabilitado() {
		return idiomaCanceHabilitado;
	}
	public Boolean getCanalCanceParHabilitado() {
		return canalCanceParHabilitado;
	}
	public Boolean getIdiomaCanceParHabilitado() {
		return idiomaCanceParHabilitado;
	}
	public Boolean getCanalLiquiHabilitado() {
		return canalLiquiHabilitado;
	}
	public Boolean getIdiomaLiquiHabilitado() {
		return idiomaLiquiHabilitado;
	}
	public Boolean getCanalFijTipHabilitado() {
		return canalFijTipHabilitado;
	}
	public Boolean getIdiomaFijTipHabilitado() {
		return idiomaFijTipHabilitado;
	}
	public Boolean getTipoPlantillaHabilitado() {
		return tipoPlantillaHabilitado;
	}
	public Boolean getCanalContraRecHabilitado() {
		return canalContraRecHabilitado;
	}
	public Boolean getCanalModifRecHabilitado() {
		return canalModifRecHabilitado;
	}
	public Boolean getCanalCanceRecHabilitado() {
		return canalCanceRecHabilitado;
	}
	public Boolean getCanalCanceRecParHabilitado() {
		return canalCanceRecParHabilitado;
	}
	public Boolean getCanalLiquiRecHabilitado() {
		return canalLiquiRecHabilitado;
	}
	public Boolean getCanalFijTipRecHabilitado() {
		return canalFijTipRecHabilitado;
	}
	public void irConfirmacionProductosCompuestos(){		
		limpiarIdiomaAndCanal();
		habilitarTodosCombos();
		habilitarTipoPlantilla();

//		En caso de no encontrar Indiconf se llama a buildListaIdiomaPlantilla 
		
//		if (!"ALTAPROD".equals(pantalla)){
			cargarIndiConfirmacion();
//		}else{
//			buildListaIdiomaPlantilla();
//		}
		
	}

	public void habilitarTodosCombos(){
		canalContraHabilitado = true;
		canalContraRecHabilitado = true;
		idiomaContraHabilitado = true;
		canalModifHabilitado = true;
		canalModifRecHabilitado = true;
		idiomaModifHabilitado = true;		
		canalCanceHabilitado = true;
		canalCanceRecHabilitado = true;
		idiomaCanceHabilitado = true;
		canalCanceParHabilitado = true;
		canalCanceRecParHabilitado = true;
		idiomaCanceParHabilitado = true;		
		canalLiquiRecHabilitado = true;
		idiomaLiquiHabilitado = true;
		canalFijTipRecHabilitado = true;
		idiomaFijTipHabilitado = true;		

	}
	public void habilitarTipoPlantilla(){
		
		/*
		FLO: placonfi se enlaza con producto por el campo producat.
		Se tiene que buscar todos los placonfi con el mismo producat que este producto
		Tras hablar con Mercado no es producat es prodcomp
		 */
		if (!GenericUtils.isNullOrBlank(boletaProdCompuestosPantalla.getVartipo())){
			if ( boletaProdCompuestosPantalla.getVartipo().equals("L")){
				tipoPlantillaHabilitado = true;
				return;
			}else if (boletaProdCompuestosPantalla.getVartipo().equals("D")){
				String prodcom = boletaProdCompuestosPantalla.getHistoricoProductoCompuesto().getCatalogoProdCompuesto().getId()+"";
				List<PlantillasConfirmacion> plantillaList = boletaProdCompuestoBo.obtenerPlantillasConfirmacion(prodcom, null, null);
				if (plantillaList.isEmpty()){
					tipoPlantillaHabilitado = true;
					return;
				}
			}			
		}
			
		tipoPlantillaHabilitado = false;
	}
	
	public String obtenerCodCanal(CanalConfirmacion canal){
		
		String codCanal = null;
		if (!GenericUtils.isNullOrBlank(canal)){
			codCanal = canal.getId().getCodcanal();
		}
		return codCanal;
	}

	public CanalConfirmacion obtenerCanal(List<CanalConfirmacion> canalList, String codCanal){
		if (codCanal==null || canalList==null ) return null;
		for (CanalConfirmacion element : canalList) {
			if (element.getId().getCodcanal().equals(codCanal)){
				return (CanalConfirmacion) element;
			}
		}
		return null;
	}
	
	/**
	 * Guarda el indicador de Confirmación
	 * @return
	 */
	public String guardarIndiConfirmacion(){
		
		OperacionId operacionId = new OperacionId(boletaProdCompuestosPantalla.getHistoricoProductoCompuesto().getFechaContratacion(),
				boletaProdCompuestosPantalla.getHistoricoProductoCompuesto().getId().getEstructu());
		
		IndicadorConfirmacion indicadorConfirmacion = 	boletaProdCompuestoBo.cargarIndicadorConfirmacion(operacionId);
		
		if (indicadorConfirmacion == null){
			indicadorConfirmacion = new IndicadorConfirmacion();
			indicadorConfirmacion.setId(operacionId);
		}
		
		
		//Contratracion
		indicadorConfirmacion.setIndicadorConfirmacionAlta(boletaProdCompuestosPantalla.getContraEnviar());
		indicadorConfirmacion.setIdiomaConfirmacionAlta(boletaProdCompuestosPantalla.getIdiomaContraSelect());
		indicadorConfirmacion.setCanelEmisionConfirmacionAlta(obtenerCodCanal(boletaProdCompuestosPantalla.getCanalContraESelect()));
		indicadorConfirmacion.setIndicadorRecepcionConfirmacionAlta(boletaProdCompuestosPantalla.getContraRecibir());
		indicadorConfirmacion.setCanelRecepcionConfirmacionAlta(obtenerCodCanal(boletaProdCompuestosPantalla.getCanalContraRSelect()));	

		//Modificacion
		indicadorConfirmacion.setIndicadorConfirmacionModificacion(boletaProdCompuestosPantalla.getModifEnviar());
		indicadorConfirmacion.setIdiomaConfirmacionModificacion(boletaProdCompuestosPantalla.getIdiomaModifSelect());
		indicadorConfirmacion.setCanelEmisionConfirmacionModificacion(obtenerCodCanal(boletaProdCompuestosPantalla.getCanalModifESelect()));
		indicadorConfirmacion.setIndicadorRecepcionConfirmacionModificacion(boletaProdCompuestosPantalla.getModifRecibir());
		indicadorConfirmacion.setCanelRecepcionConfirmacionModificacion(obtenerCodCanal(boletaProdCompuestosPantalla.getCanalModifRSelect()));	
		
		//Cancelacion
		indicadorConfirmacion.setIndicadorConfirmacionCancelacion(boletaProdCompuestosPantalla.getCanceEnviar());
		indicadorConfirmacion.setIdiomaConfirmacionCancelacion(boletaProdCompuestosPantalla.getIdiomaCanceSelect());
		indicadorConfirmacion.setCanelEmisionConfirmacionCancelacion(obtenerCodCanal(boletaProdCompuestosPantalla.getCanalCanceESelect()));
		indicadorConfirmacion.setIndicadorRecepcionConfirmacionCancelacion(boletaProdCompuestosPantalla.getCanceRecibir());
		indicadorConfirmacion.setCanelRecepcionConfirmacionCancelacion(obtenerCodCanal(boletaProdCompuestosPantalla.getCanalCanceRSelect()));	

		//Cancelación Parcial
		indicadorConfirmacion.setIndicadorConfirmacionCancelacionParcial(boletaProdCompuestosPantalla.getCanceParEnviar());
		indicadorConfirmacion.setIdiomaConfirmacionCancelacionParcial(boletaProdCompuestosPantalla.getIdiomaCanceParSelect());
		indicadorConfirmacion.setCanelEmisionConfirmacionCancelacionParcial(obtenerCodCanal(boletaProdCompuestosPantalla.getCanalCanceParESelect()));
		indicadorConfirmacion.setIndicadorRecepcionConfirmacionCancelacionParcial(boletaProdCompuestosPantalla.getCanceParRecibir());
		indicadorConfirmacion.setCanelRecepcionConfirmacionCancelacionParcial(obtenerCodCanal(boletaProdCompuestosPantalla.getCanalCanceParRSelect()));	

		//Liquidación
		indicadorConfirmacion.setIndicadorConfirmacionLiquidacion(boletaProdCompuestosPantalla.getLiquiEnviar());
		indicadorConfirmacion.setIdiomaConfirmacionLiquidacion(boletaProdCompuestosPantalla.getIdiomaLiquiSelect());
		indicadorConfirmacion.setCanelEmisionConfirmacionLiquidacion(obtenerCodCanal(boletaProdCompuestosPantalla.getCanalLiquiESelect()));
		indicadorConfirmacion.setIndicadorRecepcionConfirmacionLiquidacion(boletaProdCompuestosPantalla.getLiquiRecibir());
		indicadorConfirmacion.setCanelRecepcionConfirmacionLiquidacion(obtenerCodCanal(boletaProdCompuestosPantalla.getCanalLiquiRSelect()));	

		//Fijación Tipos
		indicadorConfirmacion.setIndicadorConfirmacionFijacion(boletaProdCompuestosPantalla.getFijTipEnviar());
		indicadorConfirmacion.setIdiomaConfirmacionFijacion(boletaProdCompuestosPantalla.getIdiomaFijTipSelect());
		indicadorConfirmacion.setCanelEmisionConfirmacionFijacion(obtenerCodCanal(boletaProdCompuestosPantalla.getCanalFijTipESelect()));
		indicadorConfirmacion.setIndicadorRecepcionConfirmacionFijacion(boletaProdCompuestosPantalla.getFijTipRecibir());
		indicadorConfirmacion.setCanelRecepcionConfirmacionFijacion(obtenerCodCanal(boletaProdCompuestosPantalla.getCanalFijTipRSelect()));
		
		//SMM  - MERCADO: en NCORRELA meter el valor de ESTRUCTURA

		indicadorConfirmacion.setCodigoEstructura(boletaProdCompuestosPantalla.getHistoricoProductoCompuesto().getId().getEstructu());
		DescripcionTipoPlantilla tipoPlantilla = boletaProdCompuestosPantalla.getTipoPlantillaSelect();
		indicadorConfirmacion.setTipoPlan(tipoPlantilla==null?null:tipoPlantilla.getCodigoca());
		
		AuditData audit = new AuditData();
		audit.setFechaUltimaModi(new Date());
		audit.setUsuarioUltimaModi(credentials.getUsername());
		
		indicadorConfirmacion.setAuditData(audit);
		
		boletaProdCompuestoBo.confirmarProdCompuesto(indicadorConfirmacion,
				boletaProdCompuestosPantalla.getContraEnviar(),
				boletaProdCompuestosPantalla.getContraRecibir(),
				boletaProdCompuestosPantalla.getModifEnviar(),
				boletaProdCompuestosPantalla.getModifRecibir(),
				boletaProdCompuestosPantalla.getCanceEnviar(),
				boletaProdCompuestosPantalla.getCanceRecibir(),
				boletaProdCompuestosPantalla.getCanceParEnviar(),
				boletaProdCompuestosPantalla.getCanceParRecibir(),
				boletaProdCompuestosPantalla.getLiquiEnviar(),
				boletaProdCompuestosPantalla.getLiquiRecibir(),
				boletaProdCompuestosPantalla.getFijTipEnviar(),
				boletaProdCompuestosPantalla.getFijTipRecibir(),
				credentials.getUsername());
		
		Conversation.instance().redirectToParent();
		return Constantes.SUCCESS;
	}
	
	
	public Idioma setIdiomaSelect(List<Idioma> idiomaList, Idioma idioma){
		
		if (idioma==null || idiomaList==null ) return null;
		
		for (Idioma element : idiomaList) {
			if (element.getCodigo().equals(idioma.getCodigo())){
				return element;
			}
		}
		return null;
	}
	
	/**
	 * Guarda el indicador de Confirmación
	 * @return
	 */
	public void cargarIndiConfirmacion(){
		
		OperacionId operacionId = new OperacionId(boletaProdCompuestosPantalla.getHistoricoProductoCompuesto().getFechaContratacion(),
				boletaProdCompuestosPantalla.getHistoricoProductoCompuesto().getId().getEstructu());
		
		IndicadorConfirmacion indicadorConfirmacion = 	boletaProdCompuestoBo.cargarIndicadorConfirmacion(operacionId);
		
		if (indicadorConfirmacion!=null) {
			
			
			
			List<DescripcionTipoPlantilla> plantillaList = new ArrayList<DescripcionTipoPlantilla>();
			plantillaList = boletaProdCompuestoBo.obtenerTipoPlantilla();
			for (DescripcionTipoPlantilla tipo : plantillaList) {
				if (tipo.getCodigoca().equals(indicadorConfirmacion.getTipoPlan())){
					boletaProdCompuestosPantalla.setTipoPlantillaSelect(tipo);
					continue;
				}
			}
		
			buildListaIdiomaPlantilla();
			
		//Contratracion
		boletaProdCompuestosPantalla.setContraEnviar(indicadorConfirmacion.getIndicadorConfirmacionAlta());
		boletaProdCompuestosPantalla.setIdiomaContraSelect(setIdiomaSelect(boletaProdCompuestosPantalla.getIdiomaContraList(),indicadorConfirmacion.getIdiomaConfirmacionAlta()));
//		boletaProdCompuestosPantalla.setIdiomaContraSelect(indicadorConfirmacion.getIdiomaConfirmacionAlta());
		boletaProdCompuestosPantalla.setCanalContraESelect(obtenerCanal(boletaProdCompuestosPantalla.getCanalContraEList(),indicadorConfirmacion.getCanelEmisionConfirmacionAlta()));
		boletaProdCompuestosPantalla.setContraRecibir(indicadorConfirmacion.getIndicadorRecepcionConfirmacionAlta());
		boletaProdCompuestosPantalla.setCanalContraRSelect(obtenerCanal(boletaProdCompuestosPantalla.getCanalContraRList(),indicadorConfirmacion.getCanelRecepcionConfirmacionAlta()));	

		//Modificacion
		boletaProdCompuestosPantalla.setModifEnviar(indicadorConfirmacion.getIndicadorConfirmacionModificacion());
		boletaProdCompuestosPantalla.setIdiomaModifSelect(setIdiomaSelect(boletaProdCompuestosPantalla.getIdiomaModifList(),indicadorConfirmacion.getIdiomaConfirmacionModificacion()));
//		boletaProdCompuestosPantalla.setIdiomaModifSelect(indicadorConfirmacion.getIdiomaConfirmacionModificacion());
		boletaProdCompuestosPantalla.setCanalModifESelect(obtenerCanal(boletaProdCompuestosPantalla.getCanalModifEList() ,indicadorConfirmacion.getCanelEmisionConfirmacionModificacion()));
		boletaProdCompuestosPantalla.setModifRecibir(indicadorConfirmacion.getIndicadorRecepcionConfirmacionModificacion());
		boletaProdCompuestosPantalla.setCanalModifRSelect(obtenerCanal(boletaProdCompuestosPantalla.getCanalModifRList(),indicadorConfirmacion.getCanelRecepcionConfirmacionModificacion()));	
		
		//Cancelacion
		boletaProdCompuestosPantalla.setCanceEnviar(indicadorConfirmacion.getIndicadorConfirmacionCancelacion());
		boletaProdCompuestosPantalla.setIdiomaCanceSelect(setIdiomaSelect(boletaProdCompuestosPantalla.getIdiomaCanceList(),indicadorConfirmacion.getIdiomaConfirmacionCancelacion()));
//		boletaProdCompuestosPantalla.setIdiomaCanceSelect(indicadorConfirmacion.getIdiomaConfirmacionCancelacion());
		boletaProdCompuestosPantalla.setCanalCanceESelect(obtenerCanal(boletaProdCompuestosPantalla.getCanalCanceEList(),indicadorConfirmacion.getCanelEmisionConfirmacionCancelacion()));
		boletaProdCompuestosPantalla.setCanceRecibir(indicadorConfirmacion.getIndicadorRecepcionConfirmacionCancelacion());
		boletaProdCompuestosPantalla.setCanalCanceRSelect(obtenerCanal(boletaProdCompuestosPantalla.getCanalCanceRList(),indicadorConfirmacion.getCanelRecepcionConfirmacionCancelacion()));	

		//Cancelación Parcial
		boletaProdCompuestosPantalla.setCanceParEnviar(indicadorConfirmacion.getIndicadorConfirmacionCancelacionParcial());
		boletaProdCompuestosPantalla.setIdiomaCanceParSelect(setIdiomaSelect(boletaProdCompuestosPantalla.getIdiomaCanceParList(),indicadorConfirmacion.getIdiomaConfirmacionCancelacionParcial()));
//		boletaProdCompuestosPantalla.setIdiomaCanceParSelect(indicadorConfirmacion.getIdiomaConfirmacionCancelacionParcial());
		boletaProdCompuestosPantalla.setCanalCanceParESelect(obtenerCanal(boletaProdCompuestosPantalla.getCanalCanceParEList(),indicadorConfirmacion.getCanelEmisionConfirmacionCancelacionParcial()));
		boletaProdCompuestosPantalla.setCanceParRecibir(indicadorConfirmacion.getIndicadorRecepcionConfirmacionCancelacionParcial());
		boletaProdCompuestosPantalla.setCanalCanceParRSelect(obtenerCanal(boletaProdCompuestosPantalla.getCanalCanceParRList(),indicadorConfirmacion.getCanelRecepcionConfirmacionCancelacionParcial()));	

		//Liquidación
		boletaProdCompuestosPantalla.setLiquiEnviar(indicadorConfirmacion.getIndicadorConfirmacionLiquidacion());
		boletaProdCompuestosPantalla.setIdiomaLiquiSelect(setIdiomaSelect(boletaProdCompuestosPantalla.getIdiomaLiquiList(),indicadorConfirmacion.getIdiomaConfirmacionLiquidacion()));
//		boletaProdCompuestosPantalla.setIdiomaLiquiSelect(indicadorConfirmacion.getIdiomaConfirmacionLiquidacion());
		boletaProdCompuestosPantalla.setCanalLiquiESelect(obtenerCanal(boletaProdCompuestosPantalla.getCanalLiquiEList(),indicadorConfirmacion.getCanelEmisionConfirmacionLiquidacion()));
		boletaProdCompuestosPantalla.setLiquiRecibir(indicadorConfirmacion.getIndicadorRecepcionConfirmacionLiquidacion());
		boletaProdCompuestosPantalla.setCanalLiquiRSelect(obtenerCanal(boletaProdCompuestosPantalla.getCanalLiquiRList(),indicadorConfirmacion.getCanelRecepcionConfirmacionLiquidacion()));	

		//Fijación Tipos
		boletaProdCompuestosPantalla.setFijTipEnviar(indicadorConfirmacion.getIndicadorConfirmacionFijacion());
		boletaProdCompuestosPantalla.setIdiomaFijTipSelect(setIdiomaSelect(boletaProdCompuestosPantalla.getIdiomaFijTipList(),indicadorConfirmacion.getIdiomaConfirmacionFijacion()));
//		boletaProdCompuestosPantalla.setIdiomaFijTipSelect(indicadorConfirmacion.getIdiomaConfirmacionFijacion());
		boletaProdCompuestosPantalla.setCanalFijTipESelect(obtenerCanal(boletaProdCompuestosPantalla.getCanalFijTipEList(),indicadorConfirmacion.getCanelEmisionConfirmacionFijacion()));
		boletaProdCompuestosPantalla.setFijTipRecibir(indicadorConfirmacion.getIndicadorRecepcionConfirmacionFijacion());
		boletaProdCompuestosPantalla.setCanalFijTipRSelect(obtenerCanal(boletaProdCompuestosPantalla.getCanalFijTipRList(),indicadorConfirmacion.getCanelRecepcionConfirmacionFijacion()));
		
	

			
		
		
		}else{
			buildListaIdiomaPlantilla();
		}

	}
	
	/**	Si producto Definido, valida que las operaciones indicadas esten completas (todas las filas con 
	 * Prod. Cat informado deben tener num.Oper informado sino Estructura Incompleta.
	 * Graba la información en deri.oprodcom. El estado será IN (incompleta) o PV (Pendiente Validar).
	 * Graba el evento correspondiente en deri.agendotc.
	 * Desbloquea estructura y finaliza la operación volviendo al menú. Si hay error se queda en la
	 * pantalla y muestra el mensaje de error.
	 */
	public String aceptarOperProdCompuesto(){
		
		ModoPantalla modo;
		
		if (!GenericUtils.isNullOrBlank(alta) && alta){
			modo = ModoPantalla.CREACION;
		} else {
			modo = this.modoPantalla;
		}

//SUP 14.07.2015 		
// PDTE	
//		for (OperacionesProdCompuestos oper : listaOperacionesProdCompuestos) {
//			if ("R".equalsIgnoreCase(oper.getVistaOperacion().getHistOper().getProducto().getIndPasarelaRad())){
//				boletaProdCompuestosPantalla.getHistoricoProductoCompuesto().setIndNeteoLiquidaciones("N");
//				break;
//			}
//		}
//		
		
		RetornoFuncion retorno = null;
		if (!consulta){
			retorno = boletaProdCompuestoBo.aceptarOperProdCompuesto(
					boletaProdCompuestosPantalla.getHistoricoProductoCompuesto(),
					listaOperacionesProdCompuestos,
					boletaProdCompuestosPantalla.getVartipo(),
					modo,credentials.getUsername(),pantalla);
		}
		// Desbloquear estructura y volver al menú
		dbLockService.desbloqueo(HistoricoProductoCompuesto.class,
				boletaProdCompuestosPantalla.getHistoricoProductoCompuesto().getId());
		
		if (!GenericUtils.isNullOrBlank(retorno) && retorno.getHayErrores()){
			statusMessages.add(Severity.ERROR, retorno.getDescError());
			return Constantes.FAIL;
		} 

		// //matamos conversación anidada porque volvemos al home
		// menuBean.clickAndKillLastConversation("/home.xhtml");
		// return Constantes.CONSTANTE_SUCCESS;
		consulta = false;
		final Conversation conversacion = Conversation.instance();
		// Volvemos a la anterior conversación
		if (conversacion.isNested() && !"ALTAPROD".equalsIgnoreCase(pantalla)){
			conversacion.redirectToParent();
		} else {
			menuBean.clickAndKillLastConversation("/home.xhtml");
//			redirectToURL("/home.seam");
//			conversacion.endAndRedirect();
		}

		return Constantes.SUCCESS;
	}	
	
	/********************************************************/
	/** Pantalla Confirmaciones Productos Compuestos - FIN **/
	/********************************************************/
	
	public MantProdCompuestoBo getMantProdCompuestoBo() {
		return mantProdCompuestoBo;
	}

	public void setMantProdCompuestoBo(MantProdCompuestoBo mantProdCompuestoBo) {
		this.mantProdCompuestoBo = mantProdCompuestoBo;
	}

	public ContrapartidaBo getContrapartidaBo() {
		return contrapartidaBo;
	}

	public void setContrapartidaBo(ContrapartidaBo contrapartidaBo) {
		this.contrapartidaBo = contrapartidaBo;
	}

	public BoletaProdCompuestosPantalla getBoletaProdCompuestosPantalla() {
		return boletaProdCompuestosPantalla;
	}

	public void setBoletaProdCompuestosPantalla(
			BoletaProdCompuestosPantalla boletaProdCompuestosPantalla) {
		this.boletaProdCompuestosPantalla = boletaProdCompuestosPantalla;
	}

	public BoletaProdCompuestoBo getBoletaProdCompuestoBo() {
		return boletaProdCompuestoBo;
	}

	public void setBoletaProdCompuestoBo(BoletaProdCompuestoBo boletaProdCompuestoBo) {
		this.boletaProdCompuestoBo = boletaProdCompuestoBo;
	}

	public DbLockService getDbLockService() {
		return dbLockService;
	}

	public void setDbLockService(DbLockService dbLockService) {
		this.dbLockService = dbLockService;
	}
	
	public String getMsgBoxWidth() {
		return msgBoxWidth;
	}
	public void setMsgBoxWidth(String msgBoxWidth) {
		this.msgBoxWidth = msgBoxWidth;
	}
	
	@Override
	public List<?> getDataTableList() {	
		return listaOperacionesProdCompuestos;
	}

	@SuppressWarnings("unchecked")
	@Override
	protected void refreshListInternal() {		
		setExportExcel(false);
		List<OperacionesProdCompuestos> q1 = Collections.EMPTY_LIST; 
		if("MANTPROD".equals(pantalla) && (alta != null && !alta) ){
			//si viene de la pantalla de mantenimiento de productos compuestos y no es modo ALTA 
			q1 = (List<OperacionesProdCompuestos>)boletaProdCompuestoBo.obtenerListaOperacionesProdCompMod(estructuraId.toString(), getPaginationData()) ;
		}else{
			//si viene de la pantalla de alta boletas de productos compuestos cargamos esta query
		    if ("D".equals(boletaProdCompuestosPantalla.getVartipo())){             
				q1 = 
				(List<OperacionesProdCompuestos>)boletaProdCompuestoBo.obtenerListaOperacionesProdComp(boletaProdCompuestosPantalla.getHistoricoProductoCompuesto(), getPaginationData()) ;
		    }
		    if ("L".equals(boletaProdCompuestosPantalla.getVartipo())){             
				q1 = 
				(List<OperacionesProdCompuestos>)boletaProdCompuestoBo.obtenerListaOperacionesProdCompTipoL(boletaProdCompuestosPantalla.getHistoricoProductoCompuesto(), getPaginationData()) ;
		    }
		}
		this.setListaOperacionesProdCompuestos(q1);
	}

	@Override
	public void refrescarListaExcel() {
		setExportExcel(true);
		List<OperacionesProdCompuestos> q1 = null; 
		if("MANTPROD".equals(pantalla)){
			//si viene de la pantalla de mantenimiento de productos compuestos cargamos esta query
			q1 = 
				(List<OperacionesProdCompuestos>)boletaProdCompuestoBo.obtenerListaOperacionesProdCompMod(estructuraId.toString(), getPaginationData().getPaginationDataForExcel()) ;
		}else{
			//si viene de la pantalla de alta boletas de productos compuestos cargamos esta query
			q1 = 
			(List<OperacionesProdCompuestos>)boletaProdCompuestoBo.obtenerListaOperacionesProdComp(boletaProdCompuestosPantalla.getHistoricoProductoCompuesto(), getPaginationData().getPaginationDataForExcel()) ;		
		}
		this.setListaOperacionesProdCompuestos(q1);
	}

	@SuppressWarnings("unchecked")
	@Override
	public void setDataTableList(List<?> dataTableList) {
		this.setListaOperacionesProdCompuestos((List<OperacionesProdCompuestos>)dataTableList);		
	}
	
	public String getPantalla() {
		return pantalla;
	}
	
	public void setPantalla(String pantalla) {
		this.pantalla = pantalla;
	}
	public Long getEstructuraId() {
		return estructuraId;
	}
	public void setEstructuraId(Long estructuraId) {
		this.estructuraId = estructuraId;
	}
	public BoletasBo getBoletasBo() {
		return boletasBo;
	}
	public void setBoletasBo(BoletasBo boletasBo) {
		this.boletasBo = boletasBo;
	}
	public BoletasStates getBoletaState() {
		return boletaState;
	}
	public void setBoletaState(BoletasStates boletaState) {
		this.boletaState = boletaState;
	}
	
	/**********************************************************/
	/**	MENSAJES DE ERROR *************************************/
	/**********************************************************/
	private boolean addWarning(HistoricoOperacion ho, String message) {
		SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
		return listaErrores.add(new ErrorMessage(TypeError.WARNING, ho.getId().getNumeroOperacion().toString(), sdf.format(ho.getId()
				.getFechaContratacion()), message));
	}
	
	private void msgBoxFinalStep(){
		msgBoxFinalStep(false);
	}
	private void msgBoxFinalStep(boolean finalMessage) {
		msgBoxMessageMode = false;
		msgBoxFinalStep = true;
		msgBoxWidth = "700";
		msgBoxAction.setVoidFunction(true);
		if(finalMessage){
			msgBoxFinalStep = false;
			msgBoxAction.noMostrarMensaje();
		}
	}	
	public String getMsgBoxHeaderListaErrores() {
		return msgBoxHeaderListaErrores;
	}
	public String getMsgBoxNoProcessable() {
		return msgBoxNoProcessable;
	}
	public boolean isMsgBoxFinalStep() {
		return msgBoxFinalStep;
	}
	public boolean isMsgBoxMessageMode() {
		return msgBoxMessageMode;
	}
	public void setMsgBoxHeaderListaErrores(String msgBoxHeaderListaErrores) {
		this.msgBoxHeaderListaErrores = msgBoxHeaderListaErrores;
	}
	public void setMsgBoxNoProcessable(String msgBoxNoProcessable) {
		this.msgBoxNoProcessable = msgBoxNoProcessable;
	}
	public void setMsgBoxFinalStep(boolean msgBoxFinalStep) {
		this.msgBoxFinalStep = msgBoxFinalStep;
	}
	public void setMsgBoxMessageMode(boolean msgBoxMessageMode) {
		this.msgBoxMessageMode = msgBoxMessageMode;
	}
	public List<ErrorMessage> getListaErrores() {
		return listaErrores;
	}
	public void setListaErrores(List<ErrorMessage> listaErrores) {
		this.listaErrores = listaErrores;
	}
	private void prepareMsgBox(String accion) {
		if (listaErrores.size() > 0) {
			Collections.sort(listaErrores, new Comparator<ErrorMessage>() {
				public int compare(ErrorMessage o1, ErrorMessage o2) {
					return o1.getTypeError().getSortNumber().compareTo(o2.getTypeError().getSortNumber());
				}
			});
			msgBoxNoProcessable = ResourceBundle.instance().getString("mantOper.messages." + accion + ".noSelection");
			msgBoxHeaderListaErrores = ResourceBundle.instance().getString("mantOper.messages.no." + accion + "");
			if (!msgBoxFinalStep) {
				msgBoxAction.mostrarMsg("#{mantOperacionesAction." + accion + "()}", "#{mantOperacionesAction." + accion + "Desbloquear()}", "");
			} else {
				msgBoxAction.mostrarMsg("#{mantOperacionesAction." + accion + "()}", "#{mantOperacionesAction.voidFunction()}", "");
			}

		}
	}

	private boolean addError(HistoricoOperacion ho, String message) {
		if(isWarning(ho)){
			removeMessage(ho);
		}
		SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
		return listaErrores.add(new ErrorMessage(TypeError.ERROR, ho.getId().getNumeroOperacion().toString(), sdf.format(ho.getId()
				.getFechaContratacion()), message, ho));
	}
	private boolean isWarning(HistoricoOperacion ho){
		for (ErrorMessage em : listaErrores) {
			if(em.getTypeError().equals(TypeError.WARNING)){
				if (em.getHo().equals(ho)) {
					return true;
				}
			}
		}
		return false;
	}
	
	private boolean removeMessage(HistoricoOperacion ho){
		for (ErrorMessage em : listaErrores) {
			if(em.getHo().equals(ho)){
				return listaErrores.remove(em);
			}
		}
		return false;
	}


	public List<OperacionesProdCompuestos> getListaOperacionesProdCompuestos() {
		return listaOperacionesProdCompuestos;
	}


	public void setListaOperacionesProdCompuestos(
			List<OperacionesProdCompuestos> listaOperacionesProdCompuestos) {
		this.listaOperacionesProdCompuestos = listaOperacionesProdCompuestos;
	}


	public OperacionesProdCompuestos getOperacionesProdCompuestos() {
		return operacionesProdCompuestos;
	}


	public void setOperacionesProdCompuestos(
			OperacionesProdCompuestos operacionesProdCompuestos) {
		this.operacionesProdCompuestos = operacionesProdCompuestos;
	}
	
	public void cambioEstructu(){
		if(boletaProdCompuestosPantalla.isEstructmodelo()){
			boletaProdCompuestosPantalla.getHistoricoProductoCompuesto().getContrapartida().setId("MODELO");
			boletaProdCompuestosPantalla.setContrapaActivo(false);
		}else{
			boletaProdCompuestosPantalla.getHistoricoProductoCompuesto().getContrapartida().setId("");
			boletaProdCompuestosPantalla.setContrapaActivo(true);
		}
	}
	
	public boolean existeContrapa(){
		return (!GenericUtils.isNullOrBlank(contrapartidaBo.cargar(boletaProdCompuestosPantalla.getHistoricoProductoCompuesto().getContrapartida().getId())));
			
	}
	public void cambiocontrapa(){
		if(existeContrapa()){
			if("MODELO".equals(boletaProdCompuestosPantalla.getHistoricoProductoCompuesto().getContrapartida().getId())
					|| "FDI".equals(boletaProdCompuestosPantalla.getHistoricoProductoCompuesto().getContrapartida().getId()) ){
				boletaProdCompuestosPantalla.setConfconjuntaActivo(false);
				boletaProdCompuestosPantalla.setConfconjunta(false);
			}else{
				boletaProdCompuestosPantalla.setConfconjuntaActivo(true);
			}
		}else{
			statusMessages.addToControl("contrapartida", Severity.ERROR,"#{messages['boletaprodcompuestos.error.contrapartida']}" );
		}
	}
	
	public void cancelar() {
		historicoOperacion = operacionesProdCompuestos.getVistaOperacion().getHistOper();
		cancelacionPantalla.reset();
		Date fechamis = cancelacionBo.obtenerFechamis();
		Date fechaValor = historicoOperacion.getFechaValor();
		cancelacionPantalla.setFechacan(fechamis);
		if (fechaValor != null && fechaValor.after(fechamis)) {
			cancelacionPantalla.setFecvalcan(fechaValor);
		} else {
			cancelacionPantalla.setFecvalcan(fechamis);
		}
	}
	
	public String cancelarParcial() {
		listaErrores.clear();
		historicoOperacion = operacionesProdCompuestos.getVistaOperacion().getHistOper();
		if(dbLockService.bloqueo(HistoricoOperacion.class, historicoOperacion.getId())) {
			cancelacionPantalla.reset();
			Date fechamis = cancelacionBo.obtenerFechamis();
			cancelacionPantalla.setFechacan(fechamis);
			
			if (historicoOperacion.getImporteMargenCancelacion()!=null){
				cancelacionPantalla.setImpcanof(historicoOperacion.getImporteMargenCancelacion());	
			}
			if (historicoOperacion.getDivisaMargenOficina()!=null){
				cancelacionPantalla.setDivicoof(historicoOperacion.getDivisaMargenOficina().getId());
			}
			
			CancelacionParcial cp = mantOperBo.cargarUltimaCancelacion(historicoOperacion.getId().getNumeroOperacion(),historicoOperacion.getId().getFechaContratacion());
			if (cp !=null){
				cancelacionPantalla.setFecvalcan(cp.getFechaCancelacion());
				cancelacionPantalla.setFechaliq(cp.getFechaLiquidacionPrima());
				cancelacionPantalla.setTiprican(cp.getTipoPrima());
				if(cp.getImportePrima()!=null){
					cancelacionPantalla.setImprican(cp.getImportePrima());	
				}
				cancelacionPantalla.setDiprican(cp.getDivisa());
				cancelacionPantalla.setTipocanc(cp.getTipoCancelacion());
			
				cancelacionPantalla.setSentamor(cp.getPataAmortizada());
				String chkccirs = cancelacionBo.obtenerChkccirs(historicoOperacion.getProductoCatalogo().getProducat());
				
				if ("S".equalsIgnoreCase(chkccirs) &&  "P".equalsIgnoreCase(cp.getTipoCancelacion())){
	
					cancelacionPantalla.setNominaltp(cp.getNominalPago());  	  	  	
					cancelacionPantalla.setNominalt(cp.getNominalRecibo());
					cancelacionPantalla.setAmortizap(cp.getImporteAmortizarPago());  	
					cancelacionPantalla.setAmortiza(cp.getImporteAmortizarRecibo());
		  
				}else{
					
						if (cp.getPataAmortizada()==null || "A".equalsIgnoreCase(cp.getPataAmortizada())){  
							cancelacionPantalla.setNominalt(cp.getNominalRecibo());
							cancelacionPantalla.setAmortiza(cp.getImporteAmortizarRecibo());
						}else if ("P".equalsIgnoreCase(cp.getPataAmortizada())){ 
							cancelacionPantalla.setNominalt(cp.getNominalPago());
							cancelacionPantalla.setAmortiza(cp.getImporteAmortizarPago());
						}else{
							cancelacionPantalla.setNominalt(cp.getNominalRecibo());
							cancelacionPantalla.setAmortiza(cp.getImporteAmortizarRecibo());
						}
				}
			}

			cancelacionPantalla.setObservac(historicoOperacion.getObservacionesCancelacion());
			cancelacionPantalla.setNomitota(BigDecimal.ZERO); 
			
			return Constantes.SUCCESS;
		} else {
			addError(historicoOperacion, ResourceBundle.instance().getString("mantoper.cancelacion.error.bloqueada"));
			msgBoxFinalStep();
			prepareMsgBox("cancelar");
			return Constantes.FAIL;
		}			
		
	}
	
	public String obtenerDescripcionProducto(String codigo){
		return mantOperBo.obtenerDescripcionProducto(codigo);
	}
	
	
	public Boolean getAlta() {
		return alta;
	}


	public void setAlta(Boolean alta) {
		this.alta = alta;
	}


	public Boolean getConsulta() {
		return consulta;
	}


	public void setConsulta(Boolean consulta) {
		this.consulta = consulta;
	}

	public void initAlta(){
		if(null==messageBoxAltaProdCompuestoAction){
			messageBoxAltaProdCompuestoAction = new MessageBoxAction();
		}
	}

	public void voidFunction(){
		msgBoxAction.voidFunction();
	}

	/**
	 * Mostrar PopUp cuando una contrapartida está bloqueada (no bloqueante)
	 */
	public void onVerificarContrapartidaBloqueada() {
		String contrapartida = boletaProdCompuestosPantalla.getHistoricoProductoCompuesto().getContrapartida().getId();
		if (!GenericUtils.isNullOrBlank(contrapartida)){
			 Contrapartida contrapObtenida2 = mantProdCompuestoBo.cargarContrapartida(contrapartida.toUpperCase());	
			if (!GenericUtils.isNullOrBlank(contrapObtenida2) && !GenericUtils.isNullOrBlank(contrapObtenida2.getIndBloqueo()) && "S".equalsIgnoreCase(contrapObtenida2.getIndBloqueo())){
				messageBoxAltaProdCompuestoAction.init(ResourceBundle.instance().getString("boletaprodcompuestos.messages.contrapartida.bloqueada.texto"), "boletaProdCompuestosAction.voidFunction()", null,"messageBoxPanelContrapa");
			}
		}
		
		cambiocontrapa();
	}

	private Boolean primeraEjecucionInit=null;

	public void cargarInitLista(){
		if (primeraEjecucionInit == null) {
			primeraEjecucionInit=true;
		} 
		else{
			primeraEjecucionInit = false;
		}
		
		if(null==messageBoxAltaProdCompuestoAction) messageBoxAltaProdCompuestoAction = new MessageBoxAction();
		
		if(primeraEjecucionInit){
			String contrapartida = boletaProdCompuestosPantalla.getHistoricoProductoCompuesto().getContrapartida().getId();
			if (!GenericUtils.isNullOrBlank(contrapartida)){
				 Contrapartida contrapObtenida2 = mantProdCompuestoBo.cargarContrapartida(contrapartida.toUpperCase());	
				if (!GenericUtils.isNullOrBlank(contrapObtenida2) && !GenericUtils.isNullOrBlank(contrapObtenida2.getIndBloqueo()) && "S".equalsIgnoreCase(contrapObtenida2.getIndBloqueo())){
					messageBoxAltaProdCompuestoAction.init(ResourceBundle.instance().getString("boletaprodcompuestos.messages.contrapartida.bloqueada.texto"), "boletaProdCompuestosAction.voidFunction()", null,"messageBoxPanelContrapa");
				}
			}
		}
	}



	
	

}
