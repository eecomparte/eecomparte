package com.atosorigin.deri.adminoper.boletas.prodCompuestos.screen;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.jboss.seam.ScopeType;
import org.jboss.seam.annotations.In;
import org.jboss.seam.annotations.Name;
import org.jboss.seam.annotations.Out;
import org.jboss.seam.annotations.Scope;
import org.jboss.seam.annotations.datamodel.DataModel;
import org.jboss.seam.annotations.datamodel.DataModelSelection;

import com.atosorigin.deri.model.adminoper.CanalConfirmacion;
import com.atosorigin.deri.model.adminoper.DescripcionTipoPlantilla;
import com.atosorigin.deri.model.adminoper.IndicadorConfirmacion;
import com.atosorigin.deri.model.catalogo.CatalogoProdCompuesto;
import com.atosorigin.deri.model.catalogo.HistoricoProductoCompuesto;
import com.atosorigin.deri.model.catalogo.Producto;
import com.atosorigin.deri.model.common.Idioma;
import com.atosorigin.deri.model.gestionoperaciones.DescripcionTransaccionOperacion;
import com.atosorigin.deri.model.gestionoperaciones.HistoricoOperacion;
import com.atosorigin.deri.model.gestionoperaciones.HistoricoOperacionId;
import com.atosorigin.deri.model.murex.ProcedenciaProducto;


/**
 *  Contiene los datos de pantalla necesarios para el caso de uso mantenimiento de detallePrimas.
 */
@Name("boletaProdCompuestosPantalla")
@Scope(ScopeType.CONVERSATION)
public class BoletaProdCompuestosPantalla {
	
	
	/*private String paramAcion;*/
	
	private String paramSalir;	
		
	/*private boolean modificarActivo;*/
	
	/*private String modif;*/
	
	private boolean contrapaActivo = true;
	
	private boolean confconjuntaActivo = true;
	
	protected boolean filaSelecObligatoria;
	
	protected boolean botonAnadir;
		
	protected List<CatalogoProdCompuesto> listaCatalogoProdCompuestos;
	
	protected List<DescripcionTransaccionOperacion> listaTransacciones;
	
	protected List<Producto> listaProductos;
	
	protected DescripcionTransaccionOperacion descripcionTransaccionOperacionSelect;
	
	protected CatalogoProdCompuesto catalogoProdCompuesto;
	
	protected ProcedenciaProducto procedenciaProductoSelect;
	
	protected String procedencia;
	
	protected int prodcomp;
	
	protected String transaccion;
	
	@In(required=false)
	@Out(value = "historicoProductoCompuesto", required=false)
	protected HistoricoProductoCompuesto historicoProductoCompuesto;
	
	protected String vartipo; 
	
	protected boolean neteoliq;
	
	protected boolean estructmodelo;
	
	protected boolean conoperexistentes;
	
	protected boolean confconjunta;
			
	//Seleccion de Operaciones
	@DataModel(value="listaDtHistOperSeleccionOperaciones")
	protected List<HistoricoOperacion> listaHistOperSeleccionOperaciones;
	
	@DataModelSelection(value="listaDtHistOperSeleccionOperaciones")
	protected HistoricoOperacion histOperSeleccionOperaciones;
	
	
	protected Map<HistoricoOperacionId, Boolean> selectedOperIds = new HashMap<HistoricoOperacionId, Boolean>();
	protected List<HistoricoOperacion> selectedHistOperDataList = new ArrayList<HistoricoOperacion>();
	//FIN seleccion de Operaciones
			
	/********************************************************/
	/** Pantalla Confirmaciones Productos Compuestos - INI **/
	/********************************************************/
	protected DescripcionTipoPlantilla tipoPlantillaSelect;	
	protected IndicadorConfirmacion indicadorConfSelect;
	protected Boolean contraEnviar;
	protected Boolean contraRecibir;
	protected Boolean modifEnviar;
	protected Boolean modifRecibir;
	protected Boolean canceEnviar;
	protected Boolean canceRecibir;
	protected Boolean canceParEnviar;
	protected Boolean canceParRecibir;
	protected Boolean liquiEnviar;
	protected Boolean liquiRecibir;
	protected Boolean fijTipEnviar;
	protected Boolean fijTipRecibir;

	protected Idioma idiomaContraSelect;
	protected Idioma idiomaModifSelect;
	protected Idioma idiomaCanceSelect;
	protected Idioma idiomaCanceParSelect;
	protected Idioma idiomaLiquiSelect;
	protected Idioma idiomaFijTipSelect;
	protected List<Idioma> idiomaContraList;
	protected List<Idioma> idiomaModifList;
	protected List<Idioma> idiomaCanceList;
	protected List<Idioma> idiomaCanceParList;
	protected List<Idioma> idiomaLiquiList;
	protected List<Idioma> idiomaFijTipList;
	
	protected CanalConfirmacion canalContraESelect;
	protected CanalConfirmacion canalModifESelect;
	protected CanalConfirmacion canalCanceESelect;
	protected CanalConfirmacion canalCanceParESelect;
	protected CanalConfirmacion canalLiquiESelect;
	protected CanalConfirmacion canalFijTipESelect;
	protected List<CanalConfirmacion> canalContraEList;
	protected List<CanalConfirmacion> canalModifEList;
	protected List<CanalConfirmacion> canalCanceEList;
	protected List<CanalConfirmacion> canalCanceParEList;
	protected List<CanalConfirmacion> canalLiquiEList;
	protected List<CanalConfirmacion> canalFijTipEList;	

	protected CanalConfirmacion canalContraRSelect;
	protected CanalConfirmacion canalModifRSelect;
	protected CanalConfirmacion canalCanceRSelect;
	protected CanalConfirmacion canalCanceParRSelect;
	protected CanalConfirmacion canalLiquiRSelect;
	protected CanalConfirmacion canalFijTipRSelect;
	protected List<CanalConfirmacion> canalContraRList;
	protected List<CanalConfirmacion> canalModifRList;
	protected List<CanalConfirmacion> canalCanceRList;
	protected List<CanalConfirmacion> canalCanceParRList;
	protected List<CanalConfirmacion> canalLiquiRList;
	protected List<CanalConfirmacion> canalFijTipRList;	
	/********************************************************/
	/** Pantalla Confirmaciones Productos Compuestos - FIN **/
	/********************************************************/
	
	public BoletaProdCompuestosPantalla(){
		
	}

	public String getProcedencia() {
		return procedencia;
	}

	public void setProcedencia(String procedencia) {
		this.procedencia = procedencia;
	}

	public List<CatalogoProdCompuesto> getListaCatalogoProdCompuestos() {
		return listaCatalogoProdCompuestos;
	}

	public void setListaCatalogoProdCompuestos(
			List<CatalogoProdCompuesto> listaCatalogoProdCompuestos) {
		this.listaCatalogoProdCompuestos = listaCatalogoProdCompuestos;
	}
	
	public String getTransaccion() {
		return transaccion;
	}

	public void setTransaccion(String transaccion) {
		this.transaccion = transaccion;
	}

	public List<DescripcionTransaccionOperacion> getListaTransacciones() {
		return listaTransacciones;
	}

	public void setListaTransacciones(
			List<DescripcionTransaccionOperacion> listaTransacciones) {
		this.listaTransacciones = listaTransacciones;
	}

	public int getProdcomp() {
		return prodcomp;
	}

	public void setProdcomp(int prodcomp) {
		this.prodcomp = prodcomp;
	}

	public DescripcionTransaccionOperacion getDescripcionTransaccionOperacionSelect() {
		return descripcionTransaccionOperacionSelect;
	}

	public void setDescripcionTransaccionOperacionSelect(
			DescripcionTransaccionOperacion descripcionTransaccionOperacionSelect) {
		this.descripcionTransaccionOperacionSelect = descripcionTransaccionOperacionSelect;
	}

	public ProcedenciaProducto getProcedenciaProductoSelect() {
		return procedenciaProductoSelect;
	}

	public void setProcedenciaProductoSelect(
			ProcedenciaProducto procedenciaProductoSelect) {
		this.procedenciaProductoSelect = procedenciaProductoSelect;
	}

	public HistoricoProductoCompuesto getHistoricoProductoCompuesto() {
		return historicoProductoCompuesto; 
	}

	public void setHistoricoProductoCompuesto(
			HistoricoProductoCompuesto historicoProductoCompuesto) {
		this.historicoProductoCompuesto = historicoProductoCompuesto;
	}

	public List<Producto> getListaProductos() {
		return listaProductos;
	}

	public void setListaProductos(List<Producto> listaProductos) {
		this.listaProductos = listaProductos;
	}

	public String getVartipo() {
		return vartipo;
	}

	public void setVartipo(String vartipo) {
		this.vartipo = vartipo;
	}

	public boolean isNeteoliq() {
		return neteoliq;
	}

	public void setNeteoliq(boolean neteoliq) {
		this.neteoliq = neteoliq;
	}

	public boolean isEstructmodelo() {
		return estructmodelo;
	}

	public void setEstructmodelo(boolean estructmodelo) {
		this.estructmodelo = estructmodelo;
	}

	public boolean isConoperexistentes() {
		return conoperexistentes;
	}

	public void setConoperexistentes(boolean conoperexistentes) {
		this.conoperexistentes = conoperexistentes;
	}

	public boolean isConfconjunta() {
		return confconjunta;
	}

	public void setConfconjunta(boolean confconjunta) {
		this.confconjunta = confconjunta;
	}

        public boolean isBotonAnadir() {
		return botonAnadir;
	}

	public void setBotonAnadir(boolean botonAnadir) {
		this.botonAnadir = botonAnadir;
	}

	public boolean isFilaSelecObligatoria() {
		return filaSelecObligatoria;
	}

	public void setFilaSelecObligatoria(boolean filaSelecObligatoria) {
		this.filaSelecObligatoria = filaSelecObligatoria;
	}

	public DescripcionTipoPlantilla getTipoPlantillaSelect() {
		return tipoPlantillaSelect;
	}

	public void setTipoPlantillaSelect(DescripcionTipoPlantilla tipoPlantillaSelect) {
		this.tipoPlantillaSelect = tipoPlantillaSelect;
	}

	public IndicadorConfirmacion getIndicadorConfSelect() {
		return indicadorConfSelect;
	}

	public void setIndicadorConfSelect(IndicadorConfirmacion indicadorConfSelect) {
		this.indicadorConfSelect = indicadorConfSelect;
	}

/*
	public boolean isModificarActivo() {
		return modificarActivo;
	}

	public void setModificarActivo(boolean modificarActivo) {
		this.modificarActivo = modificarActivo;
	}

	public String getModif() {
		return modif;
	}

	public void setModif(String modif) {
		this.modif = modif;
	}
*/
	public Idioma getIdiomaContraSelect() {
		return idiomaContraSelect;
	}

	public void setIdiomaContraSelect(Idioma idiomaContraSelect) {
		this.idiomaContraSelect = idiomaContraSelect;
	}

	public List<Idioma> getIdiomaContraList() {
		if (idiomaContraList == null){
			idiomaContraList = new ArrayList<Idioma>();
		}
		return idiomaContraList;
	}

	public void setIdiomaContraList(List<Idioma> idiomaContraList) {
		this.idiomaContraList = idiomaContraList;
	}
	
	//Seleccion de Operaciones
	public List<HistoricoOperacion> getListaHistOperSeleccionOperaciones() {
		return listaHistOperSeleccionOperaciones;
	}

	public void setListaHistOperSeleccionOperaciones(
			List<HistoricoOperacion> listaHistOperSeleccionOperaciones) {
		this.listaHistOperSeleccionOperaciones = listaHistOperSeleccionOperaciones;
	}

	public HistoricoOperacion getHistOperSeleccionOperaciones() {
		return histOperSeleccionOperaciones;
	}

	public void setHistOperSeleccionOperaciones(
			HistoricoOperacion histOperSeleccionOperaciones) {
		this.histOperSeleccionOperaciones = histOperSeleccionOperaciones;
	}

        public Map<HistoricoOperacionId, Boolean> getSelectedOperIds() {
		return selectedOperIds;
	}

	public void setSelectedOperIds(
			Map<HistoricoOperacionId, Boolean> selectedOperIds) {
		this.selectedOperIds = selectedOperIds;
	}

	public List<HistoricoOperacion> getSelectedHistOperDataList() {
		return selectedHistOperDataList;
	}

	public void setSelectedHistOperDataList(
			List<HistoricoOperacion> selectedHistOperDataList) {
		this.selectedHistOperDataList = selectedHistOperDataList;
	}
	//FIN Seleccion de Operaciones	
/*
        public String getParamAcion() {
		return paramAcion;
	}

	public void setParamAcion(String paramAcion) {
		this.paramAcion = paramAcion;
	}
*/
	public String getParamSalir() {
		return paramSalir;
	}

	public void setParamSalir(String paramSalir) {
		this.paramSalir = paramSalir;
	}

	public Idioma getIdiomaModifSelect() {
		return idiomaModifSelect;
	}

	public Idioma getIdiomaCanceSelect() {
		return idiomaCanceSelect;
	}

	public Idioma getIdiomaCanceParSelect() {
		return idiomaCanceParSelect;
	}

	public Idioma getIdiomaLiquiSelect() {
		return idiomaLiquiSelect;
	}

	public Idioma getIdiomaFijTipSelect() {
		return idiomaFijTipSelect;
	}

	public void setIdiomaModifSelect(Idioma idiomaModifSelect) {
		this.idiomaModifSelect = idiomaModifSelect;
	}

	public void setIdiomaCanceSelect(Idioma idiomaCanceSelect) {
		this.idiomaCanceSelect = idiomaCanceSelect;
	}

	public void setIdiomaCanceParSelect(Idioma idiomaCanceParSelect) {
		this.idiomaCanceParSelect = idiomaCanceParSelect;
	}

	public void setIdiomaLiquiSelect(Idioma idiomaLiquiSelect) {
		this.idiomaLiquiSelect = idiomaLiquiSelect;
	}

	public void setIdiomaFijTipSelect(Idioma idiomaFijTipSelect) {
		this.idiomaFijTipSelect = idiomaFijTipSelect;
	}

	public List<Idioma> getIdiomaModifList() {
		if (idiomaModifList == null){
			idiomaModifList = new ArrayList<Idioma>();
		}
		return idiomaModifList;
	}

	public List<Idioma> getIdiomaCanceList() {
		if (idiomaCanceList == null){
			idiomaCanceList = new ArrayList<Idioma>();
		}
		return idiomaCanceList;
	}

	public List<Idioma> getIdiomaCanceParList() {
		if (idiomaCanceParList == null){
			idiomaCanceParList = new ArrayList<Idioma>();
		}
		return idiomaCanceParList;
	}

	public List<Idioma> getIdiomaLiquiList() {
		if (idiomaLiquiList == null){
			idiomaLiquiList = new ArrayList<Idioma>();
		}
		return idiomaLiquiList;
	}

	public List<Idioma> getIdiomaFijTipList() {
		if (idiomaFijTipList == null){
			idiomaFijTipList = new ArrayList<Idioma>();
		}
		return idiomaFijTipList;
	}

	public void setIdiomaModifList(List<Idioma> idiomaModifList) {
		this.idiomaModifList = idiomaModifList;
	}

	public void setIdiomaCanceList(List<Idioma> idiomaCanceList) {
		this.idiomaCanceList = idiomaCanceList;
	}

	public void setIdiomaCanceParList(List<Idioma> idiomaCanceParList) {
		this.idiomaCanceParList = idiomaCanceParList;
	}

	public void setIdiomaLiquiList(List<Idioma> idiomaLiquiList) {
		this.idiomaLiquiList = idiomaLiquiList;
	}

	public void setIdiomaFijTipList(List<Idioma> idiomaFijTipList) {
		this.idiomaFijTipList = idiomaFijTipList;
	}

	public CanalConfirmacion getCanalContraESelect() {
		return canalContraESelect;
	}

	public CanalConfirmacion getCanalModifESelect() {
		return canalModifESelect;
	}

	public CanalConfirmacion getCanalCanceESelect() {
		return canalCanceESelect;
	}

	public CanalConfirmacion getCanalCanceParESelect() {
		return canalCanceParESelect;
	}

	public CanalConfirmacion getCanalLiquiESelect() {
		return canalLiquiESelect;
	}

	public CanalConfirmacion getCanalFijTipESelect() {
		return canalFijTipESelect;
	}

	public List<CanalConfirmacion> getCanalContraEList() {
		if (canalContraEList == null){
			canalContraEList = new ArrayList<CanalConfirmacion>();
		}
		return canalContraEList;
	}

	public List<CanalConfirmacion> getCanalModifEList() {
		if (canalModifEList == null){
			canalModifEList = new ArrayList<CanalConfirmacion>();
		}
		return canalModifEList;
	}

	public List<CanalConfirmacion> getCanalCanceEList() {
		if (canalCanceEList == null){
			canalCanceEList = new ArrayList<CanalConfirmacion>();
		}
		return canalCanceEList;
	}

	public List<CanalConfirmacion> getCanalCanceParEList() {
		if (canalCanceParEList == null){
			canalCanceParEList = new ArrayList<CanalConfirmacion>();
		}
		return canalCanceParEList;
	}

	public List<CanalConfirmacion> getCanalLiquiEList() {
		if (canalLiquiEList == null){
			canalLiquiEList = new ArrayList<CanalConfirmacion>();
		}
		return canalLiquiEList;
	}

	public List<CanalConfirmacion> getCanalFijTipEList() {
		if (canalFijTipEList == null){
			canalFijTipEList = new ArrayList<CanalConfirmacion>();
		}
		return canalFijTipEList;
	}

	public CanalConfirmacion getCanalContraRSelect() {		
		return canalContraRSelect;
	}

	public CanalConfirmacion getCanalModifRSelect() {
		
		return canalModifRSelect;
	}

	public CanalConfirmacion getCanalCanceRSelect() {
		return canalCanceRSelect;
	}

	public CanalConfirmacion getCanalCanceParRSelect() {
		return canalCanceParRSelect;
	}

	public CanalConfirmacion getCanalLiquiRSelect() {
		return canalLiquiRSelect;
	}

	public CanalConfirmacion getCanalFijTipRSelect() {
		return canalFijTipRSelect;
	}

	public List<CanalConfirmacion> getCanalContraRList() {
		if (canalContraRList == null){
			canalContraRList = new ArrayList<CanalConfirmacion>();
		}
		return canalContraRList;
	}

	public List<CanalConfirmacion> getCanalModifRList() {
		if (canalModifRList == null){
			canalModifRList = new ArrayList<CanalConfirmacion>();
		}
		return canalModifRList;
	}

	public List<CanalConfirmacion> getCanalCanceRList() {
		if (canalCanceRList == null){
			canalCanceRList = new ArrayList<CanalConfirmacion>();
		}
		return canalCanceRList;
	}

	public List<CanalConfirmacion> getCanalCanceParRList() {
		if (canalCanceParRList == null){
			canalCanceParRList = new ArrayList<CanalConfirmacion>();
		}
		return canalCanceParRList;
	}

	public List<CanalConfirmacion> getCanalLiquiRList() {
		if (canalLiquiRList == null){
			canalLiquiRList = new ArrayList<CanalConfirmacion>();
		}
		return canalLiquiRList;
	}

	public List<CanalConfirmacion> getCanalFijTipRList() {
		if (canalFijTipRList == null){
			canalFijTipRList = new ArrayList<CanalConfirmacion>();
		}
		return canalFijTipRList;
	}

	public void setCanalContraESelect(CanalConfirmacion canalContraESelect) {
		this.canalContraESelect = canalContraESelect;
	}

	public void setCanalModifESelect(CanalConfirmacion canalModifESelect) {
		this.canalModifESelect = canalModifESelect;
	}

	public void setCanalCanceESelect(CanalConfirmacion canalCanceESelect) {
		this.canalCanceESelect = canalCanceESelect;
	}

	public void setCanalCanceParESelect(CanalConfirmacion canalCanceParESelect) {
		this.canalCanceParESelect = canalCanceParESelect;
	}

	public void setCanalLiquiESelect(CanalConfirmacion canalLiquiESelect) {
		this.canalLiquiESelect = canalLiquiESelect;
	}

	public void setCanalFijTipESelect(CanalConfirmacion canalFijTipESelect) {
		this.canalFijTipESelect = canalFijTipESelect;
	}

	public void setCanalContraEList(List<CanalConfirmacion> canalContraEList) {
		this.canalContraEList = canalContraEList;
	}

	public void setCanalModifEList(List<CanalConfirmacion> canalModifEList) {
		this.canalModifEList = canalModifEList;
	}

	public void setCanalCanceEList(List<CanalConfirmacion> canalCanceEList) {
		this.canalCanceEList = canalCanceEList;
	}

	public void setCanalCanceParEList(List<CanalConfirmacion> canalCanceParEList) {
		this.canalCanceParEList = canalCanceParEList;
	}

	public void setCanalLiquiEList(List<CanalConfirmacion> canalLiquiEList) {
		this.canalLiquiEList = canalLiquiEList;
	}

	public void setCanalFijTipEList(List<CanalConfirmacion> canalFijTipEList) {
		this.canalFijTipEList = canalFijTipEList;
	}

	public void setCanalContraRSelect(CanalConfirmacion canalContraRSelect) {
		this.canalContraRSelect = canalContraRSelect;
	}

	public void setCanalModifRSelect(CanalConfirmacion canalModifRSelect) {
		this.canalModifRSelect = canalModifRSelect;
	}

	public void setCanalCanceRSelect(CanalConfirmacion canalCanceRSelect) {
		this.canalCanceRSelect = canalCanceRSelect;
	}

	public void setCanalCanceParRSelect(CanalConfirmacion canalCanceParRSelect) {
		this.canalCanceParRSelect = canalCanceParRSelect;
	}

	public void setCanalLiquiRSelect(CanalConfirmacion canalLiquiRSelect) {
		this.canalLiquiRSelect = canalLiquiRSelect;
	}

	public void setCanalFijTipRSelect(CanalConfirmacion canalFijTipRSelect) {
		this.canalFijTipRSelect = canalFijTipRSelect;
	}

	public void setCanalContraRList(List<CanalConfirmacion> canalContraRList) {
		this.canalContraRList = canalContraRList;
	}

	public void setCanalModifRList(List<CanalConfirmacion> canalModifRList) {
		this.canalModifRList = canalModifRList;
	}

	public void setCanalCanceRList(List<CanalConfirmacion> canalCanceRList) {
		this.canalCanceRList = canalCanceRList;
	}

	public void setCanalCanceParRList(List<CanalConfirmacion> canalCanceParRList) {
		this.canalCanceParRList = canalCanceParRList;
	}

	public void setCanalLiquiRList(List<CanalConfirmacion> canalLiquiRList) {
		this.canalLiquiRList = canalLiquiRList;
	}

	public void setCanalFijTipRList(List<CanalConfirmacion> canalFijTipRList) {
		this.canalFijTipRList = canalFijTipRList;
	}

	public Boolean getContraEnviar() {
		return contraEnviar;
	}

	public Boolean getContraRecibir() {
		return contraRecibir;
	}

	public Boolean getModifEnviar() {
		return modifEnviar;
	}

	public Boolean getModifRecibir() {
		return modifRecibir;
	}

	public Boolean getCanceEnviar() {
		return canceEnviar;
	}

	public Boolean getCanceRecibir() {
		return canceRecibir;
	}

	public Boolean getCanceParEnviar() {
		return canceParEnviar;
	}

	public Boolean getCanceParRecibir() {
		return canceParRecibir;
	}

	public Boolean getLiquiEnviar() {
		return liquiEnviar;
	}

	public Boolean getLiquiRecibir() {
		return liquiRecibir;
	}

	public Boolean getFijTipEnviar() {
		return fijTipEnviar;
	}

	public Boolean getFijTipRecibir() {
		return fijTipRecibir;
	}

	public void setContraEnviar(Boolean contraEnviar) {
		this.contraEnviar = contraEnviar;
	}

	public void setContraRecibir(Boolean contraRecibir) {
		this.contraRecibir = contraRecibir;
	}

	public void setModifEnviar(Boolean modifEnviar) {
		this.modifEnviar = modifEnviar;
	}

	public void setModifRecibir(Boolean modifRecibir) {
		this.modifRecibir = modifRecibir;
	}

	public void setCanceEnviar(Boolean canceEnviar) {
		this.canceEnviar = canceEnviar;
	}

	public void setCanceRecibir(Boolean canceRecibir) {
		this.canceRecibir = canceRecibir;
	}

	public void setCanceParEnviar(Boolean canceParEnviar) {
		this.canceParEnviar = canceParEnviar;
	}

	public void setCanceParRecibir(Boolean canceParRecibir) {
		this.canceParRecibir = canceParRecibir;
	}

	public void setLiquiEnviar(Boolean liquiEnviar) {
		this.liquiEnviar = liquiEnviar;
	}

	public void setLiquiRecibir(Boolean liquiRecibir) {
		this.liquiRecibir = liquiRecibir;
	}

	public void setFijTipEnviar(Boolean fijTipEnviar) {
		this.fijTipEnviar = fijTipEnviar;
	}

	public void setFijTipRecibir(Boolean fijTipRecibir) {
		this.fijTipRecibir = fijTipRecibir;
	}

	public CatalogoProdCompuesto getCatalogoProdCompuesto() {
		return catalogoProdCompuesto;
	}

	public void setCatalogoProdCompuesto(CatalogoProdCompuesto catalogoProdCompuesto) {
		this.catalogoProdCompuesto = catalogoProdCompuesto;
	}

	public boolean isContrapaActivo() {
		return contrapaActivo;
	}

	public void setContrapaActivo(boolean contrapaActivo) {
		this.contrapaActivo = contrapaActivo;
	}

	public boolean isConfconjuntaActivo() {
		return confconjuntaActivo;
	}

	public void setConfconjuntaActivo(boolean confconjuntaActivo) {
		this.confconjuntaActivo = confconjuntaActivo;
	}
}
