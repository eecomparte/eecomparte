package com.atosorigin.deri.adminoper.boletas.screen;

import java.util.Date;
import java.util.List;

import org.jboss.seam.ScopeType;
import org.jboss.seam.annotations.Name;
import org.jboss.seam.annotations.Scope;

import com.atosorigin.deri.model.murex.ProcedenciaProducto;

/**
 * Contiene los datos de pantalla necesarios para el caso de uso "consulta operaciones asociadas" 
 * del mantenimiento de datos de mercado.
 */
@Name("boletasAltaPantalla")
@Scope(ScopeType.CONVERSATION)
public class BoletasAltaPantalla implements java.io.Serializable{

	protected ProcedenciaProducto procedencia;
	protected String modelo;
	protected String producto;
	protected Long num;
	protected Date fContr;
	protected boolean modeloChk;
	protected List<String> productosLista;
	
	public ProcedenciaProducto getProcedencia() {
		return procedencia;
	}
	public void setProcedencia(String ProcedenciaProducto) {
		this.procedencia = procedencia;
	}
	public String getModelo() {
		return modelo;
	}
	public void setModelo(String modelo) {
		this.modelo = modelo;
	}
	public String getProducto() {
		return producto;
	}
	public void setProducto(String producto) {
		this.producto = producto;
	}
	
	public Long getNum() {
		return num;
	}
	public void setNum(Long num) {
		this.num = num;
	}
	public Date getfContr() {
		return fContr;
	}
	public void setfContr(Date fContr) {
		this.fContr = fContr;
	}
	
	public boolean isModeloChk() {
		return modeloChk;
	}
	public void setModeloChk(boolean modeloChk) {
		this.modeloChk = modeloChk;
	}
	public List<String> getProductosLista() {
		return productosLista;
	}
	public void setProductosLista(List<String> productosLista) {
		this.productosLista = productosLista;
	}
}
