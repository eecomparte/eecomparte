package com.atosorigin.deri.adminoper.boletas.screen;

import java.util.Date;

import org.jboss.seam.ScopeType;
import org.jboss.seam.annotations.Name;
import org.jboss.seam.annotations.Scope;

import com.atosorigin.deri.model.parametrizacion.Divisa;

/**
 * Contiene los datos de pantalla necesarios para el caso de uso
 * "consulta operaciones" del mantenimiento de datos de mercado.
 */
@Name("boletasPantalla")
@Scope(ScopeType.CONVERSATION)
public class BoletasPantalla implements java.io.Serializable {

	// Datos Producto
	protected String procedencia;
	protected String modelo;
	protected String producto;
	protected Long num;
	protected Date fContr;
	protected boolean modeloChk;
	protected String estado;
	protected String usuario;
	protected String operador;
	protected String situacion;
	protected String nivel;
	protected boolean campanyaChk;
	protected boolean compuestaChk;
	// Datos Contrataci�n
	protected Date fValor;
	protected Date fVto;
	protected String Transacc;
	protected String interNom;
	// Datos Mist
	protected String unidad;
	protected boolean modAfecMistChk;
	// Datos contables
	protected String prodOper;
	protected String ent;
	protected String oficina;
	protected boolean colat;
	protected String grupoCont;
	protected String esquema;
	protected boolean bsAgent;
	protected String tipoCobert;
	protected String tipoRiesgo;
	protected String cobAP;
	// Datos Kondor
	protected String kondorCarteraFO;
	protected String kondorNumExt;
	protected String kondorDelaType;

	// Datos Murex
	protected String murexCarteraFO;
	protected String murexCodOper;
	protected String murexNVers;
	protected String murexCompon;
	protected String murexValInicial;

	/* PESTANA COBROS / PAGOS */
	/* COBROS */
	protected String cobrosClase;
	protected String cobrosNomTit;
	protected String cobrosDivisa;
	protected String cobrosPerLiq;
	protected String cobrosImpFijo;
	protected String cobrosTipoInt;
	protected String cobrosSig;
	protected String cobrosSpread;
	protected String cobrosFormula;
	protected String cobrosBase;
	protected String cobrosDivLiq;
	protected String cobrosAmortiz;
	protected String cobrosAmortizFija;
	protected boolean cobrosLiq;
	protected String cobrosLab;
	protected String cobrosAdj;
	protected String cobrosTipoCurva;
	protected String cobrosAnt;
	protected boolean cobrosCre;
	protected boolean cobrosArr;
	protected boolean cobrosCap;
	protected boolean cobros1erTr;
	/* PAGOS */
	protected String pagosClase;
	protected String pagosNomTit;
	protected String pagosDivisa;
	protected String pagosPerLiq;
	protected String pagosImpFijo;
	protected String pagosTipoInt;
	protected String pagosSig;
	protected String pagosSpread;
	protected String pagosFormula;
	protected String pagosBase;
	protected String pagosDivLiq;
	protected String pagosAmortiz;
	protected String pagosAmortizFija;
	protected boolean pagosLiq;
	protected String pagosLab;
	protected String pagosAdj;
	protected String pagosTipoCurva;
	protected String pagosAnt;
	protected boolean pagosCre;
	protected boolean pagosArr;
	protected boolean pagosCap;
	protected boolean pagos1erTr;
	/* SIMPLE EDITION */
	protected String cpsSubyacente;
	protected String cpsTitulos;
	protected String cpsDivisa;
	protected String cpsPerLiq;
	protected String cpsPrecioInicial;
	protected String cpsFormula;
	protected String cpsBase;
	protected String cpsDivLiq;
	protected String cpsAnt;
	protected String cpsUnidad;
	protected String cpsLab;
	protected String cpsAdj;
	protected String cpsTipoCurva;
	
	protected boolean cobrosPagosLiqDigital;
	protected boolean cobrosPagosCallable;
	protected boolean cobrosPagosNoNetea;
	protected boolean cobrosPagosUltTramoLargo;
	protected String cobrosPagosLiquidacion;
	/* PESTANA PRIMAS */
	protected boolean primasUpFront;
	protected boolean primasPeriodica;
	protected boolean primasImplicita;
	protected boolean primasCancelac;

	protected boolean primasUpFrontCobroPago;
	protected String primasUpFrontPercent;
	protected String primasUpFrontImporte;
	protected String primasUpFrontDivisa;
	protected String primasUpFrontDivLiq;
	protected Date primasUpFrontFLiquidacion;
	protected boolean primasPeriodicaCobroPago;
	protected String primasPeriodicaPercent;
	protected String primasPeriodicaImporte;
	protected String primasPeriodicaDivisa;
	protected String primasPeriodicaDivLiq;
	protected boolean primasImplicitaCobroPago;
	protected String primasImplicitaPercent;
	protected String primasImplicitaImporte;
	protected String primasImplicitaDivisa;
	protected String primasImplicitaDivLiq;
	protected String primasImplicitaFPrImpl;
	protected boolean primasCancelacCobroPago;
	protected String primasCancelacPercent;
	protected String primasCancelacImporte;
	protected String primasCancelacDivisa;
	protected String primasCancelacDivLiq;
	/* PESTANA DATOS OPCION */
	protected String datosOpcionNominal;
	protected Divisa datosOpcionDivisa;
	protected String datosOpcionLab;
	protected String datosOpcionAdj;
	protected String datosOpcionTipoCurva;
	protected String datosOpcionFormula;
	protected String datosOpcionTipoSurby;
	protected String datosOpcionDivCamb;
	protected String datosOpcionMultiplicador;
	protected String datosOpcionBase;
	protected String datosOpcionEstiloOpcion;
	protected String datosOpcionModoEjercicio;
	protected String datosOpcionTipo;
	protected String datosOpcionFEjercicio;
	protected String datosOpcionMultipReval;
	protected String datosOpcionTipoStrike;
	protected String datosOpcionRefInicial;
	protected String datosOpcionPercentage;
	protected boolean datosOpcionStrike;
	protected String datosOpcionNivel1;
	protected String datosOpcionNivel2;
	protected String datosOpcionNivel1Desc;
	protected String datosOpcionNivel2Desc;
	protected boolean datosOpcionNoNetea;
	protected boolean datosOpcionUltTrLargo;
	protected boolean datosOpcionQuanto;
	protected boolean datosOpcionCesta;
	protected boolean datosOpcionCallable;
	protected boolean datosOpcionCondFij;
	protected String datosOpcionCambio;
	protected String datosOpcionDivQuan;
	protected String datosOpcionTipoBarr;
	protected boolean datosOpcionStrikePromedio;
	/* PESTANA BARRERAS */
	protected String barrerasTipoBarreraPago;
	protected String barrerasTipoBarreraCobro;
	protected String barrerasPercentageBarreraPago;
	protected String barrerasPercentageBarreraCobro;
	protected boolean barrerasRebatePagoChk;
	protected boolean barrerasRebateCobroChk;
	protected String barrerasPercentRebatePago;
	protected String barrerasPercentRebateCobro;
	/* PESTANA CONTRAPARTIDAS */
	protected String ContrapartidasPartida;
	protected String ContrapartidasContrapartida;
	protected String ContrapartidasEntMatriz;
	protected String ContrapartidasSncorrela;
	protected String ContrapartidasUC;
	protected String ContrapartidasFLiqPartida;
	protected String ContrapartidasFLiqContrapartida;
	/* PESTANA CONFIRMACIONES */
	protected boolean confContratacionEnviar;
	protected String confContratacionIdioma;
	protected String confContratacionCanal;
	protected boolean confContratacionRecibir;
	protected String confContratacionRecibirCanal;
	protected boolean confModificacionEnviar;
	protected String confModificacionIdioma;
	protected String confModificacionCanal;
	protected boolean confModificacionRecibir;
	protected String confModificacionRecibirCanal;
	protected boolean confAnulacionEnviar;
	protected String confAnulacionIdioma;
	protected String confAnulacionCanal;
	protected boolean confAnulacionRecibir;
	protected String confAnulacionRecibirCanal;
	protected boolean confCancelacionEnviar;
	protected String confCancelacionIdioma;
	protected String confCancelacionCanal;
	protected boolean confCancelacionRecibir;
	protected String confCancelacionRecibirCanal;
	protected boolean confCancParcialEnviar;
	protected String confCancParcialIdioma;
	protected String confCancParcialCanal;
	protected boolean confCancParcialRecibir;
	protected String confCancParcialRecibirCanal;
	protected boolean confLiquidacionEnviar;
	protected String confLiquidacionIdioma;
	protected String confLiquidacionCanal;
	protected boolean confLiquidacionRecibir;
	protected String confLiquidacionRecibirCanal;
	protected boolean confFijTiposEnviar;
	protected String confFijTiposIdioma;
	protected String confFijTiposCanal;
	protected boolean confFijTiposRecibir;
	protected String confFijTiposRecibirCanal;

	/* PESTANAS COMISIONES */
	protected String comisionesBrokers;
	protected String comisionesImporte;
	protected String comisionesDivisa;

	/* PESTANA MIFID */
	protected String mifidCodAutorizacion;
	protected String mifidTipoOperacion;
	protected String mifidTipoCliente;
	protected String mifidIndServicio;
	protected String mifidIndEnvio;
	protected String mifidIndForzaje;
	protected String mifidNombreOrdenante;
	protected String mifidApellido1Ord;
	protected String mifidApellido2Ord;
	protected String mifidContrapartidaOrd;
	
	/* PESTANA SIBIS */
	protected String sibisAplicacion;
	protected String sibisEntidad;
	protected String sibisOficina;
	protected String sibisCodigoContrato;
	
	/* PESTANAS CDS */
	protected String cdsTipoIdentif;
	protected String cdsIdentificador;
	protected String cdsIdentifEvento;
	protected String cdsNivelCalif;
	protected String cdsTasaRecup;
	protected String cdsEntregableValorable;
	
	/* PESTANAS DATOS GESTION */
	protected String datosGestionClaveBDU;
	protected String datosGestionOficina;
	protected String datosGestionImporte;
	protected String datosGestionCancelacion;
	protected String datosGestionDivisa;
	protected String datosGestionImputacion;
	protected String datosGestionImporteSales;
	protected String datosGestionCancelacionSales;
	protected String datosGestionImporteTotal;
	protected String datosGestionCancelacionTotal;
	public String getProcedencia() {
		return procedencia;
	}
	public void setProcedencia(String procedencia) {
		this.procedencia = procedencia;
	}
	public String getModelo() {
		return modelo;
	}
	public void setModelo(String modelo) {
		this.modelo = modelo;
	}
	public String getProducto() {
		return producto;
	}
	public void setProducto(String producto) {
		this.producto = producto;
	}
	public Long getNum() {
		return num;
	}
	public void setNum(Long num) {
		this.num = num;
	}
	public Date getfContr() {
		return fContr;
	}
	public void setfContr(Date fContr) {
		this.fContr = fContr;
	}
	public boolean isModeloChk() {
		return modeloChk;
	}
	public void setModeloChk(boolean modeloChk) {
		this.modeloChk = modeloChk;
	}
	public String getEstado() {
		return estado;
	}
	public void setEstado(String estado) {
		this.estado = estado;
	}
	public String getUsuario() {
		return usuario;
	}
	public void setUsuario(String usuario) {
		this.usuario = usuario;
	}
	public String getOperador() {
		return operador;
	}
	public void setOperador(String operador) {
		this.operador = operador;
	}
	public String getSituacion() {
		return situacion;
	}
	public void setSituacion(String situacion) {
		this.situacion = situacion;
	}
	public String getNivel() {
		return nivel;
	}
	public void setNivel(String nivel) {
		this.nivel = nivel;
	}
	public boolean isCampanyaChk() {
		return campanyaChk;
	}
	public void setCampanyaChk(boolean campanyaChk) {
		this.campanyaChk = campanyaChk;
	}
	public boolean isCompuestaChk() {
		return compuestaChk;
	}
	public void setCompuestaChk(boolean compuestaChk) {
		this.compuestaChk = compuestaChk;
	}
	public Date getfValor() {
		return fValor;
	}
	public void setfValor(Date fValor) {
		this.fValor = fValor;
	}
	public Date getfVto() {
		return fVto;
	}
	public void setfVto(Date fVto) {
		this.fVto = fVto;
	}
	public String getTransacc() {
		return Transacc;
	}
	public void setTransacc(String transacc) {
		Transacc = transacc;
	}
	public String getInterNom() {
		return interNom;
	}
	public void setInterNom(String interNom) {
		this.interNom = interNom;
	}
	public String getUnidad() {
		return unidad;
	}
	public void setUnidad(String unidad) {
		this.unidad = unidad;
	}
	public boolean isModAfecMistChk() {
		return modAfecMistChk;
	}
	public void setModAfecMistChk(boolean modAfecMistChk) {
		this.modAfecMistChk = modAfecMistChk;
	}
	public String getProdOper() {
		return prodOper;
	}
	public void setProdOper(String prodOper) {
		this.prodOper = prodOper;
	}
	public String getEnt() {
		return ent;
	}
	public void setEnt(String ent) {
		this.ent = ent;
	}
	public String getOficina() {
		return oficina;
	}
	public void setOficina(String oficina) {
		this.oficina = oficina;
	}
	public boolean isColat() {
		return colat;
	}
	public void setColat(boolean colat) {
		this.colat = colat;
	}
	public String getGrupoCont() {
		return grupoCont;
	}
	public void setGrupoCont(String grupoCont) {
		this.grupoCont = grupoCont;
	}
	public String getEsquema() {
		return esquema;
	}
	public void setEsquema(String esquema) {
		this.esquema = esquema;
	}
	public boolean isBsAgent() {
		return bsAgent;
	}
	public void setBsAgent(boolean bsAgent) {
		this.bsAgent = bsAgent;
	}
	public String getTipoCobert() {
		return tipoCobert;
	}
	public void setTipoCobert(String tipoCobert) {
		this.tipoCobert = tipoCobert;
	}
	public String getTipoRiesgo() {
		return tipoRiesgo;
	}
	public void setTipoRiesgo(String tipoRiesgo) {
		this.tipoRiesgo = tipoRiesgo;
	}
	public String getCobAP() {
		return cobAP;
	}
	public void setCobAP(String cobAP) {
		this.cobAP = cobAP;
	}
	public String getKondorCarteraFO() {
		return kondorCarteraFO;
	}
	public void setKondorCarteraFO(String kondorCarteraFO) {
		this.kondorCarteraFO = kondorCarteraFO;
	}
	public String getKondorNumExt() {
		return kondorNumExt;
	}
	public void setKondorNumExt(String kondorNumExt) {
		this.kondorNumExt = kondorNumExt;
	}
	public String getKondorDelaType() {
		return kondorDelaType;
	}
	public void setKondorDelaType(String kondorDelaType) {
		this.kondorDelaType = kondorDelaType;
	}
	public String getMurexCarteraFO() {
		return murexCarteraFO;
	}
	public void setMurexCarteraFO(String murexCarteraFO) {
		this.murexCarteraFO = murexCarteraFO;
	}
	public String getMurexCodOper() {
		return murexCodOper;
	}
	public void setMurexCodOper(String murexCodOper) {
		this.murexCodOper = murexCodOper;
	}
	public String getMurexNVers() {
		return murexNVers;
	}
	public void setMurexNVers(String murexNVers) {
		this.murexNVers = murexNVers;
	}
	public String getMurexCompon() {
		return murexCompon;
	}
	public void setMurexCompon(String murexCompon) {
		this.murexCompon = murexCompon;
	}
	public String getMurexValInicial() {
		return murexValInicial;
	}
	public void setMurexValInicial(String murexValInicial) {
		this.murexValInicial = murexValInicial;
	}
	public String getCobrosClase() {
		return cobrosClase;
	}
	public void setCobrosClase(String cobrosClase) {
		this.cobrosClase = cobrosClase;
	}
	public String getCobrosNomTit() {
		return cobrosNomTit;
	}
	public void setCobrosNomTit(String cobrosNomTit) {
		this.cobrosNomTit = cobrosNomTit;
	}
	public String getCobrosDivisa() {
		return cobrosDivisa;
	}
	public void setCobrosDivisa(String cobrosDivisa) {
		this.cobrosDivisa = cobrosDivisa;
	}
	public String getCobrosPerLiq() {
		return cobrosPerLiq;
	}
	public void setCobrosPerLiq(String cobrosPerLiq) {
		this.cobrosPerLiq = cobrosPerLiq;
	}
	public String getCobrosImpFijo() {
		return cobrosImpFijo;
	}
	public void setCobrosImpFijo(String cobrosImpFijo) {
		this.cobrosImpFijo = cobrosImpFijo;
	}
	public String getCobrosTipoInt() {
		return cobrosTipoInt;
	}
	public void setCobrosTipoInt(String cobrosTipoInt) {
		this.cobrosTipoInt = cobrosTipoInt;
	}
	public String getCobrosSig() {
		return cobrosSig;
	}
	public void setCobrosSig(String cobrosSig) {
		this.cobrosSig = cobrosSig;
	}
	public String getCobrosSpread() {
		return cobrosSpread;
	}
	public void setCobrosSpread(String cobrosSpread) {
		this.cobrosSpread = cobrosSpread;
	}
	public String getCobrosFormula() {
		return cobrosFormula;
	}
	public void setCobrosFormula(String cobrosFormula) {
		this.cobrosFormula = cobrosFormula;
	}
	public String getCobrosBase() {
		return cobrosBase;
	}
	public void setCobrosBase(String cobrosBase) {
		this.cobrosBase = cobrosBase;
	}
	public String getCobrosDivLiq() {
		return cobrosDivLiq;
	}
	public void setCobrosDivLiq(String cobrosDivLiq) {
		this.cobrosDivLiq = cobrosDivLiq;
	}
	public String getCobrosAmortiz() {
		return cobrosAmortiz;
	}
	public void setCobrosAmortiz(String cobrosAmortiz) {
		this.cobrosAmortiz = cobrosAmortiz;
	}
	public String getCobrosAmortizFija() {
		return cobrosAmortizFija;
	}
	public void setCobrosAmortizFija(String cobrosAmortizFija) {
		this.cobrosAmortizFija = cobrosAmortizFija;
	}
	public boolean isCobrosLiq() {
		return cobrosLiq;
	}
	public void setCobrosLiq(boolean cobrosLiq) {
		this.cobrosLiq = cobrosLiq;
	}
	public String getCobrosLab() {
		return cobrosLab;
	}
	public void setCobrosLab(String cobrosLab) {
		this.cobrosLab = cobrosLab;
	}
	public String getCobrosAdj() {
		return cobrosAdj;
	}
	public void setCobrosAdj(String cobrosAdj) {
		this.cobrosAdj = cobrosAdj;
	}
	public String getCobrosTipoCurva() {
		return cobrosTipoCurva;
	}
	public void setCobrosTipoCurva(String cobrosTipoCurva) {
		this.cobrosTipoCurva = cobrosTipoCurva;
	}
	public String getCobrosAnt() {
		return cobrosAnt;
	}
	public void setCobrosAnt(String cobrosAnt) {
		this.cobrosAnt = cobrosAnt;
	}
	public boolean isCobrosCre() {
		return cobrosCre;
	}
	public void setCobrosCre(boolean cobrosCre) {
		this.cobrosCre = cobrosCre;
	}
	public boolean isCobrosArr() {
		return cobrosArr;
	}
	public void setCobrosArr(boolean cobrosArr) {
		this.cobrosArr = cobrosArr;
	}
	public boolean isCobrosCap() {
		return cobrosCap;
	}
	public void setCobrosCap(boolean cobrosCap) {
		this.cobrosCap = cobrosCap;
	}
	public boolean isCobros1erTr() {
		return cobros1erTr;
	}
	public void setCobros1erTr(boolean cobros1erTr) {
		this.cobros1erTr = cobros1erTr;
	}
	public String getPagosClase() {
		return pagosClase;
	}
	public void setPagosClase(String pagosClase) {
		this.pagosClase = pagosClase;
	}
	public String getPagosNomTit() {
		return pagosNomTit;
	}
	public void setPagosNomTit(String pagosNomTit) {
		this.pagosNomTit = pagosNomTit;
	}
	public String getPagosDivisa() {
		return pagosDivisa;
	}
	public void setPagosDivisa(String pagosDivisa) {
		this.pagosDivisa = pagosDivisa;
	}
	public String getPagosPerLiq() {
		return pagosPerLiq;
	}
	public void setPagosPerLiq(String pagosPerLiq) {
		this.pagosPerLiq = pagosPerLiq;
	}
	public String getPagosImpFijo() {
		return pagosImpFijo;
	}
	public void setPagosImpFijo(String pagosImpFijo) {
		this.pagosImpFijo = pagosImpFijo;
	}
	public String getPagosTipoInt() {
		return pagosTipoInt;
	}
	public void setPagosTipoInt(String pagosTipoInt) {
		this.pagosTipoInt = pagosTipoInt;
	}
	public String getPagosSig() {
		return pagosSig;
	}
	public void setPagosSig(String pagosSig) {
		this.pagosSig = pagosSig;
	}
	public String getPagosSpread() {
		return pagosSpread;
	}
	public void setPagosSpread(String pagosSpread) {
		this.pagosSpread = pagosSpread;
	}
	public String getPagosFormula() {
		return pagosFormula;
	}
	public void setPagosFormula(String pagosFormula) {
		this.pagosFormula = pagosFormula;
	}
	public String getPagosBase() {
		return pagosBase;
	}
	public void setPagosBase(String pagosBase) {
		this.pagosBase = pagosBase;
	}
	public String getPagosDivLiq() {
		return pagosDivLiq;
	}
	public void setPagosDivLiq(String pagosDivLiq) {
		this.pagosDivLiq = pagosDivLiq;
	}
	public String getPagosAmortiz() {
		return pagosAmortiz;
	}
	public void setPagosAmortiz(String pagosAmortiz) {
		this.pagosAmortiz = pagosAmortiz;
	}
	public String getPagosAmortizFija() {
		return pagosAmortizFija;
	}
	public void setPagosAmortizFija(String pagosAmortizFija) {
		this.pagosAmortizFija = pagosAmortizFija;
	}
	public boolean isPagosLiq() {
		return pagosLiq;
	}
	public void setPagosLiq(boolean pagosLiq) {
		this.pagosLiq = pagosLiq;
	}
	public String getPagosLab() {
		return pagosLab;
	}
	public void setPagosLab(String pagosLab) {
		this.pagosLab = pagosLab;
	}
	public String getPagosAdj() {
		return pagosAdj;
	}
	public void setPagosAdj(String pagosAdj) {
		this.pagosAdj = pagosAdj;
	}
	public String getPagosTipoCurva() {
		return pagosTipoCurva;
	}
	public void setPagosTipoCurva(String pagosTipoCurva) {
		this.pagosTipoCurva = pagosTipoCurva;
	}
	public String getPagosAnt() {
		return pagosAnt;
	}
	public void setPagosAnt(String pagosAnt) {
		this.pagosAnt = pagosAnt;
	}
	public boolean isPagosCre() {
		return pagosCre;
	}
	public void setPagosCre(boolean pagosCre) {
		this.pagosCre = pagosCre;
	}
	public boolean isPagosArr() {
		return pagosArr;
	}
	public void setPagosArr(boolean pagosArr) {
		this.pagosArr = pagosArr;
	}
	public boolean isPagosCap() {
		return pagosCap;
	}
	public void setPagosCap(boolean pagosCap) {
		this.pagosCap = pagosCap;
	}
	public boolean isPagos1erTr() {
		return pagos1erTr;
	}
	public void setPagos1erTr(boolean pagos1erTr) {
		this.pagos1erTr = pagos1erTr;
	}
	public String getCpsSubyacente() {
		return cpsSubyacente;
	}
	public void setCpsSubyacente(String cpsSubyacente) {
		this.cpsSubyacente = cpsSubyacente;
	}
	public String getCpsTitulos() {
		return cpsTitulos;
	}
	public void setCpsTitulos(String cpsTitulos) {
		this.cpsTitulos = cpsTitulos;
	}
	public String getCpsDivisa() {
		return cpsDivisa;
	}
	public void setCpsDivisa(String cpsDivisa) {
		this.cpsDivisa = cpsDivisa;
	}
	public String getCpsPerLiq() {
		return cpsPerLiq;
	}
	public void setCpsPerLiq(String cpsPerLiq) {
		this.cpsPerLiq = cpsPerLiq;
	}
	public String getCpsPrecioInicial() {
		return cpsPrecioInicial;
	}
	public void setCpsPrecioInicial(String cpsPrecioInicial) {
		this.cpsPrecioInicial = cpsPrecioInicial;
	}
	public String getCpsFormula() {
		return cpsFormula;
	}
	public void setCpsFormula(String cpsFormula) {
		this.cpsFormula = cpsFormula;
	}
	public String getCpsBase() {
		return cpsBase;
	}
	public void setCpsBase(String cpsBase) {
		this.cpsBase = cpsBase;
	}
	public String getCpsDivLiq() {
		return cpsDivLiq;
	}
	public void setCpsDivLiq(String cpsDivLiq) {
		this.cpsDivLiq = cpsDivLiq;
	}
	public String getCpsAnt() {
		return cpsAnt;
	}
	public void setCpsAnt(String cpsAnt) {
		this.cpsAnt = cpsAnt;
	}
	public String getCpsUnidad() {
		return cpsUnidad;
	}
	public void setCpsUnidad(String cpsUnidad) {
		this.cpsUnidad = cpsUnidad;
	}
	public String getCpsLab() {
		return cpsLab;
	}
	public void setCpsLab(String cpsLab) {
		this.cpsLab = cpsLab;
	}
	public String getCpsAdj() {
		return cpsAdj;
	}
	public void setCpsAdj(String cpsAdj) {
		this.cpsAdj = cpsAdj;
	}
	public String getCpsTipoCurva() {
		return cpsTipoCurva;
	}
	public void setCpsTipoCurva(String cpsTipoCurva) {
		this.cpsTipoCurva = cpsTipoCurva;
	}
	public boolean isCobrosPagosLiqDigital() {
		return cobrosPagosLiqDigital;
	}
	public void setCobrosPagosLiqDigital(boolean cobrosPagosLiqDigital) {
		this.cobrosPagosLiqDigital = cobrosPagosLiqDigital;
	}
	public boolean isCobrosPagosCallable() {
		return cobrosPagosCallable;
	}
	public void setCobrosPagosCallable(boolean cobrosPagosCallable) {
		this.cobrosPagosCallable = cobrosPagosCallable;
	}
	public boolean isCobrosPagosNoNetea() {
		return cobrosPagosNoNetea;
	}
	public void setCobrosPagosNoNetea(boolean cobrosPagosNoNetea) {
		this.cobrosPagosNoNetea = cobrosPagosNoNetea;
	}
	public boolean isCobrosPagosUltTramoLargo() {
		return cobrosPagosUltTramoLargo;
	}
	public void setCobrosPagosUltTramoLargo(boolean cobrosPagosUltTramoLargo) {
		this.cobrosPagosUltTramoLargo = cobrosPagosUltTramoLargo;
	}
	public String getCobrosPagosLiquidacion() {
		return cobrosPagosLiquidacion;
	}
	public void setCobrosPagosLiquidacion(String cobrosPagosLiquidacion) {
		this.cobrosPagosLiquidacion = cobrosPagosLiquidacion;
	}
	public boolean isPrimasUpFront() {
		return primasUpFront;
	}
	public void setPrimasUpFront(boolean primasUpFront) {
		this.primasUpFront = primasUpFront;
	}
	public boolean isPrimasPeriodica() {
		return primasPeriodica;
	}
	public void setPrimasPeriodica(boolean primasPeriodica) {
		this.primasPeriodica = primasPeriodica;
	}
	public boolean isPrimasImplicita() {
		return primasImplicita;
	}
	public void setPrimasImplicita(boolean primasImplicita) {
		this.primasImplicita = primasImplicita;
	}
	public boolean isPrimasCancelac() {
		return primasCancelac;
	}
	public void setPrimasCancelac(boolean primasCancelac) {
		this.primasCancelac = primasCancelac;
	}
	public boolean isPrimasUpFrontCobroPago() {
		return primasUpFrontCobroPago;
	}
	public void setPrimasUpFrontCobroPago(boolean primasUpFrontCobroPago) {
		this.primasUpFrontCobroPago = primasUpFrontCobroPago;
	}
	public String getPrimasUpFrontPercent() {
		return primasUpFrontPercent;
	}
	public void setPrimasUpFrontPercent(String primasUpFrontPercent) {
		this.primasUpFrontPercent = primasUpFrontPercent;
	}
	public String getPrimasUpFrontImporte() {
		return primasUpFrontImporte;
	}
	public void setPrimasUpFrontImporte(String primasUpFrontImporte) {
		this.primasUpFrontImporte = primasUpFrontImporte;
	}
	public String getPrimasUpFrontDivisa() {
		return primasUpFrontDivisa;
	}
	public void setPrimasUpFrontDivisa(String primasUpFrontDivisa) {
		this.primasUpFrontDivisa = primasUpFrontDivisa;
	}
	public String getPrimasUpFrontDivLiq() {
		return primasUpFrontDivLiq;
	}
	public void setPrimasUpFrontDivLiq(String primasUpFrontDivLiq) {
		this.primasUpFrontDivLiq = primasUpFrontDivLiq;
	}
	public Date getPrimasUpFrontFLiquidacion() {
		return primasUpFrontFLiquidacion;
	}
	public void setPrimasUpFrontFLiquidacion(Date primasUpFrontFLiquidacion) {
		this.primasUpFrontFLiquidacion = primasUpFrontFLiquidacion;
	}
	public boolean isPrimasPeriodicaCobroPago() {
		return primasPeriodicaCobroPago;
	}
	public void setPrimasPeriodicaCobroPago(boolean primasPeriodicaCobroPago) {
		this.primasPeriodicaCobroPago = primasPeriodicaCobroPago;
	}
	public String getPrimasPeriodicaPercent() {
		return primasPeriodicaPercent;
	}
	public void setPrimasPeriodicaPercent(String primasPeriodicaPercent) {
		this.primasPeriodicaPercent = primasPeriodicaPercent;
	}
	public String getPrimasPeriodicaImporte() {
		return primasPeriodicaImporte;
	}
	public void setPrimasPeriodicaImporte(String primasPeriodicaImporte) {
		this.primasPeriodicaImporte = primasPeriodicaImporte;
	}
	public String getPrimasPeriodicaDivisa() {
		return primasPeriodicaDivisa;
	}
	public void setPrimasPeriodicaDivisa(String primasPeriodicaDivisa) {
		this.primasPeriodicaDivisa = primasPeriodicaDivisa;
	}
	public String getPrimasPeriodicaDivLiq() {
		return primasPeriodicaDivLiq;
	}
	public void setPrimasPeriodicaDivLiq(String primasPeriodicaDivLiq) {
		this.primasPeriodicaDivLiq = primasPeriodicaDivLiq;
	}
	public boolean isPrimasImplicitaCobroPago() {
		return primasImplicitaCobroPago;
	}
	public void setPrimasImplicitaCobroPago(boolean primasImplicitaCobroPago) {
		this.primasImplicitaCobroPago = primasImplicitaCobroPago;
	}
	public String getPrimasImplicitaPercent() {
		return primasImplicitaPercent;
	}
	public void setPrimasImplicitaPercent(String primasImplicitaPercent) {
		this.primasImplicitaPercent = primasImplicitaPercent;
	}
	public String getPrimasImplicitaImporte() {
		return primasImplicitaImporte;
	}
	public void setPrimasImplicitaImporte(String primasImplicitaImporte) {
		this.primasImplicitaImporte = primasImplicitaImporte;
	}
	public String getPrimasImplicitaDivisa() {
		return primasImplicitaDivisa;
	}
	public void setPrimasImplicitaDivisa(String primasImplicitaDivisa) {
		this.primasImplicitaDivisa = primasImplicitaDivisa;
	}
	public String getPrimasImplicitaDivLiq() {
		return primasImplicitaDivLiq;
	}
	public void setPrimasImplicitaDivLiq(String primasImplicitaDivLiq) {
		this.primasImplicitaDivLiq = primasImplicitaDivLiq;
	}
	public String getPrimasImplicitaFPrImpl() {
		return primasImplicitaFPrImpl;
	}
	public void setPrimasImplicitaFPrImpl(String primasImplicitaFPrImpl) {
		this.primasImplicitaFPrImpl = primasImplicitaFPrImpl;
	}
	public boolean isPrimasCancelacCobroPago() {
		return primasCancelacCobroPago;
	}
	public void setPrimasCancelacCobroPago(boolean primasCancelacCobroPago) {
		this.primasCancelacCobroPago = primasCancelacCobroPago;
	}
	public String getPrimasCancelacPercent() {
		return primasCancelacPercent;
	}
	public void setPrimasCancelacPercent(String primasCancelacPercent) {
		this.primasCancelacPercent = primasCancelacPercent;
	}
	public String getPrimasCancelacImporte() {
		return primasCancelacImporte;
	}
	public void setPrimasCancelacImporte(String primasCancelacImporte) {
		this.primasCancelacImporte = primasCancelacImporte;
	}
	public String getPrimasCancelacDivisa() {
		return primasCancelacDivisa;
	}
	public void setPrimasCancelacDivisa(String primasCancelacDivisa) {
		this.primasCancelacDivisa = primasCancelacDivisa;
	}
	public String getPrimasCancelacDivLiq() {
		return primasCancelacDivLiq;
	}
	public void setPrimasCancelacDivLiq(String primasCancelacDivLiq) {
		this.primasCancelacDivLiq = primasCancelacDivLiq;
	}
	public String getDatosOpcionNominal() {
		return datosOpcionNominal;
	}
	public void setDatosOpcionNominal(String datosOpcionNominal) {
		this.datosOpcionNominal = datosOpcionNominal;
	}
	public Divisa getDatosOpcionDivisa() {
		return datosOpcionDivisa;
	}
	public void setDatosOpcionDivisa(Divisa datosOpcionDivisa) {
		this.datosOpcionDivisa = datosOpcionDivisa;
	}
	public String getDatosOpcionLab() {
		return datosOpcionLab;
	}
	public void setDatosOpcionLab(String datosOpcionLab) {
		this.datosOpcionLab = datosOpcionLab;
	}
	public String getDatosOpcionAdj() {
		return datosOpcionAdj;
	}
	public void setDatosOpcionAdj(String datosOpcionAdj) {
		this.datosOpcionAdj = datosOpcionAdj;
	}
	public String getDatosOpcionTipoCurva() {
		return datosOpcionTipoCurva;
	}
	public void setDatosOpcionTipoCurva(String datosOpcionTipoCurva) {
		this.datosOpcionTipoCurva = datosOpcionTipoCurva;
	}
	public String getDatosOpcionFormula() {
		return datosOpcionFormula;
	}
	public void setDatosOpcionFormula(String datosOpcionFormula) {
		this.datosOpcionFormula = datosOpcionFormula;
	}
	public String getDatosOpcionTipoSurby() {
		return datosOpcionTipoSurby;
	}
	public void setDatosOpcionTipoSurby(String datosOpcionTipoSurby) {
		this.datosOpcionTipoSurby = datosOpcionTipoSurby;
	}
	public String getDatosOpcionDivCamb() {
		return datosOpcionDivCamb;
	}
	public void setDatosOpcionDivCamb(String datosOpcionDivCamb) {
		this.datosOpcionDivCamb = datosOpcionDivCamb;
	}
	public String getDatosOpcionMultiplicador() {
		return datosOpcionMultiplicador;
	}
	public void setDatosOpcionMultiplicador(String datosOpcionMultiplicador) {
		this.datosOpcionMultiplicador = datosOpcionMultiplicador;
	}
	public String getDatosOpcionBase() {
		return datosOpcionBase;
	}
	public void setDatosOpcionBase(String datosOpcionBase) {
		this.datosOpcionBase = datosOpcionBase;
	}
	public String getDatosOpcionEstiloOpcion() {
		return datosOpcionEstiloOpcion;
	}
	public void setDatosOpcionEstiloOpcion(String datosOpcionEstiloOpcion) {
		this.datosOpcionEstiloOpcion = datosOpcionEstiloOpcion;
	}
	public String getDatosOpcionModoEjercicio() {
		return datosOpcionModoEjercicio;
	}
	public void setDatosOpcionModoEjercicio(String datosOpcionModoEjercicio) {
		this.datosOpcionModoEjercicio = datosOpcionModoEjercicio;
	}
	public String getDatosOpcionTipo() {
		return datosOpcionTipo;
	}
	public void setDatosOpcionTipo(String datosOpcionTipo) {
		this.datosOpcionTipo = datosOpcionTipo;
	}
	public String getDatosOpcionFEjercicio() {
		return datosOpcionFEjercicio;
	}
	public void setDatosOpcionFEjercicio(String datosOpcionFEjercicio) {
		this.datosOpcionFEjercicio = datosOpcionFEjercicio;
	}
	public String getDatosOpcionMultipReval() {
		return datosOpcionMultipReval;
	}
	public void setDatosOpcionMultipReval(String datosOpcionMultipReval) {
		this.datosOpcionMultipReval = datosOpcionMultipReval;
	}
	public String getDatosOpcionTipoStrike() {
		return datosOpcionTipoStrike;
	}
	public void setDatosOpcionTipoStrike(String datosOpcionTipoStrike) {
		this.datosOpcionTipoStrike = datosOpcionTipoStrike;
	}
	public String getDatosOpcionRefInicial() {
		return datosOpcionRefInicial;
	}
	public void setDatosOpcionRefInicial(String datosOpcionRefInicial) {
		this.datosOpcionRefInicial = datosOpcionRefInicial;
	}
	public String getDatosOpcionPercentage() {
		return datosOpcionPercentage;
	}
	public void setDatosOpcionPercentage(String datosOpcionPercentage) {
		this.datosOpcionPercentage = datosOpcionPercentage;
	}
	public boolean isDatosOpcionStrike() {
		return datosOpcionStrike;
	}
	public void setDatosOpcionStrike(boolean datosOpcionStrike) {
		this.datosOpcionStrike = datosOpcionStrike;
	}
	public String getDatosOpcionNivel1() {
		return datosOpcionNivel1;
	}
	public void setDatosOpcionNivel1(String datosOpcionNivel1) {
		this.datosOpcionNivel1 = datosOpcionNivel1;
	}
	public String getDatosOpcionNivel2() {
		return datosOpcionNivel2;
	}
	public void setDatosOpcionNivel2(String datosOpcionNivel2) {
		this.datosOpcionNivel2 = datosOpcionNivel2;
	}
	public String getDatosOpcionNivel1Desc() {
		return datosOpcionNivel1Desc;
	}
	public void setDatosOpcionNivel1Desc(String datosOpcionNivel1Desc) {
		this.datosOpcionNivel1Desc = datosOpcionNivel1Desc;
	}
	public String getDatosOpcionNivel2Desc() {
		return datosOpcionNivel2Desc;
	}
	public void setDatosOpcionNivel2Desc(String datosOpcionNivel2Desc) {
		this.datosOpcionNivel2Desc = datosOpcionNivel2Desc;
	}
	public boolean isDatosOpcionNoNetea() {
		return datosOpcionNoNetea;
	}
	public void setDatosOpcionNoNetea(boolean datosOpcionNoNetea) {
		this.datosOpcionNoNetea = datosOpcionNoNetea;
	}
	public boolean isDatosOpcionUltTrLargo() {
		return datosOpcionUltTrLargo;
	}
	public void setDatosOpcionUltTrLargo(boolean datosOpcionUltTrLargo) {
		this.datosOpcionUltTrLargo = datosOpcionUltTrLargo;
	}
	public boolean isDatosOpcionQuanto() {
		return datosOpcionQuanto;
	}
	public void setDatosOpcionQuanto(boolean datosOpcionQuanto) {
		this.datosOpcionQuanto = datosOpcionQuanto;
	}
	public boolean isDatosOpcionCesta() {
		return datosOpcionCesta;
	}
	public void setDatosOpcionCesta(boolean datosOpcionCesta) {
		this.datosOpcionCesta = datosOpcionCesta;
	}
	public boolean isDatosOpcionCallable() {
		return datosOpcionCallable;
	}
	public void setDatosOpcionCallable(boolean datosOpcionCallable) {
		this.datosOpcionCallable = datosOpcionCallable;
	}
	public boolean isDatosOpcionCondFij() {
		return datosOpcionCondFij;
	}
	public void setDatosOpcionCondFij(boolean datosOpcionCondFij) {
		this.datosOpcionCondFij = datosOpcionCondFij;
	}
	public String getDatosOpcionCambio() {
		return datosOpcionCambio;
	}
	public void setDatosOpcionCambio(String datosOpcionCambio) {
		this.datosOpcionCambio = datosOpcionCambio;
	}
	public String getDatosOpcionDivQuan() {
		return datosOpcionDivQuan;
	}
	public void setDatosOpcionDivQuan(String datosOpcionDivQuan) {
		this.datosOpcionDivQuan = datosOpcionDivQuan;
	}
	public String getDatosOpcionTipoBarr() {
		return datosOpcionTipoBarr;
	}
	public void setDatosOpcionTipoBarr(String datosOpcionTipoBarr) {
		this.datosOpcionTipoBarr = datosOpcionTipoBarr;
	}
	public boolean isDatosOpcionStrikePromedio() {
		return datosOpcionStrikePromedio;
	}
	public void setDatosOpcionStrikePromedio(boolean datosOpcionStrikePromedio) {
		this.datosOpcionStrikePromedio = datosOpcionStrikePromedio;
	}
	public String getBarrerasTipoBarreraPago() {
		return barrerasTipoBarreraPago;
	}
	public void setBarrerasTipoBarreraPago(String barrerasTipoBarreraPago) {
		this.barrerasTipoBarreraPago = barrerasTipoBarreraPago;
	}
	public String getBarrerasTipoBarreraCobro() {
		return barrerasTipoBarreraCobro;
	}
	public void setBarrerasTipoBarreraCobro(String barrerasTipoBarreraCobro) {
		this.barrerasTipoBarreraCobro = barrerasTipoBarreraCobro;
	}
	public String getBarrerasPercentageBarreraPago() {
		return barrerasPercentageBarreraPago;
	}
	public void setBarrerasPercentageBarreraPago(String barrerasPercentageBarreraPago) {
		this.barrerasPercentageBarreraPago = barrerasPercentageBarreraPago;
	}
	public String getBarrerasPercentageBarreraCobro() {
		return barrerasPercentageBarreraCobro;
	}
	public void setBarrerasPercentageBarreraCobro(String barrerasPercentageBarreraCobro) {
		this.barrerasPercentageBarreraCobro = barrerasPercentageBarreraCobro;
	}
	public boolean isBarrerasRebatePagoChk() {
		return barrerasRebatePagoChk;
	}
	public void setBarrerasRebatePagoChk(boolean barrerasRebatePagoChk) {
		this.barrerasRebatePagoChk = barrerasRebatePagoChk;
	}
	public boolean isBarrerasRebateCobroChk() {
		return barrerasRebateCobroChk;
	}
	public void setBarrerasRebateCobroChk(boolean barrerasRebateCobroChk) {
		this.barrerasRebateCobroChk = barrerasRebateCobroChk;
	}
	public String getBarrerasPercentRebatePago() {
		return barrerasPercentRebatePago;
	}
	public void setBarrerasPercentRebatePago(String barrerasPercentRebatePago) {
		this.barrerasPercentRebatePago = barrerasPercentRebatePago;
	}
	public String getBarrerasPercentRebateCobro() {
		return barrerasPercentRebateCobro;
	}
	public void setBarrerasPercentRebateCobro(String barrerasPercentRebateCobro) {
		this.barrerasPercentRebateCobro = barrerasPercentRebateCobro;
	}
	public String getContrapartidasPartida() {
		return ContrapartidasPartida;
	}
	public void setContrapartidasPartida(String contrapartidasPartida) {
		ContrapartidasPartida = contrapartidasPartida;
	}
	public String getContrapartidasContrapartida() {
		return ContrapartidasContrapartida;
	}
	public void setContrapartidasContrapartida(String contrapartidasContrapartida) {
		ContrapartidasContrapartida = contrapartidasContrapartida;
	}
	public String getContrapartidasEntMatriz() {
		return ContrapartidasEntMatriz;
	}
	public void setContrapartidasEntMatriz(String contrapartidasEntMatriz) {
		ContrapartidasEntMatriz = contrapartidasEntMatriz;
	}
	public String getContrapartidasSncorrela() {
		return ContrapartidasSncorrela;
	}
	public void setContrapartidasSncorrela(String contrapartidasSncorrela) {
		ContrapartidasSncorrela = contrapartidasSncorrela;
	}
	public String getContrapartidasUC() {
		return ContrapartidasUC;
	}
	public void setContrapartidasUC(String contrapartidasUC) {
		ContrapartidasUC = contrapartidasUC;
	}
	public String getContrapartidasFLiqPartida() {
		return ContrapartidasFLiqPartida;
	}
	public void setContrapartidasFLiqPartida(String contrapartidasFLiqPartida) {
		ContrapartidasFLiqPartida = contrapartidasFLiqPartida;
	}
	public String getContrapartidasFLiqContrapartida() {
		return ContrapartidasFLiqContrapartida;
	}
	public void setContrapartidasFLiqContrapartida(String contrapartidasFLiqContrapartida) {
		ContrapartidasFLiqContrapartida = contrapartidasFLiqContrapartida;
	}
	public boolean isConfContratacionEnviar() {
		return confContratacionEnviar;
	}
	public void setConfContratacionEnviar(boolean confContratacionEnviar) {
		this.confContratacionEnviar = confContratacionEnviar;
	}
	public String getConfContratacionIdioma() {
		return confContratacionIdioma;
	}
	public void setConfContratacionIdioma(String confContratacionIdioma) {
		this.confContratacionIdioma = confContratacionIdioma;
	}
	public String getConfContratacionCanal() {
		return confContratacionCanal;
	}
	public void setConfContratacionCanal(String confContratacionCanal) {
		this.confContratacionCanal = confContratacionCanal;
	}
	public boolean isConfContratacionRecibir() {
		return confContratacionRecibir;
	}
	public void setConfContratacionRecibir(boolean confContratacionRecibir) {
		this.confContratacionRecibir = confContratacionRecibir;
	}
	public String getConfContratacionRecibirCanal() {
		return confContratacionRecibirCanal;
	}
	public void setConfContratacionRecibirCanal(String confContratacionRecibirCanal) {
		this.confContratacionRecibirCanal = confContratacionRecibirCanal;
	}
	public boolean isConfModificacionEnviar() {
		return confModificacionEnviar;
	}
	public void setConfModificacionEnviar(boolean confModificacionEnviar) {
		this.confModificacionEnviar = confModificacionEnviar;
	}
	public String getConfModificacionIdioma() {
		return confModificacionIdioma;
	}
	public void setConfModificacionIdioma(String confModificacionIdioma) {
		this.confModificacionIdioma = confModificacionIdioma;
	}
	public String getConfModificacionCanal() {
		return confModificacionCanal;
	}
	public void setConfModificacionCanal(String confModificacionCanal) {
		this.confModificacionCanal = confModificacionCanal;
	}
	public boolean isConfModificacionRecibir() {
		return confModificacionRecibir;
	}
	public void setConfModificacionRecibir(boolean confModificacionRecibir) {
		this.confModificacionRecibir = confModificacionRecibir;
	}
	public String getConfModificacionRecibirCanal() {
		return confModificacionRecibirCanal;
	}
	public void setConfModificacionRecibirCanal(String confModificacionRecibirCanal) {
		this.confModificacionRecibirCanal = confModificacionRecibirCanal;
	}
	public boolean isConfAnulacionEnviar() {
		return confAnulacionEnviar;
	}
	public void setConfAnulacionEnviar(boolean confAnulacionEnviar) {
		this.confAnulacionEnviar = confAnulacionEnviar;
	}
	public String getConfAnulacionIdioma() {
		return confAnulacionIdioma;
	}
	public void setConfAnulacionIdioma(String confAnulacionIdioma) {
		this.confAnulacionIdioma = confAnulacionIdioma;
	}
	public String getConfAnulacionCanal() {
		return confAnulacionCanal;
	}
	public void setConfAnulacionCanal(String confAnulacionCanal) {
		this.confAnulacionCanal = confAnulacionCanal;
	}
	public boolean isConfAnulacionRecibir() {
		return confAnulacionRecibir;
	}
	public void setConfAnulacionRecibir(boolean confAnulacionRecibir) {
		this.confAnulacionRecibir = confAnulacionRecibir;
	}
	public String getConfAnulacionRecibirCanal() {
		return confAnulacionRecibirCanal;
	}
	public void setConfAnulacionRecibirCanal(String confAnulacionRecibirCanal) {
		this.confAnulacionRecibirCanal = confAnulacionRecibirCanal;
	}
	public boolean isConfCancelacionEnviar() {
		return confCancelacionEnviar;
	}
	public void setConfCancelacionEnviar(boolean confCancelacionEnviar) {
		this.confCancelacionEnviar = confCancelacionEnviar;
	}
	public String getConfCancelacionIdioma() {
		return confCancelacionIdioma;
	}
	public void setConfCancelacionIdioma(String confCancelacionIdioma) {
		this.confCancelacionIdioma = confCancelacionIdioma;
	}
	public String getConfCancelacionCanal() {
		return confCancelacionCanal;
	}
	public void setConfCancelacionCanal(String confCancelacionCanal) {
		this.confCancelacionCanal = confCancelacionCanal;
	}
	public boolean isConfCancelacionRecibir() {
		return confCancelacionRecibir;
	}
	public void setConfCancelacionRecibir(boolean confCancelacionRecibir) {
		this.confCancelacionRecibir = confCancelacionRecibir;
	}
	public String getConfCancelacionRecibirCanal() {
		return confCancelacionRecibirCanal;
	}
	public void setConfCancelacionRecibirCanal(String confCancelacionRecibirCanal) {
		this.confCancelacionRecibirCanal = confCancelacionRecibirCanal;
	}
	public boolean isConfCancParcialEnviar() {
		return confCancParcialEnviar;
	}
	public void setConfCancParcialEnviar(boolean confCancParcialEnviar) {
		this.confCancParcialEnviar = confCancParcialEnviar;
	}
	public String getConfCancParcialIdioma() {
		return confCancParcialIdioma;
	}
	public void setConfCancParcialIdioma(String confCancParcialIdioma) {
		this.confCancParcialIdioma = confCancParcialIdioma;
	}
	public String getConfCancParcialCanal() {
		return confCancParcialCanal;
	}
	public void setConfCancParcialCanal(String confCancParcialCanal) {
		this.confCancParcialCanal = confCancParcialCanal;
	}
	public boolean isConfCancParcialRecibir() {
		return confCancParcialRecibir;
	}
	public void setConfCancParcialRecibir(boolean confCancParcialRecibir) {
		this.confCancParcialRecibir = confCancParcialRecibir;
	}
	public String getConfCancParcialRecibirCanal() {
		return confCancParcialRecibirCanal;
	}
	public void setConfCancParcialRecibirCanal(String confCancParcialRecibirCanal) {
		this.confCancParcialRecibirCanal = confCancParcialRecibirCanal;
	}
	public boolean isConfLiquidacionEnviar() {
		return confLiquidacionEnviar;
	}
	public void setConfLiquidacionEnviar(boolean confLiquidacionEnviar) {
		this.confLiquidacionEnviar = confLiquidacionEnviar;
	}
	public String getConfLiquidacionIdioma() {
		return confLiquidacionIdioma;
	}
	public void setConfLiquidacionIdioma(String confLiquidacionIdioma) {
		this.confLiquidacionIdioma = confLiquidacionIdioma;
	}
	public String getConfLiquidacionCanal() {
		return confLiquidacionCanal;
	}
	public void setConfLiquidacionCanal(String confLiquidacionCanal) {
		this.confLiquidacionCanal = confLiquidacionCanal;
	}
	public boolean isConfLiquidacionRecibir() {
		return confLiquidacionRecibir;
	}
	public void setConfLiquidacionRecibir(boolean confLiquidacionRecibir) {
		this.confLiquidacionRecibir = confLiquidacionRecibir;
	}
	public String getConfLiquidacionRecibirCanal() {
		return confLiquidacionRecibirCanal;
	}
	public void setConfLiquidacionRecibirCanal(String confLiquidacionRecibirCanal) {
		this.confLiquidacionRecibirCanal = confLiquidacionRecibirCanal;
	}
	public boolean isConfFijTiposEnviar() {
		return confFijTiposEnviar;
	}
	public void setConfFijTiposEnviar(boolean confFijTiposEnviar) {
		this.confFijTiposEnviar = confFijTiposEnviar;
	}
	public String getConfFijTiposIdioma() {
		return confFijTiposIdioma;
	}
	public void setConfFijTiposIdioma(String confFijTiposIdioma) {
		this.confFijTiposIdioma = confFijTiposIdioma;
	}
	public String getConfFijTiposCanal() {
		return confFijTiposCanal;
	}
	public void setConfFijTiposCanal(String confFijTiposCanal) {
		this.confFijTiposCanal = confFijTiposCanal;
	}
	public boolean isConfFijTiposRecibir() {
		return confFijTiposRecibir;
	}
	public void setConfFijTiposRecibir(boolean confFijTiposRecibir) {
		this.confFijTiposRecibir = confFijTiposRecibir;
	}
	public String getConfFijTiposRecibirCanal() {
		return confFijTiposRecibirCanal;
	}
	public void setConfFijTiposRecibirCanal(String confFijTiposRecibirCanal) {
		this.confFijTiposRecibirCanal = confFijTiposRecibirCanal;
	}
	public String getComisionesBrokers() {
		return comisionesBrokers;
	}
	public void setComisionesBrokers(String comisionesBrokers) {
		this.comisionesBrokers = comisionesBrokers;
	}
	public String getComisionesImporte() {
		return comisionesImporte;
	}
	public void setComisionesImporte(String comisionesImporte) {
		this.comisionesImporte = comisionesImporte;
	}
	public String getComisionesDivisa() {
		return comisionesDivisa;
	}
	public void setComisionesDivisa(String comisionesDivisa) {
		this.comisionesDivisa = comisionesDivisa;
	}
	public String getMifidCodAutorizacion() {
		return mifidCodAutorizacion;
	}
	public void setMifidCodAutorizacion(String mifidCodAutorizacion) {
		this.mifidCodAutorizacion = mifidCodAutorizacion;
	}
	public String getMifidTipoOperacion() {
		return mifidTipoOperacion;
	}
	public void setMifidTipoOperacion(String mifidTipoOperacion) {
		this.mifidTipoOperacion = mifidTipoOperacion;
	}
	public String getMifidTipoCliente() {
		return mifidTipoCliente;
	}
	public void setMifidTipoCliente(String mifidTipoCliente) {
		this.mifidTipoCliente = mifidTipoCliente;
	}
	public String getMifidIndServicio() {
		return mifidIndServicio;
	}
	public void setMifidIndServicio(String mifidIndServicio) {
		this.mifidIndServicio = mifidIndServicio;
	}
	public String getMifidIndEnvio() {
		return mifidIndEnvio;
	}
	public void setMifidIndEnvio(String mifidIndEnvio) {
		this.mifidIndEnvio = mifidIndEnvio;
	}
	public String getMifidIndForzaje() {
		return mifidIndForzaje;
	}
	public void setMifidIndForzaje(String mifidIndForzaje) {
		this.mifidIndForzaje = mifidIndForzaje;
	}
	public String getMifidNombreOrdenante() {
		return mifidNombreOrdenante;
	}
	public void setMifidNombreOrdenante(String mifidNombreOrdenante) {
		this.mifidNombreOrdenante = mifidNombreOrdenante;
	}
	public String getMifidApellido1Ord() {
		return mifidApellido1Ord;
	}
	public void setMifidApellido1Ord(String mifidApellido1Ord) {
		this.mifidApellido1Ord = mifidApellido1Ord;
	}
	public String getMifidApellido2Ord() {
		return mifidApellido2Ord;
	}
	public void setMifidApellido2Ord(String mifidApellido2Ord) {
		this.mifidApellido2Ord = mifidApellido2Ord;
	}
	public String getMifidContrapartidaOrd() {
		return mifidContrapartidaOrd;
	}
	public void setMifidContrapartidaOrd(String mifidContrapartidaOrd) {
		this.mifidContrapartidaOrd = mifidContrapartidaOrd;
	}
	public String getSibisAplicacion() {
		return sibisAplicacion;
	}
	public void setSibisAplicacion(String sibisAplicacion) {
		this.sibisAplicacion = sibisAplicacion;
	}
	public String getSibisEntidad() {
		return sibisEntidad;
	}
	public void setSibisEntidad(String sibisEntidad) {
		this.sibisEntidad = sibisEntidad;
	}
	public String getSibisOficina() {
		return sibisOficina;
	}
	public void setSibisOficina(String sibisOficina) {
		this.sibisOficina = sibisOficina;
	}
	public String getSibisCodigoContrato() {
		return sibisCodigoContrato;
	}
	public void setSibisCodigoContrato(String sibisCodigoContrato) {
		this.sibisCodigoContrato = sibisCodigoContrato;
	}
	public String getCdsTipoIdentif() {
		return cdsTipoIdentif;
	}
	public void setCdsTipoIdentif(String cdsTipoIdentif) {
		this.cdsTipoIdentif = cdsTipoIdentif;
	}
	public String getCdsIdentificador() {
		return cdsIdentificador;
	}
	public void setCdsIdentificador(String cdsIdentificador) {
		this.cdsIdentificador = cdsIdentificador;
	}
	public String getCdsIdentifEvento() {
		return cdsIdentifEvento;
	}
	public void setCdsIdentifEvento(String cdsIdentifEvento) {
		this.cdsIdentifEvento = cdsIdentifEvento;
	}
	public String getCdsNivelCalif() {
		return cdsNivelCalif;
	}
	public void setCdsNivelCalif(String cdsNivelCalif) {
		this.cdsNivelCalif = cdsNivelCalif;
	}
	public String getCdsTasaRecup() {
		return cdsTasaRecup;
	}
	public void setCdsTasaRecup(String cdsTasaRecup) {
		this.cdsTasaRecup = cdsTasaRecup;
	}
	public String getCdsEntregableValorable() {
		return cdsEntregableValorable;
	}
	public void setCdsEntregableValorable(String cdsEntregableValorable) {
		this.cdsEntregableValorable = cdsEntregableValorable;
	}
	public String getDatosGestionClaveBDU() {
		return datosGestionClaveBDU;
	}
	public void setDatosGestionClaveBDU(String datosGestionClaveBDU) {
		this.datosGestionClaveBDU = datosGestionClaveBDU;
	}
	public String getDatosGestionOficina() {
		return datosGestionOficina;
	}
	public void setDatosGestionOficina(String datosGestionOficina) {
		this.datosGestionOficina = datosGestionOficina;
	}
	public String getDatosGestionImporte() {
		return datosGestionImporte;
	}
	public void setDatosGestionImporte(String datosGestionImporte) {
		this.datosGestionImporte = datosGestionImporte;
	}
	public String getDatosGestionCancelacion() {
		return datosGestionCancelacion;
	}
	public void setDatosGestionCancelacion(String datosGestionCancelacion) {
		this.datosGestionCancelacion = datosGestionCancelacion;
	}
	public String getDatosGestionDivisa() {
		return datosGestionDivisa;
	}
	public void setDatosGestionDivisa(String datosGestionDivisa) {
		this.datosGestionDivisa = datosGestionDivisa;
	}
	public String getDatosGestionImputacion() {
		return datosGestionImputacion;
	}
	public void setDatosGestionImputacion(String datosGestionImputacion) {
		this.datosGestionImputacion = datosGestionImputacion;
	}
	public String getDatosGestionImporteSales() {
		return datosGestionImporteSales;
	}
	public void setDatosGestionImporteSales(String datosGestionImporteSales) {
		this.datosGestionImporteSales = datosGestionImporteSales;
	}
	public String getDatosGestionCancelacionSales() {
		return datosGestionCancelacionSales;
	}
	public void setDatosGestionCancelacionSales(String datosGestionCancelacionSales) {
		this.datosGestionCancelacionSales = datosGestionCancelacionSales;
	}
	public String getDatosGestionImporteTotal() {
		return datosGestionImporteTotal;
	}
	public void setDatosGestionImporteTotal(String datosGestionImporteTotal) {
		this.datosGestionImporteTotal = datosGestionImporteTotal;
	}
	public String getDatosGestionCancelacionTotal() {
		return datosGestionCancelacionTotal;
	}
	public void setDatosGestionCancelacionTotal(String datosGestionCancelacionTotal) {
		this.datosGestionCancelacionTotal = datosGestionCancelacionTotal;
	}

	
}