package com.atosorigin.deri.adminoper.boletas.tramos.action;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import javax.persistence.EntityManager;

import org.jboss.seam.ScopeType;
import org.jboss.seam.annotations.In;
import org.jboss.seam.annotations.Name;
import org.jboss.seam.annotations.Out;
import org.jboss.seam.annotations.Scope;
import org.jboss.seam.core.Conversation;
import org.jboss.seam.core.ResourceBundle;
import org.jboss.seam.international.StatusMessage.Severity;
import org.jboss.seam.security.Credentials;
import org.jboss.seam.security.Identity;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.BeansException;

import com.atosorigin.common.action.GenericAction;
import com.atosorigin.common.constantes.Constantes;
import com.atosorigin.common.formvalidator.FormValidator;
import com.atosorigin.common.utils.GenericUtils;
import com.atosorigin.deri.adminoper.boletas.action.TramosTableComponent;
import com.atosorigin.deri.adminoper.boletas.action.BoletasAction.BoletasStates;
import com.atosorigin.deri.adminoper.boletas.action.BoletasAction.PagoCobroType;
import com.atosorigin.deri.adminoper.boletas.business.BoletasBo;
import com.atosorigin.deri.adminoper.boletas.tramos.action.TramosAction.TramosTipoAccion;
import com.atosorigin.deri.adminoper.boletas.tramos.business.AltaTramosBo;
import com.atosorigin.deri.adminoper.boletas.tramos.business.TramosBo;
import com.atosorigin.deri.common.dbLock.DbLockService;
import com.atosorigin.deri.dao.mercado.DescripcionFormula;
import com.atosorigin.deri.model.adminoper.DescripcionHisttramSigno;
import com.atosorigin.deri.model.adminoper.DescripcionTipoOperacionHistderi;
import com.atosorigin.deri.model.gestionoperaciones.HistoricoOperacion;
import com.atosorigin.deri.model.gestionoperaciones.HistoricoOperacionId;
import com.atosorigin.deri.model.mercado.DescripcionIndice;
import com.atosorigin.deri.model.mercado.HistoricoIndice;
import com.atosorigin.deri.model.mercado.HistoricoIndiceId;
import com.atosorigin.deri.model.mercado.HistoricoTramos;
import com.atosorigin.deri.model.mercado.HistoricoTramosId;
import com.atosorigin.deri.model.mercado.IndicesPantalla;
import com.atosorigin.deri.model.mercado.Subyacente;
import com.atosorigin.deri.model.mercado.TiposPorIndice;
import com.atosorigin.deri.model.mercado.TramosTable;
import com.atosorigin.deri.model.murex.ProductoCatalogo;
import com.atosorigin.deri.util.EntityUtil;

/**
 * Clase action listener para el caso de uso de consulta operaciones asociadas
 * en datos de mercado.
 */
@Name("altaTramosAction")
@Scope(ScopeType.CONVERSATION)
@FormValidator
public class AltaTramosAction extends GenericAction {

	@In("#{altaTramosBo}")
	protected AltaTramosBo altaTramosBo;

	@In("#{tramosBo}")
	protected TramosBo tramosBo;

	@In(value = "historicoOperacion")
	protected HistoricoOperacion historicoOperacion;

	@In(required=false)
	HistoricoOperacionId historicoOperacionBloqueadoId;
	
	@In(value = "tramoSelnou")
	protected HistoricoTramos tramoOriginal;
	/** Objecte amb el que treballem (copia del tramoOriginal */
	private HistoricoTramos historicoTramos; 
	
	@Out(value = "historicTramosForIndice", required = false)
	protected HistoricoTramos historicTramosForIndice;
	
	@In
	private BoletasStates boletaState;

	@In(value = "dbLockService", create = true)
	private DbLockService dbLockService;

	@In(required=false)
	private String forcedReturnView;
	
	@In
	private EntityManager entityManager;

	@In("#{boletasBo}")
	protected BoletasBo boletasBo;
	
	@In(required = false)
	@Out(required=false)
	private TramosTipoAccion tipoAccion;

	@In(required = false, value="PagoCobroType")
	private PagoCobroType pataOpcion;
	
	@In(required=false)
	protected TramosTableComponent tramosTableComponent;
	
    @In Credentials credentials;
    
    @Out
    private String source="";
    
    @Out
    protected List<IndicesPantalla> indicesPantallaList = new ArrayList<IndicesPantalla>();
	
	private Set<String> cjtoDisabled = new HashSet<String>();

	private Set <HistoricoIndice> listaIndicesViejo;
	
	// TODO
	private Boolean primeraVez = true;
	
	/** Copies del camps del tramo original per comparar */
	private BigDecimal importeViejo;
	private Date fecFinTramoViejo;
	private Date fecIniTramoViejo;
	private Date fechaValorDelTipoViejo;
	private Date fechaInformarImporteViejo;
	private DescripcionTipoOperacionHistderi tipoOperacionViejo;
	private String conceptoViejo;
	private String tipoConceptoViejo;
	private Long codigoLiquidacionViejo;
	private Date complementoCodLiquiViejo;
	private BigDecimal nominalParaCalculoViejo;
	private BigDecimal importeCapitalizadoViejo; 
	private BigDecimal porcentajeTipoInteresViejo;
	private BigDecimal porcentajePeriodifIntArrearsViejo; 
	private DescripcionFormula codigoFormulaViejo;

	private Boolean pasaValidacion = false;
	private boolean sinErrores = true;
	private StringBuilder mensajesValidacion = new StringBuilder();
	private boolean salirDirecto;
	
	/** Camps de pantalla */
	private Boolean irregular;
	private Boolean indCapitalizacion;
	private DescripcionHisttramSigno signo;
	private Boolean nivelBarreraRequired = false;
	private String labelPorcentajeTipoInteres ="Tipo Interes";
	private String labelStrikeCFC ="Strike";	
	private BigDecimal importeTotal;
	
	List<DescripcionFormula> listaFormula = new ArrayList();

	public void init() {
		try {
			if (primeraVez) {
				// Copia de l'historico tramos original
				historicoTramos = new HistoricoTramos();
				BeanUtils.copyProperties(tramoOriginal,historicoTramos);	

				if (tipoAccion == TramosTipoAccion.CONSULTA){
					//TODO Comprobar que funcione.
					listaIndicesViejo = new HashSet<HistoricoIndice>(tramoOriginal.getHistoricoIndices());
					if (historicoTramos.getCodigoFormula() !=null) {
						obtencionIndicesTramo(listaIndicesViejo);
					}
				}

				if (tipoAccion == TramosTipoAccion.MODIFICA){
					// Si ens modifiquen creem una nova ID
					//Nueva ID
					HistoricoTramosId id = new HistoricoTramosId();
					id.setFechaFinTramo(new Date(tramoOriginal.getId().getFechaFinTramo().getTime()));
					id.setFechaInicioTramo(new Date(tramoOriginal.getId().getFechaInicioTramo().getTime()));
					id.setHistoricoOperacion(historicoOperacion);
					id.setTipoConcepto(new String(tramoOriginal.getId().getTipoConcepto()));
					id.setConcepto(tramoOriginal.getId().getConcepto());
					id.setTipoOperacion(tramoOriginal.getId().getTipoOperacion());
					historicoTramos.setId(id);
						
					//Eliminamos Coleccion
					listaIndicesViejo = new HashSet<HistoricoIndice>(tramoOriginal.getHistoricoIndices());
					historicoTramos.setHistoricoIndices(null);	
					if (historicoTramos.getCodigoFormula() !=null) {
						obtencionIndicesTramo(listaIndicesViejo);
					}
					// Detach del la còpia
					tramosBo.detach(historicoTramos);
				}
				
				importeViejo = historicoTramos.getImporteOperacion();
				fecFinTramoViejo = historicoTramos.getId().getFechaFinTramo();
				fecIniTramoViejo = historicoTramos.getId().getFechaInicioTramo();
				fechaValorDelTipoViejo = historicoTramos.getFechaValorDelTipo();
				fechaInformarImporteViejo = historicoTramos.getFechaInformarImporte();
				tipoOperacionViejo = historicoTramos.getId().getTipoOperacion();
				conceptoViejo = historicoTramos.getId().getConcepto();
				tipoConceptoViejo = historicoTramos.getId().getTipoConcepto();
				codigoLiquidacionViejo = historicoTramos.getCodigoLiquidacion();
				complementoCodLiquiViejo = historicoTramos.getComplementoCodLiqui();
				nominalParaCalculoViejo = historicoTramos.getNominalParaCalculo();
				importeCapitalizadoViejo = historicoTramos.getImporteCapitalizado(); 
				porcentajeTipoInteresViejo = historicoTramos.getPorcentajeTipoInteres();
				porcentajePeriodifIntArrearsViejo = historicoTramos.getPorcentajePeriodifIntArrears();
				codigoFormulaViejo = historicoTramos.getCodigoFormula();
				
				if ("S".equals(historicoTramos.getIndicadorTramoCapitaliza()))
					setIndCapitalizacion(true);
				else	setIndCapitalizacion(false);
				
				if ("S".equals(historicoTramos.getIndicadorTramoIrregular()))
					setIrregular(true);
				else	setIrregular(false);
				
				//Inicializar Signo
				if (historicoTramos.getSpreadOperacion() != null){
					if (BigDecimal.ZERO.compareTo(historicoTramos.getSpreadOperacion()) <= 0) signo = altaTramosBo.obtenerSigno("+");
					else signo = altaTramosBo.obtenerSigno("-");
				} else signo = altaTramosBo.obtenerSigno("+");
				
				
				if ((historicoTramos.getImporteCapitalizado()!=null) && (historicoTramos.getImporteOperacion()!=null))
					importeTotal = historicoTramos.getImporteCapitalizado().add(historicoTramos.getImporteOperacion());
				else if (historicoTramos.getImporteCapitalizado()==null) {
					if (historicoTramos.getImporteOperacion()==null) importeTotal = BigDecimal.ZERO;
					else importeTotal = historicoTramos.getImporteOperacion();
				}else importeTotal = historicoTramos.getImporteCapitalizado(); 
				
				primeraVez = false;
			
			
			if ((tipoAccion != TramosTipoAccion.CONSULTA)){
				String proteccion = tablaProteccion();
				if ("IRS_A".equals(proteccion)) {
					 Set<String> IRS_A = new HashSet<String>(Arrays.asList(
							 new String[] {"divisaLiquidacion","strikeCFC","nivelBarrera"}));
					 cjtoDisabled = IRS_A;
					 valoresDefectoIRSA();
				}else if ("IRS_M".equals(proteccion)) {
					 Set<String> IRS_M = new HashSet<String>(Arrays.asList(
							 new String[] {"divisaLiquidacion","strikeCFC","nivelBarrera","nominalParaCalculo",
									 		"nominalAmortizado","porcentajePeriodifIntArrears"}));
					 cjtoDisabled = IRS_M;
					 valoresDefectoIRSM();
				}else if ("IRS_C".equals(proteccion)) {
					 Set<String> IRS_C = new HashSet<String>(Arrays.asList(
							 new String[] {"divisaLiquidacion","strikeCFC","nivelBarrera","baseDeCalculoDias","signo","spreadOperacion",
									 "codigoFormula","porcentajeTipoInteres","btnIndices","nominalAmortizado","porcentajePeriodifIntArrears",
									 "fechaValorDelTipo"}));
					 cjtoDisabled = IRS_C;
					 valoresDefectoIRSC();
					 
				}else if ("CFC_A".equals(proteccion)) {
					 Set<String> CFC_A = new HashSet<String>(Arrays.asList(
							  new String[] {"divisaLiquidacion","strikeCFC","nivelBarrera"}));
					 cjtoDisabled = CFC_A;
					 valoresDefectoCFCA();
				}else if ("CFC_M".equals(proteccion)) {
					 Set<String> CFC_M = new HashSet<String>(Arrays.asList(
							 new String[] {"divisaLiquidacion","strikeCFC","nivelBarrera","nominalParaCalculo",
									 		"nominalAmortizado","porcentajePeriodifIntArrears"}));
					 cjtoDisabled = CFC_M;
					 valoresDefectoCFCM();
				}else if ("FWD_A".equals(proteccion)) {
					 Set<String> FWD_A = new HashSet<String>(Arrays.asList(
							 new String[] {"indicadorTramoIrregular","divisaLiquidacion","baseDeCalculoDias","nivelBarrera",
									 		"diferenciaDias","signo","spreadOperacion","indicadorTramoCapitaliza","importeCapitalizado"}));
					 cjtoDisabled = FWD_A;
					 valoresDefectoFWDA();
				}else if ("FWD_M".equals(proteccion)) {
					 Set<String> FWD_M = new HashSet<String>(Arrays.asList(
							 new String[] {"indicadorTramoIrregular","divisaLiquidacion","strikeCFC","baseDeCalculoDias",
									 	   "nivelBarrera","diferenciaDias","signo","spreadOperacion","nominalAmortizado",
									 	   "indicadorTramoCapitaliza","importeCapitalizado"}));
					 cjtoDisabled = FWD_M;
					 valoresDefectoFWDM();
				}else if ("OPL".equals(proteccion)) {
					 Set<String> OPL = new HashSet<String>(Arrays.asList(
						     new String[] {"indicadorTipindiv", "tipoOperacion",
//					    		 	   "fechaInicioTramo", "fechaFinTramo", 
						    		 	   "indicadorTramoIrregular","divisaLiquidacion","porcentajePeriodifIntArrears",
						    		 	   "strikeCFC","nivelBarrera","diferenciaDias","signo","spreadOperacion","nominalAmortizado",
						    		 	   "indicadorTramoCapitaliza","importeCapitalizado","codigoFormula","nominalParaCalculo"}));
					 cjtoDisabled = OPL;
					 valoresDefectoOPL();
				}else if ("OPE".equals(proteccion)) {
					 Set<String> OPE = new HashSet<String>(Arrays.asList(
						     new String[] {"indicadorTipindiv","fechaValorDelTipo",
//					    		 "fechaInicioTramo", "fechaFinTramo",
						    		 		"tipoOperacion","indicadorTramoIrregular","divisaLiquidacion","porcentajePeriodifIntArrears",
						    		 		"porcentajeTipoInteres","strikeCFC","nivelBarrera","diferenciaDias","signo","spreadOperacion",
						    		 		"nominalParaCalculo","nominalAmortizado","baseDeCalculoDias","indicadorTramoCapitaliza",
						    		 		"importeCapitalizado","codigoFormula"}));
					 cjtoDisabled = OPE;
					 valoresDefectoOPE();
				}
				
				
				if (historicoTramos.getIndicadorTipindiv()!=null &&  "F".equals(historicoTramos.getIndicadorTipindiv().getCodigo())) {
					 valoresDefectoTramoFijo();
				}
			
				if (	historicoTramos.getId().getHistoricoOperacion().getProductoCatalogo()!=null &&
						historicoTramos.getId().getHistoricoOperacion().getProductoCatalogo().getProdtrat()!=null &&
						"S".equalsIgnoreCase(historicoTramos.getId().getHistoricoOperacion().getProductoCatalogo().getProdtrat().getTratge02())){
					
					cjtoDisabled.remove("numeroTitulos");
					cjtoDisabled.remove("strikeCFC");
					
				}else{
					cjtoDisabled.add("numeroTitulos");
				}
//			modificarClase();
				//Deshabilitar Ratefactor
				if (historicoTramos.getIndicadorTipindiv()==null || !"V".equals(historicoTramos.getIndicadorTipindiv().getCodigo())
						|| !atributo43001(historicoOperacion.getProductoCatalogo(),historicoTramos.getCodigoFormula())) {
					cjtoDisabled.add("ratefactor");
					historicoTramos.setRateFactor(null);
				}
					
			
			}

			//SMM 04/10/2016 Permitir modif Nominal en Pant. Tramos	
			cjtoDisabled.remove("nominalParaCalculo");
			
			//Incidencia 1148
			if ((tipoAccion == TramosTipoAccion.MODIFICA || tipoAccion == TramosTipoAccion.CONSULTA) && 
				historicoTramos.getIndicadorTipindiv()!=null && 
				("F".equals(historicoTramos.getIndicadorTipindiv().getCodigo())) ){
				
				cjtoDisabled.add("btnIndices");
				
			}
			
			
			}
			if (tipoAccion == TramosTipoAccion.CREA){
				retriveFormulaList(null);	
			}else {
				String tipoFormTramo = tramosBo.obtenerTipoformTramo(historicoTramos.getCodigoFormula(), 
						historicoOperacion.getProductoCatalogo());			

				retriveFormulaList(tipoFormTramo);	
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			statusMessages.add(Severity.ERROR,e.toString());
			salirDirecto();
		}
		
	}

	private boolean atributo43001(ProductoCatalogo producat,DescripcionFormula  codigoFormula) {
		return altaTramosBo.comprobarAtributo43001(producat,codigoFormula);
	}

	private void valoresDefectoTramoFijo() {
		cjtoDisabled.add("fechaValorDelTipo");
	}

	/**
	 * Mètode que es crida quan canviem el combo de formula o ens cliquen al botó de "Indices"
	 * 
	 * @param source: "B" si és des de botó. "F" si és canvi de formula.
	 * @return success si tot ha anat OK
	 */
	public String indicesTramos(String source) {
		if (historicoTramos.getId().getFechaInicioTramo() == null
				|| historicoTramos.getId().getFechaFinTramo() == null
				|| (((pataOpcion != null && pataOpcion.getCodigo().equals(historicoTramos
						.getId().getTipoOperacion().getCodigo())) || (pataOpcion == null && "J"
						.equals(historicoTramos.getId().getTipoOperacion()
								.getCodigo())))
						&& historicoTramos.getFechaValorDelTipo() == null && historicoTramos
						.getFechaLiquidacion() == null)
				|| historicoTramos.getCodigoFormula() == null
				|| historicoTramos.getId().getTipoOperacion() == null) {
			statusMessages.add(Severity.ERROR,
					"#{messages['Tramos.error.CamposNoInformados']}");
			return null;
		} else {
//			FLM: 1334, modificacion, no estaba en el dt, pero la hacemos igualmente
			if (historicoTramos.getIndicadorTipindiv() != null && "V".equals(historicoTramos.getIndicadorTipindiv().getCodigo()) &&
					!"OPC".equals(historicoTramos.getId().getTipoConcepto())) {
				if ( historicoTramos.getFechaValorDelTipo()==null ) {
					statusMessages.add(Severity.ERROR,
					"#{messages['Tramos.error.CamposNoInformados']}");
					return null;					
				}				
			}
			
			historicTramosForIndice = historicoTramos;
			this.source = source;
			return Constantes.CONSTANTE_SUCCESS;
		}
	}

	/**
	 * Prepara el indicePantallaList per mostrar a la pantalla de Indices.
	 * Pasa de indices de BDD a indices de pantalla.
	 * 
	 * @param listaIndices
	 */
	private void obtencionIndicesTramo(Set<HistoricoIndice> listaIndices) {
		boolean existeValor;
		for (HistoricoIndice indice : listaIndices) {

			IndicesPantalla h = new IndicesPantalla();
			
			h.setLiteralIndice(indice.getId().getLiteralIndice());
			h.setFechaInicio(indice.getFechaInicio());
			h.setFechaFin(indice.getFechaFin());

			if (indice.getCodigoIndice()!=null){
				h.setDescripcionCorta(indice.getCodigoIndice().getDescripcionCorta());
				h.setDescripcionLarga(indice.getCodigoIndice().getDescripcionLarga());
				h.setCodigoSubyacente(indice.getCodigoIndice().getCodigo());
			}
			
			List<DescripcionIndice> descripcionIndice =altaTramosBo.obtenerDescripcionIndice(historicoTramos.getCodigoFormula().getCodigoFormula(), indice.getId().getLiteralIndice());
			if (descripcionIndice!=null && descripcionIndice.size()> 0){
				h.setTipoFechaInicio(descripcionIndice.get(0).getTipoFechaInicio());
				h.setTipoFechaFin(descripcionIndice.get(0).getTipoFechaFin());
			}

			existeValor = false;

			if (indice!=null && indice.getCodigoIndice()!=null && indice.getCodigoIndice().getTiposPorIndices()!=null && indice.getFechaInicio() != null 
					&& indice.getFechaFin()!=null 
					&& indice.getFechaInicio().compareTo(indice.getFechaFin()) == 0){
				for (TiposPorIndice tipos : indice.getCodigoIndice().getTiposPorIndices()) {
					if ((tipos.getId().getFaplicacion() !=null && tipos.getId().getFaplicacion().compareTo(indice.getFechaInicio()) == 0) &&
						"VA".equalsIgnoreCase(tipos.getEstadoindice())	){
							existeValor = true;
							h.setTipoValorIndice(tipos.getTipoValorIndice());
							indicesPantallaList.add(h);
					}
				}
			}

			if (!existeValor) {
				h.setTipoValorIndice(null);
				indicesPantallaList.add(h);	
			}					
			
			
		}
	}

	/**
	 * Acció del botó aceptar
	 */
	public void altaAceptar() {
		mensajesValidacion.delete(0,mensajesValidacion.length());
		pasaValidacion = false;
		
		if (irregular) {
			historicoTramos.setIndicadorTramoIrregular("S");
		} else {
			historicoTramos.setIndicadorTramoIrregular("N");
		}
		if (indCapitalizacion) {
			historicoTramos.setIndicadorTramoCapitaliza("S");
		} else {
			historicoTramos.setIndicadorTramoCapitaliza("N");
		}
		
		aceptarTramoIntereses();
		primeraVez = true;
	}

	public void retriveFormulaList(String tipoForm) {
		listaFormula = altaTramosBo.buildFormulaSelect(historicoOperacion.getProductoCatalogo(),tipoForm);
	}

	public void salir() {

//		Conversation conversacion = Conversation.instance();
//		//Volvemos a la anterior conversación
//		while (!"Mantenimiento de Operaciones".equalsIgnoreCase(conversacion.getDescription())){
//
//			conversacion.redirectToParent();
//			conversacion = Conversation.instance();
//				
//		}
//				
		
		primeraVez = true;
	}

	public boolean fieldDisabled() {
		if ((tipoAccion == TramosTipoAccion.CONSULTA)) {
			// System.out.println("*******historicoTramos.getIndicadorTramoCapitaliza()--------"+historicoTramos.getIndicadorTramoCapitaliza());
			if (historicoTramos.getIndicadorTramoCapitaliza().equalsIgnoreCase(
					"S")) {
				// System.out.println("*******Gonna make it True indCapitalizacion--------");
				indCapitalizacion = true;
			}
			if (historicoTramos.getIndicadorTramoIrregular().equalsIgnoreCase(
					"S")) {
				irregular = true;
			}
			return true;
		}
		return false;
	}

	/**
	 * Acció que s'executa en el onchage dels camp de dates (fInicio, fFin)
	 */
	public void modificarInicioFinTramo() {
		if ((TramosTipoAccion.CREA.equals(tipoAccion)
				&& historicoTramos.getId().getFechaInicioTramo() != null
				&& historicoTramos.getId().getFechaFinTramo() != null && !historicoTramos
				.getId().getFechaFinTramo().before(
						historicoTramos.getId().getFechaInicioTramo()))
				|| (TramosTipoAccion.MODIFICA.equals(tipoAccion)
						&& historicoTramos.getId().getFechaInicioTramo() != null
						&& historicoTramos.getId().getFechaFinTramo() != null
						&& !historicoTramos.getId().getFechaFinTramo().before(
								historicoTramos.getId().getFechaInicioTramo()) && (fecIniTramoViejo != historicoTramos
						.getId().getFechaInicioTramo() || fecFinTramoViejo != historicoTramos
						.getId().getFechaFinTramo()))) {

			
			historicoTramos.setDiferenciaDias(altaTramosBo.calcularDiasTramo(
					historicoTramos.getBaseDeCalculoDias()!=null?historicoTramos.getBaseDeCalculoDias().getCodigo():"",
					historicoTramos.getId().getFechaInicioTramo(),
					historicoTramos.getId().getFechaFinTramo()));
			String accion = "";
			if (TramosTipoAccion.CREA.equals(tipoAccion))
				accion = "A";
			if (historicoTramos.getId().getTipoOperacion()!=null && historicoTramos.getId().getTipoOperacion().getCodigo()!=null){
				if (altaTramosBo.verificarPeriodosSolapados(historicoTramos,
						fecIniTramoViejo, fecFinTramoViejo, accion))
					statusMessages.add(Severity.WARN,
							"#{messages['Tramos.mensaje.TramosSolapados']}");
			}

		}

	}

	/**
	 * Acció que s'executa quan canvien el tipo de operacion
	 */
	public void tipoOperacionChange(){
		//Incidencia 1549 02/06/2010
		//Siempre que se va a llamar InformarDatosDefectoINT deshabilitamos campo Amortización.
		cjtoDisabled.add("nominalAmortizado");
		
		if (altaTramosBo.informarDatosDefectoINT(historicoTramos, signo, pataOpcion==null?null:pataOpcion.getCodigo()))
			activarONoBarreraStrike();

		tratarTipoPeriodificacion(historicoTramos);
		modificarInicioFinTramo();
		cambiarNominalINT();

	}
	
	/**
	 * Acció que s'executa quan ens canvien el combo de clase
	 */
	public void modificarClase() {
		if (historicoTramos.getIndicadorTipindiv()!=null && "F".equals(historicoTramos.getIndicadorTipindiv().getCodigo())) {
			historicoTramos.setCodigoFormula(null);
			historicoTramos.setFechaValorDelTipo(null);
			historicoTramos.setRateFactor(null);
			cjtoDisabled.add("codigoFormula");
			cjtoDisabled.add("fechaValorDelTipo");
			cjtoDisabled.add("btnIndices");
			cjtoDisabled.add("ratefactor");
			
			cjtoDisabled.remove("porcentajeTipoInteres");
			cjtoDisabled.remove("baseDeCalculoDias");
			cjtoDisabled.remove("nominalAmortizado");
			cjtoDisabled.remove("spreadOperacion");
			cjtoDisabled.remove("signo");
			cjtoDisabled.remove("porcentajePeriodifIntArrears");
			cjtoDisabled.remove("nominalParaCalculo");
			
		} else if (historicoTramos.getIndicadorTipindiv()!=null &&  "C".equals(historicoTramos.getIndicadorTipindiv()
				.getCodigo())) {
			historicoTramos.setCodigoFormula(null);
			historicoTramos.setFechaValorDelTipo(null);
			historicoTramos.setRateFactor(null);
//			cjtoDisabled.add("fechaValorDelTipo");
			cjtoDisabled.add("codigoFormula");
			cjtoDisabled.add("fechaValorDelTipo");
			cjtoDisabled.add("btnIndices");
			cjtoDisabled.add("porcentajeTipoInteres");
			cjtoDisabled.add("baseDeCalculoDias");
			cjtoDisabled.add("nominalAmortizado");
			cjtoDisabled.add("spreadOperacion");
			cjtoDisabled.add("signo");
			cjtoDisabled.add("porcentajePeriodifIntArrears");
			cjtoDisabled.add("ratefactor");
			cjtoDisabled.remove("nominalParaCalculo");

		}else if (historicoTramos.getIndicadorTipindiv()!=null && "V".equals(historicoTramos.getIndicadorTipindiv()
				.getCodigo())) {

			cjtoDisabled.remove("codigoFormula");
			cjtoDisabled.remove("fechaValorDelTipo");
			cjtoDisabled.remove("btnIndices");
			cjtoDisabled.remove("porcentajeTipoInteres");
			cjtoDisabled.remove("baseDeCalculoDias");
			cjtoDisabled.remove("nominalAmortizado");
			cjtoDisabled.remove("spreadOperacion");
			cjtoDisabled.remove("signo");
			cjtoDisabled.remove("porcentajePeriodifIntArrears");
			cjtoDisabled.remove("nominalParaCalculo");
			
			if (atributo43001(historicoOperacion.getProductoCatalogo(),historicoTramos.getCodigoFormula())){
				cjtoDisabled.remove("ratefactor");	
			}
			
		}

		//Incidencia 1549 02/06/2010
		//Siempre que se va a llamar InformarDatosDefectoINT deshabilitamos campo Amortización.
		cjtoDisabled.add("nominalAmortizado");
		if (altaTramosBo.informarDatosDefectoINT(historicoTramos, signo, pataOpcion==null?null:pataOpcion.getCodigo()))
			activarONoBarreraStrike();

		tratarTipoPeriodificacion(historicoTramos);
		modificarInicioFinTramo();
		cambiarNominalINT();

	}

	public DescripcionHisttramSigno getSigno() {
		return signo;
	}

	public void setSigno(DescripcionHisttramSigno signo) {
		this.signo = signo;
	}

	public void cambiarNominalINT() {
 
		if (historicoTramos.getNominalParaCalculo() != null
				&& nominalParaCalculoViejo != null)
			if (historicoTramos.getNominalParaCalculo().compareTo(
					nominalParaCalculoViejo) != 0) {
				if (historicoTramos.getId().getFechaInicioTramo() == null) {
					historicoTramos.setNominalParaCalculo(null);
					statusMessages.add(Severity.ERROR,
							"#{messages['Tramos.error.InformarFechaInicio']}");
				} else if (historicoTramos.getId().getTipoOperacion() == null) {
					historicoTramos.setNominalParaCalculo(null);
					statusMessages
							.add(Severity.ERROR,
									"#{messages['Tramos.error.InformarTipoOperacion']}");
				} else {
					historicoTramos.setNominalAmortizado(altaTramosBo
							.obtenerNominalAmortizado(historicoTramos));
				}

			}
	}

	public void tratarTipoPeriodificacion(HistoricoTramos detalle) {

		if (detalle.getIndicadorTipindiv() != null && ("C".equals(detalle.getIndicadorTipindiv().getCodigo())
				|| "F".equals(detalle.getIndicadorTipindiv().getCodigo()))) {
			cjtoDisabled.add("porcentajePeriodifIntArrears");
			detalle.setPorcentajePeriodifIntArrears(detalle
					.getPorcentajeTipoInteres());
		}
		if (detalle.getIndicadorTipindiv() != null && "V".equals(detalle.getIndicadorTipindiv().getCodigo())) {
			if (detalle.getId().getTipoOperacion() != null) {
				if ("P".equals(detalle.getId().getTipoOperacion().getCodigo())) {
					if (detalle.getId().getHistoricoOperacion()
							.getIndFixingInArrearsPago())
						cjtoDisabled.remove("porcentajePeriodifIntArrears"); 
					else {
						cjtoDisabled.add("porcentajePeriodifIntArrears");
						detalle.setPorcentajePeriodifIntArrears(detalle
								.getPorcentajeTipoInteres());
					}
				} else if (detalle.getId().getHistoricoOperacion()
						.getIndFixingInArrearsRecibo())
					cjtoDisabled.remove("porcentajePeriodifIntArrears"); 
				else {
					cjtoDisabled.add("porcentajePeriodifIntArrears");
					detalle.setPorcentajePeriodifIntArrears(detalle
							.getPorcentajeTipoInteres());
				}
			} else
				cjtoDisabled.remove("porcentajePeriodifIntArrears"); 
		}
		if (detalle.getIndicadorTipindiv() == null)
			cjtoDisabled.remove("porcentajePeriodifIntArrears"); 

	}

	public String tablaProteccion() {

		if (tipoAccion == TramosTipoAccion.CREA) {

			if ("CFC".equals(historicoOperacion.getProductoCatalogo()
					.getModelpro().getModelpro())) {
				 return "CFC_A";
			} else if ("FWD".equals(historicoOperacion.getProductoCatalogo()
					.getModelpro().getModelpro())) {
				 return "FWD_A"; 
			} else if ("OPC".equals(historicoOperacion.getProductoCatalogo()
					.getModelpro().getModelpro())
					|| "EQU".equals(historicoOperacion.getProductoCatalogo()
							.getModelpro().getModelpro())
					|| "DED".equals(historicoOperacion.getProductoCatalogo()
							.getModelpro().getModelpro())
					|| "SWP".equals(historicoOperacion.getProductoCatalogo()
							.getModelpro().getModelpro())) {
				return "IRS_A";
			}

		} else if (tipoAccion == TramosTipoAccion.MODIFICA) {
			String tipoFormTramo = tramosBo.obtenerTipoformTramo(historicoTramos.getCodigoFormula(), 
					historicoOperacion.getProductoCatalogo());			

			if ("F".equals(historicoTramos.getIndicadorTipindiv().getCodigo())) {
				return "IRS_M";
			} else if ("C".equals(historicoTramos.getIndicadorTipindiv().getCodigo())) {
				return "IRS_C";
			} else if ("OPE".equals(tipoFormTramo)) {
				 return "OPE";
			} else if ("OPL".equals(tipoFormTramo)) {
				 return "OPL";
			} else if ("LIQ".equals(tipoFormTramo)) {

				if ("CFC".equals(historicoOperacion.getProductoCatalogo()
						.getModelpro().getModelpro())) {
					 return "CFC_M";
				} else if ("FWD".equals(historicoOperacion
						.getProductoCatalogo().getModelpro().getModelpro())) {
					 return "FWD_M"; 
				} else if ("OPC".equals(historicoOperacion
						.getProductoCatalogo().getModelpro().getModelpro())
						|| "EQU".equals(historicoOperacion
								.getProductoCatalogo().getModelpro()
								.getModelpro())
						|| "DED".equals(historicoOperacion
								.getProductoCatalogo().getModelpro()
								.getModelpro())
						|| "SWP".equals(historicoOperacion
								.getProductoCatalogo().getModelpro()
								.getModelpro())) {
					return "IRS_M";
				}

			}
		}
		statusMessages.add(Severity.WARN, "#{messages['Tramos.EsquemaProteccion']}");
		return "CFC_M";
	}

	public void porcentajeTipoInteresChange() {
		if (isFieldDisabled("porcentajePeriodifIntArrears")){
			historicoTramos.setPorcentajePeriodifIntArrears(historicoTramos
					.getPorcentajeTipoInteres());
		}else if (historicoTramos.getPorcentajeTipoInteres()!=null && 
				!historicoTramos.getPorcentajeTipoInteres().equals(BigDecimal.ZERO)){
			historicoTramos.setPorcentajePeriodifIntArrears(historicoTramos
					.getPorcentajeTipoInteres());
		}
			
	}

	public void baseDeCalculoDiasChange() {
		if (historicoTramos.getBaseDeCalculoDias()!=null){
			historicoTramos.setDiferenciaDias(altaTramosBo.calcularDiasTramo(
					historicoTramos.getBaseDeCalculoDias().getCodigo(),
					historicoTramos.getId().getFechaInicioTramo(), historicoTramos
							.getId().getFechaFinTramo()));
		}else{
			historicoTramos.setDiferenciaDias(altaTramosBo.calcularDiasTramo(
					"000",historicoTramos.getId().getFechaInicioTramo(), historicoTramos.getId().getFechaFinTramo()));
		}
		
	}

	public void nominalParaCalculoChange() {
		cambiarNominalINT();
	}

	public void strikeCFCChange(){
		calcularNuevoCapital();
	}
	public void nTitulosChange(){
		calcularNuevoCapital();
	}
	
	public void calcularNuevoCapital(){
	
		if ("FWD".equals(historicoOperacion.getProductoCatalogo()
				.getModelpro().getModelpro())  &&
				historicoOperacion.getProductoCatalogo().getProdtrat()!=null &&
				"S".equalsIgnoreCase(historicoOperacion.getProductoCatalogo().getProdtrat().getTratge02()) &&
				historicoTramos.getStrikeCFC()!=null && !BigDecimal.ZERO.equals(historicoTramos.getStrikeCFC()) &&
				historicoTramos.getNumeroTitulos()!=null && !BigDecimal.ZERO.equals(historicoTramos.getNumeroTitulos()) &&
				(historicoTramos.getNominalParaCalculo()== null || BigDecimal.ZERO.equals(historicoTramos.getNominalParaCalculo()))
			) {
			
			historicoTramos.setNominalParaCalculo(historicoTramos.getStrikeCFC().multiply(historicoTramos.getNumeroTitulos()));
			cambiarNominalINT();
		}
		
	}
	
	
	public void signoChange() {
		if (signo != null) {
			if ("+".equals(signo.getCodigo())) {
				if (historicoTramos.getSpreadOperacion().compareTo(
						BigDecimal.ZERO) == -1)
					historicoTramos.setSpreadOperacion(historicoTramos
							.getSpreadOperacion().negate());
			}
			if ("-".equals(signo.getCodigo())) {
				if (historicoTramos.getSpreadOperacion().compareTo(
						BigDecimal.ZERO) == 1)
					historicoTramos.setSpreadOperacion(historicoTramos
							.getSpreadOperacion().negate());
			}
		}
	}

	public void importeOperacionChange() {
		if ((historicoTramos.getImporteCapitalizado()!=null) && (historicoTramos.getImporteOperacion()!=null))
			importeTotal = historicoTramos.getImporteCapitalizado().add(historicoTramos.getImporteOperacion());
		else if (historicoTramos.getImporteCapitalizado()==null) {
			if (historicoTramos.getImporteOperacion()==null) importeTotal = BigDecimal.ZERO;
			else importeTotal = historicoTramos.getImporteOperacion();
		}else importeTotal = historicoTramos.getImporteCapitalizado(); 
		
		if ((tipoAccion == TramosTipoAccion.MODIFICA && importeViejo == null && historicoTramos.getImporteOperacion() !=null) ||
				(tipoAccion == TramosTipoAccion.MODIFICA  && importeViejo != null 
				&& !importeViejo.equals(historicoTramos.getImporteOperacion()))) {

			
			if (historicoTramos.getCodigoLiquidacion() != null
					&& !(historicoTramos.getCodigoLiquidacion() != 0L)) {
				if ("VA".equals(tramosBo.estadoLiquidacionTramo(historicoTramos
						.getCodigoLiquidacion(), historicoTramos
						.getComplementoCodLiqui())))
					statusMessages
							.add(Severity.WARN,
									"#{messages['Tramos.mensaje.LiquidacionValidada']}");
			}
		}
	}

	public void divisaTramoChange() {
		historicoTramos.setDivisaLiquidacion(historicoTramos.getDivisaTramo()
				.getId());
	}

	public void indCapitalizacionChange() {
		if (indCapitalizacion) {
			if (altaTramosBo.obtenerNumeroTramosPosteriores(historicoTramos) == 0L)
				indCapitalizacion = false;
		}
	}

	public void importeCapitalizadoChange() {
		if ((historicoTramos.getImporteCapitalizado()!=null) && (historicoTramos.getImporteOperacion()!=null))
			importeTotal = historicoTramos.getImporteCapitalizado().add(historicoTramos.getImporteOperacion());
		else if (historicoTramos.getImporteCapitalizado()==null) {
			if (historicoTramos.getImporteOperacion()==null) importeTotal = BigDecimal.ZERO;
			else importeTotal = historicoTramos.getImporteOperacion();
		}else importeTotal = historicoTramos.getImporteCapitalizado(); 
		
		if (tipoAccion == TramosTipoAccion.MODIFICA
				&& (((importeCapitalizadoViejo != null) && (!importeCapitalizadoViejo
						.equals(historicoTramos.getImporteCapitalizado()))) || (importeCapitalizadoViejo == null && historicoTramos
						.getImporteCapitalizado() != null))) {

			if (historicoTramos.getCodigoLiquidacion() != null
					&& !(historicoTramos.getCodigoLiquidacion() != 0L)) {
				if ("VA".equals(tramosBo.estadoLiquidacionTramo(historicoTramos
						.getCodigoLiquidacion(), historicoTramos
						.getComplementoCodLiqui())))
					statusMessages
							.add(Severity.WARN,
									"#{messages['Tramos.mensaje.LiquidacionValidada']}");
			}
		}

	}

	public HistoricoTramos getHistoricoTramos() {
		return historicoTramos;
	}

	public void setHistoricoTramos(HistoricoTramos historicoTramos) {
		this.historicoTramos = historicoTramos;
	}

	public BigDecimal getImporteTotal() {
		return importeTotal;
	}

	public void setImporteTotal(BigDecimal importeTotal) {
		this.importeTotal = importeTotal;
	}

	public boolean isRenderedSalir() {
		return (tipoAccion == TramosTipoAccion.CONSULTA);

	}

	public String aceptar() {
		if ((!pasaValidacion) && sinErrores) {
			altaAceptar();
			return Constantes.CONSTANTE_SUCCESS;
		}
		return Constantes.CADENA_VACIA;

	}

	public boolean aceptarValidator(){

		mensajesValidacion.delete(0,mensajesValidacion.length());
		pasaValidacion = false;
		sinErrores = true;
		

		
		//Sustitucion Required
		if (historicoTramos.getId().getTipoOperacion() == null){
			sinErrores = false;
			pasaValidacion = false;
			statusMessages.addFromResourceBundle(Severity.ERROR, "Tramos.error.CampoObligatorio","Tipo Operacion");
		}

		if (historicoTramos.getId().getFechaInicioTramo() == null){
			sinErrores = false;
			pasaValidacion = false;
			statusMessages.addFromResourceBundle(Severity.ERROR, "Tramos.error.CampoObligatorio","Fecha Inicio Valor");
		}
		
		if (historicoTramos.getId().getFechaFinTramo() == null){
			sinErrores = false;
			pasaValidacion = false;
			statusMessages.addFromResourceBundle(Severity.ERROR, "Tramos.error.CampoObligatorio","Fecha Fin Valor");
		}
		if (historicoTramos.getFechaValorDelTipo() == null && !cjtoDisabled.contains("fechaValorDelTipo") &&
			(( historicoTramos.getIndicadorTipindiv() != null && "V".equals(historicoTramos.getIndicadorTipindiv().getCodigo())) ||
			   historicoTramos.getIndicadorTipindiv() == null )){
			sinErrores = false;
			pasaValidacion = false;
			statusMessages.addFromResourceBundle(Severity.ERROR, "Tramos.error.CampoObligatorio","Fecha Fixing Valor");
		}
		if (historicoTramos.getFechaLiquidacion() == null){
			sinErrores = false;
			pasaValidacion = false;
			statusMessages.addFromResourceBundle(Severity.ERROR, "Tramos.error.CampoObligatorio","Fecha Liq Valor");
		}


		if (historicoTramos.getIndicadorTipindiv() == null ){
			sinErrores = false;
			pasaValidacion = false;
			statusMessages.addFromResourceBundle(Severity.ERROR, "Tramos.error.CampoObligatorio","Clase Valor");
		}
		if (historicoTramos.getDivisaLiquidacion() == null){
			sinErrores = false;
			pasaValidacion = false;
			statusMessages.addFromResourceBundle(Severity.ERROR, "Tramos.error.CampoObligatorio","Div Liq Valor");
		}
		if (historicoTramos.getDivisaTramo() == null){
			sinErrores = false;
			pasaValidacion = false;
			statusMessages.addFromResourceBundle(Severity.ERROR, "Tramos.error.CampoObligatorio","Div Tramo Valor");
		}
		if (historicoTramos.getNivelBarrera() == null && nivelBarreraRequired){
			sinErrores = false;
			pasaValidacion = false;
			statusMessages.addFromResourceBundle(Severity.ERROR, "Tramos.error.CampoObligatorio","Nivel Barrera");
		}
		
		//Miramos si se ha cambiado la clave y si el nuevo registro se ha modificado.
		if (tipoAccion == TramosTipoAccion.CREA || compararTramoViejo(historicoTramos)) {

			HistoricoTramosId idExistente = new HistoricoTramosId();
			HistoricoTramos  existente = new HistoricoTramos();

			idExistente.setHistoricoOperacion(historicoOperacion);
			idExistente.setTipoConcepto(new String(historicoTramos.getId().getTipoConcepto()!=null?historicoTramos.getId().getTipoConcepto():"INT"));
			idExistente.setFechaFinTramo(historicoTramos.getId().getFechaFinTramo());
			idExistente.setFechaInicioTramo(historicoTramos.getId().getFechaInicioTramo());
			idExistente.setConcepto(new String("INT"));
			idExistente.setTipoOperacion(historicoTramos.getId().getTipoOperacion());
			
			existente = altaTramosBo.cargar(idExistente);
			if (existente  != null){
				sinErrores = false;
				pasaValidacion = false;
				statusMessages.add(Severity.ERROR, "#{messages['Tramos.error.TramoExistente']}");
			}
		}
		
		//Fin validaciones Required 
		
		if (tipoAccion == TramosTipoAccion.MODIFICA) {
			if ( ((((importeCapitalizadoViejo != null ) && 
					(!importeCapitalizadoViejo.equals(historicoTramos.getImporteCapitalizado()))) ||
					(importeCapitalizadoViejo == null && historicoTramos.getImporteCapitalizado()!= null )) ||
					(((porcentajeTipoInteresViejo != null ) && 
					(!porcentajeTipoInteresViejo.equals(historicoTramos.getPorcentajeTipoInteres()))) ||
					(porcentajeTipoInteresViejo == null && historicoTramos.getPorcentajeTipoInteres()!= null ))) &&
					(historicoTramos.getFechaLiquidacion().compareTo(altaTramosBo.obtenerFechaSistema()) < 0)
					
			){
				mensajesValidacion.append(ResourceBundle.instance().getString("Tramos.mensaje.CambiosNoReflejados"));
				pasaValidacion = true;
				statusMessages.add(Severity.WARN, "#{messages['Tramos.mensaje.CambiosNoReflejados']}");	
			}

		}
		
		if (indCapitalizacion) {
			if (altaTramosBo.obtenerNumeroTramosPosteriores(historicoTramos) == 0L) {
			statusMessages.add(Severity.ERROR, "#{messages['Tramos.error.UltimoTramo']}");
			sinErrores = false;
			pasaValidacion = false;}
		}
		
		if ((historicoTramos.getId().getFechaInicioTramo() != null && historicoTramos.getId().getFechaFinTramo() != null) && 
		(historicoTramos.getId().getFechaInicioTramo().compareTo(historicoTramos.getId().getFechaFinTramo()) > 0 )) {
			statusMessages.add(Severity.ERROR, "#{messages['Tramos.error.FechasErroneas']}");
			sinErrores = false;
			pasaValidacion = false;
		}

		if ((tipoAccion == TramosTipoAccion.CREA && irregular && ( altaTramosBo.numeroTramosIrregularesAlta(historicoTramos) == 0L)) ||
		    (tipoAccion == TramosTipoAccion.CONSULTA && irregular && ( altaTramosBo.numeroTramosIrregularesModificacion(historicoTramos) == 0L))){
			sinErrores = false;
			pasaValidacion = false;
			if ("P".equals(historicoTramos.getId().getTipoOperacion().getCodigo()))
				statusMessages.add(Severity.ERROR, "#{messages['Tramos.error.TramoIrregularPago']}");
			else if ("R".equals(historicoTramos.getId().getTipoOperacion().getCodigo()))
				statusMessages.add(Severity.ERROR, "#{messages['Tramos.error.TramoIrregularCobro']}");
		}
			 
		if (historicoTramos.getFechaValorDelTipo() == null && !"OPC".equals(historicoTramos.getId().getTipoConcepto()) && 
			historicoTramos.getIndicadorTipindiv() != null && "V".equals(historicoTramos.getIndicadorTipindiv().getCodigo())	){
			sinErrores = false;
			pasaValidacion = false;
			statusMessages.add(Severity.ERROR, "#{messages['Tramos.error.FechaFixing']}");
		}
			
		if (historicoTramos.getSpreadOperacion() != null && signo == null){
			sinErrores = false;
			pasaValidacion = false;
			statusMessages.add(Severity.ERROR, "#{messages['Tramos.error.SignoNoInformado']}");
		}
		
		if (historicoTramos.getNominalParaCalculo() == null && !isFieldDisabled("nominalParaCalculo")){ 
			sinErrores = false;
			pasaValidacion = false;
			statusMessages.add(Severity.ERROR, "#{messages['Tramos.error.CapitalNoInformado']}");			
		}
		 
		if (historicoTramos.getCodigoFormula() == null && historicoTramos.getIndicadorTipindiv()!=null &&
		"V".equals(historicoTramos.getIndicadorTipindiv().getCodigo())	){
			sinErrores = false;
			pasaValidacion = false;
			statusMessages.add(Severity.ERROR, "#{messages['Tramos.error.FormulaNoInformada']}");
		}


//		Set<HistoricoIndice> listIndices = indicesPantallaToHistoricoIndices();
//		historicoTramos.setHistoricoIndices(listIndices);
		//FLM: este mensaje no es claro, lo que quiere decir es que el indice no esta informado
		if (historicoTramos.getIndicadorTipindiv() !=null &&
				"V".equals(historicoTramos.getIndicadorTipindiv().getCodigo()) && 
				!altaTramosBo.informadasVariablesFormula(indicesPantallaList)){
				sinErrores = false;
				pasaValidacion = false;
				statusMessages.add(Severity.ERROR, "#{messages['Tramos.error.VariablesNoInformadas']}");
		}
		 
		if (!"OPC".equals(historicoTramos.getId().getTipoConcepto()) && checkPorcentajeTipoInteresErroneo()){
			sinErrores = false;
			pasaValidacion = false;
			statusMessages.add(Severity.ERROR, "#{messages['Tramos.error.TipoInteresErroneo']}");
			}
		
		 
		 if (tipoAccion == TramosTipoAccion.CREA){
		 		if 	(altaTramosBo.numeroRegistrosDuplicados(historicoTramos) > 0) 
		 		{
				sinErrores = false;
				pasaValidacion = false;
				statusMessages.add(Severity.ERROR, "#{messages['Tramos.error.TramoExistente']}");
				}			 
		 }
		 
		 if (tipoAccion == TramosTipoAccion.MODIFICA  &&
			(fecIniTramoViejo != historicoTramos.getId().getFechaInicioTramo() || 
					fecFinTramoViejo != historicoTramos.getId().getFechaFinTramo())){
		 		if 	(altaTramosBo.numeroRegistrosDuplicados(historicoTramos) > 0) 
		 		{
				sinErrores = false;pasaValidacion = false;
				statusMessages.add(Severity.ERROR, "#{messages['Tramos.error.TramoExistente']}");
				}			 
		 }

		 
		 String estadoLiquidacion = tramosBo.estadoLiquidacionTramo(historicoTramos.getCodigoLiquidacion(), 
					historicoTramos.getComplementoCodLiqui());
		 
		 if (tipoAccion == TramosTipoAccion.MODIFICA  && (((importeViejo != null) && 
			(!importeViejo.equals(historicoTramos.getImporteOperacion()))) || 
			(importeViejo == null && historicoTramos.getImporteOperacion() != null))) {
			 
//				if ("VA".equals(tramosBo.estadoLiquidacionTramo(historicoTramos.getCodigoLiquidacion(), 
//						historicoTramos.getComplementoCodLiqui()))){
					
				if ("VA".equals(estadoLiquidacion)){
					
					if (sinErrores) pasaValidacion = true;
					mensajesValidacion.append(ResourceBundle.instance().getString("Tramos.mensaje.LiquidacionValidada"));
					statusMessages.add(Severity.WARN,"#{messages['Tramos.mensaje.LiquidacionValidada']}");
				}	
		 
//				if ("LI".equals(tramosBo.estadoLiquidacionTramo(historicoTramos.getCodigoLiquidacion(), 
//						historicoTramos.getComplementoCodLiqui()))){

				if ("LI".equals(estadoLiquidacion)){
					
					if (sinErrores) pasaValidacion = true;
					mensajesValidacion.append(ResourceBundle.instance().getString("Tramos.mensaje.LiquidacionLiquidada"));
					statusMessages.add(Severity.WARN,"#{messages['Tramos.mensaje.LiquidacionLiquidada']}");
				}

				if ("EN".equals(estadoLiquidacion)){
					
					if (sinErrores) pasaValidacion = true;
					mensajesValidacion.append(ResourceBundle.instance().getString("Tramos.mensaje.LiquidacionEnviada"));
					statusMessages.add(Severity.WARN,"#{messages['Tramos.mensaje.LiquidacionEnviada']}");
				}

					
		 
		 }
		 
		 if (historicoTramos.getFechaValorDelTipo() != null && fechaValorDelTipoViejo != null && 
				 historicoTramos.getFechaValorDelTipo().compareTo(fechaValorDelTipoViejo) != 0 &&
				 altaTramosBo.obtenerFechaSistema().compareTo(historicoTramos.getFechaValorDelTipo()) < 0){

//			if ("VA".equals(tramosBo.estadoLiquidacionTramo(historicoTramos.getCodigoLiquidacion(), 
//					historicoTramos.getComplementoCodLiqui()))){

			if ("VA".equals(estadoLiquidacion)){

				if (sinErrores) pasaValidacion = true;
				mensajesValidacion.append(ResourceBundle.instance().getString("Tramos.mensaje.LiquidacionValidada"));
				statusMessages.add(Severity.WARN,"#{messages['Tramos.mensaje.LiquidacionValidada']}");				
			}


//			if ("LI".equals(tramosBo.estadoLiquidacionTramo(historicoTramos.getCodigoLiquidacion(), 
//					historicoTramos.getComplementoCodLiqui()))){

	 
			if ("LI".equals(estadoLiquidacion)){
				if (sinErrores) pasaValidacion = true;
				mensajesValidacion.append(ResourceBundle.instance().getString("Tramos.mensaje.LiquidacionLiquidada"));
				statusMessages.add(Severity.WARN,"#{messages['Tramos.mensaje.LiquidacionLiquidada']}");
			}

			if ("EN".equals(estadoLiquidacion)){
				if (sinErrores) pasaValidacion = true;
				mensajesValidacion.append(ResourceBundle.instance().getString("Tramos.mensaje.LiquidacionEnviada"));
				statusMessages.add(Severity.WARN,"#{messages['Tramos.mensaje.LiquidacionEnviada']}");
			}				
	 
		 }		

		if ((!pasaValidacion) && sinErrores) return true;
		else if (pasaValidacion) {
			mensajesValidacion.append("\nEsta Seguro que desea grabar?"); 
			return true;
		}
		return false;
	}

	private Boolean checkPorcentajeTipoInteresErroneo() {
		BigDecimal porcentajeTipoInteres = historicoTramos.getPorcentajeTipoInteres();
		BigDecimal porcentajePeriodifIntArrears = historicoTramos.getPorcentajePeriodifIntArrears();
		if(porcentajeTipoInteres == null && porcentajePeriodifIntArrears == null){
			return false;
		}
		if(porcentajeTipoInteres != null && porcentajePeriodifIntArrears == null){
			return true;
//			return !porcentajeTipoInteres.equals(BigDecimal.ZERO);			
		}	
		if(porcentajeTipoInteres == null && porcentajePeriodifIntArrears != null){
			return porcentajePeriodifIntArrears.equals(BigDecimal.ZERO);   
		}	
		if(porcentajeTipoInteres != null && porcentajePeriodifIntArrears != null){
			if (porcentajeTipoInteres.equals(BigDecimal.ZERO)) {
				return false;
			}else{
				return 
//				!porcentajeTipoInteres.equals(porcentajePeriodifIntArrears)
						!(porcentajeTipoInteres.compareTo(porcentajePeriodifIntArrears)==0);
			}
		}	
		return false;
	}

	public Set<String> getCjtoDisabled() {
		return cjtoDisabled;
	}

	public void setCjtoDisabled(Set<String> cjtoDisabled) {
		this.cjtoDisabled = cjtoDisabled;
	}

	

	public boolean isButtonDisabled(String campo) {
		if (tipoAccion == TramosTipoAccion.CONSULTA && !"btnIndices".equals(campo)) return true;
		if (cjtoDisabled.contains(campo)) return true;
		else return false;
	}
	
	public boolean isFieldDisabled(String campo) {
		if (tipoAccion == TramosTipoAccion.CONSULTA) return true;

		if (cjtoDisabled.contains(campo)) return true;
		else return false;
	}

	private void valoresDefectoIRSA() {
		if (historicoTramos.getDivisaTramo() != null)
		historicoTramos.setDivisaLiquidacion(historicoTramos.getDivisaTramo().getId());
		historicoTramos.setStrikeCFC(BigDecimal.ZERO);
		historicoTramos.setNivelBarrera(BigDecimal.ZERO);
	}


	private void valoresDefectoIRSM() {

		if (historicoTramos.getId().getHistoricoOperacion().getIndFixingInArrearsPago() || 
				historicoTramos.getId().getHistoricoOperacion().getIndFixingInArrearsRecibo()){
			cjtoDisabled.remove("porcentajePeriodifIntArrears"); 
		}else{
			historicoTramos.setPorcentajePeriodifIntArrears(historicoTramos.getPorcentajeTipoInteres());	
		}
			

		if (historicoTramos.getId()!=null && historicoTramos.getId().getTipoOperacion()!=null){
			if ("P".equals(historicoTramos.getId().getTipoOperacion().getCodigo()) && historicoTramos.getId().getHistoricoOperacion().getTipoAmortizacionPago() != null && "L".equals(historicoTramos.getId().getHistoricoOperacion().getTipoAmortizacionPago().getCodigo())){
				cjtoDisabled.remove("nominalParaCalculo");
			}
	  
			if ("R".equals(historicoTramos.getId().getTipoOperacion().getCodigo()) && historicoTramos.getId().getHistoricoOperacion().getTipoAmortizacionRecibo() != null && "L".equals(historicoTramos.getId().getHistoricoOperacion().getTipoAmortizacionRecibo().getCodigo())) {
				cjtoDisabled.remove("nominalParaCalculo");
			}
		}	
	}


	private void valoresDefectoIRSC() {
	
		historicoTramos.setCodigoFormula(null);
		historicoTramos.setFechaValorDelTipo(null);
	
		if (!historicoTramos.getId().getHistoricoOperacion().getIndFixingInArrearsPago() && 
				!historicoTramos.getId().getHistoricoOperacion().getIndFixingInArrearsRecibo()){

			historicoTramos.setPorcentajePeriodifIntArrears(historicoTramos.getPorcentajeTipoInteres());	
		}
	}

	
	private void valoresDefectoCFCA() {
		if (historicoTramos.getDivisaTramo()!=null){
			historicoTramos.setDivisaLiquidacion(historicoTramos.getDivisaTramo().getId());	
		}
		if (historicoTramos.getId()!=null && historicoTramos.getId().getTipoOperacion()!=null && historicoTramos.getIndicadorTipindiv()!=null){
			if (!"C".equals(historicoTramos.getIndicadorTipindiv().getCodigo())){
				if ("P".equals(historicoTramos.getId().getTipoOperacion().getCodigo()) && (historicoTramos.getId().getHistoricoOperacion().getIndPagoTipoFijoCreciente())){			
					cjtoDisabled.remove("strikeCFC");
					cjtoDisabled.remove("nivelBarrera");
				}
				if ("R".equals(historicoTramos.getId().getTipoOperacion().getCodigo()) && (historicoTramos.getId().getHistoricoOperacion().getIndReciboTipoFijoCreciente())){
					cjtoDisabled.remove("strikeCFC");
					cjtoDisabled.remove("nivelBarrera");
				}
			}
		}
	}
	
	private void valoresDefectoCFCM() {

		if (historicoTramos.getId().getHistoricoOperacion().getIndFixingInArrearsPago() || 
				historicoTramos.getId().getHistoricoOperacion().getIndFixingInArrearsRecibo()){
			cjtoDisabled.remove("porcentajePeriodifIntArrears"); 
		}else{
			historicoTramos.setPorcentajePeriodifIntArrears(historicoTramos.getPorcentajeTipoInteres());	
		}
			
		
		if (historicoTramos.getId()!=null && historicoTramos.getId().getTipoOperacion()!=null && historicoTramos.getIndicadorTipindiv()!=null){
			if (!"C".equals(historicoTramos.getIndicadorTipindiv().getCodigo())){
				if ("P".equals(historicoTramos.getId().getTipoOperacion().getCodigo()) && (historicoTramos.getId().getHistoricoOperacion().getIndPagoTipoFijoCreciente())){			
					cjtoDisabled.remove("strikeCFC");
					String IDOBLOPC = altaTramosBo.obtenerIDOBLOPCBarreraCFC(historicoTramos.getId().getHistoricoOperacion().getProductoCatalogo(),  
							historicoTramos.getCodigoFormula().getCodigoFormula().intValue());
					if ("N".equals(IDOBLOPC)){
						cjtoDisabled.remove("nivelBarrera"); 
						setNivelBarreraRequired(false);	
					}
						
					if ("S".equals(IDOBLOPC)){
						cjtoDisabled.remove("nivelBarrera");
						setNivelBarreraRequired(true);
					}
				}
				if ("R".equals(historicoTramos.getId().getTipoOperacion().getCodigo()) && (historicoTramos.getId().getHistoricoOperacion().getIndReciboTipoFijoCreciente())){
					cjtoDisabled.remove("strikeCFC");
					String IDOBLOPC = altaTramosBo.obtenerIDOBLOPCBarreraCFC(historicoTramos.getId().getHistoricoOperacion().getProductoCatalogo(),  
							historicoTramos.getCodigoFormula().getCodigoFormula().intValue());
					if ("N".equals(IDOBLOPC)) { 
						cjtoDisabled.remove("nivelBarrera"); 
						setNivelBarreraRequired(false);
					}
					if ("S".equals(IDOBLOPC)) {
						cjtoDisabled.remove("nivelBarrera"); 
						setNivelBarreraRequired(true);
						}
				}
			}
		}

		if (historicoTramos.getId()!=null && historicoTramos.getId().getTipoOperacion()!=null){
			if ("P".equals(historicoTramos.getId().getTipoOperacion().getCodigo()) && historicoTramos.getId().getHistoricoOperacion().getTipoAmortizacionPago() != null && "L".equals(historicoTramos.getId().getHistoricoOperacion().getTipoAmortizacionPago().getCodigo())){
				cjtoDisabled.remove("nominalParaCalculo");
			}
	  
			if ("R".equals(historicoTramos.getId().getTipoOperacion().getCodigo()) && historicoTramos.getId().getHistoricoOperacion().getTipoAmortizacionRecibo() != null && "L".equals(historicoTramos.getId().getHistoricoOperacion().getTipoAmortizacionRecibo().getCodigo())) {
				cjtoDisabled.remove("nominalParaCalculo");
			}
		}
	}		

	private void valoresDefectoFWDA() {
		if (historicoTramos.getDivisaTramo()!=null){
			historicoTramos.setDivisaLiquidacion(historicoTramos.getDivisaTramo().getId());	
		}
		
		historicoTramos.setIndicadorTramoIrregular("N");
		setIrregular(false);
		setLabelPorcentajeTipoInteres("Precio Final");
		setLabelStrikeCFC("Precio Inicial");
		historicoTramos.setNivelBarrera(BigDecimal.ZERO);
		historicoTramos.setBaseDeCalculoDias(altaTramosBo.recuperarBaseCalculo("000"));
		historicoTramos.setIndicadorTramoCapitaliza("N");
		setIndCapitalizacion(false);
	}

	private void valoresDefectoOPE() {
		if (historicoTramos.getId()!=null && historicoTramos.getId().getTipoOperacion()!=null){
			if ("P".equals(historicoTramos.getId().getTipoOperacion().getCodigo()) && historicoTramos.getId().getHistoricoOperacion().getTipoAmortizacionPago() != null && "L".equals(historicoTramos.getId().getHistoricoOperacion().getTipoAmortizacionPago().getCodigo())){
				cjtoDisabled.remove("nominalParaCalculo");
			}
	  
			if ("R".equals(historicoTramos.getId().getTipoOperacion().getCodigo()) && historicoTramos.getId().getHistoricoOperacion().getTipoAmortizacionRecibo() != null && "L".equals(historicoTramos.getId().getHistoricoOperacion().getTipoAmortizacionRecibo().getCodigo())) {
				cjtoDisabled.remove("nominalParaCalculo");
			}
		}
	}
	
	private void valoresDefectoOPL() {
		if (historicoTramos.getId()!=null && historicoTramos.getId().getTipoOperacion()!=null){
			if ("P".equals(historicoTramos.getId().getTipoOperacion().getCodigo()) && historicoTramos.getId().getHistoricoOperacion().getTipoAmortizacionPago() != null && "L".equals(historicoTramos.getId().getHistoricoOperacion().getTipoAmortizacionPago().getCodigo())){
				cjtoDisabled.remove("nominalParaCalculo");
			}
	  
			if ("R".equals(historicoTramos.getId().getTipoOperacion().getCodigo()) && historicoTramos.getId().getHistoricoOperacion().getTipoAmortizacionRecibo() != null && "L".equals(historicoTramos.getId().getHistoricoOperacion().getTipoAmortizacionRecibo().getCodigo())) {
				cjtoDisabled.remove("nominalParaCalculo");
			}
		}
	}
	
	private void valoresDefectoFWDM() {
		setLabelPorcentajeTipoInteres("Precio Final");
		setLabelStrikeCFC("Precio Inicial");
	}

	public Boolean getNivelBarreraRequired() {
		return nivelBarreraRequired;
	}

	public void setNivelBarreraRequired(Boolean nivelBarreraRequired) {
		this.nivelBarreraRequired = nivelBarreraRequired;
	}

	public String getLabelPorcentajeTipoInteres() {
		return labelPorcentajeTipoInteres;
	}

	public void setLabelPorcentajeTipoInteres(String labelPorcentajeTipoInteres) {
		this.labelPorcentajeTipoInteres = labelPorcentajeTipoInteres;
	}

	public String getLabelStrikeCFC() {
		return labelStrikeCFC;
	}

	public void setLabelStrikeCFC(String labelStrikeCFC) {
		this.labelStrikeCFC = labelStrikeCFC;
	}

	
	public void activarONoBarreraStrike() {
			if (("P".equals(historicoTramos.getId().getTipoOperacion().getCodigo()) && (historicoTramos.getId().getHistoricoOperacion().getIndPagoTipoFijoCreciente())) ||
				("R".equals(historicoTramos.getId().getTipoOperacion().getCodigo()) && (historicoTramos.getId().getHistoricoOperacion().getIndReciboTipoFijoCreciente())))	
					{			
				cjtoDisabled.remove("strikeCFC");
				cjtoDisabled.remove("nivelBarrera");
			}else{
				cjtoDisabled.add("strikeCFC");
				cjtoDisabled.add("nivelBarrera");
			}
		}

	



	public void aceptarTramoIntereses() {

		// Passem de indices pantalla a indices BDD
		Set<HistoricoIndice> listIndices = indicesPantallaToHistoricoIndices();
		historicoTramos.setHistoricoIndices(listIndices);

		// TODO
		if (historicoTramos.getCodigoFormula() !=null) {
			if (historicoTramos.getFechaValorDelTipo() !=null && 
					(!historicoTramos.getFechaValorDelTipo().equals(fechaValorDelTipoViejo))){
				altaTramosBo.actualizarVariablesFormula("FECFIXIN", historicoTramos);	
			}else if  (!historicoTramos.getId().getFechaInicioTramo().equals(fecIniTramoViejo)){
				altaTramosBo.actualizarVariablesFormula("FECINITR", historicoTramos);
			}
		
		}
		
		//SMM 09/04/2015  No admet valors nuls
		if (GenericUtils.isNullOrBlank(historicoTramos.getImporteOperacion())) {
			
			historicoTramos.setImporteOperacion(BigDecimal.ZERO);
			if (GenericUtils.isNullOrBlank(importeViejo)) {
				importeViejo = historicoTramos.getImporteOperacion();
			}
		}
		
		// Tenim l'objecte preparat per gravar a BDD
		if (tipoAccion == TramosTipoAccion.CREA) {
			altaTramosBo.insertarHisttramINT(historicoTramos,credentials.getUsername());
			tramoOriginal = historicoTramos;
		}
		
		if (tipoAccion == TramosTipoAccion.MODIFICA) {
			
			if (historicoTramos.getCodigoFormula() == null && codigoFormulaViejo != null){
				historicoTramos.setHistoricoIndices(new HashSet<HistoricoIndice>(0));
			}
			
			historicoTramos.setFechaCalculoLiquidacion(historicoTramos.getFechaValorDelTipo());
			if (!"V".equals(historicoTramos.getIndicadorTipindiv().getCodigo())) {
				historicoTramos.setFechaCalculoLiquidacion(altaTramosBo.ajustarFechaInf(historicoTramos.getId().getFechaInicioTramo(), 
					3, historicoTramos.getDivisaTramo()));
			}
		
			historicoTramos.setFechaInformarImporte(fechaInformarImporteViejo);

			if ((((porcentajeTipoInteresViejo != null) && 
					(!porcentajeTipoInteresViejo.equals(historicoTramos.getPorcentajeTipoInteres()))) || 
					(porcentajeTipoInteresViejo == null && historicoTramos.getPorcentajeTipoInteres() != null)) ||
					(((porcentajePeriodifIntArrearsViejo != null) && 
							(!porcentajePeriodifIntArrearsViejo.equals(historicoTramos.getPorcentajePeriodifIntArrears()))) || 
							(porcentajePeriodifIntArrearsViejo == null && historicoTramos.getPorcentajePeriodifIntArrears() != null))) {
				historicoTramos.setFechaInformarImporte(altaTramosBo.obtenerFechaSistema());
			}

			//Queremos ver si se ha cambiado algún valor de la clave que puede provocar según el select original 
			// que se modifique un registro distinto al actual.
			// Si se cumple el IF se ha cambiado alguno de los valores
			if (compararTramoViejo(historicoTramos)) {
				//Comprobamos si existe en BD
			
				HistoricoTramosId idRecuperada = new HistoricoTramosId();
				HistoricoTramos  recuperado = new HistoricoTramos();

				idRecuperada.setHistoricoOperacion(historicoOperacion);
				idRecuperada.setTipoConcepto(new String(tipoConceptoViejo));
				idRecuperada.setFechaFinTramo(fecFinTramoViejo);
				idRecuperada.setFechaInicioTramo(fecIniTramoViejo);
				idRecuperada.setConcepto(new String("INT"));
				idRecuperada.setTipoOperacion(tipoOperacionViejo);
				
				recuperado = altaTramosBo.cargar(idRecuperada);
				if (recuperado  != null){
					altaTramosBo.borrar(recuperado);
					//historicoTramos.setHistoricoIndices(listaIndices);
					altaTramosBo.insertar(historicoTramos,credentials.getUsername());
				}else{
					altaTramosBo.borrar(tramoOriginal);
					altaTramosBo.insertar(historicoTramos,credentials.getUsername());
				}
			}else {
				// No se han cambiado los valores, procedimiento normal.
				altaTramosBo.borrar(tramoOriginal);
				//historicoTramos.setHistoricoIndices(listaIndices);
				altaTramosBo.insertar(historicoTramos,credentials.getUsername());
			}
			tramoOriginal = historicoTramos;
			

		}
		

		if (((nominalParaCalculoViejo != null) && 
				(!nominalParaCalculoViejo.equals(historicoTramos.getNominalParaCalculo()))) || 
				(nominalParaCalculoViejo == null && historicoTramos.getNominalParaCalculo() != null)){

//			(NOTA: Antes de realizar la llamada a la función se deberán persistir todos los cambios 
//			realizados en histtram y al volver  se deberán recuperar los datos ya que la función 
//			modifica la tabla histtram)
			altaTramosBo.amortizaTramoAnterior(historicoTramos);
			altaTramosBo.refrescar(historicoTramos);	
			tramoOriginal = historicoTramos;
		}		
		if (tipoAccion != TramosTipoAccion.CREA){
			preparaTramosTable();	
		}
		
	
		
	}
	
	//Compara si se ha cambiado algun campo de la clave.
	private boolean compararTramoViejo(HistoricoTramos historicoTramos){
		if (((tipoOperacionViejo != null && historicoTramos.getId().getTipoOperacion() !=null &&
				!tipoOperacionViejo.getCodigo().equals(historicoTramos.getId().getTipoOperacion().getCodigo())) ||
				(tipoOperacionViejo == null && historicoTramos.getId().getTipoOperacion() !=null ) ||
				(tipoOperacionViejo != null && historicoTramos.getId().getTipoOperacion() ==null )) 
				||
				((tipoConceptoViejo != null && !tipoConceptoViejo.equals(historicoTramos.getId().getTipoConcepto())) ||
				(tipoConceptoViejo == null && historicoTramos.getId().getTipoConcepto() !=null ))
				|| (fecIniTramoViejo !=null && !fecIniTramoViejo.equals(historicoTramos.getId().getFechaInicioTramo())) 
				|| (fecFinTramoViejo !=null && !fecFinTramoViejo.equals(historicoTramos.getId().getFechaFinTramo()))
			) {
			return true;	
		}else{
			return false;
		}
	}
	
	
	
	private void preparaTramosTable() {
		if (tipoAccion == TramosTipoAccion.MODIFICA  && (((importeViejo != null) && 
			(!importeViejo.equals(historicoTramos.getImporteOperacion()))) || 
			(importeViejo == null && historicoTramos.getImporteOperacion() != null)) && 
			("LI".equals(tramosBo.estadoLiquidacionTramo(historicoTramos
						.getCodigoLiquidacion(), historicoTramos
						.getComplementoCodLiqui())))){
			 
				TramosTable	registro = new TramosTable();
				registro.setAccion("I");
				registro.setCodigoLiquidacion(historicoTramos.getCodigoLiquidacion());
				registro.setComplementoCodLiqui(historicoTramos.getComplementoCodLiqui());
				registro.setImporteOperacion(historicoTramos.getImporteOperacion());
				tramosTableComponent.getTramosTableList().add(registro);
		}
		
		if (fechaValorDelTipoViejo != null && !fechaValorDelTipoViejo.equals(historicoTramos.getFechaValorDelTipo()) && 
				historicoTramos.getFechaValorDelTipo() != null &&
				altaTramosBo.obtenerFechaSistema().compareTo(historicoTramos.getFechaValorDelTipo())< 0 &&
				historicoTramos.getCodigoLiquidacion()!=null &&
				(!"LI".equals(tramosBo.estadoLiquidacionTramo(historicoTramos
						.getCodigoLiquidacion(), historicoTramos
						.getComplementoCodLiqui())) 
						&& !"EN".equals(tramosBo.estadoLiquidacionTramo(historicoTramos
								.getCodigoLiquidacion(), historicoTramos
								.getComplementoCodLiqui()))
						&& !"VA".equals(tramosBo.estadoLiquidacionTramo(historicoTramos
								.getCodigoLiquidacion(), historicoTramos
								.getComplementoCodLiqui())))){
			
			TramosTable	registro = new TramosTable();
			registro.setAccion("M");
			registro.setCodigoLiquidacion(historicoTramos.getCodigoLiquidacion());
			registro.setComplementoCodLiqui(historicoTramos.getComplementoCodLiqui());
			tramosTableComponent.getTramosTableList().add(registro);
		}
		

		if  (fecIniTramoViejo !=null  && fecFinTramoViejo!=null && 
			((!historicoTramos.getId().getFechaInicioTramo().equals(fecIniTramoViejo)) ||
			(!historicoTramos.getId().getFechaFinTramo().equals(fecFinTramoViejo)))){
		
			TramosTable	registro = new TramosTable();
			registro.setAccion("T");

			registro.setFechaInicioTramo(fecIniTramoViejo);
			registro.setFechaFinTramo(fecFinTramoViejo);
			registro.setTipoOperacion(tipoOperacionViejo);
			registro.setConcepto(conceptoViejo);
			registro.setTipoConcepto(tipoConceptoViejo);
//			registro.setFechaInicioTramo(historicoTramos.getId().getFechaInicioTramo());
//			registro.setFechaFinTramo(historicoTramos.getId().getFechaFinTramo());
//			registro.setTipoOperacion(historicoTramos.getId().getTipoOperacion());
//			registro.setConcepto(historicoTramos.getId().getConcepto());
//			registro.setTipoConcepto(historicoTramos.getId().getTipoConcepto());
			tramosTableComponent.getTramosTableList().add(registro);
			
		}
		if (!"V".equals(historicoTramos.getIndicadorTipindiv().getCodigo()) && 
				historicoTramos.getFechaCalculoLiquidacion().compareTo(historicoOperacion.getId().getFechaTratamiento())>0
				&& !GenericUtils.isNullOrBlank(historicoTramos.getCodigoLiquidacion()))
		{
			TramosTable	registro = new TramosTable();
			registro.setAccion("M");
			registro.setCodigoLiquidacion(historicoTramos.getCodigoLiquidacion());
			registro.setComplementoCodLiqui(historicoTramos.getComplementoCodLiqui());
			tramosTableComponent.getTramosTableList().add(registro);
			
		}
			
	}

	private Set<HistoricoIndice> indicesPantallaToHistoricoIndices() {
		// Passem de indices pantalla a indices BDD
		Set<HistoricoIndice> listIndices = new HashSet<HistoricoIndice>(); 
		for (IndicesPantalla indice: indicesPantallaList) {
			HistoricoIndice hi = new HistoricoIndice();
			HistoricoIndiceId id = new HistoricoIndiceId();
			
			Subyacente obtenerDescripcionSubyacente = null;
			if(indice.getCodigoSubyacente()!=null){
				obtenerDescripcionSubyacente = altaTramosBo.obtenerDescripcionSubyacente(indice.getCodigoSubyacente());
			}
			hi.setCodigoIndice(obtenerDescripcionSubyacente);
			hi.setFechaFin(indice.getFechaFin());
			hi.setFechaInicio(indice.getFechaInicio());
			hi.setIndicNulo(null);
			hi.setProducto(historicoTramos.getProducto());
			hi.setUsuario(credentials.getUsername());
			id.setHistoricoTramos(historicoTramos);
			id.setLiteralIndice(indice.getLiteralIndice());
			hi.setId(id);
			listIndices.add(hi);
		}
		return listIndices;
	}
	
	public StringBuilder getMensajesValidacion() {
		return mensajesValidacion;
	}

	public void setMensajesValidacion(StringBuilder mensajesValidacion) {
		this.mensajesValidacion = mensajesValidacion;
	}

	public Boolean isPasaValidacion() {
		return pasaValidacion;
	}

	public void setPasaValidacion(Boolean pasaValidacion) {
		this.pasaValidacion = pasaValidacion;
	}

	public Boolean getIrregular() {
		return irregular;
	}

	public void setIrregular(Boolean irregular) {
		this.irregular = irregular;
	}

	public Boolean getIndCapitalizacion() {
		return indCapitalizacion;
	}

	public void setIndCapitalizacion(Boolean indCapitalizacion) {
		this.indCapitalizacion = indCapitalizacion;
	}

	public List<DescripcionFormula> getListaFormula() {
		return listaFormula;
	}

	public void setListaFormula(List<DescripcionFormula> listaFormula) {
		this.listaFormula = listaFormula;
	}


	public String salirDirecto(){

		if ( !BoletasStates.CONSULTA_BOLETA.equals( this.boletaState) ) {
			try {
				String result = boletasBo.salirOperacion("R", historicoOperacion, Identity.instance().getCredentials().getUsername());
				if (result != null) {
					String codigoValidacionErroneo = result;
					statusMessages.add(Severity.ERROR, "#{messages['boletas.edicion.error.salir.operacion']");
				}
				//FLM: boletas es un caso especial, si estamos en alta tenemos que saltar 2 parents quizas?
				return doCommonRedirect();
				//return doSalirRedirect();
			} finally {
				if (boletaState == BoletasStates.MODI_BOLETA) {
					dbLockService.desbloqueo(HistoricoOperacion.class, historicoOperacionBloqueadoId);
				}
			}

		} else { 
			return doCommonRedirect();
		}
		    

		
	}
	
private String doCommonRedirect() {
	
	
	if(forcedReturnView!=null){
		return doSalirRedirect();
	}
	if(boletaState==BoletasStates.ALTA_BOLETA){
		Conversation.instance().pop();
		Conversation.instance().pop();
		return "salir";
	}
	
	Conversation conversacion=Conversation.instance();
	Conversation.instance().pop();
	Conversation.instance().pop();
//	Conversation conversacion = Conversation.instance();
	//Volvemos al anterior
	conversacion.redirectToParent();
	return "";
}	

private String doSalirRedirect() {

	if ( BoletasStates.ALTA_BOLETA.equals( this.boletaState) ) {
		
    	Conversation nested =Conversation.instance();
    	Conversation.instance().pop();
    	Conversation.instance().pop();
    	Conversation.instance().pop();
    	
    	boolean dosSaltos= ( "/pages/adminoper/boletas/alta/altaOper.xhtml".equalsIgnoreCase( Conversation.instance().getViewId() ) );
    	
    
    	if(forcedReturnView!=null){
    		if(dosSaltos){
    			Conversation.instance().redirectToParent();
    			return "";
    		}else{
    			Conversation.instance().redirect();
    			return "";

    		}
		}
    	
    	nested.end(true);
    	if(EntityUtil.checkEntityExists(entityManager, historicoOperacion.getProductoCompuesto())){
    		return "/pages/gestionoperaciones/productocompuesto/mantProdCompuesto.xhtml";
    	}
		return "salir";
	} else {
		Conversation conversacion=Conversation.instance();
		Conversation.instance().pop();
		Conversation.instance().pop();
		conversacion.redirectToParent();
		return "";
	}
}

public String decidirSalir(){

	if (isSalirDirecto()) return salirDirecto(); 
	else{ 
		salir();
		return "SalirDos";
	}
	
//	return null;
	
}

public boolean isSalirDirecto() {
	return salirDirecto;
}

public void setSalirDirecto(boolean salirDirecto) {
	this.salirDirecto = salirDirecto;
}




}