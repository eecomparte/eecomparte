package com.atosorigin.deri.adminoper.boletas.tramos.action;

import java.math.BigDecimal;
import java.util.Date;

import org.jboss.seam.ScopeType;
import org.jboss.seam.annotations.In;
import org.jboss.seam.annotations.Name;
import org.jboss.seam.annotations.Scope;

import com.atosorigin.common.action.GenericAction;
import com.atosorigin.common.utils.GenericUtils;
import com.atosorigin.deri.adminoper.boletas.action.BoletasAction.BoletasStates;
import com.atosorigin.deri.adminoper.boletas.tramos.business.DatosPrimerTramoIrregularBo;
import com.atosorigin.deri.model.adminoper.DescripcionClaseInt;
import com.atosorigin.deri.model.gestionoperaciones.HistoricoOperacion;
import com.atosorigin.deri.util.ErrorMessageBoxAction;
import com.atosorigin.deri.util.FormatUtil;

/**
 * Clase action listener para el caso de uso de consulta operaciones asociadas en datos de mercado.
 */
@Name("datosPrimerTramoIrregularAction")
@Scope(ScopeType.CONVERSATION)
public class DatosPrimerTramoIrregularAction extends GenericAction {
	
	@In("#{datosPrimerTramoIrregularBo}")
	protected DatosPrimerTramoIrregularBo datosPrimerTramoIrregularBo;
	
	@In
	private HistoricoOperacion historicoOperacion;
	
	@In(required=false)
	private BoletasStates boletaState;
	
	@In
	private ErrorMessageBoxAction errorMessageBoxAction;

	@In(required=false)
	private FormatUtil formatUtil;
	
	private String cobroPago;
	
	private DescripcionClaseInt claseInt;
	private Date fInicio;
	private Date fFin;
	private Boolean interpola = false;
	private BigDecimal importeFijo;
	private BigDecimal tipoInteres;
	
	public void cargaInicial(String cobroPago) {
		this.cobroPago = cobroPago;
//SMM Incidencia 1734
		errorMessageBoxAction.setReRender("datosPrimerTramoIrregularForm,breadBoleta");
		errorMessageBoxAction.setOnComplete("");

		
		if("C".equalsIgnoreCase(cobroPago)) {
			this.claseInt =GenericUtils.nvl(historicoOperacion.getIndTipoTramoIrregularRecibo(),historicoOperacion.getIndicadorTipoRecibo());
			this.fInicio = historicoOperacion.getInicioTramoIrregularRecibo();
			this.fFin = historicoOperacion.getFinTramoIrregularRecibo();
			this.interpola = historicoOperacion.getIndInterpolaTramoIrregularRecibo();
			this.importeFijo = historicoOperacion.getCuponTramoIrregularRecibo();
			this.tipoInteres = GenericUtils.nvl(historicoOperacion.getPorcentajeTramoIrregularRecibo(),historicoOperacion.getPorcentajeTipoFijoRecibo());
		} else if ("P".equalsIgnoreCase(cobroPago)) {
			this.claseInt =  GenericUtils.nvl(historicoOperacion.getIndTipoTramoIrregularPago(),historicoOperacion.getIndicadorTipoPago());
			this.fInicio = historicoOperacion.getInicioTramoIrregularPago();
			this.fFin = historicoOperacion.getFinTramoIrregularPago();
			this.interpola = historicoOperacion.getIndInterpolaTramoIrregularPago();
			this.importeFijo = historicoOperacion.getCuponTramoIrregularPago();
			this.tipoInteres = GenericUtils.nvl(historicoOperacion.getPorcentajeTramoIrregularPago(),historicoOperacion.getPorcentajeTipoFijoPago());
		}
	}
	
	public void aceptar() {
		if("C".equalsIgnoreCase(this.cobroPago)) {
			historicoOperacion.setIndTipoTramoIrregularRecibo(this.claseInt);
			historicoOperacion.setInicioTramoIrregularRecibo(this.fInicio);
			historicoOperacion.setFinTramoIrregularRecibo(this.fFin);
			historicoOperacion.setIndInterpolaTramoIrregularRecibo(this.interpola);
			historicoOperacion.setCuponTramoIrregularRecibo(this.importeFijo);
			historicoOperacion.setPorcentajeTramoIrregularRecibo(this.tipoInteres);
		} else if ("P".equalsIgnoreCase(this.cobroPago)) {
			historicoOperacion.setIndTipoTramoIrregularPago(this.claseInt);
			historicoOperacion.setInicioTramoIrregularPago(this.fInicio);
			historicoOperacion.setFinTramoIrregularPago(this.fFin);
			historicoOperacion.setIndInterpolaTramoIrregularPago(this.interpola);
			historicoOperacion.setCuponTramoIrregularPago(this.importeFijo);
			historicoOperacion.setPorcentajeTramoIrregularPago(this.tipoInteres);
		}
		//nNo es necesario
		//datosPrimerTramoIrregularBo.saveHistoricoOperacion(historicoOperacion);
	}

	public DescripcionClaseInt getClaseInt() {
		return claseInt;
	}

	public void setClaseInt(DescripcionClaseInt claseInt) {
		this.claseInt = claseInt;
	}

	public Date getfInicio() {
		return fInicio;
	}

	public void setfInicio(Date fInicio) {
		this.fInicio = fInicio;
	}

	public Date getfFin() {
		return fFin;
	}

	public void setfFin(Date fFin) {
		this.fFin = fFin;
	}

	public Boolean getInterpola() {
		return interpola;
	}

	public void setInterpola(Boolean interpola) {
		this.interpola = interpola;
	}

	public BigDecimal getImporteFijo() {
		return importeFijo;
	}

	public void setImporteFijo(BigDecimal importeFijo) {
		this.importeFijo = importeFijo;
	}

	public BigDecimal getTipoInteres() {
		return tipoInteres;
	}

	public void setTipoInteres(BigDecimal tipoInteres) {
		this.tipoInteres = tipoInteres;
	}
	public void Salir(){
		
	}
}
