package com.atosorigin.deri.adminoper.boletas.tramos.action;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import javax.persistence.EntityManager;

import org.jboss.seam.ScopeType;
import org.jboss.seam.annotations.Factory;
import org.jboss.seam.annotations.In;
import org.jboss.seam.annotations.Name;
import org.jboss.seam.annotations.Out;
import org.jboss.seam.annotations.Scope;
import org.jboss.seam.core.Conversation;
import org.jboss.seam.core.ResourceBundle;
import org.jboss.seam.international.StatusMessage.Severity;
import org.jboss.seam.security.Credentials;
import org.jboss.seam.security.Identity;
import org.springframework.beans.BeanUtils;

import com.atosorigin.common.action.GenericAction;
import com.atosorigin.common.constantes.Constantes;
import com.atosorigin.common.formvalidator.FormValidator;
import com.atosorigin.common.utils.GenericUtils;
import com.atosorigin.deri.adminoper.boletas.action.TramosTableComponent;
import com.atosorigin.deri.adminoper.boletas.action.BoletasAction.BoletasStates;
import com.atosorigin.deri.adminoper.boletas.business.BoletasBo;
import com.atosorigin.deri.adminoper.boletas.tramos.action.TramosAction.TramosTipoAccion;
import com.atosorigin.deri.adminoper.boletas.tramos.action.TramosAction.TramosTipoTramo;
import com.atosorigin.deri.adminoper.boletas.tramos.business.AltaTramosBo;
import com.atosorigin.deri.adminoper.boletas.tramos.business.DetallePrimasBo;
import com.atosorigin.deri.adminoper.boletas.tramos.business.TramosBo;
import com.atosorigin.deri.common.dbLock.DbLockService;
import com.atosorigin.deri.model.adminoper.DescripcionTipoOperacionHistderi;
import com.atosorigin.deri.model.gestionoperaciones.HistoricoOperacion;
import com.atosorigin.deri.model.gestionoperaciones.HistoricoOperacionId;
import com.atosorigin.deri.model.mercado.HistoricoIndice;
import com.atosorigin.deri.model.mercado.HistoricoTramos;
import com.atosorigin.deri.model.mercado.HistoricoTramosId;
import com.atosorigin.deri.model.mercado.TramosTable;
import com.atosorigin.deri.model.parametrizacion.Divisa;
import com.atosorigin.deri.util.EntityUtil;

@Name("detallePrimasAction")
@Scope(ScopeType.CONVERSATION)
@FormValidator
public class DetallePrimasAction extends GenericAction {

	// private Date fechaLiquidacion;
	private String concepto;
	private Date fechaLiquidacion;
	private String divisaLiq;
	private boolean liquida;
	private boolean disabledLiquida;
	private boolean disabledFechaLiquidacion;
	
	//Copias para comparar con los valores originales
	private BigDecimal importeViejo;
	private Date fecFinTramoViejo;
	private Date fecIniTramoViejo;
	private DescripcionTipoOperacionHistderi tipoOperacionViejo; 
	private String conceptoViejo;
	private String tipoConceptoViejo;
	private Long codigoLiquidacionViejo;
	private Date complementoCodLiquiViejo;
	
	
	//private HistoricoTramos tramoViejo = new HistoricoTramos();
	
	@In(required = true)
	private TramosTipoTramo tipoTramo;

	@In(required = true)
	private TramosTipoAccion tipoAccion;	
	

	@In(value = "tramoSelnou")
	@Out
	protected HistoricoTramos tramoOriginal;

	@In
	private HistoricoOperacion historicoOperacion;

	@In(required=false)
	HistoricoOperacionId historicoOperacionBloqueadoId;

	@In
	private BoletasStates boletaState;

	@In(value = "dbLockService", create = true)
	private DbLockService dbLockService;

	@In(required=false)
	private String forcedReturnView;
	
	@In
	private EntityManager entityManager;

	@In("#{boletasBo}")
	protected BoletasBo boletasBo;

	private HistoricoTramos tramoViejo;
	private HistoricoTramos tramoSeleccionado;
	private Set <HistoricoIndice> listaIndices;
	
	/**
	 * Inyección del bean de Spring 
	 */
	@In("#{tramosBo}")
	protected TramosBo tramosBo;

	/**
	 * Inyección del bean de Spring 
	 */
	@In("#{altaTramosBo}")
	protected AltaTramosBo altaTramosBo;
	
	/**
	 * Inyección del bean de Spring 
	 */
	@In("#{detallePrimasBo}")
	protected DetallePrimasBo detallePrimasBo;

	@In(required=false)
	private TramosTableComponent tramosTableComponent;
	
	public DetallePrimasAction() {
		super();
	}

	@In(create = true)
	protected TramosAction tramosAction;

    @In Credentials credentials;	
	
	private Boolean primeraVez = true;
	private boolean pasaValidacion = false;
	private boolean sinErrores = true;
	private StringBuilder mensajesValidacion = new StringBuilder();
	private boolean salirDirecto;	
	
	
	
	
	
	
	
	public boolean conceptoDisabled() {
//		return tipoTramo == TramosTipoTramo.NOM;
		return ((tipoTramo == TramosTipoTramo.NOM || tipoAccion != TramosTipoAccion.CREA));
	}

	public boolean divisaDisabled() {
		//if ((tipoTramo == TramosTipoTramo.NOM && tipoAccion == TramosTipoAccion.CREA) ||
		if(( "NOM".equals(tramoSeleccionado.getId().getConcepto()) &&  tipoAccion == TramosTipoAccion.MODIFICA ) ||
			(tipoAccion == TramosTipoAccion.CONSULTA)) 
			return true
			;
		else return false;
	}

//	public boolean validateChkLiq() {
//
//		if ((tipoTramo == TramosTipoTramo.PRI && tipoAccion == TramosTipoAccion.CREA) ||
//			!("IMP".equals(tramoSeleccionado.getId().getConcepto())))
//		return true;
//		else return false;
////		{
////			if ("COM".equals(tramoSeleccionado.getId().getConcepto())) {
////				return false;
////			} else {
////				return true;
////			}
////		} else {
////			return false;
////		}
//	}

//	public boolean fechaLiqDisabled() {
//	return ("IMP".equals(tramoSeleccionado.getId().getConcepto()) && !isLiquida());
//		if (("IMP".equals(tramoSeleccionado.getId().getConcepto()) && !isLiquida() && tipoAccion == TramosTipoAccion.MODIFICA  ) ||
//			(true==true)
//				) {
//			return true;
//		} else {
//			return false;
//		}
//	}
	
	
//// Dos listas, una para habilitar y la otra para decison x A/M x Tipus IRS,....
////  collection.add (campo,IHabilitar)	
////  collection.add (campo,IValorDefecto)	
////	Set < cercar  campo,   >
//// Cal tenir interficie no pas clase
//// La implementacio estandard 	
//	// Interficie DecisionHabilitar(campo,valor  )	
//	// Interficie ValorDefecto(campo, valordefecto )
//// Para cada excepcion una clase diferente	
//
////	Array  por cada tipo, x modo
//
//	
//	private static final Set<String> IRS_A = new HashSet<String>(Arrays.asList(
//		     new String[] {"AB","BC","CD","AE"}
//		));
//
//	public boolean HabilitarNormal(String campo ) {
//		// recuperar la llisa
//		// determinar cas normal
//		if ( IRS_A.contains(campo) )
//			;
//;
//	}
//
//	public boolean Habilitar(String campo ) {
//		// Seleccionar el que toca segons els 3
//		// Obtenir el valor normal  Si esta es protegido, si no es activo
//		// Excepciones
//		
//		if ( IRS_A.contains(campo) )
//			;
//		// Excepcions
////		if ()
////		elseif
//		
//
//  
//		return true;
//	}
//	// Una excepcion segun cada caso
//	
//	
//	public Object ValorPorDefecto(String campo) {
//		// A mano
//		// Ifs del infierno
//		return null;
//	}
//	
//	// Una funcion por excepcion
//	

	public void init(){
	//TODO Validar que solo entre una vez.
	if (primeraVez){
	
		tramoSeleccionado = new HistoricoTramos();
		BeanUtils.copyProperties(tramoOriginal,tramoSeleccionado);
		if (tipoAccion == TramosTipoAccion.MODIFICA){
		
		//Nueva ID
			HistoricoTramosId id = new HistoricoTramosId();
			id.setFechaFinTramo(new Date(tramoOriginal.getId().getFechaFinTramo().getTime()));
			id.setFechaInicioTramo(new Date(tramoOriginal.getId().getFechaInicioTramo().getTime()));
			id.setHistoricoOperacion(historicoOperacion);
			id.setTipoConcepto(new String(tramoOriginal.getId().getTipoConcepto()));
			id.setConcepto(tramoOriginal.getId().getConcepto());
			id.setTipoOperacion(tramoOriginal.getId().getTipoOperacion());
			tramoSeleccionado.setId(id);
			
		//Eliminamos Coleccion
		listaIndices = new HashSet<HistoricoIndice>(tramoOriginal.getHistoricoIndices());
		tramoSeleccionado.setHistoricoIndices(null);	
		
//		tramoSeleccionado.setImporteOperacion(new BigDecimal(tramoOriginal.getImporteOperacion().longValue()));
//		tramoSeleccionado.setDivisaLiquidacion(new String(tramoOriginal.getDivisaLiquidacion()));
//		tramoSeleccionado.setFechaLiquidacion(new Date(tramoOriginal.getFechaLiquidacion().getTime()));
//		

		tramosBo.detach(tramoSeleccionado);
	}
		importeViejo = tramoSeleccionado.getImporteOperacion();
		fecFinTramoViejo = tramoSeleccionado.getId().getFechaFinTramo();
		fecIniTramoViejo = tramoSeleccionado.getId().getFechaInicioTramo();
		conceptoViejo = tramoSeleccionado.getId().getConcepto();
		tipoConceptoViejo = tramoSeleccionado.getId().getTipoConcepto();
		tipoOperacionViejo = tramoSeleccionado.getId().getTipoOperacion();
		codigoLiquidacionViejo = tramoSeleccionado.getCodigoLiquidacion();
		complementoCodLiquiViejo = tramoSeleccionado.getComplementoCodLiqui();
		primeraVez = false;
	
		
//		if (tipoTramo == TramosTipoTramo.PRI || (tipoAccion == TramosTipoAccion.CONSULTA))			
//				setDisabledLiquida(true);
//		else 	setDisabledLiquida(false);
		
		if (tipoTramo == TramosTipoTramo.NOM && (tipoAccion != TramosTipoAccion.CONSULTA))			
			setDisabledLiquida(false);
		else 	setDisabledLiquida(true);

		
		if (("IMP".equals(tramoSeleccionado.getId().getConcepto()) 
				&& tipoAccion == TramosTipoAccion.MODIFICA  && !isLiquida()) 
				|| (tipoAccion == TramosTipoAccion.CONSULTA))
			setDisabledFechaLiquidacion(true);
		else setDisabledFechaLiquidacion(false);
	
	
		if (tipoTramo == TramosTipoTramo.NOM && tipoAccion == TramosTipoAccion.CREA) {
						tramoSeleccionado.getId().setConcepto("NOM");
						tramoSeleccionado.getId().setTipoConcepto("NOM");
						detallePrimasBo.setConcepto_fin("1");
						detallePrimasBo.setConcepto_ini("1");
		}						
						
		if (tipoTramo == TramosTipoTramo.PRI && tipoAccion == TramosTipoAccion.CREA){
			detallePrimasBo.setConcepto_fin("29");
			detallePrimasBo.setConcepto_ini("4");
		}
	
		if (tipoAccion == TramosTipoAccion.MODIFICA) {
			if ("NOM".equals(tramoSeleccionado.getId().getConcepto())){
				detallePrimasBo.setConcepto_fin("1");
				detallePrimasBo.setConcepto_ini("1");
			}  
			else {
				detallePrimasBo.setConcepto_fin("29");
				detallePrimasBo.setConcepto_ini("2");
			}		
		
		if ("IMP".equals(tramoSeleccionado.getId().getConcepto())) {
				if (tramoSeleccionado.getFechaLiquidacion() !=null) setLiquida(true);
				else setLiquida(false);
		}	
		}
	}	
	}
	
	public boolean tipoOperacionDisabled(){
		return (tipoAccion == TramosTipoAccion.CONSULTA || tipoAccion == TramosTipoAccion.MODIFICA);
	}

	public void campsChange(){
		tramosBo.informarDatosDefectoPRI(tramoSeleccionado, historicoOperacion);
	}
	
	public void divisaPagoChange(){
		if (tramosBo.validarDivisa(tramoSeleccionado.getDivisaTramo()))
			tramoSeleccionado.setDivisaLiquidacion(tramoSeleccionado.getDivisaTramo().getId());
		else statusMessages.add(Severity.ERROR, "#{messages['Tramos.error.DivisaIncorrecta']}");
	}
	
	public void chkLiquidaChange(){
		if (isLiquida()) {
			if (isDisabledFechaLiquidacion()){
				setDisabledFechaLiquidacion(false);
			}
		}
		else {
			setDisabledFechaLiquidacion(true);
			tramoSeleccionado.setFechaLiquidacion(null);
			tramoSeleccionado.setDivisaLiquidacion(null);
		}
	}
	
	public TramosAction getTramosAction() {
		return tramosAction;
	}

	public void setTramosAction(TramosAction tramosAction) {
		this.tramosAction = tramosAction;
	}

	public void validateConcepto() {
		if ("IMP".equals(tramoSeleccionado.getId().getTipoConcepto())) {
			tramoSeleccionado.setDivisaLiquidacion(null);
			tramoSeleccionado.setFechaLiquidacion(null);
			setDisabledFechaLiquidacion(true);
			setLiquida(false);
			setDisabledLiquida(false);
			if (tipoAccion == TramosTipoAccion.CREA){
				tramoSeleccionado.getId().setFechaInicioTramo(historicoOperacion.getFechaValor());
				tramoSeleccionado.getId().setFechaFinTramo(historicoOperacion.getFechaVencimiento());
			}
		}
		else {
			setLiquida(false);
			setDisabledLiquida(true);
			setDisabledFechaLiquidacion(false);
		}
	}

	public String getConcepto() {
		return concepto;
	}

	public void setConcepto(String concepto) {
		this.concepto = concepto;
	}

	public HistoricoTramos getTramoSeleccionado() {
		return tramoSeleccionado;
	}

	public void setTramoSeleccionado(HistoricoTramos tramoSeleccionado) {
		this.tramoSeleccionado = tramoSeleccionado;
	}

	public void setFechaLiquidacion(Date fechaLiquidacion) {
		this.fechaLiquidacion = fechaLiquidacion;
	}

	public Date getFechaLiquidacion() {
		return fechaLiquidacion;
	}

	public void setDivisaLiq(String divisaLiq) {
		this.divisaLiq = divisaLiq;
	}

	public String getDivisaLiq() {
		return divisaLiq;
	}
	
	public boolean isLiquida() {
		return liquida;
	}

	public void setLiquida(boolean liquida) {
		this.liquida = liquida;
	}

	public boolean isDisabledLiquida() {
		return disabledLiquida;
	}

	public void setDisabledLiquida(boolean disabledLiquida) {
		this.disabledLiquida = disabledLiquida;
	}

	public boolean isDisabledFechaLiquidacion() {
		return disabledFechaLiquidacion;
	}

	public void setDisabledFechaLiquidacion(boolean disabledFechaLiquidacion) {
		this.disabledFechaLiquidacion = disabledFechaLiquidacion;
	}

	
	public String aceptar(){
		if ((!pasaValidacion) && sinErrores) {
			alta();
			return Constantes.CONSTANTE_SUCCESS;
		}
		return null;
	}
	public boolean aceptarValidator(){
		mensajesValidacion.delete(0,mensajesValidacion.length());
		pasaValidacion = false;
		sinErrores = true;
		
		//Validaciones
		if (tramoSeleccionado.getId().getFechaInicioTramo().after(tramoSeleccionado.getId().getFechaFinTramo())){
			pasaValidacion = false;
			sinErrores = false;
			statusMessages.add(Severity.ERROR, "#{messages['Tramos.error.FechasErroneas']}");
		}

		if ((tramoSeleccionado.getFechaLiquidacion() == null) 
				&& !("IMP".equals(tramoSeleccionado.getId().getTipoConcepto()))){
			pasaValidacion = false;
			sinErrores = false;
			statusMessages.add(Severity.ERROR, "#{messages['Tramos.error.FechaLiquidacionObligatoria']}");
		}

		
		if ((tramoSeleccionado.getDivisaLiquidacion() == null) 
				&& !("IMP".equals(tramoSeleccionado.getId().getTipoConcepto()))){
			pasaValidacion = false;
			sinErrores = false;
			statusMessages.add(Severity.ERROR, "#{messages['Tramos.error.DivisaLiquidacionObligatoria']}");
		}
		
		if (tipoAccion == TramosTipoAccion.MODIFICA) { 
			
			if (((importeViejo != null ) && 
				 (!importeViejo.equals(tramoSeleccionado.getImporteOperacion()))) ||
				 (importeViejo == null && tramoSeleccionado.getImporteOperacion()!= null ))
		{
			
			  
				
		  if ("LI".equals(tramosBo.estadoLiquidacionTramo(tramoSeleccionado.getCodigoLiquidacion(),
				  tramoSeleccionado.getComplementoCodLiqui())) ){
			  if (sinErrores) pasaValidacion = true;
			  mensajesValidacion.append(ResourceBundle.instance().getString("Tramos.mensaje.LiquidacionLiquidada"));
//			  statusMessages.add(Severity.WARN, "#{messages['Tramos.mensaje.LiquidacionLiquidada']}");
			  
		  }
			  		  
		  if ("VA".equals(tramosBo.estadoLiquidacionTramo(tramoSeleccionado.getCodigoLiquidacion(),
				  tramoSeleccionado.getComplementoCodLiqui())) ){
			  if (sinErrores)  pasaValidacion = true;
			  mensajesValidacion.append(ResourceBundle.instance().getString("Tramos.mensaje.LiquidacionValidada"));
//			  statusMessages.add(Severity.WARN, "#{messages['Tramos.mensaje.LiquidacionValidada']}");
		  }

		  
		  if ("EN".equals(tramosBo.estadoLiquidacionTramo(tramoSeleccionado.getCodigoLiquidacion(),
				  tramoSeleccionado.getComplementoCodLiqui())) ){
			  if (sinErrores)  pasaValidacion = true;
			  mensajesValidacion.append(ResourceBundle.instance().getString("Tramos.mensaje.LiquidacionEnviada"));
		  }
		  
		}}
	
		if ((!pasaValidacion) && sinErrores) {
			return true;
		}
		else if (pasaValidacion) {
			mensajesValidacion.append("\nEsta Seguro que desea grabar?");
			return true;
		}
		return false;
	}
	
	
	
	@Factory(value = "ListaDetallePrimasDivisaCobroRecibo", scope = ScopeType.CONVERSATION)
	public List<Divisa> buildListaDetallePrimasDivisaCobroRecibo() {
		List<Divisa> divisas = new ArrayList<Divisa>();
		Set<Divisa> hs = new HashSet<Divisa>();
		
		if(historicoOperacion.getDivisaPago() != null)
			hs.add(historicoOperacion.getDivisaPago());
		if(historicoOperacion.getDivisaRecibo() != null)
			hs.add(historicoOperacion.getDivisaRecibo());
		if(historicoOperacion.getDivisaLiquidacionPago() != null)
			hs.add(historicoOperacion.getDivisaLiquidacionPago());
		if(historicoOperacion.getDivisaLiquidacionRecibo() != null)
			hs.add(historicoOperacion.getDivisaLiquidacionRecibo());
		if(historicoOperacion.getDivisaPrimaUpFront() != null)
			hs.add(historicoOperacion.getDivisaPrimaUpFront());
		if(historicoOperacion.getDivisaLiquidacionUpFront() != null)
			hs.add(historicoOperacion.getDivisaLiquidacionUpFront());
		
		divisas.addAll(hs);
		return divisas;
	}

	
	
	
	
	public void alta(){
		
		if (tipoAccion == TramosTipoAccion.CREA) {
			tramosBo.insertarHisttramPRI(tramoSeleccionado, historicoOperacion, isLiquida(),credentials.getUsername());
			tramoOriginal = tramoSeleccionado;
		}
			

		if (tipoAccion == TramosTipoAccion.MODIFICA) {
			
			if (importeViejo != null ) {
				if (!importeViejo.equals(tramoSeleccionado.getImporteOperacion()) &&
			  "LI".equals(tramosBo.estadoLiquidacionTramo(tramoSeleccionado.getCodigoLiquidacion(),
					  tramoSeleccionado.getComplementoCodLiqui()))) {

					TramosTable	registro = new TramosTable();
					registro.setAccion("I");
					registro.setCodigoLiquidacion(codigoLiquidacionViejo);
	  				registro.setComplementoCodLiqui(complementoCodLiquiViejo);
	  				registro.setImporteOperacion(tramoSeleccionado.getImporteOperacion());
					tramosTableComponent.getTramosTableList().add(registro);
				}
			} else if (importeViejo == null && tramoSeleccionado.getImporteOperacion() == null) {

				TramosTable	registro = new TramosTable();
				registro.setAccion("I");
				registro.setCodigoLiquidacion(codigoLiquidacionViejo);
  				registro.setComplementoCodLiqui(complementoCodLiquiViejo);
  				registro.setImporteOperacion(tramoSeleccionado.getImporteOperacion());
				tramosTableComponent.getTramosTableList().add(registro);
			}
			
			if (fecFinTramoViejo != tramoSeleccionado.getId().getFechaFinTramo() ||
			   fecIniTramoViejo != tramoSeleccionado.getId().getFechaInicioTramo()) {

				TramosTable	registro = new TramosTable();
				registro.setAccion("T");
				registro.setFechaInicioTramo(fecIniTramoViejo);
  				registro.setFechaFinTramo(fecFinTramoViejo);
  				registro.setTipoOperacion(tipoOperacionViejo);
  				registro.setConcepto(conceptoViejo);
  				registro.setTipoConcepto(tipoConceptoViejo);
  				tramosTableComponent.getTramosTableList().add(registro);
			}


			if (!("PRI".equals(tramoSeleccionado.getId().getConcepto()) && 
				    "IMP".equals(tramoSeleccionado.getId().getTipoConcepto()) && !isLiquida())) {
			// En primas tambien recalculamos la FECCALIQ
			
				if ("PRI".equals(tramoSeleccionado.getId().getConcepto()) 
					&& "NOR".equals(tramoSeleccionado.getId().getTipoConcepto())){
					tramoSeleccionado.setFechaCalculoLiquidacion(tramosBo.obtenerFechaSistema());
				}else{
					tramoSeleccionado.setFechaCalculoLiquidacion(altaTramosBo.ajustarFechaInf(tramoSeleccionado.getId().getFechaInicioTramo(), 
							3, tramoSeleccionado.getDivisaTramo()));
				}

				
				if (tramoSeleccionado.getFechaCalculoLiquidacion().compareTo(historicoOperacion.getId().getFechaTratamiento())>0
						&& !GenericUtils.isNullOrBlank(tramoSeleccionado.getCodigoLiquidacion())){
					TramosTable	registro = new TramosTable();
					registro.setAccion("M");
					registro.setCodigoLiquidacion(codigoLiquidacionViejo);
	  				registro.setComplementoCodLiqui(complementoCodLiquiViejo);
					tramosTableComponent.getTramosTableList().add(registro);	
				}

			}
			
		tramosBo.borrar(tramoOriginal);
		tramosBo.altaAceptar(tramoSeleccionado);
		tramoSeleccionado.setHistoricoIndices(listaIndices);
		tramoOriginal = tramoSeleccionado;
		
		
//		 Set<HistoricoIndice> indices = new HashSet();
//		 indices = tramoOriginal.getHistoricoIndices();
//		 tramoOriginal.getHistoricoIndices().clear();
//		 tramosBo.detach(tramoSeleccionado);
//		 tramosBo.detach(tramoViejo);
//		 tramosBo.borrar(tramoOriginal);
//		 tramosBo.detach(tramoOriginal);
//		 tramosBo.flush();
//		 tramoSeleccionado.getHistoricoIndices().clear();
//		 tramosBo.altaAceptar(tramoSeleccionado);
//		 tramoSeleccionado.setHistoricoIndices(indices);
//		 tramosBo.altaAceptar(tramoSeleccionado);
//		 tramosBo.refrescar(tramoSeleccionado);
//		 BeanUtils.copyProperties(tramoSeleccionado, tramoOriginal);
		 primeraVez = false;
		 //tramosBo.modificarHisttramPRI(tramoSeleccionado, historicoOperacion, isLiquida(),fecIniTramoViejo,fecFinTramoViejo);
		}
	}

	public boolean isCapContingente(){
		return (GenericUtils.nvl(historicoOperacion.getProductoCatalogo().getProdtrat().getTratge03(),"N").equals("S"));
	}

	public boolean isRenderedSalir(){
		return (tipoAccion == TramosTipoAccion.CONSULTA);
		
	}

	public Boolean getPrimeraVez() {
		return primeraVez;
	}

	public void setPrimeraVez(Boolean primeraVez) {
		this.primeraVez = primeraVez;
	}

	
	public StringBuilder getMensajesValidacion() {
		return mensajesValidacion;
	}

	public void setMensajesValidacion(StringBuilder mensajesValidacion) {
		this.mensajesValidacion = mensajesValidacion;
	}

	public boolean isPasaValidacion() {
		return pasaValidacion;
	}

	public void setPasaValidacion(boolean pasaValidacion) {
		this.pasaValidacion = pasaValidacion;
	}

	public HistoricoTramos getTramoViejo() {
		return tramoViejo;
	}

	public void setTramoViejo(HistoricoTramos tramoViejo) {
		this.tramoViejo = tramoViejo;
	}

	public Set<HistoricoIndice> getListaIndices() {
		return listaIndices;
	}

	public void setListaIndices(Set<HistoricoIndice> listaIndices) {
		this.listaIndices = listaIndices;
	}

	public Object executeYes(){
		return null;
		
	}


	public String salirDirecto(){

		if ( !BoletasStates.CONSULTA_BOLETA.equals( this.boletaState) ) {
			try {
				String result = boletasBo.salirOperacion("R", historicoOperacion, Identity.instance().getCredentials().getUsername());
				if (result != null) {
					String codigoValidacionErroneo = result;
					statusMessages.add(Severity.ERROR, "#{messages['boletas.edicion.error.salir.operacion']");
				}
				//FLM: boletas es un caso especial, si estamos en alta tenemos que saltar 2 parents quizas?
				return doCommonRedirect();
				//return doSalirRedirect();
			} finally {
				if (boletaState == BoletasStates.MODI_BOLETA) {
					dbLockService.desbloqueo(HistoricoOperacion.class, historicoOperacionBloqueadoId);
				}
			}

		} else { 
			return doCommonRedirect();
		}
		    

		
	}
	
private String doCommonRedirect() {
	
	
	if(forcedReturnView!=null){
		return doSalirRedirect();
	}
	if(boletaState==BoletasStates.ALTA_BOLETA){
		Conversation.instance().pop();
		Conversation.instance().pop();
		return "salir";
	}
	
	Conversation conversacion=Conversation.instance();
	Conversation.instance().pop();
	Conversation.instance().pop();
//	Conversation conversacion = Conversation.instance();
	//Volvemos al anterior
	conversacion.redirectToParent();
	return "";
}	

private String doSalirRedirect() {

	if ( BoletasStates.ALTA_BOLETA.equals( this.boletaState) ) {
		
    	Conversation nested =Conversation.instance();
    	Conversation.instance().pop();
    	Conversation.instance().pop();
    	Conversation.instance().pop();
    	
    	boolean dosSaltos= ( "/pages/adminoper/boletas/alta/altaOper.xhtml".equalsIgnoreCase( Conversation.instance().getViewId() ) );
    	
    
    	if(forcedReturnView!=null){
    		if(dosSaltos){
    			Conversation.instance().redirectToParent();
    			return "";
    		}else{
    			Conversation.instance().redirect();
    			return "";

    		}
		}
    	
    	nested.end(true);
    	if(EntityUtil.checkEntityExists(entityManager, historicoOperacion.getProductoCompuesto())){
    		return "/pages/gestionoperaciones/productocompuesto/mantProdCompuesto.xhtml";
    	}
		return "salir";
	} else {
		Conversation conversacion=Conversation.instance();
		Conversation.instance().pop();
		Conversation.instance().pop();
		conversacion.redirectToParent();
		return "";
	}
}

public String decidirSalir(){

	if (isSalirDirecto()) return salirDirecto(); 
	else{ 
		salir();
		return "SalirDos";
	}
	
//	return null;
	
}

public boolean isSalirDirecto() {
	return salirDirecto;
}

public void setSalirDirecto(boolean salirDirecto) {
	this.salirDirecto = salirDirecto;
}

public boolean esEquityOption(){

	if (!GenericUtils.isNullOrBlank(historicoOperacion) && !GenericUtils.isNullOrBlank(historicoOperacion.getProducto()) 
			&&  "RV".equalsIgnoreCase(historicoOperacion.getProducto().getIndicadorClase2()) ){
		return true;
}
	
	return false;	
}


}