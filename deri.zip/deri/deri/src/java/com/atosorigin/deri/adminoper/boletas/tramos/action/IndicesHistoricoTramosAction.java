package com.atosorigin.deri.adminoper.boletas.tramos.action;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.persistence.EntityManager;

import org.jboss.seam.ScopeType;
import org.jboss.seam.annotations.In;
import org.jboss.seam.annotations.Name;
import org.jboss.seam.annotations.Scope;
import org.jboss.seam.annotations.datamodel.DataModel;
import org.jboss.seam.annotations.datamodel.DataModelSelection;
import org.jboss.seam.core.Conversation;
import org.jboss.seam.international.StatusMessage.Severity;
import org.jboss.seam.security.Identity;

import com.atosorigin.common.action.PaginatedListAction;
import com.atosorigin.common.constantes.Constantes;
import com.atosorigin.deri.adminoper.boletas.action.BoletasAction.BoletasStates;
import com.atosorigin.deri.adminoper.boletas.business.BoletasBo;
import com.atosorigin.deri.adminoper.boletas.tramos.action.TramosAction.TramosTipoAccion;
import com.atosorigin.deri.adminoper.boletas.tramos.business.AltaTramosBo;
import com.atosorigin.deri.common.dbLock.DbLockService;
import com.atosorigin.deri.model.adminoper.HistoricoIndiceContainer;
import com.atosorigin.deri.model.gestionoperaciones.HistoricoOperacion;
import com.atosorigin.deri.model.gestionoperaciones.HistoricoOperacionId;
import com.atosorigin.deri.model.mercado.DescripcionIndice;
import com.atosorigin.deri.model.mercado.DescripcionIndiceId;
import com.atosorigin.deri.model.mercado.HistoricoIndice;
import com.atosorigin.deri.model.mercado.HistoricoTramos;
import com.atosorigin.deri.model.mercado.IndicesPantalla;
import com.atosorigin.deri.model.mercado.Subyacente;
import com.atosorigin.deri.model.mercado.TiposPorIndice;
import com.atosorigin.deri.util.EntityUtil;
/**
 * Clase action listener para el caso de uso de consulta operaciones asociadas en datos de mercado.
 */
@Name("indicesAction")
@Scope(ScopeType.CONVERSATION)
public class IndicesHistoricoTramosAction extends PaginatedListAction{	
	
	@In("#{altaTramosBo}")
	protected AltaTramosBo altaTramosBo;
	
	/** List of Indices for a HistoricTramo */
	@DataModel(value ="listaDeIndice")
	protected List<HistoricoIndiceContainer> indiceList;

	/** Selected Indice from the List */
	@DataModelSelection(value ="listaDeIndice")
    protected HistoricoIndiceContainer indiceSelected;	

	/** For Modify screen to have the same selected Indice Object */
	//@Out(required=false, value="historicIndiceModify")
	protected HistoricoIndice historicIndiceModify;
	
	/** Get the HistoricTramos selected in BusquedaDeTramos screen */
	@In(value="historicTramosForIndice")
	protected HistoricoTramos historicTramosForIndice;
	
	@DataModel(value ="listaDeIndicesPantalla")
	protected List<IndicesPantalla> indicesPantallaList;

	/** Selected Indice from the List */
	@DataModelSelection(value ="listaDeIndicesPantalla")
    protected IndicesPantalla indicePantallaSelected;
	
	@In(value="indicesPantallaList")
	protected List<IndicesPantalla> indicesPantallaListInjected;
	
	@In(required=false)
	private TramosTipoAccion tipoAccion;
	
	@In
	private HistoricoOperacion historicoOperacion;

	@In(required=false)
	HistoricoOperacionId historicoOperacionBloqueadoId;

	
	@In
	private String source;

	@In(value = "dbLockService", create = true)
	private DbLockService dbLockService;

	@In(required=false)
	private String forcedReturnView;
	
	@In
	private EntityManager entityManager;
	
	@In
	private BoletasStates boletaState;

	@In("#{boletasBo}")
	protected BoletasBo boletasBo;

	
	List<Subyacente> listaIndices = new ArrayList();
	
	Subyacente selectedIndice;
	
	private Boolean modificar = false;
	
	private Date fechaInicioIndiceOld;

	/**
	 * Actualiza la lista del grid de Errores de Conciliación.
	 * 
	 */
	@SuppressWarnings("unchecked")
	public void buscar(boolean modificado) {

		indiceList = new ArrayList();
		indicesPantallaList = indicesPantallaListInjected;

		System.out.println("*****tipoAccion---"+tipoAccion);
		
		if(!modificado) {
			if("F".equalsIgnoreCase(source)){
				obtencionIndicesFormula();
			} else if(  (tipoAccion == TramosTipoAccion.MODIFICA || tipoAccion == TramosTipoAccion.CREA) && indicesPantallaList.size() == 0){
				obtencionIndicesFormula();
			} else if("B".equalsIgnoreCase(source) && indicesPantallaList.size() > 0){
				recuperarListaIndices();
			} else if("B".equalsIgnoreCase(source) && indicesPantallaList.size() == 0 &&  ( tipoAccion == TramosTipoAccion.CONSULTA ) ){
				//Este obtener no recupera nada
				obtencionIndicesTramo();
			}
		}
		
		setPrimerAcceso(false);
	}

	private void recuperarListaIndices() {
		// JA NO CAL FER RES PQ JA TENIM LA LLISTA A MEMÒRIA
		
//		for (HistoricoIndice indice : historicTramosForIndice.getHistoricoIndices()) {
//			HistoricoIndiceContainer h = new HistoricoIndiceContainer();
//			h.setHistoricoIndice(indice);
//			h.setTiposPorIndice(altaTramosBo.recuperarTipoPorIndice(indice));
//			indiceList.add(h);	
//		}
	}

	private void obtencionIndicesTramo() {
		boolean existeValor;
		//System.out.println("*****Gonna prepare indiceList----"+historicTramosForIndice.getHistoricoIndices().size());
//		List<Object[]> tempList = (List<Object[]>) altaTramosBo.buildIndiceList(historicTramosForIndice);
		indicesPantallaList.clear();
		if(historicTramosForIndice.getHistoricoIndices() != null) {
			for (HistoricoIndice indice : historicTramosForIndice.getHistoricoIndices()) {
				IndicesPantalla h = new IndicesPantalla();
	
				h.setLiteralIndice(indice.getId().getLiteralIndice());
				h.setFechaInicio(indice.getFechaInicio());
				h.setFechaFin(indice.getFechaFin());
				h.setDescripcionCorta(indice.getCodigoIndice().getDescripcionCorta());
				h.setDescripcionLarga(indice.getCodigoIndice().getDescripcionLarga());
				h.setCodigoSubyacente(indice.getCodigoIndice().getCodigo());

				List<DescripcionIndice> descripcionIndice =altaTramosBo.obtenerDescripcionIndice(historicTramosForIndice.getCodigoFormula().getCodigoFormula(), indice.getId().getLiteralIndice());
				h.setTipoFechaInicio(descripcionIndice.get(0).getTipoFechaInicio());
				h.setTipoFechaFin(descripcionIndice.get(0).getTipoFechaFin());
				existeValor = false;

				if (indice.getFechaInicio() != null && indice.getFechaInicio().compareTo(indice.getFechaFin()) == 0){
					for (TiposPorIndice tipos : indice.getCodigoIndice().getTiposPorIndices()) {
						if ((tipos.getId().getFaplicacion() !=null && tipos.getId().getFaplicacion().compareTo(indice.getFechaInicio()) == 0) &&
							"VA".equalsIgnoreCase(tipos.getEstadoindice())	){
								existeValor = true;
								h.setTipoValorIndice(tipos.getTipoValorIndice());
								indicesPantallaList.add(h);
						}
					}
				}

				if (!existeValor) {
					h.setTipoValorIndice(null);
					indicesPantallaList.add(h);	
				}
				
			}
		}
	}

	private void obtencionIndicesFormula() {
		// Not Tested - This Alta part of code is not tested due to unavailability of MantOper
		// Please test this method properly
		List<DescripcionIndice> tempList = altaTramosBo.obtenerDescripcionIndice(historicTramosForIndice.getCodigoFormula().getCodigoFormula(),null);			
		System.out.println("*****tempList.size---"+tempList.size());
		// Now we have only the List from DescripcionIndice, which will give us only the LiteIndi.
		// For setting all other fields of the HistoricoIndiceContainer, please see loop below.
		indicesPantallaList.clear();
		String sinInfo = new String(Constantes.DESCRIPCIONCORTA_SIN_INFORMAR);
		if(tempList.size() > 0){				
			for(int i=0;i<tempList.size();i++){			
				
				IndicesPantalla h = new IndicesPantalla();
				
				h.setLiteralIndice(tempList.get(i).getId().getLiteralIndice());
				h.setDescripcionCorta(sinInfo);
				h.setDescripcionLarga(sinInfo);
				h.setFechaInicio(altaTramosBo.obtencionFecha(tempList.get(i).getTipoFechaInicio(), historicTramosForIndice));
				h.setFechaFin(altaTramosBo.obtencionFecha(tempList.get(i).getTipoFechaFin(), historicTramosForIndice));
				h.setTipoValorIndice(null);
				h.setCodigoSubyacente(null);
				h.setTipoFechaInicio(tempList.get(i).getTipoFechaInicio());
				h.setTipoFechaFin(tempList.get(i).getTipoFechaFin());

				indicesPantallaList.add(h);
				
//				if (historicTramosForIndice.getHistoricoIndices() == null){
//					historicTramosForIndice.setHistoricoIndices(new HashSet<HistoricoIndice>());
//				}else {
//					historicTramosForIndice.getHistoricoIndices().clear();
//				}
//				historicTramosForIndice.getHistoricoIndices().add(h.getHistoricoIndice());
//				indiceList.add(h);

			}// End of For loop
		}
	}
	
	protected void refreshListInternal() {
		setExportExcel(false);		
	}
/// for command buttons 
	public void modificarIndice() {		
//		historicIndiceModify = indicePantallaSelected;
		//System.out.println("*****Producto Check in modificarIndice------"+historicIndiceModify.getId().getHistoricoTramos().getId().getHistoricoOperacion().getProductoCatalogo().getProducat());
		listaIndices = altaTramosBo.buildIndiceSelect(historicoOperacion.getProductoCatalogo()!=null?historicoOperacion.getProductoCatalogo().getProducat():null);

		//MECAP-36652			
		fechaInicioIndiceOld = indicePantallaSelected.getFechaInicio();
		
		/*for(int i = 0; i < listaIndices.size();i++){
			//System.out.println("*****listaIndices.get(i).getCodigo ------"+listaIndices.get(i).getCodigo());
			//System.out.println("**historicIndiceModify.getCodigoIndice ------"+historicIndiceModify.getCodigoIndice());
			if(listaIndices.get(i).getCodigo().equals(historicIndiceModify.getCodigoIndice().getCodigo())){
				//System.out.println("**In For IF Setting selectedIndice**");
				selectedIndice = listaIndices.get(i);
			}
		}	*/	
	}	
	
	public void modificarIndiceSubmit() {		
		//altaTramosBo.modificarIndice(historicIndiceModify);
	//MECAP-36652	
		if (!fechaInicioIndiceOld.equals(indicePantallaSelected.getFechaInicio())){
			DescripcionIndiceId descripcionIndiceId;	

			descripcionIndiceId = new DescripcionIndiceId(historicTramosForIndice.getCodigoFormula().getCodigoFormula().intValue(),
							indicePantallaSelected.getLiteralIndice());

			DescripcionIndice descripcionIndice = altaTramosBo.cargarDescripcionIndice(descripcionIndiceId);
				
			if(descripcionIndice!=null){
				if ("FECFIXIN".equals(descripcionIndice.getTipoFechaInicio())) {
					historicTramosForIndice.setFechaValorDelTipo(indicePantallaSelected.getFechaInicio());
				}
			}
		}
	
	}
	
	public void obtenerDescripcionSubyacente() {
		Subyacente subyacente = altaTramosBo.obtenerDescripcionSubyacente(indicePantallaSelected.getCodigoSubyacente());
		if(subyacente != null) {
			indicePantallaSelected.setDescripcionCorta(subyacente.getDescripcionCorta());
			indicePantallaSelected.setDescripcionLarga(subyacente.getDescripcionLarga());
		}
	}
	
	@Override
	public void refrescarListaExcel() {
		setExportExcel(true);		
	}

	public List<HistoricoIndiceContainer> getIndiceList() {
		return indiceList;
	}

	public void setIndiceList(List<HistoricoIndiceContainer> indiceList) {
		this.indiceList = indiceList;
	}

	public HistoricoIndiceContainer getIndiceSelected() {
		return indiceSelected;
	}

	public void setIndiceSelected(HistoricoIndiceContainer indiceSelected) {
		this.indiceSelected = indiceSelected;
	}

	public HistoricoIndice getHistoricIndiceModify() {
		return historicIndiceModify;
	}

	public void setHistoricIndiceModify(HistoricoIndice historicIndiceModify) {
		this.historicIndiceModify = historicIndiceModify;
	}

	@Override
	public List<?> getDataTableList() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void setDataTableList(List<?> dataTableList) {
		// TODO Auto-generated method stub
		
	}

	public List<Subyacente> getListaIndices() {
		return listaIndices;
	}

	public void setListaIndices(List<Subyacente> listaIndices) {
		this.listaIndices = listaIndices;
	}

	public Subyacente getSelectedIndice() {
		return selectedIndice;
	}

	public void setSelectedIndice(Subyacente selectedIndice) {
		this.selectedIndice = selectedIndice;
	}	

	public boolean isModificarRendered(){
		//En modo Modificación, si Tramos.DescConcepto like ‘%(OPC)’, el botón ‘Modificar’ 
		//estará deshabilitado
		//if historicTramosForIndice.getId().getConcepto()
		if (tipoAccion == TramosTipoAccion.CONSULTA){
			return false;
		}else{
			return true;	
		}
		
	}

	public List<IndicesPantalla> getIndicesPantallaList() {
		return indicesPantallaList;
	}

	public void setIndicesPantallaList(List<IndicesPantalla> indicesPantallaList) {
		this.indicesPantallaList = indicesPantallaList;
	}

	public IndicesPantalla getIndicePantallaSelected() {
		return indicePantallaSelected;
	}

	public void setIndicePantallaSelected(IndicesPantalla indicePantallaSelected) {
		this.indicePantallaSelected = indicePantallaSelected;
	}


	public String salirDirectoMod(){
		setModificar(true);
		return salirDirecto();
	}
	
	public String salirDirecto(){

		if ( !BoletasStates.CONSULTA_BOLETA.equals( this.boletaState) ) {
			try {
				String result = boletasBo.salirOperacion("R", historicoOperacion, Identity.instance().getCredentials().getUsername());
				if (result != null) {
					String codigoValidacionErroneo = result;
					statusMessages.add(Severity.ERROR, "#{messages['boletas.edicion.error.salir.operacion']");
				}
				//FLM: boletas es un caso especial, si estamos en alta tenemos que saltar 2 parents quizas?
				return doCommonRedirect();
				//return doSalirRedirect();
			} finally {
				if (boletaState == BoletasStates.MODI_BOLETA) {
					dbLockService.desbloqueo(HistoricoOperacion.class, historicoOperacionBloqueadoId);
				}
			}

		} else { 
			return doCommonRedirect();
		}
		    

		
	}
	
private String doCommonRedirect() {
	
	
	if(forcedReturnView!=null){
		return doSalirRedirect();
	}
	if(boletaState==BoletasStates.ALTA_BOLETA){
		Conversation.instance().pop();
		Conversation.instance().pop();
		Conversation.instance().pop();
    	if (getModificar()){
    		Conversation.instance().pop();	
    	}

		return "salir";
	}
	
	Conversation conversacion=Conversation.instance();
	Conversation.instance().pop();
	Conversation.instance().pop();
	Conversation.instance().pop();
	if (getModificar()){
		Conversation.instance().pop();	
	}

//	Conversation conversacion = Conversation.instance();
	//Volvemos al anterior
	conversacion.redirectToParent();
	return "";
}	

private String doSalirRedirect() {

	if ( BoletasStates.ALTA_BOLETA.equals( this.boletaState) ) {
		
    	Conversation nested =Conversation.instance();
    	Conversation.instance().pop();
    	Conversation.instance().pop();
    	Conversation.instance().pop();
    	Conversation.instance().pop();
    	if (getModificar()){
    		Conversation.instance().pop();	
    	}
    	
    	boolean dosSaltos= ( "/pages/adminoper/boletas/alta/altaOper.xhtml".equalsIgnoreCase( Conversation.instance().getViewId() ) );
    	
    
    	if(forcedReturnView!=null){
    		if(dosSaltos){
    			Conversation.instance().redirectToParent();
    			return "";
    		}else{
    			Conversation.instance().redirect();
    			return "";

    		}
		}
    	
    	nested.end(true);
    	if(EntityUtil.checkEntityExists(entityManager, historicoOperacion.getProductoCompuesto())){
    		return "/pages/gestionoperaciones/productocompuesto/mantProdCompuesto.xhtml";
    	}
		return "salir";
	} else {
		Conversation conversacion=Conversation.instance();
		Conversation.instance().pop();
		Conversation.instance().pop();
		Conversation.instance().pop();
    	if (getModificar()){
    		Conversation.instance().pop();	
    	}

		conversacion.redirectToParent();
		return "";
	}
}

public Boolean getModificar() {
	return modificar;
}

public void setModificar(Boolean modificar) {
	this.modificar = modificar;
}

public Date getFechaInicioIndiceOld() {
	return fechaInicioIndiceOld;
}

public void setFechaInicioIndiceOld(Date fechaInicioIndiceOld) {
	this.fechaInicioIndiceOld = fechaInicioIndiceOld;
}

}
