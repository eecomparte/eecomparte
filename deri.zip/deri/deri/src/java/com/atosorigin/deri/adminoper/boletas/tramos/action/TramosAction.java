package com.atosorigin.deri.adminoper.boletas.tramos.action;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.persistence.EntityManager;

import org.jboss.seam.ScopeType;
import org.jboss.seam.annotations.In;
import org.jboss.seam.annotations.Logger;
import org.jboss.seam.annotations.Name;
import org.jboss.seam.annotations.Out;
import org.jboss.seam.annotations.Scope;
import org.jboss.seam.annotations.datamodel.DataModel;
import org.jboss.seam.annotations.datamodel.DataModelSelection;
import org.jboss.seam.core.Conversation;
import org.jboss.seam.core.ResourceBundle;
import org.jboss.seam.international.StatusMessage.Severity;
import org.jboss.seam.log.Log;
import org.jboss.seam.security.Identity;

import com.atosorigin.common.action.PaginatedListAction;
import com.atosorigin.common.excelexporter.CustomExcelExporter;
import com.atosorigin.deri.adminoper.boletas.action.TramosTableComponent;
import com.atosorigin.deri.adminoper.boletas.action.BoletasAction.BoletasStates;
import com.atosorigin.deri.adminoper.boletas.business.BoletasBo;
import com.atosorigin.deri.adminoper.boletas.business.BoletasBusinessException;
import com.atosorigin.deri.adminoper.boletas.tramos.business.TramosBo;
import com.atosorigin.deri.common.dbLock.DbLockService;
import com.atosorigin.deri.model.adminoper.DescripcionTipoOperacionHistderi;
import com.atosorigin.deri.model.catalogo.RelProductoAtributo;
import com.atosorigin.deri.model.catalogo.RelProductoDatosAtributo;
import com.atosorigin.deri.model.gestionoperaciones.HistoricoOperacion;
import com.atosorigin.deri.model.gestionoperaciones.HistoricoOperacionId;
import com.atosorigin.deri.model.mercado.HistoricoTramos;
import com.atosorigin.deri.model.mercado.HistoricoTramosId;
import com.atosorigin.deri.model.mercado.IndicesPantalla;
import com.atosorigin.deri.model.mercado.TiposPorIndice;
import com.atosorigin.deri.model.mercado.TramosTable;
import com.atosorigin.deri.util.EntityUtil;
/**
 * Clase action listener para el caso de uso de consulta operaciones asociadas en datos de mercado.
 */
@Name("tramosAction")
@Scope(ScopeType.CONVERSATION)
public class TramosAction extends PaginatedListAction{

	@Logger
	private Log log;
	
	@In("#{boletasBo}")
	protected BoletasBo boletasBo;

	@In
	private HistoricoOperacion historicoOperacion;
	
	@In
	private BoletasStates boletaState;

	@In(value = "dbLockService", create = true)
	private DbLockService dbLockService;

	@In(required=false)
	private String forcedReturnView;
	
	@In
	private EntityManager entityManager;
	
	public enum TramosTipoTramo {INT, NOM, PRI,AMO,AMP}
	
	public enum TramosTipoAccion {CREA, MODIFICA, CONSULTA}
	
	@Out(required=false)
	private TramosTipoTramo tipoTramo;
	
	@Out(required=false)
	private TramosTipoAccion tipoAccion;
	/**
	 * Inyección del bean de Spring 
	 */
	@In("#{tramosBo}")
	protected TramosBo tramosBo;
	
	@In(value="origenPantalla", required=true)
	protected String origen;
	
		/** Lista de datos para el grid. */
	@DataModel(value ="listaDtTramos")
	protected List<HistoricoTramos> tramosList;

	/** Tipo de documento seleccionado en el grid */
	@DataModelSelection(value ="listaDtTramos")
    protected HistoricoTramos tramoSeleccionado;	

	@Out(required=false, value="tramoSelnou")
	protected HistoricoTramos tramoSelnou;
	
	
	@In(required=false)
	HistoricoOperacionId historicoOperacionBloqueadoId;
	
	@In(value="#{customExcelExporter}")
	protected CustomExcelExporter customExcelExporter;
	
	private Map<Short, RelProductoAtributo> relProductoAtributoMap = null; 
	
	/** Tipo por indice seleccionado en la pantalla de mantenimiento de datos de mercado */
	@In(required=false)
    protected TiposPorIndice tipoIndiceSelec;

	
	@In(required=false)
	private TramosTableComponent tramosTableComponent;
	
	//SMM 07/01/2014
	@In(required = false)
	List <IndicesPantalla> indicesFxCobroList;
	
	@In(required = false)
	List <IndicesPantalla> indicesFxPagoList;
	@Out(required = false, scope = ScopeType.EVENT)
	private String codigoValidacionErroneo;
	
	//Opcion de la ventana popup
	private String opcion="NOM";
	
	
	public HashMap<String, RelProductoDatosAtributo> datosMap;
	
	public String getOpcion() {
		return opcion;
	}
	public void setOpcion(String opcion) {
		this.opcion = opcion;
	}
	
	public List<HistoricoTramos> getTramosList() {
		return tramosList;
	}
	public void setTramosList(List<HistoricoTramos> tramosList) {
		this.tramosList = tramosList;
	}
	public HistoricoTramos getTramoSeleccionado() {
		return tramoSeleccionado;
	}
	public void setTramoSeleccionado(HistoricoTramos tramoSeleccionado) {
		this.tramoSeleccionado = tramoSeleccionado;
	}

	/**
	 * Actualiza la lista del grid de Errores de Conciliación.
	 * 
	 */
	public void buscar() {
		refrescarLista();	
		setPrimerAcceso(false);
	}

	
	public List<HistoricoTramos> getDataTableList() {
		// TODO Auto-generated method stub
		return getTramosList();
	}


	protected void refreshListInternal() {
//		System.out.println("INI BUSQUEDA");
//		final ThreadDebugger td;
//		try {
//			td = new ThreadDebugger(Thread.currentThread(), 50, 2 * 60 * 1000);
//		} catch (IOException e) {
//			throw new IllegalStateException(e);
//		}
		setPrimerAcceso(false);
		setExportExcel(false);
		List<HistoricoTramos> list = getTramosList();
		if(list==null){
			list = new ArrayList<HistoricoTramos>();
			setTramosList(list);
		}
		list.clear();
		if 	(!BoletasStates.CONSULTA_BOLETA.equals(boletaState) && !TramosTipoAccion.CONSULTA.equals(tipoAccion)) {
			tramosBo.refrescarDatosTramos(historicoOperacion);
		}
		list.addAll((List<HistoricoTramos>)tramosBo.obtenerDatosTramos(historicoOperacion));
		
//		System.out.println("FIN BUSQUEDA");
	}
/// for command buttons 
	public void editarElemento() {		
		tramoSelnou = tramoSeleccionado;
		tipoAccion = TramosTipoAccion.MODIFICA;
		if(tramoSelnou.getId().getConcepto().equals("NOM")){
			tipoTramo = TramosTipoTramo.NOM;
		} else if(tramoSelnou.getId().getConcepto().equals("INT")){
			tipoTramo = TramosTipoTramo.INT;
		} else if(tramoSelnou.getId().getConcepto().equals("PRI")){
			tipoTramo = TramosTipoTramo.PRI;
		} else if(tramoSelnou.getId().getConcepto().equals("AMO")){
			tipoTramo = TramosTipoTramo.AMO;
		} else if(tramoSelnou.getId().getConcepto().equals("AMP")){
			tipoTramo = TramosTipoTramo.AMP;
		}
		setPrimerAcceso(true);
	}
	public void borrarElemento() {		

//		statusMessages.add(Severity.ERROR, "#{messages['boletas.pestanas.datosOpcion.busquedaDeTramos.ErrorEliminar']}");	
	if (tramoSeleccionado.getCodigoLiquidacion()==null) {
		TramosTable	registro = new TramosTable();
		registro.setAccion("T");
		registro.setFechaInicioTramo(tramoSeleccionado.getId().getFechaInicioTramo());
		registro.setFechaFinTramo(tramoSeleccionado.getId().getFechaFinTramo());
		registro.setTipoOperacion(tramoSeleccionado.getId().getTipoOperacion());
		registro.setConcepto(tramoSeleccionado.getId().getConcepto());
		registro.setTipoConcepto(tramoSeleccionado.getId().getTipoConcepto());
		tramosTableComponent.getTramosTableList().add(registro);
		
		tramosBo.eliminarTramo(tramoSeleccionado, historicoOperacion);
		buscar();
	   }
	else {
	if ("VA".equals(tramosBo.estadoLiquidacionTramo(tramoSeleccionado.getCodigoLiquidacion(), tramoSeleccionado.getComplementoCodLiqui())) ||
		"EN".equals(tramosBo.estadoLiquidacionTramo(tramoSeleccionado.getCodigoLiquidacion(), tramoSeleccionado.getComplementoCodLiqui())) ||
		"LI".equals(tramosBo.estadoLiquidacionTramo(tramoSeleccionado.getCodigoLiquidacion(), tramoSeleccionado.getComplementoCodLiqui())))
		statusMessages.add(Severity.ERROR, "#{messages['boletas.pestanas.datosOpcion.busquedaDeTramos.ErrorEliminar']}"); 
	else { 
			TramosTable	registro = new TramosTable();
			registro.setAccion("T");
			registro.setFechaInicioTramo(tramoSeleccionado.getId().getFechaInicioTramo());
			registro.setFechaFinTramo(tramoSeleccionado.getId().getFechaFinTramo());
			registro.setTipoOperacion(tramoSeleccionado.getId().getTipoOperacion());
			registro.setConcepto(tramoSeleccionado.getId().getConcepto());
			registro.setTipoConcepto(tramoSeleccionado.getId().getTipoConcepto());
			tramosTableComponent.getTramosTableList().add(registro);
			if  (tramosBo.estadoLiquidacionTramo(tramoSeleccionado.getCodigoLiquidacion(), tramoSeleccionado.getComplementoCodLiqui()) != null) {
				TramosTable	registro2 = new TramosTable();
				registro2.setAccion("B");
				registro2.setCodigoLiquidacion(tramoSeleccionado.getCodigoLiquidacion());
				registro2.setComplementoCodLiqui(tramoSeleccionado.getComplementoCodLiqui());
				registro2.setFechaInicioTramo(tramoSeleccionado.getId().getFechaInicioTramo());
				registro2.setFechaFinTramo(tramoSeleccionado.getId().getFechaFinTramo());
				registro2.setTipoOperacion(tramoSeleccionado.getId().getTipoOperacion());
				registro2.setConcepto(tramoSeleccionado.getId().getConcepto());
				registro2.setTipoConcepto(tramoSeleccionado.getId().getTipoConcepto());
				tramosTableComponent.getTramosTableList().add(registro2);
			}
			tramosBo.eliminarTramo(tramoSeleccionado, historicoOperacion);
			buscar();
		 }
	}
	}
	
	
	public void altaTramos() {	
		//tramoSeleccionado = new HistoricoTramos();
		
		
		tramoSelnou = new HistoricoTramos();
//		DescripcionTipoOperacionHistderi descripcionTipoOperacionHistderi = new DescripcionTipoOperacionHistderi();
		HistoricoTramosId tramId = new HistoricoTramosId();
		tramId.setHistoricoOperacion(historicoOperacion);
		tramId.setTipoOperacion(new DescripcionTipoOperacionHistderi());
		tramoSelnou.setId(tramId);
		
		
		tipoAccion = TramosTipoAccion.CREA;
		if(opcion.equals("NOM")){
			tipoTramo = TramosTipoTramo.NOM;
		} else if(opcion.equals("INT")){
			tipoTramo = TramosTipoTramo.INT;
		} else if(opcion.equals("PRI")){
			tipoTramo = TramosTipoTramo.PRI;
		}
		setPrimerAcceso(true);
	}
	public TramosTipoTramo getTipoTramo() {
		return tipoTramo;
	}
	public void setTipoTramo(TramosTipoTramo tipoTramo) {
		this.tipoTramo = tipoTramo;
	}
	public void condFijacion(){
		tramoSelnou = tramoSeleccionado;
	}

	public void ver(){
		tramoSelnou = tramoSeleccionado;
		tipoAccion = TramosTipoAccion.CONSULTA;
		
//		tramoSelnou = new HistoricoTramos();
//		HistoricoTramosId tramId = new HistoricoTramosId();
//		tramId.setHistoricoOperacion(historicoOperacion);
//		tramId.setTipoOperacion(new DescripcionTipoOperacionHistderi());
//		tramoSelnou.setId(tramId);
//		tipoAccion = TramosTipoAccion.CREA;
//		tipoTramo = TramosTipoTramo.PRI;
		
//			if (tramoSeleccionado.getId().getConcepto().equals("INT")) ;
//		else ;
		if(tramoSelnou.getId().getConcepto().equals("NOM")){
			tipoTramo = TramosTipoTramo.NOM;
		} else if(tramoSelnou.getId().getConcepto().equals("INT")){
			tipoTramo = TramosTipoTramo.INT;
		} else if(tramoSelnou.getId().getConcepto().equals("PRI")){
			tipoTramo = TramosTipoTramo.PRI;
		} else if(tramoSelnou.getId().getConcepto().equals("AMO")){
			tipoTramo = TramosTipoTramo.AMO;
		} else if(tramoSelnou.getId().getConcepto().equals("AMP")){
			tipoTramo = TramosTipoTramo.AMP;
		}
	}

	
	public boolean 	tipoFormTramo() {
//		System.out.println("TipoForm");	
		if (tramoSeleccionado.getCodigoFormula() == null || 
				historicoOperacion.getProductoCatalogo().getProducat()==null)
			return true;
		String tipoFormTramo = tramosBo.obtenerTipoformTramo(tramoSeleccionado.getCodigoFormula(),
				historicoOperacion.getProductoCatalogo());
		if ( "OPE".equals(tipoFormTramo) ) return false;
		else if ( "OPL".equals(tipoFormTramo)) return false;
		else return true;
		
	}

	
	
	public String obtenerModeloProdcata(){
			if ("OPC".equals(historicoOperacion.getProductoCatalogo().getModelpro().getModelpro())) 
					opcion = "PRI" ; 
		return historicoOperacion.getProductoCatalogo().getModelpro().getModelpro();
	}

	public boolean isRendered(boolean creacion, boolean edicion, boolean inspeccion){
			if (boletaState.equals(BoletasStates.ALTA_BOLETA)) {
				return creacion;
			} else if (boletaState.equals(BoletasStates.MODI_BOLETA)) {
				return edicion;
			} else if (boletaState.equals(BoletasStates.CONSULTA_BOLETA)) {
				return inspeccion;
			} else {
				return false;
			}		
		}		
	
	public void excel(){
		//llamar a refrescar lista excel
		customExcelExporter.generarExcel("tablaResultados:table", this);
	}
	@Override
	public void refrescarListaExcel() {
		setExportExcel(true);
		List<HistoricoTramos> list = getTramosList();
		if(list==null){
			list = new ArrayList<HistoricoTramos>();
			setTramosList(list);
		}
		list.clear();
		list.addAll((List<HistoricoTramos>)tramosBo.obtenerDatosTramos(historicoOperacion));
		
	}

	@Override
	public void setDataTableList(List<?> dataTableList) {
		setTramosList((List<HistoricoTramos>)dataTableList);
	}
		

	public String obtenerDescripcionConcepto(HistoricoTramos tramo) {
		//TEST VELOCIDAD
//		System.out.println("Impresion Descripcion");		
//		return tramo.getId().getConcepto();
		//DESCOMENTAR!!!
	if (tramo == null) {
		 return "";
	 }else{
		 if ("C".equals(tramo.getIndicadorTipindiv().getCodigo())) { 
			 String descripcion="Cupón";
			 return descripcion;
			 
		 }
		 else{
		 return tramosBo.obtenerDescripcionConcepto(tramo.getId().getConcepto(), tramo.getId().getTipoConcepto(), 
				 tramo.getId().getTipoOperacion().getCodigo(), 
				 tramo.getCodigoFormula()==null?null:tramo.getCodigoFormula().getCodigoFormula(), 
				 tramo.getId().getHistoricoOperacion().getProductoCatalogo());	
	 }
	 }
	}
	

	public boolean existeCondFijacion(){
		if (tramoSeleccionado!=null && tramoSeleccionado.getId().getHistoricoOperacion().getHistoricoExoticidadesIRSs()!=null && !tramoSeleccionado.getId().getHistoricoOperacion().getHistoricoExoticidadesIRSs().isEmpty()){
			return true;	
		}else{
			return false;
		}
		
	}
	public boolean chivato() {
		System.out.println("CHIVATO LOG");
		return true;
	}
	
	public String mensajeRegenerar(){
	
		if (boletasBo.validateFestivo(historicoOperacion.getFechaVencimiento(),historicoOperacion.getDivisaPago()) ||	
		boletasBo.validateFestivo(historicoOperacion.getFechaVencimiento(),historicoOperacion.getDivisaRecibo())){
			String mensaje;
			mensaje = ResourceBundle.instance().getString("boletas.messageBox.regenerar.calendario.festivo").concat(
			ResourceBundle.instance().getString("boletas.regenerarTramos.confirmacion.message"));
			return mensaje;
		}else{
			return ResourceBundle.instance().getString("boletas.regenerarTramos.confirmacion.message");
		}

	}
	
	
	public void regenerar(){
		if (boletasBo.esCalendarioRegenerable(historicoOperacion)){
//			tramosTableComponent = new TramosTableComponent();
			if ("TO_MANTRAM".equalsIgnoreCase(llamarCalendarioCrear(true))) {
				this.refrescarLista();
			}
		}else{
			statusMessages.add(Severity.ERROR, "#{messages['boletas.edicion.no.regenerable']}");
		}
	}
		
		public String llamarCalendarioCrear(boolean hasCalendario ){
			//FLM: VIP, aqui hacemos la llamada al pck de tramos !!
			try {
				String result = boletasBo.crearCalendario(historicoOperacion, indicesFxCobroList, indicesFxPagoList);
			if (result !=null && result.startsWith("03-")){
				codigoValidacionErroneo = result.substring(3);
				statusMessages.add(Severity.ERROR, "#{messages['boletas.validacion.calendario']}");
				return null;
			}
			if ("00".equals(result) && hasCalendario) {
				/**
				 * Si retorno=’00’ and v_existe_calendario =’S’ Limpiar
				 * T_ACCIONES_TRAMOS_SALIR (199) Grabar matriz
				 * T_ACCIONES_TRAMOS_SALIR (1) Acción , varchar2(2) ‘C’
				 * Codliqui, number(12) null Fetraliq, date null Fecintr, date
				 * null Fecfintr,date null Tipopera, varchar2(2) null Concepto,
				 * varchar2(3) null Tipconce, varchar2(3) null Importes,
				 * number(17,4) null
				 */

				tramosTableComponent.getTramosTableList().clear();
				TramosTable tramoTable = new TramosTable();
				List<TramosTable> tramosTableList = new ArrayList<TramosTable>();
				tramoTable.setAccion("C");
				tramosTableList.add(tramoTable);
				tramosTableComponent.setTramosTableList(tramosTableList);			
				//

			}
			if ("01".equals(result)) {
				statusMessages.add(Severity.ERROR, "#{messages['boletas.alta.completa.error.perdida.historico']}");
			}
			return "TO_MANTRAM";
		} catch (BoletasBusinessException e) {
			codigoValidacionErroneo = e.getMessage();
			statusMessages.add(Severity.ERROR, "#{messages['boletas.alta.completa.error.crear.calendario']}");
			return null;
		}
		}	
	
	public String salirTramos(){

//		while(Conversation.instance().isNested()){
//		        	Conversation nested =Conversation.instance();
//		        	Conversation.instance().pop();
//		        	nested.end(true);
//		        }
//		    	Conversation.instance().end(true);
//			        return "http://localhost:8080/deri_web/home.seam";
//		    
		return origen;
	}

	public String salirDirecto(){

		if ( !BoletasStates.CONSULTA_BOLETA.equals( this.boletaState) ) {
			try {
				String result = boletasBo.salirOperacion("R", historicoOperacion, Identity.instance().getCredentials().getUsername());
				if (result != null) {
					String codigoValidacionErroneo = result;
					statusMessages.add(Severity.ERROR, "#{messages['boletas.edicion.error.salir.operacion']");
				}
				//FLM: boletas es un caso especial, si estamos en alta tenemos que saltar 2 parents quizas?
				return doCommonRedirect();
				//return doSalirRedirect();
			} finally {
				if (boletaState == BoletasStates.MODI_BOLETA) {
					dbLockService.desbloqueo(HistoricoOperacion.class, historicoOperacionBloqueadoId);
				}
			}

		} else { 
			return doCommonRedirect();
		}
		    

		
	}
	
private String doCommonRedirect() {
	
	
	if(forcedReturnView!=null){
		return doSalirRedirect();
	}
	if(boletaState==BoletasStates.ALTA_BOLETA){
		Conversation.instance().pop();
		return "salir";
	}
	
	Conversation conversacion=Conversation.instance();
	Conversation.instance().pop();
//	Conversation conversacion = Conversation.instance();
	//Volvemos al anterior
	conversacion.redirectToParent();
	return "";
}	

private String doSalirRedirect() {

	if ( BoletasStates.ALTA_BOLETA.equals( this.boletaState) ) {
		
    	Conversation nested =Conversation.instance();
    	Conversation.instance().pop();
    	Conversation.instance().pop();
    	
    	boolean dosSaltos= ( "/pages/adminoper/boletas/alta/altaOper.xhtml".equalsIgnoreCase( Conversation.instance().getViewId() ) );
    	
    
    	if(forcedReturnView!=null){
    		if(dosSaltos){
    			Conversation.instance().redirectToParent();
    			return "";
    		}else{
    			Conversation.instance().redirect();
    			return "";

    		}
		}
    	
    	nested.end(true);
    	if(EntityUtil.checkEntityExists(entityManager, historicoOperacion.getProductoCompuesto())){
    		return "/pages/gestionoperaciones/productocompuesto/mantProdCompuesto.xhtml";
    	}
		return "salir";
	} else {
		Conversation conversacion=Conversation.instance();
		Conversation.instance().pop();
		conversacion.redirectToParent();
		return "";
	}
}



}
