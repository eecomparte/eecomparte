package com.atosorigin.deri.adminoper.boletas.tramos.screen;

import java.util.Date;

import org.jboss.seam.ScopeType;
import org.jboss.seam.annotations.Name;
import org.jboss.seam.annotations.Scope;


/**
 *  Contiene los datos de pantalla necesarios para el caso de uso mantenimiento de detallePrimas.
 */
@Name("detallePrimasPantalla")
@Scope(ScopeType.CONVERSATION)
public class DetallePrimasPantalla {
	
	private String concepto;
	private String pagoCobro;
	private Date fechaInicio;
	private Date fechaFin; 
	private String importe;
	private String divisa;
	private Date fechaLiq;
	private String divisaLiq;
	private boolean liquida;
	
	
	public DetallePrimasPantalla(){
		
	}

	public String getConcepto() {
		return concepto;
	}

	public void setConcepto(String concepto) {
		this.concepto = concepto;
	}

	public String getPagoCobro() {
		return pagoCobro;
	}

	public void setPagoCobro(String pagoCobro) {
		this.pagoCobro = pagoCobro;
	}

	public Date getFechaInicio() {
		return fechaInicio;
	}

	public void setFechaInicio(Date fechaInicio) {
		this.fechaInicio = fechaInicio;
	}

	public Date getFechaFin() {
		return fechaFin;
	}

	public void setFechaFin(Date fechaFin) {
		this.fechaFin = fechaFin;
	}

	public String getImporte() {
		return importe;
	}

	public void setImporte(String importe) {
		this.importe = importe;
	}

	public String getDivisa() {
		return divisa;
	}

	public void setDivisa(String divisa) {
		this.divisa = divisa;
	}

	public Date getFechaLiq() {
		return fechaLiq;
	}

	public void setFechaLiq(Date fechaLiq) {
		this.fechaLiq = fechaLiq;
	}

	public String getDivisaLiq() {
		return divisaLiq;
	}

	public void setDivisaLiq(String divisaLiq) {
		this.divisaLiq = divisaLiq;
	}

	public boolean isLiquida() {
		return liquida;
	}

	public void setLiquida(boolean liquida) {
		this.liquida = liquida;
	}
	
	}
