package com.atosorigin.deri.adminoper.calendario.action;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.math.BigDecimal;
import java.text.DecimalFormat;
import java.text.MessageFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.List;
import java.util.Set;

import javax.faces.context.ExternalContext;
import javax.faces.context.FacesContext;
import javax.persistence.EntityManager;
import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServletResponse;

import org.jboss.seam.ScopeType;
import org.jboss.seam.annotations.In;
import org.jboss.seam.annotations.Name;
import org.jboss.seam.annotations.Scope;
import org.jboss.seam.core.Conversation;
import org.jboss.seam.core.ResourceBundle;
import org.jboss.seam.international.StatusMessage.Severity;
import org.jboss.seam.security.Identity;
import org.richfaces.event.UploadEvent;
import org.richfaces.model.UploadItem;

import com.atosorigin.common.action.GenericAction;
import com.atosorigin.common.constantes.Constantes;
import com.atosorigin.common.formvalidator.FormValidator;
import com.atosorigin.common.utils.ExcelImporter;
import com.atosorigin.common.utils.GenericUtils;
import com.atosorigin.deri.adminoper.calendario.business.ImportExportCalendarBo;
import com.atosorigin.deri.adminoper.calendario.screen.ImportExportCalendarPantalla;
import com.atosorigin.deri.common.dbLock.DbLockService;
import com.atosorigin.deri.dao.mercado.DescripcionFormula;
import com.atosorigin.deri.model.adminoper.DescripcionClaseHisttramIndifiva;
import com.atosorigin.deri.model.adminoper.DescripcionHisttramConcepto;
import com.atosorigin.deri.model.adminoper.DescripcionHisttramTipoConcepto;
import com.atosorigin.deri.model.adminoper.DescripcionTipoOperacionHistderi;
import com.atosorigin.deri.model.adminoper.ImportExportCalendar;
import com.atosorigin.deri.model.adminoper.ImportExportCalendarId;
import com.atosorigin.deri.model.contrapartida.Contrapartida;
import com.atosorigin.deri.model.gestionoperaciones.HistoricoOperacion;
import com.atosorigin.deri.model.gestiontesoreria.BaseCalculo;
import com.atosorigin.deri.model.gestiontesoreria.TipoCurva;
import com.atosorigin.deri.model.mercado.HistoricoIndice;
import com.atosorigin.deri.model.mercado.HistoricoTramos;
import com.atosorigin.deri.model.mercado.Subyacente;
import com.atosorigin.deri.model.parametrizacion.Divisa;
import com.atosorigin.deri.swift.gestionswift.screen.GestionSwiftFilterPantalla;
import com.atosorigin.deri.util.EntityUtil;


/**
 * Clase que actúa de action listener para el caso de uso de mantenimiento de tipos de documentos.
 */
@Name("importExportCalendarAction")
@Scope(ScopeType.CONVERSATION)
@FormValidator
public class ImportExportCalendarAction extends GenericAction{ 
//PaginatedListAction{

	/**
	 * Inyección del bean de Spring "swiftBo" que contiene los métodos de negocio
	 * para el caso de uso Gestion de Swift.
	 */
	@In("#{importExportCalendarBo}")
	protected ImportExportCalendarBo importExportCalendarBo;
	
	@In(value="#{facesContext.externalContext}")
	private ExternalContext extCtx;

	@In
	private EntityManager entityManager;
	
	/**
	 * Inyección del screen bean que contiene los datos de pantalla del caso de uso
	 * Gestion de Swift.
	 */
	@In(create=true)
	protected ImportExportCalendarPantalla importExportCalendarPantalla;
	protected GestionSwiftFilterPantalla gestionSwiftFilterPantalla;

	@In(create = true) /* Inyección del servicio que gestiona los bloqueos de registros en base de datos */
	private DbLockService dbLockService;
	
	/**
	 * Actualiza la lista del grid de tipos de documentos.
	 * 
	 */
	public void buscar() {
//		paginationData.reset();
		setPrimerAcceso(false);
		importExportCalendarPantalla.setMostrarAdjuntar(false);
		limpiarAdjuntos();
		comprobarOperacion();
	}

	
	/**
	 * Que no tenga liquidaciones ‘Validadas’
	 * 
	 * select count(*)
	 *  from deri.liquidac
	 *   where proyecto = 'DERI'
	 *      and ncorrela = ncorrela_pantalla
	 *      and fechaope = fechaope_pantalla
	 *      and estadoco = 'VA'
	 *      
	 *      
	 *      Si contador > 0, mostrar error ‘Operación con liquidaciones validadas, no se puede tratar’
	 *      
	 */
	private boolean comprobarLiquidaciones(HistoricoOperacion histoper) {
		 

		if (importExportCalendarBo.cuentaLiquidacionesValidadas(histoper)>0L){
			return false;
		}
		return true;
			        
	}


	/**
	 * Valida que la operación indicada exista y que esté viva
	 * 
	 * 	select estadoco, feultact   
	 *		 from deri.histderi 
	 *		 where (ncorrela, fechaope, feultact) in
	 *		   (   
	 *		     select ncorrela, fechaope, max(feultact)
	 *		       from deri.histderi
	 *		      where ncorrela = ncorrela_pantalla
	 *		        and fechaope = fechaope_pantalla
	 *		       group by ncorrela, fechaope
	 *		   )
	 * 
	 *Si Estadoco devuelto = ‘VA’, continuar (es correcto)
	 *Si Estadoco devuelto <> ‘VA’, mostrar error ‘Operación no tiene estado correcto’
	 *Si devuelve error, mostrar ‘Operación no existe’
	 * 
	 */
	private void comprobarOperacion() {

		
		/** Cargamos los valores seleccionados en los criterios de búsqueda para realizar la consulta*/
		if (!GenericUtils.isNullOrBlank(this.importExportCalendarPantalla.getFechaContratacion())){
			fechaContratacion = this.importExportCalendarPantalla.getFechaContratacion();
		}else{
			statusMessages.add(Severity.ERROR,"#{messages['importexport.error.fechaContratacion']}");
			return;
		}
		
		
		if (!GenericUtils.isNullOrBlank(this.importExportCalendarPantalla.getOperacionid()) && !GenericUtils.isNullOrBlank(nOperacion = this.importExportCalendarPantalla.getOperacionid() )){
			nOperacion = this.importExportCalendarPantalla.getOperacionid();
		}else{
			statusMessages.add(Severity.ERROR,"#{messages['importexport.error.numOperacion']}");
			return;
		}

		HistoricoOperacion histoper = importExportCalendarBo.obtenerOperacion(nOperacion,fechaContratacion);
		if (histoper==null){
			statusMessages.add(Severity.ERROR,"#{messages['importexport.error.noexiste']}");
			return;
		} else if (histoper.getEstado() == null
				|| !"VA".equalsIgnoreCase(histoper.getEstado().getCodigo())){
			statusMessages.add(Severity.ERROR,"#{messages['importexport.error.estadoincorrecto']}");
			return;
		}
		
		if (!comprobarLiquidaciones(histoper)){
			statusMessages.add(Severity.ERROR,"#{messages['importexport.error.liquidacionesvalidadas']}");
			return;
		}

		this.importExportCalendarPantalla.setHistoricoOperacion(histoper);
		importExportCalendarPantalla.setMostrarAdjuntar(true);
	
	}

	public void exportar(){
		
		Set<HistoricoTramos> tramos = this.importExportCalendarPantalla.getHistoricoOperacion().getHistoricoTramoses();
		List<String> lineas = new ArrayList<String>();
		
		if (tramos!=null && tramos.size()>0){
			
			lineas = convertirTramos(tramos);
		
		}
		
		if (lineas == null || lineas.size()==0 || lineas.isEmpty()){
			statusMessages.add(Severity.ERROR,"#{messages['importexport.error.tramos']}");
			return;
		}
		
		String retorno = new String("\r\n");
		String oper = "attachment; filename=\"" + "Tramos " + this.importExportCalendarPantalla.getHistoricoOperacion().getId().getNumeroOperacion().toString()+".csv";
		
		String header = new String ("F. Contrat.;Operacion;Tipo Op.;F. Inicio;F. Fin;Concepto;Tipo Conc.;" +
		"Tramo Irreg.;Nominal Vivo;Liq. Amort.;Amortizac;Divisa Tr.;Dias;Base Calc.;F. Liquidac.;" +
		"F. Fixing;FECHINFU;Strike;Clase;Tipo Int.;Tipo Period.;Spread;Barrera;Importe;Ind. Cap.;" +
		"Imp. Capit.;Formula;Divisa Liq.;Tipo Curva;Num. Titulos;RateFact;Codindic;F.Fixing2;Codindic2;Codindic3;Codindic4;Codindic5");

		FacesContext context = FacesContext.getCurrentInstance();
		
		HttpServletResponse response = (HttpServletResponse)extCtx.getResponse();
		
		response.setContentType("text/plain");

		response.addHeader("Content-disposition", oper);

					
		try {
			ServletOutputStream os = response.getOutputStream();
			
			os.write(header.getBytes());
			os.write(retorno.getBytes());
			
			for(String linea: lineas){
				os.write(linea.getBytes());		
				os.write(retorno.getBytes());
			}			
			os.flush();
			os.close();
			context.responseComplete();
		} catch(Exception e) {
			log.error("\nFailure : " + e.toString() + "\n");
		}

		
	}
	
	public List<String> convertirTramos(Set<HistoricoTramos> tramos){

//		Select	t.FECHAOPE,		t.NCORRELA,		t.TIPOPERA,		t.FECINITR,		t.FECFINTR,
//		t.CONCEPTO,		t.TIPCONCE,		t.INTRAIRR,		t.NOMINALT,		t.INDLIQAM,		t.AMORTIZA,
//		t.DIVISATR,		t.DIASTRAM,		t.BASECALC,		t.FECHALIQ,		t.FECFIXIN,		t.FECHINFU,
//		t.STRIKEOP,		t.INDIFIVA,		t.PORTIPIN,		t.PORTIARR,		t.SPREADOP,		t.BARRERAT,
//		t.IMPORTES,		t.INDICAPI,		t.IMPORTEC,		t.CODFORMU,		t.DIVISALI,		t.TIPOCURV,
//		t.NTITULOS,		i.codindic
//		from deri.histtram t, 		       deri.histindi i
//		 where t.ncorrela = ncorrela_pantalla		   and t.fechaope = fechaope_pantalla
//		   and t.feultact = feultact_guadarda		   and t.codliqui is null 
//		   and t.fetraliq is null 		   and i.ncorrela(+) = t.ncorrela
//		   and i.fechaope(+) = t.fechaope		   and i.feultact(+) = t.feultact 
//		   and i.tipopera(+) = t.tipopera		   and i.fecinitr(+) = t.fecinitr
//		   and i.fecfintr(+) = t.fecfintr		   and i.concepto(+) = t.concepto
//		   and i.tipconce(+) = t.tipconce
		   
		List<String> lineas = new ArrayList<String>();

		for (HistoricoTramos tramo : tramos) {
			if (tramo.getCodigoLiquidacion()==null && tramo.getComplementoCodLiqui()==null){
				lineas.add(obtenerLineaExcel(tramo));
			}else if (comprobarLiquidacion(tramo)){
				lineas.add(obtenerLineaExcel(tramo));
			}
		}
		
		return lineas;
	}
	
	private boolean comprobarLiquidacion(HistoricoTramos tramo) {
		if (importExportCalendarBo.comprobarLiquidacionNoLiq(tramo)){
			return true;
		}
		if (importExportCalendarBo.comprobarLiquidacionNoLiqAG(tramo)){
			return true;
		}
		
		return false;
	}


	private String obtenerLineaExcel(HistoricoTramos tramo) {
		//Separador
		String sep= new String(";");
		StringBuffer sb = new StringBuffer();
		String codindic = null;
		String codindic2 = null;
		String codindic3 = null;
		String codindic4 = null;
		String codindic5 = null;
		Date fecfixing = null;
		
		String retorno = new String("\r\n");
		
		
		if ( tramo.getHistoricoIndices()!=null &&  !tramo.getHistoricoIndices().isEmpty()){
			int i = 0;
			for (HistoricoIndice indice : tramo.getHistoricoIndices()) {
				if (indice.getCodigoIndice()!=null){
					i++;
					switch (i) {
					case 1:
						codindic = indice.getCodigoIndice().getCodigo().toString();						
						break;
					case 2:
						codindic2 = indice.getCodigoIndice().getCodigo().toString();
						//Aprovechamos para informar en caso que tuviera la fecha fixing 2.
						fecfixing = indice.getFechaInicio();
						break;
					case 3:
						codindic3 = indice.getCodigoIndice().getCodigo().toString();						
						break;
					case 4:
						codindic4 = indice.getCodigoIndice().getCodigo().toString();						
						break;
					case 5:
						codindic5 = indice.getCodigoIndice().getCodigo().toString();						
						break;
					default:
						break;
					}
				}
			}
		}
		
//		t.CONCEPTO,		t.TIPCONCE,		t.INTRAIRR,		t.NOMINALT,		t.INDLIQAM,		t.AMORTIZA,
//		t.DIVISATR,		t.DIASTRAM,		t.BASECALC,		t.FECHALIQ,		t.FECFIXIN,		t.FECHINFU,
//		t.STRIKEOP,		t.INDIFIVA,		t.PORTIPIN,		t.PORTIARR,		t.SPREADOP,		t.BARRERAT,
//		t.IMPORTES,		t.INDICAPI,		t.IMPORTEC,		t.CODFORMU,		t.DIVISALI,		t.TIPOCURV,
//		t.NTITULOS,		i.codindic
		
		SimpleDateFormat sdf = new SimpleDateFormat(Constantes.DDMMYYYY );
		
		sb.append(sdf.format(tramo.getId().getHistoricoOperacion().getId().getFechaContratacion()))
		.append(sep).append(tramo.getId().getHistoricoOperacion().getId().getNumeroOperacion().toString())
		.append(sep).append(tramo.getId().getTipoOperacion().getCodigo())
		.append(sep).append(tramo.getId().getFechaInicioTramo().toString())
		.append(sep).append(tramo.getId().getFechaFinTramo().toString())
		.append(sep).append(tramo.getId().getConcepto())
		.append(sep).append(tramo.getId().getTipoConcepto())
		.append(sep).append(tramo.getIndicadorTramoIrregular()!=null?tramo.getIndicadorTramoIrregular():"")
//		.append(sep).append(tramo.getNominalParaCalculo()!=null?tramo.getNominalParaCalculo().toString():"")
		.append(sep).append(tramo.getNominalParaCalculo()!=null?formatBigDecimal(tramo.getNominalParaCalculo()):"")
		.append(sep).append(tramo.getIndicadorLiquiAmortizacion()!=null?tramo.getIndicadorLiquiAmortizacion():"")
//		.append(sep).append(tramo.getNominalAmortizado()!=null?tramo.getNominalAmortizado().toString():"")
		.append(sep).append(tramo.getNominalAmortizado()!=null?formatBigDecimal(tramo.getNominalAmortizado()):"0")
		.append(sep).append(tramo.getDivisaTramo()!=null?tramo.getDivisaTramo().getId():"")
		.append(sep).append(tramo.getDiferenciaDias()!=null?tramo.getDiferenciaDias().toString():"")
		.append(sep).append(tramo.getBaseDeCalculoDias()!=null? "B" + tramo.getBaseDeCalculoDias().getCodigo():"B")
		.append(sep).append(tramo.getFechaLiquidacion()!=null?tramo.getFechaLiquidacion().toString():"")
		.append(sep).append(tramo.getFechaValorDelTipo()!=null?tramo.getFechaValorDelTipo().toString():"")
		.append(sep).append(tramo.getFechaInformarImporte()!=null?tramo.getFechaInformarImporte().toString():"")
		.append(sep).append(tramo.getStrikeCFC()!=null?formatBigDecimal(tramo.getStrikeCFC()):"")
		.append(sep).append(tramo.getIndicadorTipindiv()!=null?tramo.getIndicadorTipindiv().getCodigo():"")
		.append(sep).append(tramo.getPorcentajeTipoInteres()!=null?formatBigDecimal(tramo.getPorcentajeTipoInteres()):"")
		.append(sep).append(tramo.getPorcentajePeriodifIntArrears()!=null?formatBigDecimal(tramo.getPorcentajePeriodifIntArrears()):"")
		.append(sep).append(tramo.getSpreadOperacion()!=null?formatBigDecimal(tramo.getSpreadOperacion()):"")
		.append(sep).append(tramo.getNivelBarrera()!=null?formatBigDecimal(tramo.getNivelBarrera()):"")
		.append(sep).append(tramo.getImporteOperacion()!=null?formatBigDecimal(tramo.getImporteOperacion()):"")
		.append(sep).append(tramo.getIndicadorTramoCapitaliza()!=null?tramo.getIndicadorTramoCapitaliza():"")
		.append(sep).append(tramo.getImporteCapitalizado()!=null?formatBigDecimal(tramo.getImporteCapitalizado()):"")
		.append(sep).append(tramo.getCodigoFormula()!=null?tramo.getCodigoFormula().getCodigoFormula().toString():"")
		.append(sep).append(tramo.getDivisaLiquidacion()!=null?tramo.getDivisaLiquidacion():"")
		.append(sep).append(tramo.getTipoCurvaTramo()!=null? "C"+tramo.getTipoCurvaTramo():"C")
		.append(sep).append(tramo.getNumeroTitulos()!=null?formatBigDecimal(tramo.getNumeroTitulos()):"")
		.append(sep).append(tramo.getRateFactor()!=null?formatBigDecimal(tramo.getRateFactor()):"")
		.append(sep).append(codindic!=null?codindic:"0")
//		.append(sep).append(tramo.getFechaValorDelTipo()!=null?tramo.getFechaValorDelTipo().toString():"")
		.append(sep).append(fecfixing!=null?fecfixing.toString():"")
		.append(sep).append(codindic2!=null?codindic2:"0")
		.append(sep).append(codindic3!=null?codindic3:"0")
		.append(sep).append(codindic4!=null?codindic4:"0")
		.append(sep).append(codindic5!=null?codindic5:"0")
		; 
		
		return sb.toString();
	}

	
	private String formatBigDecimal(BigDecimal bd){
	    DecimalFormat df = new DecimalFormat();
	    df.setMinimumFractionDigits(20);
//	    df.setMaximumFractionDigits(3);
//	    df.setMinimumIntegerDigits(1);
//	    df.setMaximumIntegerDigits(3);
//	    df.setGroupingSize(20);
	    return df.format(bd);
	}
	
	private BigDecimal parserBigDecimal(String sd) throws ParseException{
		DecimalFormat df = new DecimalFormat();
	     df.setParseBigDecimal(true);
        BigDecimal bd = (BigDecimal) df.parse(sd);
        return bd;
	}
	
	public void init() {

//			paginationData.reset();
//			refrescarLista();
	}

	/**
	 * parametors de busqueda
	 */
	Date fechaContratacion = null;
	Date fechaEnvio = null;
	String descripcionEstadoswift = Constantes.CADENA_VACIA;
	String tipoSwift =Constantes.CADENA_VACIA;
	Long nOperacion =null;
	
//	@Override
//	protected void refreshListInternal() {
//
//		Date fechaContratacion = null;
//		Date fechaEnvio = null;
//		String descripcionEstadoswift = Constantes.CADENA_VACIA;
//		String tipoSwift =Constantes.CADENA_VACIA;
//		Long nOperacion =null;
//		
//		setExportExcel(false);
//		
//		/** Cargamos los valores seleccionados en los criterios de búsqueda para realizar la consulta*/
//		if (!GenericUtils.isNullOrBlank(this.importExportCalendarPantalla.getFechaContratacion())){
//			fechaContratacion = this.importExportCalendarPantalla.getFechaContratacion();
//		}
//		
//		
//		if (!GenericUtils.isNullOrBlank(this.importExportCalendarPantalla.getOperacionid()) && !GenericUtils.isNullOrBlank(nOperacion = this.importExportCalendarPantalla.getOperacionid() )){
//			nOperacion = this.importExportCalendarPantalla.getOperacionid();
//		}
//		
//		
//	}
//
//	@Override
//	public void refrescarListaExcel() {
//		setExportExcel(true);
//			if (!GenericUtils.isNullOrBlank(this.importExportCalendarPantalla.getFechaContratacion())){
//				fechaContratacion = this.importExportCalendarPantalla.getFechaContratacion();
//			}
//			
//			if (!GenericUtils.isNullOrBlank(this.importExportCalendarPantalla.getOperacionid()) && !GenericUtils.isNullOrBlank(nOperacion = this.importExportCalendarPantalla.getOperacionid() )){
//				nOperacion = this.importExportCalendarPantalla.getOperacionid();
//			}
//		
//	}

	public void salir(){
		Conversation conversacion = Conversation.instance();
		//Volvemos a la anterior conversación
		if(conversacion.isNested()){
			conversacion.redirectToParent();
		} else {
			redirectToURL("/home.seam");
			conversacion.endAndRedirect();
		}
	}

	
   public void importar(){
	   fichero();
   }
	
/**
	public void uploadFile(UploadEvent event) throws IOException{
		
		UploadItem item = event.getUploadItem();

        String name = Constantes.CADENA_VACIA;
        int fileSize = -1;
        byte[] data = null;
        String contentType = Constantes.CADENA_VACIA;
               
        if (item.isTempFile()) {
            name = item.getFileName().substring(item.getFileName().lastIndexOf(File.separator) + 1);
       		fileSize = item.getFileSize();
            contentType = item.getContentType();
            
            InputStream is = new FileInputStream(item.getFile());
            
            // Creamos el array de byte para guardar los datos
            data = new byte[fileSize];
            
            // Leemos los bytes
            int offset = 0;
            int numRead = 0;
            while (offset < data.length
                   && (numRead=is.read(data, offset, data.length-offset)) >= 0) {
                offset += numRead;
            }
            
            if (offset < data.length) {
                throw new IOException("No se pudo leer el fichero "+ name);
            }
            
            // Cerramos el inputstream
            is.close();
            importExportCalendarPantalla.setArchivoAdjunto(data);
            importExportCalendarPantalla.setFileName(name);
            importExportCalendarPantalla.setContentType(contentType);
            importExportCalendarPantalla.setFileSize(Long.valueOf(fileSize));
        } else {
        	statusMessages.add(Severity.ERROR,"#{messages['importexport.error.noarchivo']}");
        }
	}
	**/
	
	
	/**
	 * Función para gestionar el upload de ficheros adjuntos
	 */
	public void uploadFile(UploadEvent event) throws IOException{
		
		UploadItem item = event.getUploadItem();
               
        if (item.isTempFile()) {
        	importExportCalendarPantalla.setFileName(item.getFile().getPath());
        } else {
        	statusMessages.add(Severity.ERROR,"#{messages['importexport.error.noarchivo']}");
        }
	}
	

	public void fichero(){
		String fichero = importExportCalendarPantalla.getFileName(); 
		String contenido;
		List<ImportExportCalendar> importExportCalendarList = new ArrayList<ImportExportCalendar>();
//		paginationData.reset();
		
		if (!GenericUtils.isNullOrBlank(fichero)) {

			try {
				
				contenido = ExcelImporter.excelExtractor(fichero);
				System.out.println(contenido);
				if (!GenericUtils.isNullOrBlank(contenido)){
					importExportCalendarList  = parser(contenido);	
					comprobacionBloqueo();
					importExportCalendarBo.borrarRegistros(importExportCalendarPantalla.getHistoricoOperacion());
					importarLista(importExportCalendarList);
				}
			} catch (FileNotFoundException e) {
				e.printStackTrace();
				statusMessages.add(Severity.ERROR,"#{messages['importexport.error.abrir']}");
			}catch (Exception ex){
				ex.printStackTrace();
				if (ex!=null && !GenericUtils.isNullOrBlank(ex.getMessage())){
					statusMessages.add(Severity.ERROR,ex.getMessage());
				}else{
					statusMessages.add(Severity.ERROR,"#{messages['importexport.error.lectura']}");
				}
				
			} finally{
				importExportCalendarBo.borrarRegistros(importExportCalendarPantalla.getHistoricoOperacion());
				dbLockService.desbloqueo(HistoricoOperacion.class, importExportCalendarPantalla.getHistoricoOperacion().getId());		
			}
		}else{
			statusMessages.add(Severity.ERROR,"#{messages['importexport.error.archivo']}");
			importExportCalendarBo.borrarRegistros(importExportCalendarPantalla.getHistoricoOperacion());
			dbLockService.desbloqueo(HistoricoOperacion.class, importExportCalendarPantalla.getHistoricoOperacion().getId());
		}
		
	}
	
	private void comprobacionBloqueo() throws Exception {
	
		if (importExportCalendarPantalla.getHistoricoOperacion().getEstado()==null || 
				!"VA".equalsIgnoreCase(importExportCalendarPantalla.getHistoricoOperacion().getEstado().getCodigo())){
			throw 
			new Exception(ResourceBundle.instance().getString("importexport.error.estadoincorrecto"));
		}
	
	if (!comprobarLiquidaciones(importExportCalendarPantalla.getHistoricoOperacion())){
		throw 
		new Exception(ResourceBundle.instance().getString("importexport.error.liquidacionesvalidadas"));
	}

	if (!dbLockService.bloqueo(HistoricoOperacion.class,  importExportCalendarPantalla.getHistoricoOperacion().getId())) {
		throw 
		new Exception(ResourceBundle.instance().getString("importexport.messages.blocked"));
	}

		
	}


	private void importarLista(List<ImportExportCalendar> importExportCalendarList) throws Exception {
		
		if(!importExportCalendarBo.grabarImportExportCalendarList(importExportCalendarList)){
	 		throw 
	 		new Exception(ResourceBundle.instance().getString("importexport.error.grabacion"));
		}
//		else{
//			statusMessages.add(Severity.INFO,"#{messages['importexport.grabacion']}");
//		}
		
		StringBuffer errorCode = new StringBuffer();
		try {
			
		if (!importExportCalendarBo.callImportarCalendario(importExportCalendarPantalla.getHistoricoOperacion(), Identity.instance().getCredentials().getUsername(), errorCode)) {
	 		if (!GenericUtils.isNullOrBlank(errorCode))	throw	new Exception(errorCode.toString());
	 		else throw new Exception(ResourceBundle.instance().getString("importexport.error.importacion"));
 
	 	}else{
	 		statusMessages.add(Severity.INFO,"#{messages['importexport.calendario.importado']}");
	 	}

		} catch (Exception e) {
			throw e;
		}

	
	}
	

	@SuppressWarnings("unchecked")
	public List<ImportExportCalendar> parser(String excel) throws Exception{
		
		SimpleDateFormat sdf = new SimpleDateFormat(Constantes.DDMMYYYY );
		List<ImportExportCalendar> extractos = new ArrayList<ImportExportCalendar>();
		List<ImportExportCalendar>  extractosError= new ArrayList<ImportExportCalendar>();
		String[] lineas = excel.split("\n");
		
		for (int i = 0; i < lineas.length; i++) {
		
			String string = lineas[i];
			String[] campos;
			// Primera línea Nombre Columna
			if (i!=0){
				campos = string.split("\t");
				Double oper= null;
				DescripcionTipoOperacionHistderi tipoOpera = null;
				String codigoDivisatramo=null;
				String baseCalculoDias = null;
				DescripcionClaseHisttramIndifiva indicadorTipindiv=null;
				DescripcionFormula codigoFormula= null;
				
				//SMM 06/10/2016 Indicador Cesta && Producto EQS
				Boolean indicadorCesta = false;
				Boolean productoEQS = false;
				String tipoOperacionOpcion = null;
				
				if (!GenericUtils.isNullOrBlank(importExportCalendarPantalla.getHistoricoOperacion().getHistoricoOpcion())){
					
					indicadorCesta = importExportCalendarPantalla.getHistoricoOperacion().getHistoricoOpcion().getIndicadorCesta();
					tipoOperacionOpcion = importExportCalendarPantalla.getHistoricoOperacion().getHistoricoOpcion().getTipoOperacion();
					
				}
				
				
				productoEQS = isProductoEQS(importExportCalendarPantalla.getHistoricoOperacion());
				
				//SMM 06/10/2016 Fin Indicador Cesta
				
				
				
				
				ImportExportCalendar registre = new ImportExportCalendar();
				ImportExportCalendarId registreId = new ImportExportCalendarId();
				String registro= String.valueOf(i);
				
				registreId.setFechaTratamiento(importExportCalendarPantalla.getHistoricoOperacion().getId().getFechaTratamiento());
				registreId.setFechaModificacion(importExportCalendarPantalla.getHistoricoOperacion().getId().getFechaModificacion());
				
				if (campos.length == 0){
					continue;	
				}
				
				//Verificamos que tena el número de columnas acordado.
				//SMM 06/10/2016 Tocar numero campos una vez sepamos si va la fecha o no
				if (campos.length == 37){
					for (int j = 0; j < campos.length; j++) {
					 
						switch (j){
						 case 0:
//							 try{	
									sdf.setLenient(false);
									try {
									
										registreId.setFechaContratacion(sdf.parse(campos[j]));
										
									} catch (Exception e) {
									    	throw 
									 		new Exception(
									 				MessageFormat.format(ResourceBundle.instance().getString("importexport.errorParser.genericoCampo"),
									 						"FechaContratacion",registro)
									 				);
									} 

								 	if (registreId.getFechaContratacion().compareTo(
								 		importExportCalendarPantalla.getHistoricoOperacion().getId().getFechaContratacion())!=0){
								 		throw 
								 		new Exception(ResourceBundle.instance().getString("importexport.errorParser.fechaContratacion")+registro);
								 	}
								 	break;
// 							    } catch (ParseException e) {
//								     e.printStackTrace();
//								} finally{
////									break;
//								}

						 case 1:
//								try{
									 
								try {
									
									oper = Double.valueOf(campos[j]);
									registreId.setNumeroOperacion(oper.longValue());
									
								} catch (Exception e) {
								    	throw 
								 		new Exception(
								 				MessageFormat.format(ResourceBundle.instance().getString("importexport.errorParser.genericoCampo"),
								 						"NumeroOperacion",registro)
								 				);
								} 


									 
									 if (registreId.getNumeroOperacion().compareTo(
									 		importExportCalendarPantalla.getHistoricoOperacion().getId().getNumeroOperacion())!=0
									 		){
									 		throw 
									 		new Exception(ResourceBundle.instance().getString("importexport.errorParser.NumeroOperacion")+registro);
									 	}
									 	break;									 
//								} catch (NumberFormatException e) {
//									e.printStackTrace();
//								} finally{
//									break;
//								}
						 case 2:;
						 		tipoOpera =  recuperarTipoOpera(campos[j]);
								if(!GenericUtils.isNullOrBlank(tipoOpera)){
									registreId.setTipoOperacion(tipoOpera);
								}else{
							 		throw 
							 		new Exception(ResourceBundle.instance().getString("importexport.errorParser.tipoOpera")+registro);
							 	}
							 	break;
						 case 3:
//								 (>= Fechaope o >= Fechaval) 
									sdf.setLenient(false);
									try {
										
										registreId.setFechaInicioTramo(sdf.parse(campos[j]));
										
									} catch (Exception e) {
									    	throw 
									 		new Exception(
									 				MessageFormat.format(ResourceBundle.instance().getString("importexport.errorParser.genericoCampo"),
									 						"FechaInicioTramo",registro)
									 				);
									} 
									
									
								 	if (registreId.getFechaInicioTramo()
								 		.compareTo(importExportCalendarPantalla.getHistoricoOperacion().getId().getFechaContratacion())<0
								 	&& registreId.getFechaInicioTramo()
							 		.compareTo(importExportCalendarPantalla.getHistoricoOperacion().getFechaValor())<0){
								 		throw 
								 		new Exception(ResourceBundle.instance().getString("importexport.errorParser.FechaInicioTramo")+registro);
								 	}
								 	break;
						 case 4:
//							 >= FECINITR  y <= (Fechaven + 3 habiles)
							 
							 	GregorianCalendar fechaVen = new GregorianCalendar();
							 	fechaVen.setTime(importExportCalendarPantalla.getHistoricoOperacion().getFechaVencimiento());
							 	fechaVen.add(Calendar.DAY_OF_MONTH,3);
							 	
							 		sdf.setLenient(false);
								 	
								 	
								 	
								 	try {
										
								 		registreId.setFechaFinTramo(sdf.parse(campos[j]));
										
									} catch (Exception e) {
									    	throw 
									 		new Exception(
									 				MessageFormat.format(ResourceBundle.instance().getString("importexport.errorParser.genericoCampo"),
									 						"FechaFinTramo",registro)
									 				);
									} 
								 	
								 	
								 	if (registreId.getFechaFinTramo().compareTo(registreId.getFechaInicioTramo()) <0 ||
								 		fechaVen.getTime().compareTo(registreId.getFechaFinTramo()) < 0	){
								 	throw 
							 		new Exception(ResourceBundle.instance().getString("importexport.errorParser.FechaFinTramo")+registro);
								 	}
									break;
							
						case 5:
								registreId.setConcepto(campos[j]);
								if(!comprobarConcepto(registreId.getConcepto())){
									throw 
							 		new Exception(ResourceBundle.instance().getString("importexport.errorParser.concepto")+registro);
								}
								break;
							
						case 6:
								registreId.setTipoConcepto(campos[j]);
								if(!comprobarTipoConcepto(registreId.getTipoConcepto())){
									throw 
							 		new Exception(ResourceBundle.instance().getString("importexport.errorParser.tipoConcepto")+registro);
								}
								break;

						case 7:
//							INTRAIRR: Puede ser S, N, null
							registre.setIndicadorTramoIrregular(campos[j]);
							if (!comprobarFlag(registre.getIndicadorTramoIrregular())){
								throw 
						 		new Exception(ResourceBundle.instance().getString("importexport.errorParser.IndicadorTramoIrregular")+registro);
							}
							break;
						
						case 8:
//							NOMINALT: Numérico positivo (>=0)
							
							try {
								
								if (!"INT".equalsIgnoreCase(registreId.getConcepto()) && GenericUtils.isNullOrBlank(campos[j])) {
									registre.setNominalParaCalculo(null);
									break;
								}else{
									registre.setNominalParaCalculo(new BigDecimal(campos[j]));
								}
								
								
							} catch (Exception e) {
							    	throw 
							 		new Exception(
							 				MessageFormat.format(ResourceBundle.instance().getString("importexport.errorParser.genericoCampo"),
							 						"NominalParaCalculo",registro)
							 				);
							} 
								
								
								
								
								if (BigDecimal.ZERO.compareTo(registre.getNominalParaCalculo()) >0){
									throw 
							 		new Exception(ResourceBundle.instance().getString("importexport.errorParser.NominalParaCalculo")+registro);
								}
								break;
						case 9:
//							INDLIQAM: Puede ser S, N, null
							registre.setIndicadorLiquiAmortizacion(campos[j]);
							if (!comprobarFlag(registre.getIndicadorLiquiAmortizacion())){
								throw 
						 		new Exception(ResourceBundle.instance().getString("importexport.errorParser.IndicadorLiquiAmortizacion")+registro);
							}
							break;
						case 10:
//							AMORTIZA: Numérico, positivo
								
							try {
								
								if (!"INT".equalsIgnoreCase(registreId.getConcepto()) && GenericUtils.isNullOrBlank(campos[j])) {
									registre.setNominalAmortizado(null);
									break;
								}else{
									registre.setNominalAmortizado(new BigDecimal(campos[j]));	
								}
								
								
							} catch (Exception e) {
							    	throw 
							 		new Exception(
							 				MessageFormat.format(ResourceBundle.instance().getString("importexport.errorParser.genericoCampo"),
							 						"NominalAmortizado",registro)
							 				);
							}
							
								if (BigDecimal.ZERO.compareTo(registre.getNominalAmortizado()) >0){
									throw 
							 		new Exception(ResourceBundle.instance().getString("importexport.errorParser.NominalAmortizado")+registro);
								}
								break;
						case 11:
//							DIVISATR: select count(*) from gestio_tressoreria.codivisa where codivisa = valor_excel
//							Si count <> 1, valor incorrecto
							codigoDivisatramo = campos[j];
							Divisa divisaTemp = recuperarDivisa(codigoDivisatramo); 
							if(!GenericUtils.isNullOrBlank(divisaTemp)){
								registre.setDivisaTramo(divisaTemp);
							}else{
								throw 
						 		new Exception(ResourceBundle.instance().getString("importexport.errorParser.DivisaTramo")+registro);
							}
							break;
						case 12:
							try{
								 registre.setDiferenciaDias(Double.valueOf(campos[j]).shortValue());
							} catch (NumberFormatException e) {
								throw 
						 		new Exception(ResourceBundle.instance().getString("importexport.errorParser.DiferenciaDias")+registro);
							} 
							break;
						case 13:
							//SMM 01/08/2016 Como aun no sabemos si se trata de un campo Cupon vamos a recuperar el campo 18 (CLASE)  
							// OJO!! CUALQUIER MODIFICACION EN EL FORMATO FICHERO EXCEL PUEDE VARIAR EL CORRECTO FUNCIONAMIENTO
							
//							BASECALC: select * from gestio_tressoreria.basecalc where basecalc = valor_excel
//							Si count <> 1, valor incorrecto
							if (GenericUtils.isNullOrBlank(campos[j]) || "B".equalsIgnoreCase(campos[j])){
								
								if (!"INT".equalsIgnoreCase(registreId.getConcepto()) 
										//SMM 01/08/2016 Campo Clase columna Excel 18		
										|| "C".equalsIgnoreCase(campos[18]) 
								){
									registre.setBaseDeCalculoDias(null);	
								}else{
									throw 
							 		new Exception(ResourceBundle.instance().getString("importexport.errorParser.BaseDeCalculoDiasInteres")+registro);
								}
								
									
							}else if (campos[j].length() == 4) {
								BaseCalculo baseCalculoTemp = recuperarBaseCalculo(campos[j].substring(1, 4));
								if(!GenericUtils.isNullOrBlank(baseCalculoTemp)){
										registre.setBaseDeCalculoDias(baseCalculoTemp);	
								}else{
									throw 
							 		new Exception(ResourceBundle.instance().getString("importexport.errorParser.BaseDeCalculoDias")+registro);
								}
							}else{
								throw 
						 		new Exception(ResourceBundle.instance().getString("importexport.errorParser.BaseDeCalculoDias")+registro);
							}
//							baseCalculoDias = String.format("%03.0f",Double.valueOf(campos[j]));
//							baseCalculoDias = String.format(campos[j],"999");
//							if (Double.valueOf(baseCalculoDias)==0){ 
//								baseCalculoDias= "000";	
//							}
							break;
						case 14:
//							FECHALIQ: que sea fecha lógica 
							try{		
									sdf.setLenient(false);
								 	registre.setFechaLiquidacion(sdf.parse(campos[j]));
							    } catch (ParseException e) {
							    	throw 
							 		new Exception(
//							 				ResourceBundle.instance().getString("importexport.errorParser.FechaLiquidacion")+registro
		 				MessageFormat.format(ResourceBundle.instance().getString("importexport.errorParser.genericoCampo"), "FechaLiquidacion",registro)		
							 		);
							    	
								} 
							break;
						case 15:
//							FECFIXIN: que sea fecha lógica o null
							 try{	
									sdf.setLenient(false);
									if (GenericUtils.isNullOrBlank(campos[j])){
										registre.setFechaValorDelTipo(null);
									}else{
										registre.setFechaValorDelTipo(sdf.parse(campos[j]));	
									}
								 	
							    } catch (ParseException e) {
							    	throw 
							 		new Exception(
							 				MessageFormat.format(ResourceBundle.instance().getString("importexport.errorParser.genericoCampo"), "FechaValorDelTipo",registro)
							 				);
								}
							    break;
								
						case 16:
//							FECHINFU: que sea fecha lógica o null 
							try{	
									sdf.setLenient(false);
									if (GenericUtils.isNullOrBlank(campos[j])){
										registre.setFechaInformarImporte(null);
									}else{
										registre.setFechaInformarImporte(sdf.parse(campos[j]));	
									}
								 	
							   } catch (ParseException e) {
							    	throw 
							 		new Exception(
							 				MessageFormat.format(ResourceBundle.instance().getString("importexport.errorParser.genericoCampo"), "FechaInformarImporte",registro)
							 				);
								}
							    break;
								
						case 17:
//							STRIKEOP: que sea numérico, o null
							try{
								if (GenericUtils.isNullOrBlank(campos[j])){
									registre.setStrikeCFC(BigDecimal.ZERO);	
								}else{
									registre.setStrikeCFC(new BigDecimal(campos[j]));	
								}
							} catch (Exception e) {
						    	throw 
						 		new Exception(
						 				MessageFormat.format(ResourceBundle.instance().getString("importexport.errorParser.genericoCampo"),
						 						"StrikeCFC",registro)
						 				);
							} 
								break;
						case 18:
							//SMM 01/08/2016 Si cambia esta columna de posicion verificar columna 13 (Base calculo)
//							INDIFIVA: select count(*) from gestio_tressoreria.desccodi where  nomtabla = 'HISTTRAM' and 
//							nomcampo = 'INDIFIVA' and codigoca = valor_excel
//							Si count <> 1, valor incorrecto
							indicadorTipindiv = recuperarIndifiva(campos[j]);
							if(indicadorTipindiv!=null){
								registre.setIndicadorTipindiv(indicadorTipindiv);	
							}else{
								throw 
								new Exception(
						 				MessageFormat.format(ResourceBundle.instance().getString("importexport.errorParser.genericoCampo"),
						 						"Clase",registro)
						 				);
							}
							break;
						case 19:
//							PORTIPIN: 
//								•	Si INDIFIVA = ‘F’ debe ser <> 0 
//								•	Si INDIFIVA = ‘V’ debe sea numérico, o null
							
							if (!"INT".equalsIgnoreCase(registreId.getConcepto()) && GenericUtils.isNullOrBlank(campos[j])) {
								registre.setPorcentajeTipoInteres(null);
								break;
							}
							
							
							String indifiva = null;
							if (registre.getIndicadorTipindiv()!=null){
								indifiva = registre.getIndicadorTipindiv().getCodigo();
							}
							
							try{
								if (GenericUtils.isNullOrBlank(campos[j])){
									if ("F".equalsIgnoreCase(indifiva)){
								    	throw 
								 		new Exception(
								 				MessageFormat.format(ResourceBundle.instance().getString("importexport.errorParser.genericoCampo"),
								 						"PorcentajeTipoInteres",registro)
								 				);
									}else{
										registre.setPorcentajeTipoInteres(BigDecimal.ZERO);										
									}
								}else{
									registre.setPorcentajeTipoInteres(new BigDecimal(campos[j]));
									if ("F".equalsIgnoreCase(indifiva) &&  BigDecimal.ZERO == registre.getPorcentajeTipoInteres()){
								    	throw 
								 		new Exception(
								 				MessageFormat.format(ResourceBundle.instance().getString("importexport.errorParser.genericoCampo"),
								 						"PorcentajeTipoInteres",registro)
								 				);
									}
								}
							} catch (Exception e) {
						    	throw 
						 		new Exception(
						 				MessageFormat.format(ResourceBundle.instance().getString("importexport.errorParser.genericoCampo"),
						 						"PorcentajeTipoInteres",registro)
						 				);
							} 
								break;

						case 20:
//							PORTIARR: que sea numérico, o null
							try{
								if (GenericUtils.isNullOrBlank(campos[j])){
									registre.setPorcentajePeriodifIntArrears(BigDecimal.ZERO);	
								}else{
									registre.setPorcentajePeriodifIntArrears(new BigDecimal(campos[j]));	
								}
							} catch (Exception e) {
						    	throw 
						 		new Exception(
						 				MessageFormat.format(ResourceBundle.instance().getString("importexport.errorParser.genericoCampo"),
						 						"PorcentajePeriodifIntArrears",registro)
						 				);
							} 
								break;
						case 21:
//							SPREADOP: debe sea numérico, o null
							try{
								if (GenericUtils.isNullOrBlank(campos[j])){
									registre.setSpreadOperacion(BigDecimal.ZERO);	
								}else{
									registre.setSpreadOperacion(new BigDecimal(campos[j]));	
								}
							} catch (Exception e) {
						    	throw 
						 		new Exception(
						 				MessageFormat.format(ResourceBundle.instance().getString("importexport.errorParser.genericoCampo"),
						 						"SpreadOperacion",registro)
						 				);
							} 
								break;
						case 22:
//							BARRERAT: debe sea numérico, o null
							try{
								if (GenericUtils.isNullOrBlank(campos[j])){
									registre.setNivelBarrera(BigDecimal.ZERO);	
								}else{
									registre.setNivelBarrera(new BigDecimal(campos[j]));	
								}
							} catch (Exception e) {
						    	throw 
						 		new Exception(
						 				MessageFormat.format(ResourceBundle.instance().getString("importexport.errorParser.genericoCampo"),
						 						"NivelBarrera",registro)
						 				);
							} 
								break;
						case 23:
//							IMPORTES: debe sea numérico, o null
							try{
								if (GenericUtils.isNullOrBlank(campos[j])){
									registre.setImporteOperacion(BigDecimal.ZERO);	
								}else{
									registre.setImporteOperacion(new BigDecimal(campos[j]));	
								}
							} catch (Exception e) {
						    	throw 
						 		new Exception(
						 				MessageFormat.format(ResourceBundle.instance().getString("importexport.errorParser.genericoCampo"),
						 						"ImporteOperacion",registro)
						 				);
							} 
								break;
						case 24:
//							INDICAPI: Puede ser S, N, null
							registre.setIndicadorTramoCapitaliza(campos[j]);
							if (!comprobarFlag(registre.getIndicadorTramoCapitaliza())){
								throw 
						 		new Exception(ResourceBundle.instance().getString("importexport.errorParser.IndicadorTramoCapitaliza")+registro);
							}
							break;
							
						case 25:
//							IMPORTEC: debe sea numérico, o null
							try{
								if (GenericUtils.isNullOrBlank(campos[j])){
									registre.setImporteCapitalizado(BigDecimal.ZERO);	
								}else{
									registre.setImporteCapitalizado(new BigDecimal(campos[j]));	
								}
							} catch (Exception e) {
						    	throw 
						 		new Exception(
						 				MessageFormat.format(ResourceBundle.instance().getString("importexport.errorParser.genericoCampo"),
						 						"ImporteCapitalizado",registro)
						 				);
							} 
								break;
						case 26:
//							CODFORMU: select count(*) from deri.descform where codformu = valor_excel
//							Si count <> 1, valor incorrecto
								if (!"INT".equalsIgnoreCase(registreId.getConcepto()) && GenericUtils.isNullOrBlank(campos[j])) {
									registre.setCodigoFormula(null);
									break;
								}
								try {
									
									codigoFormula = recuperarCodFormula(Double.valueOf(campos[j]).intValue());
									
								} catch (Exception e) {
								    	throw 
								 		new Exception(
								 				MessageFormat.format(ResourceBundle.instance().getString("importexport.errorParser.genericoCampo"),
								 						"codigoFormula",registro)
								 				);
								}
								
								if(!GenericUtils.isNullOrBlank(codigoFormula)){
									registre.setCodigoFormula(codigoFormula);
								}else{
									throw 
							 		new Exception(
							 				MessageFormat.format(ResourceBundle.instance().getString("importexport.errorParser.genericoCampo"),
							 						"codigoFormula",registro)
							 				);

								}
								break;							
							
						case 27:
//							DIVISALI: select count(*) from gestio_tressoreria.codivisa where codivisa = valor_excel
//							Si count <> 1, valor incorrecto
							Divisa divisaLiqTemp = recuperarDivisa(campos[j]); 
							if(!GenericUtils.isNullOrBlank(divisaLiqTemp)){
								registre.setDivisaLiquidacion(divisaLiqTemp.getId());
							}else{
								throw 
						 		new Exception(
						 				MessageFormat.format(ResourceBundle.instance().getString("importexport.errorParser.genericoCampo"),
						 						"DivisaLiquidacion",registro)
						 				);

							}
							break;							
							
						case 28:
//							t.TIPOCURV: select count(*)from gestio_tressoreria.tipocurv where tipocurv = valor_excel
//							Si count <> 1, valor incorrecto
							
							if (GenericUtils.isNullOrBlank(campos[j]) || "C".equalsIgnoreCase(campos[j])){
								registre.setTipoCurvaTramo(null);	
							}else if (campos[j].length() == 4) {
								registre.setTipoCurvaTramo(campos[j].substring(1, 4));
							}else{
								throw 
								new Exception(
						 				MessageFormat.format(ResourceBundle.instance().getString("importexport.errorParser.genericoCampo"),
						 						"TipoCurvaTramo",registro)
						 				);
							}
							if (!comprobarTipoCurva(registre.getTipoCurvaTramo())){
								throw 
						 		new Exception(
						 				MessageFormat.format(ResourceBundle.instance().getString("importexport.errorParser.genericoCampo"),
						 						"TipoCurvaTramo",registro)
						 				);
							}
							break;

						case 29:
//							NTITULOS: puede ser null o un valor numérico positivo
							try{
								if (GenericUtils.isNullOrBlank(campos[j])){
									registre.setNumeroTitulos(BigDecimal.ZERO);	
								}else{
									registre.setNumeroTitulos(new BigDecimal(campos[j]));
									if (BigDecimal.ZERO.compareTo(registre.getNominalAmortizado()) >0){
								    	throw 
								 		new Exception(
								 				MessageFormat.format(ResourceBundle.instance().getString("importexport.errorParser.genericoCampo"),
								 						"NumeroTitulos",registro)
								 				);
									}
								}
							} catch (Exception e) {
						    	throw 
						 		new Exception(
						 				MessageFormat.format(ResourceBundle.instance().getString("importexport.errorParser.genericoCampo"),
						 						"NumeroTitulos",registro)
						 				);
							} 
								break;
						case 30:
							try{
								if (GenericUtils.isNullOrBlank(campos[j])){
									registre.setRateFact(null);	
								}else{
									registre.setRateFact(new BigDecimal(campos[j]));	
								}
							} catch (Exception e) {
						    	throw 
						 		new Exception(
						 				MessageFormat.format(ResourceBundle.instance().getString("importexport.errorParser.genericoCampo"),
						 						"RateFact",registro)
						 				);
							} 
								break;

						case 31:
//							codindic: para tramos Fijos (indifiva =’F’) debe ser nulo, para los tramos variables no puede ser nulo y se validará: select count(*)from mercado.indidesc where codindic = valor_excel
//							Si count <> 1, valor incorrecto							
							indifiva = null;
							if (registre.getIndicadorTipindiv()!=null){
								indifiva = registre.getIndicadorTipindiv().getCodigo();
							}
							
							if ("F".equalsIgnoreCase(indifiva) || "C".equalsIgnoreCase(indifiva) ){
								
								try {
								if (GenericUtils.isNullOrBlank(campos[j]) || 0L == Double.valueOf(campos[j]).longValue()){
									registre.setCodigoIndice(0L);		
								}else{
							    	throw 
							 		new Exception(
							 				MessageFormat.format(ResourceBundle.instance().getString("importexport.errorParser.genericoCampo"),
							 						"Subyacente",registro)
							 						);
								}
								
								
								} catch (Exception e) {
								    	throw 
								 		new Exception(
								 				MessageFormat.format(ResourceBundle.instance().getString("importexport.errorParser.genericoCampo"),
								 						"Subyacente",registro)
								 				);
								} 
							}else if (GenericUtils.isNullOrBlank(campos[j])){
						    	throw 
						 		new Exception(
						 				MessageFormat.format(ResourceBundle.instance().getString("importexport.errorParser.genericoCampo"),
						 						"Subyacente",registro));
							}else {
								
								try {
									registre.setCodigoIndice(Double.valueOf(campos[j]).longValue());	
									
									} catch (Exception e) {
									    	throw 
									 		new Exception(
									 				MessageFormat.format(ResourceBundle.instance().getString("importexport.errorParser.genericoCampo"),
									 						"Subyacente",registro)
									 				);
									} 
								
								if (!comprobarSubyacente(registre.getCodigoIndice())){
							    	throw 
							 		new Exception(
							 				MessageFormat.format(ResourceBundle.instance().getString("importexport.errorParser.genericoCampo"),
							 						"Subyacente",registro));
								
								}
								
							}
							break;
					    case 32:
   							//FECFIXIN2   						
					    
					    	 try{	
					    		 sdf.setLenient(false);
									if (GenericUtils.isNullOrBlank(campos[j])){
										registre.setFechaFixing(null);
									}else{
										registre.setFechaFixing(sdf.parse(campos[j]));	
									}
								 	
							    } catch (ParseException e) {
							    	throw 
							 		new Exception(
							 				MessageFormat.format(ResourceBundle.instance().getString("importexport.errorParser.genericoCampo"), "FechaFixing2",registro)
							 				);
								}
							    break;
						case 33:
   							//CODINDIC2		
					    	//Índice 2: Sólo se permitirá informarlo para EQS que tengan la 
					    	//marca de Cesta,. Si tiene la marca de Cesta es obligatorio
					    	// O formula es Interpolado tb se puede y es obligatoria.Codformu 1025
					    	
							//02/11/2016 SITUOPCI - TIPOOPERA Indica la pata que puede/debe tener estos indices
							
							
							
					    	Boolean interpolado = false;
					    	
					        if (!GenericUtils.isNullOrBlank(registre.getCodigoFormula()) && 
					        		registre.getCodigoFormula().getCodigoFormula()==1025){
					        	
					        	interpolado = true;
					        	
					        }
					        
					        Boolean admiteValorOblig = false;
					        
					        if ( ( indicadorCesta && productoEQS && 
					        	tipoOperacionOpcion.equalsIgnoreCase(registreId.getTipoOperacion().getCodigo()) ) || interpolado ) admiteValorOblig = true;
					        

	//						codindic: para tramos Fijos (indifiva =’F’) debe ser nulo, para los tramos variables no puede ser nulo y se validará: select count(*)from mercado.indidesc where codindic = valor_excel
	//						Si count <> 1, valor incorrecto							
							indifiva = null;
							if (registre.getIndicadorTipindiv()!=null){
								indifiva = registre.getIndicadorTipindiv().getCodigo();
							}
							
							if ( ( "F".equalsIgnoreCase(indifiva) || "C".equalsIgnoreCase(indifiva) ) 
									|| !admiteValorOblig ){
								
								try {
								if (GenericUtils.isNullOrBlank(campos[j]) || 0L == Double.valueOf(campos[j]).longValue()){
									registre.setCodigoIndice2(0L);		
								}else{
							    	throw 
							 		new Exception(
							 				MessageFormat.format(ResourceBundle.instance().getString("importexport.errorParser.genericoCampo"),
							 						"Subyacente-2",registro)
							 						);
								}
								
								
								} catch (Exception e) {
								    	throw 
								 		new Exception(
								 				MessageFormat.format(ResourceBundle.instance().getString("importexport.errorParser.genericoCampo"),
								 						"Subyacente-2",registro)
								 				);
								} 
							}else if (!"F".equalsIgnoreCase(indifiva) && !"C".equalsIgnoreCase(indifiva) 
									&& admiteValorOblig  
									&& GenericUtils.isNullOrBlank(campos[j])){
						    	throw 
						 		new Exception(
						 				MessageFormat.format(ResourceBundle.instance().getString("importexport.errorParser.genericoCampo"),
						 						"Subyacente-2",registro));
							}else {

								try {
									registre.setCodigoIndice2(Double.valueOf(campos[j]).longValue());	
									
									} catch (Exception e) {
									    	throw 
									 		new Exception(
									 				MessageFormat.format(ResourceBundle.instance().getString("importexport.errorParser.genericoCampo"),
									 						"Subyacente-2",registro)
									 				);
									} 
								
								if (!comprobarSubyacente(registre.getCodigoIndice2())){
							    	throw 
							 		new Exception(
							 				MessageFormat.format(ResourceBundle.instance().getString("importexport.errorParser.genericoCampo"),
							 						"Subyacente-2",registro));
								
								}
								
							}
							break;
					    case 34: case 35: case 36:
   							//CODINDIC3, CODINDIC4, 
					    	//CODINDIC5
					    	//Índice 3,4,5: Sólo se permitirá informarlo para EQS 
					    	//que tengan la marca de Cesta, pero no es obligatorio   						
					    
							//02/11/2016 SITUOPCI - TIPOOPERA Indica la pata que puede/debe tener estos indices
					    	
					    	String subyacenteError = null;
   							
   							if (j==34) subyacenteError = "Subyacente-3";
   							else if (j==35) subyacenteError = "Subyacente-4";
   							else subyacenteError = "Subyacente-5";

					        Boolean admiteValor= false;
					        
					        if ( indicadorCesta && productoEQS && 
					        		tipoOperacionOpcion.equalsIgnoreCase(registreId.getTipoOperacion().getCodigo()) )  admiteValor = true;
   							
					    	indifiva = null;
							if (registre.getIndicadorTipindiv()!=null){
								indifiva = registre.getIndicadorTipindiv().getCodigo();
							}
							
							if ( ( "F".equalsIgnoreCase(indifiva) || "C".equalsIgnoreCase(indifiva) ) 
									|| !admiteValor ){
								
								try {
								if (GenericUtils.isNullOrBlank(campos[j]) || 0L == Double.valueOf(campos[j]).longValue()){
									
									if (j==34) registre.setCodigoIndice3(0L);
		   							else if (j==35) registre.setCodigoIndice4(0L);
		   							else registre.setCodigoIndice5(0L);
											
								}else{
							    	throw 
							 		new Exception(
							 				MessageFormat.format(ResourceBundle.instance().getString("importexport.errorParser.genericoCampo"),
							 						subyacenteError,registro)
							 						);
								}
								
								
								} catch (Exception e) {
								    	throw 
								 		new Exception(
								 				MessageFormat.format(ResourceBundle.instance().getString("importexport.errorParser.genericoCampo"),
								 						subyacenteError,registro)
								 				);
								} 
							}else if (GenericUtils.isNullOrBlank(campos[j]) || 0L == Double.valueOf(campos[j]).longValue()){
								
								if (j==34) registre.setCodigoIndice3(0L);
	   							else if (j==35) registre.setCodigoIndice4(0L);
	   							else registre.setCodigoIndice5(0L);
							
							}else{
								try {
									
									if (j==34) registre.setCodigoIndice3(Double.valueOf(campos[j]).longValue());
		   							else if (j==35) {
		   								//Registre Codindic4
		   								if (registre.getCodigoIndice3()==0L){
									    	throw 
									 		new Exception(
									 				MessageFormat.format(ResourceBundle.instance().getString("importexport.errorParser.genericoCampo"),
									 						subyacenteError,registro));
		   								}
		   								else registre.setCodigoIndice4(Double.valueOf(campos[j]).longValue());
		   							} else {
		   								//Registre Codindic5
		   								if (registre.getCodigoIndice4()==0L){
									    	throw 
									 		new Exception(
									 				MessageFormat.format(ResourceBundle.instance().getString("importexport.errorParser.genericoCampo"),
									 						subyacenteError,registro));
		   								}
		   								else registre.setCodigoIndice5(Double.valueOf(campos[j]).longValue());
		   							}
								
									if (!comprobarSubyacente(Double.valueOf(campos[j]).longValue())){
								    	throw 
								 		new Exception(
								 				MessageFormat.format(ResourceBundle.instance().getString("importexport.errorParser.genericoCampo"),
								 						subyacenteError,registro));
									
									}
									
									} catch (Exception e) {
									    	throw 
									 		new Exception(
									 				MessageFormat.format(ResourceBundle.instance().getString("importexport.errorParser.genericoCampo"),
									 						subyacenteError,registro)
									 				);
									} 
								
							}
					    	
					    	break;
   							
						}
												 
					}
					
					registre.setId(registreId);
 					
					Integer errorRegistre =comprobarRegistre(registre); 
 					
					if (errorRegistre !=0){
 				    	
 						String tipusTram = "";
 						if ("AMO".equalsIgnoreCase(registre.getId().getConcepto()) 
 								&&  "AMO".equalsIgnoreCase(registre.getId().getTipoConcepto())){
 							tipusTram= "Amortizacion";
 						}else if ("AMP".equalsIgnoreCase(registre.getId().getConcepto()) 
 								&&  "AMP".equalsIgnoreCase(registre.getId().getTipoConcepto())){
 							tipusTram= "Ampliacion";
 						}else if ("NOM".equalsIgnoreCase(registre.getId().getConcepto()) 
 								&&  "NOM".equalsIgnoreCase(registre.getId().getTipoConcepto())){
 							tipusTram= "Intecambio de Nominal";
 						}
 						
 						if (errorRegistre ==1){
 							throw new Exception(
 					 			MessageFormat.format(ResourceBundle.instance().getString("importexport.errorParser.genericoFechaFixing"),
 					 					tipusTram,registro));	
 						}else if (errorRegistre ==2){
 							throw new Exception(
 						 			MessageFormat.format(ResourceBundle.instance().getString("importexport.errorParser.genericoCodigoIndice"),
 						 					tipusTram,registro));
 						}else if (errorRegistre ==3){
 							throw new Exception(
 						 			MessageFormat.format(ResourceBundle.instance().getString("importexport.errorParser.genericoTipoFijo"),
 						 					tipusTram,registro));
 						}else if (errorRegistre ==4){
 							throw new Exception(
 						 			MessageFormat.format(ResourceBundle.instance().getString("importexport.errorParser.genericoFormula"),
 						 					tipusTram,registro));
 						}
 			
 					}

					
					extractos.add(registre);
					
				}else{
					statusMessages.add(Severity.ERROR,"#{messages['importexport.error.columnas']}");
				
					throw new Exception();
				}
			}
		}
			return extractos;	
		
	}

	private Integer comprobarRegistre(ImportExportCalendar registre) {
 		//Los tramos de Intercambio de Nominal/Ampliaciones/Amortizaciones:
 		//   no deben llevar fecha fixing
 		//   no deben llevar codindic
 		//   deben ser de tipo Fijo (indifiva = F)
 		//   no deben llevar fórmula 
 		
 		if ("INT".equalsIgnoreCase(registre.getId().getConcepto())){
 			return 0;	
 		}
 
 		if (("AMO".equalsIgnoreCase(registre.getId().getConcepto()) &&  "AMO".equalsIgnoreCase(registre.getId().getTipoConcepto()))	
 		||	("AMP".equalsIgnoreCase(registre.getId().getConcepto()) &&  "AMP".equalsIgnoreCase(registre.getId().getTipoConcepto()))	
 		||	("NOM".equalsIgnoreCase(registre.getId().getConcepto()) &&  "NOM".equalsIgnoreCase(registre.getId().getTipoConcepto()))
 		){
 			if (!GenericUtils.isNullOrBlank(registre.getFechaValorDelTipo())){
 				return 1;
 			}
 			if (!GenericUtils.isNullOrBlank(registre.getCodigoIndice()) && registre.getCodigoIndice()!=0L ){
 				return 2;
 			}
 			
 			if (!"F".equalsIgnoreCase(registre.getIndicadorTipindiv().getCodigo())){
 				return 3;
 			}
 
 			if (!GenericUtils.isNullOrBlank(registre.getCodigoFormula()) && registre.getCodigoFormula().getCodigoFormula()!=0 ){
 				return 4;
 			}
 			return 0;	
 		}
 
 
 		
 		return 0;
 	}

	private boolean comprobarTipoCurva(String tipoCurvaTramo) {
		TipoCurva tipoCurva = null;
		try {
			tipoCurva = importExportCalendarBo.getTipoCurva(tipoCurvaTramo);
		} catch (Exception e) {
			return false;
		}
		
		if (tipoCurva!=null) return true;
		
		return false;
	}


	private DescripcionFormula recuperarCodFormula(int codigo) {
		return importExportCalendarBo.recuperarCodFormula(codigo);
	}


	private BaseCalculo recuperarBaseCalculo(String baseCalculoDias) {
		// TODO Auto-generated method stub
		return importExportCalendarBo.recuperarBaseCalculo(baseCalculoDias);
	}


	private Divisa recuperarDivisa(String codigoDivisatramo) {
		// TODO Auto-generated method stub
		return importExportCalendarBo.recuperarDivisa(codigoDivisatramo);
	}

	private DescripcionClaseHisttramIndifiva recuperarIndifiva(String indicadorTipindiv) {
		DescripcionClaseHisttramIndifiva descripcionClaseHisttramIndifiva= null;
		try {
			descripcionClaseHisttramIndifiva = importExportCalendarBo.getIndicadorTipindiv(indicadorTipindiv);
		} catch (Exception e) {
			return null;
		}
		
		if (descripcionClaseHisttramIndifiva!=null) return descripcionClaseHisttramIndifiva ;
		
		return null;
	}	


	private boolean comprobarFlag(String campo) {
		// Puede ser S, N, null
		if (!GenericUtils.isNullOrBlank(campo) && !"S".equalsIgnoreCase(campo)
				&& !"N".equalsIgnoreCase(campo)){
			return false;	
		}
		return true;
	}


	private DescripcionTipoOperacionHistderi recuperarTipoOpera(String tipoOpera) {
		return importExportCalendarBo.getTipoOperacion(tipoOpera);
	}

	private boolean comprobarTipoConcepto(String tipoConcepto) {
		DescripcionHisttramTipoConcepto descripcionHisttramTipoConcepto= null;
		try {
			descripcionHisttramTipoConcepto = importExportCalendarBo.getTipoConcepto(tipoConcepto);
		} catch (Exception e) {
			return false;
		}
		
		if (descripcionHisttramTipoConcepto!=null) return true;
		
		return false;
	}

	private boolean comprobarConcepto(String concepto) {
		DescripcionHisttramConcepto descripcionHisttramConcepto= null;
		try {
			descripcionHisttramConcepto = importExportCalendarBo.getConcepto(concepto);
		} catch (Exception e) {
			return false;
		}
		
		if (descripcionHisttramConcepto!=null) return true;
		
		return false;
	}	
	
	private boolean comprobarSubyacente(Long codigo) {
		Subyacente subyacente= null;
		try {
			subyacente = importExportCalendarBo.recuperarSubyacente(codigo);
		} catch (Exception e) {
			return false;
		}
		
		if (subyacente!=null) return true;
		
		return false;
	}	
	
		

	public void tipoErroneo(){
		statusMessages.add(Severity.ERROR,"#{messages['importexport.error.tipoArchivo']}");
	}
	
	/**
	 * Limpia el archivo adjunto al anexo
	 */
	public void limpiarAdjuntos(){
		importExportCalendarPantalla.setArchivoAdjunto(null);
		importExportCalendarPantalla.setFileName(null);
		importExportCalendarPantalla.setContentType(null);
		importExportCalendarPantalla.setFileSize(null);
	}


	public boolean isProductoEQS(HistoricoOperacion historicoOperacion){

		if (historicoOperacion.getProductoCatalogo() != null && historicoOperacion.getProductoCatalogo().getProdtrat() !=null 
			&& "S".equalsIgnoreCase(historicoOperacion.getProductoCatalogo().getProdtrat().getChkequit())	
		){
			
							return true;			
		}		

		return false;
	
	}

	
	
//	@Override
//	public List<?> getDataTableList() {
//
//		return null;
//	}
//
//	@Override
//	public void setDataTableList(List<?> dataTableList) {
//
//		
//	}
	

	/** ##### FIN UPLOAD ##### */


}
