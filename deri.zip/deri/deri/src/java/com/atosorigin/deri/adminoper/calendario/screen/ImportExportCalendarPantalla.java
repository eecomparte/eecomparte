package com.atosorigin.deri.adminoper.calendario.screen;

import java.util.Date;
import java.util.List;

import org.jboss.seam.ScopeType;
import org.jboss.seam.annotations.Create;
import org.jboss.seam.annotations.In;
import org.jboss.seam.annotations.Name;
import org.jboss.seam.annotations.Out;
import org.jboss.seam.annotations.Scope;
import org.jboss.seam.annotations.datamodel.DataModel;
import org.jboss.seam.annotations.datamodel.DataModelSelection;

import com.atosorigin.deri.model.gestionoperaciones.HistoricoOperacion;
import com.atosorigin.deri.model.swift.DescripcionEstadosSwift;
import com.atosorigin.deri.model.swift.MantenimientoMensajes;
import com.atosorigin.deri.model.swift.MensajeSwift;
import com.atosorigin.deri.model.swift.MensajeSwiftId;


/**
 *  Contiene los datos de pantalla necesarios para el caso de uso mantenimiento de tipos de documentos
 */
@Name("importExportCalendarPantalla")
@Scope(ScopeType.CONVERSATION)
public class ImportExportCalendarPantalla {

	/** Criterios de búsqueda */

	/** operacionid. Criterio de búsqueda  */
	private Long operacionid;
	private Date fechaContratacion;
	private boolean mostrarAdjuntar = false;
	private HistoricoOperacion historicoOperacion;
	
	
	protected String fileName;
	protected String contentType;
	protected Long fileSize;
	protected byte[] archivoAdjunto;
	
	public Long getOperacionid() {
		return operacionid;
	}

	public void setOperacionid(Long operacionid) {
		this.operacionid = operacionid;
	}

		
	
	public Date getFechaContratacion() {
		return fechaContratacion;
	}

	public void setFechaContratacion(Date fechaContratacion) {
		this.fechaContratacion = fechaContratacion;
	}


	public boolean isMostrarAdjuntar() {
		return mostrarAdjuntar;
	}

	public void setMostrarAdjuntar(boolean mostrarAdjuntar) {
		this.mostrarAdjuntar = mostrarAdjuntar;
	}

	
	public String getFileName() {
		return fileName;
	}

	public void setFileName(String fileName) {
		this.fileName = fileName;
	}

	public String getContentType() {
		return contentType;
	}

	public void setContentType(String contentType) {
		this.contentType = contentType;
	}

	public Long getFileSize() {
		return fileSize;
	}

	public void setFileSize(Long fileSize) {
		this.fileSize = fileSize;
	}

	public byte[] getArchivoAdjunto() {
		return archivoAdjunto;
	}

	public void setArchivoAdjunto(byte[] archivoAdjunto) {
		this.archivoAdjunto = archivoAdjunto;
	}

	
	@Create
	public void initialize(){
	}

	public HistoricoOperacion getHistoricoOperacion() {
		return historicoOperacion;
	}

	public void setHistoricoOperacion(HistoricoOperacion historicoOperacion) {
		this.historicoOperacion = historicoOperacion;
	}
	
	
	
}
