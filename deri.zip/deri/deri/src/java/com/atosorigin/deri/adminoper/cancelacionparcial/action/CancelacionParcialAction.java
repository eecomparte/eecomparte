package com.atosorigin.deri.adminoper.cancelacionparcial.action;

import java.math.BigDecimal;
import java.util.Date;

import org.jboss.seam.ScopeType;
import org.jboss.seam.annotations.In;
import org.jboss.seam.annotations.Name;
import org.jboss.seam.annotations.Out;
import org.jboss.seam.annotations.Scope;
import org.jboss.seam.core.Conversation;
import org.jboss.seam.international.StatusMessage.Severity;
import org.jboss.seam.security.Credentials;
import org.jboss.seam.security.Identity;

import com.atosorigin.common.action.GenericAction;
import com.atosorigin.common.constantes.Constantes;
import com.atosorigin.common.formvalidator.FormValidator;
import com.atosorigin.common.utils.GenericUtils;
import com.atosorigin.deri.adminoper.cancelacionparcial.business.CancelacionParcialBo;
import com.atosorigin.deri.adminoper.cancelacionparcial.screen.CancelacionParcialPantalla;
import com.atosorigin.deri.common.dbLock.DbLockService;
import com.atosorigin.deri.model.adminoper.ModiNcorrelaReturn;
import com.atosorigin.deri.model.common.RetornoFuncion;
import com.atosorigin.deri.model.gestionoperaciones.HistoricoOperacion;

@Name("cancelacionParcialAction")
@Scope(ScopeType.CONVERSATION)
@FormValidator
public class CancelacionParcialAction extends GenericAction {

	/**
	 * Inyección del bean de Spring "cancelacionParcialBo"
	 */
	@In("#{cancelacionParcialBo}")
	protected CancelacionParcialBo cancelacionParcialBo;
	@In(create = true) /* Inyección del servicio que gestiona los bloqueos de registros en base de datos */
	private DbLockService dbLockService;
	@In Credentials credentials;
	
	/**
	 * Inyección del screen bean que contiene los datos de pantalla del caso de
	 * uso de mantenimiento de subyacentes
	 */
	@In(create = true)
	protected CancelacionParcialPantalla cancelacionParcialPantalla;
	
	/** Inyección del objeto padre de Boletas y MANTPROD*/
	@In
	private HistoricoOperacion historicoOperacion;
	
	/** Inyección del objeto para la union con MANTPROD */
	@In(required=false)
	@Out(required=false)
	String varModif;
	/**
	 * Función a la que se debe llamar desde boletas para acceder a la pantalla de 
	 * mantenimiento de subyacentes.
	 * @return
	 */
	public void cargarPantalla(){
		
		//Ponemos a false la booleana que se usa para mostrar el popup de confirmacion
		cancelacionParcialPantalla.setEjecucionValida(false);
		
		//Invocamos a F_MODI_NCORRELA, recuperamos una fecha de modificación que será la que usemos
		//a partir de ahora
		// SCM: OJO!!! Ha cambiado el package. Llamada a BoletasDao para unificar la llamada con otras pantallas.
		ModiNcorrelaReturn modiNcorrelaReturn = cancelacionParcialBo.cargarPantalla(historicoOperacion, credentials.getUsername());
		
		cancelacionParcialPantalla.setFechaMod(modiNcorrelaReturn.getFeultact());
		cancelacionParcialPantalla.setFechaTra(modiNcorrelaReturn.getFechatra());
		
		//Inicializamos la pantalla
		cancelacionParcialPantalla.setFechaValor(modiNcorrelaReturn.getFechatra());
		cancelacionParcialPantalla.setImporteAmortizado(null);
		cancelacionParcialPantalla.setNocionalRestante(this.devolverNominal(cancelacionParcialPantalla.getFechaTra(),
														historicoOperacion.getId().getNumeroOperacion(),
														historicoOperacion.getId().getFechaContratacion(),
														cancelacionParcialPantalla.getFechaMod()));
		cancelacionParcialPantalla.setTipoPrima(null);
		cancelacionParcialPantalla.setImporte(null);
		cancelacionParcialPantalla.setDivisa(null);
		cancelacionParcialPantalla.setFechaLiquidacion(null);
	}

	/**
	 * Validaciones previas a ejercer la cancelación. Si son correctas, se mostrará popUp de
	 * decisión para que el usuario escoja si se ejecuta la cancelación o se sale sin guardar
	 * los cambios
	 * @return true si las validaciones son correctas
	 */
	public boolean validarEjecucionParcial(){
	
		boolean esCorrecto = true;
		
		// El campo Importe Amortizado tiene que estar informado y ser distinto de 0
		BigDecimal impAmort = cancelacionParcialPantalla.getImporteAmortizado();

		if(BigDecimal.ZERO.compareTo(impAmort) == 0){
			esCorrecto = false;
			statusMessages.addToControl("importeAmortTxt", Severity.ERROR, "#{messages['cancelacionparcial.error.importeamortizado']}");
		}
		
		/* Si hemos informado alguno de estos campos Importe o tipoCancelacion o bien Fecha de Liquidación,
		 * comprobaremos que los campos Importe, tipoCancelacion, Divisa, y Fecha de Liquidación estén
		 * todos informados */
		boolean importeInformado = !GenericUtils.isNullOrBlank(cancelacionParcialPantalla.getImporte());
		boolean tipoCancInformado = !GenericUtils.isNullOrBlank(cancelacionParcialPantalla.getTipoPrima());
		boolean fechaLiqInformada = !GenericUtils.isNullOrBlank(cancelacionParcialPantalla.getFechaLiquidacion());
		boolean divisaInformada = !GenericUtils.isNullOrBlank(cancelacionParcialPantalla.getDivisa());
		
		if(importeInformado || tipoCancInformado || fechaLiqInformada){
			
			if(!importeInformado){
				esCorrecto = false;
				statusMessages.addToControl("importeTxt", Severity.ERROR, "#{messages['cancelacionparcial.error.importe.informado']}");
			}
			
			if(!tipoCancInformado){
				esCorrecto = false;
				statusMessages.addToControl("primaCmb", Severity.ERROR, "#{messages['cancelacionparcial.error.tipocancelacion.informado']}");
			}
			
			if(!fechaLiqInformada){
				esCorrecto = false;
				statusMessages.addToControl("fLiqTxt", Severity.ERROR, "#{messages['cancelacionparcial.error.fechaliquidacion.informada']}");
			}
			
			if(!divisaInformada){
				esCorrecto = false;
				statusMessages.addToControl("divisaCmb", Severity.ERROR, "#{messages['cancelacionparcial.error.divisa.informada']}");
			}
			
		}
		
		/* Si la Divisa está informada y no coincide con la obtenida con el método
		 * obtenerDivisaTramoCanc también devolvemos un error */
		if(divisaInformada){
			String divisa = cancelacionParcialPantalla.getDivisa();
			String divisaTramo = cancelacionParcialBo.obtenerDivisaTramoCanc(cancelacionParcialPantalla.getFechaTra(),
														historicoOperacion.getId().getFechaContratacion(),
														historicoOperacion.getId().getNumeroOperacion(),
														cancelacionParcialPantalla.getFechaMod());
			
			if(!divisa.equalsIgnoreCase(divisaTramo)){
				esCorrecto = false;
				statusMessages.addToControl("divisaCmb", Severity.ERROR, "#{messages['cancelacionparcial.error.divisa.nocoincide']}");
			}
		}
		
		//Comprobamos que la fechaLiquidacion no sea menor a la fecha de Sistema
		if(fechaLiqInformada){
			Date fechaSis = cancelacionParcialBo.obtenerFechaSistema();
			Date fechaLiq = cancelacionParcialPantalla.getFechaLiquidacion();
		
			long diffFechaLiqSis = (fechaLiq.getTime() - fechaSis.getTime())/86400000L;
			
			if (diffFechaLiqSis < 0){
				esCorrecto = false;
				statusMessages.addToControlFromResourceBundle("fLiqTxt", Severity.ERROR, "cancelacionparcial.error.fechaliquidacion.incorrecta", fechaSis);
			}
		}
		
		//Nocional Restante sea mayor o igual que cero
		BigDecimal nocionalRest = cancelacionParcialPantalla.getNocionalRestante();
		
		if(BigDecimal.ZERO.compareTo(nocionalRest) > 0){
			esCorrecto = false;
			statusMessages.addToControl("nocionalTxt", Severity.ERROR, "#{messages['cancelacionparcial.error.nocional.negativo']}");
		}
		
		if(esCorrecto){
			cancelacionParcialPantalla.setEjecucionValida(true);
		}
		
		return esCorrecto;
		
	}
	
	/**
	 * Ejecuta la cancelacion parcial para lo cual invoca a F_Ejercer_Parcial
	 * y vuelve a la pantalla anterior
	 */
	public void ejercerCancelacion(){
		
		//String outcome = Constantes.CADENA_VACIA;
		
		RetornoFuncion retorno = cancelacionParcialBo.ejercer(historicoOperacion.getId().getNumeroOperacion(),
				historicoOperacion.getId().getFechaContratacion(),
				cancelacionParcialPantalla.getFechaMod(),
				cancelacionParcialPantalla.getNocionalRestante(),
				cancelacionParcialPantalla.getImporteAmortizado(),
				cancelacionParcialPantalla.getFechaValor(),
				cancelacionParcialPantalla.getImporte(),
				cancelacionParcialPantalla.getTipoPrima(),
				cancelacionParcialPantalla.getDivisa(),
				cancelacionParcialPantalla.getFechaLiquidacion(),
				Identity.instance().getCredentials().getUsername());
		
		if(!GenericUtils.isNullOrBlank(retorno) && !retorno.getHayErrores()){
			
			RetornoFuncion ret2 = cancelacionParcialBo.salir("c",
					historicoOperacion.getId().getNumeroOperacion(),
					historicoOperacion.getId().getFechaContratacion(),
					cancelacionParcialPantalla.getFechaMod(),
					Identity.instance().getCredentials().getUsername(),
					null);
			
			dbLockService.desbloqueo(HistoricoOperacion.class, historicoOperacion.getId());
			
			//outcome = Constantes.CONSTANTE_SUCCESS;
			
			if(!GenericUtils.isNullOrBlank(ret2) && retorno.getHayErrores()){
				//Si hay error lo mostramos por pantalla
				statusMessages.add(Severity.ERROR, ret2.getDescError());
			}	
			
			varModif = Constantes.CONSTANTE_SI;
			//SMM: regresa a la pantalla anterior, bien BOLETAS o MANDPROD
			Conversation conversacion=Conversation.instance();
			conversacion.redirectToParent();
			
		} else if(!GenericUtils.isNullOrBlank(retorno) && retorno.getHayErrores()){ //Hay errores			
			statusMessages.add(Severity.ERROR, retorno.getDescError());		
		}
		
		cancelacionParcialPantalla.setEjecucionValida(false);		
		//return outcome;
	}
	
	/**
	 * Cuando el usuario cambia el campo importe amortizado se actualiza el campo nocional restante
	 * con el valor que nos retorna "devolverNominal" menos el importe amortizado
	 */
	public void cambiarImporteAmortizado(){
		
		BigDecimal importeAmort = cancelacionParcialPantalla.getImporteAmortizado();
		BigDecimal nocional = this.devolverNominal(historicoOperacion.getId().getFechaTratamiento(),
								historicoOperacion.getId().getNumeroOperacion(),
								historicoOperacion.getId().getFechaContratacion(),
								historicoOperacion.getId().getFechaModificacion());
		BigDecimal nocionalRestante = nocional.subtract(importeAmort);
		cancelacionParcialPantalla.setNocionalRestante(nocionalRestante);
		
	}
	
	/**
	 * Salir sin grabar. Se invoca a F_SALIR_NCORRELA
	 */
	public void salirSinCambios(){
		RetornoFuncion retorno = cancelacionParcialBo.salir("r",
				historicoOperacion.getId().getNumeroOperacion(),
				historicoOperacion.getId().getFechaContratacion(),
				cancelacionParcialPantalla.getFechaMod(),
				Identity.instance().getCredentials().getUsername(),
				null);
		
		dbLockService.desbloqueo(HistoricoOperacion.class, historicoOperacion.getId());
		
		cancelacionParcialPantalla.setEjecucionValida(false);
		
		if(!GenericUtils.isNullOrBlank(retorno) && retorno.getHayErrores()){
			//Si hay error lo mostramos por pantalla
			statusMessages.add(Severity.ERROR, retorno.getDescError());
		}
		varModif = Constantes.CONSTANTE_NO;
		//SMM: regresa a la pantalla anterior, bien BOLETAS o MANDPROD
		Conversation conversacion=Conversation.instance();
		conversacion.redirectToParent();		
	}
	
	/**
	 * Devuelve el campo importe de un tramo. Si no encuentra devuelve 0.
	 */
	private BigDecimal devolverNominal(Date fechaTratamiento,
			long numeroOperacion, Date fechaContratacion, Date fechaUltimaModi) {
		return cancelacionParcialBo.devolverNominal(fechaTratamiento, fechaContratacion, numeroOperacion, fechaUltimaModi);
	}
	
}
