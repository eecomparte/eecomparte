package com.atosorigin.deri.adminoper.cancelacionparcial.screen;

import java.math.BigDecimal;
import java.util.Date;

import org.jboss.seam.ScopeType;
import org.jboss.seam.annotations.Name;
import org.jboss.seam.annotations.Out;
import org.jboss.seam.annotations.Scope;

import com.atosorigin.deri.model.adminoper.CancelacionParcial;

@Name("cancelacionParcialPantalla")
@Scope(ScopeType.CONVERSATION)
public class CancelacionParcialPantalla {

	@Out(value = "cancelacionParcial", required = false)
	protected CancelacionParcial cancelacionParcial;
	
	/** Campos de Datos del supuesto */
	protected Date fechaValor;
	protected Date fechaLiquidacion;
	protected BigDecimal importeAmortizado;
	protected BigDecimal importe;
	protected BigDecimal nocionalRestante;
	protected String tipoPrima;
	protected String divisa;

	/** Fechas que retorna F_MODI_NCORRELA */
	protected Date fechaMod;
	protected Date fechaTra;
	
	/** booleana para mostrar el popup de confirmación */
	protected boolean ejecucionValida;
	
	public CancelacionParcial getCancelacionParcial() {
		return cancelacionParcial;
	}

	public Date getFechaValor() {
		return fechaValor;
	}

	public Date getFechaLiquidacion() {
		return fechaLiquidacion;
	}

	public BigDecimal getImporteAmortizado() {
		return importeAmortizado;
	}

	public BigDecimal getImporte() {
		return importe;
	}

	public BigDecimal getNocionalRestante() {
		return nocionalRestante;
	}

	public String getTipoPrima() {
		return tipoPrima;
	}

	public String getDivisa() {
		return divisa;
	}

	public void setCancelacionParcial(CancelacionParcial cancelacionParcial) {
		this.cancelacionParcial = cancelacionParcial;
	}

	public void setFechaValor(Date fechaValor) {
		this.fechaValor = fechaValor;
	}

	public void setFechaLiquidacion(Date fechaLiquidacion) {
		this.fechaLiquidacion = fechaLiquidacion;
	}

	public void setImporteAmortizado(BigDecimal importeAmortizado) {
		this.importeAmortizado = importeAmortizado;
	}

	public void setImporte(BigDecimal importe) {
		this.importe = importe;
	}

	public void setNocionalRestante(BigDecimal nocionalRestante) {
		this.nocionalRestante = nocionalRestante;
	}

	public void setTipoPrima(String tipoPrima) {
		this.tipoPrima = tipoPrima;
	}

	public void setDivisa(String divisa) {
		this.divisa = divisa;
	}

	public Date getFechaMod() {
		return fechaMod;
	}

	public void setFechaMod(Date fechaMod) {
		this.fechaMod = fechaMod;
	}

	public boolean isEjecucionValida() {
		return ejecucionValida;
	}

	public void setEjecucionValida(boolean ejecucionValida) {
		this.ejecucionValida = ejecucionValida;
	}

	public Date getFechaTra() {
		return fechaTra;
	}

	public void setFechaTra(Date fechaTra) {
		this.fechaTra = fechaTra;
	}

}
