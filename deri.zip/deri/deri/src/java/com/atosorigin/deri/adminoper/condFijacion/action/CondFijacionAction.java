package com.atosorigin.deri.adminoper.condFijacion.action;

import java.util.List;

import org.jboss.seam.ScopeType;
import org.jboss.seam.annotations.In;
import org.jboss.seam.annotations.Name;
import org.jboss.seam.annotations.Scope;

import com.atosorigin.common.action.PaginatedListAction;
import com.atosorigin.common.constantes.Constantes;
import com.atosorigin.common.formvalidator.FormValidator;
import com.atosorigin.deri.adminoper.condFijacion.business.CondFijacionBo;
import com.atosorigin.deri.adminoper.condFijacion.screen.CondFijacionPantalla;
import com.atosorigin.deri.model.adminoper.HistoricoExoticidadesIRS;
import com.atosorigin.deri.model.gestionoperaciones.HistoricoOperacion;
import com.atosorigin.deri.model.mercado.HistoricoTramos;

@Name("condFijacionAction")
@Scope(ScopeType.CONVERSATION)
@FormValidator
public class CondFijacionAction extends PaginatedListAction {

	// oO[Variables]Oo
	@In("#{condFijacionBo}")
	protected CondFijacionBo condFijacionBo;

	@In(create=true)
	protected CondFijacionPantalla condFijacionPantalla;

	@In
	private HistoricoOperacion historicoOperacion;
	@In(value = "tramoSelnou")
    protected HistoricoTramos tramoSeleccionado;	
	
	private HistoricoTramos historicoTram;
	
	
	// oO[Métodos]Oo
	@Override
	public List<?> getDataTableList() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	protected void refreshListInternal() {
		// TODO Auto-generated method stub
	}

	@Override
	public void refrescarListaExcel() {
		// TODO Auto-generated method stub
	}

	@Override
	public void setDataTableList(List<?> dataTableList) {
		// TODO Auto-generated method stub
	}
	
	/**
	 * Método que se ejecuta cada vez que se entra en la página
	 */
	public void mostrarListado(){
		//TODO ABC - Provisional hasta que esté creada MANTRAM
//		HistoricoOperacion historicoOpe = new HistoricoOperacion();
//		HistoricoOperacionId historicoOpeId = new HistoricoOperacionId();
//		this.setHistoricoTram(new HistoricoTramos());
//		HistoricoTramosId historicoTramId = new HistoricoTramosId();
//		DescripcionTipoOperacionHistderi descripcionTipoOperacionHistderi = new DescripcionTipoOperacionHistderi();
//		SimpleDateFormat sdf= new SimpleDateFormat("dd/MM/yyyy");
//		SimpleDateFormat sdfh= new SimpleDateFormat("dd/MM/yyyy HH:mm:ss");
//		try {
//			historicoOpeId.setFechaTratamiento(sdf.parse("10/05/2007"));
//			historicoOpeId.setNumeroOperacion(9612107696L);
//			historicoOpeId.setFechaContratacion(sdf.parse("12/02/2007"));
//			descripcionTipoOperacionHistderi.setCodigo("P");
//			historicoTramId.setTipoOperacion(descripcionTipoOperacionHistderi);
//			historicoOpeId.setFechaModificacion(sdfh.parse("10/05/2007 12:14:57"));
//			historicoTramId.setFechaFinTramo(sdf.parse("14/05/2010"));
//			historicoOpe.setFormulaPago(1022);
//			historicoOpe.setIndicePago(219L);
//		} catch (ParseException e) {
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//		}
		
//		historicoOpe.setId(historicoOpeId);
//		historicoTramId.setHistoricoOperacion(historicoOpe);
//		historicoTram.setId(historicoTramId);
//		condFijacionPantalla.setHistoricoExoticidadesIRSList(condFijacionBo.busqueda(historicoOpe, historicoTram));
		condFijacionPantalla.setHistoricoExoticidadesIRSList(condFijacionBo.busqueda(historicoOperacion, tramoSeleccionado));
	}
	
	/**
	 * Método que se ejecuta al salir de la página
	 */
	public void salir(){
		
	}
	
	/**
	 * Recupera el campo desc_indice
	 * @param codigoIndice
	 * @return
	 */
	public String obtenerDescIndice(String codigoIndice){
		return condFijacionBo.obtenerDescIndice(codigoIndice);
	}

	/**
	 * Recupera el campo "Supuesto" de la tabla
	 * @param codigoIndice
	 * @return
	 */
	public String obtenerDescSupuesto(HistoricoExoticidadesIRS historico){
		return condFijacionBo.obtenerDescripcionSupuesto(historico);
	}
	
	/**
	 * Recupera el campo "Tipo" de la tabla
	 * @param codIndice
	 * @return
	 */
	public String obtenerDescTipo(){
		String codIndice = "";
		
		if(this.tramoSeleccionado.getId().getHistoricoOperacion().getFormulaPago()!=null && 
		   this.tramoSeleccionado.getId().getHistoricoOperacion().getFormulaPago().getCodigoFormula().equals(1022)){
			codIndice = this.tramoSeleccionado.getId().getHistoricoOperacion().getIndicePago().getCodigo().toString();
		}else if(this.tramoSeleccionado.getId().getHistoricoOperacion().getFormulaRecibo()!=null &&
				 this.tramoSeleccionado.getId().getHistoricoOperacion().getFormulaRecibo().getCodigoFormula().equals(1022)){
			codIndice = this.tramoSeleccionado.getId().getHistoricoOperacion().getIndiceRecibo().getCodigo().toString();
		}
		
		codIndice = condFijacionBo.obtenerDescIndice(codIndice);
		
		if(codIndice.equals(Constantes.CODINDICE_E)){
			return Constantes.ECUACION;
		}else if(codIndice.equals(Constantes.CODINDICE_F)){
			return Constantes.FIJO;
		}else if(codIndice.equals(Constantes.CODINDICE_V)){
			return Constantes.VARIABLE;
		}else{
			//TODO ABC - mostrar_mensaje(CondFijacion.error.codigoIndice)
			return Constantes.DESCONOCIDO;
		}
	}
	
	//oO[Getters y Setters]Oo
	public CondFijacionBo getCondFijacionBo() {
		return condFijacionBo;
	}

	public void setCondFijacionBo(CondFijacionBo condFijacionBo) {
		this.condFijacionBo = condFijacionBo;
	}

	public void setHistoricoTram(HistoricoTramos historicoTram) {
		this.historicoTram = historicoTram;
	}

	public HistoricoTramos getHistoricoTram() {
		return historicoTram;
	}
}
