package com.atosorigin.deri.adminoper.condFijacion.action;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.List;

import javax.persistence.EntityManager;

import org.jboss.seam.ScopeType;
import org.jboss.seam.annotations.In;
import org.jboss.seam.annotations.Name;
import org.jboss.seam.annotations.Out;
import org.jboss.seam.annotations.Scope;
import org.jboss.seam.annotations.datamodel.DataModel;
import org.jboss.seam.annotations.datamodel.DataModelSelection;
import org.jboss.seam.core.Conversation;
import org.jboss.seam.core.ResourceBundle;
import org.jboss.seam.international.StatusMessage.Severity;
import org.jboss.seam.security.Identity;

import com.atosorigin.common.action.GenericAction;
import com.atosorigin.common.action.ModoPantalla;
import com.atosorigin.common.auditdata.AuditData;
import com.atosorigin.common.constantes.Constantes;
import com.atosorigin.common.formvalidator.FormValidator;
import com.atosorigin.common.utils.GenericUtils;
import com.atosorigin.deri.adminoper.boletas.action.BoletasAction.BoletasStates;
import com.atosorigin.deri.adminoper.boletas.action.BoletasAction.PagoCobroType;
import com.atosorigin.deri.adminoper.condFijacion.business.CondFijacionBo;
import com.atosorigin.deri.adminoper.condFijacion.screen.MantCondFijacionPantalla;
import com.atosorigin.deri.model.adminoper.HistoricoExoticidadesIRS;
import com.atosorigin.deri.model.adminoper.HistoricoExoticidadesIRSId;
import com.atosorigin.deri.model.gestionoperaciones.HistoricoOperacion;
import com.atosorigin.deri.util.EntityUtil;

@Name("mantCondFijacionAction")
@Scope(ScopeType.CONVERSATION)
@FormValidator(doRollback=false)
public class MantCondFijacionAction extends GenericAction {

	public static final String TIPO_OPERACION_P = "P";
	public static final String TIPO_OPERACION_C = "R";
	
	/**
	 * Inyección del bean de Spring "condFijacionBo"
	 */
	
	@In
	private EntityManager entityManager;
	
	@In("#{condFijacionBo}")
	protected CondFijacionBo condFijacionBo;
	
	@In(value="EntityUtil", create = true)
	private EntityUtil entityUtil;
	/**
	 * Inyección del screen bean que contiene los datos de pantalla del caso de
	 * uso de mantenimiento de subyacentes
	 */
	@In(create = true)
	protected MantCondFijacionPantalla mantCondFijacionPantalla;
	
	@In(required=false)
	private PagoCobroType fijacionPagoCobroType;

	/** Inyección del objeto padre de Boletas, en este caso HistoricoOperacion */
	@In(required=false)
	protected HistoricoOperacion historicoOperacion;
	@In(required=true)
	private BoletasStates boletaState;
	
	
	
	/** Lista de datos para el grid. */
	@DataModel(value = "listaDtCondicionesFijacion")
	protected List<HistoricoExoticidadesIRS> historicoExoticidadesList;

	/** Registro seleccionado en el grid */
	@DataModelSelection(value = "listaDtCondicionesFijacion")
	protected HistoricoExoticidadesIRS historicoExoticidadesIRSSelect;

	@Out(value = "historicoExoticidadesIRS", required = false)
	protected HistoricoExoticidadesIRS historicoExoticidadesIRS;

	
	/**
	 * Función a la que se debe llamar desde boletas para acceder a la pantalla de 
	 * mantenimiento de subyacentes.
	 * @return
	 */
	public String irMantenimientoCondFijacion(){
		//Cargamos en pantalla la lista de historicosubyacentes del historicoOperacion que viene de boletas
		cargarGrid();
		
		/* RBS: 23/03/2010 Según el analista cuando llaman a esta pantalla ya se le pasa por parámetro
		 el TIPOPERA que nos indica la 'pata', P de pago o R de recibo o Cobro. Asi que en aquellos
		 casos en que tengan las dos patas, al programa le llegará una sola, la que le envie la boleta
		 y ésta ya se cuidará de enviarle la “pata” adecuada*/
		if (fijacionPagoCobroType==PagoCobroType.ES_PAGO){
			mantCondFijacionPantalla.setCodindic(historicoOperacion.getIndicePago().getCodigo().toString());
		} else if (fijacionPagoCobroType==PagoCobroType.ES_COBRO) {
			mantCondFijacionPantalla.setCodindic(historicoOperacion.getIndiceRecibo().getCodigo().toString());
		}
		
		return Constantes.CONSTANTE_SUCCESS;
	}
	
	private void cargarGrid(){
		
		this.setPrimerAcceso(false);
		historicoExoticidadesList = new ArrayList(historicoOperacion.getHistoricoExoticidadesIRSs());
		Collections.sort(historicoExoticidadesList, new Comparator<HistoricoExoticidadesIRS>() {

			public int compare(HistoricoExoticidadesIRS o1,
					HistoricoExoticidadesIRS o2) {
				int result = o1.getInicioCondicion().compareTo(o2.getInicioCondicion());
				if(result!=0){
					return result;
				}
				result = o1.getFinCondicion().compareTo(o2.getFinCondicion());
				if(result!=0){
					return result;
				}
				result = o1.getId().getNumeroOrden().compareTo(o2.getId().getNumeroOrden());
				if(result!=0){
					return result;
				}
				return 0;
			}
		});
	}
	
	/**
	 * Obtiene la descripción del supuesto para la pantalla de detalle
	 */
	public String obtenerDescripcionIndice(){
		
		String retorno = Constantes.CADENA_VACIA;
		
		if(!GenericUtils.isNullOrBlank(mantCondFijacionPantalla.getCodindic())){
			retorno = condFijacionBo.obtenerDescIndice(mantCondFijacionPantalla.getCodindic());
		}
		
		return retorno;
	}
	
	/**
	 * Genera el string para el campo "supuesto" del grid 
	 */
	public String obtenerDescripcionSupuesto(HistoricoExoticidadesIRS histo){
		
		StringBuffer descripcion = new StringBuffer();
		String espacio = " ";
		
		if (GenericUtils.isNullOrBlank(histo.getInicioCondicion())){
			descripcion.append(Constantes.CADENA_VACIA);
		} else {
			
			String tipoSup1 = Constantes.CADENA_VACIA;
			String tipoSup2 = Constantes.CADENA_VACIA;
			String descIndice = condFijacionBo.obtenerDescIndice(mantCondFijacionPantalla.getCodindic());
			
			if(!GenericUtils.isNullOrBlank(histo.getPorcentajeSupuesto1())){
				tipoSup1 = String.valueOf(histo.getPorcentajeSupuesto1());
			}
			
			if(!GenericUtils.isNullOrBlank(histo.getPorcentajeSupuesto2())){
				tipoSup2 = String.valueOf(histo.getPorcentajeSupuesto2());
			}
			
			descripcion.append(descIndice);
			descripcion.append(espacio);
			descripcion.append(histo.getOperadorSupuesto1());
			descripcion.append(espacio);
			descripcion.append(tipoSup1);
			
			if(!GenericUtils.isNullOrBlank(histo.getRelacionSupuestos())){
				
				descripcion.append(espacio);
				descripcion.append(histo.getRelacionSupuestos());
				descripcion.append(espacio);
				descripcion.append(histo.getOperadorSupuesto2());
				descripcion.append(espacio);
				descripcion.append(tipoSup2);
			}
		}		
		
		return descripcion.toString();
	}
	
	/**
	 * Genera el string para el campo "tipo operación" del grid 
	 */
	public String obtenerTipoOperacion(String tipoOper){
		
		String desc = Constantes.CADENA_VACIA;
		
//		if (TIPO_OPERACION_P.equals(tipoOper)){
//			desc = ResourceBundle.instance().getString("mantcondfijacion.tipo.pago");
//		} else if (TIPO_OPERACION_C.equals(tipoOper)) {
//			desc = ResourceBundle.instance().getString("mantcondfijacion.tipo.cobro");
//		} 
		if("F".equals(tipoOper)){
			return ResourceBundle.instance().getString("mantcondfijacion.tipocondicion.fijo");
		}
		if("V".equals(tipoOper)){
			return ResourceBundle.instance().getString("mantcondfijacion.tipocondicion.variable");
		}
		if("E".equals(tipoOper)){
			return ResourceBundle.instance().getString("mantcondfijacion.tipocondicion.ecuacion");
		}
		if("N".equals(tipoOper)){
			return ResourceBundle.instance().getString("mantcondfijacion.tipocondicion.nominal");
		}

		return desc;
	}
	
	/**
	 * Siempre que se modifique el campo de relacionSupuesto hacer lo siguiente:
	 * Si relacionSupuesto es NULL, informar a NULL los campos descripcion supuesto 2, 
	 * operadorSupuesto2 y porcentajeSupuesto2. Desactivar los campos operadorSupuesto2 y porcentajeSupuesto2.
	 * Si relacionSupuesto no es NULL, activar los campos operadorSupuesto2 y porcentajeSupuesto2.
	 */
	public void cambiarRelacSupuesto(){
		
		if(GenericUtils.isNullOrBlank(mantCondFijacionPantalla.getRelacionSupuestos())){
			mantCondFijacionPantalla.setOper2(null);
			mantCondFijacionPantalla.setPorcentaje2(null);
			mantCondFijacionPantalla.setSupuesto2Habilitado(false);
			mantCondFijacionPantalla.setMostrarSupuesto2(false);
		} else {
			mantCondFijacionPantalla.setSupuesto2Habilitado(true);
			mantCondFijacionPantalla.setMostrarSupuesto2(true);
		}
	}
	
	/**
	 * Función que se invoca cada vez que el usuario cambia la selección en los
	 * radiobutton de tipo condición en la pantalla de detalle
	 */
	public void modificarRadioTipoCond(){
		
		String tipo = mantCondFijacionPantalla.getTipoCondicion();
		
		habilitarCampos(tipo); //Habilitamos o deshabilitamos los campos del formulario
		
		//Vacíamos los campos en función del tipo de condición
		if ("F".equals(tipo)){
			mantCondFijacionPantalla.setSpread(null);
			mantCondFijacionPantalla.setSigno(null);
			mantCondFijacionPantalla.setMultiplicador(null);
			mantCondFijacionPantalla.setRangsup(null);
			mantCondFijacionPantalla.setRanginf(null);
			mantCondFijacionPantalla.setTipoFijo2(null);
			mantCondFijacionPantalla.setMultiplicador2(null);
		} else if("V".equals(tipo)){
			mantCondFijacionPantalla.setTipoFijo(null);
			mantCondFijacionPantalla.setMultiplicador(null);
			mantCondFijacionPantalla.setRangsup(null);
			mantCondFijacionPantalla.setRanginf(null);
			mantCondFijacionPantalla.setTipoFijo2(null);
			mantCondFijacionPantalla.setMultiplicador2(null);
		} else if("N".equals(tipo)){
			mantCondFijacionPantalla.setTipoFijo(null);
			mantCondFijacionPantalla.setSpread(null);
			mantCondFijacionPantalla.setSigno(null);
			mantCondFijacionPantalla.setMultiplicador(null);
			mantCondFijacionPantalla.setRangsup(null);
			mantCondFijacionPantalla.setRanginf(null);
			mantCondFijacionPantalla.setTipoFijo2(null);
			mantCondFijacionPantalla.setMultiplicador2(null);
		}
	}
	
	/**
	 * Borra un historicoExocitidad
	 */
	public void borrar(){
		historicoExoticidadesList.remove(historicoExoticidadesIRSSelect);
		historicoOperacion.getHistoricoExoticidadesIRSs().remove(historicoExoticidadesIRSSelect);
		flush();
	
	}

	private boolean flush() {
		try {
			entityManager.flush();
			return true;
		} catch (Exception e) {
			statusMessages.add(Severity.ERROR, e.getMessage());
			return false;
		}
	}
	
	/**
	 * Prepara para la modificación de un historicoExocitidad
	 */
	public void editar(){
		this.setModoPantalla(ModoPantalla.EDICION);
		historicoExoticidadesIRS = historicoExoticidadesIRSSelect;
		this.mantCondFijacionPantalla.setSupuesto2Habilitado(!GenericUtils.isNullOrBlank(historicoExoticidadesIRS.getRelacionSupuestos()));
		mantCondFijacionPantalla.setMostrarSupuesto2(!GenericUtils.isNullOrBlank(historicoExoticidadesIRS.getRelacionSupuestos()));
		beanToForm();
	}
	
	/**
	 * Prepara para la inspección de un historicoExocitidad 
	 */
	public void ver(){
		this.setModoPantalla(ModoPantalla.INSPECCION);
		historicoExoticidadesIRS = historicoExoticidadesIRSSelect;
		mantCondFijacionPantalla.setSupuesto2Habilitado(false);
		mantCondFijacionPantalla.setMostrarSupuesto2(!GenericUtils.isNullOrBlank(historicoExoticidadesIRS.getRelacionSupuestos()));
		beanToForm();
	}
	
	/**
	 * Prepara para el alta de un historicoExocitidad 
	 */
	public void nuevo(){
		this.setModoPantalla(ModoPantalla.CREACION);
		
		HistoricoExoticidadesIRSId idNuevo = new HistoricoExoticidadesIRSId(
						this.historicoOperacion,
						fijacionPagoCobroType.getCodigo(),
						Short.valueOf("0")); //Inicializamos a 0 pero más adelante al guardar le asignamos el valor adecuado
		HistoricoExoticidadesIRS histoNuevo = new HistoricoExoticidadesIRS(idNuevo,
				null, null, null, null, null, null, null, null, "F", null, //por defecto tipo condición es Fijo
				null, null, null, null, Identity.instance().getCredentials().getUsername());
		
		historicoExoticidadesIRS = histoNuevo;
		mantCondFijacionPantalla.setSupuesto2Habilitado(false);
		mantCondFijacionPantalla.setMostrarSupuesto2(false);
		beanToForm();
	}
	
	/**
	 * Validaciones previas al alta/edición de un nuevo registro
	 */
	public boolean guardarValidator(){
		
		boolean esCorrecto = true;
		
		Date fechaIni = mantCondFijacionPantalla.getFechaDesde();
		Date fechaFin = mantCondFijacionPantalla.getFechaHasta();
		
		//Fecha fin inferior a fecha inicio del supuesto
		long diffFechaFinIni = (fechaFin.getTime() - fechaIni.getTime())/86400000L;
		
		if(diffFechaFinIni < 0){
			esCorrecto = false;
			statusMessages.addToControl("fFinTxt", Severity.ERROR, "#{messages['mantcondfijacion.error.fechas']}");
		}
		
		//Las fechas inicio o fin de supuesto no coinciden con alguna fecha inicio o fin de los tramos
		 boolean existenFechas = condFijacionBo.existenFechasTramosCoinci(this.historicoOperacion,
				fijacionPagoCobroType.getCodigo(),
				fechaIni,
				fechaFin);
		 
		 if(!existenFechas){
			 esCorrecto = false;
			 statusMessages.addToControl("fInicioTxt", Severity.ERROR, "#{messages['mantcondfijacion.error.fechas.tramos']}");
		 }
		
		//Si tipo supuesto = V, no es necesario informar el signo y spread, aunque si alguno de los 2 
		//está informado, entonces es obligado informar el otro
		if ("V".equalsIgnoreCase(mantCondFijacionPantalla.getTipoCondicion())) {
			boolean spreadInformado = !GenericUtils.isNullOrBlank(mantCondFijacionPantalla.getSpread());
			boolean signoInformado = !GenericUtils.isNullOrBlank(mantCondFijacionPantalla.getSigno());
			if (spreadInformado && !signoInformado) {
				esCorrecto = false;
				statusMessages.addToControl("signoCmb", Severity.ERROR,"#{messages['mantcondfijacion.error.signo']}");
			} else if (!spreadInformado && signoInformado) {
				esCorrecto = false;
				statusMessages.addToControl("spreadTxt", Severity.ERROR,"#{messages['mantcondfijacion.error.spread']}");
			}
		}
		
		//El valor introducido en spread debe ser positivo siempre
		if(!GenericUtils.isNullOrBlank(mantCondFijacionPantalla.getSpread())){
			int signo = mantCondFijacionPantalla.getSpread().signum();
			if(signo < 0){
				esCorrecto = false;
				statusMessages.addToControl("spreadTxt", Severity.ERROR,"#{messages['mantcondfijacion.error.spread.negativo']}");
			}
		}
		
		//Validamos en formato los campos numéricos
		if (!validaFormatoNumericos()){
			esCorrecto = false;
		}
		
		return esCorrecto;
		
	}

	public void salirDetalle(){
		Conversation conversacion=Conversation.instance();
		conversacion.redirectToParent();
	}
	
	
	/**
	 * Guarda o actualiza un registro en base de datos (no hace commit)
	 */
	public String guardar(){
		
		// Cargamos los valores del form en el objeto tratado
		formToBean();
		
		//Asignamos auditData
		HistoricoExoticidadesIRS registroTratado = historicoExoticidadesIRS;
		AuditData auditData = new AuditData();
		auditData.setFechaUltimaModi(new Date());
		auditData.setUsuarioUltimaModi(Identity.instance().getCredentials().getUsername());
		registroTratado.setAuditData(auditData);
		registroTratado.setUsuario(Identity.instance().getCredentials().getUsername());
		
		if (ModoPantalla.CREACION.equals(this.modoPantalla)) {
			//Asignamos numorden
			short numeroOrden = condFijacionBo.obtenerNumeroSiguiente(this.historicoOperacion);
			registroTratado.getId().setNumeroOrden(numeroOrden);
			
			//Damos de alta, añadimos el nuevo registro a la lista que nos viene de boletas
			//mantCondFijacionPantalla.getHistoricoExoticidadesList().add(registroTratado);
			this.historicoOperacion.getHistoricoExoticidadesIRSs().add(registroTratado);
			//entityManager.persist(registroTratado);			
		} //Si es modificación no hay que hacer nada, ya están actualizados los valores en el registro

		//FLM: Debemos guardar
		if(!flush()){
			return Constantes.FAIL;
		}
		Conversation conversacion=Conversation.instance();
		conversacion.redirectToParent();
		return Constantes.CONSTANTE_SUCCESS;
	}
	
	/**
	 * Habilita o deshabilita los campos del panel de tipo de supuesto en función del
	 * tipo seleccionado
	 */
	private void habilitarCampos (String tipoCond){
		
		if("E".equalsIgnoreCase(tipoCond)){
			mantCondFijacionPantalla.setTipofijoDisabled(false);
			mantCondFijacionPantalla.setSignoDisabled(false);
			mantCondFijacionPantalla.setSpreadvaDisabled(false);
			mantCondFijacionPantalla.setMultipliDisabled(false);
			mantCondFijacionPantalla.setRangsupDisabled(false);
			mantCondFijacionPantalla.setRanginfDisabled(false);
			mantCondFijacionPantalla.setTipofijo2Disabled(true);
			mantCondFijacionPantalla.setMultipli2Disabled(true);
		} else if ("F".equals(tipoCond)){
			mantCondFijacionPantalla.setTipofijoDisabled(false);
			mantCondFijacionPantalla.setSignoDisabled(true);
			mantCondFijacionPantalla.setSpreadvaDisabled(true);
			mantCondFijacionPantalla.setMultipliDisabled(true);
			mantCondFijacionPantalla.setRangsupDisabled(true);
			mantCondFijacionPantalla.setRanginfDisabled(true);
			mantCondFijacionPantalla.setTipofijo2Disabled(true);
			mantCondFijacionPantalla.setMultipli2Disabled(true);
		} else if("V".equals(tipoCond)){
			mantCondFijacionPantalla.setTipofijoDisabled(true);
			mantCondFijacionPantalla.setSignoDisabled(false);
			mantCondFijacionPantalla.setSpreadvaDisabled(false);
			mantCondFijacionPantalla.setMultipliDisabled(true);
			mantCondFijacionPantalla.setRangsupDisabled(true);
			mantCondFijacionPantalla.setRanginfDisabled(true);
			mantCondFijacionPantalla.setTipofijo2Disabled(true);
			mantCondFijacionPantalla.setMultipli2Disabled(true);
		} else if("N".equals(tipoCond)){
			mantCondFijacionPantalla.setTipofijoDisabled(true);
			mantCondFijacionPantalla.setSignoDisabled(true);
			mantCondFijacionPantalla.setSpreadvaDisabled(true);
			mantCondFijacionPantalla.setMultipliDisabled(true);
			mantCondFijacionPantalla.setRangsupDisabled(true);
			mantCondFijacionPantalla.setRanginfDisabled(true);
			mantCondFijacionPantalla.setTipofijo2Disabled(false);
			mantCondFijacionPantalla.setMultipli2Disabled(false);
		}
	}
	
	/**
	 * Valida que los valores númericos cumplan que tengan máximo 17 cifras y 12 decimales
	 * return true si todos lo cumplen
	 */
	private boolean validaFormatoNumericos() {
		
		boolean esCorrecto = true;
		
		if(!GenericUtils.isNullOrBlank(mantCondFijacionPantalla.getTipoFijo())
				&& !GenericUtils.validaFormatoDecimal(mantCondFijacionPantalla.getTipoFijo(), 17, 12)){
			esCorrecto = false;
			statusMessages.addToControl("precFijoTxt", Severity.ERROR,"#{messages['mantcondfijacion.error.formato.numerico']}");
		}
		
		if(!GenericUtils.isNullOrBlank(mantCondFijacionPantalla.getTipoFijo2())
				&& !GenericUtils.validaFormatoDecimal(mantCondFijacionPantalla.getTipoFijo2(), 17, 12)){
			esCorrecto = false;
			statusMessages.addToControl("precFijo2Txt", Severity.ERROR,"#{messages['mantcondfijacion.error.formato.numerico']}");
		}
		
		if(!GenericUtils.isNullOrBlank(mantCondFijacionPantalla.getSpread())
				&& !GenericUtils.validaFormatoDecimal(mantCondFijacionPantalla.getSpread(), 17, 12)){
			esCorrecto = false;
			statusMessages.addToControl("spreadTxt", Severity.ERROR,"#{messages['mantcondfijacion.error.formato.numerico']}");
		}
		
		if(!GenericUtils.isNullOrBlank(mantCondFijacionPantalla.getMultiplicador())
				&& !GenericUtils.validaFormatoDecimal(mantCondFijacionPantalla.getMultiplicador(), 17, 12)){
			esCorrecto = false;
			statusMessages.addToControl("multiplicadortxt", Severity.ERROR,"#{messages['mantcondfijacion.error.formato.numerico']}");
		}
		
		if(!GenericUtils.isNullOrBlank(mantCondFijacionPantalla.getRangsup())
				&& !GenericUtils.validaFormatoDecimal(mantCondFijacionPantalla.getRangsup(), 17, 12)){
			esCorrecto = false;
			statusMessages.addToControl("rangoSupTxt", Severity.ERROR,"#{messages['mantcondfijacion.error.formato.numerico']}");
		}
		
		if(!GenericUtils.isNullOrBlank(mantCondFijacionPantalla.getRanginf())
				&& !GenericUtils.validaFormatoDecimal(mantCondFijacionPantalla.getRanginf(), 17, 12)){
			esCorrecto = false;
			statusMessages.addToControl("rangoInfTxt", Severity.ERROR,"#{messages['mantcondfijacion.error.formato.numerico']}");
		}
		
		if(!GenericUtils.isNullOrBlank(mantCondFijacionPantalla.getMultiplicador2())
				&& !GenericUtils.validaFormatoDecimal(mantCondFijacionPantalla.getMultiplicador2(), 17, 12)){
			esCorrecto = false;
			statusMessages.addToControl("porcNominalTxt", Severity.ERROR,"#{messages['mantcondfijacion.error.formato.numerico']}");
		}
		
		if(!GenericUtils.validaFormatoDecimal(mantCondFijacionPantalla.getPorcentaje1(), 17, 12)){
			esCorrecto = false;
			statusMessages.addToControl("porc1Txt", Severity.ERROR,"#{messages['mantcondfijacion.error.formato.numerico']}");
		}
		
		if(!GenericUtils.isNullOrBlank(mantCondFijacionPantalla.getPorcentaje2())
				&& !GenericUtils.validaFormatoDecimal(mantCondFijacionPantalla.getPorcentaje2(), 17, 12)){
			esCorrecto = false;
			statusMessages.addToControl("porc2Txt", Severity.ERROR,"#{messages['mantcondfijacion.error.formato.numerico']}");
		}
		
		return esCorrecto;
	}
	
	/**
	 * Carga los valores del form correspondienteas a Tipo Supuesto en el registro tratado
	 */
	private void formToBean(){
	
		HistoricoExoticidadesIRS registroTratado = historicoExoticidadesIRS;
		
		//rellenamos valores datos del supuesto
		registroTratado.setInicioCondicion(mantCondFijacionPantalla.getFechaDesde());
		registroTratado.setFinCondicion(mantCondFijacionPantalla.getFechaHasta());
		registroTratado.setOperadorSupuesto1(mantCondFijacionPantalla.getOper1());
		registroTratado.setPorcentajeSupuesto1(mantCondFijacionPantalla.getPorcentaje1());
		registroTratado.setRelacionSupuestos(mantCondFijacionPantalla.getRelacionSupuestos());
		registroTratado.setOperadorSupuesto2(mantCondFijacionPantalla.getOper2());
		registroTratado.setPorcentajeSupuesto2(mantCondFijacionPantalla.getPorcentaje2());
		
		//rellenamos valores tipo del supuesto 
		String tipoCondicion = mantCondFijacionPantalla.getTipoCondicion();
		registroTratado.setTipoCondicion(tipoCondicion);
				
		if("N".equals(tipoCondicion)){
			registroTratado.setTipoFijo(mantCondFijacionPantalla.getTipoFijo2());
			registroTratado.setMultiplicador(mantCondFijacionPantalla.getMultiplicador2());
		} else {
			registroTratado.setTipoFijo(mantCondFijacionPantalla.getTipoFijo());
			registroTratado.setMultiplicador(mantCondFijacionPantalla.getMultiplicador());
		}
		
		if("-".equals(mantCondFijacionPantalla.getSigno()) && mantCondFijacionPantalla.getSpread()!=null){
			registroTratado.setSpread(mantCondFijacionPantalla.getSpread().negate());
		} else {
			registroTratado.setSpread(mantCondFijacionPantalla.getSpread());
		}
		
		registroTratado.setRangoSuperior(mantCondFijacionPantalla.getRangsup());
		registroTratado.setRangoInferior(mantCondFijacionPantalla.getRanginf());
		
	}
	
	/**
	 * Carga los valores del registro correspondienteas a Tipo Supuesto en el formulario de detalle
	 */
	private void beanToForm() {
	
		clearPantalla(); //limpiamos el form de la pantalla para eliminar valores de registros anteriores
		
		HistoricoExoticidadesIRS registroTratado = historicoExoticidadesIRS;
		
		//rellenamos campos datos del supuesto
		mantCondFijacionPantalla.setFechaDesde(registroTratado.getInicioCondicion());
		mantCondFijacionPantalla.setFechaHasta(registroTratado.getFinCondicion());
		mantCondFijacionPantalla.setOper1(registroTratado.getOperadorSupuesto1());
		mantCondFijacionPantalla.setPorcentaje1(registroTratado.getPorcentajeSupuesto1());
		String relacion = registroTratado.getRelacionSupuestos();
		
		if(!GenericUtils.isNullOrBlank(relacion)){
			mantCondFijacionPantalla.setRelacionSupuestos(relacion);
			mantCondFijacionPantalla.setOper2(registroTratado.getOperadorSupuesto2());
			mantCondFijacionPantalla.setPorcentaje2(registroTratado.getPorcentajeSupuesto2());
		}
		
		//rellenamos campos tipo del supuesto
		String tipoCondicion = registroTratado.getTipoCondicion();
		habilitarCampos(tipoCondicion); // habilitamos los campos correspondientes
		mantCondFijacionPantalla.setTipoCondicion(tipoCondicion);
		
		if("F".equals(tipoCondicion)){
			mantCondFijacionPantalla.setTipoFijo(registroTratado.getTipoFijo());
		}
		
		if("V".equals(tipoCondicion)){
			if(!GenericUtils.isNullOrBlank(registroTratado.getSpread())){
				if(registroTratado.getSpread().signum() == -1){
					mantCondFijacionPantalla.setSigno("-");
					mantCondFijacionPantalla.setSpread(registroTratado.getSpread().negate());
				} else {
					mantCondFijacionPantalla.setSigno("+");
					mantCondFijacionPantalla.setSpread(registroTratado.getSpread());
				}
			} else {
				mantCondFijacionPantalla.setSpread(null);
				mantCondFijacionPantalla.setSigno(null);
			}
		}
		
		if("E".equals(tipoCondicion)){
			
			mantCondFijacionPantalla.setTipoFijo(registroTratado.getTipoFijo());
			
			if(!GenericUtils.isNullOrBlank(registroTratado.getSpread())){
				if(registroTratado.getSpread().signum() == -1){
					mantCondFijacionPantalla.setSigno("-");
					mantCondFijacionPantalla.setSpread(registroTratado.getSpread().negate());
				} else {
					mantCondFijacionPantalla.setSigno("+");
					mantCondFijacionPantalla.setSpread(registroTratado.getSpread());
				}
			} else {
				mantCondFijacionPantalla.setSpread(null);
				mantCondFijacionPantalla.setSigno(null);
			}
			
			mantCondFijacionPantalla.setRangsup(registroTratado.getRangoSuperior());
			mantCondFijacionPantalla.setRanginf(registroTratado.getRangoInferior());
			mantCondFijacionPantalla.setMultiplicador(registroTratado.getMultiplicador());
		}
		
		if("N".equals(tipoCondicion)){
			mantCondFijacionPantalla.setTipoFijo2(registroTratado.getTipoFijo());
			mantCondFijacionPantalla.setMultiplicador2(registroTratado.getTipoFijo());
		}
	}
	
	/**
	 * Limpia todos los campos de la pantalla de detalle para que no se queden guardados valores
	 * de registros anteriormente editados
	 */
	private void clearPantalla(){

		mantCondFijacionPantalla.setOper2(null);
		mantCondFijacionPantalla.setPorcentaje2(null);
		mantCondFijacionPantalla.setRelacionSupuestos(null);
		mantCondFijacionPantalla.setTipoFijo(null);
		mantCondFijacionPantalla.setSpread(null);
		mantCondFijacionPantalla.setMultiplicador(null);
		mantCondFijacionPantalla.setRangsup(null);
		mantCondFijacionPantalla.setRanginf(null);
		mantCondFijacionPantalla.setTipoFijo2(null);
		mantCondFijacionPantalla.setMultiplicador2(null);
	
	}

	public BoletasStates getBoletaState() {
		return boletaState;
	}

	public void setBoletaState(BoletasStates boletaState) {
		this.boletaState = boletaState;
	}
}
