package com.atosorigin.deri.adminoper.condFijacion.screen;

import java.util.List;

import org.jboss.seam.ScopeType;
import org.jboss.seam.annotations.Name;
import org.jboss.seam.annotations.Scope;
import org.jboss.seam.annotations.datamodel.DataModel;

import com.atosorigin.deri.model.adminoper.HistoricoExoticidadesIRS;

@Name("condFijacionPantalla")
@Scope(ScopeType.CONVERSATION)
public class CondFijacionPantalla {

	// oO[Variables]Oo
	protected Long numFilas = 0L;
	
	@DataModel(value ="listaDtCondFijacion")
	protected List<HistoricoExoticidadesIRS> historicoExoticidadesIRSList;


	// oO[Getters y Setters]Oo
	public Long getNumFilas() {
		return numFilas;
	}

	public void setNumFilas(Long numFilas) {
		this.numFilas = numFilas;
	}

	public List<HistoricoExoticidadesIRS> getHistoricoExoticidadesIRSList() {
		return historicoExoticidadesIRSList;
	}

	public void setHistoricoExoticidadesIRSList(
			List<HistoricoExoticidadesIRS> historicoExoticidadesIRSList) {
		this.historicoExoticidadesIRSList = historicoExoticidadesIRSList;
	}
		
}
