package com.atosorigin.deri.adminoper.condFijacion.screen;

import java.math.BigDecimal;
import java.util.Date;

import org.jboss.seam.ScopeType;
import org.jboss.seam.annotations.Name;
import org.jboss.seam.annotations.Scope;

@Name("mantCondFijacionPantalla")
@Scope(ScopeType.CONVERSATION)
public class MantCondFijacionPantalla {

	
	/** Parametros recibidos desde boletas */
//	protected String opcion;
//	protected String tipoOperacion;
	protected String codindic;
	
	/** Parametros necesarios de la pantalla de detalle */
	protected String signo;
	protected boolean supuesto2Habilitado;
	protected boolean mostrarSupuesto2;
	
	/** Booleanas para deshabilitar campos de tipo supuesto */
	protected boolean tipofijoDisabled;
	protected boolean signoDisabled;
	protected boolean spreadvaDisabled;
	protected boolean multipliDisabled;
	protected boolean rangsupDisabled;
	protected boolean ranginfDisabled;
	protected boolean tipofijo2Disabled;
	protected boolean multipli2Disabled;
	
	/** Campos de Datos del supuesto */
	protected Date fechaDesde;
	protected Date fechaHasta;
	protected String oper1;
	protected String oper2;
	protected BigDecimal porcentaje1;
	protected BigDecimal porcentaje2;
	protected String relacionSupuestos;
	
	/** Campos de tipo del supuesto */
	protected BigDecimal tipoFijo;
	protected BigDecimal spread;
	protected BigDecimal multiplicador;
	protected BigDecimal rangsup;
	protected BigDecimal ranginf;
	protected BigDecimal tipoFijo2;
	protected BigDecimal multiplicador2;
	protected String tipoCondicion;
	


//	public String getOpcion() {
//		return opcion;
//	}
//
//	public String getTipoOperacion() {
//		return tipoOperacion;
//	}
//
//	public void setOpcion(String opcion) {
//		this.opcion = opcion;
//	}
//
//	public void setTipoOperacion(String tipoOperacion) {
//		this.tipoOperacion = tipoOperacion;
//	}

//	public HistoricoOperacion getHistOperMadre() {
//		return histOperMadre;
//	}
//
//	public void setHistOperMadre(HistoricoOperacion histOperMadre) {
//		this.histOperMadre = histOperMadre;
//	}

//	public String getCodindic() {
//		return codindic;
//	}
//
//	public void setCodindic(String codindic) {
//		this.codindic = codindic;
//	}

	public boolean isSupuesto2Habilitado() {
		return supuesto2Habilitado;
	}

	public void setSupuesto2Habilitado(boolean supuesto2Habilitado) {
		this.supuesto2Habilitado = supuesto2Habilitado;
	}

	public boolean isTipofijoDisabled() {
		return tipofijoDisabled;
	}

	public boolean isSignoDisabled() {
		return signoDisabled;
	}

	public boolean isSpreadvaDisabled() {
		return spreadvaDisabled;
	}

	public boolean isMultipliDisabled() {
		return multipliDisabled;
	}

	public boolean isRangsupDisabled() {
		return rangsupDisabled;
	}

	public boolean isRanginfDisabled() {
		return ranginfDisabled;
	}

	public boolean isTipofijo2Disabled() {
		return tipofijo2Disabled;
	}

	public boolean isMultipli2Disabled() {
		return multipli2Disabled;
	}

	public void setTipofijoDisabled(boolean tipofijoDisabled) {
		this.tipofijoDisabled = tipofijoDisabled;
	}

	public void setSignoDisabled(boolean signoDisabled) {
		this.signoDisabled = signoDisabled;
	}

	public void setSpreadvaDisabled(boolean spreadvaDisabled) {
		this.spreadvaDisabled = spreadvaDisabled;
	}

	public void setMultipliDisabled(boolean multipliDisabled) {
		this.multipliDisabled = multipliDisabled;
	}

	public void setRangsupDisabled(boolean rangsupDisabled) {
		this.rangsupDisabled = rangsupDisabled;
	}

	public void setRanginfDisabled(boolean ranginfDisabled) {
		this.ranginfDisabled = ranginfDisabled;
	}

	public void setTipofijo2Disabled(boolean tipofijo2Disabled) {
		this.tipofijo2Disabled = tipofijo2Disabled;
	}

	public void setMultipli2Disabled(boolean multipli2Disabled) {
		this.multipli2Disabled = multipli2Disabled;
	}

	public BigDecimal getTipoFijo() {
		return tipoFijo;
	}

	public BigDecimal getSpread() {
		return spread;
	}

	public BigDecimal getMultiplicador() {
		return multiplicador;
	}

	public BigDecimal getRangsup() {
		return rangsup;
	}

	public BigDecimal getRanginf() {
		return ranginf;
	}

	public BigDecimal getTipoFijo2() {
		return tipoFijo2;
	}

	public BigDecimal getMultiplicador2() {
		return multiplicador2;
	}

	public void setTipoFijo(BigDecimal tipoFijo) {
		this.tipoFijo = tipoFijo;
	}

	public void setSpread(BigDecimal spread) {
		this.spread = spread;
	}

	public void setMultiplicador(BigDecimal multiplicador) {
		this.multiplicador = multiplicador;
	}

	public void setRangsup(BigDecimal rangsup) {
		this.rangsup = rangsup;
	}

	public void setRanginf(BigDecimal ranginf) {
		this.ranginf = ranginf;
	}

	public void setTipoFijo2(BigDecimal tipoFijo2) {
		this.tipoFijo2 = tipoFijo2;
	}

	public void setMultiplicador2(BigDecimal multiplicador2) {
		this.multiplicador2 = multiplicador2;
	}

	public String getTipoCondicion() {
		return tipoCondicion;
	}

	public void setTipoCondicion(String tipoCondicion) {
		this.tipoCondicion = tipoCondicion;
	}

	public String getSigno() {
		return signo;
	}

	public void setSigno(String signo) {
		this.signo = signo;
	}

	public Date getFechaDesde() {
		return fechaDesde;
	}

	public Date getFechaHasta() {
		return fechaHasta;
	}

	public String getOper1() {
		return oper1;
	}

	public String getOper2() {
		return oper2;
	}

	public String getRelacionSupuestos() {
		return relacionSupuestos;
	}

	public void setFechaDesde(Date fechaDesde) {
		this.fechaDesde = fechaDesde;
	}

	public void setFechaHasta(Date fechaHasta) {
		this.fechaHasta = fechaHasta;
	}

	public void setOper1(String oper1) {
		this.oper1 = oper1;
	}

	public void setOper2(String oper2) {
		this.oper2 = oper2;
	}

	public void setRelacionSupuestos(String relacionSupuestos) {
		this.relacionSupuestos = relacionSupuestos;
	}

	public BigDecimal getPorcentaje1() {
		return porcentaje1;
	}

	public BigDecimal getPorcentaje2() {
		return porcentaje2;
	}

	public void setPorcentaje1(BigDecimal porcentaje1) {
		this.porcentaje1 = porcentaje1;
	}

	public void setPorcentaje2(BigDecimal porcentaje2) {
		this.porcentaje2 = porcentaje2;
	}

	public String getCodindic() {
		return codindic;
	}

	public void setCodindic(String codindic) {
		this.codindic = codindic;
	}

	public boolean isMostrarSupuesto2() {
		return mostrarSupuesto2;
	}

	public void setMostrarSupuesto2(boolean mostrarSupuesto2) {
		this.mostrarSupuesto2 = mostrarSupuesto2;
	}
}
