package com.atosorigin.deri.adminoper.confirmaciones.action;


//import java.io.File;
import java.io.File;
import java.io.IOException;
import java.lang.reflect.Field;
import java.math.BigDecimal;
import java.math.BigInteger;
import java.sql.SQLException;
import java.text.DecimalFormat;
import java.text.MessageFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.regex.Pattern;

import javax.faces.context.FacesContext;
import javax.persistence.EntityManager;
import javax.servlet.http.HttpSession;
import javax.xml.transform.URIResolver;

import org.hibernate.SQLQuery;
import org.jasig.cas.client.util.AssertionHolder;
import org.jasig.cas.client.validation.Assertion;
import org.jboss.seam.Component;
import org.jboss.seam.ScopeType;
import org.jboss.seam.annotations.Create;
import org.jboss.seam.annotations.In;
import org.jboss.seam.annotations.Logger;
import org.jboss.seam.annotations.Name;
import org.jboss.seam.annotations.Out;
import org.jboss.seam.annotations.Scope;
import org.jboss.seam.core.Conversation;
import org.jboss.seam.core.Interpolator;
import org.jboss.seam.core.ResourceBundle;
import org.jboss.seam.international.StatusMessage.Severity;
import org.jboss.seam.log.Log;
import org.jboss.seam.security.Credentials;
import org.jboss.seam.security.Identity;
import org.springframework.util.StringUtils;

import com.ConstantesFD;
import com.atos.firmaCentralizada.FirmaCentralizada;
import com.atos.firmaDigital.FirmaDigital;
import com.atos.oficinaSinPapeles.EnviarConfirmacionOSP;
import com.atos.validacionFD.ValidacionFD;
import com.atosorigin.common.action.ModoPantalla;
import com.atosorigin.common.action.PaginatedListAction;
import com.atosorigin.common.action.PaginationData;
import com.atosorigin.common.constantes.Constantes;
import com.atosorigin.common.constantes.Enumeraciones.CanalOperacion;
import com.atosorigin.common.constantes.Enumeraciones.EstadoConfirmacion;
import com.atosorigin.common.constantes.Enumeraciones.EventoConfirmacion;
import com.atosorigin.common.constantes.Enumeraciones.MarcaDeAgua;
import com.atosorigin.common.constantes.Enumeraciones.SentidoConfirmacion;
import com.atosorigin.common.constantes.Enumeraciones.TipoReclamacion;
import com.atosorigin.common.formvalidator.FormValidator;
import com.atosorigin.common.utils.GenericUtils;
import com.atosorigin.confirmaciones.edicion.database.BaseDBAccess;
import com.atosorigin.confirmaciones.edicion.database.DBAccess;
import com.atosorigin.confirmaciones.edicion.entities.base.ExtendedPDF;
import com.atosorigin.confirmaciones.edicion.tools.ExtendedPDFFactory;
import com.atosorigin.confirmaciones.servlet.JarServletContextURIResolver;
import com.atosorigin.deri.adminoper.admconfirmaciones.business.ConfirmacionOperacionesBo;
import com.atosorigin.deri.adminoper.admconfirmaciones.business.ConfirmacionOperacionesBo.ConfOperacionComparator;
import com.atosorigin.deri.adminoper.admconfirmaciones.business.ConfirmacionOperacionesBo.TipoCodacion;
import com.atosorigin.deri.adminoper.boletas.action.BoletasAction.BoletasStates;
import com.atosorigin.deri.adminoper.confirmaciones.action.AdmConfirmacionOracleReport.InformeEnum;
import com.atosorigin.deri.adminoper.confirmaciones.action.AdmConfirmacionOracleReport.TipoFichero;
import com.atosorigin.deri.adminoper.confirmaciones.screen.AdmConfirmacionesPantalla;
import com.atosorigin.deri.appListados.circularizacion.business.CircularizacionBo;
import com.atosorigin.deri.common.authentication.Authorizator;
import com.atosorigin.deri.contrapartida.buscadorContrapartida.action.BuscadorContrapartidaAction;
import com.atosorigin.deri.contrapartida.business.ContrapartidaBo;
import com.atosorigin.deri.gestionoperaciones.anexooperacion.business.AnexoOperacionBo;
import com.atosorigin.deri.gestionoperaciones.listasuscripciones.buscadoroficina.action.BuscadorOficinaAction;
import com.atosorigin.deri.model.adminoper.DescripcionTipoConfirmacion;
import com.atosorigin.deri.model.adminoper.DocumentoConfirmacion;
import com.atosorigin.deri.model.adminoper.ProductoTgr;
import com.atosorigin.deri.model.agenda.EventoAgenda;
import com.atosorigin.deri.model.catalogo.Producto;
import com.atosorigin.deri.model.common.Idioma;
import com.atosorigin.deri.model.contrapartida.AbstractContrapartida;
import com.atosorigin.deri.model.contrapartida.Contrapartida;
import com.atosorigin.deri.model.contrapartida.DocsContrapartida;
import com.atosorigin.deri.model.gestionoperaciones.AnexoOperacion;
import com.atosorigin.deri.model.gestionoperaciones.AnexoOperacionId;
import com.atosorigin.deri.model.gestionoperaciones.Apoderado;
import com.atosorigin.deri.model.gestionoperaciones.ConfOperacion;
import com.atosorigin.deri.model.gestionoperaciones.HistoricoOperacion;
import com.atosorigin.deri.model.gestionoperaciones.Operacion;
import com.atosorigin.deri.model.gestionoperaciones.TipoConfirmacion;
import com.atosorigin.deri.seguridad.pantalla.business.PantallaBo;
import com.atosorigin.deri.util.ConfiguracionDeri;
import com.atosorigin.deri.util.ContrapartidaUtil;
import com.atosorigin.deri.util.EntityUtil;
import com.atosorigin.deri.util.MessageBoxAction;
import com.atosorigin.deri.util.MsgBoxAction;
import com.bancsabadell.xmlns.proteo.SharedResources.ErrorSchema.FaultInfo;
import com.bancsabadell.xmlns.proteo.SharedResources.Header.HeaderRequest;
import com.bancsabadell.xmlns.proteo.SharedResources.Header.HeaderRequestHostRequest;
import com.bs.proteo.soa.service.centralizedsignature.managementservice.domain.ContextCaptcha;
import com.bs.proteo.soa.service.centralizedsignature.managementservice.domain.Document;
import com.bs.proteo.soa.service.centralizedsignature.managementservice.domain.Product;
import com.bs.proteo.soa.service.centralizedsignature.managementservice.domain.ProductDetail;
import com.bs.proteo.soa.service.centralizedsignature.managementservice.domain.Signer;
import com.bs.proteo.soa.service.centralizedsignature.managementservice.domain.SignerIdentification;
import com.bs.proteo.soa.service.centralizedsignature.managementservice.management.domain.RegisterInputData;
import com.bs.proteo.soa.service.centralizedsignature.managementservice.management.domain.message.RegisterRequest;
import com.bs.proteo.soa.service.centralizedsignature.managementservice.management.domain.message.RegisterResponse;
import com.bs.proteo.soa.service.firmacentralizada.firmacentralizadacontroller.domain.Contexto;
import com.bs.proteo.soa.service.firmacentralizada.firmacentralizadacontroller.firmacentralizada.domain.RegistrarCasoFirmaRequestData;
import com.bs.proteo.soa.service.firmacentralizada.firmacentralizadacontroller.firmacentralizada.domain.RegistrarCasoFirmaRequestDataIdFirmante;
import com.bs.proteo.soa.service.firmacentralizada.firmacentralizadacontroller.firmacentralizada.domain.message.RegistrarCasoFirmaRequest;
import com.bs.proteo.soa.service.firmacentralizada.firmacentralizadacontroller.firmacentralizada.domain.message.RegistrarCasoFirmaResponse;
import com.bs.proteo.soa.service.mainframe.OficinaSinPapeles.domain.message.ModificaRequest;
import com.bs.proteo.soa.service.mainframe.OficinaSinPapeles.domain.message.ModificaResponse;
import com.bs.proteo.soa.service.teso.valid.validacionfirmante.domain.Fp7005I;
import com.bs.proteo.soa.service.teso.valid.validacionfirmante.domain.message.ExecuteResponse;
import com.neoris.ejemploUsoGestorDocumental.Principal;



/**
 * Clase action listener para el caso de uso de preconfirmaciones
 */
@Name("admconfirmacionesAction")
@Scope(ScopeType.CONVERSATION)
@FormValidator
public class AdmConfirmacionAction extends PaginatedListAction {

	public static class Boton {

		protected boolean disabled;
		protected Interpolator interpolator = Interpolator.instance();
		protected boolean isLazyInitialized = false;
		protected Object[] params;
		protected boolean rendered;
		protected String value;
		
		public Boton(String value) {
			this(value, true, false);
		}

		public Boton(String value, boolean rendered, boolean disabled) {
			setValue(value);
			setRendered(rendered);
			setDisabled(disabled);
		}

		public boolean isRendered() {
			return rendered;
		}

		public void setRendered(boolean rendered) {
			this.rendered = rendered;
		}

		public boolean isDisabled() {
			return disabled;
		}

		public void setDisabled(boolean disabled) {
			this.disabled = disabled;
		}

		public String getValue() {

			if (isLazyInitialized)
				return value;

			isLazyInitialized = true;

			// InterpolaciÃ³n mensaje
			if (fqName.matcher(value).matches()) {

				final String msg = interpolator.interpolate("#{messages['"
						+ value + "']}");
				this.value = MessageFormat.format(msg, params);

			} else if (value.startsWith("#{")) {

				final String msg = interpolator.interpolate(value, params);
				this.value = MessageFormat.format(msg, params);
			}

			return this.value;
		}

		public void setValue(String value, Object... params) {
			this.value = value;
			this.params = params;
			isLazyInitialized = false;
		}

	}
	
	private static final long serialVersionUID = 1L;

	@Logger
	private Log log;

	@In
	EntityManager entityManager;

	@In(value = "org.jboss.seam.faces.facesContext")
	private FacesContext facesContext;

	@In
	Interpolator interpolator;

	@In("#{authorizator}")
	Authorizator authorizator;

	@In 
	Credentials credentials;
	
	/**
	 * InyecciÃ³n del bean de Spring "preconfirmacionesBo" que contiene los
	 * mÃ©todos de negocio para el caso de uso preconfirmaciones.
	 */
	@In("#{admconfirmacionesBo}")
	protected ConfirmacionOperacionesBo admconfirmacionesBo;

	@In("#{anexoOperacionBo}")
	protected AnexoOperacionBo anexoOperacionBo;

	private boolean mostrarPDF = false;

	private boolean mostrarEnviarFase2Panel = false;

	private boolean mostrarReport = false;

	private boolean mostrarReclamarPanel = false;

	private boolean excel = false;

	private String tipoReclamada = TipoReclamacion.C.toString();

	private String tipoEventoEnvio = EventoConfirmacion.ALTA.toString();
	
	private boolean mostrarAnexoPanel = true;
	private String oncompleteModePanel = "";
	private String reRenderModePanel ="";
	private boolean activarOSP = false;
	private boolean activarFirmaDigital = false;
	
	private Integer ultimRegistre;
	
	//Necesaria para llamar al webservice de firma digital
	@In(required=false)
	@Out(required=true, scope=ScopeType.SESSION)
	private String sessionId="";
	
	private String proxyGrantingTicket = getTicket();
	
	/**
	 * InyecciÃ³n del bean de Spring "contrapartidaBo" que contiene los mÃ©todos
	 * de negocio para el caso de uso de contrapartidas.
	 */
	@In("#{contrapartidaBo}")
	protected ContrapartidaBo contrapartidaBo;

	@In("#{pantallaBo}")
	protected PantallaBo pantallaBo;

	@In("EntityUtil")
	private EntityUtil entityUtil;

	@In
	private ContrapartidaUtil contrapartidaUtil;
	/**
	 * InyecciÃ³n del screen bean que contiene los datos de pantalla del caso de
	 * uso preconfirmaciones
	 */
	@In(create = true)
	protected AdmConfirmacionesPantalla admConfirmacionesPantalla;

	public AdmConfirmacionesPantalla getAdmConfirmacionesPantalla() {
		return admConfirmacionesPantalla;
	}

	public void setAdmConfirmacionesPantalla(
			AdmConfirmacionesPantalla admConfirmacionesPantalla) {
		this.admConfirmacionesPantalla = admConfirmacionesPantalla;
	}

	// @In(required=false , value="admConfirmacionSelec")
	@Out(required = false)
	protected ConfOperacion confOperacionSelect;

	@In(required = false)
	private Boolean estadoAgenda;

	@In(required = false)
	private EventoAgenda eventoSelectAgenda;

	@In(required = false)
	private Long estructuraId;

	@In(required = false)
	private String numOperIni;

	@In(required = false)
	private String numOperFin;

	@In(required = false)
	private Producto producto;

	@In(required = false)
	private Date fechaTraIni;

	@In(required = false)
	private String modo;

	@In(create = true)
	private BuscadorContrapartidaAction buscadorContrapartidaAction;

	@In(create = true)
	private BuscadorOficinaAction buscadorOficinaAction;

	private Boolean busqueda = false;

	@In(required = false)
	@Out(required = false)
	private HistoricoOperacion historicoOperacion;

	@In(value = "configuracionDeri")
	ConfiguracionDeri configuracionDeri;

	@In("#{circularizacionBo}")
	protected CircularizacionBo circularizacionBo;

	@In(create = true)
	private MsgBoxAction msgBoxAction;

	public Boolean errorWS = false;
	private String pdfs;
	private String texts;

	@Create
	public void onCreate() {
		pdfs = configuracionDeri.getPdfs();
		texts = configuracionDeri.getTexts();
	}

	@In(value = "principalDMS", create = true)
	protected Principal principalDMS;

	@In(value = "firmaDigital", create = true)
	protected FirmaDigital firmaDigital;
	
	@In(value = "firmaCentralizada", create = true)
	protected FirmaCentralizada firmaCentralizada;
	
	@In(value = "enviarConfirmacionOsp", create = true)
	protected EnviarConfirmacionOSP enviarConfirmacionOsp;
	
	@In(value = "validacionFD", create = true)
	protected ValidacionFD validacionFD;

	//TODO SMM 14/11 BORRAR SOLO PARA LOGIN ANONIMO TEST
//	@In(value = "mifidWS", create = true)
//	protected MifidWS mifidWS;
	
	
	public HistoricoOperacion getHistoricoOperacion() {
		return historicoOperacion;
	}

	public void setHistoricoOperacion(HistoricoOperacion historicoOperacion) {
		this.historicoOperacion = historicoOperacion;
	}

	@Out(required = false)
	private String modoTratamiento;

	@Out(required = false)
	private String tipoAnexo;

	@Out
	Boton botonAlta = new Boton("boton.alta");

	@Out
	Boton botonEnviar = new Boton("boton.enviar", false, true);

	@Out
	Boton botonRecibida = new Boton("boton.confirmada", false, true);

	@Out
	Boton botonRecepcionada = new Boton("boton.recepcionada", false, true);
	
	@Out
	Boton botonDescartada = new Boton("boton.descartar", false, true);

	@Out
	Boton botonReclamar = new Boton("boton.reclamar", false, true);

	@Out(required = false, value = "admConfirmacionMessageBoxAction")
	private MessageBoxAction messageAdmConfirmacionesMO;
	
	private String complete = "";
	
	private Boolean enviarFDManual = false;
	private Boolean enviarFDUrgente = false;
	
	
	public String getTipoAnexo() {
		return tipoAnexo;
	}

	public void setTipoAnexo(String tipoAnexo) {
		this.tipoAnexo = tipoAnexo;
	}

	public String getModoTratamiento() {
		return modoTratamiento;
	}

	public void setModoTratamiento(String modoTratamiento) {
		this.modoTratamiento = modoTratamiento;
	}

	public ConfOperacion getConfOperacionSelect() {
		return confOperacionSelect;
	}

	public void setConfOperacionSelect(ConfOperacion confOperacionSelect) {
		this.confOperacionSelect = confOperacionSelect;
	}

	protected boolean noPlantilla = false;

	public boolean isNoPlantilla() {
		return noPlantilla;
	}

	public void setNoPlantilla(boolean noPlantilla) {
		this.noPlantilla = noPlantilla;
	}

	protected boolean enviar = false;

	protected boolean consultar = false;

	public boolean isEnviar() {
		return enviar;
	}

	public void setEnviar(boolean enviar) {
		this.enviar = enviar;
	}

	protected boolean fromAction = false;

	public boolean isFromAction() {
		return fromAction;
	}

	public void setFromAction(boolean fromAction) {
		this.fromAction = fromAction;
	}

	private StringBuilder mensajeConfirmacion = new StringBuilder();

	public StringBuilder getMensajeConfirmacion() {
		return mensajeConfirmacion;
	}

	public void setMensajeConfirmacion(StringBuilder mensajeConfirmacion) {
		this.mensajeConfirmacion = mensajeConfirmacion;
	}

	protected String reclamarTipoAnexo;
	
	protected Date reclamarFechaAnexo;
	
	
	protected String reclamarTextoAnexo;

	/** Actualiza la lista del grid de preconfirmaciones */
	public void buscar() {

		ocultarPanelesModales();
		
		ultimRegistre = 0;
		paginationData.reset();
		seleccionOPMap.clear();
		this.admConfirmacionesPantalla.setModo(Constantes.CADENA_VACIA);
		/** Limpiamos la informaciÃ³n de paginaciÃ³n */
		// setPrimerAcceso(false);
		busqueda = true;
		modo = "";

		setFromAction(false);
		setEnviar(false);
		setConsultar(true);

		refrescarLista();
		
		// Forzar refresco
		final List<ConfOperacion> lista = getDataTableList();
		for (ConfOperacion co: lista)
			admconfirmacionesBo.recargar(co);

		setFormFields(); // Setting the fields in the list of Search Criterios
		setPrimerAcceso(false);

	}

	// This functions is used to set all fields on screen to retain the selected
	// values by user.
	public void setFormFields() {
		this.admConfirmacionesPantalla
				.setTipoConfirmacion(this.admConfirmacionesPantalla
						.getTipoConfirmacion());
		this.admConfirmacionesPantalla
				.setIdiomaConfirmacion(this.admConfirmacionesPantalla
						.getIdiomaConfirmacion());
		this.admConfirmacionesPantalla
				.setCanalConfirmacion(this.admConfirmacionesPantalla
						.getCanalConfirmacion());
		this.admConfirmacionesPantalla
				.setPdtoContable(this.admConfirmacionesPantalla
						.getPdtoContable());
		this.admConfirmacionesPantalla
				.setPdtoCatalogo(this.admConfirmacionesPantalla
						.getPdtoCatalogo());
		this.admConfirmacionesPantalla
				.setEstadoConfirmacion(this.admConfirmacionesPantalla
						.getEstadoConfirmacion());
		this.admConfirmacionesPantalla
				.setTipoContrapa(this.admConfirmacionesPantalla
						.getTipoContrapa());
		this.admConfirmacionesPantalla
				.setSentidoConfirmacion(this.admConfirmacionesPantalla
						.getSentidoConfirmacion());
		this.admConfirmacionesPantalla
				.setContrapartida(this.admConfirmacionesPantalla
						.getContrapartida());
		this.admConfirmacionesPantalla
				.setOficina(this.admConfirmacionesPantalla.getOficina());
	}

	/**
	 * Valida si existe la contrapartida y si los valores introducidos en los
	 * campos de fecha y nÃºmero de operaciÃ³n son correctos (num oper desde <=
	 * num oper hasta y fecha desde <= fecha hasta)
	 */
	public boolean buscarValidator() {

		if (!GenericUtils.isNullOrBlank(admConfirmacionesPantalla
				.getContrapartida())) {
			/** Se valida la contrapartida introducida por el usuario */
			if (!validaContrapaExiste(admConfirmacionesPantalla
					.getContrapartida())) {

				addToControlStatusMessage("contrapartida", Severity.ERROR,
						"#{messages['admconfirmaciones.error.contrapartida']}",
						admConfirmacionesPantalla.getContrapartida());

				return false;
			}
		}

		try {
			if (admConfirmacionesPantalla.getNumOperHasta().compareTo(
					admConfirmacionesPantalla.getNumOperDesde()) < 0) {

				addStatusMessage(Severity.ERROR,
						"#{messages['admconfirmaciones.error.operhasta']}");

				return false;
			}
		} catch (NullPointerException e) {
		}

		try {
			long diffFechaFinIni = (admConfirmacionesPantalla.getFechaHasta()
					.getTime() - admConfirmacionesPantalla.getFechaDesde()
					.getTime()) / 86400000L;

			if (diffFechaFinIni < 0) {

				addStatusMessage(Severity.ERROR,
						"#{messages['admconfirmaciones.error.fechahasta']}");

				return false;
			}
		} catch (NullPointerException e) {
		}

		try {
			if (admConfirmacionesPantalla.getEstructHasta() < admConfirmacionesPantalla
					.getEstructDesde()) {

				addStatusMessage(Severity.ERROR,
						"#{messages['admconfirmaciones.error.estructhasta']}");

				return false;
			}
		} catch (NullPointerException e) {
		}

		return true;
	}

	/** Prepara para entrar en el modo ediciÃ³n de una preconfirmaciÃ³n */
	public void editar() {

		ocultarPanelesModales();

		admConfirmacionesPantalla.setAdmconfirmacion(admConfirmacionesPantalla
				.getAdmconfirmacionSelec());

		/** Marcamos el check de preconfirmar si estadoco=S */
		/*
		 * if(Constantes.CONSTANTE_SI.equalsIgnoreCase(this.admConfirmacionesPantalla
		 * .getPreconfirmacionSelec().getEstado())){
		 * this.admConfirmacionesPantalla.setPreconfirmado(true); } else {
		 * this.admConfirmacionesPantalla.setPreconfirmado(false); }
		 */

		this.setModoPantalla(ModoPantalla.EDICION);
	}

	/** Actualiza la preconfirmacion */
	public String tratar() {

		/**
		 * Recogemos el valor del checkbox preconfirmar y asignamos S Ã³ N segÃºn
		 * estÃ© o no marcado
		 */
		if (this.admConfirmacionesPantalla.isPreconfirmado()) {
			// (admConfirmacionesPantalla.getPreconfirmacion()).setEstado(Constantes.CONSTANTE_SI);
		} else {
			// (admConfirmacionesPantalla.getPreconfirmacion()).setEstado(Constantes.CONSTANTE_NO);
		}

		// preconfirmacionesBo.tratar(admConfirmacionesPantalla.getPreconfirmacion());
		// preconfirmacionesBo.recargar(admConfirmacionesPantalla.getPreconfirmacion());
		refrescarLista();
		return Constantes.CONSTANTE_SUCCESS;
	}

	/**
	 * Actualiza la lista del grid de parÃ¡metros informe y vuelve a la pantalla
	 * de bÃºsqueda
	 */
	public void salirDetalle() {
		paginationData.reset();
		/** Limpiamos la informaciÃ³n de paginaciÃ³n */
		if (this.modoPantalla.equals(ModoPantalla.EDICION)) {
			refrescarLista();
		}
	}

	@Override
	protected void refreshListInternal() {

//		final ThreadDebugger td;
//		try {
//			td = new ThreadDebugger(Thread.currentThread(), 100, 3 * 60 * 1000);
//		} catch (IOException e) {
//			throw new IllegalStateException(e);
//		}

		if (!busqueda && Constantes.MODO_AGE.equals(modo)) {
			setExportExcel(false);
			cargarAgenda(false);
			return;
		}

		setExportExcel(false);
		final List<ConfOperacion> listaAdmconfirmaciones = recargarLista(paginationData, false);
		admConfirmacionesPantalla
				.setAdmconfirmacionesList(listaAdmconfirmaciones);

//		td.print();
	}

	/** MÃ©todo que comprueba si existe la contrapartida que introduce el usuario */
	private boolean validaContrapaExiste(String idContrapa) {

		boolean existeContrapa = true;

		if (GenericUtils.isNullOrBlank(this.contrapartidaBo.cargar(idContrapa))) {
			existeContrapa = false;
		}

		return existeContrapa;
	}

	@Override
	public void refrescarListaExcel() {

		ocultarPanelesModales();

		if (!busqueda && Constantes.MODO_AGE.equals(modo)) {
			excel = true;
			setExportExcel(true);
			cargarAgenda(false);
			return;
		}

		setExportExcel(true);

		final List<ConfOperacion> listaAdmconfirmaciones = recargarLista(paginationData
				.getPaginationDataForExcel(),false);

		admConfirmacionesPantalla
				.setAdmconfirmacionesList(listaAdmconfirmaciones);

	}


	public void enviarConfirmacionBatch(){
		List<ConfOperacion> seleccionadas = GenericUtils
		.getSeleccionCheckbox(seleccionOPMap);

		if (seleccionadas.isEmpty()) {
			addStatusMessage(Severity.ERROR,
			"#{messages['admconfirmaciones.error.noseleccion']}");
			return;
		}else{
			Long peticion = admconfirmacionesBo.enviarConfBatch(seleccionadas);
			String mensaje = ResourceBundle.instance().getString("liquidaciones.registros.validadosBatch") + " " + peticion ;
			statusMessages.add(Severity.INFO, mensaje);
			seleccionadas.clear();
			seleccionOPMap.clear();
	}
	}

	public void excelBatch() {
		setExportExcel(true);
		List<ConfOperacion> listaAdmconfirmaciones = new ArrayList<ConfOperacion>();

		if (!busqueda && Constantes.MODO_AGE.equals(modo)) {
			excel = true;
			setExportExcel(true);
			listaAdmconfirmaciones = cargarAgenda(true);
			procesoExcelBatch(listaAdmconfirmaciones,"AGE");
		}else{
			listaAdmconfirmaciones = recargarLista(paginationData.getPaginationDataForExcel(),true);
			procesoExcelBatch(listaAdmconfirmaciones,"NOR");
		}
	}


	private void procesoExcelBatch(List<ConfOperacion> listaAdmconfirmaciones,String caso) {
		String sqlTxt = null; String sustitucion = null; String sqlHeader = null;
		
		
		sqlHeader ="NumOp/Estr;Pdto.cat.;Tipo Confirm.;Idioma;Canal;Fecha Proceso;Contrapartida;Sentido;Estado;Su Referencia;"+
		"Observaciones;Fecha de alta;Nominal de pago;Nominal de recibo;Entidad;Tipo contrapartida;Oficina;Fecha valor;"+
		"Fecha vencimiento;Fecha Ãºltima actualizaciÃ³n;Fecha Ãºltima confirmaciÃ³n;Indicador confirmaciÃ³n reclamada;Preconfirmada;Prod.TGR;Clave Externa;Indicador FD";
		

		if (listaAdmconfirmaciones!=null && listaAdmconfirmaciones.size()>0){
			
			SQLQuery sql = listaAdmconfirmaciones.get(0).getSqlQuery();
			sqlTxt = sql.getQueryString();
			for (String param : sql.getNamedParameters()) {
				sustitucion = obtenerSustitucion(param, caso);
				param = ":".concat(param);
				
				sqlTxt =	sqlTxt.replaceAll(param , sustitucion);	
			}	
		
			Long peticion = admconfirmacionesBo.generarPeticionExcel(sqlTxt,sqlHeader,caso);

			String mensaje = ResourceBundle.instance().getString("liquidaciones.registros.validadosBatch") + " " + peticion ;
			statusMessages.add(Severity.INFO, mensaje);

		}
	}


	private String obtenerSustitucion(String param, String caso) {
		
		
		SimpleDateFormat sdf = new SimpleDateFormat(Constantes.DDMMYYYY);
//		SimpleDateFormat sdf2 = new SimpleDateFormat(Constantes.YYYYMMDD);

		if ("rownumMin".equalsIgnoreCase(param)){
			return paginationData.getPaginationDataForExcel().getFirstResult().toString();
		}else if ("rownumMax".equalsIgnoreCase(param)){
			return paginationData.getPaginationDataForExcel().getMaxResults().toString();
		}else if ("eventoConfirmacion".equalsIgnoreCase(param)){
			return this.admConfirmacionesPantalla.getTipoConfirmacion()==null?"null":"'".concat(this.admConfirmacionesPantalla.getTipoConfirmacion().getCodigo()).concat("'"); 
		}else if ("productocatalogo".equalsIgnoreCase(param)){
			return this.admConfirmacionesPantalla.getPdtoCatalogoBusqueda()==null?"null":this.admConfirmacionesPantalla.getPdtoCatalogoBusqueda().getProducat().toString();
		}else if ("idioma".equalsIgnoreCase(param)){
			return this.admConfirmacionesPantalla.getIdiomaConfirmacion()==null?"null":this.admConfirmacionesPantalla.getIdiomaConfirmacion().getCodigo();
		}else if ("canal".equalsIgnoreCase(param)){
			return this.admConfirmacionesPantalla.getCanalConfirmacion()==null?"null":"'".concat(this.admConfirmacionesPantalla.getCanalConfirmacion().getId().getCodcanal()).concat("'");
		}else if ("sentidoConfirmacion".equalsIgnoreCase(param)){
			return this.admConfirmacionesPantalla.getSentidoConfirmacion()==null?"null":"'".concat(this.admConfirmacionesPantalla.getSentidoConfirmacion().getCodigo()).concat("'");
//			if ("AGE".equals(caso)){
//				return ""; //parametrosMantOper.getNcorrelaIni()==null?"null":parametrosMantOper.getNcorrelaIni().toString();
//			}else{
//				return  ""; //parametrosMantOper.getNcorrelaIni().toString();
//			}
		}else if ("estadoConfirmacion".equalsIgnoreCase(param)){
			return this.admConfirmacionesPantalla.getEstadoConfirmacion()==null?"null":"'".concat(this.admConfirmacionesPantalla.getEstadoConfirmacion().getCodigo()).concat("'");
//			if ("AGE".equals(caso)){
//				return  ""; //parametrosMantOper.getNcorrelaFin()==null?"null":parametrosMantOper.getNcorrelaFin().toString();
//			}else{
//				return  ""; //parametrosMantOper.getNcorrelaFin().toString();
//			}
		}else if ("idEstructConfirmadaDesde".equalsIgnoreCase(param)){
			return this.admConfirmacionesPantalla.getEstructDesde().toString();
		}else if ("idEstructConfirmadaHasta".equalsIgnoreCase(param)){
			return this.admConfirmacionesPantalla.getEstructHasta().toString();
			//parametrosMantOper.getProducto()==null?"null":"'".concat(parametrosMantOper.getProducto().getId()).concat("'");
		}else if ("ncorrelaDesde".equalsIgnoreCase(param)){
			if ("AGE".equals(caso)){
				return numOperIni==null?"null":numOperIni.toString();  
			}else{
				return this.admConfirmacionesPantalla.getNumOperDesde().toString();
			}
		}else if ("ncorrelaHasta".equalsIgnoreCase(param)){
			if ("AGE".equals(caso)){
				return numOperFin==null?"null":numOperFin.toString(); 
			}else{
				return this.admConfirmacionesPantalla.getNumOperHasta().toString();
			}
		}else if ("fechaConfirmacionDesde".equalsIgnoreCase(param)){
			return "'".concat(sdf.format(this.admConfirmacionesPantalla.getFechaDesde()).toString()).concat("'");
		}else if ("fechaConfirmacionHasta".equalsIgnoreCase(param)){
			return "'".concat(sdf.format(this.admConfirmacionesPantalla.getFechaHasta()).toString()).concat("'");
		}else if ("producto".equalsIgnoreCase(param)){
			if ("AGE".equals(caso)){
				return producto==null?"null":"'".concat(producto.getId()).concat("'"); 
			}else{
				return this.admConfirmacionesPantalla.getPdtoContable()==null?"null":"'".concat(this.admConfirmacionesPantalla.getPdtoContable().getId()).concat("'");
			}
		}else if ("oficina".equalsIgnoreCase(param)){
			return "'".concat(this.admConfirmacionesPantalla.getOficina()).concat("'");
		}else if ("contrapartida".equalsIgnoreCase(param)){
			return 	"'".concat(this.admConfirmacionesPantalla.getContrapartida()).concat("'");
		}else if ("tipoContrapartida".equalsIgnoreCase(param)){
			return this.admConfirmacionesPantalla.getTipoContrapa()==null?"null":"'".concat(this.admConfirmacionesPantalla.getTipoContrapa().getId()).concat("'");
		}else if ("fechaContratacion".equalsIgnoreCase(param)){
			return "'".concat(sdf.format(historicoOperacion.getId().getFechaContratacion())).concat("'"); 
		}else if ("codigoEvento".equalsIgnoreCase(param)){
			return eventoSelectAgenda.getCodigoEvento().toString(); //"'".concat(contrapartida).concat("'");
		}else if ("estadoEvento".equalsIgnoreCase(param)){
			return "'".concat(estadoAgenda ? "P" : "N").concat("'");
		}else if ("suRefer".equalsIgnoreCase(param)){
			return ""; //"'".concat(suReferencia).concat("'");
		}else if ("fechaSistema".equalsIgnoreCase(param)){
			Date fechaSistema = admconfirmacionesBo.obtenerFechaSistema();
			return "'".concat(sdf.format(fechaSistema)).concat("'");
		}else if ("fechaTratamiento".equalsIgnoreCase(param)){
			return "'".concat(sdf.format(fechaTraIni)).concat("'");
		}
		
		/**
		else if ("numOperMin".equalsIgnoreCase(param)){
			return numOper.getLow().toString();
		}else if ("numOperMax".equalsIgnoreCase(param)){
			return numOper.getHigh().toString();
		}else if ("fechaOpeMin".equalsIgnoreCase(param)){
			return "'".concat(sdf.format(fechaOpe.getLow()).toString()).concat("'");
		}else if ("fechaOpeMax".equalsIgnoreCase(param)){
			return "'".concat(sdf.format(fechaOpe.getHigh()).toString()).concat("'");
		}else if ("fechaValMin".equalsIgnoreCase(param)){
			return "'".concat(sdf.format(fechaVal.getLow()).toString()).concat("'");
		}else if ("fechaValMax".equalsIgnoreCase(param)){
			return "'".concat(sdf.format(fechaVal.getHigh()).toString()).concat("'");
		}else if ("fechaVenMin".equalsIgnoreCase(param)){
			return "'".concat(sdf.format(fechaVen.getLow()).toString()).concat("'");
		}else if ("fechaVenMax".equalsIgnoreCase(param)){
			return "'".concat(sdf.format(fechaVen.getHigh()).toString()).concat("'");
		}else if ("pendienteConf".equalsIgnoreCase(param)){
			return "'".concat(GenericUtils.SNBooleanNotNull(pendienteConf)).concat("'");
		}else if ("estructura".equalsIgnoreCase(param)){
			return "'".concat(GenericUtils.SNBooleanNotNull(estructura)).concat("'");
		}else if ("campana".equalsIgnoreCase(param)){
			return "'".concat(GenericUtils.SNBooleanNotNull(campana)).concat("'");
		}else if ("cobertura".equalsIgnoreCase(param)){
			return "'".concat(GenericUtils.SNBooleanNotNull(cobertura)).concat("'");
		}else if ("situacion".equalsIgnoreCase(param)){
			return "'".concat(situacion.getCodigo()).concat("'");
		}else if ("clExternaMin".equalsIgnoreCase(param)){
			return clExterna.getLow().toString();
		}else if ("clExternaMax".equalsIgnoreCase(param)){
			return clExterna.getHigh().toString();
		}else if ("estructuraMin".equalsIgnoreCase(param)){
			return numEstructu.getLow().toString();
		}else if ("estructuraMax".equalsIgnoreCase(param)){
			return numEstructu.getHigh().toString();
		}else if ("claveBduMin".equalsIgnoreCase(param)){
			return "'".concat(clBduGid.getLow()).concat("'");
		}else if ("claveBduMax".equalsIgnoreCase(param)){
			return "'".concat(clBduGid.getHigh()).concat("'");
		}
		*/
		else{
			return "1";		
		}

	}

	
	
	

	/**
	 * FunciÃ³n a la que se llama desde la pantalla de agenda, para precargar el
	 * listado de preconfirmaciones
	 */
	public void preCargarDesdeAgenda() {
		this.admConfirmacionesPantalla.setModo(Constantes.MODO_AGE);
		refrescarLista();
	}

	@SuppressWarnings("unchecked")
	@Override
	public void setDataTableList(List<?> dataTableList) {
		this.admConfirmacionesPantalla
				.setAdmconfirmacionesList((List<ConfOperacion>) dataTableList);
	}

	@Override
	public List<ConfOperacion> getDataTableList() {
		return this.admConfirmacionesPantalla.getAdmconfirmacionesList();
	}

	/**
	 * Mapa con el <i>status</i> de los checkboxes.
	 * 
	 * @see GenericUtils#getSeleccionCheckbox(Map)
	 */
	final SeleccionCheckboxMap<ConfOperacion> seleccionOPMap = new SeleccionCheckboxMap<ConfOperacion>(
			new ConfirmacionOperacionesBo.ConfOperacionComparator()) {

		private static final long serialVersionUID = 1L;

		@Override
		public void onUpdate(ConfOperacion key, Boolean value) {
			recalcularBotonera();
			
		}
	};

	public boolean isReadyDatosConf() {
		return !GenericUtils.getSeleccionCheckbox(seleccionOPMap).isEmpty();
	}

	public boolean existeSeleccion() {

		return !GenericUtils.isNullOrEmpty(GenericUtils
				.getSeleccionCheckbox(seleccionOPMap));
	}

	public boolean existenDatos() {

		return !GenericUtils.isNullOrEmpty(getDataTableList());
	}

	public void seleccionarTodos() {

		final Integer primer = paginationData.getFirstResult();
		final Integer ultim = paginationData.getMaxResults();

		try {
			seleccionOPMap.superClear();

			paginationData.setFirstResult(0);
			paginationData.setMaxResults(Constantes.MAX_RESULTS_SELECCION_TOTAL);
			refrescarLista();

			final List<ConfOperacion> list = getDataTableList();
			for (ConfOperacion co : list)
				seleccionOPMap.superPut(co, Boolean.TRUE);

			recalcularBotonera();
		} catch (Exception e) {

			addFromResourceBundleStatusMessage(e,
					"admconfirmaciones.seleccionarTodos.error");

		} finally {
			// Volvemos a poner la pagina actual
			paginationData.setFirstResult(primer);
			paginationData.setMaxResults(ultim);

			setDataTableList(getDataTableList().subList(primer,
					Math.min(primer + ultim +1, getDataTableList().size())));
//			refrescarLista();
		}
	}

	public void deseleccionarTodos() {
		seleccionOPMap.clear();
	}

	public List<ConfOperacion> getDataTableScreen() {

		final List<ConfOperacion> ols = getDataTableList();
		if (GenericUtils.isNullOrEmpty(seleccionOPMap))
			return null;

		return ols.subList(0, Math.min(ols.size(), 10));
	}

	// End Checkboxes
	// Start Alta

	public void verPDF() {
		
		setFromAction(false);
		setEnviar(true);
		msgBoxAction.setMostrarMensaje(false);

		setConsultar(true);
		setMostrarPDF(true);
		setMostrarReport(false);
		
		
		//SMM 05/06/2018
		Contrapartida contrapartida = null;
		if (confOperacionaux.getOperacionID()!=null && !GenericUtils.isNullOrBlank(confOperacionaux.getOperacion())){
			contrapartida = (Contrapartida) confOperacionaux.getOperacion().getContrapartida();
		}else{
			contrapartida = (Contrapartida) confOperacionaux.getEstructura().getContrapartida();
		}
//		Contrapartida contrapartida = (Contrapartida) confOperacionaux.getOperacion().getContrapartida(); //SMM Luego se comenta
		if(null!=contrapartida && null!=contrapartida.getIndBloqueo() && "S".equals(contrapartida.getIndBloqueo())){
			iniciarPopUpContrapartidaBloqueada();
		}
	}

	public void editarPDF() {
		setFromAction(false);
		setEnviar(true);
		msgBoxAction.setMostrarMensaje(false);

		setConsultar(false);
		setMostrarPDF(true);
		setMostrarReport(false);

		//SMM 05/06/2018
		Contrapartida contrapartida = null;
		if (confOperacionaux.getOperacionID()!=null && !GenericUtils.isNullOrBlank(confOperacionaux.getOperacion())){
			contrapartida = (Contrapartida) confOperacionaux.getOperacion().getContrapartida();
		}else{
			contrapartida = (Contrapartida) confOperacionaux.getEstructura().getContrapartida();
		}
//		Contrapartida contrapartida = (Contrapartida) confOperacionaux.getOperacion().getContrapartida();
		if(null!=contrapartida && null!=contrapartida.getIndBloqueo() && "S".equals(contrapartida.getIndBloqueo())){
			iniciarPopUpContrapartidaBloqueada();
		}
	}

	public void preview() {

	}

	public void recibida() {

		ocultarPanelesModales();

		final List<ConfOperacion> seleccionadas = GenericUtils
				.getSeleccionCheckbox(seleccionOPMap);

		admconfirmacionesBo.recibida(seleccionadas, TipoCodacion.RECIBIDA);

		for (ConfOperacion co : seleccionadas)
			admconfirmacionesBo.recargar(co);

		seleccionOPMap.clear();
		refrescarLista();
	}

	
	public void recepcionada(){
		ocultarPanelesModales();

		final List<ConfOperacion> seleccionadas = GenericUtils
				.getSeleccionCheckbox(seleccionOPMap);

		admconfirmacionesBo.recepcionar(seleccionadas, TipoCodacion.RECIBIDA);

		for (ConfOperacion co : seleccionadas)
			admconfirmacionesBo.recargar(co);

		seleccionOPMap.clear();
		refrescarLista();
	}

	
	/**
	 * Comprueba si hay alguna confirmaciÃ³n susceptible de ser reclamada.
	 * 
	 * @return
	 */
	public boolean isReclamarDisabled() {
		
		final List<ConfOperacion> seleccionadas = GenericUtils
				.getSeleccionCheckbox(seleccionOPMap);

		if (GenericUtils.isNullOrEmpty(seleccionadas))
			return true;

		for (ConfOperacion co : seleccionadas) {

			if (admconfirmacionesBo.isReclamable(co))
				return false;
		}

		return true;
	}

	/**
	 * Filtra las confirmaciones que no cumplen los prerequisitos.
	 * 
	 * @param confirmaciones
	 * @return Lista de confirmaciones vÃ¡lidas.
	 */
	protected List<ConfOperacion> filtroReclamadas(
			List<ConfOperacion> confirmaciones) {

		final ArrayList<ConfOperacion> seleccionadasOk = new ArrayList<ConfOperacion>();

		if (GenericUtils.isNullOrEmpty(confirmaciones))
			return seleccionadasOk;

		for (ConfOperacion co : confirmaciones) {

			if (admconfirmacionesBo.isReclamable(co))
				seleccionadasOk.add(co);
		}

		return seleccionadasOk;
	}

	
	
	public void validateName(){
//	FacesContext context, UIComponent toValidate,      
//            Object value) { 
//		String [] name = value.toString().split(" "); 

		setMostrarAnexoPanel(true);
		if (getReclamarTextoAnexo()!=null && getReclamarTextoAnexo().length()>400){
//		if(value!=null && value.toString().length() > 400) { 
//			((UIInput) toValidate).setValid(false); 
//			context.addMessage(toValidate.getClientId(context), 
//					new FacesMessage("Texto Demasiado Largo")); 
			setMostrarAnexoPanel(false);
		}
	}

	public void reclamarInit(){
		setMostrarAnexoPanel(true);
		
		if(messageAdmConfirmacionesMO==null){
			messageAdmConfirmacionesMO = new MessageBoxAction();
		}

	}
	
	public void reclamada() {

//		if (getReclamarTextoAnexo()!=null && getReclamarTextoAnexo().length()>400){
		if (!isMostrarAnexoPanel()){
			oncompleteModePanel ="";
			reRenderModePanel="textodecorate1";
//			addFromResourceBundleStatusMessage(Severity.ERROR,
//					"admconfirmaciones.AnexoModalPanel.tamanyo");
		}else{

		reRenderModePanel="tablaResultados,actionButtonsPanel";
		oncompleteModePanel = "Richfaces.hideModalPanel('anexoPanel');";
		ocultarPanelesModales();

		final List<ConfOperacion> seleccionadas = GenericUtils
				.getSeleccionCheckbox(seleccionOPMap);

		if (GenericUtils.isNullOrEmpty(seleccionadas))
			return;

		//
		// Filtro reclamables
		//

		final ArrayList<ConfOperacion> reclamables = new ArrayList<ConfOperacion>();

		for (ConfOperacion co : seleccionadas) {

			if (admconfirmacionesBo.isReclamable(co))
				reclamables.add(co);
		}

		admconfirmacionesBo.reclamada(reclamables, getTipoReclamada());
		admconfirmacionesBo.flush();

		final Date d = new Date();
		for (ConfOperacion co : reclamables) {

			admconfirmacionesBo.recargar(co);

			final AnexoOperacion anexo = new AnexoOperacion(
					new AnexoOperacionId());

			anexo.getId().setOperacionID(co.getOperacionID());
			anexo.getId().setFechaContratacion(co.getFechaContratacion());
			anexo.getId().setFechaModificacion(d);
			anexo.setCodConfi(co.getNumConfirmacion());
			anexo.setEstructu(co.getIdEstructConfirmada());
			anexo.setFechaAnex(getReclamarFechaAnexo());
			anexo.setTextAnex(getReclamarTextoAnexo());
			anexo.setTipoAnex("R");

			anexoOperacionBo.insertar(anexo);
		}

		admconfirmacionesBo.flush();
		prepararReclamada();

		seleccionOPMap.clear();
		refrescarLista();
	
		
		
		}//ERROR LONG	
	}

	public ConfOperacion unaSolaReclamacion(){
		final List<ConfOperacion> seleccionadas = GenericUtils
		.getSeleccionCheckbox(seleccionOPMap);

		if (GenericUtils.isNullOrEmpty(seleccionadas)) 	return null;

		final ArrayList<ConfOperacion> reclamables = new ArrayList<ConfOperacion>();

		for (ConfOperacion co : seleccionadas) {

			if (admconfirmacionesBo.isReclamable(co))
				reclamables.add(co);
		}

		if (!GenericUtils.isNullOrEmpty(reclamables) && reclamables.size()==1) return reclamables.get(0);
		else return null;
		
	}
	
	public void prepararReclamada() {

		setModoTratamiento(Constantes.TIPOANEXO_MODO_E);
		setTipoAnexo(Constantes.TIPOANEXO_RECLAMACION);
//		setTipoAnexo(Constantes.TIPOANEXO_CONFIRMACION);


		setReclamarTextoAnexo(null);
		
		
		//Verificar si solo se ha seleccionado un registro y tiene anexo de reclamacion previo
		ConfOperacion co;
		if (!GenericUtils.isNullOrBlank( co = unaSolaReclamacion() )){
			
			String textoInicial = anexoOperacionBo.recuperarUltimoAnexoReclamado(co.getOperacionID(),co.getFechaContratacion(),"R", co.getNumConfirmacion());			
			setReclamarTextoAnexo(textoInicial);
			
		}
		
		
		
		
		//Parametro Obsoleto.
		setTipoReclamada(TipoReclamacion.NO_RECIBIDA.toString());
		
		
		setReclamarFechaAnexo(admconfirmacionesBo.obtenerFechaSistema());
		setMostrarAnexoPanel(true);
	}

	public void salirSeleccionar(){
		msgBoxAction.voidFunction();
		//return Constantes.SUCCESS;
	}

	public void obtenerSesionOSP(){
		
		try {
			if(sessionId==null || sessionId.equals("")){
			
				enviarConfirmacionOsp.setUsername(credentials.getUsername());
				if (proxyGrantingTicket == null) proxyGrantingTicket = getTicket();
				System.out.println("proxyGrantingTicket=-"+proxyGrantingTicket+"-");
				String passTicket = enviarConfirmacionOsp.getPassTicket(proxyGrantingTicket);
				System.out.println("passTicket=-"+passTicket+"-");
				enviarConfirmacionOsp.setPassword(passTicket);
				String sessionValida=enviarConfirmacionOsp.login(Constantes.I18N_IDIOMA_CASTELLANO_FD, "");
				if(sessionValida.equals("-1")||	sessionValida.equals("-2")){
					System.out.println("Problemas al recuperar la sesion");
					//TODO BORRAR SMM Solo Login anonimo
//					try {
//						StartResponse response = mifidWS.autorizacionTest(ConstantesFD.MIFID_PROCEDENCIA,null);
//						sessionId=response.getHeader().getSessionId();
//						System.out.println("response DERI: " + response.getHeader().getSessionId());
//					} catch (Exception f) {
//						System.out.println("Problemas al recuperar la sesion. Exception");
//					}
				}else{
					sessionId = sessionValida;
				}
			}
		} catch (Exception e) {
			System.out.println("Problemas al recuperar la sesion. Exception");
		//TODO BORRAR SMM Solo Login anonimo
//			try {
//				StartResponse response = mifidWS.autorizacionTest(ConstantesFD.MIFID_PROCEDENCIA,null);
//				sessionId=response.getHeader().getSessionId();
//				System.out.println("response DERI: " + response.getHeader().getSessionId());
//			} catch (Exception f) {
//				System.out.println("Problemas al recuperar la sesion. Exception");
//			}
		
		}
	
	
		
	}
	
	public void irrecuperable() throws Exception {

		ocultarPanelesModales();

		final List<ConfOperacion> seleccionadas = GenericUtils
				.getSeleccionCheckbox(seleccionOPMap);

		//SMM 04/08/2011 Se elimina el documento en el gestor documental		
//		for (ConfOperacion co : seleccionadas){
//			if (co.getIdDocDMS()!=null)
//				{
//						borrarDocumentoDMS(co);
//				}
//		}
		
		admconfirmacionesBo.descartada(seleccionadas,
				TipoCodacion.IRRECUPERABLE,activarOSP);

		activarFirmaDigital = admconfirmacionesBo.activarFirmaDigital();
		System.out.println("activarFirmaDigital: "+activarFirmaDigital);
		
		//Si la session no esta informada intentamos recuperarla.
		obtenerSesionOSP();
		
		for (ConfOperacion co : seleccionadas){
		
			cancelacionFDLogalty_OSP(co);
			
			
			admconfirmacionesBo.recargar(co);
		}
		seleccionOPMap.clear();
		refrescarLista();
		
		
	}

	private void cancelacionFDLogalty_OSP(ConfOperacion co) {
		//Cancelacion firma digital en el caso de que la confirmaciÃ³n haya entrado en circuito:
		//indiloga='E'

		if(activarFirmaDigital && co.getIdDocDMS()!=null && co.getIndicadorLogalty()!=null 
					&& co.getIndicadorLogalty().equals(ConstantesFD.INDILOGA_ONLINE)
		){
				cancelarFD(co);
			
		}else  if(co.getIdDocDMS()!=null && co.getIndicadorOSP()!=null && co.getIndicadorOSP().equals(ConstantesFD.INDICOSP_ONLINE)
				&& ( GenericUtils.isNullOrBlank(co.getIndicadorLogalty()) 
				|| !co.getIndicadorLogalty().equals(ConstantesFD.INDILOGA_ONLINE))		
		){

			//Cancelacion OSP en el caso de que la confirmaciÃ³n haya entrado en circuito:
			//indicosp='E'
			
			cancelarOSP(co);
		
		}
	}

	private void cancelarOSP(ConfOperacion co) {
		//SMM 13/11/2014
		// SI FALLA DEBEMOS DESCARTAR IGUAL PERO MARCAR EL INDICADOR CON D DE DESCARTE
		// PARA QUE EL BATCH NOCTURNO ANULE EL OSP
		String llamadaCancelarOSP = null;
		try {
			
			ModificaRequest modificaRequest = admconfirmacionesBo.creaModificaRequestParaOsp(co, co.getIdDocDMS(),ConstantesFD.OPCION_OSP_CANCELAR, null,true);
			modificaRequest.getModificaInputData().setUsuario(credentials.getUsername());
			modificaRequest.getHeaderRequest().getHostRequest().setSessionId(sessionId);
			
			llamadaCancelarOSP = generarStringLlamadaOSP(modificaRequest);
			
			ModificaResponse modificaResponse = enviarConfirmacionOsp.modifica(modificaRequest);
			
			
			if(null==modificaResponse || null==modificaResponse.getModificaOutputData()||null==modificaResponse.getModificaOutputData().getCodigoRetorno()){
//							statusMessages.add(Severity.INFO ,"#{messages['admconfirmaciones.osp.cancelacion.error']}");
					co.setIndicadorOSP(ConstantesFD.INDICOSP_ADESCARTAR);	
					admconfirmacionesBo.saveResultadoToLog(ConstantesFD.LOG_COD_ERROR_SIN_ACCESO_WS, "Respuesta OSP nula", co, ConstantesFD.LOG_IDWEBSEV_CANCEOSP,ConstantesFD.LOG_WEBSERV_OSP_KO,llamadaCancelarOSP);
				}else if(Integer.valueOf(modificaResponse.getModificaOutputData().getCodigoError().toString())==0
				|| (Integer.valueOf(modificaResponse.getModificaOutputData().getCodigoError().toString())==8550
				&&  Integer.valueOf(modificaResponse.getModificaOutputData().getCodigoRetorno().toString())==1)		
				){
//					 codigoError=8550, codigoRetorno=01 Tambien es valido
//							statusMessages.add(Severity.INFO ,"#{messages['admconfirmaciones.osp.cancelacion.ok']}");					
					
					admconfirmacionesBo.saveResultadoToLog(modificaResponse.getModificaOutputData().getCodigoError().toString(), modificaResponse.getModificaOutputData().getCodigoRetorno(), co, ConstantesFD.LOG_IDWEBSEV_CANCEOSP,ConstantesFD.LOG_WEBSERV_OSP_OK,llamadaCancelarOSP);						
					co.setIndicadorOSP(null);
				}else{
//							statusMessages.add(Severity.INFO ,"Servicio de cancelaciÃ³n Firma Digital. "+
//									modificaResponse.getModificaOutputData().getCodigoError().toString() + ": "+
//									modificaResponse.getModificaOutputData().getCodigoRetorno());
					
					co.setIndicadorOSP(ConstantesFD.INDICOSP_ADESCARTAR);
					String errorTxtOsp = modificaResponse.getModificaOutputData().getCodigoError().toString() + ": "+
					modificaResponse.getModificaOutputData().getCodigoRetorno();
//						if (errorTxtOsp.length()>=200) {errorTxtOsp=errorTxtOsp.substring(0, 199);};
					admconfirmacionesBo.saveResultadoToLog(ConstantesFD.LOG_COD_ERROR_SIN_ACCESO_WS, errorTxtOsp, co, ConstantesFD.LOG_IDWEBSEV_CANCEOSP,ConstantesFD.LOG_WEBSERV_OSP_KO,llamadaCancelarOSP);

				}
		} catch (Exception e) {
			
			String errorLog = e.toString();
			log.debug(e.toString());
			e.printStackTrace();
			
//				if (errorLog.length()>=200) {errorLog=errorLog.substring(0, 199);};
			co.setIndicadorOSP(ConstantesFD.INDICOSP_ADESCARTAR);
			admconfirmacionesBo.saveResultadoToLog(ConstantesFD.LOG_COD_ERROR_SIN_ACCESO_WS, errorLog, co, ConstantesFD.LOG_IDWEBSEV_CANCEOSP,ConstantesFD.LOG_WEBSERV_OSP_KO,llamadaCancelarOSP);
							
		
		}
	}

	private void borrarOSP(ConfOperacion co) {
		String llamadaBorrarOSP = null;
		try {
			
			ModificaRequest modificaRequest = admconfirmacionesBo.creaModificaRequestParaOsp(co, co.getIdDocDMS(),ConstantesFD.OPCION_OSP_BORRAR, null, true);
			modificaRequest.getModificaInputData().setUsuario(credentials.getUsername());
			modificaRequest.getHeaderRequest().getHostRequest().setSessionId(sessionId);
			
			llamadaBorrarOSP = generarStringLlamadaOSP(modificaRequest);
			
			ModificaResponse modificaResponse = enviarConfirmacionOsp.modifica(modificaRequest);
			
			
			if(null==modificaResponse || null==modificaResponse.getModificaOutputData()||null==modificaResponse.getModificaOutputData().getCodigoRetorno()){
					co.setIndicadorOSP(ConstantesFD.INDICOSP_ADESCARTAR);	
					admconfirmacionesBo.saveResultadoToLog(ConstantesFD.LOG_COD_ERROR_SIN_ACCESO_WS, "Respuesta OSP nula", co, ConstantesFD.LOG_IDWEBSEV_BORRAOSP,ConstantesFD.LOG_WEBSERV_OSP_KO,llamadaBorrarOSP);
				}else if(Integer.valueOf(modificaResponse.getModificaOutputData().getCodigoError().toString())==0
				){
					
					admconfirmacionesBo.saveResultadoToLog(modificaResponse.getModificaOutputData().getCodigoError().toString(), modificaResponse.getModificaOutputData().getCodigoRetorno(), co, ConstantesFD.LOG_IDWEBSEV_BORRAOSP,ConstantesFD.LOG_WEBSERV_OSP_OK,llamadaBorrarOSP);						
					co.setIndicadorOSP(null);
				}else{
					
					co.setIndicadorOSP(ConstantesFD.INDICOSP_ADESCARTAR);
					String errorTxtOsp = modificaResponse.getModificaOutputData().getCodigoError().toString() + ": "+
					modificaResponse.getModificaOutputData().getCodigoRetorno();

					admconfirmacionesBo.saveResultadoToLog(ConstantesFD.LOG_COD_ERROR_SIN_ACCESO_WS, errorTxtOsp, co, ConstantesFD.LOG_IDWEBSEV_BORRAOSP,ConstantesFD.LOG_WEBSERV_OSP_KO,llamadaBorrarOSP);

				}
		} catch (Exception e) {
			
			String errorLog = e.toString();
			log.debug(e.toString());
			e.printStackTrace();
			
			co.setIndicadorOSP(ConstantesFD.INDICOSP_ADESCARTAR);
			admconfirmacionesBo.saveResultadoToLog(ConstantesFD.LOG_COD_ERROR_SIN_ACCESO_WS, errorLog, co, ConstantesFD.LOG_IDWEBSEV_BORRAOSP,ConstantesFD.LOG_WEBSERV_OSP_KO,llamadaBorrarOSP);
							
		
		}
	}

	
	private void cancelarFD(ConfOperacion co) {
		try {
//			String cancelOk = admconfirmacionesBo.cancelarFirmaDigital(co,sessionId,proxyGrantingTicket);
			String cancelOk = admconfirmacionesBo.cancelarFirmaCentralizada(co,sessionId,proxyGrantingTicket);
			if("OK".equals(cancelOk)){
//			statusMessages.add(Severity.INFO ,"#{messages['admconfirmaciones.firmadigital.firma.ok']}");
				admconfirmacionesBo.saveResultadoToLog(cancelOk, "Cancelacion FD Logalty", co, ConstantesFD.LOG_IDWEBSEV_CANCELAR,ConstantesFD.LOG_IDWEBSEV_ESTADOCO_OK);
			}else if("KO".equals(cancelOk)){
//			statusMessages.add(Severity.INFO ,"#{messages['admconfirmaciones.firmadigital.cancelacion.error']}");
				admconfirmacionesBo.saveResultadoToLog(ConstantesFD.LOG_COD_ERROR_SIN_ACCESO_WS, "Cancelacion FD Logalty", co, ConstantesFD.LOG_IDWEBSEV_CANCELAR,ConstantesFD.LOG_IDWEBSEV_ESTADOCO_KO);
			}
			else{
//			statusMessages.add(Severity.INFO ,"Servicio de cancelaciÃ³n Firma Digital. "+cancelOk);
				admconfirmacionesBo.saveResultadoToLog(ConstantesFD.LOG_COD_ERROR_SIN_ACCESO_WS, cancelOk, co, ConstantesFD.LOG_IDWEBSEV_CANCELAR,ConstantesFD.LOG_IDWEBSEV_ESTADOCO_KO);						
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			admconfirmacionesBo.saveResultadoToLog(ConstantesFD.LOG_COD_ERROR_SIN_ACCESO_WS, "Cancelacion FD Logalty", co, ConstantesFD.LOG_IDWEBSEV_CANCELAR,ConstantesFD.LOG_IDWEBSEV_ESTADOCO_KO);
		}
	}


	
	
	private Long generarDocumentoDMS(ConfOperacion co, byte[] pdf) throws Exception {

		
		//SMM 27/10/2011 NO GENERAR DMS TEMPORALMENTE
		//SMM 24/04/2012 Se reactiva
		//SMM 20/06/2012 Se aÃ±ade condiciÃ³n
		if (!activarOSP){
			return null;
		}else {
		
//			codDocumento = co.getIdDocDMS().toString();
		
		StringBuffer sb = new StringBuffer();
		// GENERAR CODI DOCUMENTO
//TODO SI ES M --> A (y borrar previo).
		
		if (co.getOperacionID()!=null){

		sb.append(GenericUtils.lpad(co.getOperacionID().toString(), 12,"0"))
		.append("|")
		.append(co.getEvenConf().substring(0, 1))
//		.append("A")
		.append("|")
		.append(GenericUtils.lpad(co.getNumConfirmacion().toString(), 12,"0"));
		
		} else {
			//Sera un Producto Compuesto
			sb.append(GenericUtils.lpad(co.getIdEstructConfirmada().toString(), 12,"0"))
			.append("|")
			.append(co.getEvenConf().substring(0, 1))
//			.append("A")
			.append("|")
			.append(GenericUtils.lpad(co.getNumConfirmacion().toString(), 12,"0"));

		}
		
		String codDocumento = sb.toString();
		
		
		//GENERAR CODIGO EXPEDIENTE 
		String contrato ="";
		if (co.getOperacionID()!=null){
		
			if (admconfirmacionesBo.esCliente(co.getOperacion().getContrapa())){
				contrato = admconfirmacionesBo.obtenerContrato(co.getOperacion().getContrapa(),co.getOperacion().getEntidad().toString());
				contrato = contrato.substring(0, contrato.indexOf("-"));
				// Se eliminan los dos digitos de control.
				// .concat(contrato.substring(contrato.lastIndexOf("-")+1, contrato.length()));
			}
			else{
				contrato = co.getOperacionID().toString();
			}
			
		}else{

			if (admconfirmacionesBo.esCliente(co.getEstructura().getContrapartida().getId())){
				contrato = admconfirmacionesBo.obtenerContrato(co.getEstructura().getContrapartida().getId(), admconfirmacionesBo.recuperarEntidad(co.getEstructura()));
				contrato = contrato.substring(0, contrato.indexOf("-"));
				// Se eliminan los dos digitos de control.
				// .concat(contrato.substring(contrato.lastIndexOf("-")+1, contrato.length()));
			}
			else{
				contrato = co.getIdEstructConfirmada().toString();
			}
		}
		
		
		
		sb = new StringBuffer();
		
		String  entidadCod ;
		if (co.getOperacionID()!=null){
			 entidadCod = convertirEntidad(co.getOperacion().getEntidad().toString());	
		}else{
			entidadCod = convertirEntidad(admconfirmacionesBo.recuperarEntidad(co.getEstructura()));	
		}

		
		
		sb.append(entidadCod)
		.append("|")
		.append("DD ")
		.append("|")
		.append(GenericUtils.lpad(contrato, 15,"0"));
		String codExpediente = sb.toString();
		
		String descripcionCodigoExpediente = codExpediente;
		String nombreTipoExpediente = Constantes.TIPO_EXPEDIENTE;
		String nombreTipoDocumento = Constantes.TIPO_DOCUMENTO;
		
		String descripcionFichero;
		if (co.getOperacionID()!=null){
			descripcionFichero = descripcionFichero(co.getOperacion().getId().getNumeroOperacion(),co.getEvenConf().substring(0, 1));	
		}else{
			descripcionFichero = descripcionFichero(co.getIdEstructConfirmada(),co.getEvenConf().substring(0, 1));
		}
		
		
	
		
		String usuarioAlta = credentials.getUsername(); 
		String nombreFichero=descripcionFichero.replace(" ", "_").concat(".pdf");
		
		Long claveDMS = null;
		
		try {

			claveDMS = principalDMS.insertarNuevoDocumento(pdf, nombreFichero, nombreTipoExpediente, 
					nombreTipoDocumento, codDocumento, descripcionCodigoExpediente,  codExpediente, 
					descripcionFichero, usuarioAlta);

		} catch (Exception e) {
			if (e.toString().contains("EB-015")){
				
				principalDMS.eliminarDocumento(-1L, codDocumento, nombreTipoExpediente, nombreTipoDocumento, codExpediente);
				
				claveDMS = principalDMS.insertarNuevoDocumento(pdf, nombreFichero, nombreTipoExpediente, 
						nombreTipoDocumento, codDocumento, descripcionCodigoExpediente,  codExpediente, 
						descripcionFichero, usuarioAlta);
			}else{
				throw e;	
			}
			
		}

		return claveDMS;
	}
		}
	
	private String convertirEntidad(String entidad ) {
		
		if ("81".equals(GenericUtils.lpad(entidad, 2,"0"))) {
			return "01";
		}else if ("42".equals(GenericUtils.lpad(entidad, 2,"0"))) {
			return "BG";
		}else{
			return "05";
		}
		
	}

	private String descripcionFichero(Long operacion, String evento) {
//		A ALTA
//		M RECTIFICACION
//		C CANCELACION
//		P CANCELACION PÃ‚RCIAL + NCORRELA
		String numOper = operacion.toString();
		
		if ("A".equals(evento)) {
			return "Alta ".concat(numOper);
		}else if ("M".equals(evento)) {
			return "RectificaciÃ³n ".concat(numOper);
		}else if ("C".equals(evento)) {
			return "CancelaciÃ³n ".concat(numOper);
		}else if ("P".equals(evento)) {
			return "CancelaciÃ³n Parcial ".concat(numOper);
		}else {
			return numOper;
		}
		
	}

	private void borrarDocumentoDMS(ConfOperacion co) throws Exception {

		//SMM 27/10/2011 NO GENERAR-BORRAR DMS TEMPORALMENTE
		//OJO!!!!!!
		//Mirar Funcion descartada en BO donde tambien se ha eliminado temporalmente
		//el borrar el DMS de la tabla confiope. En action descarta e irrecuperable.
		//		admconfirmacionesBo.descartada()

//SMM 24/04/2012 SE VUELVE A ACTIVAR		
//SMM 20/06/2012 Se aÃ±ade condiciÃ³n
		if (activarOSP){
//		if (false){
		String codDocumento;

//			codDocumento = co.getIdDocDMS().toString();
		
		principalDMS.eliminarDocumento( co.getIdDocDMS(),null, null, null, null);
		}
		
	}

	public void descartada() throws Exception {

		ocultarPanelesModales();

		final List<ConfOperacion> seleccionadas = GenericUtils
				.getSeleccionCheckbox(seleccionOPMap);

		//SMM 04/08/2011 Se elimina el documento en el gestor documental
		//JOLL 10/12/2013 No borrarmos el documentoDMS, lo hace el ws de firma digital
		/*for (ConfOperacion co : seleccionadas){
			if (co.getIdDocDMS()!=null)
				{
						borrarDocumentoDMS(co);
				}
		}*/
		
		admconfirmacionesBo.descartada(seleccionadas, TipoCodacion.DESCARTADA,activarOSP);
		activarFirmaDigital = admconfirmacionesBo.activarFirmaDigital();
		System.out.println("activarFirmaDigital: "+activarFirmaDigital);
		
		//Si la session no esta informada intentamos recuperarla.
		obtenerSesionOSP();
		
		for (ConfOperacion co : seleccionadas){

			//			01/12/2014 SMM - Solo llamamos a Cancelar FD (logalty), esta llamada ya cancela OSP. 
			//			Solo en el caso que no haya Logalty y si OSP se cancelara solo OSP
		
			cancelacionFDLogalty_OSP(co);
			admconfirmacionesBo.recargar(co);
		}

		seleccionOPMap.clear();
		refrescarLista();
	}
	public void seleccionarDescarteIrecuper(){
		msgBoxAction
		.mostrarMsg("#{admconfirmacionesAction.descartada()}", // funcionSi
				"#{admconfirmacionesAction.irrecuperable()}", // funcionNo
				"#{admconfirmacionesAction.salirSeleccionar()}", // funcionSalir
				"Descartar", // messageSi
				"Irrecuperable", // messageNo
				"Salir", // messageSalir
				"seleccionPanel,tablaResultados", // reRenderSi Descartada
				"seleccionPanel,tablaResultados", // reRenderNo Irrecuperable
				"seleccionPanel",// reRendersalir
				"Como desea marcar la operaci�n, Descartada o Irrecuperable?");
	}
	
	public Boolean habilitadoPrevia(ConfOperacion cOperacion) {
		return admconfirmacionesBo.habilitarVistaPrevia(cOperacion);
	}

	public Boolean habilitadoRecibida() {
		// return
		// (admconfirmacionesBo.habilitarRecibida(admConfirmacionesPantalla.getAdmconfirmacionSelec()));
		return admconfirmacionesBo.habilitarRecibida(GenericUtils
				.getSeleccionCheckbox(seleccionOPMap));
	}

	public Boolean habilitadoRecepcionada() {
		// return
		// (admconfirmacionesBo.habilitarRecibida(admConfirmacionesPantalla.getAdmconfirmacionSelec()));
		return admconfirmacionesBo.habilitarRecepcionada(GenericUtils
				.getSeleccionCheckbox(seleccionOPMap));
	}

	
	public Boolean habilitadoDescartar() {
			return true;
//		return admconfirmacionesBo.habilitarDescartar(GenericUtils
//				.getSeleccionCheckbox(seleccionOPMap));
	}

	public Boolean habilitadoEnviar() {
		return admconfirmacionesBo.habilitarEnviar(GenericUtils
				.getSeleccionCheckbox(seleccionOPMap));
	}

	public void init() {
		excel = false;
		setErrorWS(false);
		if(null==sessionId)
			sessionId="";
		activarOSP = admconfirmacionesBo.activarOSP();
		activarFirmaDigital = admconfirmacionesBo.activarFirmaDigital();
		
		if(messageAdmConfirmacionesMO==null){
			messageAdmConfirmacionesMO = new MessageBoxAction();
		}
		
		if (isRedireccionExterna()) {

			// Se carga la pÃ¡gina despuÃ©s de regresar de una pantalla externa.
			// Se reinicializa algunas propiedades

			ocultarPanelesModales();

			setRedireccionExterna(false);
		}

		if (Constantes.MODO_AGE.equals(modo) && isPrimerAcceso()) {

			paginationData.reset();
			seleccionOPMap.clear();
			setPrimerAcceso(false);

			ocultarPanelesModales();
			setReclamarTipoAnexo(Constantes.TIPOANEXO_DESCR_RECLAMACION);
			
			cargarAgenda(false);

		} else if (Constantes.MODO_OPE.equals(modo) && isPrimerAcceso()) {
			buscarDesdeMantOperaciones(historicoOperacion);
			setPrimerAcceso(false);
		}

		final boolean rendered = !isPrimerAcceso()
				|| GenericUtils.in(modo, Constantes.MODO_OPE, Constantes.MODO_AGE);

		botonEnviar.setRendered(rendered);
		botonDescartada.setRendered(rendered);
		botonRecibida.setRendered(rendered);
		botonRecepcionada.setRendered(rendered);
		botonReclamar.setRendered(rendered);

		if (!isPrimerAcceso())
			return;

		botonAlta.setDisabled(!authorizator.isPermisoAlta());
		botonEnviar.setDisabled(!authorizator.isPermisoModificacion());
		botonDescartada.setDisabled(!authorizator.isPermisoModificacion());
		botonRecibida.setDisabled(!authorizator.isPermisoModificacion());
		botonRecepcionada.setDisabled(!authorizator.isPermisoModificacion());
		botonReclamar.setDisabled(!authorizator.isPermisoModificacion());

		
		setReclamarTipoAnexo(Constantes.TIPOANEXO_DESCR_RECLAMACION);
//		setReclamarTipoAnexo(Constantes.TIPOANEXO_DESCR_CONFIRMACION);
		prepararReclamada();

	}
	
	private List<ConfOperacion> cargarAgenda(Boolean batch) {

		final String estadoEvento = estadoAgenda ? "P" : "N";
		final Short codigoEvento = eventoSelectAgenda.getCodigoEvento();

		List<ConfOperacion> listaAdmconfirmaciones;
		
		if (estructuraId != null) {
			listaAdmconfirmaciones = cargarDesdeAgenda(codigoEvento, estadoEvento, batch);
			return listaAdmconfirmaciones;
		}

		final String prodId = (GenericUtils.isNullOrBlank(producto)) ? null
				: producto.getId();

		final Long numOperDesde = (GenericUtils.isNullOrBlank(numOperIni)) ? null
				: Long.parseLong(numOperIni);

		final Long numOperHasta = (GenericUtils.isNullOrBlank(numOperFin)) ? null
				: Long.parseLong(numOperFin);

		return cargarDesdeAgendaSinEst(codigoEvento, estadoEvento, numOperDesde,
				numOperHasta, fechaTraIni, prodId, batch);
		
	}

	public List<ConfOperacion> cargarDesdeAgenda(Short codigoEvento, String estadoEvento, Boolean batch) {
		List<ConfOperacion> listaAdmconfirmaciones;
		Date fechaSistema = admconfirmacionesBo.obtenerFechaSistema();
		if (excel) {
		listaAdmconfirmaciones = admconfirmacionesBo
				.cargarDatosConfirmacionAgendaEstructura(codigoEvento,
						estadoEvento, fechaSistema,  paginationData.getPaginationDataForExcel(), batch);
		}else{
		listaAdmconfirmaciones = admconfirmacionesBo
				.cargarDatosConfirmacionAgendaEstructura(codigoEvento,
					estadoEvento, fechaSistema,  paginationData, batch);
		}
		admConfirmacionesPantalla
				.setAdmconfirmacionesList(listaAdmconfirmaciones);
		return listaAdmconfirmaciones;

	}

	public List<ConfOperacion> cargarDesdeAgendaSinEst(Short codigoEvento,
			String estadoEvento, Long numOperDesde, Long numOperHasta,
			Date fechaTraIni, String producto, Boolean batch) {
		
		List<ConfOperacion> listaAdmconfirmaciones;
		Date fechaSistema = admconfirmacionesBo.obtenerFechaSistema();

		if (excel) {
			listaAdmconfirmaciones = admconfirmacionesBo
					.cargarDatosConfirmacionesAgenda(numOperDesde,
							numOperHasta, fechaTraIni, fechaTraIni,
							estadoEvento, codigoEvento, fechaSistema, producto,
							paginationData.getPaginationDataForExcel(), batch);
		} else {
			listaAdmconfirmaciones = admconfirmacionesBo
					.cargarDatosConfirmacionesAgenda(numOperDesde,
							numOperHasta, fechaTraIni, fechaTraIni,
							estadoEvento, codigoEvento, fechaSistema, producto,
							paginationData, batch);
		}
		admConfirmacionesPantalla
				.setAdmconfirmacionesList(listaAdmconfirmaciones);
		return listaAdmconfirmaciones;
	}

	public void buscarDesdeMantOperaciones(HistoricoOperacion historicoOperacion) {
		List<ConfOperacion> listaAdmconfirmaciones;
		listaAdmconfirmaciones = admconfirmacionesBo.cargarDatosConfirmaciones(
				historicoOperacion.getId().getNumeroOperacion(),
				historicoOperacion.getId().getNumeroOperacion(), null, null,
				null, null, null, null, null, null, null, null, null,
				historicoOperacion.getId().getFechaContratacion(), null, null,
				null,null, paginationData, false);
		admConfirmacionesPantalla
				.setAdmconfirmacionesList(listaAdmconfirmaciones);
	}

	public String retornoPdf() {
		return "pdf";
	}

	@Out(required = false)
	public ConfOperacion confOperacionaux;

	@Out(required = false)
	public Contrapartida contrapartidaaux;

	public ConfOperacion getConfOperacionaux() {
		return confOperacionaux;
	}

	public void setConfOperacionaux(ConfOperacion confOperacionaux) {
		this.confOperacionaux = confOperacionaux;
	}

	public Contrapartida getContrapartidaaux() {
		return contrapartidaaux;
	}

	public void setContrapartidaaux(Contrapartida contrapartidaaux) {
		this.contrapartidaaux = contrapartidaaux;
	}

	List<ConfOperacion> confirmacionesMM = new ArrayList<ConfOperacion>();

	private AdmConfirmacionOracleReport acOracleReport;

	/**
	 * Filtra las confirmaciones que no cumplen los prerequisitos.
	 * 
	 * @param seleccionadas
	 * @return
	 */
	@SuppressWarnings("unchecked")
	protected List<ConfOperacion> filtroMultiples(
			List<ConfOperacion> seleccionadas) {

		final ArrayList<ConfOperacion> seleccionadasOk = new ArrayList<ConfOperacion>();

		for (ConfOperacion confOperacion : seleccionadas) {
			try {

				// Las modificadas se eliminan
				if (admconfirmacionesBo.operacionModificada(confOperacion)) {

					addFromResourceBundleStatusMessage(Severity.WARN,
							"admconfirmaciones.enviar.operacionactualizada",
							confOperacion.getNumConfirmacion().toString(), confOperacion
									.getVista().getNcorrEstructu());

					continue;
				}

				admconfirmacionesBo.recargar(confOperacion);

				// Las incorrectas se eliminan
				
				if ((confOperacion.getOperacion() == null
						|| confOperacion.getOperacion().getContrapartida() == null) &&
					(confOperacion.getEstructura() == null
						|| confOperacion.getEstructura().getContrapartida() == null)) {
					
					addFromResourceBundleStatusMessage(Severity.WARN,
							"admconfirmaciones.enviar.confirmacionincorrecta",
							confOperacion.getNumConfirmacion().toString(), confOperacion
									.getVista().getNcorrEstructu());

					continue;
					
					
				}

				final String evenconf = confOperacion.getEventoConfirmacion()
						.getCodigo();

				// Las que no sean FIJACION o LIQUIDACION se eliminan
				if (!GenericUtils.in(evenconf, EventoConfirmacion.FIJACION,
						EventoConfirmacion.LIQUIDACION)) {

					addFromResourceBundleStatusMessage(Severity.WARN,
							"admconfirmaciones.enviar.error.noLoX",
							confOperacion.getNumConfirmacion().toString(), confOperacion
									.getVista().getNcorrEstructu());

					continue;
				}

				// Las que no sean CORREO_INTEGRADO o SWIFT se eliminan
				if (!GenericUtils.in(confOperacion.getCanalConfirmacion(),
						CanalOperacion.CORREO_INTEGRADO, CanalOperacion.SWIFT)) {

					addFromResourceBundleStatusMessage(Severity.WARN,
							"admconfirmaciones.enviar.error.noCIoSW",
							confOperacion.getNumConfirmacion().toString(), confOperacion
									.getVista().getNcorrEstructu());

					continue;
				}

				// Las MM se eliminan
				if (GenericUtils.equals(confOperacion.getCanalConfirmacion(),
						CanalOperacion.MANUAL_MANUAL)) {

					addFromResourceBundleStatusMessage(Severity.WARN,
							"admconfirmaciones.enviar.error.esMM",
							confOperacion.getNumConfirmacion().toString(), confOperacion
									.getVista().getNcorrEstructu());

					continue;
				}

				// Las SIBIS se eliminan
				if (GenericUtils.equals(EventoConfirmacion.ALTA, evenconf)
						&& admconfirmacionesBo.esSibis(confOperacion)) {

					addFromResourceBundleStatusMessage(Severity.WARN,
							"admconfirmaciones.sibis", confOperacion
									.getNumConfirmacion().toString(), confOperacion
									.getVista().getNcorrEstructu());

					continue;
				}

				seleccionadasOk.add(confOperacion);

			} catch (Exception e) {

				addFromResourceBundleStatusMessage(e,
						"admconfirmaciones.enviar.error.generico",
						confOperacion.getNumConfirmacion().toString(), confOperacion
								.getVista().getNcorrEstructu());

				return Collections.EMPTY_LIST;
			}
		}

		return seleccionadasOk;
	}

	/**
	 * 
	 * @param confOperacion
	 * @return <code>false</code> en el caso que se tenga que abortar el
	 *         procesamiento subisiguiente.
	 */
	public boolean validacion(ConfOperacion confOperacion) {

		confirmacionesMM = new ArrayList<ConfOperacion>(1);

		try {
			if ((confOperacion.getOperacion() == null
					|| confOperacion.getOperacion().getContrapartida() == null) && confOperacion.getEstructura()==null) {

				addFromResourceBundleStatusMessage(Severity.ERROR,
						"admconfirmaciones.enviar.confirmacionincorrecta",
						confOperacion.getNumConfirmacion().toString(), confOperacion
						.getVista().getNcorrEstructu());

				return false;
			}

			// Modificada?
			if (confOperacion.getEstructura()==null && admconfirmacionesBo.operacionModificada(confOperacion)) {

				addFromResourceBundleStatusMessage(Severity.ERROR,
						"admconfirmaciones.enviar.operacionactualizada",
						confOperacion.getNumConfirmacion().toString(), confOperacion
						.getVista().getNcorrEstructu());

				return false;
			}

//			if (!GenericUtils.in(confOperacion.getCanalConfirmacion(),
//					CanalOperacion.CORREO_INTEGRADO, CanalOperacion.SWIFT,
//					CanalOperacion.MANUAL_MANUAL)) {
//
//				addFromResourceBundleStatusMessage(Severity.ERROR,
//						"admconfirmaciones.enviar.error.noCIoSWoMM",
//						confOperacion.getNumConfirmacion().toString(), confOperacion
//						.getVista().getNcorrEstructu());
//
//				return false;
//			}

			if (confOperacion.getEstructura()==null &&  GenericUtils.equals(confOperacion.getEventoConfirmacion()
					.getCodigo(), EventoConfirmacion.ALTA)
					&& admconfirmacionesBo.esSibis(confOperacion)) {

				addFromResourceBundleStatusMessage(Severity.ERROR,
						"admconfirmaciones.sibis", confOperacion
								.getNumConfirmacion().toString(), confOperacion
								.getVista().getNcorrEstructu());

				return false;
			}

			if (GenericUtils.equals(confOperacion.getCanalConfirmacion(),
					CanalOperacion.MANUAL_MANUAL)) {

				if (confOperacion.getEstructura()==null && confOperacion.getOperacion().getId() == null) {

					addFromResourceBundleStatusMessage(Severity.ERROR,
							"admconfirmaciones.error.enviar.nooperacion",
							confOperacion.getNumConfirmacion().toString(), confOperacion
							.getVista().getNcorrEstructu());

					return false;
				}

				confirmacionesMM.add(confOperacion);
			}
		} catch (Exception e) {

			addFromResourceBundleStatusMessage(e,
					"admconfirmaciones.enviar.error.generico", confOperacion
							.getNumConfirmacion().toString(), confOperacion
							.getVista().getNcorrEstructu());

			return false;
		}

		return true;
	}

	public void logConfirmacion(){
		confOperacionSelect = admConfirmacionesPantalla.getAdmconfirmacionSelec();
	}

	public void enviarConfirmacionManual() {
		enviarFDManual=true;
		enviarConfirmacion();
	}
	public void enviarConfirmacionPre() {
		enviarFDManual=false;
		enviarConfirmacion();
	}

	
	public void enviarConfirmacion() {

		ocultarPanelesModales();
//		Context ctx;


		/*
//CODIGO CON CONTROL TRANSACCION		
		UserTransaction ut = null;
		try {
			
	        


			ut = ((javax.transaction.UserTransaction)org.jboss.seam.transaction.Transaction.instance());
			
			if (ut.getStatus()== Status.STATUS_ACTIVE){
				ut.commit();
				
			}
			ut.setTransactionTimeout(3000);
			ut.begin();
			entityManager.joinTransaction();
			_enviarConfirmacion();
			
		} catch (Exception e) {
			e.printStackTrace();
			
			if (confOperacion!=null){
				addFromResourceBundleStatusMessage(e,e.getMessage(),
						"admconfirmaciones.enviar.error.generico", confOperacion
								.getNumConfirmacion().toString(), confOperacion
								.getVista().getNcorrEstructu());
				
			}else{
				addFromResourceBundleStatusMessage(e,e.getMessage());
				}
		
			try {
					ut.rollback();
				} catch (Exception e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
		
		}finally{
			try {
				if (ut.getStatus()!= Status.STATUS_ACTIVE){
					ut.setTransactionTimeout(300);
					ut.begin();
					entityManager.joinTransaction();
					}
			} catch (Exception e) {
				e.printStackTrace();
			}
			
		}
		
		
		*/
		
		
		
		
//		UserTransaction ut = null;
		try {
			
//			ut = ((javax.transaction.UserTransaction)org.jboss.seam.transaction.Transaction.instance());
			
//			 ctx = new InitialContext(System.getProperties());  
//			 ut = (UserTransaction)ctx.lookup("java:comp/UserTransaction");
////			if (Status.==0);
////			STATUS_NO_TRANSACTION 6 STATUS_ACTIVE 0
//			if (ut.getStatus()== Status.STATUS_ACTIVE){
//				ut.commit();
//				
//			}
//			ut.setTransactionTimeout(3000);
//			ut.begin();
//			entityManager.joinTransaction();
			_enviarConfirmacion();
//			transactionTimeoutSeconds = 300;
//	        ((javax.transaction.UserTransaction)org.jboss.seam.transaction.Transaction.instance()).setTransactionTimeout(transactionTimeoutSeconds);
			
		} catch (Exception e) {
			e.printStackTrace();
			
			if (confOperacion!=null){
				addFromResourceBundleStatusMessage(e,e.getMessage(),
						"admconfirmaciones.enviar.error.generico", confOperacion
								.getNumConfirmacion().toString(), confOperacion
								.getVista().getNcorrEstructu());
				
			}else{
				addFromResourceBundleStatusMessage(e,e.getMessage());
				}

			//Abajo todo descomentado ROLLBACK Y FINALLY
//			//ROLLBACK En teoria ya lo hace.
//				try {
//					ut.rollback();
//				} catch (Exception e1) {
//					e1.printStackTrace();
//				}
		
//		}finally{
//			try {
//				if (ut.getStatus()!= Status.STATUS_ACTIVE){
//					ut.setTransactionTimeout(300);
//					ut.begin();
//					entityManager.joinTransaction();
//					}
//			} catch (Exception e) {
//				e.printStackTrace();
//			}
			
		}
	}

	public void enviarConfirmacion_fase2() {

		ocultarPanelesModales();

		try {

			// Re-generaciÃ³n del XML para ver el PDF si el evento es de alta
			if (GenericUtils.equals(getTipoEventoEnvio(), "A")) {

				final DescripcionTipoConfirmacion dtc = admconfirmacionesBo.buscarTipoConfirmacion("A");
				confOperacionaux.setEventoConfirmacion(dtc);
				admconfirmacionesBo.guardarDatosConfirmacion(confOperacionaux);
				
				//Descartar posibles altas anteriores de la misma operaciÃ³n enviadas en circuito de FC 
				List<ConfOperacion> listaRecAlta = admconfirmacionesBo.buscarConfirmacionesRectificacionAlta(confOperacionaux.getOperacionID(), confOperacionaux.getIdEstructConfirmada(), confOperacionaux.getNumConfirmacion());
				if(listaRecAlta.size()>0){
					
					activarFirmaDigital = admconfirmacionesBo.activarFirmaDigital();
					//Si la session no esta informada intentamos recuperarla.
					obtenerSesionOSP();
					
					for(int i=0;i<listaRecAlta.size();i++){
						ConfOperacion actual = listaRecAlta.get(i);
					
//						01/12/2014 SMM - Solo llamamos a Cancelar FD (logalty), esta llamada ya cancela OSP. 
//						Solo en el caso que no haya Logalty y si OSP se cancelara solo OSP
						
						cancelacionFDLogalty_OSP(actual);
						
						}
					
				}
				
				//TODO SMM BORRAR DMS ANTERIOR SI EXISTE.
				admconfirmacionesBo.descartarAltas(confOperacionaux);
				
				admconfirmacionesBo.flush();				
				admconfirmacionesBo.rehacerXML(confOperacionaux);
				admconfirmacionesBo.recargar(confOperacionaux);
			}

			//setTipoEventoEnvioPanel(EventoConfirmacion.RECTIFICACION.toString());
			

			_enviarConfirmacion_fase2();
		} catch (Exception e) {
			if (e instanceof SQLException){
				addFromResourceBundleStatusMessage(e,
						"admconfirmaciones.error.rehacerXML", e.getMessage());				
			}else{
			addFromResourceBundleStatusMessage(e,
					"admconfirmaciones.enviar.error.generico", confOperacionaux
							.getNumConfirmacion().toString(), confOperacionaux
							.getVista().getNcorrEstructu());
			}
		}
	}

	private void _enviarConfirmacion() throws SQLException {

		List<ConfOperacion> seleccionadas = GenericUtils
				.getSeleccionCheckbox(seleccionOPMap);

		if (seleccionadas.isEmpty()) {

			addStatusMessage(Severity.ERROR,
					"#{messages['admconfirmaciones.error.noseleccion']}");
			return;
		}

		final boolean seleccionMultiple = 1 < seleccionadas.size();

		if (seleccionMultiple) {

			seleccionadas = filtroMultiples(seleccionadas);

			if (seleccionadas.isEmpty())
				return;
		} else {
			if (!validacion(seleccionadas.get(0)))
				return;
		}

		if (!seleccionMultiple) {

			confOperacionaux = admconfirmacionesBo.cargar(seleccionadas.get(0)
					.getNumConfirmacion());

			if (GenericUtils.equals(confOperacionaux.getEvenConf(),
					EventoConfirmacion.RECTIFICACION)) {

				setMostrarEnviarFase2Panel(true);
			} else {
				tipoEventoEnvio = confOperacionaux.getEvenConf();
				_enviarConfirmacion_fase2();
			}

			return;
		}

		// mÃºltiple

		int contador = 0;

		for (ConfOperacion confOperacion : seleccionadas) {

			final String cc = confOperacion.getCanalConfirmacion();

//			System.out.println(confOperacion.getNumConfirmacion());
//			System.out.println(confOperacion.getOperacion().getId().getNumeroOperacion());
//			System.out.println(cc);
//			System.out.println(contador);
			
			
			if (CanalOperacion.CORREO_INTEGRADO.equals(cc)) {

				admconfirmacionesBo.confirmarCI(confOperacion, confOperacion
						.getConfirmReclamada());

			} else if (CanalOperacion.SWIFT.equals(cc)) {

				admconfirmacionesBo.confirmarSW(confOperacion, confOperacion
						.getConfirmReclamada());
			} else if(GenericUtils.in(cc,CanalOperacion.BATCH_FAX, CanalOperacion.ON_LINE_FAX, CanalOperacion.ON_LINE_EMAIL, CanalOperacion.BATCH_EMAIL)){
				obtenerDatosFax(confOperacion);
			}else
			{

				// Esta comprobaciÃ³n se deberÃ­a haber hecho en
				// filtroMultiples(), por lo que es un ERROR.

				throw new IllegalStateException();
			}

			contador++;

			seleccionOPMap.remove(confOperacion);

			admconfirmacionesBo.recargar(confOperacion);
//			if (contador==450){
//				System.out.println(contador);
//			}
			
		}

		addFromResourceBundleStatusMessage(Severity.INFO,
				"admconfirmaciones.enviar.total", contador);

		seleccionOPMap.clear();
		refrescarLista();
	}

	private void _enviarConfirmacion_fase2() throws SQLException {

		// AquÃ­ SÃ³lo TENGO UNA , grande y Ãºnica

		if (confOperacionaux.getDocumentoConfirmacion() != null
				&& confOperacionaux.getDocumentoConfirmacion().getXmlorigi() == null) {

			addFromResourceBundleStatusMessage(Severity.ERROR,
					"admconfirmaciones.error.enviar.noxmldocumento", confOperacionaux
							.getNumConfirmacion().toString());

			return;
		}

		if (!GenericUtils.equals(confOperacionaux.getEvenConf(),
				tipoEventoEnvio)) {

			final DescripcionTipoConfirmacion dtc = admconfirmacionesBo
					.buscarTipoConfirmacion(tipoEventoEnvio);
			confOperacionaux.setEventoConfirmacion(dtc);

			admconfirmacionesBo.guardarDatosConfirmacion(confOperacionaux);
		}

		// Hay confirmaciones MM?
		if (!confirmacionesMM.isEmpty()) {

			final List<Long> numeroOperaciones = obtenerNumeroOperaciones(confirmacionesMM);

			msgBoxAction.mostrarMsg("#{admconfirmacionesAction.retornoLlamadaMM}", // 
					null, null, null, //
					"resultadosConsulta,table,msgboxPanel", "msgboxPanel", //
					"No existen plantillas de confirmaciÃ³n para la operaciÃ³n "
							+ StringUtils.collectionToCommaDelimitedString(numeroOperaciones)
							+ " Â¿Desea marcarlo como enviado?");
			return;
		}

		mostrarEditorPdf(confOperacionaux);

		// // Recarga descripcion estado confirmaciÃ³n
		// final DescripcionEstadoConfirmacion dec = confOperacionaux
		// .getDescripcionEstadoConfirmacion();
		// dec.setDescripcion(admconfirmacionesBo.obtenerDescripcionEstado(dec
		// .getCodigo()));

		admconfirmacionesBo.recargar(confOperacionaux);

		seleccionOPMap.clear();
		refrescarLista();
	}

	private List<Long> obtenerNumeroOperaciones(
			List<ConfOperacion> confirmaciones) {

		final List<Long> numeroOperaciones = new ArrayList<Long>(confirmaciones
				.size());

		for (ConfOperacion co : confirmaciones) {
			if (co.getOperacion()==null && co.getEstructura()!=null){
				numeroOperaciones.add(co.getEstructura().getEstructu());
			}else{
				numeroOperaciones.add(co.getOperacion().getId()
						.getNumeroOperacion());	
			}
			
		}

		return numeroOperaciones;
	}

	public void retornoLlamadaMM() {

		ocultarPanelesModales();

		for (ConfOperacion confOperacion : confirmacionesMM) {

			if (!GenericUtils.equals(confOperacion.getCanalConfirmacion(),
					CanalOperacion.MANUAL_MANUAL))
				continue;

			if (confOperacion.getEstructura()==null && admconfirmacionesBo.operacionModificada(confOperacion)) {
				addStatusMessage(
						Severity.WARN,
						"#{messages['admconfirmaciones.enviar.operacionmodificada']}",
						confOperacion.getNumConfirmacion().toString(), confOperacion
						.getVista().getNcorrEstructu());

				continue;
			}

			try {
				admconfirmacionesBo.retornoLlamadaMM(confOperacion,
						confOperacion.getConfirmReclamada());

				admconfirmacionesBo.recargar(confOperacion);
			} catch (Exception e) {
				addStatusMessage(Severity.WARN,
						"#{messages['admconfirmaciones.enviar.errormm']}",
						confOperacion.getNumConfirmacion().toString(), confOperacion
						.getVista().getNcorrEstructu());
			}
		}

		confirmacionesMM.clear();
		seleccionOPMap.clear();
		refrescarLista();
	}

	public void actualizacionBBDD() {

		admconfirmacionesBo.actualizacionBBDD(confOperacionaux,
				confOperacionaux.getConfirmReclamada());
	}

	private void mostrarEditorPdf(ConfOperacion confOperacion) {

		// FLM VIP : REVISION funcionalidad ENVIAR segun reunion con Mario y
		// Francisco dia 13 /05/2010
		// SÃ³lo se envia si se ha pasado antes por el editor. El editor, tanto
		// en consulta como en edicion
		// debe guardar el PDF en documentoconfirmacion
		// Una vez tenemos el PDF en el blob podemos ejecutar directamente el
		// PDF sin la CALLBACK
		// Nota: El tema de la marca de agua sÃ³lo se hace al hacer clic en el
		// boton vista previa, por aqui siempre pasamos por el original

		// FLM: ModificaciÃ³n de arquitectura, Aqui el tema se simplifica mucho y
		// garantiza la separaciÃ³n entre aplicaciones
		// 1. si document=null enviamos al editor de pdf en consulta
		// 2. ejecutamos el retorno del editor directamente

		setEnviar(true);

		final DocumentoConfirmacion documentoConfirmacion = confOperacion
				.getDocumentoConfirmacion();

		if (documentoConfirmacion == null) {

			// No hay DRCONXML

			if (CanalOperacion.MANUAL_MANUAL.equals(confOperacion
					.getCanalConfirmacion())) {

				// Paso 1

				msgBoxAction.mostrarMsg(
						"#{admconfirmacionesAction.actualizacionBBDD}", null, // 
						null, null, // 
						"resultadosConsulta,table,msgboxPanel", "msgboxPanel", //
						"No existen plantillas de confirmaciÃ³n para la operaciÃ³n "
								+ confOperacion.getNumConfirmacion().toString()
								+ " Â¿Desea marcarlo como enviado?");
				return;
			}

			// Paso 2
			admconfirmacionesBo.actualizacionBBDD(confOperacion, confOperacion
					.getConfirmReclamada());

		} else {
			Long claveDMS = null;
			// Caso 1. Existe XML
			
			//SMM 21/10/2015 Miramos si hay que rehacer el XML INI
			//Variables Globales para esta funcion
			Boolean checkFD=false;
			Boolean referCheck=false;
			Boolean envioFDNormal=true;
			Boolean indicadorViaSegura = false;

			indicadorViaSegura = admconfirmacionesBo.obtenerIndViaSegura();
			
			try {
				if (confOperacion.getEvenConf() != null
						&& !"L".equals(confOperacion.getEvenConf())
						&& !"X".equals(confOperacion.getEvenConf())) {

					//Recuperamos CONTRAPA
					String idContrapa = "";
					if(confOperacion.getOperacion()!=null)
						idContrapa = confOperacion.getOperacion().getContrapa();
					else if(confOperacion.getEstructura()!=null){
						idContrapa = confOperacion.getEstructura().getContrapartida().getId();
					}
					Contrapartida contrapa = contrapartidaBo.cargar(idContrapa);
					
					if (GenericUtils.isNullOrBlank(contrapa)){
						
						addFromResourceBundleStatusMessage(Severity.ERROR,
								"admconfirmaciones.error.comprobarFD", confOperacion
										.getNumConfirmacion().toString(),
								confOperacion.getVista().getNcorrEstructu());
						
						enviarFDManual=false;
						
						return;
					}
					
					 // 0 - Error
					 // 1 - Ni checkFD ni referCheck
					 // 2 - CheckFD pero no referCheck
					 // 3 - Sin CheckFD pero si referCheck
					 // 4-  CheckFD y referCheck 
					 // 5 - Ni checkFD ni referCheck ni actualizarContrapa FORZADO
					 // 6 - Sin CheckFD pero si referCheck ni actualizarContrapa FORZADO
					 // 7 - Sin CheckFD pero si referCheck ni actualizar flags CANAL URGENTE  
					 // 8 - Ni checkFD ni referCheck ni actualizar flags CANAL URGENTE
					enviarFDUrgente=false;
					switch (checkFD(confOperacion,contrapa)) {
			            case 0: 
			            	addFromResourceBundleStatusMessage(Severity.ERROR,
								"admconfirmaciones.error.comprobarFD", confOperacion
								.getNumConfirmacion().toString(),
								confOperacion.getVista().getNcorrEstructu());
			            	
			            	enviarFDManual=false;
			            	
			            	return;
						case 1:
							checkFD= false;
							referCheck=false;
							break;
						case 2:
							checkFD= true;
							referCheck=false;
							break;
						case 3:									
							checkFD= false;
							referCheck=true;
							break;
						case 4:
							checkFD= true;
							referCheck=true;
							break;
						case 5:
							checkFD= false;
							referCheck=false;
							envioFDNormal=false;
							break;
						case 6:									
							checkFD= false;
							referCheck=true;
							envioFDNormal=false;
							break;
						case 7:									
							checkFD= false;
							referCheck=true;
							envioFDNormal=false;
							enviarFDUrgente=true;
							break;
						case 8:									
							checkFD= false;
							referCheck=false;
							envioFDNormal=false;
							enviarFDUrgente=true;
							break;							
					}

					//SMM Cuando se canal urgente no marcamos ningÃºn flag de forzado
					if (!enviarFDUrgente){
						//Forzado envio Manual, marcar flag de forzado	
						if(!envioFDNormal && !confOperacion.getIndFirmaManualForzada() ){
							confOperacion.setIndFirmaManualForzada(true);
						}else if (envioFDNormal && confOperacion.getIndFirmaManualForzada() ){
							confOperacion.setIndFirmaManualForzada(false);
						}
					}
					
					if (referCheck){
						//Llamar REFER
						try {
							
							if (checkFD){
								confOperacion.setIndicadorFirmaDigital("S");	
							}else{
								confOperacion.setIndicadorFirmaDigital("N");
							}
							
							if (envioFDNormal && (GenericUtils.isNullOrBlank(contrapa.getIndBsOnl()) 
									|| "N".equalsIgnoreCase(contrapa.getIndBsOnl())) && checkFD){
								contrapa.setIndBsOnl("S");
							}
							if (envioFDNormal &&  (!GenericUtils.isNullOrBlank(contrapa.getIndBsOnl()) 
									&& "S".equalsIgnoreCase(contrapa.getIndBsOnl())) && !checkFD){
								contrapa.setIndBsOnl("N");
							}
							
							if (!GenericUtils.isNullOrBlank(confOperacion.getIdDocDMS())){
								
								try {
									borrarDocumentoDMS(confOperacion);
								} catch (Exception e) {
									//Solo control de seguridad
									//No es obligatorio su borrado
									e.printStackTrace();
								}
								confOperacion.setIdDocDMS(null);
							}
							admconfirmacionesBo.flush();
															
							
							admconfirmacionesBo.rehacerXML(confOperacion);
							admconfirmacionesBo.recargar(confOperacion);
						
							
						} catch (Exception e) {
							if (e instanceof SQLException){
								addFromResourceBundleStatusMessage(e,
										"admconfirmaciones.error.rehacerXML", e.getMessage());		
								
								//Como estamos en refer se tiene que dejar al reves para volver a procesar.
								if (checkFD){
									confOperacion.setIndicadorFirmaDigital("N");	
								}else{
									confOperacion.setIndicadorFirmaDigital("S");
								}
								admconfirmacionesBo.flush();
								enviarFDManual=false;
								
								return;
							}							
						}
						//SE HA REGENERADO EL XML
						System.out.println("XML Regenearado:="+confOperacion.getNumConfirmacion().toString());
						addFromResourceBundleStatusMessage(Severity.INFO,
							"admconfirmaciones.warn.referpdf", confOperacion
									.getNumConfirmacion().toString(),
							confOperacion.getVista().getNcorrEstructu());
				}else{

				
					if (envioFDNormal && (GenericUtils.isNullOrBlank(contrapa.getIndBsOnl()) 
							|| "N".equalsIgnoreCase(contrapa.getIndBsOnl())) && checkFD){
						contrapa.setIndBsOnl("S");
					}
					if (envioFDNormal && (!GenericUtils.isNullOrBlank(contrapa.getIndBsOnl()) 
							&& "S".equalsIgnoreCase(contrapa.getIndBsOnl())) && !checkFD){
						contrapa.setIndBsOnl("N");
					}
					
					if (envioFDNormal){
						admconfirmacionesBo.flush();	
					}
				}
					
					
				}
				
			} catch (Exception e) {
					log.debug(e.toString());
					e.printStackTrace();
					addFromResourceBundleStatusMessage(e,
							"admconfirmaciones.error.pdf", confOperacion
									.getNumConfirmacion().toString(),
							confOperacion.getVista().getNcorrEstructu());
					
					enviarFDManual=false;
					
					return;
				}	
			
			//SMM 21/10/2015 Miramos si hay que rehacer el XML FIN			
			
			
			
			
			
			

			if (GenericUtils.isNullOrEmpty(documentoConfirmacion.getDocument()) || referCheck) {

				// No hay PDF generado
				// Paso 1.
				//
				// GeneraciÃ³n del PDF a partir del XML
				//
				// HPQC 1715
				if (isVistaPreviaOracleReports(confOperacion)) {

					addStatusMessage(Severity.ERROR,
							"El PDF no se puede generar "
									+ "mediante el sistema nuevo");

					enviarFDManual=false;
					return;
				}

				if (facesContext == null)
					throw new IllegalStateException("facesContext == null");

				final HttpSession session = (HttpSession) facesContext
						.getExternalContext().getSession(false);
				final URIResolver uriResolver = new JarServletContextURIResolver(
						session.getServletContext());

				try {

					final ExtendedPDF extendedPDF = ExtendedPDFFactory
							.generate(entityManager, confOperacion
									.getNumConfirmacion(), this, null,
									uriResolver, configuracionDeri
											.getPdfSubstitutionFont());

					// if (confOperacion.getEvenConf()!=null &&
					// !"L".equals(confOperacion.getEvenConf()) &&
					// !"X".equals(confOperacion.getEvenConf())){
					// claveDMS =
					// generarDocumentoDMS(confOperacion,extendedPDF.getPdfByteArray());
					// actualizarDMS(confOperacion,claveDMS);
					// }
					// System.out.println("TERMINA GRABAR DMS GRABA DB");
					// System.out.println(Calendar.getInstance().getTime().toString());
					final boolean insertPDF = new DBAccess(null, entityManager)
							.savePDF(extendedPDF.getPdfByteArray(),
									confOperacion.getNumConfirmacion());
					// System.out.println("TERMINA GRABA DB");
					// System.out.println(Calendar.getInstance().getTime().toString());
					if (!insertPDF)
						throw new IllegalStateException("!insertPDF");

					// Paso 2.
					addStatusMessage(Severity.INFO,
							"La confirmaciÃ³n se ha consultado por primera vez. "
									+ "Para procesarla ha de volver a hacer "
									+ "Enviar Conf.");

					admConfirmacionesPantalla.setWatermark(MarcaDeAgua.ORIGINAL
							.toString());

					// System.out.println("VERPDF");
					// System.out.println(Calendar.getInstance().getTime().toString());

					verPDF();
					// System.out.println("TERMINA VERPDF");
					// System.out.println(Calendar.getInstance().getTime().toString());
				} catch (Exception e) {
					log.debug(e.toString());
					e.printStackTrace();
					addFromResourceBundleStatusMessage(e,
							"admconfirmaciones.error.pdf", confOperacion
									.getNumConfirmacion().toString(),
							confOperacion.getVista().getNcorrEstructu());
				}
				
				enviarFDManual=false;
				
				return;
			} else {

				// Existe PDF 

				admConfirmacionesPantalla.setWatermark(MarcaDeAgua.ORIGINAL
						.toString());

				// Paso 1.
				// System.out.println("VERPDF YA EXISTE");
				// System.out.println(Calendar.getInstance().getTime().toString());

				verPDF();

				// System.out.println("TERMINA VERPDF YA EXISTE");
				// System.out.println(Calendar.getInstance().getTime().toString());
				try {
					if (confOperacion.getEvenConf() != null
							&& !"L".equals(confOperacion.getEvenConf())
							&& !"X".equals(confOperacion.getEvenConf())) {
/*
//						Indicador ConfirmaciÃ³n con firma digital  â€˜Sâ€™ / â€˜Nâ€™
						Boolean checkFD=false;
//						Indicador de si se ha modificado el flag de firma digital  â€˜Sâ€™/â€™Nâ€™
						Boolean referCheck=false;
						Boolean envioFDNormal=true;
						
						String idContrapa = "";
						if(confOperacion.getOperacion()!=null)
							idContrapa = confOperacion.getOperacion().getContrapa();
						else if(confOperacion.getEstructura()!=null){
							idContrapa = confOperacion.getEstructura().getContrapartida().getId();
						}
						Contrapartida contrapa = contrapartidaBo.cargar(idContrapa);
						
						if (GenericUtils.isNullOrBlank(contrapa)){
							
							addFromResourceBundleStatusMessage(Severity.ERROR,
									"admconfirmaciones.error.comprobarFD", confOperacion
											.getNumConfirmacion().toString(),
									confOperacion.getVista().getNcorrEstructu());
							
							return;
						}
						
						 // 0 - Error
						 // 1 - Ni checkFD ni referCheck
						 // 2 - CheckFD pero no referCheck
						 // 3 - Sin CheckFD pero si referCheck
						 // 4-  CheckFD y referCheck 
						 // 5 - Ni checkFD ni referCheck ni actualizarContrapa FORZADO
						 // 6 - Sin CheckFD pero si referCheck ni actualizarContrapa FORZADO
 
						switch (checkFD(confOperacion,contrapa)) {
				            case 0: 
				            	addFromResourceBundleStatusMessage(Severity.ERROR,
									"admconfirmaciones.error.comprobarFD", confOperacion
									.getNumConfirmacion().toString(),
									confOperacion.getVista().getNcorrEstructu());
					
				            	return;
							case 1:
								checkFD= false;
								referCheck=false;
								break;
							case 2:
								checkFD= true;
								referCheck=false;
								break;
							case 3:									
								checkFD= false;
								referCheck=true;
								break;
							case 4:
								checkFD= true;
								referCheck=true;
								break;
							case 5:
								checkFD= false;
								referCheck=false;
								envioFDNormal=false;
								break;
							case 6:									
								checkFD= false;
								referCheck=true;
								envioFDNormal=false;
								break;
								
						}

						//Forzado envio Manual, marcar flag de forzado	
						if(!envioFDNormal && !confOperacion.getIndFirmaManualForzada() ){
							confOperacion.setIndFirmaManualForzada(true);
						}else if (envioFDNormal && confOperacion.getIndFirmaManualForzada() ){
							confOperacion.setIndFirmaManualForzada(false);
						}

						
						if (referCheck){
							//Llamar REFER
							try {
								
								if (checkFD){
									confOperacion.setIndicadorFirmaDigital("S");	
								}else{
									confOperacion.setIndicadorFirmaDigital("N");
								}
								
								//TODO SMM OJO!
								//CONTRAPA SOLO SE ACTUALIZA SI HAY QUE REHACER LA CONFIRMACION
								//SINO MOVER FUERA DEL REFERCHECK Y QUE SE ACTUALICE SIEMPRE QUE ESTE MAL

								if (envioFDNormal && (GenericUtils.isNullOrBlank(contrapa.getIndBsOnl()) 
										|| "N".equalsIgnoreCase(contrapa.getIndBsOnl())) && checkFD){
									contrapa.setIndBsOnl("S");
								}
								if (envioFDNormal &&  (!GenericUtils.isNullOrBlank(contrapa.getIndBsOnl()) 
										&& "S".equalsIgnoreCase(contrapa.getIndBsOnl())) && !checkFD){
									contrapa.setIndBsOnl("N");
								}
								
								admconfirmacionesBo.flush();
																
								
								admconfirmacionesBo.rehacerXML(confOperacion);
								admconfirmacionesBo.recargar(confOperacion);
							
								
							} catch (Exception e) {
								if (e instanceof SQLException){
									addFromResourceBundleStatusMessage(e,
											"admconfirmaciones.error.rehacerXML", e.getMessage());		
									
									//Como estamos en refer se tiene que dejar al reves para volver a procesar.
									if (checkFD){
										confOperacion.setIndicadorFirmaDigital("N");	
									}else{
										confOperacion.setIndicadorFirmaDigital("S");
									}
									admconfirmacionesBo.flush();
									return;
								}							
							}
							
							addFromResourceBundleStatusMessage(Severity.INFO,
									"admconfirmaciones.warn.referpdf", confOperacion
											.getNumConfirmacion().toString(),
									confOperacion.getVista().getNcorrEstructu());
							
							return;
							
						}else{

							if (envioFDNormal && (GenericUtils.isNullOrBlank(contrapa.getIndBsOnl()) 
									|| "N".equalsIgnoreCase(contrapa.getIndBsOnl())) && checkFD){
								contrapa.setIndBsOnl("S");
							}
							if (envioFDNormal && (!GenericUtils.isNullOrBlank(contrapa.getIndBsOnl()) 
									&& "S".equalsIgnoreCase(contrapa.getIndBsOnl())) && !checkFD){
								contrapa.setIndBsOnl("N");
							}
							
							if (envioFDNormal){
								admconfirmacionesBo.flush();	
							}
							
															
							
						}
						
*/
						
						
						BaseDBAccess access = new BaseDBAccess("read-only",
								entityManager);
						// documentoConfirmacion.getDocument()
						
						
						
						claveDMS = generarDocumentoDMS(confOperacion, access.getPDF(documentoConfirmacion.getCodconfi()));
						if (!GenericUtils.isNullOrBlank(claveDMS)) {
							log.debug("Clave DMS - Documento Generado sin error");
							log.debug(claveDMS);
							actualizarDMS(confOperacion, claveDMS);


							try {

							//NO ADMITIMOS CONTRAPARTIDAS BANCARIAS
							if ( (confOperacion.getOperacionID()!=null && 
									admconfirmacionesBo.esCliente(confOperacion.getOperacion().getContrapa()))
							|| (GenericUtils.isNullOrBlank(confOperacion.getOperacionID()) && 
									admconfirmacionesBo.esCliente(confOperacion.getEstructura().getContrapartida().getId()))
							){

								
							// Enviar la confirmaciÃ³n a OSP (Webservice OSP)
							if(sessionId==null || sessionId.equals("")){
								enviarConfirmacionOsp.setUsername(credentials.getUsername());
								if (proxyGrantingTicket == null) proxyGrantingTicket = getTicket();
								System.out.println("proxyGrantingTicket=-"+proxyGrantingTicket+"-");
								String passTicket = enviarConfirmacionOsp.getPassTicket(proxyGrantingTicket);
								System.out.println("passTicket=-"+passTicket+"-");
								enviarConfirmacionOsp.setPassword(passTicket);
								String sessionValida=enviarConfirmacionOsp.login(confOperacion.getIdioma().obteCodigoI18n(), "");
								if(sessionValida.equals("-1")||	sessionValida.equals("-2")){
									admconfirmacionesBo.saveResultadoToLog(ConstantesFD.LOG_COD_ERROR_SIN_ACCESO_WS, ConstantesFD.LOG_DESC_ERROR_SIN_SESION, confOperacion,ConstantesFD.LOG_IDWEBSEV_OSP,ConstantesFD.LOG_WEBSERV_OSP_KO);
									//Si hay FD y falla no se confirma la confirmacion
									if (checkFD){
										addFromResourceBundleStatusMessage(Severity.ERROR,
												"admconfirmaciones.firmadigital.sesion.invalida", confOperacion
														.getNumConfirmacion().toString());

										return;
									}
									
								}else{
									sessionId = sessionValida;
								}
							}
//							ModificaRequest modificaRequest = admconfirmacionesBo.creaModificaRequestParaOsp(confOperacion, claveDMS,ConstantesFD.OPCION_OSP,checkFD);
							ModificaRequest modificaRequest = admconfirmacionesBo.creaModificaRequestParaOsp(confOperacion, claveDMS,ConstantesFD.OPCION_OSP,checkFD,indicadorViaSegura);
							modificaRequest.getModificaInputData().setUsuario(credentials.getUsername());
							modificaRequest.getHeaderRequest().getHostRequest().setSessionId(sessionId);
 
							
							String llamadaOSP = generarStringLlamadaOSP(modificaRequest);
							
							ModificaResponse modificaResponse = enviarConfirmacionOsp.modifica(modificaRequest);
							if(null==modificaResponse || null==modificaResponse.getModificaOutputData()||null==modificaResponse.getModificaOutputData().getCodigoRetorno()){
								//actualizamos la tabla WsLogOsp
								admconfirmacionesBo.saveResultadoToLog(ConstantesFD.LOG_COD_ERROR_SIN_ACCESO_WS, ConstantesFD.LOG_DESC_ERROR_SIN_ACCESO_WS_OSP, confOperacion,ConstantesFD.LOG_IDWEBSEV_OSP,ConstantesFD.LOG_WEBSERV_OSP_KO,llamadaOSP);
								//return "admconfirmaciones.enviarOSP.error.llamada.ws";

								if (indicadorViaSegura && !checkFD){
									actualizarIndiloga(confOperacion, ConstantesFD.INDILOGA_BATCH);
								}			
								
								if (checkFD){
									addFromResourceBundleStatusMessage(Severity.ERROR,
											"admconfirmaciones.enviarOSP.error.llamada.ws", confOperacion
													.getNumConfirmacion().toString());

									return;
								}
								//Si ha ido bien --> ACTUALIZAR INDICOSP A 'E'
//								actualizarIndicosp(confOperacion, ConstantesFD.INDICOSP_E);
							}else{
								//Si se ha producido un error al registrar la confirmaciÃ³n enviamos un evento a la agenda
								//TODO TRATAR ERRORES
								String codError = modificaResponse.getModificaOutputData().getCodigoError().toString();
								String codRetorno = modificaResponse.getModificaOutputData().getCodigoRetorno();
								
								System.out.println("codError=-"+codError+"-");
								System.out.println("codRetorno=-"+codRetorno+"-");
								
								if(Integer.valueOf(codError)==0){
									//ok
									admconfirmacionesBo.saveResultadoToLog(codError, codRetorno, confOperacion, ConstantesFD.LOG_IDWEBSEV_OSP,ConstantesFD.LOG_WEBSERV_OSP_OK,llamadaOSP);
									if (GenericUtils.isNullOrBlank(confOperacion.getIndicadorOSP())){
										actualizarIndicosp(confOperacion, ConstantesFD.INDICOSP_E);	  
									}
								}else{
									//no ok
									System.out.println("Error con codigo-");
									admconfirmacionesBo.saveResultadoToLog(codError, codRetorno, confOperacion, ConstantesFD.LOG_IDWEBSEV_OSP,ConstantesFD.LOG_WEBSERV_OSP_KO,llamadaOSP );
									
									if (indicadorViaSegura && !checkFD){
										actualizarIndiloga(confOperacion, ConstantesFD.INDILOGA_BATCH);
									}	
									
									if (checkFD){
										addFromResourceBundleStatusMessage(Severity.ERROR,
												"admconfirmaciones.enviarOSP.error.llamada.ws", confOperacion
														.getNumConfirmacion().toString());

										return;
									}
								}
							}
							//Actualizamos la sesiÃ³n si fuera necesario
							if(null!=enviarConfirmacionOsp.getSessionId()&&!enviarConfirmacionOsp.getSessionId().equals(sessionId))
								sessionId = enviarConfirmacionOsp.getSessionId();

							
							}							//NO ADMITIMOS CONTRAPARTIDAS BANCARIAS
							
							} catch (Exception e) {
							// CATCH para errores sin controlar de ENVIO OSP.
							// La idea es que la confirmaciÃ³n se confirme igual.	
								enviarFDManual=false;
								String errorLog = e.toString();
								log.debug(e.toString());
								e.printStackTrace();
								
								if (indicadorViaSegura && !checkFD){
									actualizarIndiloga(confOperacion, ConstantesFD.INDILOGA_BATCH);
								}	
								if (errorLog.length()>=200) {errorLog=errorLog.substring(0, 199);};
								
								admconfirmacionesBo.saveResultadoToLog(ConstantesFD.LOG_COD_ERROR_SIN_ACCESO_WS, errorLog, confOperacion, ConstantesFD.LOG_IDWEBSEV_OSP,ConstantesFD.LOG_WEBSERV_OSP_KO);							
							
								//Si Falla el envio OSP
								if (checkFD){
									addFromResourceBundleStatusMessage(Severity.ERROR,
											"admconfirmaciones.enviarOSP.error.llamada.ws", confOperacion
													.getNumConfirmacion().toString());

									return;
								}
							}	


							try {
								//SMM Se llamara siempre Ini 19/01/2016
								envioFD(confOperacion,checkFD,indicadorViaSegura);

								//SMM Se llamara siempre Fi 19/01/2016
							} catch (Exception e) {
								
								//QUE una exception en FD no haga que no se envie la confirmacion
								enviarFDManual=false;
								String errorLog = e.toString();
								log.debug(e.toString());
								e.printStackTrace();
								
								admconfirmacionesBo.saveResultadoToLog(ConstantesFD.LOG_COD_ERROR_SIN_ACCESO_WS, errorLog, confOperacion, ConstantesFD.LOG_IDWEBSEV_REGISTRAR,ConstantesFD.LOG_WEBSERV_OSP_KO);							
								//SMM Solo error si es FD Ini 19/01/2016
								if (checkFD){
								//SMM Solo error si es FD Fi 19/01/2016									

								borrarOSP(confOperacion);
								addFromResourceBundleStatusMessage(Severity.ERROR,
										"admconfirmaciones.firmadigital.error.llamada.ws", confOperacion
												.getNumConfirmacion().toString());

								return;
								//SMM Solo error si es FD Ini 19/01/2016
								}
								//SMM Solo error si es FD Fi 19/01/2016									

							}

							
							
							
//							}ESTRUCTURAS NO
						}else{
						//No se ha obtenido Clave DMS
							addFromResourceBundleStatusMessage(Severity.ERROR,
									"admconfirmaciones.error.clavedms", confOperacion
											.getNumConfirmacion().toString());
							enviarFDManual=false;
							return;
						}
					}

				} catch (Exception e) {
					log.debug(e.toString());
					e.printStackTrace();
					addFromResourceBundleStatusMessage(e,
							"admconfirmaciones.error.pdf", confOperacion
									.getNumConfirmacion().toString(),
							confOperacion.getVista().getNcorrEstructu());
					
					enviarFDManual=false;
					
					return;
				}
				// Paso 2.
				admconfirmacionesBo.actualizacionBBDD(confOperacion,
						confOperacion.getConfirmReclamada());

				//SMM 21/10/2015 volvemos a dejar el flag por defecto.
				enviarFDManual=false;

			}
		}

		// Si ya hemos pasado por el editor ejecutamos las acciones
		// Ojo, esto se hacia antes en la callback, ahora la callback es
		// ejecuciÃ³n directa
		retornoLlamadaEditor();
	}


	private void envioFD(ConfOperacion confOperacion, Boolean checkFD, Boolean indicadorViaSegura) throws Exception {

		if (confOperacion.getIndicadorOSP()!=null 
				&& ConstantesFD.INDICOSP_ONLINE.equalsIgnoreCase(confOperacion.getIndicadorOSP())
				&& (indicadorViaSegura || checkFD)
		) {
			// FIRMA DIGITAL
			String resFirma = firmaCentralizada(confOperacion,indicadorViaSegura,checkFD);
			String indiloga = null;
			// Si el proceso ha ido bien grabamos 'E' en el
			// campo INDILOGA
			if (resFirma.equals("")) {
				indiloga = ConstantesFD.INDILOGA_ONLINE;
				actualizarIndiloga(confOperacion, indiloga);
//										statusMessages
//												.add(Severity.INFO,
//														"#{messages['admconfirmaciones.firmadigital.firma.ok']}");
			} else if (resFirma.equals("INDBSONL")) {
				// Si no se ejecuta la llamada al WS porque el indBsOnl no estÃ¡ a S no hacemos nada
			} else {
				// Se mostrarÃ¡ el motivo del error por pantalla y se dejarÃ¡ la confirmaciÃ³n tambiÃ©n como
				// procesada pero dejando a null la columna INDICOSP para que entre en el circuito normal
				// (firma en papel y digitalizaciÃ³n).
				
				if (indicadorViaSegura && !checkFD){
					actualizarIndiloga(confOperacion, ConstantesFD.INDILOGA_BATCH);
				}else{
					actualizarIndiloga(confOperacion, null);	
				}
				

				log.debug("resFirma: " + "#{messages["
						+ resFirma + "]}");
				
				throw new Exception(resFirma);
//										statusMessages
//												.add(Severity.ERROR,
//														"#{messages['admconfirmaciones.firmadigital.error.llamada.ws']}");
				
//				admconfirmacionesBo.saveResultadoToLog(ConstantesFD.LOG_COD_ERROR_SIN_ACCESO_WS, resFirma, confOperacion, ConstantesFD.LOG_IDWEBSEV_REGISTRAR,ConstantesFD.LOG_WEBSERV_OSP_KO);
				/*
				 * //Se muestra el mensaje de error si es funcional if (resFirma.indexOf(ConstantesFD.ERROR_FUNCIONAL)!=-1)
				 * statusMessages.add(Severity.ERROR ,resFirma.substring(resFirma.indexOf(ConstantesFD.ERROR_FUNCIONAL
				 * )+ConstantesFD.TAM_PREFIJO_ERR_FUN));
				 * else//si no error genÃ©rico
				 * statusMessages.add(Severity.ERROR,"#{messages['"+resFirma+"']}");
				 */
			}
		}// FIN if(activarFirmaDigital)
		
		
	}

	private void actualizarDMS(ConfOperacion confiOpe, Long claveDMS) {
		
		admconfirmacionesBo.actualizarConf(confiOpe, claveDMS);
		
	}

	private void actualizarIndicosp(ConfOperacion confiOpe, String indicosp) {
		admconfirmacionesBo.actualizarIndicosp(confiOpe, indicosp);
	}

	private void actualizarIndiloga(ConfOperacion confiOpe, String indiloga) {
		admconfirmacionesBo.actualizarIndiloga(confiOpe, indiloga);
	}
	
	public void buildOracleReportPre(){
		msgBoxAction.setMostrarMensaje(false);
		setMostrarReport(true);
		final ConfOperacion cOperacion = admConfirmacionesPantalla
		.getAdmconfirmacionSelec();

		buildOracleReport(cOperacion);
	}
	
/*	*//**
	 * Devuelve los cÃ³digos de documento y expediente
	 * codigos[0] = codDocumento;
	 * codigos[1] = codExpediente;
	 * @param co
	 * @return
	 *//*
	private String[] calcularCodDocumentoCodExpediente(ConfOperacion co){
		String[] codigos = new String[2];
		StringBuffer sb = new StringBuffer();
		// GENERAR CODI DOCUMENTO
		if (co.getOperacionID() != null) {

			sb.append(
					GenericUtils.lpad(co.getOperacionID().toString(), 12, "0"))
					.append("|").append(co.getEvenConf().substring(0, 1))
					// .append("A")
					.append("|").append(
							GenericUtils.lpad(co.getNumConfirmacion()
									.toString(), 12, "0"));

		} else {
			// Sera un Producto Compuesto
			sb.append(
					GenericUtils.lpad(co.getIdEstructConfirmada().toString(),
							12, "0")).append("|").append(
					co.getEvenConf().substring(0, 1))
					.append("|").append(
							GenericUtils.lpad(co.getNumConfirmacion()
									.toString(), 12, "0"));

		}

		String codDocumento = sb.toString();
		codigos[0] = codDocumento;

		// GENERAR CODIGO EXPEDIENTE
		String contrato = "";
		if (co.getOperacionID() != null) {

			if (admconfirmacionesBo.esCliente(co.getOperacion().getContrapa())) {
				contrato = admconfirmacionesBo.obtenerContrato(co
						.getOperacion().getContrapa(), co.getOperacion()
						.getEntidad().toString());
				contrato = contrato.substring(0, contrato.indexOf("-"));
				// Se eliminan los dos digitos de control.
				// .concat(contrato.substring(contrato.lastIndexOf("-")+1,
				// contrato.length()));
			} else {
				contrato = co.getOperacionID().toString();
			}

		} else {

			if (admconfirmacionesBo.esCliente(co.getEstructura()
					.getContrapartida().getId())) {
				contrato = admconfirmacionesBo.obtenerContrato(co
						.getEstructura().getContrapartida().getId(),
						admconfirmacionesBo
								.recuperarEntidad(co.getEstructura()));
				contrato = contrato.substring(0, contrato.indexOf("-"));
				// Se eliminan los dos digitos de control.
				// .concat(contrato.substring(contrato.lastIndexOf("-")+1,
				// contrato.length()));
			} else {
				contrato = co.getIdEstructConfirmada().toString();
			}
		}

		sb = new StringBuffer();

		String entidadCod;
		if (co.getOperacionID() != null) {
			entidadCod = convertirEntidad(co.getOperacion().getEntidad()
					.toString());
		} else {
			entidadCod = convertirEntidad(admconfirmacionesBo
					.recuperarEntidad(co.getEstructura()));
		}

		sb.append(entidadCod).append("|").append("DD ").append("|").append(
				GenericUtils.lpad(contrato, 15, "0"));
		String codExpediente = sb.toString();

		codigos[1] = codExpediente;

		return codigos;
	}
*/	
	private void buildOracleReport(ConfOperacion cOperacion) {


		final Idioma idioma = cOperacion.getIdioma();
		final String codigoIdioma;

		if (idioma == null) {
			codigoIdioma = Constantes.IDIOMA_CASTELLANO;

		} else if (GenericUtils.in(idioma.getCodigo(),
				Constantes.IDIOMA_CASTELLANO, Constantes.IDIOMA_INGLES)) {

			codigoIdioma = idioma.getCodigo();
		} else {
			codigoIdioma = Constantes.IDIOMA_CASTELLANO;
		}

		log.debug("idioma::" + idioma + " codigoIdioma::" + codigoIdioma);

		final InformeEnum informe;

		if (cOperacion.getIdEstructConfirmada() == null) {

			// Operaciones

			final HistoricoOperacion histo = admconfirmacionesBo
					.obtenerHistoricoOperacion(
							cOperacion.getOperacionID(),
							cOperacion.getFechaContratacion());

			if (GenericUtils.in(cOperacion.getEventoConfirmacion().getCodigo(),
					EventoConfirmacion.ALTA, EventoConfirmacion.RECTIFICACION)) {

				if (histo == null) {
					
					addStatusMessage(Severity.ERROR,
					"No existe modelo de producto para la confirmaciÃ³n");

	return;
				}
				
				final String modeloProd = admconfirmacionesBo
						.obtenerModeloProducto(histo.getProducto().getId());

				if (GenericUtils.isNullOrBlank(modeloProd)) {

					addStatusMessage(Severity.ERROR,
									"No existe modelo de producto para la confirmaciÃ³n");

					return;
				}

				if (GenericUtils.equals(modeloProd, "SWP")
						&& GenericUtils.equals(Constantes.IDIOMA_CASTELLANO,
								codigoIdioma)) {

					informe = InformeEnum.DERIMA1;

				} else if (GenericUtils.equals(modeloProd, "SWP")
						&& GenericUtils.equals(Constantes.IDIOMA_INGLES,
								codigoIdioma)) {

					informe = InformeEnum.DERIMA2;

				} else if (GenericUtils.equals(modeloProd, "CFC")
						&& GenericUtils.equals(Constantes.IDIOMA_CASTELLANO,
								codigoIdioma)) {

					informe = InformeEnum.DERIMA10;

				} else if (GenericUtils.equals(modeloProd, "CFC")
						&& GenericUtils.equals(Constantes.IDIOMA_INGLES,
								codigoIdioma)) {

					informe = InformeEnum.DERIMA20;

				} else if (GenericUtils.equals(modeloProd, "OPC")
						&& GenericUtils.equals(Constantes.IDIOMA_CASTELLANO,
								codigoIdioma)) {

					informe = InformeEnum.DERIMA3;

				} else {

					addStatusMessage(Severity.ERROR,
							"No existe listado de confirmaciÃ³n "
									+ "para la operaciÃ³n "
									+ cOperacion.getOperacionID());

					return;
				}
			} else if (GenericUtils.in(cOperacion.getEventoConfirmacion()
					.getCodigo(), EventoConfirmacion.FIJACION,
					EventoConfirmacion.LIQUIDACION)) {

				String modeloProd = admconfirmacionesBo
						.obtenerModeloProducto(histo
								.getProducto().getId());

				if (GenericUtils.isNullOrBlank(modeloProd)) {

					addStatusMessage(Severity.ERROR,
									"No existe modelo de producto para la confirmaciÃ³n");

					return;
				}

				if (GenericUtils.equals(modeloProd, "EQU"))
					modeloProd = "SWP";

				if (GenericUtils.equals(modeloProd, "SWP")
						&& GenericUtils.equals(Constantes.IDIOMA_CASTELLANO,
								codigoIdioma)) {

					informe = InformeEnum.DERIMB1;

				} else if (GenericUtils.equals(modeloProd, "SWP")
						&& GenericUtils.equals(Constantes.IDIOMA_INGLES,
								codigoIdioma)) {

					informe = InformeEnum.DERIMB2;

				} else if (GenericUtils.equals(modeloProd, "CFC")
						&& GenericUtils.equals(Constantes.IDIOMA_CASTELLANO,
								codigoIdioma)) {

					informe = InformeEnum.DERIMB10;

				} else if (GenericUtils.equals(modeloProd, "CFC")
						&& GenericUtils.equals(Constantes.IDIOMA_INGLES,
								codigoIdioma)) {

					informe = InformeEnum.DERIMB20;

				} else if (GenericUtils.equals(modeloProd, "FWD")
						&& GenericUtils.equals(Constantes.IDIOMA_CASTELLANO,
								codigoIdioma)) {

					informe = InformeEnum.DERIMFW2;

				} else {

					addStatusMessage(Severity.ERROR,
							"No existe listado de confirmaciÃ³n "
									+ "para la operaciÃ³n "
									+ cOperacion.getOperacionID());

					return;
				}
			} else if (GenericUtils.in(cOperacion.getEventoConfirmacion()
					.getCodigo(), EventoConfirmacion.CANCELACION)) {

				if (GenericUtils.equals(Constantes.IDIOMA_CASTELLANO,
						codigoIdioma)) {

					informe = InformeEnum.DERIMC1;

				} else {

					informe = InformeEnum.DERIMC2;
				}
			} else if (GenericUtils.in(cOperacion.getEventoConfirmacion()
					.getCodigo(), EventoConfirmacion.CANCEL_PARCIAL)) {

				if (GenericUtils.equals(Constantes.IDIOMA_CASTELLANO,
						codigoIdioma)) {

					informe = InformeEnum.DERIMC10;

				} else {

					addStatusMessage(Severity.ERROR,
							"No existe listado de confirmaciÃ³n "
									+ "para la operaciÃ³n "
									+ cOperacion.getOperacionID());

					return;
				}
			} else {

				addStatusMessage(Severity.ERROR,
						"No existe listado de confirmaciÃ³n "
								+ "para la operaciÃ³n "
								+ cOperacion.getOperacionID());

				return;
			}
		} else {

			// Estructuras

			if (GenericUtils.in(cOperacion.getEventoConfirmacion().getCodigo(),
					EventoConfirmacion.ALTA, EventoConfirmacion.RECTIFICACION)) {

				// String modeloProd = "COLLAR";

				if (GenericUtils.equals(Constantes.IDIOMA_CASTELLANO,
						codigoIdioma)) {

					informe = InformeEnum.DERIMA6;
				} else {

					addStatusMessage(Severity.ERROR,
							"No existe listado de confirmaciÃ³n "
									+ "para la operaciÃ³n "
									+ cOperacion.getOperacionID());

					return;
				}
			} else if (GenericUtils.in(cOperacion.getEventoConfirmacion()
					.getCodigo(), EventoConfirmacion.FIJACION,
					EventoConfirmacion.LIQUIDACION)) {

				if (GenericUtils.equals(Constantes.IDIOMA_CASTELLANO,
						codigoIdioma)) {

					informe = InformeEnum.DERIMB6;
				} else {

					addStatusMessage(Severity.ERROR,
							"No existe listado de confirmaciÃ³n "
									+ "para la operaciÃ³n "
									+ cOperacion.getOperacionID());

					return;
				}
			} else {

				addStatusMessage(Severity.ERROR,
						"No existe listado de confirmaciÃ³n "
								+ "para la operaciÃ³n "
								+ cOperacion.getOperacionID());

				return;
			}
		}

		acOracleReport = new AdmConfirmacionOracleReport(msgBoxAction,
				statusMessages, informe, cOperacion, false, TipoFichero.REPORT,
				admconfirmacionesBo, circularizacionBo, pantallaBo,
				configuracionDeri);

		try {
			acOracleReport.runReport_Fase1();

			// En el caso que NO haya un mensaje a mostrar se visualizarÃ¡ el
			// Report

			setMostrarReport(!msgBoxAction.isMostrarMensaje());

		} catch (IllegalStateException e) {

			addStatusMessage(Severity.ERROR,
					"Se ha producido un error generando el Report.");
		}
	}

	/**
	 * Callback de las ventanas modales de Oracle Report (en el caso que se
	 * necesite).
	 * 
	 * @param bSi
	 */
	public void oracleReport_runReport_Fase2(boolean bSi) {
		try {
			acOracleReport.runReport_Fase2(bSi);

			setMostrarReport(true);

		} catch (IllegalStateException e) {

			addStatusMessage(Severity.ERROR,
					"Se ha producido un error generando el Report.");
		}
	}

	/**
	 * Actualiza los datos de confiope (indconre y ) y gestiona los datos de
	 * fax.
	 * @throws IOException 
	 */
	public void retornoLlamadaEditor() {
		// El editor SIEMPRE VUELVE AQUI
		//

		// Si entramos por ver el PDF no hacemos nada !!
		if (!isEnviar())
			return;

		// activar link desde action
		this.setEnviar(false);

		if (GenericUtils.in(confOperacionaux.getCanalConfirmacion(),
				CanalOperacion.ON_LINE_FAX, CanalOperacion.BATCH_FAX, CanalOperacion.ON_LINE_EMAIL, CanalOperacion.BATCH_EMAIL)) {

			obtenerDatosFax(confOperacionaux);
		}
	}

	// variables globales obtener datos fax
	String fax = null;
	String oficina = null;
	String contacto = null;
	Integer numcontr = null;

	Contrapartida obtenerContrapaBase(Object contrapartida) {
		AbstractContrapartida aContrapa = entityUtil.unwrapProxy(contrapartida,
				AbstractContrapartida.class);
		Contrapartida contrapa = null;
		if (!(aContrapa instanceof Contrapartida)) {
			// statusMessages.add(Severity.ERROR ,
			// "Esta contrapartida no tiene tipo contrapartida asociado");
			return null;
		}
		contrapa = (Contrapartida) aContrapa;
		return contrapa;
	}

	public void obtenerDatosFax(ConfOperacion confOperacion) {

		if (confOperacion.getOperacion() == null)
			return;

		final Contrapartida contrapartida = obtenerContrapaBase(confOperacion
				.getOperacion().getContrapartida());

		if (contrapartida == null)
			return;

		fax = contrapartida.getFax();
		contacto = contrapartida.getPersonaContacto();

		if (contrapartida.getTipoContrapartida() != null
				&& ("O").equals(contrapartida.getTipoContrapartida().getId())) {

			oficina = "S";
		} else {
			oficina = "N";
		}

		try {
			if (fax != null && !("O").equals(fax)
					&& admconfirmacionesBo.faxCorrecto(confOperacion)
					&& admconfirmacionesBo.eventoConfirmInXL(confOperacion)) {

				numcontr = admconfirmacionesBo.obtenerNumeroContador();
				admconfirmacionesBo.crearFicheroControl(contacto, oficina, fax,
						confOperacion.getEventoConfirmacion().getDescripcion(),
						confOperacion.getOperacion().getId().getNumeroOperacion(),
						numcontr, pdfs, texts);
				savePDF(confOperacion);
			} else {
				if (contrapartida.getTipoContrapartida() != null
						&& ("C").equals(contrapartida.getTipoContrapartida()
								.getId())) {

					if (confOperacion.getOperacion() != null
							&& ("39005001Z").equals(confOperacion.getOperacion()
									.getContrapartida().getId())) {
						// No se crea fichero de control
					} else {
						if (admconfirmacionesBo.obtenerFaxOficina(confOperacion)) {
							
							contacto = "Direccion Oficina";
							numcontr = admconfirmacionesBo.obtenerNumeroContador();
							admconfirmacionesBo.crearFicheroControl(contacto,
									oficina, fax, confOperacion
											.getEventoConfirmacion().getDescripcion(),
									confOperacion.getOperacion().getId()
											.getNumeroOperacion(), numcontr, pdfs,
									texts);
							savePDF(confOperacion);
						}
					}

					if ((contrapartida.getTipoContrapartida() != null && ("B")
							.equals(contrapartida.getTipoContrapartida().getId()))
							|| !admconfirmacionesBo
									.obtenerFaxOficina(confOperacion)) {

						// muestra mensaje fax no inforMostrar mensaje (Fax
						// no informado o errÃ³neo para la contrapartida ' ||
						// :BLK_PRAL.CONTRAPA || '. Â¿Desea confirmar?');
						contrapartidaaux = contrapartida;
						confOperacionaux = confOperacion;
						// confirmar = true;

						msgBoxAction.mostrarMsg(
								"#{admconfirmacionesAction.crearFicheroControl}",
								"#{admconfirmacionesAction.salir}",
								"Fax no informado o errÃ³neo para la contrapartida"
										+ contrapartidaaux + "Â¿Desea confirmar?");

						// Si pulsa SÃ
						// Continuar

						// Else
						// Salir sin hacer nada.
						// Fin si
					}// end if
				}// end if tipocont =C
			}
				
		} catch (IOException e) {

			addFromResourceBundleStatusMessage(e,
					"admconfirmaciones.obtenerDatosFax.error", confOperacion
							.getNumConfirmacion().toString(), confOperacion
							.getVista().getNcorrEstructu());
		}
	}

	public void savePDF(ConfOperacion confOperacion)
	//Integer numcontr,String pathPdf, String eventoConf, Long idDocDMS)
	{
		String fileName =  "Ot" + GenericUtils.lpad(numcontr.toString(),6,'0') + ".pdf";
		if (GenericUtils.in(confOperacion.getEvenConf(), EventoConfirmacion.FIJACION,
				EventoConfirmacion.LIQUIDACION)){
			try{
			final File pdfFile = principalDMS.obtenerDocumento(fileName, confOperacion.getIdDocDMS(), pdfs);
			} catch (Exception e) {
				log.error(e);
			}
		}else{
			BaseDBAccess access = new BaseDBAccess( "read-only",entityManager);
			try{
			access.saveTmpPDF(confOperacion.getNumConfirmacion(), pdfs+File.separatorChar+ "Ot" + GenericUtils.lpad(numcontr.toString(),6,'0') + ".pdf");
			}catch(Exception e){
				addStatusMessage(Severity.ERROR, e.getMessage());
			}
			
		}
		
	}

	public void crearFicheroControl() throws IOException {
		admconfirmacionesBo.crearFicheroControl(contacto, oficina, fax,
				confOperacionaux.getEventoConfirmacion().getDescripcion(),
				confOperacionaux.getOperacion().getId().getNumeroOperacion(),
				numcontr, pdfs, texts);
	}

	@Out(required = false)
	protected ConfOperacion cOperacionFrom;

	public ConfOperacion getcOperacionFrom() {
		return cOperacionFrom;
	}

	public void setcOperacionFrom(ConfOperacion cOperacionFrom) {
		this.cOperacionFrom = cOperacionFrom;
	}

	/**
	 * metodo para alta
	 */
	/**
	 * Objeto usado para el alta
	 */
	// @Out(required = false)
	protected ConfOperacion confOperacion;

	public ConfOperacion getConfOperacion() {
		return confOperacion;
	}

	public void setConfOperacion(ConfOperacion confOperacion) {
		this.confOperacion = confOperacion;
	}

	public String anexos() {
		modoTratamiento = Constantes.TIPOANEXO_MODO_C;
		tipoAnexo = Constantes.TIPOANEXO_CONFIRMACION;
		confOperacionSelect = admConfirmacionesPantalla
				.getAdmconfirmacionSelec();

		return "anexos";
	}

	/**
	 * Objeto HistoricoOperacion para outjectar a MANTOPER
	 */
	@Out(required = false)
	HistoricoOperacion hOperacion;

	public HistoricoOperacion gethOperacion() {
		return hOperacion;
	}

	public void sethOperacion(HistoricoOperacion hOperacion) {
		this.hOperacion = hOperacion;
	}

	@Out(required = false)
	@In(required = false)
	@SuppressWarnings("unused")
	private BoletasStates boletaState;

	/**
	 * Flag que indica que se viene (o se vendrÃ¡) de una redirecciÃ³n (a Boletas
	 * por ejemplo).
	 */
	private boolean redireccionExterna = false;

  
	public void obtenerReferencia(){
//		9612233566
		final ConfOperacion cOperacion = admConfirmacionesPantalla
		.getAdmconfirmacionSelec();
	    
//		TESTEAR OPERACION NO BLOQUEADA
		
//		final ConfOperacion cOperacion = admConfirmacionesPantalla
//		.getAdmconfirmacionSelec();


		historicoOperacion = admconfirmacionesBo.obtenerHistoricoOperacion(
				cOperacion.getOperacionID(), cOperacion.getFechaContratacion());
		
		Contrapartida contrapa = admconfirmacionesBo.cargarContrapa(cOperacion.getOperacion().getContrapa());
//		oncomplete="{Richfaces.showModalPanel('suReferenciaPanel');}"
	
		if (Constantes.CONTRAPA_GRUPOBAN_CLIENTE.equalsIgnoreCase(contrapa.getGrupoBancario().getId())){
			statusMessages.add(Severity.ERROR,"#{messages['admconfirmaciones.error.contrapanobanco']}");
			setOnCompleteNo();
		}else{
			setOnCompleteSi();
		}
		
		admConfirmacionesPantalla.sethOperReferencia(historicoOperacion);
		admConfirmacionesPantalla.setSuReferencia(historicoOperacion.getSuReferencia());
		admConfirmacionesPantalla.setAdmconfirmacionSuRefer(cOperacion);
	}
	
	public void setOnCompleteNo() {
		admConfirmacionesPantalla.setOnComplete("$('suReferenciaPanel').component.hide();return false;");
	}

	public void setOnCompleteSi() {
		admConfirmacionesPantalla.setOnComplete("$('suReferenciaPanel').component.show();");
	}

	public void suReferencia(){



		if 	(!GenericUtils.isNullOrBlank(admConfirmacionesPantalla.getSuReferencia())){
			admconfirmacionesBo.guardarReferencia(admConfirmacionesPantalla.getAdmconfirmacionSuRefer().getOperacionID(), 
					admConfirmacionesPantalla.getAdmconfirmacionSuRefer().getFechaContratacion(),admConfirmacionesPantalla.getSuReferencia());
			HistoricoOperacion hOperReferencia = admConfirmacionesPantalla.gethOperReferencia();
			admconfirmacionesBo.refrescarHO(admConfirmacionesPantalla.getAdmconfirmacionSuRefer(),hOperReferencia);
			
		}
	}
	/**
	 * metodo para integrar con Boletas
	 */
	public void boletas() {

		final ConfOperacion cOperacion = admConfirmacionesPantalla
				.getAdmconfirmacionSelec();

		historicoOperacion = admconfirmacionesBo.obtenerHistoricoOperacion(
				cOperacion.getOperacionID(), cOperacion.getFechaContratacion());
		boletaState = BoletasStates.CONSULTA_BOLETA;

		setRedireccionExterna(true);
	}

	/**
	 * metodo de comprobacion de la contrapartida para el renderizsado
	 */
	public Contrapartida obtenerContrapa(ConfOperacion confOperacion) {

		HistoricoOperacion oper = admconfirmacionesBo
				.obtenerHistoricoOperacion(confOperacion.getOperacionID(),
						confOperacion.getFechaContratacion());
		AbstractContrapartida a = entityUtil.unwrapProxy(oper
				.getContrapartida(), AbstractContrapartida.class);
		Contrapartida b = null;
		if (!(a instanceof Contrapartida)) {
			addStatusMessage(Severity.ERROR,
					"Esta contrapartida no tiene tipo contrapartida asociado");
		}
		b = (Contrapartida) a;

		return b;
	}


	/**
	 * metodo para caomprobar que todos los elementos de la lsita son del tipo
	 * descartada o recibida
	 */
	public HashSet<ConfOperacion> eliminarREorDE(List<ConfOperacion> list) {
		HashSet<ConfOperacion> listElimDEoRE = null;
		List<ConfOperacion> listaux = new ArrayList<ConfOperacion>();
		boolean descartada = false;
		for (ConfOperacion confOperacion : list) {
			listaux.add(confOperacion);
			if (("DE").equals(confOperacion.getEstadoConfirmacion())
					|| ("RE").equals(confOperacion.getEstadoConfirmacion())) {
				listaux.remove(confOperacion);
				descartada = true;
			}
		}
		if (descartada) {
			addStatusMessage(Severity.WARN,
					"#{messages['admconfirmaciones.error.exceptodere']}");
		}
		listElimDEoRE = new HashSet<ConfOperacion>(listaux);
		return listElimDEoRE;
	}

	/**
	 * metodo para obtener la decripcion del canal al no poder mapearse ya que
	 * los campos id que coinciden entre tablas, pueden estar repetidos
	 */
	public String obtenerDescripcionCanal(String canal) {
		return admconfirmacionesBo.obtenerDescripcionCanal(canal);
	}

	public String preconfirmada(ConfOperacion confirmacion){
		if (admconfirmacionesBo.existePreconfirmacion(confirmacion)) return "S"; else return "N";

	}
	
	/**
	 * metodo para obtener la decripcion del canal al no poder mapearse ya que
	 * los campos id que coinciden entre tablas, pueden estar repetidos
	 */
	public String obtenerDescripcionEstado(String estadoco) {
		return admconfirmacionesBo.obtenerDescripcionEstado(estadoco);
	}

	private List<ConfOperacion> recargarLista(PaginationData paginationData, Boolean batch) {

		String eventoConfirmacion = null;
		try {
			eventoConfirmacion = defaultIfNullOrBlank(
					this.admConfirmacionesPantalla.getTipoConfirmacion()
							.getCodigo(), null);
		} catch (NullPointerException e) {
		}

		String sentidoConfirmacion = null;
		try {
			sentidoConfirmacion = defaultIfNullOrBlank(
					this.admConfirmacionesPantalla.getSentidoConfirmacion()
							.getCodigo(), null);
		} catch (NullPointerException e) {
		}

		String estadoConfirmacion = null;
		try {
			estadoConfirmacion = defaultIfNullOrBlank(
					this.admConfirmacionesPantalla.getEstadoConfirmacion()
							.getCodigo(), null);
		} catch (NullPointerException e) {
		}

		// listaAdmconfirmaciones.clear();
		// PU P_CARGAR_DATOS_CONFIR_ESTRUCTU
		// listaAdmconfirmaciones =
		// admconfirmacionesBo.cargarDatosConfirmacionEstrucura(eventoConfirmacion,
		// estadoConfirmacion, this.admConfirmacionesPantalla.getEstructDesde(),
		// this.admConfirmacionesPantalla.getEstructHasta(),sentidoConfirmacion,
		// paginationData);
		// P_CARGAR_DATOS_CONFIRMACIONES

		final List<ConfOperacion> listaAdmconfirmaciones;

	
			String producto = null;
			try {
				producto = defaultIfNullOrBlank(this.admConfirmacionesPantalla
						.getPdtoContable().getId(), null);
			} catch (NullPointerException e) {
			}

			String oficina = null;
			try {
				oficina = defaultIfNullOrBlank(this.admConfirmacionesPantalla
						.getOficina(), null);
			} catch (NullPointerException e) {
			}

			String contrapartida = null;
			try {
				contrapartida = defaultIfNullOrBlank(
						this.admConfirmacionesPantalla.getContrapartida(), null);
			} catch (NullPointerException e) {
			}

			String tipoContrapartida = null;
			try {
				tipoContrapartida = defaultIfNullOrBlank(
						this.admConfirmacionesPantalla.getTipoContrapa()
								.getId(), null);
			} catch (NullPointerException e) {
			}

			String idioma = null;
			try {
				idioma = defaultIfNullOrBlank(this.admConfirmacionesPantalla
						.getIdiomaConfirmacion().getCodigo(), null);
			} catch (NullPointerException e) {
			}

			String canal = null;
			try {
				canal = defaultIfNullOrBlank(this.admConfirmacionesPantalla
						.getCanalConfirmacion().getId().getCodcanal(), null);
			} catch (NullPointerException e) {
			}

			Long productocatalogo = null;
			try {
				productocatalogo = defaultIfNullOrBlank(
						this.admConfirmacionesPantalla
								.getPdtoCatalogoBusqueda().getProducat(), null);
			} catch (NullPointerException e) {
			}

			if (admConfirmacionesPantalla.getEstructDesde() != null
					|| admConfirmacionesPantalla.getEstructHasta() != null) {

				admConfirmacionesPantalla.setNumOperDesde(null);
				admConfirmacionesPantalla.setNumOperHasta(null);
				listaAdmconfirmaciones = admconfirmacionesBo
						.cargarDatosConfirmacionEstrucura(this.admConfirmacionesPantalla
								.getNumOperDesde(), this.admConfirmacionesPantalla
								.getNumOperHasta(), eventoConfirmacion,
								sentidoConfirmacion, estadoConfirmacion,
								this.admConfirmacionesPantalla.getEstructDesde(),
								this.admConfirmacionesPantalla.getEstructHasta(),
								this.admConfirmacionesPantalla.getFechaDesde(),
								this.admConfirmacionesPantalla.getFechaHasta(),
								producto, oficina, contrapartida,
								tipoContrapartida, null, productocatalogo,
								idioma, canal, paginationData, batch);
								
//								eventoConfirmacion,
//								estadoConfirmacion, admConfirmacionesPantalla
//										.getEstructDesde(),
//								admConfirmacionesPantalla.getEstructHasta(),
//								sentidoConfirmacion, paginationData);
			} else {	
			
			admConfirmacionesPantalla.setEstructDesde(null);
			admConfirmacionesPantalla.setEstructHasta(null);
			Date fechaProceso = null;
			listaAdmconfirmaciones = admconfirmacionesBo
					.cargarDatosConfirmaciones(this.admConfirmacionesPantalla
							.getNumOperDesde(), this.admConfirmacionesPantalla
							.getNumOperHasta(), eventoConfirmacion,
							sentidoConfirmacion, estadoConfirmacion,
							this.admConfirmacionesPantalla.getEstructDesde(),
							this.admConfirmacionesPantalla.getEstructHasta(),
							this.admConfirmacionesPantalla.getFechaDesde(),
							this.admConfirmacionesPantalla.getFechaHasta(),
							producto, oficina, contrapartida,
							tipoContrapartida, fechaProceso, productocatalogo,
							idioma, canal, this.admConfirmacionesPantalla.getSuReferenciaBusc(), paginationData, batch);
		}

		return listaAdmconfirmaciones;
	}

	protected <T> T defaultIfNullOrBlank(T value, T tDefault) {
		return GenericUtils.isNullOrBlank(value) ? tDefault : value;
	}

	public boolean isConsultar() {
		return consultar;
	}

	public void setConsultar(boolean consultar) {
		this.consultar = consultar;
	}

	public boolean isMostrarPDF() {
		return mostrarPDF;
	}

	public void setMostrarPDF(boolean mostrarPDF) {
		this.mostrarPDF = mostrarPDF;
	}

	/**
	 * Verifica si el botÃ³n de vista previa puede verse.
	 * 
	 * @see #isVistaPreviaCaso1(ConfOperacion)
	 * @see #isVistaPreviaCaso2(ConfOperacion)
	 * @return <code>true</code> en el caso que se pueda habilitar/ver el botÃ³n.
	 */
	public boolean isVistaPreviaHabilitada() {

		final ConfOperacion cOperacion = admConfirmacionesPantalla
				.getAdmconfirmacionSelec();

		return isVistaPreviaCasoWS2(cOperacion) || isVistaPreviaOracleReports(cOperacion)
				|| isVistaPreviaBBDD(cOperacion);
	}

	/**
	 * En el caso que tenga habilitado el PDF por DRCONXML.
	 * 
	 * @param cOperacion
	 * @return
	 */
	public boolean isVistaPreviaBBDD(ConfOperacion cOperacion) {

		// TODO Actualizar VW_CONFIOPE2 en todos los entornos!!!
		return (isVistaPreviaCaso1(cOperacion) || isVistaPreviaCaso2(cOperacion))
				&& cOperacion.getVista().isVistaPreviaBBDDOk();
	}

	/**
	 * En el caso que tenga habilitado el PDF por WS.
	 * 
	 * @param cOperacion
	 * @return
	 */
	public boolean isVistaPreviaCasoWS(ConfOperacion cOperacion) {
		return (( cOperacion.getIdDocDMS() != null && 0 < cOperacion.getIdDocDMS()) && comprobarWS(casoWSIdDoc(cOperacion)) );
	}

	/**
	 * En el caso que tenga habilitado el PDF por WS.
	 * 
	 * @param cOperacion
	 * @return
	 */
	public boolean isVistaPreviaCasoWS2(ConfOperacion cOperacion) {
		return (( cOperacion.getIdDocDMS() != null && 0 < cOperacion.getIdDocDMS()));
	}

	
	/**
	 * En el caso que tenga habilitado el PDF por WS.
	 * 
	 * @param cOperacion
	 * @return
	 */
	public Long casoWSIdDoc(ConfOperacion cOperacion) {
			return cOperacion.getIdDocDMS() ;
	}
	
	
	
	/**
	 * En el caso que tenga habilitado el la vista previa mediante Oracle
	 * Reports.
	 * 
	 * @param cOperacion
	 * @return
	 */
	public boolean isVistaPreviaOracleReports(ConfOperacion cOperacion) {
//		return false;
		return !GenericUtils.in(cOperacion.getModelcon(), null,
				Constantes.MODELCON_MIGRADO)
				&& !GenericUtils.isNullOrBlank(cOperacion.getModelcon().trim());
	}

	/**
	 * Verifica si la operaciÃ³n pertenece al <b>caso1</b> del documento
	 * 
	 * <pre>
	 * DT - Lista de Confirmaciones v4 1.doc
	 * </pre>
	 * 
	 * @param cOperacion
	 * @return
	 */
	public boolean isVistaPreviaCaso1(ConfOperacion cOperacion) {

		return GenericUtils.equals(SentidoConfirmacion.ENVIAR, cOperacion
				.getSentidoConfirmacion())
				&& GenericUtils.equals(EstadoConfirmacion.PENDIENTE_CONFIRMAR,
						cOperacion.getEstadoConfirmacion())
				&& GenericUtils.isNullOrBlank(cOperacion.getConfirmReclamada())
				&& !GenericUtils.in(cOperacion.getCanalConfirmacion(),
						CanalOperacion.CORREO_INTEGRADO,
						CanalOperacion.MANUAL_MANUAL, CanalOperacion.SWIFT);
	}

	/**
	 * Verifica si la operaciÃ³n pertenece al <b>caso2</b> del documento
	 * 
	 * <pre>
	 * DT - Lista de Confirmaciones v4 1.doc
	 * </pre>
	 * 
	 * @param cOperacion
	 * @return
	 */
	public boolean isVistaPreviaCaso2(ConfOperacion cOperacion) {

		return GenericUtils.equals(SentidoConfirmacion.ENVIAR, cOperacion
				.getSentidoConfirmacion())
				&& GenericUtils.in(cOperacion.getEstadoConfirmacion(),
						EstadoConfirmacion.PROCESADA,
						EstadoConfirmacion.DESCARTADO)
				&& !GenericUtils.in(cOperacion.getCanalConfirmacion(),
						CanalOperacion.MANUAL_MANUAL, CanalOperacion.SWIFT);
	}


	public void preVistaPrevia() {
		
		ocultarPanelesModales();

		final ConfOperacion cOperacion = admConfirmacionesPantalla
				.getAdmconfirmacionSelec();


		if (isVistaPreviaCasoWS(cOperacion)) {
			vistaPrevia();
		}else if (isVistaPreviaCasoWS2(cOperacion)) {

//			vistaPrevia();
			msgBoxAction
			.mostrarMsg("#{admconfirmacionesAction.vistaPrevia()}", // funcionSi
					"#{admconfirmacionesAction.vistaPrevia()}", // funcionNo
					null, // onCompleteSi
					null, // onCompleteNo
					"mostrarPDFPanel,confirmarPanel", // reRenderSi
					"mostrarPDFPanel,confirmarPanel", // reRenderNo
					"No existe en DMS y deberÃ­a");

		}else{
			vistaPrevia();
		}

	}
	
	
	/**
	 * AcciÃ³n llamada por el botÃ³n de vista previa.
	 * 
	 * @see #isVistaPreviaHabilitada()
	 */
	public void vistaPrevia() {

		ocultarPanelesModales();
		setErrorWS(false);
		final ConfOperacion cOperacion = admConfirmacionesPantalla
				.getAdmconfirmacionSelec();

		if (!isVistaPreviaHabilitada()) {

			addStatusMessage(Severity.ERROR,
					"#{messages['admconfirmaciones.error.operacion']}");

			return;
		}

		// Para que el link funcione
		confOperacionaux = cOperacion;

		//
		// MÃ©todo WS
		//

		if (isVistaPreviaCasoWS(cOperacion)) {
			
			
			
			// ncorrela : 9612500211

			// if (true) {
			//
			// statusMessages.add(StatusMessage.Severity.ERROR,
			// "VisualizaciÃ³n de PDFs mediante "
			// + "WS no implementado todavÃ­a.");
			//
			// return;
			// }

				verPDF();
				
				return ;
		}else if (isVistaPreviaCasoWS2(cOperacion)) {
			setErrorWS(true);
		}

		//
		// MÃ©todo Oracle Reports - Hablar con Sonia
		//

		if (isVistaPreviaOracleReports(cOperacion)) {

			log.debug("MÃ©todo Oracle Reports:: "
					+ cOperacion.getNumConfirmacion());

			
//			if (getErrorWS()){
//				
//				msgBoxAction
//				.mostrarMsg("#{admconfirmacionesAction.buildOracleReportPre()}", // funcionSi
//						"#{admconfirmacionesAction.buildOracleReportPre()}", // funcionNo
//						null, // onCompleteSi
//						null, // onCompleteNo
//						null, // reRenderSi
//						null, // reRenderNo
//						"No existe en DMS y deberÃ­a");
////				buildOracleReportPre();
//				return;
//			}
			
			buildOracleReport(cOperacion);

			return ;
		}

		//
		// MÃ©todo por BBDD
		//

		admConfirmacionesPantalla.setWatermark(MarcaDeAgua.ORIGINAL.toString());

		if (isVistaPreviaCaso1(cOperacion)) {

			log
					.debug("isVistaPreviaCaso1:: "
							+ cOperacion.getNumConfirmacion());

			if (GenericUtils.equals(cOperacion.getEventoConfirmacion(),
					EventoConfirmacion.ALTA)
					&& !admconfirmacionesBo.isCampanya(cOperacion)) {

				addFromResourceBundleStatusMessage(Severity.ERROR,
						"admconfirmaciones.sibis", confOperacion
								.getNumConfirmacion().toString(), confOperacion
								.getVista().getNcorrEstructu());

				if (getErrorWS()){
					addStatusMessage(Severity.WARN,"#{messages['admconfirmaciones.error.wsdms']}");
				}
				return;
			}

			if (GenericUtils.in(cOperacion.getCanalConfirmacion(),
					CanalOperacion.ON_LINE_EMAIL, CanalOperacion.ON_LINE_FAX,
					CanalOperacion.ON_LINE_MANUAL,CanalOperacion.URGENTE)) {
				
				if (authorizator.isPermisoModificacion()){
				
				msgBoxAction
						.mostrarMsg("#{admconfirmacionesAction.verPDF()}", // funcionSi
								"#{admconfirmacionesAction.editarPDF()}", // funcionNo
								null, // onCompleteSi
								null, // onCompleteNo
								"mostrarPDFPanel,messageBoxPanelContrapa", // reRenderSi
								"mostrarPDFPanel", // reRenderNo
								"¿Desea consultar (Si) o modificar (No) la confirmacion?");
				
				
				}else{
					verPDF();
				}
				
			} else if (GenericUtils.in(cOperacion.getCanalConfirmacion(),
					CanalOperacion.BATCH_EMAIL, CanalOperacion.BATCH_FAX,
					CanalOperacion.BATCH_MANUAL)) {

				verPDF();

			} else {

				addStatusMessage(Severity.ERROR,
						"#{messages['admconfirmaciones.error.operacion']}");

				if (getErrorWS()){
					addStatusMessage(Severity.WARN,"#{messages['admconfirmaciones.error.wsdms']}");
				}
				
				return;
			}
		}

		if (isVistaPreviaCaso2(cOperacion)) {

			log
					.debug("isVistaPreviaCaso2:: "
							+ cOperacion.getNumConfirmacion());

			if (GenericUtils.equals(cOperacion.getEstadoConfirmacion(),
					EstadoConfirmacion.PROCESADA)
					&& cOperacion.getConfirmReclamada() == null) {

				msgBoxAction
						.mostrarMsg(
								"#{admconfirmacionesAction.verPdfConMarcaDeAguaDuplicado()}", // funcionSi
								"#{admconfirmacionesAction.verPDF()}", // funcionNo
								null, // onCompleteSi
								null, // onCompleteNo
								"mostrarPDFPanel,messageBoxPanelContrapa", // reRenderSi
								"mostrarPDFPanel", // reRenderNo
								"Â¿Desea usar la marca de agua 'Duplicado' ?");

			} else if (GenericUtils.equals(cOperacion.getEstadoConfirmacion(),
					EstadoConfirmacion.DESCARTADO)) {
				verPdfConMarcaDeAguaAnulado();
			} else {
				verPDF();
			}
		}
	}

	private boolean comprobarWS(Long casoWSIdDoc) {
		// TODO Auto-generated method stub
		return true;
	}

	public void verPdfConMarcaDeAguaAnulado() {

		// ATH 10/08/10 : No hay que enviar la marca de agua ANULADO.
//		admConfirmacionesPantalla.setWatermark(MarcaDeAgua.ANULADO.toString());
		admConfirmacionesPantalla.setWatermark(null);
		verPDF();
	}

	public void verPdfConMarcaDeAguaDuplicado() {

		admConfirmacionesPantalla
				.setWatermark(MarcaDeAgua.DUPLICADO.toString());
		verPDF();
	}

	public String getContrapartidaId(AbstractContrapartida abstractContrapartida) {
		if (!contrapartidaUtil.isInstanceOfContrapartida(abstractContrapartida)) {
			return "";
		}
		Contrapartida contrapartida = contrapartidaUtil
				.castAsContrapartida(abstractContrapartida);
		return contrapartida.getId();
	}

	//
	// FIN MÃ©todos para el control y gestiÃ³n de la vista previa.
	//

	public String obtenerEstadoConfirmacion(ConfOperacion co) {

		if (co.getConfirmReclamada() != null) {

			return obtenerDescripcionEstado(co.getEstadoConfirmacion()
					+ co.getConfirmReclamada());
		}

		return obtenerDescripcionEstado(co.getEstadoConfirmacion());
	}

	public void cargarContrapartidas() {
		buscadorContrapartidaAction.buscar();
	}

	public void cargarOficinas() {
		buscadorOficinaAction.buscar();
	}

	public void salir() {
		Conversation conversacion = Conversation.instance();
		// Volvemos a la anterior conversaciÃ³n
		if (conversacion.isNested()) {
			conversacion.redirectToParent();
		} else {
			redirectToURL("/home.seam");
			conversacion.endAndRedirect();
		}
	}

	public boolean isRedireccionExterna() {
		return redireccionExterna;
	}

	public void setRedireccionExterna(boolean redireccionExterna) {
		this.redireccionExterna = redireccionExterna;
	}

	public boolean isMostrarReport() {
		return mostrarReport;
	}

	public void setMostrarReport(boolean mostrarReport) {
		this.mostrarReport = mostrarReport;
	}

	public AdmConfirmacionOracleReport getAcOracleReport() {
		return acOracleReport;
	}

	public String getTipoReclamada() {
		return tipoReclamada;
	}

	public void setTipoReclamada(String tipoReclamada) {
		this.tipoReclamada = tipoReclamada;
	}

	public boolean isMostrarReclamarPanel() {
		return mostrarReclamarPanel;
	}

	public void setMostrarReclamarPanel(boolean mostrarReclamarPanel) {
		this.mostrarReclamarPanel = mostrarReclamarPanel;
	}

	protected static AtomicInteger messageId = new AtomicInteger(1);

	protected static Pattern fqName = Pattern.compile("(?:\\w+\\.)+\\w+");

	void addStatusMessage(Severity severity, String messageTemplate,
			Object... params) {

		final String msg = getInterpolatedMessage(messageTemplate, params);

		log.info(msg);

		statusMessages.add(severity, msg);
	}

	void addFromResourceBundleStatusMessage(Severity severity,
			String messageTemplate, Object... params) {

		final String msg = getInterpolatedMessage(messageTemplate, params);

		log.info(msg);

		statusMessages.addFromResourceBundle(severity, msg);

	}

	void addFromResourceBundleStatusMessage(Exception e,
			String messageTemplate, Object... params) {

		final String msg = getInterpolatedMessage(messageTemplate, params);

		GenericUtils.logException(log, e, msg);

		statusMessages.addFromResourceBundle(Severity.ERROR, msg);
	}

	private String getInterpolatedMessage(String messageTemplate, Object... params) {

		final int mId = messageId.getAndIncrement();
		final Object[] params2;
		if (params == null) {
			params2 = new Object[] { mId };
		} else {
			final List<Object> paramList = new ArrayList<Object>(Arrays
					.asList(params));
			paramList.add(mId);
			params2 = paramList.toArray();
		}

		// InterpolaciÃ³n mensaje
		if (fqName.matcher(messageTemplate).matches()) {

			final String msg = interpolator.interpolate("#{messages['"
					+ messageTemplate + "']}");
			return MessageFormat.format(msg, params2);

		} else if (messageTemplate.startsWith("#{")) {

			final String msg = interpolator.interpolate(messageTemplate,
					params2);
			return MessageFormat.format(msg, params2);
		} else {
			return messageTemplate;
		}
	}

	void addToControlStatusMessage(String id, Severity severity,
			String messageTemplate, Object... params) {

		final String msg = getInterpolatedMessage(messageTemplate, params);

		log.info(msg);

		statusMessages.addToControl(id, severity, msg);
	}

	public String getReclamarTipoAnexo() {
		return reclamarTipoAnexo;
	}

	public void setReclamarTipoAnexo(String reclamarTipoAnexo) {
		this.reclamarTipoAnexo = reclamarTipoAnexo;
	}

	public Date getReclamarFechaAnexo() {
		return reclamarFechaAnexo;
	}

	public void setReclamarFechaAnexo(Date reclamarFechaAnexo) {
		this.reclamarFechaAnexo = reclamarFechaAnexo;
	}


	public String getReclamarTextoAnexo() {
		return reclamarTextoAnexo;
	}
	
	public void setReclamarTextoAnexo(String reclamarTextoAnexo) {
		this.reclamarTextoAnexo = reclamarTextoAnexo;
	}

	public boolean isMostrarEnviarFase2Panel() {
		return mostrarEnviarFase2Panel;
	}

	public void setMostrarEnviarFase2Panel(boolean mostrarEnviarFase2Panel) {
		this.mostrarEnviarFase2Panel = mostrarEnviarFase2Panel;
	}

	public String getTipoEventoEnvio() {
		return tipoEventoEnvio;
	}

	public void setTipoEventoEnvio(String tipoEventoEnvio) {
		this.tipoEventoEnvio = tipoEventoEnvio;
	}
	
	public void recalcularBotonera() {

		if (admconfirmacionesBo == null || admConfirmacionesPantalla == null) {
			try {
				Component.forName("admconfirmacionesAction").inject(this, true);
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}

		if (admconfirmacionesBo == null || admConfirmacionesPantalla == null)
			return;

		botonEnviar.setDisabled(!habilitadoEnviar()|| !authorizator.isPermisoModificacion());
		botonRecibida.setDisabled(!habilitadoRecibida()|| !authorizator.isPermisoModificacion());
		botonRecepcionada.setDisabled(!habilitadoRecepcionada()|| !authorizator.isPermisoModificacion());
		botonDescartada.setDisabled(!habilitadoDescartar()|| !authorizator.isPermisoModificacion());
		botonReclamar.setDisabled(isReclamarDisabled()|| !authorizator.isPermisoModificacion());
	}

	public SeleccionCheckboxMap<ConfOperacion> getSeleccionOPMap() {
		return seleccionOPMap;
	}

	/**
	 * Oculta todos los paneles modales.
	 */
	private void ocultarPanelesModales() {

		setMostrarEnviarFase2Panel(false);
		setMostrarPDF(false);
		setMostrarReport(false);
		setMostrarReclamarPanel(false);
		msgBoxAction.setMostrarMensaje(false);
	}

	public Boolean getErrorWS() {
		return errorWS;
	}

	public void setErrorWS(Boolean errorWS) {
		this.errorWS = errorWS;
	}

	public boolean isMostrarAnexoPanel() {
		return mostrarAnexoPanel;
	}

	public void setMostrarAnexoPanel(boolean mostrarAnexoPanel) {
		this.mostrarAnexoPanel = mostrarAnexoPanel;
	}

	public String getOncompleteModePanel() {
		return oncompleteModePanel;
	}

	public void setOncompleteModePanel(String oncompleteModePanel) {
		this.oncompleteModePanel = oncompleteModePanel;
	}

	public String getReRenderModePanel() {
		return reRenderModePanel;
	}

	public void setReRenderModePanel(String reRenderModePanel) {
		this.reRenderModePanel = reRenderModePanel;
	}




	@Override
	public boolean isLastExists() {
		return true;
	}
	
	public void last(){
		if ( GenericUtils.isNullOrBlank(ultimRegistre) || ultimRegistre == 0 ){
			ultimRegistre = prepareConfirmacionesListCount();
		}
		if (ultimRegistre == -1){
			addStatusMessage(Severity.ERROR,
					"#{messages['admconfirmaciones.error.last']}");
			return;
		}
		goLast(ultimRegistre);
	}

	public Integer getUltimRegistre() {
		return ultimRegistre;
	}

	public void setUltimRegistre(Integer ultimRegistre) {
		this.ultimRegistre = ultimRegistre;
	}


	private Integer prepareConfirmacionesListCount() {
		Integer comptadorRegistres = new Integer(0);
		List<ConfOperacion> listaAdmconfirmaciones = new ArrayList<ConfOperacion>();

		
		if (!busqueda && Constantes.MODO_AGE.equals(modo)) {
			excel = true;
			setExportExcel(true);
			listaAdmconfirmaciones = cargarAgenda(null);
		}else{
			listaAdmconfirmaciones = recargarLista(paginationData.getPaginationDataForExcel(),null);
		}
		
		if (listaAdmconfirmaciones!=null && listaAdmconfirmaciones.size()!=0){
			comptadorRegistres = listaAdmconfirmaciones.get(0).getNumeroRegistros();
		}
		
		return comptadorRegistres;

	}
	
	private Boolean esCanalUrgente(ConfOperacion co){
	
		if ("UR".equalsIgnoreCase(co.getCanalConfirmacion())){
				return true;
			}
		return false;	
	}
	
	
	/**
	 * Miramos si se va a realizar la llamada a FD.
	 *  
	 *  1 - que este activo el flag de Firmadigital (tabla DESCCODI)
	 *  PACKAGE 2 - Flag INDBSONL para la contrapartida
	 *  PACKAGE 3 - Persona Juridica y tenga apoderados o Persona Fisica
	 *  4 - Estadoco confiope PC
	 * @param co
	 * @param referCheck 
	 * @param checkFD 
	 * @param contrapa 
	 * @return
	 * Devuelve
	 * 0 - Error
	 * 1 - Ni checkFD ni referCheck
	 * 2 - CheckFD pero no referCheck
	 * 3 - Sin CheckFD pero si referCheck
	 * 4 - CheckFD y referCheck
	 * 5 - Ni checkFD ni referCheck ni actualizarContrapa FORZADO
	 * 6 - Sin CheckFD pero si referCheck ni actualizarContrapa FORZADO 
	 * 7 - Sin CheckFD pero si referCheck ni actualizar flags CANAL URGENTE  
	 * 8 - Ni checkFD ni referCheck ni actualizar flags CANAL URGENTE
	 * 
	 */
	private Integer checkFD(ConfOperacion co, Contrapartida contrapa){
		
		try {
		
			activarFirmaDigital = admconfirmacionesBo.activarFirmaDigital();
			
			if (!activarFirmaDigital){
				System.out.println("Retorno checkFD:1");
				return 1;
			}
			
			if (esCanalUrgente(co)){
				if (!GenericUtils.isNullOrBlank(co.getIndicadorFirmaDigital())  
						&& "S".equalsIgnoreCase(co.getIndicadorFirmaDigital())){
					System.out.println("Retorno checkFD:7");
					return 7;
				}else{
					System.out.println("Retorno checkFD:8");
					return 8;	
				}
			}
			
				if (isForzadoManual(co,contrapa)){

					if (!GenericUtils.isNullOrBlank(co.getIndicadorFirmaDigital())  
							&& "S".equalsIgnoreCase(co.getIndicadorFirmaDigital())){
						System.out.println("Retorno checkFD:6");
						return 6;
					}else{
						System.out.println("Retorno checkFD:5");
						return 5;	
					}
				
				}
				
				Boolean validarFirmantes = contraFirmaDigital(co,contrapa);
				
				if (GenericUtils.isNullOrBlank(validarFirmantes)){

					if (!GenericUtils.isNullOrBlank(co.getIndicadorFirmaDigital())  
							&& "S".equalsIgnoreCase(co.getIndicadorFirmaDigital())){
						System.out.println("Retorno checkFD:2");
						return 2;
					}else{
						System.out.println("Retorno checkFD:1");
						return 1;	
					}
				}
				
				if (validarFirmantes){
					//Informar contrapa a S
//					boletasBo.actualizarContrapaFD(historicoOperacion.getContrapartida().getId(),ConstantesFD.VALIDACION_FIRMANTES_CONTRAPAFD);
					if (GenericUtils.isNullOrBlank(co.getIndicadorFirmaDigital())  
							|| "N".equalsIgnoreCase(co.getIndicadorFirmaDigital())){
						System.out.println("Retorno checkFD:4");
						return 4;
					}else{
						System.out.println("Retorno checkFD:2");
						return 2;
					}
					
					
				}else{
					//Informar contrapa a N
//					boletasBo.actualizarContrapaFD(historicoOperacion.getContrapartida().getId(),ConstantesFD.VALIDACION_FIRMANTES_CONTRAPANOFD);
					if (!GenericUtils.isNullOrBlank(co.getIndicadorFirmaDigital())  
							&& "S".equalsIgnoreCase(co.getIndicadorFirmaDigital())){
						System.out.println("Retorno checkFD:3");
						return 3;
					}else{
						System.out.println("Retorno checkFD:1");
						return 1;
					}
				}
			

			
			
			
		} catch (Exception e) {
			
			//PENSAR SI HACE FALTA DEVOLVER FALSE Y ABORTAR MISION o ANOTAR ERROR y go on
			admconfirmacionesBo.saveResultadoToLog(ConstantesFD.LOG_COD_ERROR_SIN_ACCESO_WS,  e.getLocalizedMessage(),co, 
					ConstantesFD.VALIDACION_FIRMANTES_CON, ConstantesFD.VALIDACION_FIRMANTES_KO);
			e.printStackTrace();
			System.out.println("Retorno checkFD:0");
			return 0;
		}
		
//		activarFirmaDigital = admconfirmacionesBo.activarFirmaDigital();
//		
//		if (!activarFirmaDigital){
//			return false;
//		}
//		
//		if (!"PC".equals(co.getEstadoco())){
//			return false;
//		}
//		
//		String idContrapa = "";
//		if(co.getOperacion()!=null)
//			idContrapa = co.getOperacion().getContrapa();
//		else if(co.getEstructura()!=null){
//			idContrapa = co.getEstructura().getContrapartida().getId();
//		}
//		Contrapartida contrapa = contrapartidaBo.cargar(idContrapa);
//		if(!"S".equals(contrapa.getIndBsOnl())){
//			return false;
//		}
//		
//		List<Apoderado> apoderados = null ;
//
//		if (!"F".equalsIgnoreCase(contrapa.getTipoPersona())){
//		
//			apoderados = admconfirmacionesBo.apoderadosDeContrapa(contrapa.getId(), ConstantesFD.IND_MASOL_SOLIDARIA, contrapa.getTipoPersona());
//
//			if(apoderados.size()==0){
//				return false;
//			}
//		}
		
	}
	
	
	
	private boolean isForzadoManual(ConfOperacion co, Contrapartida contrapa) {

		if (enviarFDManual  || 
			"S".equalsIgnoreCase(contrapa.getIndFirmaManualForzada())){
				
			return true;
		}else{
			return false;	
		}
		
		
	}

	private String obtenerSesionValidacion(){

		try {
//			com.bs.proteo.soa.service.mainframe.UserLogin.domain.InputData inputData = new com.bs.proteo.soa.service.mainframe.UserLogin.domain.InputData();
			//setusername y password
//			firmaDigital.setUsername(Identity.instance().getCredentials().getUsername());
			String proxyGrantingTicket = getTicket();
			String passTicket = firmaDigital.getPassTicket(proxyGrantingTicket);
			System.out.println("passTicket=-"+passTicket+"-");
//			String grantServiceTicket = firmaDigital.getServiceTicket(proxyGrantingTicket);
//			System.out.println("grantServiceTicket=-"+grantServiceTicket+"-");
			
			String sessionValida = validacionFD.userLogin(Identity.instance().getCredentials().getUsername(),passTicket,sessionId);
			
			if(sessionValida.equals("-1")||	sessionValida.equals("-2")){
				System.out.println("validacionFD KO SESION NO");
				return null;
			}else{
				System.out.println("validacionFD sesion2 =-"+sessionValida+"-");
				return sessionValida;
			}
		} catch (Exception e) {
			System.out.println("validacionFD KO SESION NO:"+e.getLocalizedMessage());
			e.printStackTrace();
			return null;
			
		}

		

	}
	
	private Boolean contraFirmaDigital(ConfOperacion co, Contrapartida contrapartida) {

		String sesionValidarConfirmacion = obtenerSesionValidacion();
		if (GenericUtils.isNullOrBlank(sesionValidarConfirmacion)){
			admconfirmacionesBo.saveResultadoToLog(ConstantesFD.LOG_COD_ERROR_SIN_SESION,  ConstantesFD.LOG_DESC_ERROR_SIN_SESION, co, 
					ConstantesFD.VALIDACION_FIRMANTES_CON, ConstantesFD.VALIDACION_FIRMANTES_KO);
			return null;
		}
		//Llamada WS
		return validacionFirmaDigital(co,sesionValidarConfirmacion,contrapartida);
		
	}

	
	
	private Boolean validacionFirmaDigital(ConfOperacion confOperacion, String sesionValidarConfirmacion, Contrapartida contrapa){
		
//		Contrapartida contrapa = obtenerContrapaBase(contrapartida);
		List<Long> numpersonas = new ArrayList<Long>();
		Long numPersoEmpresa = null;
		
		if (!GenericUtils.isNullOrBlank(contrapa)){
			
			//SMM 01/06/2016 Si no tenemos Tipperso no miramos grabamos errror en tabla
			if (GenericUtils.isNullOrBlank(contrapa.getTipoPersona())){
				admconfirmacionesBo.saveResultadoToLog(ConstantesFD.VALIDACION_FIRMANTES_APODERA,  ConstantesFD.VALIDACION_FIRMANTES_APODERATXT, confOperacion, 
						ConstantesFD.VALIDACION_FIRMANTES_BOL, ConstantesFD.VALIDACION_FIRMANTES_KO);
				return false;
			}
			
			if (!"F".equalsIgnoreCase(contrapa.getTipoPersona())){
				
				List<Apoderado> apoderados = admconfirmacionesBo.apoderadosDeContrapa(contrapa.getId(), 
						ConstantesFD.IND_MASOL_SOLIDARIA, contrapa.getTipoPersona());
				
				if (GenericUtils.isNullOrBlank(apoderados) || apoderados.isEmpty() || apoderados.size() == 0){
					admconfirmacionesBo.saveResultadoToLog(ConstantesFD.VALIDACION_FIRMANTES_APODERA2,  ConstantesFD.VALIDACION_FIRMANTES_APODERA2TXT, confOperacion, 
							ConstantesFD.VALIDACION_FIRMANTES_CON, ConstantesFD.VALIDACION_FIRMANTES_KO);
					return false;
				}
				
				for (Apoderado apoderado : apoderados) {

//					//SMM 03/12/2015 Mancomunadas NO tienen FD
//					if (ConstantesFD.IND_MASOL_MANCOMUNADA.equalsIgnoreCase(apoderado.getIndMasol())){
//						
//						admconfirmacionesBo.saveResultadoToLog(ConstantesFD.VALIDACION_FIRMANTES_APODERA3,  ConstantesFD.VALIDACION_FIRMANTES_APODERA3TXT, confOperacion, 
//								ConstantesFD.VALIDACION_FIRMANTES_CON, ConstantesFD.VALIDACION_FIRMANTES_KO);
//						
//						return false;
//					}
//					
					
					if (!GenericUtils.isNullOrBlank(apoderado.getCapoderado()) && 
							!GenericUtils.isNullOrBlank(apoderado.getCapoderado().getNumPerso())){
						numpersonas.add(apoderado.getCapoderado().getNumPerso().longValue());		
					}else{
						admconfirmacionesBo.saveResultadoToLog(ConstantesFD.VALIDACION_FIRMANTES_APODERA,  ConstantesFD.VALIDACION_FIRMANTES_APODERATXT, confOperacion, 
								ConstantesFD.VALIDACION_FIRMANTES_CON, ConstantesFD.VALIDACION_FIRMANTES_KO);
						return false;		
					}
				}
			
				
				//Se necesita numPersoEmpresa cuando se trata de personas no fisicas
				if (!GenericUtils.isNullOrBlank(contrapa.getNumeroPersona())){
					numPersoEmpresa  = contrapa.getNumeroPersona().longValue();	
				}else{
					admconfirmacionesBo.saveResultadoToLog(ConstantesFD.VALIDACION_FIRMANTES_APODERA,  ConstantesFD.VALIDACION_FIRMANTES_APODERATXT, confOperacion, 
							ConstantesFD.VALIDACION_FIRMANTES_CON, ConstantesFD.VALIDACION_FIRMANTES_KO);
					return false;
				}
				
				
			}else if (!GenericUtils.isNullOrBlank(contrapa.getNumeroPersona())){
				Long numperso = contrapa.getNumeroPersona().longValue();	
				numpersonas.add(numperso);
			}else{
				admconfirmacionesBo.saveResultadoToLog(ConstantesFD.VALIDACION_FIRMANTES_APODERA,  ConstantesFD.VALIDACION_FIRMANTES_APODERATXT, confOperacion, 
						ConstantesFD.VALIDACION_FIRMANTES_CON, ConstantesFD.VALIDACION_FIRMANTES_KO);
				return false;
			}

		
		
		}else{
			admconfirmacionesBo.saveResultadoToLog(ConstantesFD.VALIDACION_FIRMANTES_CONTRAPA,  ConstantesFD.VALIDACION_FIRMANTES_CONTRAPATXT, confOperacion, 
					ConstantesFD.VALIDACION_FIRMANTES_CON, ConstantesFD.VALIDACION_FIRMANTES_KO);
			return false;
		}
		
		if (GenericUtils.isNullOrBlank(numpersonas) || numpersonas.isEmpty() || numpersonas.size() == 0){
			admconfirmacionesBo.saveResultadoToLog(ConstantesFD.VALIDACION_FIRMANTES_APODERA,  ConstantesFD.VALIDACION_FIRMANTES_APODERATXT, confOperacion, 
					ConstantesFD.VALIDACION_FIRMANTES_CON, ConstantesFD.VALIDACION_FIRMANTES_KO);
			return false;
		}

		
		Fp7005I inputdata =null;
		for (Long persona : numpersonas) {

			
			//CODOPCION : â€˜PEâ€™
			//CODCONTRAT: numpersona particular

//			CODOPCION : â€˜PJâ€™
//			CODCONTRAT: numpersona autoritzat
//			TIPEXP: numpersona de lâ€™empresa (completat amb 0 per lâ€™esquerra). 20 carÃ cters alfanumÃ¨rics.

				String opcion,tipExp;
				if (GenericUtils.isNullOrBlank(numPersoEmpresa)){
					//Persona FISICA
					opcion = ConstantesFD.CODIGO_OPCION_PE;
					tipExp = "0";	
				}else{
					opcion = ConstantesFD.CODIGO_OPCION_PJ;
					tipExp = GenericUtils.lpad(numPersoEmpresa.toString(), 20, "0");	
				}
				
				System.out.println("validacionFD opcion =-"+opcion+"-");
				System.out.println("validacionFD tipExp =-"+tipExp+"-");
				System.out.println("validacionFD persona =-"+persona+"-");
				
				inputdata = new Fp7005I(opcion ,ConstantesFD.CODIGO_ENTIDAD_81, "0", persona, "0", 
						"0", "0",tipExp, "0", "0", "0", "0");
		
	
			try {
//				String xmlText = XMLUtils.toXML(inputdata);
//				System.out.println("validacionFD Llamada =-"+xmlText+"-");
				ExecuteResponse resposta = validacionFD.autorizacionTest(sesionValidarConfirmacion, inputdata);
				
				System.out.println("validacionFD OK O NO");
				if (!GenericUtils.isNullOrBlank(resposta) && !GenericUtils.isNullOrBlank(resposta.getOutputData())){
					
					
					System.out.println("validacionFD OK =-"+resposta.getOutputData()+"-");
					System.out.println("validacionFD IndFc OK =-"+resposta.getOutputData().getIndFc()+"-");
					
					if (!"S".equalsIgnoreCase(resposta.getOutputData().getIndFc())){
						admconfirmacionesBo.saveResultadoToLog(ConstantesFD.VALIDACION_FIRMANTES_CODOK,  ConstantesFD.VALIDACION_FIRMANTES_FDKO + contrapa.getId() , confOperacion, 
								ConstantesFD.VALIDACION_FIRMANTES_CON, ConstantesFD.VALIDACION_FIRMANTES_OK);
						
						System.out.println("validacionFD KO Salida FC=-");	
						
						return false;
					}
					
					if (!GenericUtils.isNullOrBlank(resposta.getOutputData().getFp7005Or()) 
							&& resposta.getOutputData().getFp7005Or().length> 0){
						
						System.out.println("validacionFD IndBd OK =-"+resposta.getOutputData().getFp7005Or(0).getIndBd()+"-");
						System.out.println("validacionFD IndMovAa OK =-"+resposta.getOutputData().getFp7005Or(0).getIndMovAa()+"-");
						
							if (!"S".equalsIgnoreCase(resposta.getOutputData().getFp7005Or(0).getIndBd()) ||
								!"S".equalsIgnoreCase(resposta.getOutputData().getFp7005Or(0).getIndMovAa())){
								
								admconfirmacionesBo.saveResultadoToLog(ConstantesFD.VALIDACION_FIRMANTES_CODOK,  ConstantesFD.VALIDACION_FIRMANTES_FDKO + contrapa.getId() , confOperacion, 
										ConstantesFD.VALIDACION_FIRMANTES_CON, ConstantesFD.VALIDACION_FIRMANTES_OK);
								return false;
							}
					
					}else{
						admconfirmacionesBo.saveResultadoToLog(ConstantesFD.LOG_COD_ERROR_SIN_ACCESO_WS,  ConstantesFD.VALIDACION_FIRMANTES_VACIA, confOperacion, 
								ConstantesFD.VALIDACION_FIRMANTES_CON, ConstantesFD.VALIDACION_FIRMANTES_KO);
						System.out.println("validacionFD KO =-OutputData-");
						if (!GenericUtils.isNullOrBlank(resposta.getOutputData().getFp7005Or()) ){
							System.out.println("validacionFD KO =-"+resposta.getOutputData().getFp7005Or()+"-");	
						}
						return false;
					}
				
				}else{
					admconfirmacionesBo.saveResultadoToLog(ConstantesFD.LOG_COD_ERROR_SIN_ACCESO_WS,  ConstantesFD.VALIDACION_FIRMANTES_VACIA, confOperacion, 
							ConstantesFD.VALIDACION_FIRMANTES_CON, ConstantesFD.VALIDACION_FIRMANTES_KO);
					System.out.println("validacionFD KO =-Sin Respuesta-");
					return false;
				}
			} catch (FaultInfo e) {
				String errorWS=null;
				
				if (!GenericUtils.isNullOrBlank(e.getNativeFault())){
					if (!GenericUtils.isNullOrBlank(e.getNativeFault().getFaultCode())){
						if (!GenericUtils.isNullOrBlank(e.getNativeFault().getFaultMessage())){
							errorWS = e.getNativeFault().getFaultCode().concat(" ").concat(e.getNativeFault().getFaultMessage());
						}else{
							errorWS = e.getNativeFault().getFaultCode();
						}
						
					}
					
				}
				if (GenericUtils.isNullOrBlank(errorWS)){
					errorWS = e.getMessage();
				}
				
				admconfirmacionesBo.saveResultadoToLog(ConstantesFD.LOG_COD_ERROR_SIN_ACCESO_WS, errorWS, confOperacion, 
						ConstantesFD.VALIDACION_FIRMANTES_CON, ConstantesFD.VALIDACION_FIRMANTES_KO);
				System.out.println("validacionFD=-"+errorWS+"-");
				e.printStackTrace();
				return false;
			} catch (Exception e) {
				admconfirmacionesBo.saveResultadoToLog(ConstantesFD.LOG_COD_ERROR_SIN_ACCESO_WS,  e.getMessage(), confOperacion, 
						ConstantesFD.VALIDACION_FIRMANTES_CON, ConstantesFD.VALIDACION_FIRMANTES_KO);
				System.out.println("validacionFD=-"+e.getMessage()+"-");
				e.printStackTrace();
				return false;
			}
		
		}
		
		admconfirmacionesBo.saveResultadoToLog(ConstantesFD.VALIDACION_FIRMANTES_CODOK,  ConstantesFD.VALIDACION_FIRMANTES_FDOK + contrapa.getId() , confOperacion, 
				ConstantesFD.VALIDACION_FIRMANTES_CON, ConstantesFD.VALIDACION_FIRMANTES_OK);
		return true;
		
			

		}	
	
	
	//SMM IN Progress

	private String generarStringLlamadaOSP(ModificaRequest modificaRequest) {
		StringBuilder sb = new StringBuilder();
		String retorno = new String("\r\n");
		
		sb.append("HeaderRequest: ").append(modificaRequest.getHeaderRequest().toString()).append(retorno);
		sb.append("InputData: ").append(modificaRequest.getModificaInputData().toString()).append(retorno);
		
		return sb.toString();
	}
	
	private String generarStringLlamadaFD(String sessionId, String globalid){
		
		StringBuilder sb = new StringBuilder();
		String retorno = new String("\r\n");
		
		sb.append("ApplicationId: DERI").append(retorno);
		sb.append("Language: ES").append(retorno);
		sb.append("Step: 1").append(retorno);
		sb.append("TrackingId: DERI:MIFID:").append(retorno);
		sb.append("PROCEDENCIA: DP01").append(retorno);
		sb.append("TIPCONTRATO: 05").append(retorno);
		sb.append("TIP-PERSONA: 99").append(retorno);
		sb.append("CODOPEINF: MF36").append(retorno);
		sb.append("SessionId: "+ sessionId).append(retorno);
		sb.append("Globalid: "+ globalid);


		return sb.toString();
		
	}

	/**
	 * Devuelve String vacÃ­o si todo ha ido bien o el error que se haya producido en el proceso
	 * @param co
	 * @return
	 */
	private String firmaCentralizada(ConfOperacion co,Boolean indicadorViaSegura, Boolean checkFD){
	/*1- Tenemos que hacer la llamada?
		1.1. obtener contrapartida: la tenemos en la operaciÃ³n
		1.2. indicador mancomunada o solidaria: acceder a tabla deri.reltiapo 
								where ctitular=contrapa 1.1 and estadoco='VA'
			OJO. puede haber mÃ¡s de 1 registro. Si no hay --> FIN proceso, no tiene apoderados
			uno o mÃ¡s filas: el campo INDMASOL. 
			Si es 'S' llamada WS. Si no --> FIN proceso (de momento solo para solidaria)
		1.3. llamada WS
		 	1.3.1. OK --> actualizar INDICOSP a 'O' en la tabla deri.confiope
		 	1.3.2. KO --> mostrar display con el error devuelto por el WS
	 */
	//1.1. obtener contrapartida: la tenemos en la operaciÃ³n
	String idContrapa = "";
	Operacion opeEstr =null;
	if(co.getOperacion()!=null)
		idContrapa = co.getOperacion().getContrapa();
	else if(co.getEstructura()!=null){
		idContrapa = co.getEstructura().getContrapartida().getId();
	//nos quedamos con la primera operacion
		opeEstr = co.getEstructura().getOperacions().iterator().next();
	}
	log.debug("idContrapa: -"+idContrapa+"-");
	//De momento sÃ³lo para firma solidaria. indmasol='S'
	//1.2
	Contrapartida contrapa = contrapartidaBo.cargar(idContrapa);
	if(!indicadorViaSegura && !"S".equals(contrapa.getIndBsOnl())){
		//Si no estÃ¡ activo el indBsOnl no hacemos nada
		return "INDBSONL";
	}
	
	List<Apoderado> apoderados = null ;
	//Si la persona es fÃ­sica la propia contrapartida hace de apoderado
	if (!"F".equalsIgnoreCase(contrapa.getTipoPersona())){
	
		apoderados = admconfirmacionesBo.apoderadosDeContrapa(contrapa.getId(), ConstantesFD.IND_MASOL_SOLIDARIA, contrapa.getTipoPersona());
		log.debug("nÃºmero de apoderados de la contrapa: -"+apoderados.size()+"-");
	
	}
	if(!"F".equalsIgnoreCase(contrapa.getTipoPersona()) && apoderados.size()==0){
		return "admconfirmaciones.firmadigital.no.existen.firmantes";
		//"No existen firmantes vÃ¡lidos para el tipo de firma requerido.";//fin del proceso
	}else{
		//obtenemos o validamos el identificador de la sesiÃ³n
		System.out.println("sessionId: "+sessionId);
		if(sessionId==null|| sessionId.equals("")){
			//login en el webservice con el usuario de sesiÃ³n de DERI
			com.bs.proteo.soa.service.mainframe.UserLogin.domain.InputData inputData = new com.bs.proteo.soa.service.mainframe.UserLogin.domain.InputData();
			//setusername y password
			firmaDigital.setUsername(credentials.getUsername());
			System.out.println("username: "+credentials.getUsername());
			//String proxyGrantingTicket = getTicket();
			System.out.println("proxyGrantingTicket=-"+proxyGrantingTicket+"-");
			String passTicket = firmaDigital.getPassTicket(proxyGrantingTicket);
			System.out.println("passTicket=-"+passTicket+"-");
			firmaDigital.setPassword(passTicket);
			String sessionValida = firmaDigital.login(co.getIdioma().obteCodigoI18n(),"");
			if(sessionValida.equals("-1")||	sessionValida.equals("-2")){
				return "admconfirmaciones.firmadigital.sesion.invalida";//SesiÃ³n de servicio invÃ¡lida"
			}else{
				sessionId = sessionValida;
				//Contexts.getSessionContext().set("sessionId", sessionId);  
			}
		}
		//llamada al webservice de firma digital
		SimpleDateFormat sdf = new SimpleDateFormat(Constantes.DDMMYYYY);
		RegisterRequest request = new RegisterRequest();
		//headerRq: aplicacion, language
		HeaderRequest headerRequest = new HeaderRequest();
		HeaderRequestHostRequest hostRequest = new HeaderRequestHostRequest();
		hostRequest.setSessionId(sessionId);
		headerRequest.setHostRequest(hostRequest);
		headerRequest.setApplicationId(ConstantesFD.APLICACION_FIRMA);
		headerRequest.setLanguage(co.getIdioma().obteCodigoI18n());
		headerRequest.setStep(ConstantesFD.FD_STEP);
	    headerRequest.setTrackingId(ConstantesFD.FD_TRACKING_ID_FD);//+new Random());
		request.setHeaderRequest(headerRequest);
		
		/* codigos[0] = codDocumento;
		   codigos[1] = codExpediente;*/
		String[] codigosExpedienteDocumento=admconfirmacionesBo.calcularCodDocumentoCodExpediente(co);

		//input data: idOperacion, codUsuario, idioma, idDocumento, titularContrato,firmante/s,tipoFirma
		//Contexto: importe, divisa, tradeDate, fechaVen
		RegisterInputData inputData = new RegisterInputData();
		
		Document[] document = new Document[1];
		Product product = new Product();
		Document documento = new Document();
		
		documento.setRepository(ConstantesFD.REPOSITORIO_DMS);
		//SMM Descripcion 16/10/2015
		if (Constantes.IDIOMA_CATALAN.equals(co.getIdioma().getCodigo())){
			documento.setDescription(ConstantesFD.DESCRIP_FD_CATALAN);
		}else if (Constantes.IDIOMA_INGLES.equals(co.getIdioma().getCodigo())){
			documento.setDescription(ConstantesFD.DESCRIP_FD_INGLES);
		}else{
			documento.setDescription(ConstantesFD.DESCRIP_FD_CASTELLANO);
		}
				
		
		
		
//		inputData.setTipoOperacion(ConstantesFD.OPERACION_CONFIRMACIONTS);
//		inputData.setProductType(ConstantesFD.PRODUCT_TYPE);
		inputData.setProductType(ConstantesFD.OPERACION_CONFIRMACIONTS);
		//ncorrela o estructu segÃºn sea una operaciÃ³n o una estructura
		String idOperacion = co.getOperacionID()!=null?co.getOperacionID().toString():new Long(co.getEstructura().getEstructu()).toString(); 
		String operacion=idOperacion+"|"+co.getEvenConf()+"|"+co.getNumConfirmacion();
		//String operacion = codigosExpedienteDocumento[1];
		System.out.println("idOperacion: "+operacion);
// SMM 13/12/2017
		//		inputData.setIdOperacion(operacion);
		
		
		inputData.setApplicationCode(ConstantesFD.APLICACION_DERITD);
		inputData.setUserCode(co.getAuditData().getUsuarioUltimaModi());
		inputData.setRequester(co.getAuditData().getUsuarioUltimaModi());
		inputData.setLanguage(co.getIdioma().obteCodigoI18n());
//		inputData.setIdRepositorio(ConstantesFD.REPOSITORIO_DMS);
		inputData.setInputChannel(ConstantesFD.CANALENTRADA_DERI);
		
//		inputData.setIsFC1(true);
		
		
		//Producto: productgr de la operacion. Pasamos al WS la descripciÃ³n del productoTgr
		ProductoTgr productoTgr=null;
		if(co.getOperacion()!=null){
			if(co.getOperacion().getProductoTgr()!=null){
				productoTgr = admconfirmacionesBo.obtenerProductoTgr(co.getOperacion().getProductoCatalogo(), co.getOperacion().getProductoTgr());
				product.setProductId(productoTgr.getDescripcionProductoTgr());
			}
		}else{
			//nos quedamos con la primera operacion
//			Operacion opeEstr = co.getEstructura().getOperacions().iterator().next();
			productoTgr = admconfirmacionesBo.obtenerProductoTgr(opeEstr.getProductoCatalogo(), opeEstr.getProductoTgr());
			product.setProductId(productoTgr.getDescripcionProductoTgr());//setProductId("DD 00004");
		}

		DocsContrapartida docCMOF= admconfirmacionesBo.obtenerDocucont(co, Constantes.DOCUCONT_CMOF);
//		inputData.setIdContrato(formatearIdContrato(docCMOF));
		product.setContractNumber(formatearIdContrato(docCMOF));
		product.setCaseDescription(ConstantesFD.APLICACION_FIRMA);
		
		

		//SMM 01/12/2014			
		inputData.setBankCode("01");
		
	
		//SMM 20/01/2016 Cambio WS Caducidad
		String caducidad;
		GregorianCalendar fechaCad= new GregorianCalendar();
		fechaCad.setTime(new Date());
		fechaCad.add(Calendar.YEAR, 15);
		Date datCaducitat = admconfirmacionesBo.ajustarFecha(fechaCad.getTime(),"F",admconfirmacionesBo.obtenerDivisa(Constantes.DIVISA_EUR));
		fechaCad.setTime(datCaducitat);
//		SimpleDateFormat sdfCad = new SimpleDateFormat(Constantes.YYYYMMDD10);
//		caducidad = sdfCad.format(datCaducitat);
//		//            <dom:caducidad>2015-11-30T15:30:00</dom:caducidad>
//		caducidad = caducidad.concat("T15:00:00");
//		
//		inputData.setCaducidad(fechaCad);
		inputData.setExpirationDate(fechaCad);
//		System.out.println(caducidad);
		
		
		
		//CodDocumento|TipoDocumento|CodExpediente|TipoExpediente
		//String idDocumento = idOperacion+"|"+Constantes.TIPO_DOCUMENTO+"|"+co.getNumConfirmacion()+"|"+Constantes.TIPO_EXPEDIENTE;
		
		/*
			codigoDocumento: â€œ220112000002|M|000000617553â€
			tipoDocumento: â€œConfirmacionesTSâ€
			codigoExpediente: â€œ01|DD |000009370009556â€
			tipoExpdiente: â€œContratoDDâ€
		 */
		//220112000002|M|000000617553][ ConfirmacionesTS][01|DD |000009370009556][ContratoDD]
//		String idDocumento = "["+codigosExpedienteDocumento[0] + "][" + Constantes.TIPO_DOCUMENTO + "]["+codigosExpedienteDocumento[1]+"]["+Constantes.TIPO_EXPEDIENTE+"]";
//		inputData.setIdDocumento(idDocumento);

		documento.setDocumentCode(codigosExpedienteDocumento[0]);
		documento.setDocumentType(Constantes.TIPO_DOCUMENTO);
		documento.setFolderCode(codigosExpedienteDocumento[1]);
		documento.setFolderType(Constantes.TIPO_EXPEDIENTE);
		documento.setLOPD(ConstantesFD.LOPD);
//		documento.setFilename(ConstantesFD.PRODUCT_TYPE);
		documento.setFilename(ConstantesFD.OPERACION_CONFIRMACIONTS);
		documento.setDocumentFileId(co.getIdDocDMS().toString());
		documento.setMimeType(ConstantesFD.MIME_TYPE);
   
		product.setTripletaSIBIS(codigosExpedienteDocumento[1]);
		
		inputData.setProduct(product);
		
		Contrapartida contrapartida = this.contrapartidaBo.cargar(idContrapa);
		String  titularContrato=null;

		if(contrapartida!=null)
			titularContrato = contrapartida.getNumeroPersona().toString();
		//inputData.setTitularContrato((BigInteger)titularContrato);

		
//		Sâ€™ha dâ€™informar el numpersona de lâ€™empresa (en el cas dâ€™autoritzats) 
//			en el camp titularContrato, en el cas de particulars aquest camp va a 0.

		
//		String[] canalfirma;
		if(!checkFD){
//			canalfirma = new String[1];
//			canalfirma[0]=ConstantesFD.PRESENCIAL;	
			inputData.setSignChannel(ConstantesFD.PRESENCIAL);
		}
			//SMM 20/01/2016 Cambio WS Firmantes
		
		//numperso   Numero de persona de los apoderados numÃ©rico de 10 (occurs)
		String indicadorTipofirma=null;
		Signer[] firmantes;
		SignerIdentification company = new SignerIdentification();
		String tipoPersonaFisica= "F";
		if(contrapa.getTipoPersona().equals(tipoPersonaFisica)){
			firmantes = new Signer[1];
			firmantes[0]=new Signer(titularContrato,null,null,null);	
			company.setSignerPersonNumber("0");
			company.setSegment("P");
		}else{
			company.setSignerPersonNumber(titularContrato);
			company.setSegment("E");
			firmantes = new Signer[apoderados.size()];
			
			if ("S".equalsIgnoreCase((apoderados.get(0)).getIndMasol())){
				indicadorTipofirma =ConstantesFD.PARAM_IND_MASOL_INDISTINTA; 
			}else{
				indicadorTipofirma =ConstantesFD.PARAM_IND_MASOL_CONJUNTA;
			}
			
			for(int i=0;i<apoderados.size();i++){
				Integer firmantei=(apoderados.get(i)).getCapoderado().getNumPerso();
				if(firmantei!=null){
					firmantes[i]=new Signer(firmantei.toString(),null,null,null);
				}
			}
		}
		//SMM 20/01/2016 Cambio WS Firmantes
		documento.setSigner(firmantes);
		/* individual / indistinta / conjunta (no para 1Âª fase) 
		En nuestro caso Indmasol   
		indistinta
		individual
		RELTIAPO
		blanc NOOOOO
		S
		M

		<> Blanc

		1 individual
		>1 S indistinta
		>1 M conjunta
		 */
		if(firmantes.length>1)
			//inputData.setTipoFirma(ConstantesFD.PARAM_IND_MASOL_INDISTINTA);
			documento.setSignType(indicadorTipofirma);
		else
			documento.setSignType(ConstantesFD.PARAM_IND_MASOL_INDIVIDUAL);
		
		company.setName(contrapa.getDescLarga());
		company.setCIF(contrapa.getId());
		
		inputData.setCompany(company);
		document[0] = documento;
		inputData.setDocument(document);
		
		
		ProductDetail[] contexto = new ProductDetail[67];//11 etiquetas x 6 idiomas, nCorrela, tipoProceso
		BigDecimal importe;
		String divisa = "";
		
		if(co.getOperacion()!=null){
			//SMM 03/12/2015
//			if (co.getOperacion().getProductoCatalogo()== 1751417 || co.getOperacion().getProductoCatalogo()== 1751416){
			if (!GenericUtils.isNullOrBlank(co.getVista()) &&
				!GenericUtils.isNullOrBlank(co.getVista().getProductoCatalogo()) &&
				!GenericUtils.isNullOrBlank(co.getVista().getProductoCatalogo().getProdtrat()) &&
				!GenericUtils.isNullOrBlank(co.getVista().getProductoCatalogo().getProdtrat().getTratge02()) &&
				"S".equalsIgnoreCase(co.getVista().getProductoCatalogo().getProdtrat().getTratge02())){
				importe =
					co.getOperacion().getDivisaPago()==null?
							co.getOperacion().getNominalRecibo().multiply(co.getOperacion().getStrikeRecibo()):
								co.getOperacion().getNominalPago().multiply(co.getOperacion().getStrikePago());
				 
			}else{
				importe =co.getOperacion().getDivisaPago()==null?co.getOperacion().getNominalRecibo():co.getOperacion().getNominalPago();	
			}

			divisa = co.getOperacion().getDivisaPago()==null?co.getOperacion().getDivisaRecibo():co.getOperacion().getDivisaPago(); 
		}
		else{
			//nos quedamos con la primera operacion
//			Operacion opeEstr = co.getEstructura().getOperacions().iterator().next();

//			if (opeEstr.getProductoCatalogo()== 1751417 || opeEstr.getProductoCatalogo()== 1751416){
			if (!GenericUtils.isNullOrBlank(co.getVista()) &&
				!GenericUtils.isNullOrBlank(co.getVista().getProductoCatalogo()) &&
				!GenericUtils.isNullOrBlank(co.getVista().getProductoCatalogo().getProdtrat()) &&
				!GenericUtils.isNullOrBlank(co.getVista().getProductoCatalogo().getProdtrat().getTratge02()) &&
				"S".equalsIgnoreCase(co.getVista().getProductoCatalogo().getProdtrat().getTratge02())){					
			
				importe =opeEstr.getDivisaPago()==null?opeEstr.getNominalRecibo().multiply(opeEstr.getStrikeRecibo()):opeEstr.getNominalPago().multiply(opeEstr.getStrikePago());
				 
			}else{
			
				importe =opeEstr.getDivisaPago()==null?opeEstr.getNominalRecibo():opeEstr.getNominalPago();
			
			}
			
			divisa = opeEstr.getDivisaPago()==null?opeEstr.getDivisaRecibo():opeEstr.getDivisaPago();
		}
		
		//SMM 21/11/2013
		String tradeDate="";
		if(co.getOperacion()!=null)
			tradeDate = sdf.format(co.getOperacion().getId().getFechaContratacion());
		else
			tradeDate = sdf.format(co.getEstructura().getFechaContratacion());

		String fechaVen="";
		if(co.getOperacion()!=null)
			fechaVen = sdf.format(co.getOperacion().getFechaVencimiento());
		else
			fechaVen = sdf.format(co.getEstructura().getFechaVencimiento());
		
		//ncorrela
		//tipoProceso
		
		//producto contexto
		String productoContexto = "";
		if(co.getOperacion()!=null)
			productoContexto=co.getOperacion().getProducto();
		else
			productoContexto=co.getEstructura().getProducto().getId();

		
		String nomEmpresa="";
		nomEmpresa = contrapa.getDescLarga();
		String nifContrapa ="";
		nifContrapa =contrapa.getId();
	
		//SUP 27/07/2015
		String fechaVal="";
		if(co.getOperacion()!=null)
			fechaVal = sdf.format(co.getOperacion().getFechaValor());
		else
			fechaVal = sdf.format(co.getEstructura().getFechaValor());
		
		
		String nominalContexto ="";
		nominalContexto = new DecimalFormat("###,##0.00").format(importe).concat(" ").concat(divisa);
		
		System.out.println(nominalContexto);
		
		List<Idioma> idiomas = admconfirmacionesBo.generarListaIdiomas();
		for(Idioma idioma: idiomas){
			
			String idiomaContext = idioma.obteCodigoI18n().concat("-");
			
		
			
//			if(idioma.getCodigo().equals(Constantes.IDIOMA_CASTELLANO)){
//				contexto[0]=new ContextCaptcha(idiomaContext.concat(ConstantesFD.CONTEXTO_PRODUCTO_ES),getDescripcionProductoContexto(productoContexto,Constantes.IDIOMA_CASTELLANO_ABREVIADO));
//				contexto[1]=new ContextCaptcha(idiomaContext.concat(ConstantesFD.CONTEXTO_NCORRELA_ES),idOperacion);
//				contexto[2]=new ContextCaptcha(idiomaContext.concat(ConstantesFD.CONTEXTO_TIPO_PROCESO_ES),getDescripcionEvenconfByIdioma(co.getEvenConf(), "ES"));
//				contexto[3]=new ContextCaptcha(idiomaContext.concat(ConstantesFD.CONTEXTO_NOMINAL_ES),nominalContexto);
//				contexto[4]=new ContextCaptcha(idiomaContext.concat(ConstantesFD.CONTEXTO_FECHAVAL_ES),fechaVal);
//				contexto[5]=new ContextCaptcha(idiomaContext.concat(ConstantesFD.CONTEXTO_FECHAVEN_ES),fechaVen);
//				contexto[6]=new ContextCaptcha(idiomaContext.concat(ConstantesFD.CONTEXTO_CONFIRMACION_ES),getDescripcionProductoContexto(productoContexto,Constantes.IDIOMA_CASTELLANO_ABREVIADO));
//				contexto[7]=new ContextCaptcha(idiomaContext.concat(ConstantesFD.CONTEXTO_TRADEDATE_ES),tradeDate);
//				contexto[8]=new ContextCaptcha(idiomaContext.concat(ConstantesFD.CONTEXTO_NOMBRE_CONTRAPA),nomEmpresa);
//				contexto[9]=new ContextCaptcha(idiomaContext.concat(ConstantesFD.CONTEXTO_CIF_CONTRAPA),nifContrapa);
//				contexto[10]=new ContextCaptcha(idiomaContext.concat("BSO_BOTON_RECHAZAR"),"No");
//				contexto[11]=new ContextCaptcha(idiomaContext.concat("MULTIIDIOMA"),"TRUE");
//			}else if(idioma.getCodigo().equals(Constantes.IDIOMA_CATALAN)){
//				contexto[12]=new ContextCaptcha(idiomaContext.concat(ConstantesFD.CONTEXTO_PRODUCTO_ES),getDescripcionProductoContexto(productoContexto,Constantes.IDIOMA_CATALAN_ABREVIADO));
//				contexto[13]=new ContextCaptcha(idiomaContext.concat(ConstantesFD.CONTEXTO_NCORRELA_ES),idOperacion);
//				contexto[14]=new ContextCaptcha(idiomaContext.concat(ConstantesFD.CONTEXTO_TIPO_PROCESO_ES),getDescripcionEvenconfByIdioma(co.getEvenConf(), "CA"));
//				contexto[15]=new ContextCaptcha(idiomaContext.concat(ConstantesFD.CONTEXTO_NOMINAL_ES),nominalContexto);
//				contexto[16]=new ContextCaptcha(idiomaContext.concat(ConstantesFD.CONTEXTO_FECHAVAL_ES),fechaVal);
//				contexto[17]=new ContextCaptcha(idiomaContext.concat(ConstantesFD.CONTEXTO_FECHAVEN_ES),fechaVen);
//				contexto[18]=new ContextCaptcha(idiomaContext.concat(ConstantesFD.CONTEXTO_CONFIRMACION_ES),getDescripcionProductoContexto(productoContexto,Constantes.IDIOMA_CATALAN_ABREVIADO));
//				contexto[19]=new ContextCaptcha(idiomaContext.concat(ConstantesFD.CONTEXTO_TRADEDATE_ES),tradeDate);
//				contexto[20]=new ContextCaptcha(idiomaContext.concat(ConstantesFD.CONTEXTO_NOMBRE_CONTRAPA),nomEmpresa);
//				contexto[21]=new ContextCaptcha(idiomaContext.concat(ConstantesFD.CONTEXTO_CIF_CONTRAPA),nifContrapa);
//				contexto[22]=new ContextCaptcha(idiomaContext.concat("BSO_BOTON_RECHAZAR"),"No");
//			}else if(idioma.getCodigo().equals(Constantes.IDIOMA_INGLES)){
//				contexto[23]=new ContextCaptcha(idiomaContext.concat(ConstantesFD.CONTEXTO_PRODUCTO_ES),getDescripcionProductoContexto(productoContexto,Constantes.IDIOMA_INGLES_ABREVIADO));
//				contexto[24]=new ContextCaptcha(idiomaContext.concat(ConstantesFD.CONTEXTO_NCORRELA_ES),idOperacion);
//				contexto[25]=new ContextCaptcha(idiomaContext.concat(ConstantesFD.CONTEXTO_TIPO_PROCESO_ES),getDescripcionEvenconfByIdioma(co.getEvenConf(), "EN"));
//				contexto[26]=new ContextCaptcha(idiomaContext.concat(ConstantesFD.CONTEXTO_NOMINAL_ES),nominalContexto);
//				contexto[27]=new ContextCaptcha(idiomaContext.concat(ConstantesFD.CONTEXTO_FECHAVAL_ES),fechaVal);
//				contexto[28]=new ContextCaptcha(idiomaContext.concat(ConstantesFD.CONTEXTO_FECHAVEN_ES),fechaVen);
//				contexto[29]=new ContextCaptcha(idiomaContext.concat(ConstantesFD.CONTEXTO_CONFIRMACION_ES),getDescripcionProductoContexto(productoContexto,Constantes.IDIOMA_INGLES_ABREVIADO));
//				contexto[30]=new ContextCaptcha(idiomaContext.concat(ConstantesFD.CONTEXTO_TRADEDATE_ES),tradeDate);
//				contexto[31]=new ContextCaptcha(idiomaContext.concat(ConstantesFD.CONTEXTO_NOMBRE_CONTRAPA),nomEmpresa);
//				contexto[32]=new ContextCaptcha(idiomaContext.concat(ConstantesFD.CONTEXTO_CIF_CONTRAPA),nifContrapa);
//				contexto[33]=new ContextCaptcha(idiomaContext.concat("BSO_BOTON_RECHAZAR"),"No");
//				
//			}
//		}
//		
//		//aleman
//		//No tenemos las descripciones en este idioma. Las mostramos en ingles
//		contexto[34]=new ContextCaptcha("de_DE-".concat(ConstantesFD.CONTEXTO_PRODUCTO_ES),getDescripcionProductoContexto(productoContexto,Constantes.IDIOMA_INGLES_ABREVIADO));
//		contexto[35]=new ContextCaptcha("de_DE-".concat(ConstantesFD.CONTEXTO_NCORRELA_ES),idOperacion);
//		contexto[36]=new ContextCaptcha("de_DE-".concat(ConstantesFD.CONTEXTO_TIPO_PROCESO_ES),getDescripcionEvenconfByIdioma(co.getEvenConf(), "DE"));
//		contexto[37]=new ContextCaptcha("de_DE-".concat(ConstantesFD.CONTEXTO_NOMINAL_ES),nominalContexto);
//		contexto[38]=new ContextCaptcha("de_DE-".concat(ConstantesFD.CONTEXTO_FECHAVAL_ES),fechaVal);
//		contexto[39]=new ContextCaptcha("de_DE-".concat(ConstantesFD.CONTEXTO_FECHAVEN_ES),fechaVen);			
//		contexto[40]=new ContextCaptcha("de_DE-".concat(ConstantesFD.CONTEXTO_CONFIRMACION_ES),getDescripcionProductoContexto(productoContexto,Constantes.IDIOMA_INGLES_ABREVIADO));
//		contexto[41]=new ContextCaptcha("de_DE-".concat(ConstantesFD.CONTEXTO_TRADEDATE_ES),tradeDate);
//		contexto[42]=new ContextCaptcha("de_DE-".concat(ConstantesFD.CONTEXTO_NOMBRE_CONTRAPA),nomEmpresa);
//		contexto[43]=new ContextCaptcha("de_DE-".concat(ConstantesFD.CONTEXTO_CIF_CONTRAPA),nifContrapa);
//		contexto[44]=new ContextCaptcha("de_DE-".concat("BSO_BOTON_RECHAZAR"),"No");
//
//		
//		//portugues
//		//No tenemos las descripciones en este idioma. Las mostramos en ingles
//		contexto[45]=new ContextCaptcha("pt_PT-".concat(ConstantesFD.CONTEXTO_PRODUCTO_ES),getDescripcionProductoContexto(productoContexto,Constantes.IDIOMA_INGLES_ABREVIADO));
//		contexto[46]=new ContextCaptcha("pt_PT-".concat(ConstantesFD.CONTEXTO_NCORRELA_ES),idOperacion);
//		contexto[47]=new ContextCaptcha("pt_PT-".concat(ConstantesFD.CONTEXTO_TIPO_PROCESO_ES),getDescripcionEvenconfByIdioma(co.getEvenConf(), "PT"));
//		contexto[48]=new ContextCaptcha("pt_PT-".concat(ConstantesFD.CONTEXTO_NOMINAL_ES),nominalContexto);
//		contexto[49]=new ContextCaptcha("pt_PT-".concat(ConstantesFD.CONTEXTO_FECHAVAL_ES),fechaVal);
//		contexto[50]=new ContextCaptcha("pt_PT-".concat(ConstantesFD.CONTEXTO_FECHAVEN_ES),fechaVen);
//		contexto[51]=new ContextCaptcha("pt_PT-".concat(ConstantesFD.CONTEXTO_CONFIRMACION_ES),getDescripcionProductoContexto(productoContexto,Constantes.IDIOMA_INGLES_ABREVIADO));
//		contexto[52]=new ContextCaptcha("pt_PT-".concat(ConstantesFD.CONTEXTO_TRADEDATE_ES),tradeDate);
//		contexto[53]=new ContextCaptcha("pt_PT-".concat(ConstantesFD.CONTEXTO_NOMBRE_CONTRAPA),nomEmpresa);
//		contexto[54]=new ContextCaptcha("pt_PT-".concat(ConstantesFD.CONTEXTO_CIF_CONTRAPA),nifContrapa);
//		contexto[55]=new ContextCaptcha("pt_PT-".concat("BSO_BOTON_RECHAZAR"),"No");
//		
//		//frances
//		//No tenemos las descripciones en este idioma. Las mostramos en ingles
//		contexto[56]=new ContextCaptcha("fr_FR-".concat(ConstantesFD.CONTEXTO_PRODUCTO_ES),getDescripcionProductoContexto(productoContexto,Constantes.IDIOMA_INGLES_ABREVIADO));
//		contexto[57]=new ContextCaptcha("fr_FR-".concat(ConstantesFD.CONTEXTO_NCORRELA_ES),idOperacion);
//		contexto[58]=new ContextCaptcha("fr_FR-".concat(ConstantesFD.CONTEXTO_TIPO_PROCESO_ES),getDescripcionEvenconfByIdioma(co.getEvenConf(), "FR"));
//		contexto[59]=new ContextCaptcha("fr_FR-".concat(ConstantesFD.CONTEXTO_NOMINAL_ES),nominalContexto);
//		contexto[60]=new ContextCaptcha("fr_FR-".concat(ConstantesFD.CONTEXTO_FECHAVAL_ES),fechaVal);
//		contexto[61]=new ContextCaptcha("fr_FR-".concat(ConstantesFD.CONTEXTO_FECHAVEN_ES),fechaVen);
//		contexto[62]=new ContextCaptcha("fr_FR-".concat(ConstantesFD.CONTEXTO_CONFIRMACION_ES),getDescripcionProductoContexto(productoContexto,Constantes.IDIOMA_INGLES_ABREVIADO));
//		contexto[63]=new ContextCaptcha("fr_FR-".concat(ConstantesFD.CONTEXTO_TRADEDATE_ES),tradeDate);
//		contexto[64]=new ContextCaptcha("fr_FR-".concat(ConstantesFD.CONTEXTO_NOMBRE_CONTRAPA),nomEmpresa);
//		contexto[65]=new ContextCaptcha("fr_FR-".concat(ConstantesFD.CONTEXTO_CIF_CONTRAPA),nifContrapa);
//		contexto[66]=new ContextCaptcha("fr_FR-".concat("BSO_BOTON_RECHAZAR"),"No");


		
		if(idioma.getCodigo().equals(Constantes.IDIOMA_CASTELLANO)){
			contexto[0]=new ProductDetail(idiomaContext.concat(ConstantesFD.CONTEXTO_PRODUCTO_ES),getDescripcionProductoContexto(productoContexto,Constantes.IDIOMA_CASTELLANO_ABREVIADO), "0");
			contexto[1]=new ProductDetail(idiomaContext.concat(ConstantesFD.CONTEXTO_NCORRELA_ES),idOperacion,"0");
			contexto[2]=new ProductDetail(idiomaContext.concat(ConstantesFD.CONTEXTO_TIPO_PROCESO_ES),getDescripcionEvenconfByIdioma(co.getEvenConf(), "ES"),"0");
			contexto[3]=new ProductDetail(idiomaContext.concat(ConstantesFD.CONTEXTO_NOMINAL_ES),nominalContexto,"0");
			contexto[4]=new ProductDetail(idiomaContext.concat(ConstantesFD.CONTEXTO_FECHAVAL_ES),fechaVal,"0");
			contexto[5]=new ProductDetail(idiomaContext.concat(ConstantesFD.CONTEXTO_FECHAVEN_ES),fechaVen,"0");
			contexto[6]=new ProductDetail(idiomaContext.concat(ConstantesFD.CONTEXTO_CONFIRMACION_ES),getDescripcionProductoContexto(productoContexto,Constantes.IDIOMA_CASTELLANO_ABREVIADO),"0");
			contexto[7]=new ProductDetail(idiomaContext.concat(ConstantesFD.CONTEXTO_TRADEDATE_ES),tradeDate,"0");
			contexto[8]=new ProductDetail(idiomaContext.concat(ConstantesFD.CONTEXTO_NOMBRE_CONTRAPA),nomEmpresa,"0");
			contexto[9]=new ProductDetail(idiomaContext.concat(ConstantesFD.CONTEXTO_CIF_CONTRAPA),nifContrapa,"0");
			contexto[10]=new ProductDetail(idiomaContext.concat("BSO_BOTON_RECHAZAR"),"No","0");
			contexto[11]=new ProductDetail(idiomaContext.concat("MULTIIDIOMA"),"TRUE","0");
		}else if(idioma.getCodigo().equals(Constantes.IDIOMA_CATALAN)){
			contexto[12]=new ProductDetail(idiomaContext.concat(ConstantesFD.CONTEXTO_PRODUCTO_ES),getDescripcionProductoContexto(productoContexto,Constantes.IDIOMA_CATALAN_ABREVIADO),"0");
			contexto[13]=new ProductDetail(idiomaContext.concat(ConstantesFD.CONTEXTO_NCORRELA_ES),idOperacion,"0");
			contexto[14]=new ProductDetail(idiomaContext.concat(ConstantesFD.CONTEXTO_TIPO_PROCESO_ES),getDescripcionEvenconfByIdioma(co.getEvenConf(), "CA"),"0");
			contexto[15]=new ProductDetail(idiomaContext.concat(ConstantesFD.CONTEXTO_NOMINAL_ES),nominalContexto,"0");
			contexto[16]=new ProductDetail(idiomaContext.concat(ConstantesFD.CONTEXTO_FECHAVAL_ES),fechaVal,"0");
			contexto[17]=new ProductDetail(idiomaContext.concat(ConstantesFD.CONTEXTO_FECHAVEN_ES),fechaVen,"0");
			contexto[18]=new ProductDetail(idiomaContext.concat(ConstantesFD.CONTEXTO_CONFIRMACION_ES),getDescripcionProductoContexto(productoContexto,Constantes.IDIOMA_CATALAN_ABREVIADO),"0");
			contexto[19]=new ProductDetail(idiomaContext.concat(ConstantesFD.CONTEXTO_TRADEDATE_ES),tradeDate,"0");
			contexto[20]=new ProductDetail(idiomaContext.concat(ConstantesFD.CONTEXTO_NOMBRE_CONTRAPA),nomEmpresa,"0");
			contexto[21]=new ProductDetail(idiomaContext.concat(ConstantesFD.CONTEXTO_CIF_CONTRAPA),nifContrapa,"0");
			contexto[22]=new ProductDetail(idiomaContext.concat("BSO_BOTON_RECHAZAR"),"No","0");
		}else if(idioma.getCodigo().equals(Constantes.IDIOMA_INGLES)){
			contexto[23]=new ProductDetail(idiomaContext.concat(ConstantesFD.CONTEXTO_PRODUCTO_ES),getDescripcionProductoContexto(productoContexto,Constantes.IDIOMA_INGLES_ABREVIADO),"0");
			contexto[24]=new ProductDetail(idiomaContext.concat(ConstantesFD.CONTEXTO_NCORRELA_ES),idOperacion,"0");
			contexto[25]=new ProductDetail(idiomaContext.concat(ConstantesFD.CONTEXTO_TIPO_PROCESO_ES),getDescripcionEvenconfByIdioma(co.getEvenConf(), "EN"),"0");
			contexto[26]=new ProductDetail(idiomaContext.concat(ConstantesFD.CONTEXTO_NOMINAL_ES),nominalContexto,"0");
			contexto[27]=new ProductDetail(idiomaContext.concat(ConstantesFD.CONTEXTO_FECHAVAL_ES),fechaVal,"0");
			contexto[28]=new ProductDetail(idiomaContext.concat(ConstantesFD.CONTEXTO_FECHAVEN_ES),fechaVen,"0");
			contexto[29]=new ProductDetail(idiomaContext.concat(ConstantesFD.CONTEXTO_CONFIRMACION_ES),getDescripcionProductoContexto(productoContexto,Constantes.IDIOMA_INGLES_ABREVIADO),"0");
			contexto[30]=new ProductDetail(idiomaContext.concat(ConstantesFD.CONTEXTO_TRADEDATE_ES),tradeDate,"0");
			contexto[31]=new ProductDetail(idiomaContext.concat(ConstantesFD.CONTEXTO_NOMBRE_CONTRAPA),nomEmpresa,"0");
			contexto[32]=new ProductDetail(idiomaContext.concat(ConstantesFD.CONTEXTO_CIF_CONTRAPA),nifContrapa,"0");
			contexto[33]=new ProductDetail(idiomaContext.concat("BSO_BOTON_RECHAZAR"),"No","0");
			
		}
	}
	
	//aleman
	//No tenemos las descripciones en este idioma. Las mostramos en ingles
	contexto[34]=new ProductDetail("de_DE-".concat(ConstantesFD.CONTEXTO_PRODUCTO_ES),getDescripcionProductoContexto(productoContexto,Constantes.IDIOMA_INGLES_ABREVIADO),"0");
	contexto[35]=new ProductDetail("de_DE-".concat(ConstantesFD.CONTEXTO_NCORRELA_ES),idOperacion,"0");
	contexto[36]=new ProductDetail("de_DE-".concat(ConstantesFD.CONTEXTO_TIPO_PROCESO_ES),getDescripcionEvenconfByIdioma(co.getEvenConf(), "DE"),"0");
	contexto[37]=new ProductDetail("de_DE-".concat(ConstantesFD.CONTEXTO_NOMINAL_ES),nominalContexto,"0");
	contexto[38]=new ProductDetail("de_DE-".concat(ConstantesFD.CONTEXTO_FECHAVAL_ES),fechaVal,"0");
	contexto[39]=new ProductDetail("de_DE-".concat(ConstantesFD.CONTEXTO_FECHAVEN_ES),fechaVen,"0");		
	contexto[40]=new ProductDetail("de_DE-".concat(ConstantesFD.CONTEXTO_CONFIRMACION_ES),getDescripcionProductoContexto(productoContexto,Constantes.IDIOMA_INGLES_ABREVIADO),"0");
	contexto[41]=new ProductDetail("de_DE-".concat(ConstantesFD.CONTEXTO_TRADEDATE_ES),tradeDate,"0");
	contexto[42]=new ProductDetail("de_DE-".concat(ConstantesFD.CONTEXTO_NOMBRE_CONTRAPA),nomEmpresa,"0");
	contexto[43]=new ProductDetail("de_DE-".concat(ConstantesFD.CONTEXTO_CIF_CONTRAPA),nifContrapa,"0");
	contexto[44]=new ProductDetail("de_DE-".concat("BSO_BOTON_RECHAZAR"),"No","0");

	
	//portugues
	//No tenemos las descripciones en este idioma. Las mostramos en ingles
	contexto[45]=new ProductDetail("pt_PT-".concat(ConstantesFD.CONTEXTO_PRODUCTO_ES),getDescripcionProductoContexto(productoContexto,Constantes.IDIOMA_INGLES_ABREVIADO),"0");
	contexto[46]=new ProductDetail("pt_PT-".concat(ConstantesFD.CONTEXTO_NCORRELA_ES),idOperacion,"0");
	contexto[47]=new ProductDetail("pt_PT-".concat(ConstantesFD.CONTEXTO_TIPO_PROCESO_ES),getDescripcionEvenconfByIdioma(co.getEvenConf(), "PT"),"0");
	contexto[48]=new ProductDetail("pt_PT-".concat(ConstantesFD.CONTEXTO_NOMINAL_ES),nominalContexto,"0");
	contexto[49]=new ProductDetail("pt_PT-".concat(ConstantesFD.CONTEXTO_FECHAVAL_ES),fechaVal,"0");
	contexto[50]=new ProductDetail("pt_PT-".concat(ConstantesFD.CONTEXTO_FECHAVEN_ES),fechaVen,"0");
	contexto[51]=new ProductDetail("pt_PT-".concat(ConstantesFD.CONTEXTO_CONFIRMACION_ES),getDescripcionProductoContexto(productoContexto,Constantes.IDIOMA_INGLES_ABREVIADO),"0");
	contexto[52]=new ProductDetail("pt_PT-".concat(ConstantesFD.CONTEXTO_TRADEDATE_ES),tradeDate,"0");
	contexto[53]=new ProductDetail("pt_PT-".concat(ConstantesFD.CONTEXTO_NOMBRE_CONTRAPA),nomEmpresa,"0");
	contexto[54]=new ProductDetail("pt_PT-".concat(ConstantesFD.CONTEXTO_CIF_CONTRAPA),nifContrapa,"0");
	contexto[55]=new ProductDetail("pt_PT-".concat("BSO_BOTON_RECHAZAR"),"No","0");
	
	//frances
	//No tenemos las descripciones en este idioma. Las mostramos en ingles
	contexto[56]=new ProductDetail("fr_FR-".concat(ConstantesFD.CONTEXTO_PRODUCTO_ES),getDescripcionProductoContexto(productoContexto,Constantes.IDIOMA_INGLES_ABREVIADO),"0");
	contexto[57]=new ProductDetail("fr_FR-".concat(ConstantesFD.CONTEXTO_NCORRELA_ES),idOperacion,"0");
	contexto[58]=new ProductDetail("fr_FR-".concat(ConstantesFD.CONTEXTO_TIPO_PROCESO_ES),getDescripcionEvenconfByIdioma(co.getEvenConf(), "FR"),"0");
	contexto[59]=new ProductDetail("fr_FR-".concat(ConstantesFD.CONTEXTO_NOMINAL_ES),nominalContexto,"0");
	contexto[60]=new ProductDetail("fr_FR-".concat(ConstantesFD.CONTEXTO_FECHAVAL_ES),fechaVal,"0");
	contexto[61]=new ProductDetail("fr_FR-".concat(ConstantesFD.CONTEXTO_FECHAVEN_ES),fechaVen,"0");
	contexto[62]=new ProductDetail("fr_FR-".concat(ConstantesFD.CONTEXTO_CONFIRMACION_ES),getDescripcionProductoContexto(productoContexto,Constantes.IDIOMA_INGLES_ABREVIADO),"0");
	contexto[63]=new ProductDetail("fr_FR-".concat(ConstantesFD.CONTEXTO_TRADEDATE_ES),tradeDate,"0");
	contexto[64]=new ProductDetail("fr_FR-".concat(ConstantesFD.CONTEXTO_NOMBRE_CONTRAPA),nomEmpresa,"0");
	contexto[65]=new ProductDetail("fr_FR-".concat(ConstantesFD.CONTEXTO_CIF_CONTRAPA),nifContrapa,"0");
	contexto[66]=new ProductDetail("fr_FR-".concat("BSO_BOTON_RECHAZAR"),"No","0");

	    inputData.setDetail(contexto);

	    //SMM 10/01/2018 Indicador Manuscrito
	    if(co.getOperacion()!=null){
	    	
		    
		    if ( co.getOperacion().getAutoriza().getIndManuscrito()){


			    ContextCaptcha[] manuscrito = new ContextCaptcha[1];//11 etiquetas x 6 idiomas, nCorrela, tipoProceso
			    
		    	if(co.getIdioma().getCodigo().equals(Constantes.IDIOMA_INGLES)){
			    	manuscrito[0]=new ContextCaptcha("mifid",ConstantesFD.TEXTO_MANUS_EN);
			    } else if(co.getIdioma().getCodigo().equals(Constantes.IDIOMA_CATALAN)){
			    	manuscrito[0]=new ContextCaptcha("mifid",ConstantesFD.TEXTO_MANUS_CA);
			    }else {
			    	manuscrito[0]=new ContextCaptcha("mifid",ConstantesFD.TEXTO_MANUS_ES);
			    }
			    
			    inputData.setCaptchaText(manuscrito);
		    
		    }
		}else{
		    if ( opeEstr.getAutoriza().getIndManuscrito()){


			    ContextCaptcha[] manuscrito = new ContextCaptcha[1];//11 etiquetas x 6 idiomas, nCorrela, tipoProceso
			    
		    	if(co.getIdioma().getCodigo().equals(Constantes.IDIOMA_INGLES)){
			    	manuscrito[0]=new ContextCaptcha("mifid",ConstantesFD.TEXTO_MANUS_EN);
			    } else if(co.getIdioma().getCodigo().equals(Constantes.IDIOMA_CATALAN)){
			    	manuscrito[0]=new ContextCaptcha("mifid",ConstantesFD.TEXTO_MANUS_CA);
			    }else {
			    	manuscrito[0]=new ContextCaptcha("mifid",ConstantesFD.TEXTO_MANUS_ES);
			    }
			    
			    inputData.setCaptchaText(manuscrito);
		    }
		}
	    
		//1.3. llamada WS
		request.setHeaderRequest(headerRequest);
		request.setInputData(inputData);
		
		System.out.println("llamada a la clase firma centralizada");
//		String xmlText = XMLUtils.toXML(inputData);
//		System.out.println("FD Llamada =-"+xmlText+"-");
		
		firmaDigital.setSessionId(sessionId);
		if(firmaDigital.getPassword()==null){
			//set username y password
			firmaDigital.setUsername(credentials.getUsername());
			//String proxyGrantingTicket = getTicket();
			System.out.println("proxyGrantingTicket=-"+proxyGrantingTicket+"-");
			String passTicket = firmaDigital.getPassTicket(proxyGrantingTicket);
			System.out.println("passTicket=-"+passTicket+"-");
			firmaDigital.setPassword(passTicket);
		}
		try{
			System.out.println("INI firmaCentralizada.registrarFirmaDigital(request)");
			RegisterResponse response = firmaCentralizada.registrarFirmaDigital(request);
			System.out.println("FIN firmaCentralizada.registrarFirmaDigital(request)");
			//TODO tratar respuesta!!!!! 
			//Si el error devuelto es una FaultInfo
			
			System.out.println("response.getOutputData(): "+response.getOutputData());
			System.out.println("response.getOutputData().getResult(0): "+response.getOutputData().getResult(0));
			System.out.println("response.getOutputData().getResult(0).getResultCode(): "+response.getOutputData().getResult(0).getResultCode());
			
			if(null==response || null==response.getOutputData()||null==response.getOutputData().getResult(0)||null==response.getOutputData().getResult(0).getResultCode()){
				System.out.println("INI IF NULL response");
				admconfirmacionesBo.saveError("IoEx", "Error en la llamada al servicio de FD. Mirar log", co,ConstantesFD.INCID_PROGRAMA_FD);
				//actualizamos la tabla WsLogOsp
				admconfirmacionesBo.saveResultadoToLog(ConstantesFD.LOG_COD_ERROR_SIN_ACCESO_WS, ConstantesFD.LOG_DESC_ERROR_SIN_ACCESO_WS, co,ConstantesFD.LOG_IDWEBSEV_REGISTRAR,ConstantesFD.LOG_IDWEBSEV_ESTADOCO_KO);
				System.out.println("FIN IF NULL RESPONSE");
				return "admconfirmaciones.firmadigital.error.llamada.ws";
			}else{
				//Si la response tiene un cÃ³digo de error diferente de OK registramos el error en la base de datos
				System.out.println("INI ELSE NULL RESPONSE");
				if (null!=response.getOutputData() && null!=response.getOutputData().getResult(0) && null!=response.getOutputData().getResult(0).getResultCode()){
					System.out.println("INI GET coderror");
					String codError = response.getOutputData().getResult(0).getResultCode();
					System.out.println("FIN GET coderror: "+ codError + "constante_ok:" + ConstantesFD.OK_FIRMA_CENTRAL);
					if (!codError.equals(ConstantesFD.OK_FIRMA_CENTRAL)
//							&& !codError.equals(ConstantesFD.OK_CODIGO1)
//							&& !codError.equals(ConstantesFD.OK_CODIGO2)
//							&& !codError.equals(ConstantesFD.OK_CODIGO3)
							){
						System.out.println("INI coderror <> OK");
						String descripcion;
						if (null!=response.getOutputData().getResult(0).getResultDescription()){
							descripcion = response.getOutputData().getResult(0).getResultDescription();
						}else{
							descripcion = codError;
						}
						
						admconfirmacionesBo.saveError(codError, descripcion, co,ConstantesFD.INCID_PROGRAMA_FD);
						//actualizamos la tabla WsLogOsp
						System.out.println("actualizamos la tabla WsLogOsp");
						admconfirmacionesBo.saveResultadoToLog(codError, descripcion, co,ConstantesFD.LOG_IDWEBSEV_REGISTRAR,ConstantesFD.LOG_IDWEBSEV_ESTADOCO_KO);

						//Si es un error funcional lo mostramos al usuario, en caso contrario mostramos el error genÃ©rico
						if(codError.indexOf(ConstantesFD.ERROR_FUNCIONAL)!=-1 || codError.indexOf(ConstantesFD.ERROR_TECNICO)!=-1){
							
							//Si se ha producido un error al registrar la confirmaciÃ³n enviamos un evento a la agenda
							admconfirmacionesBo.insertarEvento(admconfirmacionesBo.generarEventoAgenda(co, codError.concat(" - ") + descripcion));
							//return response.getOutputData().getDescripcion() + response.getOutputData().getDescripcion();
							//SMM 21/11/2013
							System.out.println("FIN 1 coderror <> OK");
							return codError.concat(" - ") + descripcion;
						}
						else{
							System.out.println("FIN 2 coderror <> OK");
							return "admconfirmaciones.firmadigital.error.llamada.ws";
						}
					}else{
						System.out.println("INI coderror = OK");
						String descripcion;
						if (null!=response.getOutputData().getResult(0).getResultDescription()){
							descripcion = response.getOutputData().getResult(0).getResultDescription();
						}else{
							descripcion = "OK";
						}
						//La llamada ha ido bien. Actualizamos la tabla WsLogOsp
						System.out.println("FIN coderror = OK. La llamada ha ido bien. Actualizamos la tabla WsLogOsp");
						admconfirmacionesBo.saveResultadoToLog(codError, descripcion, co,ConstantesFD.LOG_IDWEBSEV_REGISTRAR,ConstantesFD.LOG_IDWEBSEV_ESTADOCO_OK);
					}
				}
			}
		}catch (FaultInfo fie){
			System.out.println("INI catch");
			String faultCode = "";
			if(fie.getFaultCode()!=null && fie.getFaultCode().getLocalPart()!=null)
				faultCode=fie.getFaultCode().getLocalPart();
			String mensaje = fie.getMessage();
			admconfirmacionesBo.saveError(faultCode, mensaje, co,ConstantesFD.INCID_PROGRAMA_FD);
			admconfirmacionesBo.saveResultadoToLog(ConstantesFD.LOG_COD_ERROR_SIN_ACCESO_WS, ConstantesFD.LOG_DESC_ERROR_SIN_ACCESO_WS, co,ConstantesFD.LOG_IDWEBSEV_REGISTRAR,ConstantesFD.LOG_IDWEBSEV_ESTADOCO_KO);
			System.out.println("FIN catch");
			return "admconfirmaciones.firmadigital.error.llamada.ws";
		}
		
		//DespuÃ©s de la llamada al web service si la sesiÃ³n que tenÃ­amos ha resultado NO vÃ¡lida 
		//tendremos una nueva
//		if(!GenericUtils.isNullOrBlank(firmaDigital) &&
//				!GenericUtils.isNullOrBlank(firmaDigital.getSessionId()) &&
//				!firmaDigital.getSessionId().equals(sessionId))
//			sessionId = firmaDigital.getSessionId();
		//SÃ³lo mostramos informaciÃ³n del servicio de firma digital en el caso de que haya habido error
		return "";
	}
	
}
	
	/**
	 * Devuelve String vacÃ­o si todo ha ido bien o el error que se haya producido en el proceso
	 * @param co
	 * @return
	 */
	private String firmaDigital(ConfOperacion co,Boolean indicadorViaSegura, Boolean checkFD){
		/*1- Tenemos que hacer la llamada?
			1.1. obtener contrapartida: la tenemos en la operaciÃ³n
			1.2. indicador mancomunada o solidaria: acceder a tabla deri.reltiapo 
									where ctitular=contrapa 1.1 and estadoco='VA'
				OJO. puede haber mÃ¡s de 1 registro. Si no hay --> FIN proceso, no tiene apoderados
				uno o mÃ¡s filas: el campo INDMASOL. 
				Si es 'S' llamada WS. Si no --> FIN proceso (de momento solo para solidaria)
			1.3. llamada WS
			 	1.3.1. OK --> actualizar INDICOSP a 'O' en la tabla deri.confiope
			 	1.3.2. KO --> mostrar display con el error devuelto por el WS
		 */
		//1.1. obtener contrapartida: la tenemos en la operaciÃ³n
		String idContrapa = "";
		if(co.getOperacion()!=null)
			idContrapa = co.getOperacion().getContrapa();
		else if(co.getEstructura()!=null){
			idContrapa = co.getEstructura().getContrapartida().getId();
		}
		log.debug("idContrapa: -"+idContrapa+"-");
		//De momento sÃ³lo para firma solidaria. indmasol='S'
		//1.2
		Contrapartida contrapa = contrapartidaBo.cargar(idContrapa);
		if(!indicadorViaSegura && !"S".equals(contrapa.getIndBsOnl())){
			//Si no estÃ¡ activo el indBsOnl no hacemos nada
			return "INDBSONL";
		}
		
		List<Apoderado> apoderados = null ;
		//Si la persona es fÃ­sica la propia contrapartida hace de apoderado
		if (!"F".equalsIgnoreCase(contrapa.getTipoPersona())){
		
			apoderados = admconfirmacionesBo.apoderadosDeContrapa(contrapa.getId(), ConstantesFD.IND_MASOL_SOLIDARIA, contrapa.getTipoPersona());
			log.debug("nÃºmero de apoderados de la contrapa: -"+apoderados.size()+"-");
		
		}
		if(!"F".equalsIgnoreCase(contrapa.getTipoPersona()) && apoderados.size()==0){
			return "admconfirmaciones.firmadigital.no.existen.firmantes";
			//"No existen firmantes vÃ¡lidos para el tipo de firma requerido.";//fin del proceso
		}else{
			//obtenemos o validamos el identificador de la sesiÃ³n
			System.out.println("sessionId: "+sessionId);
			if(sessionId==null|| sessionId.equals("")){
				//login en el webservice con el usuario de sesiÃ³n de DERI
				com.bs.proteo.soa.service.mainframe.UserLogin.domain.InputData inputData = new com.bs.proteo.soa.service.mainframe.UserLogin.domain.InputData();
				//setusername y password
				firmaDigital.setUsername(credentials.getUsername());
				System.out.println("username: "+credentials.getUsername());
				//String proxyGrantingTicket = getTicket();
				System.out.println("proxyGrantingTicket=-"+proxyGrantingTicket+"-");
				String passTicket = firmaDigital.getPassTicket(proxyGrantingTicket);
				System.out.println("passTicket=-"+passTicket+"-");
				firmaDigital.setPassword(passTicket);
				String sessionValida = firmaDigital.login(co.getIdioma().obteCodigoI18n(),"");
				if(sessionValida.equals("-1")||	sessionValida.equals("-2")){
					return "admconfirmaciones.firmadigital.sesion.invalida";//SesiÃ³n de servicio invÃ¡lida"
				}else{
					sessionId = sessionValida;
					//Contexts.getSessionContext().set("sessionId", sessionId);  
				}
			}
			//llamada al webservice de firma digital
			SimpleDateFormat sdf = new SimpleDateFormat(Constantes.DDMMYYYY);
			RegistrarCasoFirmaRequest request = new RegistrarCasoFirmaRequest();
			//headerRq: aplicacion, language
			HeaderRequest headerRequest = new HeaderRequest();
			HeaderRequestHostRequest hostRequest = new HeaderRequestHostRequest();
			hostRequest.setSessionId(sessionId);
			headerRequest.setHostRequest(hostRequest);
			headerRequest.setApplicationId(ConstantesFD.APLICACION_FIRMA);
			headerRequest.setLanguage(co.getIdioma().obteCodigoI18n());
			headerRequest.setStep(ConstantesFD.FD_STEP);
		    headerRequest.setTrackingId(ConstantesFD.FD_TRACKING_ID_FD);//+new Random());
			request.setHeaderRequest(headerRequest);
			
			/* codigos[0] = codDocumento;
			   codigos[1] = codExpediente;*/
			String[] codigosExpedienteDocumento=admconfirmacionesBo.calcularCodDocumentoCodExpediente(co);
	
			//input data: idOperacion, codUsuario, idioma, idDocumento, titularContrato,firmante/s,tipoFirma
			//Contexto: importe, divisa, tradeDate, fechaVen
			RegistrarCasoFirmaRequestData inputData = new RegistrarCasoFirmaRequestData();
			inputData.setTipoOperacion(ConstantesFD.OPERACION_CONFIRMACIONTS);
			//ncorrela o estructu segÃºn sea una operaciÃ³n o una estructura
			String idOperacion = co.getOperacionID()!=null?co.getOperacionID().toString():new Long(co.getEstructura().getEstructu()).toString(); 
			String operacion=idOperacion+"|"+co.getEvenConf()+"|"+co.getNumConfirmacion();
			//String operacion = codigosExpedienteDocumento[1];
			System.out.println("idOperacion: "+operacion);
			inputData.setIdOperacion(operacion);
			inputData.setCodAplicacion(ConstantesFD.APLICACION_DERITD);
			inputData.setCodUsuario(co.getAuditData().getUsuarioUltimaModi());
			inputData.setIdioma(co.getIdioma().obteCodigoI18n());
			inputData.setIdRepositorio(ConstantesFD.REPOSITORIO_DMS);
			inputData.setCanalEntrada(ConstantesFD.CANALENTRADA_DERI);
			
			//Producto: productgr de la operacion. Pasamos al WS la descripciÃ³n del productoTgr
			ProductoTgr productoTgr=null;
			if(co.getOperacion()!=null){
				if(co.getOperacion().getProductoTgr()!=null){
					productoTgr = admconfirmacionesBo.obtenerProductoTgr(co.getOperacion().getProductoCatalogo(), co.getOperacion().getProductoTgr());
					inputData.setIdProducto(productoTgr.getDescripcionProductoTgr());
				}
			}else{
				//nos quedamos con la primera operacion
				Operacion opeEstr = co.getEstructura().getOperacions().iterator().next();
				productoTgr = admconfirmacionesBo.obtenerProductoTgr(opeEstr.getProductoCatalogo(), opeEstr.getProductoTgr());
				inputData.setIdProducto(productoTgr.getDescripcionProductoTgr());
			}

			//SMM 01/12/2014			
			inputData.setCodigoEntidad("01");
			
			//SMM Descripcion 16/10/2015
			if (Constantes.IDIOMA_CATALAN.equals(co.getIdioma().getCodigo())){
				inputData.setDescripcion(ConstantesFD.DESCRIP_FD_CATALAN);
			}else if (Constantes.IDIOMA_INGLES.equals(co.getIdioma().getCodigo())){
				inputData.setDescripcion(ConstantesFD.DESCRIP_FD_INGLES);
			}else{
				inputData.setDescripcion(ConstantesFD.DESCRIP_FD_CASTELLANO);
			}
					
			//SMM 20/01/2016 Cambio WS Caducidad
			String caducidad;
			GregorianCalendar fechaCad= new GregorianCalendar();
			fechaCad.setTime(new Date());
			fechaCad.add(Calendar.YEAR, 15);
			Date datCaducitat = admconfirmacionesBo.ajustarFecha(fechaCad.getTime(),"F",admconfirmacionesBo.obtenerDivisa(Constantes.DIVISA_EUR));
			fechaCad.setTime(datCaducitat);
//			SimpleDateFormat sdfCad = new SimpleDateFormat(Constantes.YYYYMMDD10);
//			caducidad = sdfCad.format(datCaducitat);
//			//            <dom:caducidad>2015-11-30T15:30:00</dom:caducidad>
//			caducidad = caducidad.concat("T15:00:00");
//			
			inputData.setCaducidad(fechaCad);
//			System.out.println(caducidad);
			
			
			
			//CodDocumento|TipoDocumento|CodExpediente|TipoExpediente
			//String idDocumento = idOperacion+"|"+Constantes.TIPO_DOCUMENTO+"|"+co.getNumConfirmacion()+"|"+Constantes.TIPO_EXPEDIENTE;
			
			/*
				codigoDocumento: â€œ220112000002|M|000000617553â€
				tipoDocumento: â€œConfirmacionesTSâ€
				codigoExpediente: â€œ01|DD |000009370009556â€
				tipoExpdiente: â€œContratoDDâ€
			 */
			//220112000002|M|000000617553][ ConfirmacionesTS][01|DD |000009370009556][ContratoDD]
			String idDocumento = "["+codigosExpedienteDocumento[0] + "][" + Constantes.TIPO_DOCUMENTO + "]["+codigosExpedienteDocumento[1]+"]["+Constantes.TIPO_EXPEDIENTE+"]";
			inputData.setIdDocumento(idDocumento);

			Contrapartida contrapartida = this.contrapartidaBo.cargar(idContrapa);
			BigInteger titularContrato=null;

			if(contrapartida!=null)
				titularContrato = new BigInteger(contrapartida.getNumeroPersona().toString());
			//inputData.setTitularContrato((BigInteger)titularContrato);

			DocsContrapartida docCMOF= admconfirmacionesBo.obtenerDocucont(co, Constantes.DOCUCONT_CMOF);
			inputData.setIdContrato(formatearIdContrato(docCMOF));

			
//			Sâ€™ha dâ€™informar el numpersona de lâ€™empresa (en el cas dâ€™autoritzats) 
// 			en el camp titularContrato, en el cas de particulars aquest camp va a 0.

			
			String[] canalfirma;
			if(!checkFD){
				canalfirma = new String[1];
				canalfirma[0]=ConstantesFD.PRESENCIAL;	
				inputData.setCanalFirma(canalfirma);
			}
				//SMM 20/01/2016 Cambio WS Firmantes
			
			//numperso   Numero de persona de los apoderados numÃ©rico de 10 (occurs)
			String indicadorTipofirma=null;
			RegistrarCasoFirmaRequestDataIdFirmante[] firmantes;
			String tipoPersonaFisica= "F";
			if(contrapa.getTipoPersona().equals(tipoPersonaFisica)){
				firmantes = new RegistrarCasoFirmaRequestDataIdFirmante[1];
				firmantes[0]=new RegistrarCasoFirmaRequestDataIdFirmante( titularContrato);	
				inputData.setTitularContrato(BigInteger.ZERO);
			}else{
				inputData.setTitularContrato((BigInteger)titularContrato);
				firmantes = new RegistrarCasoFirmaRequestDataIdFirmante[apoderados.size()];
				
				if ("S".equalsIgnoreCase((apoderados.get(0)).getIndMasol())){
					indicadorTipofirma =ConstantesFD.PARAM_IND_MASOL_INDISTINTA; 
				}else{
					indicadorTipofirma =ConstantesFD.PARAM_IND_MASOL_CONJUNTA;
				}
				
				for(int i=0;i<apoderados.size();i++){
					Integer firmantei=(apoderados.get(i)).getCapoderado().getNumPerso();
					if(firmantei!=null){
						firmantes[i]=new RegistrarCasoFirmaRequestDataIdFirmante(firmantei.toString());
					}
				}
			}
			//SMM 20/01/2016 Cambio WS Firmantes
			inputData.setIdFirmante(firmantes);
			/* individual / indistinta / conjunta (no para 1Âª fase) 
			En nuestro caso Indmasol   
			indistinta
			individual
			RELTIAPO
			blanc NOOOOO
			S
			M

			<> Blanc

			1 individual
			>1 S indistinta
			>1 M conjunta
			 */
			if(firmantes.length>1)
				//inputData.setTipoFirma(ConstantesFD.PARAM_IND_MASOL_INDISTINTA);
				inputData.setTipoFirma(indicadorTipofirma);
			else
				inputData.setTipoFirma(ConstantesFD.PARAM_IND_MASOL_INDIVIDUAL);
			
			Contexto[] contexto = new Contexto[67];//11 etiquetas x 6 idiomas, nCorrela, tipoProceso
			BigDecimal importe;
			String divisa = "";
			
			if(co.getOperacion()!=null){
				//SMM 03/12/2015
//				if (co.getOperacion().getProductoCatalogo()== 1751417 || co.getOperacion().getProductoCatalogo()== 1751416){
				if (!GenericUtils.isNullOrBlank(co.getVista()) &&
					!GenericUtils.isNullOrBlank(co.getVista().getProductoCatalogo()) &&
					!GenericUtils.isNullOrBlank(co.getVista().getProductoCatalogo().getProdtrat()) &&
					!GenericUtils.isNullOrBlank(co.getVista().getProductoCatalogo().getProdtrat().getTratge02()) &&
					"S".equalsIgnoreCase(co.getVista().getProductoCatalogo().getProdtrat().getTratge02())){
					importe =
						co.getOperacion().getDivisaPago()==null?
								co.getOperacion().getNominalRecibo().multiply(co.getOperacion().getStrikeRecibo()):
									co.getOperacion().getNominalPago().multiply(co.getOperacion().getStrikePago());
					 
				}else{
					importe =co.getOperacion().getDivisaPago()==null?co.getOperacion().getNominalRecibo():co.getOperacion().getNominalPago();	
				}

				divisa = co.getOperacion().getDivisaPago()==null?co.getOperacion().getDivisaRecibo():co.getOperacion().getDivisaPago(); 
			}
			else{
				//nos quedamos con la primera operacion
				Operacion opeEstr = co.getEstructura().getOperacions().iterator().next();

//				if (opeEstr.getProductoCatalogo()== 1751417 || opeEstr.getProductoCatalogo()== 1751416){
				if (!GenericUtils.isNullOrBlank(co.getVista()) &&
					!GenericUtils.isNullOrBlank(co.getVista().getProductoCatalogo()) &&
					!GenericUtils.isNullOrBlank(co.getVista().getProductoCatalogo().getProdtrat()) &&
					!GenericUtils.isNullOrBlank(co.getVista().getProductoCatalogo().getProdtrat().getTratge02()) &&
					"S".equalsIgnoreCase(co.getVista().getProductoCatalogo().getProdtrat().getTratge02())){					
				
					importe =opeEstr.getDivisaPago()==null?opeEstr.getNominalRecibo().multiply(opeEstr.getStrikeRecibo()):opeEstr.getNominalPago().multiply(opeEstr.getStrikePago());
					 
				}else{
				
					importe =opeEstr.getDivisaPago()==null?opeEstr.getNominalRecibo():opeEstr.getNominalPago();
				
				}
				
				divisa = opeEstr.getDivisaPago()==null?opeEstr.getDivisaRecibo():opeEstr.getDivisaPago();
			}
			
			//SMM 21/11/2013
			String tradeDate="";
			if(co.getOperacion()!=null)
				tradeDate = sdf.format(co.getOperacion().getId().getFechaContratacion());
			else
				tradeDate = sdf.format(co.getEstructura().getFechaContratacion());

			String fechaVen="";
			if(co.getOperacion()!=null)
				fechaVen = sdf.format(co.getOperacion().getFechaVencimiento());
			else
				fechaVen = sdf.format(co.getEstructura().getFechaVencimiento());
			
			//ncorrela
			//tipoProceso
			
			//producto contexto
			String productoContexto = "";
			if(co.getOperacion()!=null)
				productoContexto=co.getOperacion().getProducto();
			else
				productoContexto=co.getEstructura().getProducto().getId();

			
			String nomEmpresa="";
			nomEmpresa = contrapa.getDescLarga();
			String nifContrapa ="";
			nifContrapa =contrapa.getId();
		
			//SUP 27/07/2015
			String fechaVal="";
			if(co.getOperacion()!=null)
				fechaVal = sdf.format(co.getOperacion().getFechaValor());
			else
				fechaVal = sdf.format(co.getEstructura().getFechaValor());
			
			
			String nominalContexto ="";
			nominalContexto = new DecimalFormat("###,##0.00").format(importe).concat(" ").concat(divisa);
			
			System.out.println(nominalContexto);
			
			List<Idioma> idiomas = admconfirmacionesBo.generarListaIdiomas();
			for(Idioma idioma: idiomas){
				
				String idiomaContext = idioma.obteCodigoI18n().concat("-");
				
			
				
				if(idioma.getCodigo().equals(Constantes.IDIOMA_CASTELLANO)){
					contexto[0]=new Contexto(idiomaContext.concat(ConstantesFD.CONTEXTO_PRODUCTO_ES),getDescripcionProductoContexto(productoContexto,Constantes.IDIOMA_CASTELLANO_ABREVIADO));
					contexto[1]=new Contexto(idiomaContext.concat(ConstantesFD.CONTEXTO_NCORRELA_ES),idOperacion);
					contexto[2]=new Contexto(idiomaContext.concat(ConstantesFD.CONTEXTO_TIPO_PROCESO_ES),getDescripcionEvenconfByIdioma(co.getEvenConf(), "ES"));
//					contexto[2]=new Contexto(idiomaContext.concat(ConstantesFD.CONTEXTO_IMPORTE_ES),importe.toString());
//					contexto[3]=new Contexto(idiomaContext.concat(ConstantesFD.CONTEXTO_DIVISA_ES),divisa);
//					contexto[2]=new Contexto(idiomaContext.concat(ConstantesFD.CONTEXTO_NOMINAL_ES),importe.toString().concat(" ").concat(divisa));
					contexto[3]=new Contexto(idiomaContext.concat(ConstantesFD.CONTEXTO_NOMINAL_ES),nominalContexto);
					contexto[4]=new Contexto(idiomaContext.concat(ConstantesFD.CONTEXTO_FECHAVAL_ES),fechaVal);
					contexto[5]=new Contexto(idiomaContext.concat(ConstantesFD.CONTEXTO_FECHAVEN_ES),fechaVen);
//					contexto[6]=new Contexto(idiomaContext.concat(ConstantesFD.CONTEXTO_CONFIRMACION_ES),co.getNumConfirmacion().toString());
					contexto[6]=new Contexto(idiomaContext.concat(ConstantesFD.CONTEXTO_CONFIRMACION_ES),getDescripcionProductoContexto(productoContexto,Constantes.IDIOMA_CASTELLANO_ABREVIADO));
					contexto[7]=new Contexto(idiomaContext.concat(ConstantesFD.CONTEXTO_TRADEDATE_ES),tradeDate);
					contexto[8]=new Contexto(idiomaContext.concat(ConstantesFD.CONTEXTO_NOMBRE_CONTRAPA),nomEmpresa);
					contexto[9]=new Contexto(idiomaContext.concat(ConstantesFD.CONTEXTO_CIF_CONTRAPA),nifContrapa);
					contexto[10]=new Contexto(idiomaContext.concat("BSO_BOTON_RECHAZAR"),"No");
					contexto[11]=new Contexto(idiomaContext.concat("MULTIIDIOMA"),"TRUE");
				}else if(idioma.getCodigo().equals(Constantes.IDIOMA_CATALAN)){
					contexto[12]=new Contexto(idiomaContext.concat(ConstantesFD.CONTEXTO_PRODUCTO_ES),getDescripcionProductoContexto(productoContexto,Constantes.IDIOMA_CATALAN_ABREVIADO));
					contexto[13]=new Contexto(idiomaContext.concat(ConstantesFD.CONTEXTO_NCORRELA_ES),idOperacion);
					contexto[14]=new Contexto(idiomaContext.concat(ConstantesFD.CONTEXTO_TIPO_PROCESO_ES),getDescripcionEvenconfByIdioma(co.getEvenConf(), "CA"));
//					contexto[13]=new Contexto(idiomaContext.concat(ConstantesFD.CONTEXTO_IMPORTE_ES),importe.toString());
//					contexto[14]=new Contexto(idiomaContext.concat(ConstantesFD.CONTEXTO_DIVISA_ES),divisa);
					contexto[15]=new Contexto(idiomaContext.concat(ConstantesFD.CONTEXTO_NOMINAL_ES),nominalContexto);
					contexto[16]=new Contexto(idiomaContext.concat(ConstantesFD.CONTEXTO_FECHAVAL_ES),fechaVal);
					contexto[17]=new Contexto(idiomaContext.concat(ConstantesFD.CONTEXTO_FECHAVEN_ES),fechaVen);
//					contexto[18]=new Contexto(idiomaContext.concat(ConstantesFD.CONTEXTO_CONFIRMACION_ES),co.getNumConfirmacion().toString());
					contexto[18]=new Contexto(idiomaContext.concat(ConstantesFD.CONTEXTO_CONFIRMACION_ES),getDescripcionProductoContexto(productoContexto,Constantes.IDIOMA_CATALAN_ABREVIADO));
					contexto[19]=new Contexto(idiomaContext.concat(ConstantesFD.CONTEXTO_TRADEDATE_ES),tradeDate);
					contexto[20]=new Contexto(idiomaContext.concat(ConstantesFD.CONTEXTO_NOMBRE_CONTRAPA),nomEmpresa);
					contexto[21]=new Contexto(idiomaContext.concat(ConstantesFD.CONTEXTO_CIF_CONTRAPA),nifContrapa);
					contexto[22]=new Contexto(idiomaContext.concat("BSO_BOTON_RECHAZAR"),"No");
				}else if(idioma.getCodigo().equals(Constantes.IDIOMA_INGLES)){
					contexto[23]=new Contexto(idiomaContext.concat(ConstantesFD.CONTEXTO_PRODUCTO_ES),getDescripcionProductoContexto(productoContexto,Constantes.IDIOMA_INGLES_ABREVIADO));
					contexto[24]=new Contexto(idiomaContext.concat(ConstantesFD.CONTEXTO_NCORRELA_ES),idOperacion);
					contexto[25]=new Contexto(idiomaContext.concat(ConstantesFD.CONTEXTO_TIPO_PROCESO_ES),getDescripcionEvenconfByIdioma(co.getEvenConf(), "EN"));
//					contexto[24]=new Contexto(idiomaContext.concat(ConstantesFD.CONTEXTO_IMPORTE_ES),importe.toString());
//					contexto[25]=new Contexto(idiomaContext.concat(ConstantesFD.CONTEXTO_DIVISA_ES),divisa);
					contexto[26]=new Contexto(idiomaContext.concat(ConstantesFD.CONTEXTO_NOMINAL_ES),nominalContexto);
					contexto[27]=new Contexto(idiomaContext.concat(ConstantesFD.CONTEXTO_FECHAVAL_ES),fechaVal);
					contexto[28]=new Contexto(idiomaContext.concat(ConstantesFD.CONTEXTO_FECHAVEN_ES),fechaVen);
//					contexto[29]=new Contexto(idiomaContext.concat(ConstantesFD.CONTEXTO_CONFIRMACION_ES),co.getNumConfirmacion().toString());
					contexto[29]=new Contexto(idiomaContext.concat(ConstantesFD.CONTEXTO_CONFIRMACION_ES),getDescripcionProductoContexto(productoContexto,Constantes.IDIOMA_INGLES_ABREVIADO));
					contexto[30]=new Contexto(idiomaContext.concat(ConstantesFD.CONTEXTO_TRADEDATE_ES),tradeDate);
					contexto[31]=new Contexto(idiomaContext.concat(ConstantesFD.CONTEXTO_NOMBRE_CONTRAPA),nomEmpresa);
					contexto[32]=new Contexto(idiomaContext.concat(ConstantesFD.CONTEXTO_CIF_CONTRAPA),nifContrapa);
					contexto[33]=new Contexto(idiomaContext.concat("BSO_BOTON_RECHAZAR"),"No");
					
				}
			}
			
			//aleman
			//No tenemos las descripciones en este idioma. Las mostramos en ingles
			contexto[34]=new Contexto("de_DE-".concat(ConstantesFD.CONTEXTO_PRODUCTO_ES),getDescripcionProductoContexto(productoContexto,Constantes.IDIOMA_INGLES_ABREVIADO));
			contexto[35]=new Contexto("de_DE-".concat(ConstantesFD.CONTEXTO_NCORRELA_ES),idOperacion);
			contexto[36]=new Contexto("de_DE-".concat(ConstantesFD.CONTEXTO_TIPO_PROCESO_ES),getDescripcionEvenconfByIdioma(co.getEvenConf(), "DE"));
//			contexto[35]=new Contexto("de_DE-".concat(ConstantesFD.CONTEXTO_IMPORTE_ES),importe.toString());
//			contexto[36]=new Contexto("de_DE-".concat(ConstantesFD.CONTEXTO_DIVISA_ES),divisa);
			contexto[37]=new Contexto("de_DE-".concat(ConstantesFD.CONTEXTO_NOMINAL_ES),nominalContexto);
			contexto[38]=new Contexto("de_DE-".concat(ConstantesFD.CONTEXTO_FECHAVAL_ES),fechaVal);
			contexto[39]=new Contexto("de_DE-".concat(ConstantesFD.CONTEXTO_FECHAVEN_ES),fechaVen);			
//			contexto[40]=new Contexto("de_DE-".concat(ConstantesFD.CONTEXTO_CONFIRMACION_ES),co.getNumConfirmacion().toString());
			contexto[40]=new Contexto("de_DE-".concat(ConstantesFD.CONTEXTO_CONFIRMACION_ES),getDescripcionProductoContexto(productoContexto,Constantes.IDIOMA_INGLES_ABREVIADO));
			contexto[41]=new Contexto("de_DE-".concat(ConstantesFD.CONTEXTO_TRADEDATE_ES),tradeDate);
			contexto[42]=new Contexto("de_DE-".concat(ConstantesFD.CONTEXTO_NOMBRE_CONTRAPA),nomEmpresa);
			contexto[43]=new Contexto("de_DE-".concat(ConstantesFD.CONTEXTO_CIF_CONTRAPA),nifContrapa);
			contexto[44]=new Contexto("de_DE-".concat("BSO_BOTON_RECHAZAR"),"No");

			
			//portugues
			//No tenemos las descripciones en este idioma. Las mostramos en ingles
			contexto[45]=new Contexto("pt_PT-".concat(ConstantesFD.CONTEXTO_PRODUCTO_ES),getDescripcionProductoContexto(productoContexto,Constantes.IDIOMA_INGLES_ABREVIADO));
			contexto[46]=new Contexto("pt_PT-".concat(ConstantesFD.CONTEXTO_NCORRELA_ES),idOperacion);
			contexto[47]=new Contexto("pt_PT-".concat(ConstantesFD.CONTEXTO_TIPO_PROCESO_ES),getDescripcionEvenconfByIdioma(co.getEvenConf(), "PT"));
//			contexto[46]=new Contexto("pt_PT-".concat(ConstantesFD.CONTEXTO_IMPORTE_ES),importe.toString());
//			contexto[47]=new Contexto("pt_PT-".concat(ConstantesFD.CONTEXTO_DIVISA_ES),divisa);
			contexto[48]=new Contexto("pt_PT-".concat(ConstantesFD.CONTEXTO_NOMINAL_ES),nominalContexto);
			contexto[49]=new Contexto("pt_PT-".concat(ConstantesFD.CONTEXTO_FECHAVAL_ES),fechaVal);
			contexto[50]=new Contexto("pt_PT-".concat(ConstantesFD.CONTEXTO_FECHAVEN_ES),fechaVen);
//			contexto[51]=new Contexto("pt_PT-".concat(ConstantesFD.CONTEXTO_CONFIRMACION_ES),co.getNumConfirmacion().toString());
			contexto[51]=new Contexto("pt_PT-".concat(ConstantesFD.CONTEXTO_CONFIRMACION_ES),getDescripcionProductoContexto(productoContexto,Constantes.IDIOMA_INGLES_ABREVIADO));
			contexto[52]=new Contexto("pt_PT-".concat(ConstantesFD.CONTEXTO_TRADEDATE_ES),tradeDate);
			contexto[53]=new Contexto("pt_PT-".concat(ConstantesFD.CONTEXTO_NOMBRE_CONTRAPA),nomEmpresa);
			contexto[54]=new Contexto("pt_PT-".concat(ConstantesFD.CONTEXTO_CIF_CONTRAPA),nifContrapa);
			contexto[55]=new Contexto("pt_PT-".concat("BSO_BOTON_RECHAZAR"),"No");
			
			//frances
			//No tenemos las descripciones en este idioma. Las mostramos en ingles
			contexto[56]=new Contexto("fr_FR-".concat(ConstantesFD.CONTEXTO_PRODUCTO_ES),getDescripcionProductoContexto(productoContexto,Constantes.IDIOMA_INGLES_ABREVIADO));
			contexto[57]=new Contexto("fr_FR-".concat(ConstantesFD.CONTEXTO_NCORRELA_ES),idOperacion);
			contexto[58]=new Contexto("fr_FR-".concat(ConstantesFD.CONTEXTO_TIPO_PROCESO_ES),getDescripcionEvenconfByIdioma(co.getEvenConf(), "FR"));
//			contexto[57]=new Contexto("fr_FR-".concat(ConstantesFD.CONTEXTO_IMPORTE_ES),importe.toString());
//			contexto[58]=new Contexto("fr_FR-".concat(ConstantesFD.CONTEXTO_DIVISA_ES),divisa);
			contexto[59]=new Contexto("fr_FR-".concat(ConstantesFD.CONTEXTO_NOMINAL_ES),nominalContexto);
			contexto[60]=new Contexto("fr_FR-".concat(ConstantesFD.CONTEXTO_FECHAVAL_ES),fechaVal);
			contexto[61]=new Contexto("fr_FR-".concat(ConstantesFD.CONTEXTO_FECHAVEN_ES),fechaVen);
//			contexto[62]=new Contexto("fr_FR-".concat(ConstantesFD.CONTEXTO_CONFIRMACION_ES),co.getNumConfirmacion().toString());
			contexto[62]=new Contexto("fr_FR-".concat(ConstantesFD.CONTEXTO_CONFIRMACION_ES),getDescripcionProductoContexto(productoContexto,Constantes.IDIOMA_INGLES_ABREVIADO));
			contexto[63]=new Contexto("fr_FR-".concat(ConstantesFD.CONTEXTO_TRADEDATE_ES),tradeDate);
			contexto[64]=new Contexto("fr_FR-".concat(ConstantesFD.CONTEXTO_NOMBRE_CONTRAPA),nomEmpresa);
			contexto[65]=new Contexto("fr_FR-".concat(ConstantesFD.CONTEXTO_CIF_CONTRAPA),nifContrapa);
			contexto[66]=new Contexto("fr_FR-".concat("BSO_BOTON_RECHAZAR"),"No");

//			//aleman
//			contexto[33]=new Contexto("de_DE-".concat("BSO_1_TEXT_Transaktionsreferenz"),idOperacion);
//			contexto[34]=new Contexto("de_DE-".concat("BSO_1_TEXT_Art des Betriebs"),getDescripcionEvenconfByIdioma(co.getEvenConf(), "DE"));
//			contexto[35]=new Contexto("de_DE-".concat("BSO_1_AMNT_Betrag"),importe.toString());
//			contexto[36]=new Contexto("de_DE-".concat("BSO_1_TEXT_WAHRUNG"),divisa);
//			contexto[37]=new Contexto("de_DE-".concat("BSO_2_DATE_Operationstermin"),tradeDate);
//			contexto[38]=new Contexto("de_DE-".concat("BSO_1_DATE_Verfallsdatum"),fechaVen);
//			//No tenemos las descripciones en este idioma. Las mostramos en ingles
//			contexto[39]=new Contexto("de_DE-".concat("BSO_1_TEXT_Produkt"),getDescripcionProductoContexto(productoContexto,Constantes.IDIOMA_INGLES_ABREVIADO));
//			contexto[40]=new Contexto("de_DE-".concat(ConstantesFD.CONTEXTO_NOMBRE_CONTRAPA),nomEmpresa);
//			contexto[41]=new Contexto("de_DE-".concat(ConstantesFD.CONTEXTO_CIF_CONTRAPA),nifContrapa);
//			contexto[42]=new Contexto("de_DE-".concat("BSO_1_DATE_Wertstellung"),fechaVal);
//			contexto[43]=new Contexto("de_DE-".concat("BSO_BOTON_RECHAZAR"),"No");
//
//			
//			//portugues
//			contexto[44]=new Contexto("pt_PT-".concat("BSO_1_TEXT_TransaÃ§Ã£o ReferÃªncia"),idOperacion);
//			contexto[45]=new Contexto("pt_PT-".concat("BSO_1_TEXT_tipo de OperaÃ§Ã£o"),getDescripcionEvenconfByIdioma(co.getEvenConf(), "PT"));
//			contexto[46]=new Contexto("pt_PT-".concat("BSO_1_AMNT_Valor"),importe.toString());
//			contexto[47]=new Contexto("pt_PT-".concat("BSO_1_TEXT_Moeda"),divisa);
//			contexto[48]=new Contexto("pt_PT-".concat("BSO_2_DATE_Data da operaÃ§Ã£o"),tradeDate);
//			contexto[49]=new Contexto("pt_PT-".concat("BSO_1_DATE_Data de validade"),fechaVen);
//			//No tenemos las descripciones en este idioma. Las mostramos en ingles
//			contexto[50]=new Contexto("pt_PT-".concat("BSO_1_TEXT_Producto"),getDescripcionProductoContexto(productoContexto,Constantes.IDIOMA_INGLES_ABREVIADO));
//			contexto[51]=new Contexto("pt_PT-".concat(ConstantesFD.CONTEXTO_NOMBRE_CONTRAPA),nomEmpresa);
//			contexto[52]=new Contexto("pt_PT-".concat(ConstantesFD.CONTEXTO_CIF_CONTRAPA),nifContrapa);
//			contexto[53]=new Contexto("pt_PT-".concat("BSO_1_DATE_Data de validade"),fechaVal);
//			contexto[54]=new Contexto("pt_PT-".concat("BSO_BOTON_RECHAZAR"),"No");
//			
//			//frances
//			contexto[55]=new Contexto("fr_FR-".concat("BSO_1_TEXT_Transaction de rÃ©fÃ©rence"),idOperacion);
//			contexto[56]=new Contexto("fr_FR-".concat("BSO_1_TEXT_Type d'opÃ©ration"),getDescripcionEvenconfByIdioma(co.getEvenConf(), "FR"));
//			contexto[57]=new Contexto("fr_FR-".concat("BSO_1_AMNT_Montant"),importe.toString());
//			contexto[58]=new Contexto("fr_FR-".concat("BSO_1_TEXT_Devise"),divisa);
//			contexto[59]=new Contexto("fr_FR-".concat("BSO_2_DATE_Date de l'opÃ©ration"),tradeDate);
//			contexto[60]=new Contexto("fr_FR-".concat("BSO_1_DATE_Date d'expiration"),fechaVen);
//			//No tenemos las descripciones en este idioma. Las mostramos en ingles
//			contexto[61]=new Contexto("fr_FR-".concat("BSO_1_TEXT_Produit"),getDescripcionProductoContexto(productoContexto,Constantes.IDIOMA_INGLES_ABREVIADO));
//			contexto[62]=new Contexto("fr_FR-".concat(ConstantesFD.CONTEXTO_NOMBRE_CONTRAPA),nomEmpresa);
//			contexto[63]=new Contexto("fr_FR-".concat(ConstantesFD.CONTEXTO_CIF_CONTRAPA),nifContrapa);
//			contexto[64]=new Contexto("fr_FR-".concat("BSO_1_DATE_Date de valeur"),fechaVal);
//			contexto[65]=new Contexto("fr_FR-".concat("BSO_BOTON_RECHAZAR"),"No");

			inputData.setContexto(contexto);
			
			//1.3. llamada WS
			request.setHeaderRequest(headerRequest);
			request.setInputData(inputData);
			
			System.out.println("llamada a la clase firma digital");
//			String xmlText = XMLUtils.toXML(inputData);
//			System.out.println("FD Llamada =-"+xmlText+"-");
			
			firmaDigital.setSessionId(sessionId);
			if(firmaDigital.getPassword()==null){
				//set username y password
				firmaDigital.setUsername(credentials.getUsername());
				//String proxyGrantingTicket = getTicket();
				System.out.println("proxyGrantingTicket=-"+proxyGrantingTicket+"-");
				String passTicket = firmaDigital.getPassTicket(proxyGrantingTicket);
				System.out.println("passTicket=-"+passTicket+"-");
				firmaDigital.setPassword(passTicket);
			}
			try{
				RegistrarCasoFirmaResponse response = firmaDigital.registrarFirmaDigital(request);

				//TODO tratar respuesta!!!!! 
				//Si el error devuelto es una FaultInfo
				if(null==response || null==response.getOutputData()||null==response.getOutputData().getCodigo()){
					admconfirmacionesBo.saveError("IoEx", "Error en la llamada al servicio de FD. Mirar log", co,ConstantesFD.INCID_PROGRAMA_FD);
					//actualizamos la tabla WsLogOsp
					admconfirmacionesBo.saveResultadoToLog(ConstantesFD.LOG_COD_ERROR_SIN_ACCESO_WS, ConstantesFD.LOG_DESC_ERROR_SIN_ACCESO_WS, co,ConstantesFD.LOG_IDWEBSEV_REGISTRAR,ConstantesFD.LOG_IDWEBSEV_ESTADOCO_KO);
					return "admconfirmaciones.firmadigital.error.llamada.ws";
				}else{
					//Si la response tiene un cÃ³digo de error diferente de OK registramos el error en la base de datos
					if (null!=response.getOutputData() && null!=response.getOutputData().getCodigo()){
						String codError = response.getOutputData().getCodigo();
						if (!codError.equals(ConstantesFD.OK_CODIGO)
//								&& !codError.equals(ConstantesFD.OK_CODIGO1)
//								&& !codError.equals(ConstantesFD.OK_CODIGO2)
//								&& !codError.equals(ConstantesFD.OK_CODIGO3)
								){
							
							String descripcion = response.getOutputData().getDescripcion();
							admconfirmacionesBo.saveError(response.getOutputData().getCodigo(), descripcion, co,ConstantesFD.INCID_PROGRAMA_FD);
							//actualizamos la tabla WsLogOsp
							admconfirmacionesBo.saveResultadoToLog(codError, descripcion, co,ConstantesFD.LOG_IDWEBSEV_REGISTRAR,ConstantesFD.LOG_IDWEBSEV_ESTADOCO_KO);

							//Si es un error funcional lo mostramos al usuario, en caso contrario mostramos el error genÃ©rico
							if(codError.indexOf(ConstantesFD.ERROR_FUNCIONAL)!=-1 || codError.indexOf(ConstantesFD.ERROR_TECNICO)!=-1){
								
								//Si se ha producido un error al registrar la confirmaciÃ³n enviamos un evento a la agenda
								admconfirmacionesBo.insertarEvento(admconfirmacionesBo.generarEventoAgenda(co, codError.concat(" - ") + response.getOutputData().getDescripcion()));
								//return response.getOutputData().getDescripcion() + response.getOutputData().getDescripcion();
								//SMM 21/11/2013
								return codError.concat(" - ") + response.getOutputData().getDescripcion();
							}
							else{
								return "admconfirmaciones.firmadigital.error.llamada.ws";
							}
						}else{
							//La llamada ha ido bien. Actualizamos la tabla WsLogOsp
							admconfirmacionesBo.saveResultadoToLog(codError, response.getOutputData().getDescripcion(), co,ConstantesFD.LOG_IDWEBSEV_REGISTRAR,ConstantesFD.LOG_IDWEBSEV_ESTADOCO_OK);
						}
					}
				}
			}catch (FaultInfo fie){
				String faultCode = "";
				if(fie.getFaultCode()!=null && fie.getFaultCode().getLocalPart()!=null)
					faultCode=fie.getFaultCode().getLocalPart();
				String mensaje = fie.getMessage();
				admconfirmacionesBo.saveError(faultCode, mensaje, co,ConstantesFD.INCID_PROGRAMA_FD);
				admconfirmacionesBo.saveResultadoToLog(ConstantesFD.LOG_COD_ERROR_SIN_ACCESO_WS, ConstantesFD.LOG_DESC_ERROR_SIN_ACCESO_WS, co,ConstantesFD.LOG_IDWEBSEV_REGISTRAR,ConstantesFD.LOG_IDWEBSEV_ESTADOCO_KO);
				
				return "admconfirmaciones.firmadigital.error.llamada.ws";
			}
			
			//DespuÃ©s de la llamada al web service si la sesiÃ³n que tenÃ­amos ha resultado NO vÃ¡lida 
			//tendremos una nueva
			if(!GenericUtils.isNullOrBlank(firmaDigital) &&
					!GenericUtils.isNullOrBlank(firmaDigital.getSessionId()) &&
					!firmaDigital.getSessionId().equals(sessionId))
				sessionId = firmaDigital.getSessionId();
			//SÃ³lo mostramos informaciÃ³n del servicio de firma digital en el caso de que haya habido error
			return "";
		}
		
	}
	
		//Camp  idcontrato en format EEEEOOOONNNNNNNNNN 
	private String formatearIdContrato(DocsContrapartida docCMOF) {
		//(ex:<idContrato>00810000505083615793</idContrato>)
		//9370008125-0081-57	
		if (!GenericUtils.isNullOrBlank(docCMOF)&& !GenericUtils.isNullOrBlank(docCMOF.getId())
			&& !GenericUtils.isNullOrBlank(docCMOF.getId().getContrato())){
			
			try {
				String contrato = docCMOF.getId().getContrato(); 
				int indice = contrato.indexOf("-");
				String codigoContrato = contrato.substring(0, indice);
				codigoContrato = GenericUtils.lpad(codigoContrato, 10,"0");
				
				String entidad = contrato.substring(indice+1,indice + 5);
				entidad = GenericUtils.lpad(entidad, 4,"0");
				
				//SMM 26/01/2016
				String digitoControl = contrato.substring(indice+6,indice + 8);
				digitoControl = GenericUtils.lpad(digitoControl, 2,"0");
				
				String oficinaGestora = docCMOF.getOficinaGestora().toString(); 
				oficinaGestora = GenericUtils.lpad(oficinaGestora, 4,"0");
				
				
				return entidad.concat(oficinaGestora).concat(codigoContrato).concat(digitoControl);

			} catch (Exception e) {
				System.out.println("Error al obtener Idcontrato");
				return "";
			}

		}else{
			System.out.println("Error al obtener Idcontrato");
			return "";
		}
	}

	private String getTicket(){
		Assertion assertion = AssertionHolder.getAssertion();
		java.security.Principal principal = assertion.getPrincipal();
	
		
		Field[] fields = principal.getClass().getDeclaredFields();
    	System.out.println("obtener el proxyGrantingTicket!!!!: ");
		for (Field field : fields) {
		    if (field.getName().equals("proxyGrantingTicket")) {
			    field.setAccessible(true);
		        try {
		        	String res = (String) field.get(principal);
		        	System.out.println("proxyGrantingTicket del CAS!!!!: "+res);
					return res;
				} catch (IllegalArgumentException e) {
					e.printStackTrace();
				} catch (IllegalAccessException e) {
					e.printStackTrace();
				}
		    }
		}
		return "";
	}

	public String getSessionId() {
		return sessionId;
	}

	public void setSessionId(String sessionId) {
		this.sessionId = sessionId;
	}

	public String getProxyGrantingTicket() {
		return proxyGrantingTicket;
	}

	public void setProxyGrantingTicket(String proxyGrantingTicket) {
		this.proxyGrantingTicket = proxyGrantingTicket;
	}


	public void noEnvioBSOnline() {
		admconfirmacionesBo.marcarIndicadorEnvioBSOnline(confOperacionSelect,"N");
		refrescarLista();
	}

	public void envioBSOnline(){
		confOperacionSelect = admConfirmacionesPantalla.getAdmconfirmacionSelec();
//		final ConfOperacion cOperacion = admConfirmacionesPantalla
//		.getAdmconfirmacionSelec();
		confOperacionaux = confOperacionSelect ;

		verPDF();
		msgBoxAction.mostrarMsg(
				"#{admconfirmacionesAction.envioBSOnlineFinal}",
				"#{admconfirmacionesAction.noEnvioBSOnline}",
				null,null,"resultadosConsulta,table,msgboxPanel","resultadosConsulta,table,msgboxPanel",
				"Â¿Desea enviar el PDF a BS-Online? S/N ");
	}
	
	public void envioBSOnlineFinal(){
		admconfirmacionesBo.marcarIndicadorEnvioBSOnline(confOperacionSelect,"E");
		refrescarLista();
	}
	
//	public void testQuart(String cosa){
//		  log.info( "Quartz : " + cosa);
//	}
	
	private String getDescripcionEvenconfByIdioma(String evenconf, String idioma){
		String descripcion = "";
		if(idioma.equals("ES")){
			if(evenconf.equals("A")){
				descripcion=ConstantesFD.CONTEXTO_TIPO_PROCESO_ES_A;
			}else if(evenconf.equals("M")){
				descripcion=ConstantesFD.CONTEXTO_TIPO_PROCESO_ES_M;
			}else if(evenconf.equals("C")){
				descripcion=ConstantesFD.CONTEXTO_TIPO_PROCESO_ES_C;
			}else if(evenconf.equals("P")){
				descripcion=ConstantesFD.CONTEXTO_TIPO_PROCESO_ES_P;
			}
		}else if(idioma.equals("CA")){
			if(evenconf.equals("A")){
				descripcion=ConstantesFD.CONTEXTO_TIPO_PROCESO_CA_A;
			}else if(evenconf.equals("M")){
				descripcion=ConstantesFD.CONTEXTO_TIPO_PROCESO_CA_M;
			}else if(evenconf.equals("C")){
				descripcion=ConstantesFD.CONTEXTO_TIPO_PROCESO_CA_C;
			}else if(evenconf.equals("P")){
				descripcion=ConstantesFD.CONTEXTO_TIPO_PROCESO_CA_P;
			}
		}else if(idioma.equals("EN")){
			if(evenconf.equals("A")){
				descripcion=ConstantesFD.CONTEXTO_TIPO_PROCESO_EN_A;
			}else if(evenconf.equals("M")){
				descripcion=ConstantesFD.CONTEXTO_TIPO_PROCESO_EN_M;
			}else if(evenconf.equals("C")){
				descripcion=ConstantesFD.CONTEXTO_TIPO_PROCESO_EN_C;
			}else if(evenconf.equals("P")){
				descripcion=ConstantesFD.CONTEXTO_TIPO_PROCESO_EN_P;
			}
		}else if(idioma.equals("DE")){
			if(evenconf.equals("A")){
				descripcion=ConstantesFD.CONTEXTO_TIPO_PROCESO_DE_A;
			}else if(evenconf.equals("M")){
				descripcion=ConstantesFD.CONTEXTO_TIPO_PROCESO_DE_M;
			}else if(evenconf.equals("C")){
				descripcion=ConstantesFD.CONTEXTO_TIPO_PROCESO_DE_C;
			}else if(evenconf.equals("P")){
				descripcion=ConstantesFD.CONTEXTO_TIPO_PROCESO_DE_P;
			}
		}else if(idioma.equals("PT")){
			if(evenconf.equals("A")){
				descripcion=ConstantesFD.CONTEXTO_TIPO_PROCESO_PT_A;
			}else if(evenconf.equals("M")){
				descripcion=ConstantesFD.CONTEXTO_TIPO_PROCESO_PT_M;
			}else if(evenconf.equals("C")){
				descripcion=ConstantesFD.CONTEXTO_TIPO_PROCESO_PT_C;
			}else if(evenconf.equals("P")){
				descripcion=ConstantesFD.CONTEXTO_TIPO_PROCESO_PT_P;
			}
		}else if(idioma.equals("FR")){
			if(evenconf.equals("A")){
				descripcion=ConstantesFD.CONTEXTO_TIPO_PROCESO_FR_A;
			}else if(evenconf.equals("M")){
				descripcion=ConstantesFD.CONTEXTO_TIPO_PROCESO_FR_M;
			}else if(evenconf.equals("C")){
				descripcion=ConstantesFD.CONTEXTO_TIPO_PROCESO_FR_C;
			}else if(evenconf.equals("P")){
				descripcion=ConstantesFD.CONTEXTO_TIPO_PROCESO_FR_P;
			}
		}
		
		return descripcion;
	}

	/**
	 * Las descripciones de los productos solo estÃ¡n dadas de alta en idioma 8
	 * @param codiProducto
	 * @param idioma. Estamos pasando como parÃ¡metro el idioma de la confirmaciÃ³n
	 * @return
	 */
	private String getDescripcionProductoContexto(String codiProducto, String idioma){
		if(GenericUtils.isNullOrBlank(idioma))
			idioma=Constantes.IDIOMA_CASTELLANO_ABREVIADO;

		return admconfirmacionesBo.getDescripcionProductoContexto(codiProducto,idioma);
	}
	
	public void voidFunction(){
		msgBoxAction.voidFunction();
	}
	
	/**
	 * Mostrar PopUp cuando una contrapartida estÃ¡ bloqueada (no bloqueante)
	 */
	public void onVerificarContrapartidaBloqueada() {
		String idContrapa = admConfirmacionesPantalla.getContrapartida();
    	Contrapartida contrapObtenida2 = null;
		if (!GenericUtils.isNullOrBlank(idContrapa)){
			contrapObtenida2 = admconfirmacionesBo.cargarContrapartida(idContrapa.toUpperCase());
			if (null!=contrapObtenida2 && !GenericUtils.isNullOrBlank(contrapObtenida2.getIndBloqueo()) && "S".equalsIgnoreCase(contrapObtenida2.getIndBloqueo())){
				iniciarPopUpContrapartidaBloqueada();
			}
		}
    }
	
	private void iniciarPopUpContrapartidaBloqueada(){
		messageAdmConfirmacionesMO.init("admconfirmaciones.messages.contrapartida.bloqueada.texto", "admconfirmacionesAction.voidFunction()", null, "messageBoxPanelContrapa");
	}
	
	public String getComplete() {
		return complete;
	}

	public void setComplete(String complete) {
		this.complete = complete;
	}
	
	public String getRowClasses(){
    	StringBuilder builder = new StringBuilder();
    	int i=0;
    	
    	Contrapartida contrapartidaObtenida = null;
    	for(ConfOperacion confirmacionActual : admConfirmacionesPantalla.getAdmconfirmacionesList()){
    		if(i>0){
				builder.append(",");
			}
    		
    		if(null!=confirmacionActual && null!=confirmacionActual.getOperacion() && null!=confirmacionActual.getOperacion().getContrapartida()){
    				contrapartidaObtenida = (Contrapartida) confirmacionActual.getOperacion().getContrapartida();
    		}
    		
    		if(i%2==0){
    			if(null!=contrapartidaObtenida && !GenericUtils.isNullOrBlank(contrapartidaObtenida.getIndBloqueo()) && "S".equalsIgnoreCase(contrapartidaObtenida.getIndBloqueo())){
    				builder.append("oddRowRed");
    			}
    			else{
    				builder.append("oddRow");
    			}
    		}
    		else{
    			if(null!=contrapartidaObtenida && !GenericUtils.isNullOrBlank(contrapartidaObtenida.getIndBloqueo()) && "S".equalsIgnoreCase(contrapartidaObtenida.getIndBloqueo())){
    				builder.append("evenRowRed");
    			}
    			else{
    				builder.append("evenRow");
    			}
    		}
    		i++;
    		contrapartidaObtenida = null;
    	}
    	
    	return builder.toString();
    }

}

abstract class SeleccionCheckboxMap<K> extends TreeMap<K, Boolean> {

	private static final long serialVersionUID = 1L;

	@SuppressWarnings("unchecked")
	public SeleccionCheckboxMap(ConfOperacionComparator confOperacionComparator) {
		super((Comparator<? super K>) confOperacionComparator);
	}

	public Boolean superPut(K key, Boolean value) {
		return super.put(key, value);
	}

	public Boolean superRemove(Object key) {
		return super.remove(key);
	}

	public void superClear() {
		super.clear();
	}

	@Override
	public Boolean put(K key, Boolean value) {

		final Boolean b = superPut(key, value);
		onUpdate(key, value);

		return b;
	};

	@Override
	@SuppressWarnings("unchecked")
	public Boolean remove(Object key) {

		final Boolean b = superRemove(key);
		onUpdate((K) key, null);

		return b;
	};

	@Override
	public void clear() {
		superClear();
		onUpdate(null, null);
	};


	public abstract void onUpdate(K key, Boolean value);

}