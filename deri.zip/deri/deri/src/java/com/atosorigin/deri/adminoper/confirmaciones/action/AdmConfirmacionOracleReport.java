package com.atosorigin.deri.adminoper.confirmaciones.action;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.jboss.seam.international.StatusMessages;
import org.jboss.seam.international.StatusMessage.Severity;

import com.atosorigin.common.constantes.Constantes;
import com.atosorigin.common.constantes.Enumeraciones.EstadoConfirmacion;
import com.atosorigin.common.constantes.Enumeraciones.EventoConfirmacion;
import com.atosorigin.common.utils.GenericUtils;
import com.atosorigin.deri.adminoper.admconfirmaciones.business.ConfirmacionOperacionesBo;
import com.atosorigin.deri.appListados.circularizacion.business.CircularizacionBo;
import com.atosorigin.deri.common.reports.OracleReports;
import com.atosorigin.deri.common.reports.Report;
import com.atosorigin.deri.model.appListados.Informe;
import com.atosorigin.deri.model.gestionoperaciones.ConfOperacion;
import com.atosorigin.deri.model.gestionoperaciones.DescripcionEstadoConfirmacion;
import com.atosorigin.deri.model.seguridad.Pantalla;
import com.atosorigin.deri.model.seguridad.PantallaId;
import com.atosorigin.deri.seguridad.pantalla.business.PantallaBo;
import com.atosorigin.deri.util.ConfiguracionDeri;
import com.atosorigin.deri.util.MsgBoxAction;

public class AdmConfirmacionOracleReport extends OracleReports {

	public static enum InformeEnum {
		DERIMA1, DERIMA10, DERIMA2, DERIMA20, DERIMA3, //
		DERIMA6, DERIMB1, DERIMB10, DERIMB2, DERIMB20, //
		DERIMB6, DERIMC1, //
		DERIMC10, DERIMC2, // 
		DERIMFW2;
	}

	public static enum TipoFichero {
		REPORT
	}

	protected static Log log = LogFactory
			.getLog(AdmConfirmacionOracleReport.class);

	private final ConfirmacionOperacionesBo admconfirmacionesBo;
	private final ConfiguracionDeri configuracionDeri;
	private final ConfOperacion cOperacion;
	private String evenconf;
	private final InformeEnum informeEnum;
	private final boolean isDuplicado;
	private final MsgBoxAction msgBoxAction;
	private final SimpleDateFormat sdf = new SimpleDateFormat(
			Constantes.PATTERN_FECHA);
	private StatusMessages statusMessages;
	private final TipoFichero tipoFichero;
	private final PantallaBo pantallaBo;

	public AdmConfirmacionOracleReport(MsgBoxAction msgBoxAction,
			StatusMessages statusMessages, InformeEnum informe,
			ConfOperacion cOperacion, boolean isDuplicado,
			TipoFichero tipoFichero,
			ConfirmacionOperacionesBo admconfirmacionesBo,
			CircularizacionBo circularizacionBo, PantallaBo pantallaBo,
			ConfiguracionDeri configuracionDeri) {

		this.msgBoxAction = msgBoxAction;
		this.statusMessages = statusMessages;
		this.informeEnum = informe;
		this.cOperacion = cOperacion;
		this.isDuplicado = isDuplicado;
		this.tipoFichero = tipoFichero;
		this.admconfirmacionesBo = admconfirmacionesBo;
		this.pantallaBo = pantallaBo;
		this.configuracionDeri = configuracionDeri;

		report = newReport();
		report.setReportCode(informe.toString());
		report.setInformeDao(circularizacionBo.getInformeDao());

		report.addParameter("ORACLE_SHUTDOWN", "Yes");
	}

	@Override
	public String getOnClickJS() {

		try {
			return report.getOnClick();
		} catch (RuntimeException e) {

			log.error(e);

			statusMessages.add(Severity.ERROR, "Se ha producido un error "
					+ "generando el informe de Oracle Reports: " + e);
		}

		return "";
	}

	@Override
	public String getLinkValue() {

		try {
			return report.getInformeName();
		} catch (RuntimeException e) {

			log.error(e);

			statusMessages.add(Severity.ERROR, "Se ha producido un error "
					+ "generando el informe de Oracle Reports: " + e);

		}

		return "";
	}

	public void setLinkValue(String linkValue) {
		throw new UnsupportedOperationException(
				"Llamada a report delegado no permitida");
	}

	@Override
	public void setOnClickJS(String onClickJS) {
		throw new UnsupportedOperationException(
				"Llamada a report delegado no permitida");
	}

	private void modificarConfirmacion() {

		final List<ConfOperacion> coList = admconfirmacionesBo
				.buscarConfirmaciones(cOperacion.getOperacionID(), cOperacion
						.getFechaContratacion(), EventoConfirmacion.ALTA
						.toString());

		for (ConfOperacion co : coList) {

			final DescripcionEstadoConfirmacion deConfirmacion = new DescripcionEstadoConfirmacion();
			deConfirmacion.setCodigo(EstadoConfirmacion.DESCARTADO.toString());
			co.setDescripcionEstadoConfirmacion(deConfirmacion);
			co.setConfirmReclamada(null);

			admconfirmacionesBo.guardarDatosConfirmacion(co);
		}
	}

	private AdmConfirmacionReport newReport() {

		final String userId = configuracionDeri.getUserId();
		final String pathForms = configuracionDeri.getPathForms();
		final String pathEjecutable = configuracionDeri.getPathEjecutable();
		final String execMode = configuracionDeri.getExecMode();

		return new AdmConfirmacionReport(pantallaBo, userId, pathForms,
				pathEjecutable, execMode);
	}

	public void runReport_Fase1() {

		report.addParameter("P_FECHAOPE", toString(cOperacion
				.getFechaContratacion()));

		report.addParameter("P_FECHATRA", toString(cOperacion.getFechaAlta()));

		// TODO Se ha de hablar con Sonia e incorporar lo del email.
		// admconfirmacionesBo.obtenerDatosConfirmacion();

		if (cOperacion.getIdEstructConfirmada() != null) {

			// estructura

			// FIXME Hablar con Sonia sobre los parámetros!!!

			if (true)
				throw new UnsupportedOperationException();

			report.addParameter("P_NCORRELA", toString(cOperacion
					.getOperacionID()));
			report.addParameter("P_ESTRUCTU", toString(cOperacion
					.getIdEstructConfirmada()));
			report.addParameter("P_FECHAOPE_CAP", toString(cOperacion
					.getFechaContratacion()));

			report.addParameter("P_FECHATRA_CAP", toString(cOperacion));

			report.addParameter("P_NCORRELA_CAP", toString(cOperacion
					.getOperacionID()));
			report.addParameter("P_FECHAOPE_FLO", toString(cOperacion
					.getFechaContratacion()));

			report.addParameter("P_FECHATRA_FLO", toString(cOperacion));

			report.addParameter("P_NCORRELA_FLO", toString(cOperacion
					.getOperacionID()));
		} else {

			// operación

			report.addParameter("P_NCORRELA", toString(cOperacion
					.getOperacionID()));
		}

		report.addParameter("P_DUPLICADO", toString(isDuplicado));
		report.addParameter("P_ANULADO", toString("N"));

		evenconf = cOperacion.getEventoConfirmacion().getCodigo();

//SMM 08/09/2010 - El mensaje no tiene sentido aquí.
		
//		if (GenericUtils.equals(evenconf, EventoConfirmacion.RECTIFICACION)) {
//
//			msgBoxAction
//					.mostrarMsg(
//							"#{admconfirmacionesAction.oracleReport_runReport_Fase2(true)}",
//							"#{admconfirmacionesAction.oracleReport_runReport_Fase2(false)}",
//							getOnClickJS(), getOnClickJS(), //
//							null, null, //
//							"¿Desea generar la confirmación con Núm.Oper/Estr. "
//									+ cOperacion.getOperacionID()
//									+ " como una confirmación de Alta?");
//
//			return;
//		}

		runReport_Fase2(false);
	}

	public void runReport_Fase2(boolean bSi) {

		if (bSi) {

			modificarConfirmacion();

			evenconf = EventoConfirmacion.ALTA.toString();
		}

		if (GenericUtils.in(informeEnum, InformeEnum.DERIMA1,
				InformeEnum.DERIMA2, InformeEnum.DERIMA10,
				InformeEnum.DERIMA20, InformeEnum.DERIMC1, InformeEnum.DERIMC2,
				InformeEnum.DERIMC10, InformeEnum.DERIMA6)) {

			report.addParameter("P_TIPOCONF", toString(evenconf));

		} else if (GenericUtils
				.in(informeEnum, InformeEnum.DERIMB1, InformeEnum.DERIMB2,
						InformeEnum.DERIMB10, InformeEnum.DERIMB20,
						InformeEnum.DERIMB6, InformeEnum.DERIMFW2)) {

			report.addParameter("P_CODCONFI", toString(cOperacion
					.getNumConfirmacion()));

		} else if (GenericUtils.in(informeEnum, InformeEnum.DERIMA3)) {

			report.addParameter("P_TIPOCONF", toString(evenconf));
			report.addParameter("P_CODCONFI", toString(cOperacion
					.getNumConfirmacion()));
		} else {
			throw new IllegalStateException();
		}

		if (!TipoFichero.REPORT.equals(tipoFichero))
			throw new IllegalStateException();
	}

	public String toString(Object valor) {

		if (valor == null)
			return "null";

		if (valor instanceof Date)
			return sdf.format((Date) valor);

		if (valor instanceof Boolean) {
			final Boolean b = (Boolean) valor;
			return b ? "S" : "N";
		}

		return valor.toString();
	}
}

class AdmConfirmacionReport extends Report {

	private static Log log = LogFactory.getLog(AdmConfirmacionReport.class);

	public AdmConfirmacionReport(PantallaBo pantallaBo, String userId,
			String pathForms, String pathEjecutable, String execMode) {

		super(userId, pathForms, pathEjecutable, execMode, pantallaBo);
	}

	protected void cargaDatosInforme() {

		// Se debería informar que reportCode == null?

		if (pathEjecutable != null || reportCode == null)
			return;

		final Pantalla pantalla = pantallaBo.cargar(new PantallaId(
				Constantes.NOMBRE_PROYECTO_DERI,
				Pantalla.TIPO_EJECUTABLE_INFORME, reportCode));

		pathEjecutable = pantalla.getPathEjecutable().replaceAll("\\\\", "/");

		informe = new Informe();
		informe.setDescripcion(pantalla.getDescripcion());
		informe.setPathEjecutable(pathEjecutable);

		log.debug("cargaDatosInforme() pantalla::" + pantalla
				+ " pathEjecutable::" + pathEjecutable);
	}

}