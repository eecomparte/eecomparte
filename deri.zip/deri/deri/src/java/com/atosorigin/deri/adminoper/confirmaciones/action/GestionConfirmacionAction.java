package com.atosorigin.deri.adminoper.confirmaciones.action;

import java.lang.reflect.InvocationTargetException;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;

import javax.persistence.EntityManager;
import javax.transaction.SystemException;

import org.jboss.seam.ScopeType;
import org.jboss.seam.annotations.In;
import org.jboss.seam.annotations.Name;
import org.jboss.seam.annotations.Out;
import org.jboss.seam.annotations.Scope;
import org.jboss.seam.international.StatusMessage;
import org.jboss.seam.international.StatusMessage.Severity;
import org.jboss.seam.transaction.Transaction;

import com.atosorigin.common.action.GenericAction;
import com.atosorigin.common.action.ModoPantalla;
import com.atosorigin.common.constantes.Constantes;
import com.atosorigin.common.constantes.Enumeraciones;
import com.atosorigin.common.constantes.Enumeraciones.CanalOperacion;
import com.atosorigin.common.constantes.Enumeraciones.EstadoConfirmacion;
import com.atosorigin.common.constantes.Enumeraciones.EventoConfirmacion;
import com.atosorigin.common.constantes.Enumeraciones.SentidoConfirmacion;
import com.atosorigin.common.formvalidator.FormValidator;
import com.atosorigin.common.utils.GenericUtils;
import com.atosorigin.deri.adminoper.admconfirmaciones.business.ConfirmacionOperacionesBo;
import com.atosorigin.deri.common.comboboxes.ComboBoxes;
import com.atosorigin.deri.common.ui.Boton;
import com.atosorigin.deri.common.ui.Campo;
import com.atosorigin.deri.contrapartida.business.ContrapartidaBo;
import com.atosorigin.deri.model.adminoper.CanalConfirmacion;
import com.atosorigin.deri.model.adminoper.DescripcionTipoConfirmacion;
import com.atosorigin.deri.model.adminoper.PlantillasConfirmacion;
import com.atosorigin.deri.model.catalogo.CatalogoProdCompuesto;
import com.atosorigin.deri.model.catalogo.Producto;
import com.atosorigin.deri.model.catalogo.ProductoCompuesto;
import com.atosorigin.deri.model.common.Idioma;
import com.atosorigin.deri.model.contrapartida.AbstractContrapartida;
import com.atosorigin.deri.model.contrapartida.Contrapartida;
import com.atosorigin.deri.model.gestionoperaciones.ConfOperacion;
import com.atosorigin.deri.model.gestionoperaciones.ConfOperacion_Vista;
import com.atosorigin.deri.model.gestionoperaciones.DescripcionEstadoConfirmacion;
import com.atosorigin.deri.model.gestionoperaciones.HistoricoOperacion;
import com.atosorigin.deri.model.murex.ProductoCatalogo;
import com.atosorigin.deri.util.EntityUtil;
import com.atosorigin.deri.util.FacesTransactionEvents;
import com.atosorigin.deri.util.MessageBoxAction;
import com.atosorigin.deri.util.MsgBoxAction;

/**
 * Clase action listener para el caso de uso de preconfirmaciones
 */
@Name("gestionConfirmacionAction")
@Scope(ScopeType.CONVERSATION)
@FormValidator
@SuppressWarnings({"unused", "unchecked"})
public class GestionConfirmacionAction extends GenericAction {

	private static final long serialVersionUID = 1L;

	@In
	private EntityManager entityManager;

	/**
	 * Inyección del bean de Spring "preconfirmacionesBo" que contiene los métodos de
	 * negocio para el caso de uso preconfirmaciones.
	 */
	@In("#{admconfirmacionesBo}")
	protected ConfirmacionOperacionesBo admconfirmacionesBo;

	@In(value = "comboBoxes", create = true)
	protected ComboBoxes comboBoxes;

	/**
	 * Inyección del bean de Spring "contrapartidaBo" que contiene los métodos de
	 * negocio para el caso de uso de contrapartidas.
	 */
	@In("#{contrapartidaBo}")
	protected ContrapartidaBo contrapartidaBo;
	
	@In("EntityUtil")
	private EntityUtil entityUtil;

	@In(create = true, value = "org.jboss.seam.transaction.facesTransactionEvents")
	protected FacesTransactionEvents facesTransactionEvents;

	@In(value = "#{admconfirmacionesAction}", required = false)
	protected AdmConfirmacionAction admconfirmacionesAction;

	
//	@Out
//	protected Boolean anexoGrabado = false;

	//@In(create = true,required = false) aqui no hace falta una injeccion de una variable de contexto ya qu no existe tal variable, es un objeto



//	@In(create = true)
//	protected AdmConfirmacionesPantalla admConfirmacionesPantalla;	
	
	
	private ConfOperacion confOperacion;
	
	
	//Variable de salida para anexos
	//@In(required = false )
	@Out(required = false)
	protected ConfOperacion confOperacionSelect;

	//Aqui si que tenemos el seleccionado anteriormente
	@In("admconfirmacionesAction")
	private AdmConfirmacionAction admConfirmacionAction;

	@In(create = true)
	MsgBoxAction msgBoxAction;
	
	@Out(required = false, value = "migracionesGestConfirmacionBoxAction")
	private MessageBoxAction messageBoxGestConfirmacionAction;
	
//	Campos de esta pantalla, muchos son solo informativos
	//Just to set values in confOperacion as convertEntity don't work.
	private Idioma idiomaPantalla;	
	private DescripcionTipoConfirmacion tipoConfPantalla;
	private CanalConfirmacion canalPantalla;
	private boolean isModificable;
	
	// Esto si que es de confiope private ProductoCatalogo productoCatalogo;
	
	

	/**
	 * Variables internas de la pantalla de gestion.
	 * 
	 */
	
	protected Contrapartida contrapartida;
	protected boolean fechaDefaultlabel = false;
	protected String contrapartidaNif;
	protected String productoContable;	
	
	public String getProductoContable() {
		return productoContable;
	}

	public void setProductoContable(String productoContable) {
		this.productoContable = productoContable;
	}

	public ProductoCatalogo getPdtoCatalogo() {

		if (confOperacion == null)
			return null;

		final ConfOperacion_Vista vista = confOperacion.getVista();
		return vista == null ? null : vista.getProductoCatalogo();
	}

	public boolean isFechaDefaultlabel() {
		return fechaDefaultlabel;
	}

	public void setFechaDefaultlabel(boolean fechaDefaultlabel) {
		this.fechaDefaultlabel = fechaDefaultlabel;
	}

	public String getContrapartidaNif() {
		return contrapartidaNif;
	}

	public void setContrapartidaNif(String contrapartidaNif) {
		this.contrapartidaNif = contrapartidaNif;
	}
	
	protected boolean getIsModificable(){
		return isModificable;
	}
	
	protected void setIsModificable(boolean isModificable){
		this.isModificable = isModificable;
	}

	/**
	 * Variable que activa o desactiva el combo del canal por defecto activo.
	 * 
	 */
	@In("seleccionar")
	private String seleccionar;
	
	public String getSeleccionar() {
		return seleccionar;
	}

	public void setSeleccionar(String seleccionar) {
		this.seleccionar = seleccionar;
	}

	protected boolean canalDisabled = true;
	protected boolean tipoConfDisabled = true;
	protected boolean fechaLiqDisabled = true;
	protected boolean sentidoConfDisabled = true;
	protected boolean idiomaDisabled = true;
	protected boolean observacionesDisabled = true;
	
	
	private boolean readyAceptar;
	
	/**
	 * metodo para realizar el alta con copia
	 * @throws IllegalAccessException
	 * @throws InstantiationException
	 * @throws InvocationTargetException
	 * @throws NoSuchMethodException
	 */
	
	
	public String getLabelFechaModificacion() {
		if ( tipoConfPantalla == null)
			return "";
		if ( "M".equalsIgnoreCase( tipoConfPantalla.getCodigo()) )
			return "#{messages['admconfirmaciones.fechamodificacion']}";
		if ( "X".equalsIgnoreCase( tipoConfPantalla.getCodigo())  || "L".equalsIgnoreCase( tipoConfPantalla.getCodigo())  )
			return "#{messages['admconfirmaciones.fechaliquidacion']}";
		else
			return "";
	}

	// FLM: Validaremos siempre que la operación exista, si es asi cargaremos los valores que toquen
	public void confirmarOperacion() {


		// Los campos deben estar informados
		// if ( confOperacion == null || confOperacion.getFechaContratacion() ==
		// null || confOperacion.getOperacionID() == null) {
		// statusMessages.add(Severity.ERROR,
		// "#{messages['admconfirmaciones.error.faltadatosoperacion']}");
		// return;
		// }

		// La operacion debe existir
		// OperacionId idoper=new OperacionId(
		// confOperacion.getFechaContratacion(), confOperacion.getOperacionID()
		// );
		// Operacion oper = admconfirmacionesBo.buscarOperacion(idoper) ;

		
		if (calcularPdtoCatCotnrapa()) {
			// Fecha actual
			confOperacion.setFechaAlta(new Date());
			activarBotones();
		} else {
			desActivarBotones();
		}

		cargarIdiomasCanales();
	}

	private Boolean primeraEjecucionInit=null;
	
	public Boolean getPrimeraEjecucionInit() {
		return primeraEjecucionInit;
	}

	public void setPrimeraEjecucionInit(Boolean primeraEjecucionInit) {
		this.primeraEjecucionInit = primeraEjecucionInit;
	}
	
	public void voidFunction(){
		msgBoxAction.voidFunction();
	}
	
	public void init(){
		boolean primera=false;
		if ( primeraEjecucionInit == null) {
			primera=true;
			primeraEjecucionInit=true;
		} 
		else{
			primeraEjecucionInit = false;
		}
		
		if(primeraEjecucionInit){
			if (null!=contrapartida && !GenericUtils.isNullOrBlank(contrapartida.getIndBloqueo()) && "S".equalsIgnoreCase(contrapartida.getIndBloqueo())){
				messageBoxGestConfirmacionAction = new MessageBoxAction();
				messageBoxGestConfirmacionAction.init("admconfirmaciones.messages.contrapartida.bloqueada.texto", "gestionConfirmacionAction.voidFunction()", null,"messageBoxPanelContrapa");
			}
		}
	}

	//FLM: Funcion muy importante
	// centraliza la carga de la operacion y estructura, y su contrapartida asociada
	//Cuando se modifica la estructura o operacion se vuelve a llamar
	private boolean calcularPdtoCatCotnrapa() {

		// El seleccionar indica si estamos en modo operación o estructura
		// En alta nos lo pasan, en modificación es O si tenemos operacion
		if (!alta && seleccionar != null && !"".equals(seleccionar)) {
			if (confOperacion.getOperacionID() != null
					&& confOperacion.getOperacionID().longValue() > 0)
				seleccionar = "O";
			else
				seleccionar = "E";
		}

		if ("O".equalsIgnoreCase(seleccionar)) {
			if (confOperacion.getOperacionID() == null
					|| confOperacion.getFechaContratacion() == null)
				return false;

			return calcularPdtoCatCotnrapaOp();
		}

		return confOperacion.getIdEstructConfirmada() != null ? calcularPdtoCatCotnrapaEstructura()
				: false;
	}

		
	//FLM: Realizamos la carga de los valores
	private boolean calcularPdtoCatCotnrapaOp() {
		
		HistoricoOperacion oper = admconfirmacionesBo
				.obtenerHistoricoOperacion(confOperacion.getOperacionID(),
						confOperacion.getFechaContratacion());

		if (oper == null) {

			admconfirmacionesAction.addFromResourceBundleStatusMessage(
					Severity.ERROR, "admconfirmaciones.error.operacion");

			return false;
		}
		// Producto catalogo de operacion
		try {
			// ProductoCatalogo operProdCat=
			// admconfirmacionesBo.obtenerProductoCatalogo(oper);
//			confOperacion.getVista().setProductoCatalogo(oper.getProductoCatalogo());
			producat=oper.getProductoCatalogo().getProducat().toString() ;

			final ConfOperacion_Vista coVista = confOperacion.getVista();
			confOperacion.setVista((coVista != null) ? coVista : new ConfOperacion_Vista());
			confOperacion.getVista().setProductoCatalogo(oper.getProductoCatalogo());

			confOperacion.setProducat(producat);

			// FLM: Truco per obtenir contrapartidas
			AbstractContrapartida a = entityUtil.unwrapProxy(oper
					.getContrapartida(), AbstractContrapartida.class);
			if ( a == null || !(a instanceof Contrapartida)) {
				admconfirmacionesAction.addStatusMessage(Severity.ERROR,
						"La operación no tiene tipo contrapartida asociada");

				return false;
			}
			final String nif = a.getId();
			contrapartida = (Contrapartida) a;
			this.setContrapartida(contrapartida);
			this.setContrapartidaNif(nif);

	//SMM 12/02/2018
			tipocontr = getTipoContr(contrapartida);
//			if (contrapartida.getTipoContrapartida() != null)
//				tipocontr = contrapartida.getTipoContrapartida().getId() ;
//			else
//				tipocontr = "";
			

			if (oper.getProducto() != null) {

				this.setProductoContable(oper
						.getProducto().getDescripcion());
			} else {
				this.setProductoContable(null);
			}
			

			
			return true;

		} catch (Exception e) {
			admconfirmacionesAction.addStatusMessage(Severity.ERROR,
					"#{messages['admconfirmaciones.warn.productosoperacion']}");
			return false;
		}
	}

	//SMM 12/02/2018 Nueva funcion para emular comportamiento boleta
	private String getTipoContr(AbstractContrapartida abstractContrapartida) {
		
		
			if (abstractContrapartida != null && abstractContrapartida instanceof Contrapartida) {
				Contrapartida contrapartida = (Contrapartida) abstractContrapartida;

				if (entityUtil.checkEntityExists(contrapartida.getGrupoBancario()) && "CLIENTES".equals(contrapartida.getGrupoBancario().getId())) {
					return "C";
				}
			}
		return "B";
	}

	
	private boolean calcularPdtoCatCotnrapaEstructura() {
//		ProductoCompuesto prodcomp=entityManager.find(ProductoCompuesto.class , confOperacion.getIdEstructConfirmada().longValue()  );
		ProductoCompuesto prodcomp= confOperacion.getEstructura();
		if (prodcomp == null) {
			
			admconfirmacionesAction.addFromResourceBundleStatusMessage(
					Severity.ERROR, "admconfirmaciones.error.operacion");

			return false;
		}
		// Producto catalogo de operacion
		try {
			

			//FLM: esto no es correcto, un prodcatcompuesto NO es un prodcat
			CatalogoProdCompuesto catalagoP=entityUtil.unwrapProxy(prodcomp.getCatalogoProdCompuesto(), CatalogoProdCompuesto.class);
//			confOperacion.getVista().setCatalogoProdCompuesto(catalagoP );
			producat= Integer.toString( prodcomp.getCatalogoProdCompuesto().getId()) ;
			confOperacion.setProducat(producat);

			// FLM: Truco per obtenir contrapartidas
			if ( prodcomp.getContrapartida() == null  ) {
				admconfirmacionesAction.addStatusMessage(Severity.ERROR,
						"Esta estructura no tiene tipo contrapartida asociado");
				return false;
			}
			final String nif = prodcomp.getContrapartida().getId();
			final Contrapartida b = prodcomp.getContrapartida();
			this.setContrapartida(b);
			
			//SMM 12/02/2018
			tipocontr = getTipoContr(contrapartida);
//
//			if (contrapartida.getTipoContrapartida() != null)
//				tipocontr = contrapartida.getTipoContrapartida().getId() ;
//			else
//				tipocontr = "";

			this.setContrapartidaNif(nif);

			if (prodcomp.getProducto() != null) {

				this.setProductoContable(prodcomp
						.getProducto().getDescripcion());
			} else {
				this.setProductoContable(null);
			}
			//More
			if (confOperacion != null && confOperacion.getEventoConfirmacion() != null && confOperacion.getEventoConfirmacion().getCodigo()!=null){
				evenconf = confOperacion.getEventoConfirmacion().getCodigo();
			}

			//FLM: Ponemos directamente prodcom que no tiene nada que ver con producto catalogo, es de producto compuestos
//			if (pdtoCatalogo != null){
//				producat = String.valueOf(pdtoCatalogo.getProducat());
//				//Si estamos en alta lo ponemos en confope para que se pueda guardar
//			}

			//Esta solo es de visualizacion, no es modificable
			confOperacion.setFechaContratacion(prodcomp.getFechaContratacion() ); 
			
			return true;

		} catch (Exception e) {
			admconfirmacionesAction.addStatusMessage(Severity.ERROR,
					"#{messages['admconfirmaciones.warn.productosoperacion']}");
			return false;
		}
	}
	
	
	private void activarBotones(){
		setCanalDisabled(false);
		tipoConfDisabled = false;
		fechaLiqDisabled = false;
		sentidoConfDisabled = false;
		idiomaDisabled = false;
		observacionesDisabled = false;

		readyAceptar = true;

		campos.get("canalConfirmacion").setDisabled(false);
		campos.get("tipoConfirmacion").setDisabled(false);
//		fechaLiquidacion.setDisabled(false);
		campos.get("sentidoConfirmacion").setDisabled(false);
		campos.get("idiomaConfirmacion").setDisabled(false);
		campos.get("observacionesAlta").setDisabled(false);
		aceptarBoton.setEnabled(true);
	}
	
	private void desActivarBotones(){
		setCanalDisabled(true);
		tipoConfDisabled = true;
		fechaLiqDisabled = true;
		sentidoConfDisabled = true;
		idiomaDisabled = true;
		observacionesDisabled = true;

		readyAceptar = false;
		
		campos.get("canalConfirmacion").setDisabled(true);
		campos.get("tipoConfirmacion").setDisabled(true);
		fechaLiquidacion.setDisabled(true);
		campos.get("sentidoConfirmacion").setDisabled(true);
		campos.get("idiomaConfirmacion").setDisabled(true);
		campos.get("observacionesAlta").setDisabled(true);
		aceptarBoton.setEnabled(false);
	}
	
	/**
	 * variables metodos de carga de valores para alta,altaconcopia y datosconfirmacion
	 */
	String tipocontr;
	String producat;
	String evenconf;
	
		
	/**
	 * metodo para cargar evenconf
	 */
	public void cargarEventoConfirmacion() {

		evenconf = null;
		setFechaDefaultlabel(false);

		cargarIdiomasCanalesEstado();

		if (evenconf != null && admconfirmacionesBo.estadoLXM(confOperacion))
			setFechaDefaultlabel(true);


		if (GenericUtils.in(modoDetalle, ModoDetalle.ALTA, ModoDetalle.ALTA_CON_COPIA)) {

			//
			// Recálculo del campo "fecha liquidación" / "fecha modificación":
			// literal + disabled/required
			//

			if (GenericUtils.in(evenconf, EventoConfirmacion.FIJACION,
					EventoConfirmacion.LIQUIDACION)) {

				campos.put("message_fechaLiquidacion", new Campo(messages
						.get("admconfirmaciones.fechaliquidacion")));

				fechaLiquidacion.setDisabled(false);

			} else if (GenericUtils.equals(evenconf, EventoConfirmacion.RECTIFICACION)) {

				campos.put("message_fechaLiquidacion", new Campo(messages
						.get("admconfirmaciones.fechamodificacion")));

				fechaLiquidacion.setDisabled(false);
			} else {
				fechaLiquidacion.setDisabled(true);
				fechaLiquidacion.setValue(null);
			}

			fechaLiquidacion.setRequired(!fechaLiquidacion.isDisabled());
		}

		// Botón Aceptar
		aceptarBoton.setEnabled(true);
	}
	
	private void cargarIdiomasCanales() {

		//
		// Idiomas
		//

		final List<Idioma> idiomas = cargarIdiomas();

		if (GenericUtils.isNullOrEmpty(idiomas)) {

			fijarIdiomaCastellanoCanalManual();
			setIdiomaDisabled(true);

			return;
		}

		//
		// Canales
		//

		cargarCanales();

		// En datos confirmacion y este caso no podemos mostrar batch
		if (datosconfirm && estadoPCcanalCIMMOFOEOMSW(confOperacion))
			listaCanales = eliminarBFBEBM(listaCanales);

		if (GenericUtils.isNullOrEmpty(listaCanales)) {

			fijarIdiomaCastellanoCanalManual();
			setIdiomaDisabled(true);
		}
	}

	private List<CanalConfirmacion> cargarCanales() {

		String sentido = null;
		try {
			sentido = confOperacion.getSentidoConfirmacion();
		} catch (NullPointerException e) {
		}

		final List<CanalConfirmacion> canales = admconfirmacionesBo
				.obtenerCanales(evenconf, sentido, tipocontr);
		setListaCanales(canales);
		
		return canales;
	}

	private List<Idioma> cargarIdiomas() {

		List<Idioma> idiomas = null;
		if (GenericUtils.equals(confOperacion.getSentidoConfirmacion(),
				SentidoConfirmacion.ENVIAR)) {
		
		
		try {
			evenconf = confOperacion.getEventoConfirmacion().getCodigo();
		} catch (NullPointerException e) {
		}

		idiomas = admconfirmacionesBo.obtenerIdiomas(
				producat, evenconf);
		setListaIdiomas(idiomas);
		
		}else{
		idiomas = admconfirmacionesBo.buscarIdioma();
			setListaIdiomas(idiomas);
				
		}
		
		
		
		return idiomas;
	}

	/**
	 * EOB metodo para cargar la lista de idiomas y canales ,si no tiene contrapartida genera un msg de error
	 */
	public void cargarIdiomasCanalesEstado() {

		setCanalDisabled(false);
		setIdiomaDisabled(false);

		//
		// idiomas
		//

		final List<Idioma> idiomas = cargarIdiomas();

		if (GenericUtils.isNullOrEmpty(idiomas)) {

			fijarIdiomaCastellanoCanalManual();
			cargaEstadoConfirmacion();

			return;
		}

		//
		// canales
		//

		final List<CanalConfirmacion> canales = cargarCanales();

		if (GenericUtils.isNullOrEmpty(canales)) {

			log.error("No existe combinación evento/sentido/tipo "
					+ "contrapartida en CANCONFI");

			admconfirmacionesAction.addFromResourceBundleStatusMessage(Severity.WARN,
					"No existe combinación evento/sentido/tipo "
							+ "contrapartida en CANCONFI. Fijando a "
							+ "castellano/manual-manual.", confOperacion
							.getNumConfirmacion());

			fijarIdiomaCastellanoCanalManual();
		}

		canalPantalla = (CanalConfirmacion) campos.get("canalConfirmacion")
				.getValue();

		cargaEstadoConfirmacion();
	}

	private void fijarIdiomaCastellanoCanalManual() {

		idiomaPantalla = admconfirmacionesBo
				.buscarIdiomaPorCodigo(Constantes.IDIOMA_CASTELLANO);

		if (getListaCanales() == null)
			setListaIdiomas(new ArrayList<Idioma>(1));

		if (!listaIdiomas.contains(idiomaPantalla))
			listaIdiomas.add(idiomaPantalla);

		confOperacion.setIdioma(idiomaPantalla);

		final String canalMM = CanalOperacion.MANUAL_MANUAL.toString();

		String sentido = confOperacion.getSentidoConfirmacion();
		canalPantalla = admconfirmacionesBo.obtenerCanal(canalMM, evenconf,
				sentido, tipocontr);

		// Canal Manual a muerte
		if (canalPantalla == null)
			canalPantalla = obtenerCanal(canalMM);

		setListaCanales(new ArrayList<CanalConfirmacion>(Arrays
				.asList(canalPantalla)));

		campos.get("canalConfirmacion").setValue(canalPantalla);

		setCanalDisabled(true);
	}

	/**
	 * Carga el código de la contrapartida según el grupo bancario.
	 * <code>DT - Lista de Confirmaciones v4.1.doc</code>.
	 * 
	 * @param id
	 *            Identificador del grupo bancario.
	 * @return
	 * @see Enumeraciones.GrupoBancario
	 */
	private String cargarTipoContrapartidaGrupoBancario(final String id) {

		if (Enumeraciones.GrupoBancario.CLIENTES_EXTERNOS.equals(id))
			return Enumeraciones.TipoContrapartida.CLIENTES_TESORERIA
					.toString();

		return Enumeraciones.TipoContrapartida.BANCOS.toString();
	}

	public void cargaEstadoConfirmacion() {
		final String codEstado;
		canalPantalla = (CanalConfirmacion) campos.get("canalConfirmacion")
				.getValue();

		if (GenericUtils.isNullOrBlank(canalPantalla)) {
			confOperacion.setDescripcionEstadoConfirmacion(null);
			// .setEstadoConfirmacion(Constantes.CADENA_VACIA);
			return;
		}

		final EstadoConfirmacion ec;
		
		if (getIsModificable()){
			if (GenericUtils.equals(confOperacion.getSentidoConfirmacion(),
					SentidoConfirmacion.ENVIAR)) {
	
				if (GenericUtils.in(canalPantalla.getId().getCodcanal(),
						CanalOperacion.BATCH_FAX, CanalOperacion.BATCH_EMAIL,
						CanalOperacion.BATCH_MANUAL)) {
	
					ec = EstadoConfirmacion.PENDIENTE_BATCH;
	
				} else if (GenericUtils.in(canalPantalla.getId().getCodcanal(),
						CanalOperacion.ON_LINE_FAX, CanalOperacion.ON_LINE_EMAIL,
						CanalOperacion.ON_LINE_MANUAL, CanalOperacion.URGENTE)) {
	
					ec = EstadoConfirmacion.NO_VISIBLE;
				} else {
					ec = EstadoConfirmacion.PENDIENTE_CONFIRMAR;
				}
			} else {
				ec = EstadoConfirmacion.PDTE_RECIBIR_CONFIRMACION;
			}
			codEstado = ec.toString();
		} else{
			codEstado = confOperacion.getEstadoco();
		}
			
		final DescripcionEstadoConfirmacion dec = admconfirmacionesBo
		.buscarEstadoConfirmacion(codEstado);
		
		if (dec == null) {
			admconfirmacionesAction
					.addFromResourceBundleStatusMessage(Severity.WARN,
							"gestionConfirmacionAction.cargaEstadoConfirmacion.estadoNoEncontrado");
}
			confOperacion.setDescripcionEstadoConfirmacion(dec);
	
	}

	private void setEstadoConfirmacion(ConfOperacion cOperacion,
			EstadoConfirmacion ec) {

		// for (DescripcionEstadoConfirmacion dec : decList) {
		//
		// if (GenericUtils.equals(dec.getCodigo(), ec.toString())) {
		//
		// cOperacion.setDescripcionEstadoConfirmacion(dec);
		//
		// return;
		// }
		// }
		//
		// throw new IllegalStateException();
	}

	/**
	 * Actualiza la lista del grid de parámetros informe y vuelve a la pantalla
	 * de búsqueda
	 */
	public void salirDetalle() {
//		paginationData.reset();
//		/** Limpiamos la información de paginación */
//		if (this.modoPantalla.equals(ModoPantalla.EDICION)) {
//			refrescarLista();
//		}
//	
	}
	



	public Idioma getIdiomaPantalla() {
		return idiomaPantalla;
	}


	public void setIdiomaPantalla(Idioma idiomaPantalla) {
		this.idiomaPantalla = idiomaPantalla;		
	}


	public DescripcionTipoConfirmacion getTipoConfPantalla() {
		return tipoConfPantalla;
	}


	public void setTipoConfPantalla(DescripcionTipoConfirmacion tipoConfPantalla) {
		this.tipoConfPantalla = tipoConfPantalla;
	}


	public CanalConfirmacion getCanalPantalla() {
		return canalPantalla;
	}


	public void setCanalPantalla(CanalConfirmacion canalPantalla) {
		this.canalPantalla = canalPantalla;
	}

	public void salir() {

		datosconfirm = false;
		altacopia = false;
		alta = false;
		
	}	

	public boolean salirDeshabilitado() {
		if (!GenericUtils.isNullOrBlank(confOperacionSelect) && confOperacionSelect.getAnexoGrabado()){
			return true;
		}
		return false;		
	}	

	public void volver(){
	}

	//Metodos para activacion descativacion de campos
	/**
	 * -	si ESTADOCO = PR, DE, RE, PB e INDCONRE = null
		Todos los campos se presentarán protegidos y en enlace con MANTANEX será en modo consulta. 
	 */
	public boolean estadoPRDEREPBindNull(ConfOperacion confOperacion){
		if (confOperacion==null)
			return false;
		return ((("PR").equalsIgnoreCase(confOperacion.getEstadoConfirmacion()) ||
				("DE").equalsIgnoreCase(confOperacion.getEstadoConfirmacion()) ||
				("RE").equalsIgnoreCase(confOperacion.getEstadoConfirmacion()) ||
				("PB").equalsIgnoreCase(confOperacion.getEstadoConfirmacion())) &&
				confOperacion.getConfirmReclamada() == null);
	}
	public boolean estadoPCcanalBFBEBM(ConfOperacion confOperacion){
		if (confOperacion==null)
			return false;
		
		return (("PC").equalsIgnoreCase(confOperacion.getEstadoConfirmacion()) &&
				(("BF").equalsIgnoreCase(confOperacion.getCanalConfirmacion()) ||
				 ("BE").equalsIgnoreCase(confOperacion.getCanalConfirmacion()) ||
				 ("BM").equalsIgnoreCase(confOperacion.getCanalConfirmacion())));
	}

	public boolean estadoPCcanalCIMMOFOEOMSW(ConfOperacion confOperacion){
		if (confOperacion==null)
			return false;
		
		return  (("PC").equalsIgnoreCase(confOperacion.getEstadoConfirmacion()) &&
					(("CI").equalsIgnoreCase(confOperacion.getCanalConfirmacion()) ||
					 ("MM").equalsIgnoreCase(confOperacion.getCanalConfirmacion()) ||
					 ("OF").equalsIgnoreCase(confOperacion.getCanalConfirmacion()) ||
					 ("OE").equalsIgnoreCase(confOperacion.getCanalConfirmacion()) ||
					 ("OM").equalsIgnoreCase(confOperacion.getCanalConfirmacion()) ||
					 ("UR").equalsIgnoreCase(confOperacion.getCanalConfirmacion()) ||
					 ("SW").equalsIgnoreCase(confOperacion.getCanalConfirmacion()))) ;
	}
	
	public boolean canalDatosConfDisabled(){
		if (estadoPCcanalCIMMOFOEOMSW(confOperacion))
			return false;
		if (estadoRP(confOperacion))
			return false;
		return true;
	}

	public boolean idiomaDatosConfDisabled(){
		if (estadoPCcanalCIMMOFOEOMSW(confOperacion))
			return false;
		return true;
	}
	

	public boolean canalBEBFBM(ConfOperacion confOperacion) {
		if (confOperacion==null)
			return false;
		
		return ("BE").equals(confOperacion.getCanalConfirmacion())
				|| ("BF").equals(confOperacion.getCanalConfirmacion())
				|| ("BM").equals(confOperacion.getCanalConfirmacion());
	}

	public boolean estadoPRindNotNull(ConfOperacion confOperacion){
		if (confOperacion==null)
			return false;
		
		return (("PR").equalsIgnoreCase(confOperacion.getEstadoConfirmacion()) &&
				 confOperacion.getConfirmReclamada() != null);
	}

	public boolean estadoRP(ConfOperacion confOperacion){
		if (confOperacion==null)
			return false;
		
		return ("RP").equals(confOperacion.getEstadoConfirmacion());
	}
	
	


	public Contrapartida getContrapartida() {
		return contrapartida;
	}


	public void setContrapartida(Contrapartida contrapartida) {
		this.contrapartida = contrapartida;
	}
	
	public ConfOperacion getcOperacionSelect() {
		return confOperacionSelect;
	}


	public void setcOperacionSelect(ConfOperacion cOperacionSelect) {
		confOperacionSelect = cOperacionSelect;
	}


	
	/**
	 * METODOS PARA LOS CASOS DE USO
	 * ALTA 
	 * ALTA CON COPIA
	 * DATOS CONFIRMACION
	 */
	
	public ConfOperacion getConfOperacion() {
		return confOperacion;
	}

	public void setConfOperacion(ConfOperacion confOperacion) {
		this.confOperacion = confOperacion;
	}
	
	/**
	 * metodo para aceptar el objeto ConfOperacion nuevo en la pantalla
	 * gestionConfirmaciones al clicar el boton aceptar.
	 * 
	 * @throws SQLException
	 */
	public void aceptar() throws SQLException {

		if (idiomaPantalla != null
				&& GenericUtils.isNullOrBlank(confOperacion.getIdioma())) {

			confOperacion.setIdioma(idiomaPantalla);
		}

		if (canalPantalla != null
				&& GenericUtils.isNullOrBlank(confOperacion
						.getCanalConfirmacion())) {

			confOperacion.setCanalConfirmacion(canalPantalla.getId()
					.getCodcanal());
		}

		// Obtendremos PLACONFI.CODPLANT partir de PRODUCAT, EVENCONF e
		// IDIOMACO.

		PlantillasConfirmacion plantillasConfirmacion = null;
		if (!GenericUtils.isNullOrBlank(confOperacion.getIdioma())
				&& !GenericUtils.isNullOrBlank(confOperacion
						.getEventoConfirmacion())
				&& !GenericUtils.isNullOrBlank(confOperacion.getProducat())) {

//SMM 27/05/2013
			String tipoPlan=null;
			if (EventoConfirmacion.FIJACION.equals(confOperacion.getEventoConfirmacion().getCodigo())){
				tipoPlan = admconfirmacionesBo.obtenerTipoPlan(confOperacion.getOperacionID(),
					confOperacion.getFechaContratacion(),confOperacion.getFechaLiquidacion());
				
				plantillasConfirmacion = admconfirmacionesBo
				.obtenerPlantillasConfirmacion(Long.parseLong(confOperacion
						.getProducat()), confOperacion
						.getEventoConfirmacion().getCodigo(), confOperacion
						.getIdioma().getCodigo(), tipoPlan);
				
			}else{
			
			plantillasConfirmacion = admconfirmacionesBo
					.obtenerPlantillasConfirmacion(Long.parseLong(confOperacion
							.getProducat()), confOperacion
							.getEventoConfirmacion().getCodigo(), confOperacion
							.getIdioma().getCodigo());
			}
		}

		if (!GenericUtils.isNullOrBlank(plantillasConfirmacion)) {

			confOperacion.setIdPlantillaConfirmacion(plantillasConfirmacion
					.getId().getCodplant());
		}

		confOperacion.setTipoConfirmacion("M");

		// Limpieza...
		confOperacion.setVista(null);

		
		//Para borrare el documento del Gestor Documental
//		if (GenericUtils.equals(confOperacion.getEventoConfirmacion().getCodigo(),
//				EventoConfirmacion.ALTA)) {
//
//			final List<ConfOperacion> coList = admconfirmacionesDao.buscarConfirmacionesAlta(
//					confOperacion.getOperacionID(), confOperacion.getFechaContratacion());
//		}

		
		//TODO DESCARTAR FIRMA DIGITAL PARA CONFIRMACIONES DEL MISMO TIPO
		admconfirmacionesBo.aceptarAlta(confOperacion,admconfirmacionesAction.getProxyGrantingTicket());

		admconfirmacionesBo.flush();
//		((Session) entityManager.getDelegate()).flush();

		final Integer result = admconfirmacionesBo
				.altaConfirmacion(confOperacion.getNumConfirmacion());

//		statusMessages.add(Severity.INFO,
//				"DERI.PKG_ADMCONFI.F_CONFIRMACIONES ha devuelto {0}", result);

		admconfirmacionesBo.recargar(confOperacion);

		if (result == 0 || result == 2) {

			admconfirmacionesAction.addFromResourceBundleStatusMessage(
					Severity.INFO, "admconfirmaciones.warn.altacorrecta",
					confOperacion.getNumConfirmacion().toString(),
					confOperacion.getVista().getNcorrEstructu());

			if (!admConfirmacionAction.isPrimerAcceso())
				admConfirmacionAction.refrescarLista();

		} else {
			admconfirmacionesAction.addFromResourceBundleStatusMessage(
					Severity.ERROR, "admconfirmaciones.error.altaincorrecta",
					confOperacion.getVista().getNcorrEstructu());

			try {
				facesTransactionEvents.setTransactionFailedMessageEnabled(false);
//				mostrarMensajeErrorTX = false;
				Transaction.instance().setRollbackOnly();
			} catch (IllegalStateException e) {
				throw new SQLException(e.toString());
			} catch (SystemException e) {
				throw new SQLException(e.toString());
			}
		}
	}

//	boolean mostrarMensajeErrorTX = true;
//
//	@Observer(Transaction.TRANSACTION_FAILED)
//	public void controlMensajeErrorTransaccion(int status) {
//		if (!mostrarMensajeErrorTX) {
//			mostrarMensajeErrorTX ^= true;
//			statusMessages.clear();
//		}
//	}

	/**
	 * ALTA
	 */
	public boolean alta;
	
	public boolean isAlta() {
		return alta;
	}
	public void setAlta(boolean alta) {
		this.alta = alta;
	}
	/**
	 * metodo para cargar el caso de uso alta ,instanciado al objeto conf y
	 * seteando a true el flag alta
	 */
	public void altaConfirmacion() {
		setModoPantalla(ModoPantalla.CREACION);
		setProductoContable("");
		producat=null;
		setContrapartidaNif("");
		idiomaPantalla = new Idioma();
		canalPantalla = new CanalConfirmacion();

		setListaCanales(null);
		setListaIdiomas(null);
		alta = true;
		altacopia = false;
		datosconfirm = false;
		confOperacion = new ConfOperacion();
		confOperacion.setSentidoConfirmacion("E");

		modoDetalle = ModoDetalle.ALTA.toString();
		detalleConfirmacion();

		if (admconfirmacionesAction != null)
			admconfirmacionesAction.setRedireccionExterna(true);
	}
	/**
	 * ALTA CON COPIA
	 */
	public boolean altacopia = false;
	
	public boolean isAltacopia() {
		return altacopia;
	}
	public void setAltacopia(boolean altacopia) {
		this.altacopia = altacopia;
	}
	/**
	 * Outjection del objeto para casos de uso alta con copia y datos confirmacion
	 */
	//@Out(required = false)
//	protected ConfOperacion cOperacion;
//	public ConfOperacion getcOperacion() {
//		return cOperacion;
//	}
//	public void setcOperacion(ConfOperacion cOperacion) {
//		this.cOperacion = cOperacion;
//	}
	/**
	 * Metodo que realiza una copia del objeto desde que se clica el link en la tabla de confirmaciones
	 * @throws IllegalAccessException
	 * @throws InstantiationException
	 * @throws InvocationTargetException
	 * @throws NoSuchMethodException
	 * 
	 */
	public void altaConCopia() throws IllegalAccessException, InstantiationException, InvocationTargetException, NoSuchMethodException{
		altacopia = true;
		alta = false;
		datosconfirm = false;

		
		ConfOperacion confOperacion2;
		ConfOperacion cOperacion;
				
		tipocontr = null;
		String producat = null;
		String nif = null;
		Producto producto = null;
		//Nada mas llegar obtengo la operacion a copiar y la copio en COPERACION directamente
		confOperacion2 = admConfirmacionAction.getAdmConfirmacionesPantalla().getAdmconfirmacionSelec();
		//Ojo, esto es peligroso, hay que tener cuidado con los objetos de dentro pues no se clonan
		cOperacion=new ConfOperacion();

		//BeanUtils.copyProperties( cOperacion, confOperacion2 );
		//Manual
		
		cOperacion.setNumConfirmacion(null);
		
		cOperacion.setFechaContratacion(confOperacion2.getFechaContratacion());
		cOperacion.setDocumentoConfirmacion(confOperacion2.getDocumentoConfirmacion());
		cOperacion.setPlantillasConfirmacion(cOperacion.getPlantillasConfirmacion());
		cOperacion.setIdEstructConfirmada(confOperacion2.getIdEstructConfirmada());
		cOperacion.setSentidoConfirmacion (confOperacion2.getSentidoConfirmacion());
		cOperacion.setFechaAlta (confOperacion2.getFechaAlta());

		//		cOperacion.setFechaConfirmacion(confOperacion2.getFechaConfirmacion());
		
		cOperacion.setDescripcionEstadoConfirmacion(confOperacion2.getDescripcionEstadoConfirmacion());
		cOperacion.setConfirmReclamada (null);
		cOperacion.setModelcon (confOperacion2.getModelcon());
		cOperacion.setTipoConfirmacion (confOperacion2.getTipoConfirmacion());
		cOperacion.setEventoConfirmacion (confOperacion2.getEventoConfirmacion());
		cOperacion.setFechaLiquidacion (confOperacion2.getFechaLiquidacion());
		cOperacion.setTipoOperacion (confOperacion2.getTipoOperacion());
		cOperacion.setFInicioTramo(confOperacion2.getFInicioTramo());
		cOperacion.setFFinTramo(confOperacion2.getFFinTramo());
		cOperacion.setConcepto (confOperacion2.getConcepto());
		cOperacion.setTipoConcepto (confOperacion2.getTipoConcepto());
		cOperacion.setIdSwift (confOperacion2.getIdSwift());
		cOperacion.setObservaciones (confOperacion2.getObservaciones());
		cOperacion.setIndiconf (confOperacion2.getIndiconf());
		cOperacion.setRutaconf (confOperacion2.getRutaconf());
		cOperacion.setProducat(confOperacion2.getProducat());
		cOperacion.setIdPlantillaConfirmacion(confOperacion2.getIdPlantillaConfirmacion());
		cOperacion.setIdioma(confOperacion2.getIdioma());
		cOperacion.setCanalConfirmacion(confOperacion2.getCanalConfirmacion());
		
//		cOperacion.setIdDocDMS(confOperacion2.getIdDocDMS());
		
		cOperacion.setOperacion(confOperacion2.getOperacion());
		cOperacion.setOperacionID(confOperacion2.getOperacionID());
		
		cOperacion.setEstructura(confOperacion2.getEstructura());
		
		confOperacion2=null;
		confOperacion = cOperacion;

		modoDetalle = ModoDetalle.ALTA_CON_COPIA.toString();
		detalleConfirmacion();

		calcularPdtoCatCotnrapa();
		cargarIdiomasCanales();

		if (confOperacion.getVista()!=null && confOperacion.getVista().getProductoCatalogo()!=null){
		
		campos.get("pdtoCatalogo").setValue(
				confOperacion.getVista().getProductoCatalogo().getDescprod());
		}
		
		campos.get("pdtoContable").setValue(getProductoContable());

		initCanalConfirmacion();
		initIdioma();
		cargaEstadoConfirmacion();

		activarBotones();

		if (admconfirmacionesAction != null)
			admconfirmacionesAction.setRedireccionExterna(true);
	}

	/**
	 * Inicializa el campo canalConfirmacion con el valor de la confirmación de
	 * entre la lista de canales.
	 */
	private void initCanalConfirmacion() {

		if (confOperacion.getCanalConfirmacion() != null) {

			for (CanalConfirmacion cc : listaCanales) {

				if (GenericUtils.equals(confOperacion
						.getCanalConfirmacion(), cc.getId().getCodcanal())) {

					campos.get("canalConfirmacion").setValue(canalPantalla = cc);

					break;
				}
			}
		}
	}

	/**
	 * Inicializa el campo del idioma con el valor de la confirmación de entre
	 * la lista de idiomas.
	 */
	private void initIdioma() {

		if (GenericUtils.isNullOrEmpty(listaIdiomas)
				|| confOperacion.getIdioma() == null) {
			return;
		}

		for (Idioma idioma : listaIdiomas) {

			if (idioma.getCodigo()
					.equals(confOperacion.getIdioma().getCodigo())) {

				confOperacion.setIdioma(idioma);

				break;
			}
		}
	}

	/**
	 * Metodo que realiza el tratamiento de la id de confirmacion CODCONFI una
	 * vez se acepta en la pantalla gestionConfirmaciones.
	 * 
	 * @throws SQLException
	 */
	public void altaCopiaAccion() throws SQLException {

		if (idiomaPantalla != null)
			confOperacion.setIdioma(idiomaPantalla);

		if (canalPantalla != null)
			confOperacion.setCanalConfirmacion(canalPantalla.getId().getCodcanal());

		// Obtendremos PLACONFI.CODPLANT partir de PRODUCAT, EVENCONF e
		// IDIOMACO.

		PlantillasConfirmacion plantillasConfirmacion = null;
		if (!GenericUtils.isNullOrBlank(confOperacion.getIdioma())
				&& !GenericUtils.isNullOrBlank(confOperacion.getEventoConfirmacion())
				&& !GenericUtils.isNullOrBlank(confOperacion.getProducat())) {

			//SMM 27/05/2013
			String tipoPlan=null;
			if (EventoConfirmacion.FIJACION.equals(confOperacion.getEventoConfirmacion().getCodigo())){
				tipoPlan = admconfirmacionesBo.obtenerTipoPlan(confOperacion.getOperacionID(),
					confOperacion.getFechaContratacion(),confOperacion.getFechaLiquidacion());
				
				plantillasConfirmacion = admconfirmacionesBo
				.obtenerPlantillasConfirmacion(Long.parseLong(confOperacion
						.getProducat()), confOperacion
						.getEventoConfirmacion().getCodigo(), confOperacion
						.getIdioma().getCodigo(), tipoPlan);
			
			}else if (GenericUtils.isNullOrBlank(confOperacion.getOperacionID())){
				//ESTRUCTURA CAL MIRAR TIPOPLAN

				tipoPlan = admconfirmacionesBo.obtenerTipoPlanEstructura(confOperacion.getIdEstructConfirmada(),
						confOperacion.getFechaContratacion());
					
					plantillasConfirmacion = admconfirmacionesBo
					.obtenerPlantillasConfirmacion(Long.parseLong(confOperacion
							.getProducat()), confOperacion
							.getEventoConfirmacion().getCodigo(), confOperacion
							.getIdioma().getCodigo(), tipoPlan);
			}else{

			
			plantillasConfirmacion = admconfirmacionesBo.obtenerPlantillasConfirmacion(Long
					.decode(confOperacion.getProducat()), confOperacion.getEventoConfirmacion()
					.getCodigo(), confOperacion.getIdioma().getCodigo());
			}
		}

		if (!GenericUtils.isNullOrBlank(plantillasConfirmacion)) {

			confOperacion.setIdPlantillaConfirmacion(plantillasConfirmacion.getId().getCodplant());
		}

		confOperacion.setTipoConfirmacion("M");

		// Limpieza...
		confOperacion.setVista(null);

		String respuestaCancelarFD = admconfirmacionesBo.aceptarAlta(confOperacion,admconfirmacionesAction.getProxyGrantingTicket());
		if(!respuestaCancelarFD.equals("")){
			if(respuestaCancelarFD.equals("OK")){
				admconfirmacionesAction.addFromResourceBundleStatusMessage(Severity.INFO,
						"admconfirmaciones.firmadigital.cancelacion.ok");
			}else if(respuestaCancelarFD.equals("KO")){
				admconfirmacionesAction.addFromResourceBundleStatusMessage(Severity.INFO,
				"admconfirmaciones.firmadigital.cancelacion.error");
			}
			else{
				admconfirmacionesAction.addStatusMessage(Severity.INFO,
						"Servicio de cancelación Firma Digital. "+respuestaCancelarFD);
			}
		}
		admconfirmacionesBo.flush();

		final Integer result = admconfirmacionesBo.altaConfirmacion(confOperacion
				.getNumConfirmacion());

		admconfirmacionesBo.recargar(confOperacion);

		if (result == 0 || result == 2) {

			admconfirmacionesAction.addFromResourceBundleStatusMessage(Severity.INFO,
					"admconfirmaciones.altaCopia.ok",
					confOperacion.getNumConfirmacion().toString(), confOperacion.getVista()
							.getNcorrEstructu());

			if (!admConfirmacionAction.isPrimerAcceso())
				admConfirmacionAction.refrescarLista();

			altacopia = false;

		} else {
			admconfirmacionesAction.addFromResourceBundleStatusMessage(Severity.ERROR,
					"admconfirmaciones.altaCopia.error", confOperacion.getVista()
							.getNcorrEstructu());

			try {
				facesTransactionEvents.setTransactionFailedMessageEnabled(false);
				Transaction.instance().setRollbackOnly();
			} catch (IllegalStateException e) {
				throw new SQLException(e.toString());
			} catch (SystemException e) {
				throw new SQLException(e.toString());
			}
		}
	}

	/**
	 * DATOS CONFIRMACION
	 */
	
	public boolean datosconfirm = false;
	


	public boolean isDatosconfirm() {
		return datosconfirm;
	}

	public boolean isDatosconfirmDisable() {
		if (datosconfirm){
			if ( estadoPRDEREPBindNull(confOperacion)  )
				return true;
			else 
				return false;
		} 	else
			return true;
		
	}
	
	public void setDatosconfirm(boolean datosconfirm) {
		this.datosconfirm = datosconfirm;
	}

	/**
	 * metodo para cargar Datos Conf con el objeto seleccionado cen el link de
	 * acciones de la lista
	 */
	public void datosConfirmacion() {

		datosconfirm = true;
		alta = false;
		altacopia = false;

		ConfOperacion cOperacion = admConfirmacionAction.getAdmConfirmacionesPantalla().getAdmconfirmacionSelec();
		
		setConfOperacion(cOperacion);

		calcularPdtoCatCotnrapa(); //esto es para asegurar que se muestra pdto catalogo y contrapa

		modoDetalle = ModoDetalle.DATOS_CONF.toString();
		detalleConfirmacion();

		cargarIdiomasCanales();

		String tipoCGB = null;
		if (contrapartida!=null)
			tipoCGB = cargarTipoContrapartidaGrupoBancario(contrapartida
				.getGrupoBancario().getId());

		if (cOperacion.getCanalConfirmacion() != null && tipoCGB != null) {

			canalPantalla = admconfirmacionesBo.obtenerCanal(cOperacion
					.getCanalConfirmacion(), cOperacion.getEventoConfirmacion()
					.getCodigo(), cOperacion.getSentidoConfirmacion(), tipoCGB);

			// Canal Manual a muerte
			if (canalPantalla == null) {
				canalPantalla = obtenerCanal(CanalOperacion.MANUAL_MANUAL
						.toString());
			}

			confOperacion.setCanalConfirmacion(canalPantalla.getId()
					.getCodcanal());
		} else {
			canalPantalla = null;
			confOperacion.setCanalConfirmacion(null);
		}

		if (GenericUtils.equals(cOperacion.getEstadoConfirmacion(),
				EstadoConfirmacion.PDTE_RECIBIR_CONFIRMACION)) {

			campos.get("idiomaConfirmacion").setDisabled(true);
		}

		initCanalConfirmacion();
		initIdioma();
		cargaEstadoConfirmacion();

//		admConfirmacionesPantalla.setPdtoContable(oper.getProducto());

		if (confOperacion.getVista().getProductoCatalogo()!=null){
			campos.get("pdtoCatalogo").setValue(
					confOperacion.getVista().getProductoCatalogo().getDescprod());
			
		}

		if (admconfirmacionesAction != null)
			admconfirmacionesAction.setRedireccionExterna(true);
	}

	
	/**
	 * metodo para cargar Datos Conf en modo consulta con el objeto seleccionado cen el link de
	 * acciones de la lista
	 */
	public void consultaConfirmacion() {

		this.modoPantalla = ModoPantalla.INSPECCION;
		datosConfirmacion();
	}
	
	public void modificaConfirmacion() {

		this.modoPantalla = ModoPantalla.EDICION;
		datosConfirmacion();
	}

	/**
	 * metodo para guardar los cambios al objeto
	 */
	public void guardarDatosConfirmacion() {
		//boolean insertarEvento = !GenericUtils.nvl(confOperacion.getIndicadorSinFirma(),"N").equals(campos.get("identificadorSinFirmas").getValue());
		
		if (canalPantalla != null)
			confOperacion.setCanalConfirmacion(canalPantalla.getId()
					.getCodcanal());

		confOperacion.setIndicadorSinFirma(GenericUtils.SNBoolean((Boolean) campos.get("identificadorSinFirmas").getValue()));
		admconfirmacionesBo.guardarDatosConfirmacion(confOperacion);
		admconfirmacionesBo.flush();
		datosconfirm = false;
		

		if (getIsModificable())
			try {
				admconfirmacionesBo.altaConfirmacion(confOperacion.getNumConfirmacion());
			} catch (SQLException e) {
				e.printStackTrace();
			}
			
		admconfirmacionesBo.recargar(confOperacion);
		admconfirmacionesAction.addFromResourceBundleStatusMessage(
				Severity.INFO, "admconfirmaciones.guardarDatosConfirmacion.ok",
				confOperacion.getNumConfirmacion(), confOperacion.getVista()
						.getNcorrEstructu());
		admConfirmacionAction.refrescarLista();
	} 
	
	
	
	
	/**
	 * Objeto HistoricoOperacion para outjectar a MANTOPER
	 */
	@Out(required = false)
	HistoricoOperacion hOperacion;
	
	public HistoricoOperacion gethOperacion() {
		return hOperacion;
	}

	public void sethOperacion(HistoricoOperacion hOperacion) {
		this.hOperacion = hOperacion;
	}

	/**
	 * metodo para integrar con MANTOPER
	 */
//	public void detalle(){
//		hOperacion =admconfirmacionesBo.obtenerHistoricoOperacion( admConfirmacionAction.getAdmConfirmacionesPantalla().getAdmconfirmacionSelec().getOperacionID(),
//				admConfirmacionAction.getAdmConfirmacionesPantalla().getAdmconfirmacionSelec().getFechaContratacion()); 
//	}
	
	/**
	 * Lista para cargar los canales segun evenconf,sentodo y tipocontrapartida
	 */
	public List<CanalConfirmacion> listaCanales;
	
	public List<CanalConfirmacion> getListaCanales() {
		return listaCanales;
	}

	public void setListaCanales(List<CanalConfirmacion> listaCanales) {

		if (listaCanales == null) {
			this.listaCanales = null;
			return;
		}

		// Eliminación de duplicados (por descripción)

		final Map<String, CanalConfirmacion> map = new TreeMap<String, CanalConfirmacion>();
		for (CanalConfirmacion cc : listaCanales)
			map.put(cc.getDescanal(), cc);

		this.listaCanales = new ArrayList<CanalConfirmacion>(map.values());
	}

	/**
	 * Lista para cargar los idiomas a paritr de producat y evenconf
	 */
	public List<Idioma> listaIdiomas;

	public List<Idioma> getListaIdiomas() {
		return listaIdiomas;
	}

	public void setListaIdiomas(List<Idioma> listaIdiomas) {
		this.listaIdiomas = listaIdiomas;
	}
	
	
	
	
	
	
	
    /**
     * variables de contexto Integra con MANTANEX
     */
	@Out(required=false)
	private String modoTratamiento;
	
	@Out(required=false)
	private String tipoAnexo;
	
	/**
	 * metodo para Intgracion con MANTANEX
	 */
	public String anexos(){
		if(ModoPantalla.CREACION.equals(this.modoPantalla)) {
			modoTratamiento = Constantes.TIPOANEXO_MODO_A;
		} else if(ModoPantalla.EDICION.equals(this.modoPantalla)) {
			modoTratamiento = Constantes.TIPOANEXO_MODO_E;
		} else {
			modoTratamiento = Constantes.TIPOANEXO_MODO_C;
		}
		//si estamos en este estado es modo consulta este quien este
//		if ( estadoPRDEREPBindNull(confOperacion)    ) {
//			modoTratamiento = Constantes.TIPOANEXO_MODO_C;
//		}
		
		tipoAnexo = Constantes.TIPOANEXO_CONFIRMACION;
		confOperacionSelect =  confOperacion  ; //admConfirmacionAction.getAdmConfirmacionesPantalla().getAdmconfirmacionSelec();
		return "anexos";
	}
	
	/**
	 * metodo para eliminar de la lista de canales los canales BF,BE,BM
	 */
	public List<CanalConfirmacion> eliminarBFBEBM(List<CanalConfirmacion> list){
		List<CanalConfirmacion> listElimBFBEBM = null;
		List<CanalConfirmacion> listaux = new ArrayList<CanalConfirmacion>();
		for (CanalConfirmacion canalConfirmacion : list){
			listaux.add(canalConfirmacion);
			if (("BF").equals(canalConfirmacion.getId()) || ("BE").equals(canalConfirmacion.getId()) || ("BM").equals(canalConfirmacion.getId())){
				listaux.remove(canalConfirmacion);
			}
		}
		listElimBFBEBM = listaux;
		return listElimBFBEBM;
	}
//	/**
//	 * metodo para obtener tipocontrapartida
//	 * a partir de la Confirmacion
//	 */
//	public String obtenerTipoContrapartida(ConfOperacion confOperacion){
//		
//		final HistoricoOperacion oper = admconfirmacionesBo
//				.obtenerHistoricoOperacion(confOperacion.getOperacionID(),
//						confOperacion.getFechaContratacion());
//		final AbstractContrapartida a = entityUtil.unwrapProxy(oper
//				.getContrapartida(), AbstractContrapartida.class);
//
//		if (!(a instanceof Contrapartida)) {
//			statusMessages.add(Severity.ERROR,
//					"Esta contrapartida no tiene tipo contrapartida asociado");
//		} else {
//
//			Contrapartida b = (Contrapartida) a;
//			this.setContrapartida(b);
//
//			if (b != null
//					&& b.getTipoContrapartida() instanceof TipoContrapartida) {
//
//				final TipoContrapartida tipoContrapartida = b
//						.getTipoContrapartida();
//
//				if (tipoContrapartida != null)
//					tipocontr = tipoContrapartida.getId();
//			}
//		}
//
//		return tipocontr;
//	}

	public boolean isCanalDisabled() {
		return canalDisabled;
	}

	public void setCanalDisabled(boolean canalDisabled) {
		this.canalDisabled = canalDisabled;
		campos.get("canalConfirmacion").setDisabled(canalDisabled);
	}

	public boolean isTipoConfDisabled() {
		return tipoConfDisabled;
	}

	public void setTipoConfDisabled(boolean tipoConfDisabled) {
		this.tipoConfDisabled = tipoConfDisabled;
	}

	public boolean isFechaLiqDisabled() {
		return fechaLiqDisabled;
	}

	public void setFechaLiqDisabled(boolean fechaLiqDisabled) {
		this.fechaLiqDisabled = fechaLiqDisabled;
	}

	public boolean isSentidoConfDisabled() {
		return sentidoConfDisabled;
	}

	public void setSentidoConfDisabled(boolean sentidoConfDisabled) {
		this.sentidoConfDisabled = sentidoConfDisabled;
	}

	public boolean isIdiomaDisabled() {
		return idiomaDisabled;
	}

	public void setIdiomaDisabled(boolean idiomaDisabled) {
		this.idiomaDisabled = idiomaDisabled;
		campos.get("idiomaConfirmacion").setDisabled(idiomaDisabled);
	}

	public boolean isObservacionesDisabled() {
		return observacionesDisabled;
	}

	public void setObservacionesDisabled(boolean observacionesDisabled) {
		this.observacionesDisabled = observacionesDisabled;
	}

	public boolean isReadyAceptar() {
		return (isAlta()) ? readyAceptar : true;
	}
	public String obtenerDescripcionEstado (String codigo){
	if(GenericUtils.isNullOrBlank(codigo)){
		return Constantes.CADENA_VACIA;
	} else {
		return admconfirmacionesBo.obtenerDescripcionEstado(codigo);
	}
	}


	// /////////////////////////////////////////////////////////////////////////
	// MIGRACION GestionConfirmacionAction.java
	// /////////////////////////////////////////////////////////////////////////

	enum ModoDetalle {
		ALTA, ALTA_CON_COPIA, DATOS_CONF;
	}

	String modoDetalle;
	private String detalleHeader = "";
	private boolean aceptarDetalleDisabled = true;
	private boolean operEstrSupportRendered = true;
	@In("messages")
	private Map<String, String> messages;

	@Out
	private Campo<Date> fechaLiquidacion = new Campo<Date>();

	@Out
	private Campo<Long> operEstr = new Campo<Long>();

	@Out
	private Boton aceptarBoton = new Boton();

	@Out
	private Boton infoanexaBoton = new Boton();
 
	@Out("campos")
	private Map<String, Campo<Object>> campos = new HashMap<String, Campo<Object>>() {

		private static final long serialVersionUID = 1L;

		public Campo<Object> get(Object key) {

			log.debug("get() key::" + key);

			return super.get(key);
		};
	};
/*
	public static class Campo {

		private boolean disabled;
		private boolean rendered;
		private boolean required;
		private Object value;

		public static void setDisabled(boolean disabled, Campo... campos) {
			for (Campo campo : campos)
				campo.setDisabled(disabled);
		}

		public Campo() {
			this(null);
		}

		public Campo(Object value) {
			this(value, false);
		}

		public Campo(Object value, boolean disabled) {
			this(value, disabled, false);
		}

		public Campo(Object value, boolean disabled, boolean required) {
			this(value, disabled, required, true);
		}

		public Campo(Object value, boolean disabled, boolean required,
				boolean rendered) {

			super();

			setValue(value);
			setDisabled(disabled);
			setRequired(required);
			setRendered(rendered);
		}

		public boolean isRendered() {
			return rendered;
		}

		public void setRendered(boolean rendered) {
			this.rendered = rendered;
		}

		public Object getValue() {
			return value;
		}

		@SuppressWarnings("unchecked")
		protected <T> T getCastedValue() {
			return (T) value;
		}

		public Long getValueAsLong() {

			if (value instanceof Long) {
				return getCastedValue();
			} else if (value instanceof String) {
				return new Long((String) value);
			}

			throw new IllegalArgumentException("value.getClass()::"
					+ value.getClass());
		}

		public Date getValueAsDate() throws ParseException {

			if (value instanceof Date) {
				return getCastedValue();
			} else if (value instanceof String) {
				return new SimpleDateFormat(Constantes.DDMMYYYY)
						.parse((String) value);
			}

			throw new IllegalArgumentException("value.getClass()::"
					+ value.getClass());
		}

		public void setValue(Object value) {
			this.value = value;
		}

		public boolean isRequired() {
			return required;
		}

		public void setRequired(boolean required) {
			this.required = required;
		}

		public boolean isDisabled() {
			return disabled;
		}

		public void setDisabled(boolean disabled) {
			this.disabled = disabled;
		}

		@Override
		public String toString() {

			final StringBuilder sb = new StringBuilder(super.toString());
			sb.append(" disabled:").append(disabled);
			sb.append(" rendered:").append(rendered);
			sb.append(" required:").append(required);
			sb.append(" value:").append(value);

			return sb.toString();
		}
	}
*/
	public void calcularConfirmacion() {

		final long operEstrValue;
		try {
			operEstrValue = (Long) campos.get("operEstr").getValue();

		} catch (Exception e) {

			log.debug(e);
			return;
		}

		if (confOperacion.getFechaContratacion() == null)
			return;

		confOperacion.setFechaAlta(new Date());
		final boolean botonesHabilitados;

		if ("O".equals(seleccionar)) {

			confOperacion.setOperacionID(operEstrValue);
			botonesHabilitados = calcularPdtoCatCotnrapaOp();

		} else if ("E".equals(seleccionar)) {

			confOperacion.setIdEstructConfirmada(operEstrValue);
			botonesHabilitados = calcularPdtoCatCotnrapaEstructura();
		} else {
			throw new IllegalStateException();
		}

		campos.get("pdtoContable").setValue(getProductoContable());
		if (!GenericUtils.isNullOrBlank(confOperacion) 
				&&  !GenericUtils.isNullOrBlank(confOperacion.getVista()) 
				&&  !GenericUtils.isNullOrBlank(confOperacion.getVista().getProductoCatalogo())) {
			
			campos.get("pdtoCatalogo").setValue(
					confOperacion.getVista().getProductoCatalogo().getDescprod());
				
		}
		campos.get("contrapartida").setValue(getContrapartidaNif());
		confOperacion.setEventoConfirmacion(null);

		if (botonesHabilitados){
			activarBotones();
			
			if (null!=contrapartida && !GenericUtils.isNullOrBlank(contrapartida.getIndBloqueo()) && "S".equalsIgnoreCase(contrapartida.getIndBloqueo())){
				messageBoxGestConfirmacionAction = new MessageBoxAction();
				messageBoxGestConfirmacionAction.init("admconfirmaciones.messages.contrapartida.bloqueada.texto", "gestionConfirmacionAction.voidFunction()", null,"messageBoxPanelContrapa");
			}
		}
		else
			desActivarBotones();

		aceptarBoton.setEnabled(false);
		campos.get("canalConfirmacion").setDisabled(true);
		campos.get("canalConfirmacion").setValue(null);
		campos.get("idiomaConfirmacion").setDisabled(true);
		campos.get("idiomaConfirmacion").setValue(null);

		// cargarListasIdiomaCanales()	;

		
	}
	
	public void detalleConfirmacion() {
		setIsModificable(true);
		if (GenericUtils.isNullOrBlank(modoDetalle)) {

			admconfirmacionesAction.addStatusMessage(StatusMessage.Severity.ERROR,
					"Modo detalle no definido");

			return;
		}

		if (ModoDetalle.ALTA.toString().equals(modoDetalle)) {

			detalleHeader = messages.get("admconfirmaciones.alta.titulo");

			campos.put("message_fechaLiquidacion", new Campo(messages
					.get("admconfirmaciones.fechaliquidacion")));

			campos.put("operEstr", new Campo(null, true, true));
			campos.put("fechaOper", new Campo(null, true, true));
			campos.put("pdtoContable", new Campo(null, false));

			if ("O".equals(seleccionar)) {

				campos.put("fechaAlta", new Campo(new Date(), false));

			} else if ("E".equals(seleccionar)) {

				campos.put("fechaAlta", new Campo(new Date(), true, false, false));
			}

			campos.put("fechaConfirmacion", new Campo(null, false));
			campos.put("pdtoCatalogo", new Campo(null, false));
			campos.put("contrapartida", new Campo(null, false));
			campos.put("tipoConfirmacion", new Campo(null, false, true));
			fechaLiquidacion.setEnabled(false);
			campos.put("sentidoConfirmacion", new Campo("E", false));
			campos.put("idiomaConfirmacion", new Campo(null, false));
			campos.put("estadoAlta", new Campo(null, false));
			campos.put("canalConfirmacion", new Campo(null, false, true));
			campos.put("observacionesAlta", new Campo(null, false));
			
			//SMM 06/2013
			campos.put("clavedms", new Campo(null, false, false));
			campos.put("idedocum", new Campo(null, false, false));
		
			infoanexaBoton.setEnabled(false);
			aceptarBoton.setEnabled(false);

		} else if (ModoDetalle.ALTA_CON_COPIA.toString().equals(modoDetalle)) {

			// confOperacion = confOperacion;

			detalleHeader = messages.get("admconfirmaciones.altaconcopia.titulo");

			// Por defecto
			campos.put("message_fechaLiquidacion", new Campo(messages
					.get("admconfirmaciones.fechaliquidacion")));

			if (GenericUtils.equals(confOperacion.getTipoConfirmacion(), "M")) {

				campos.put("message_fechaLiquidacion", new Campo(messages
						.get("admconfirmaciones.fechamodificacion")));

			} else if (GenericUtils.in(confOperacion.getTipoConfirmacion(), "L", "X")) {

				campos.put("message_fechaLiquidacion", new Campo(messages
						.get("admconfirmaciones.fechaliquidacion")));
			}

			if (confOperacion.getOperacionID() != null) {

				campos.put("operEstr", new Campo(confOperacion.getOperacionID(), false, false));
			} else {
				campos.put("operEstr", new Campo(confOperacion.getIdEstructConfirmada(), false,
						false));
			}

			campos.put("fechaOper", new Campo(confOperacion.getFechaContratacion(), false, false));
			campos.put("pdtoContable", new Campo(null, false));
			campos.put("fechaAlta", new Campo(confOperacion.getFechaAlta(), false));
			campos.put("fechaConfirmacion", new Campo(confOperacion.getFechaConfirmacion(), false));

			// value="#{gestionConfirmacionAction.confOperacion.vista.productoCatalogo.descprod}"
			campos.put("pdtoCatalogo", new Campo(null, false));
			//SMM
			if (confOperacion.getOperacion() != null) {
			campos.put("contrapartida", new Campo(confOperacion.getOperacion().getContrapartida()
					.getId(), false));
			}else if (confOperacion.getEstructura() != null) {
				campos.put("contrapartida", new Campo(confOperacion.getEstructura().getContrapartida()
						.getId(), false));	
			}
			
			campos.put("tipoConfirmacion", new Campo(confOperacion.getEventoConfirmacion(), false,
					true));

			fechaLiquidacion.setEnabled(GenericUtils.in(confOperacion.getEventoConfirmacion()
					.getCodigo(), EventoConfirmacion.FIJACION, EventoConfirmacion.LIQUIDACION));

			fechaLiquidacion.setRequired(!fechaLiquidacion.isDisabled());
			
			campos.put("sentidoConfirmacion", new Campo(confOperacion.getSentidoConfirmacion(),
					false));
			campos.put("idiomaConfirmacion", new Campo(confOperacion.getIdioma(), false));
			campos.put("estadoAlta", new Campo(confOperacion.getDescripcionEstadoConfirmacion()
					.getDescripcion(), false));
			campos.put("canalConfirmacion", new Campo(null, false, true));
			campos.put("observacionesAlta", new Campo(confOperacion.getObservaciones(), false));
			
			//SMM 06/2013
			campos.put("clavedms", new Campo(null, false, false));
			campos.put("idedocum", new Campo(null, false, false));
		
			infoanexaBoton.setEnabled(false);
			aceptarBoton.setEnabled(false);

		} else if (ModoDetalle.DATOS_CONF.toString().equals(modoDetalle)) {

			// this.confOperacion = confOperacion;

			detalleHeader = messages.get("admconfirmaciones.datosconfirmacion.titulo");

			// Por defecto
			campos.put("message_fechaLiquidacion", new Campo(messages
					.get("admconfirmaciones.fechaliquidacion")));

			if (GenericUtils.equals(confOperacion.getTipoConfirmacion(), "M")) {

				campos.put("message_fechaLiquidacion", new Campo(messages
						.get("admconfirmaciones.fechamodificacion")));

			} else if (GenericUtils.in(confOperacion.getTipoConfirmacion(), "L", "X")) {

				campos.put("message_fechaLiquidacion", new Campo(messages
						.get("admconfirmaciones.fechaliquidacion")));
			}

			if (confOperacion.getOperacionID() != null) {
				campos.put("operEstr", new Campo(confOperacion.getOperacionID(), false, false));
			} else {
				campos.put("operEstr", new Campo(confOperacion.getIdEstructConfirmada(), false,
						false));
			}

			campos.put("fechaOper", new Campo(confOperacion.getFechaContratacion(), false));

			final HistoricoOperacion oper = admconfirmacionesBo.obtenerHistoricoOperacion(
					confOperacion.getOperacionID(), confOperacion.getFechaContratacion());

			if (oper!=null){
				campos.put("pdtoContable", new Campo(oper.getProducto().getDescripcion(), false));	
			}else if (confOperacion.getEstructura()!=null){
				campos.put("pdtoContable", new Campo(confOperacion.getEstructura().getProducto().getDescripcion(), false));
			}
			
			campos.put("fechaAlta", new Campo(confOperacion.getFechaAlta(), false));
			campos.put("fechaConfirmacion", new Campo(confOperacion.getFechaConfirmacion(), false));
			campos.put("pdtoCatalogo", new Campo(null, false));

			if (confOperacion.getOperacion() != null) {
				campos.put("contrapartida", new Campo(confOperacion.getOperacion()
						.getContrapartida().getId(), false));
			}else if (confOperacion.getEstructura() != null) {
				campos.put("contrapartida", new Campo(confOperacion.getEstructura().getContrapartida()
						.getId(), false));	
			}

			campos.put("tipoConfirmacion", new Campo(confOperacion.getEventoConfirmacion(), false));
			fechaLiquidacion = new Campo(confOperacion.getFechaLiquidacion(), false, false);
			campos.put("sentidoConfirmacion", new Campo(confOperacion.getSentidoConfirmacion(),
					false));
			
			if(GenericUtils.in(confOperacion.getEstadoConfirmacion(),EstadoConfirmacion.PENDIENTE_BATCH, EstadoConfirmacion.PENDIENTE_CONFIRMAR,EstadoConfirmacion.PDTE_RECIBIR_CONFIRMACION)){
				setIsModificable(true);
			}
			else{
				setIsModificable(false);
			}
			
			campos.put("idiomaConfirmacion", new Campo(confOperacion.getIdioma(), getIsModificable()));
			campos.put("estadoAlta", new Campo(confOperacion.getDescripcionEstadoConfirmacion()
					.getDescripcion(), false));
			campos.put("canalConfirmacion", new Campo(null, getIsModificable(), true));
			campos.put("observacionesAlta", new Campo(confOperacion.getObservaciones(), getIsModificable()));
			campos.put("identificadorSinFirmas", new Campo(GenericUtils.SNBoolean(GenericUtils.nvl(confOperacion.getIndicadorSinFirma(),"N")), getIsModificable()));
			
			if (GenericUtils.in(confOperacion.getCanalConfirmacion(),
					CanalOperacion.ON_LINE_FAX, CanalOperacion.ON_LINE_EMAIL,
					CanalOperacion.ON_LINE_MANUAL, CanalOperacion.URGENTE)){
				campos.get("identificadorSinFirmas").setRendered(true & getIsModificable());		
			}else{
				campos.put("identificadorSinFirmas", new Campo(false, false));
				campos.get("identificadorSinFirmas").setRendered(false);
			}

			//SMM 06/2013
			campos.put("clavedms", new Campo(confOperacion.getIdDocDMS(), false, false));
			campos.put("idedocum", new Campo(confOperacion.getIdeDocum(), false, false));
		

			infoanexaBoton.setEnabled(true);
			aceptarBoton.setEnabled(true);

			cargaEstadoConfirmacion();

		} else {

			admconfirmacionesAction.addStatusMessage(StatusMessage.Severity.ERROR,
					"Modo detalle mal definido");

			return;
		}
	}

	public void aceptarDetalle() throws SQLException {

		if (GenericUtils.isNullOrBlank(modoDetalle)) {

			admconfirmacionesAction.addStatusMessage(StatusMessage.Severity.ERROR,
					"Modo detalle no definido");

			return;
		}

		if (ModoDetalle.ALTA.toString().equals(modoDetalle)) {

			final CanalConfirmacion canalConfirmacion = (CanalConfirmacion) campos
					.get("canalConfirmacion").getValue();

			if (canalConfirmacion != null) {
				confOperacion.setCanalConfirmacion(canalConfirmacion.getId()
						.getCodcanal());
			}

			aceptar();
		} else if (ModoDetalle.ALTA_CON_COPIA.toString().equals(modoDetalle)) {
			altaCopiaAccion();
		} else if (ModoDetalle.DATOS_CONF.toString().equals(modoDetalle)) {
			guardarDatosConfirmacion();
		} else {

			admconfirmacionesAction.addStatusMessage(StatusMessage.Severity.ERROR,
					"Modo detalle mal definido");

			return;
		}
	}

	/**
	 * Devuelve el objeto {@link CanalConfirmacion} asociado con el codcanal.
	 * 
	 * @param codcanal
	 * @return <code>null</code> en caso que no se encuentre ninguno.
	 */
	private CanalConfirmacion obtenerCanal(String codcanal) {

		final List<CanalConfirmacion> canales = comboBoxes.buildListaCanal();
		// final List<CanalConfirmacion> canales = admconfirmacionesBo
		// .buscarCanal();

		for (CanalConfirmacion cc : canales) {

			if (GenericUtils.equals(cc.getId().getCodcanal(), codcanal))
				return cc;
		}

		return null;
	}

	public String getDetalleHeader() {
		return detalleHeader;
	}

	public String getModoDetalle() {
		return modoDetalle;
	}

	public boolean isAceptarDetalleDisabled() {
		return (GenericUtils.equals(ModoDetalle.ALTA, modoDetalle)) ? aceptarDetalleDisabled
				: true;
	}

	public boolean isOperEstrSupportRendered() {
		return operEstrSupportRendered;
	}


}
