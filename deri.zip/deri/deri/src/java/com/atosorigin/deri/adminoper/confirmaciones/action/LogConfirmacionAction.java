package com.atosorigin.deri.adminoper.confirmaciones.action;

//import java.io.File;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.persistence.EntityManager;

import org.hibernate.SQLQuery;
import org.jboss.seam.ScopeType;
import org.jboss.seam.annotations.Create;
import org.jboss.seam.annotations.In;
import org.jboss.seam.annotations.Logger;
import org.jboss.seam.annotations.Name;
import org.jboss.seam.annotations.Out;
import org.jboss.seam.annotations.Scope;
import org.jboss.seam.core.Conversation;
import org.jboss.seam.core.ResourceBundle;
import org.jboss.seam.international.StatusMessage.Severity;
import org.jboss.seam.log.Log;
import org.jboss.seam.security.Credentials;

import com.atosorigin.common.action.ModoPantalla;
import com.atosorigin.common.action.PaginatedListAction;
import com.atosorigin.common.action.PaginationData;
import com.atosorigin.common.constantes.Constantes;
import com.atosorigin.common.excelexporter.CustomExcelExporter;
import com.atosorigin.common.formvalidator.FormValidator;
import com.atosorigin.common.utils.GenericUtils;
import com.atosorigin.deri.adminoper.admconfirmaciones.business.ConfirmacionOperacionesBo;
import com.atosorigin.deri.adminoper.boletas.action.BoletasAction.BoletasStates;
import com.atosorigin.deri.adminoper.confirmaciones.screen.LogConfirmacionPantalla;
import com.atosorigin.deri.common.authentication.Authorizator;
import com.atosorigin.deri.contrapartida.business.ContrapartidaBo;
import com.atosorigin.deri.model.contrapartida.Contrapartida;
import com.atosorigin.deri.model.gestionoperaciones.ConfOperacion;
import com.atosorigin.deri.model.gestionoperaciones.HistoricoConfOperacion;
import com.atosorigin.deri.model.gestionoperaciones.HistoricoOperacion;
import com.atosorigin.deri.seguridad.pantalla.business.PantallaBo;
import com.atosorigin.deri.util.ConfiguracionDeri;
import com.atosorigin.deri.util.ContrapartidaUtil;
import com.atosorigin.deri.util.EntityUtil;
import com.atosorigin.deri.util.MessageBoxAction;
import com.atosorigin.deri.util.MsgBoxAction;

/**
 * Clase action listener para el caso de uso de preconfirmaciones
 */
@Name("logConfirmacionAction")
@Scope(ScopeType.CONVERSATION)
@FormValidator
public class LogConfirmacionAction extends PaginatedListAction {



	@In
	protected ConfOperacion confOperacionSelect;
	
		
	private static final long serialVersionUID = 1L;

	@Logger
	private Log log;

	@In
	EntityManager entityManager;

	@In("#{authorizator}")
	Authorizator authorizator;

	@In Credentials credentials;
	
	/**
	 * Inyección del bean de Spring "preconfirmacionesBo" que contiene los
	 * métodos de negocio para el caso de uso preconfirmaciones.
	 */
	@In("#{admconfirmacionesBo}")
	protected ConfirmacionOperacionesBo admconfirmacionesBo;

	/**
	 * Inyección del bean de Spring "contrapartidaBo" que contiene los métodos
	 * de negocio para el caso de uso de contrapartidas.
	 */
	@In("#{contrapartidaBo}")
	protected ContrapartidaBo contrapartidaBo;

	@In("#{pantallaBo}")
	protected PantallaBo pantallaBo;

	@In("EntityUtil")
	private EntityUtil entityUtil;

	@In
	private ContrapartidaUtil contrapartidaUtil;

	@In(value="#{customExcelExporter}")
	protected CustomExcelExporter customExcelExporter;
	
	/**
	 * Inyección del screen bean que contiene los datos de pantalla del caso de
	 * uso preconfirmaciones
	 */
	@In(create = true)
	protected LogConfirmacionPantalla logConfirmacionPantalla;

	@Out(required = false, value = "logConfirmacionMessageBoxAction")
	private MessageBoxAction msgboxPanelLogConfirmacionContrapaBloq;
	
	private Boolean primeraEjecucionInit=null;
	
	public LogConfirmacionPantalla  getLogConfirmacionPantalla () {
		return logConfirmacionPantalla;
	}

	public void setLogConfirmacionPantalla (
			LogConfirmacionPantalla logConfirmacionPantalla) {
		this.logConfirmacionPantalla = logConfirmacionPantalla;
	}

//
//	@DataModel(value = "logConfirmacion.listaResultados")
//	private List<HistoricoConfOperacion> listaConfirmacionesList = null;
//
//	@DataModelSelection(value = "logConfirmacion.listaResultados")
//	private HistoricoConfOperacion confirmacionSelected;


	@In(required = false)
	private String modo;

	private Boolean busqueda = false;

//	@In(required = false)
//	@Out(required = false)
//	private HistoricoOperacion historicoOperacion;

	@In(value = "configuracionDeri")
	ConfiguracionDeri configuracionDeri;


	@In(create = true)
	private MsgBoxAction msgBoxAction;


	@Create
	public void onCreate() {

	}

	
//	public HistoricoOperacion getHistoricoOperacion() {
//		return historicoOperacion;
//	}
//
//	public void setHistoricoOperacion(HistoricoOperacion historicoOperacion) {
//		this.historicoOperacion = historicoOperacion;
//	}

	@Out(required = false)
	private String modoTratamiento;


	public String getModoTratamiento() {
		return modoTratamiento;
	}

	public void setModoTratamiento(String modoTratamiento) {
		this.modoTratamiento = modoTratamiento;
	}

	public ConfOperacion getConfOperacionSelect() {
		return confOperacionSelect;
	}

	public void setConfOperacionSelect(ConfOperacion confOperacionSelect) {
		this.confOperacionSelect = confOperacionSelect;
	}


	private StringBuilder mensajeConfirmacion = new StringBuilder();

	public StringBuilder getMensajeConfirmacion() {
		return mensajeConfirmacion;
	}

	public void setMensajeConfirmacion(StringBuilder mensajeConfirmacion) {
		this.mensajeConfirmacion = mensajeConfirmacion;
	}

	/** Actualiza la lista del grid de preconfirmaciones */
	public void buscar() {

		paginationData.reset();
		busqueda = true;
		modo = "";

		refrescarLista();
		
		// Forzar refresco
		final List<HistoricoConfOperacion> lista = getDataTableList();
//		for (HistoricoConfOperacion co: lista)
//			admconfirmacionesBo.recargar(co);

		setPrimerAcceso(false);

	}

	
	/**
	 * Actualiza la lista del grid de parámetros informe y vuelve a la pantalla
	 * de búsqueda
	 */
	public void salirDetalle() {
		paginationData.reset();
		/** Limpiamos la información de paginación */
		if (this.modoPantalla.equals(ModoPantalla.EDICION)) {
			refrescarLista();
		}
	}

	@Override
	protected void refreshListInternal() {

		setExportExcel(false);
		final List<HistoricoConfOperacion> listaAdmconfirmaciones = recargarLista(paginationData, false);
		logConfirmacionPantalla
				.setHistConfirmacionesList(listaAdmconfirmaciones);

	}

	@Override
	public void refrescarListaExcel() {

	

		setExportExcel(true);

		final List<HistoricoConfOperacion> listaAdmconfirmaciones = recargarLista(paginationData
				.getPaginationDataForExcel(),false);

		logConfirmacionPantalla
			.setHistConfirmacionesList(listaAdmconfirmaciones);

	}

	public void excel(){
		//llamar a refrescar lista excel
		customExcelExporter.generarExcel("tablaDetalle:detalle", this);
	}

	public void excelBatch() {
		setExportExcel(true);
		List<HistoricoConfOperacion> listaAdmconfirmaciones = new ArrayList<HistoricoConfOperacion>();

			listaAdmconfirmaciones = recargarLista(paginationData.getPaginationDataForExcel(),true);
//			procesoExcelBatch(listaAdmconfirmaciones,"NOR");
	}


	private void procesoExcelBatch(List<ConfOperacion> listaAdmconfirmaciones,String caso) {
		String sqlTxt = null; String sustitucion = null; String sqlHeader = null;
		
		
		sqlHeader ="NumOp/Estr;Pdto.cat.;Tipo Confirm.;Idioma;Canal;Fecha Proceso;Contrapartida;Sentido;Estado;Su Referencia;"+
		"Observaciones;Fecha de alta;Nominal de pago;Nominal de recibo;Entidad;Tipo contrapartida;Oficina;Fecha valor;"+
		"Fecha vencimiento;Fecha última actualización;Fecha última confirmación;Indicador confirmación reclamada;Preconfirmada";
		

		if (listaAdmconfirmaciones!=null && listaAdmconfirmaciones.size()>0){
			
			SQLQuery sql = listaAdmconfirmaciones.get(0).getSqlQuery();
			sqlTxt = sql.getQueryString();
			for (String param : sql.getNamedParameters()) {
				sustitucion = obtenerSustitucion(param, caso);
				param = ":".concat(param);
				
				sqlTxt =	sqlTxt.replaceAll(param , sustitucion);	
			}	
		
			Long peticion = admconfirmacionesBo.generarPeticionExcel(sqlTxt,sqlHeader,caso);

			String mensaje = ResourceBundle.instance().getString("liquidaciones.registros.validadosBatch") + " " + peticion ;
			statusMessages.add(Severity.INFO, mensaje);

		}
	}


	private String obtenerSustitucion(String param, String caso) {
		
		
		SimpleDateFormat sdf = new SimpleDateFormat(Constantes.DDMMYYYY);

		if ("rownumMin".equalsIgnoreCase(param)){
			return paginationData.getPaginationDataForExcel().getFirstResult().toString();
		}else if ("rownumMax".equalsIgnoreCase(param)){
			return paginationData.getPaginationDataForExcel().getMaxResults().toString();
		}else if ("eventoConfirmacion".equalsIgnoreCase(param)){
			return this.logConfirmacionPantalla.getTipoConfirmacion()==null?"null":"'".concat(this.logConfirmacionPantalla.getTipoConfirmacion().getCodigo()).concat("'"); 
		}else if ("productocatalogo".equalsIgnoreCase(param)){
			return this.logConfirmacionPantalla.getPdtoCatalogoBusqueda()==null?"null":this.logConfirmacionPantalla.getPdtoCatalogoBusqueda().getProducat().toString();
		}else if ("idioma".equalsIgnoreCase(param)){
			return this.logConfirmacionPantalla.getIdiomaConfirmacion()==null?"null":this.logConfirmacionPantalla.getIdiomaConfirmacion().getCodigo();
		}else if ("canal".equalsIgnoreCase(param)){
			return this.logConfirmacionPantalla.getCanalConfirmacion()==null?"null":"'".concat(this.logConfirmacionPantalla.getCanalConfirmacion().getId().getCodcanal()).concat("'");
		}else if ("sentidoConfirmacion".equalsIgnoreCase(param)){
			return this.logConfirmacionPantalla.getSentidoConfirmacion()==null?"null":"'".concat(this.logConfirmacionPantalla.getSentidoConfirmacion().getCodigo()).concat("'");

		}else if ("estadoConfirmacion".equalsIgnoreCase(param)){
			return this.logConfirmacionPantalla.getEstadoConfirmacion()==null?"null":"'".concat(this.logConfirmacionPantalla.getEstadoConfirmacion().getCodigo()).concat("'");
		}else if ("idEstructConfirmadaDesde".equalsIgnoreCase(param)){
			return this.logConfirmacionPantalla.getEstructDesde().toString();
		}else if ("idEstructConfirmadaHasta".equalsIgnoreCase(param)){
			return this.logConfirmacionPantalla.getEstructHasta().toString();
		}else if ("fechaConfirmacionDesde".equalsIgnoreCase(param)){
			return "'".concat(sdf.format(this.logConfirmacionPantalla.getFechaDesde()).toString()).concat("'");
		}else if ("fechaConfirmacionHasta".equalsIgnoreCase(param)){
			return "'".concat(sdf.format(this.logConfirmacionPantalla.getFechaHasta()).toString()).concat("'");
		}else if ("oficina".equalsIgnoreCase(param)){
			return "'".concat(this.logConfirmacionPantalla.getOficina()).concat("'");
		}else if ("contrapartida".equalsIgnoreCase(param)){
			return 	"'".concat(this.logConfirmacionPantalla.getContrapartida()).concat("'");
		}else if ("tipoContrapartida".equalsIgnoreCase(param)){
			return this.logConfirmacionPantalla.getTipoContrapa()==null?"null":"'".concat(this.logConfirmacionPantalla.getTipoContrapa().getId()).concat("'");
//		}else if ("fechaContratacion".equalsIgnoreCase(param)){
//			return "'".concat(sdf.format(historicoOperacion.getId().getFechaContratacion())).concat("'"); 
		}else if ("fechaSistema".equalsIgnoreCase(param)){
			Date fechaSistema = admconfirmacionesBo.obtenerFechaSistema();
			return "'".concat(sdf.format(fechaSistema)).concat("'");
		}
		
		else{
			return "1";		
		}

	}

	
	
	

	@SuppressWarnings("unchecked")
	@Override
	public void setDataTableList(List<?> dataTableList) {
		this.logConfirmacionPantalla
				.setHistConfirmacionesList((List<HistoricoConfOperacion>) dataTableList);
	}

	@Override
	public List<HistoricoConfOperacion> getDataTableList() {
		return this.logConfirmacionPantalla.getHistConfirmacionesList();
	}


	public List<HistoricoConfOperacion> getDataTableScreen() {

		final List<HistoricoConfOperacion> ols = getDataTableList();

		return ols.subList(0, Math.min(ols.size(), 10));
	}

	public void salirSeleccionar(){
		msgBoxAction.voidFunction();
		//return Constantes.SUCCESS;
	}

	
	private String convertirEntidad(String entidad ) {
		
		if ("81".equals(GenericUtils.lpad(entidad, 2,"0"))) {
			return "01";
		}else if ("42".equals(GenericUtils.lpad(entidad, 2,"0"))) {
			return "BG";
		}else{
			return "05";
		}
		
	}

	private String descripcionFichero(Long operacion, String evento) {
//		A ALTA
//		M RECTIFICACION
//		C CANCELACION
//		P CANCELACION PÂRCIAL + NCORRELA
		String numOper = operacion.toString();
		
		if ("A".equals(evento)) {
			return "Alta ".concat(numOper);
		}else if ("M".equals(evento)) {
			return "Rectificación ".concat(numOper);
		}else if ("C".equals(evento)) {
			return "Cancelación ".concat(numOper);
		}else if ("P".equals(evento)) {
			return "Cancelación Parcial ".concat(numOper);
		}else {
			return numOper;
		}
		
	}

	public void init() {
		primeraEjecucionInit = null;
		setPrimerAcceso(false);

		if (!isPrimerAcceso())
			return;
	}
	
	public void initLog(){
		if (primeraEjecucionInit == null) {
			primeraEjecucionInit=true;
		} 
		else{
			primeraEjecucionInit = false;
		}
		
		if(null==msgboxPanelLogConfirmacionContrapaBloq){
			msgboxPanelLogConfirmacionContrapaBloq = new MessageBoxAction();
		}
		
		if(primeraEjecucionInit && null!=this.confOperacionSelect.getOperacion()){
			Contrapartida contrapartida = (Contrapartida) this.confOperacionSelect.getOperacion().getContrapartida();
			if (null!=contrapartida && !GenericUtils.isNullOrBlank(contrapartida.getIndBloqueo()) && "S".equalsIgnoreCase(contrapartida.getIndBloqueo())){
				iniciarPopUpContrapartidaBloqueada();
			}
		}
	}
	
	public void voidFunction(){
		msgBoxAction.voidFunction();
	}

	public void logConfirmacion(){
	
	}

	private List<Long> obtenerNumeroOperaciones(
			List<ConfOperacion> confirmaciones) {

		final List<Long> numeroOperaciones = new ArrayList<Long>(confirmaciones
				.size());

		for (ConfOperacion co : confirmaciones) {
			if (co.getOperacion()==null && co.getEstructura()!=null){
				numeroOperaciones.add(co.getEstructura().getEstructu());
			}else{
				numeroOperaciones.add(co.getOperacion().getId()
						.getNumeroOperacion());	
			}
			
		}

		return numeroOperaciones;
	}

	@Out(required = false)
	protected ConfOperacion cOperacionFrom;

	public ConfOperacion getcOperacionFrom() {
		return cOperacionFrom;
	}

	public void setcOperacionFrom(ConfOperacion cOperacionFrom) {
		this.cOperacionFrom = cOperacionFrom;
	}

	/**
	 * metodo para alta
	 */
	/**
	 * Objeto usado para el alta
	 */
	// @Out(required = false)
	protected ConfOperacion confOperacion;

	public ConfOperacion getConfOperacion() {
		return confOperacion;
	}

	public void setConfOperacion(ConfOperacion confOperacion) {
		this.confOperacion = confOperacion;
	}



	/**
	 * Objeto HistoricoOperacion para outjectar a MANTOPER
	 */
	@Out(required = false)
	HistoricoOperacion hOperacion;

	public HistoricoOperacion gethOperacion() {
		return hOperacion;
	}

	public void sethOperacion(HistoricoOperacion hOperacion) {
		this.hOperacion = hOperacion;
	}

	@Out(required = false)
	@In(required = false)
	@SuppressWarnings("unused")
	private BoletasStates boletaState;
	

	/**
	 * metodo para obtener la decripcion del canal al no poder mapearse ya que
	 * los campos id que coinciden entre tablas, pueden estar repetidos
	 */
	public String obtenerDescripcionCanal(String canal) {
		return admconfirmacionesBo.obtenerDescripcionCanal(canal);
	}


	/**
	 * metodo para obtener la decripcion del canal al no poder mapearse ya que
	 * los campos id que coinciden entre tablas, pueden estar repetidos
	 */
	public String obtenerDescripcionEstado(String estadoco) {
		return admconfirmacionesBo.obtenerDescripcionEstado(estadoco);
	}

	private List<HistoricoConfOperacion> recargarLista(PaginationData paginationData, Boolean batch) {
		return admconfirmacionesBo.obtenerHistoricoConfOperaciones(confOperacionSelect);
	}


	public void salir() {
		Conversation conversacion = Conversation.instance();
		// Volvemos a la anterior conversación
		if (conversacion.isNested()) {
			conversacion.redirectToParent();
		} else {
			redirectToURL("/home.seam");
			conversacion.endAndRedirect();
		}
	}

	private void iniciarPopUpContrapartidaBloqueada(){
		msgboxPanelLogConfirmacionContrapaBloq.init("admconfirmaciones.messages.contrapartida.bloqueada.texto", "logConfirmacionAction.voidFunction()", null, "messageBoxPanelContrapa");
	}

}

