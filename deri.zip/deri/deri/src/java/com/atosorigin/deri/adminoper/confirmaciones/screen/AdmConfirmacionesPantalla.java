package com.atosorigin.deri.adminoper.confirmaciones.screen;

import java.util.Date;
import java.util.List;

import org.jboss.seam.ScopeType;
import org.jboss.seam.annotations.Name;
import org.jboss.seam.annotations.Out;
import org.jboss.seam.annotations.Scope;
import org.jboss.seam.annotations.datamodel.DataModel;
import org.jboss.seam.annotations.datamodel.DataModelSelection;

import com.atosorigin.deri.model.adminoper.CanalConfirmacion;
import com.atosorigin.deri.model.adminoper.DescripcionSentido;
import com.atosorigin.deri.model.adminoper.DescripcionTipoConfirmacion;
import com.atosorigin.deri.model.catalogo.Producto;
import com.atosorigin.deri.model.common.Idioma;
import com.atosorigin.deri.model.contrapartida.TipoContrapartida;
import com.atosorigin.deri.model.gestionoperaciones.ConfOperacion;
import com.atosorigin.deri.model.gestionoperaciones.DescripcionEstadoConfirmacion;
import com.atosorigin.deri.model.gestionoperaciones.HistoricoOperacion;
import com.atosorigin.deri.model.gestiontesoreria.DescripcionCanalConfirmacion;
import com.atosorigin.deri.model.murex.ProductoCatalogo;


/**
 * Contiene los datos de pantalla necesarios para el caso de uso admconfirmaciones.
 */
@Name("admConfirmacionesPantalla")
@Scope(ScopeType.CONVERSATION)
public class AdmConfirmacionesPantalla {

	/** Lista de datos para el grid. */
	@DataModel(value = "listaadmConfirmaciones")
	protected List<ConfOperacion> admconfirmacionesList;

	/** Parametro seleccionado en el grid */
	@DataModelSelection(value = "listaadmConfirmaciones")
	protected ConfOperacion admconfirmacionSelec;

	
	@Out(value = "admconfirmacionEdit" ,required = false)
	protected ConfOperacion admconfirmacionEdit;

	@Out(value = "admConfirmacion", required = false)
	protected ConfOperacion admconfirmacion;
	
	/** Criterios Seleccion */	
	protected Long numOperDesde;
	protected Long numOperHasta;
	protected Date fechaDesde;
	protected Date fechaHasta;
	protected Long estructDesde;
	protected Long estructHasta;

	

	//salida para el detalle, siempre necesitamos saber de donde venimos
	@Out("seleccionar")
	protected String seleccionar;
	
	protected List<String> valoresComboSitu;
	protected List<Idioma> idiomaSelect;
	protected List<DescripcionCanalConfirmacion> canalSelect;
	
	protected DescripcionTipoConfirmacion tipoConfirmacion;
	protected Idioma idiomaConfirmacion;
	protected CanalConfirmacion  canalConfirmacion;
	protected Producto pdtoContable;
	protected ProductoCatalogo pdtoCatalogo;
	protected ProductoCatalogo pdtoCatalogoBusqueda;
	protected DescripcionEstadoConfirmacion estadoConfirmacion;
	protected TipoContrapartida tipoContrapa;
	protected String contrapartida;
	protected String oficina;
	protected DescripcionSentido sentidoConfirmacion;
	
	protected String contrapartidaNif;
	protected String watermark;
	protected String paramWater;
	
	protected ConfOperacion admconfirmacionSuRefer;
	protected String suReferencia;
	protected String suReferenciaBusc;
	protected HistoricoOperacion hOperReferencia;
	private   String onComplete;
	
	/**
	 * cargamos valores por defecto
	 */
	public AdmConfirmacionesPantalla() {
		this.watermark = "O";
		this.paramWater ="&watermark=";
		this.seleccionar = "O";
	}

	/**
	 * atributos visualizacion de productocontable
	 */
	
	public String getProductoContable() {
		return productoContable;
	}

	public void setProductoContable(String productoContable) {
		this.productoContable = productoContable;
	}

	/**
	 * atributos para visualizaciond e fechas
	 * 
	 */
	protected String productoContable;
	protected String tConfirmacion;
	protected boolean fechaDefaultlabel = false;
	
	public boolean isFechaDefaultlabel() {
		return fechaDefaultlabel;
	}

	public void setFechaDefaultlabel(boolean fechaDefaultlabel) {
		this.fechaDefaultlabel = fechaDefaultlabel;
	}

	
	public String gettConfirmacion() {
		return tConfirmacion;
	}

	public void settConfirmacion(String tConfirmacion) {
		this.tConfirmacion = tConfirmacion;
	}

	public String getContrapartidaNif() {
		return contrapartidaNif;
	}

	public void setContrapartidaNif(String contrapartidaNif) {
		this.contrapartidaNif = contrapartidaNif;
	}

	public List<Idioma> getIdiomaSelect() {
		return idiomaSelect;
	}

	public void setIdiomaSelect(List<Idioma> idiomaSelect) {
		this.idiomaSelect = idiomaSelect;
	}	
	
	public List<DescripcionCanalConfirmacion> getCanalSelect() {
		return canalSelect;
	}

	public void setCanalSelect(List<DescripcionCanalConfirmacion> canalSelect) {
		this.canalSelect = canalSelect;
	}

	public List<ConfOperacion> getAdmconfirmacionesList() {
		return admconfirmacionesList;
	}

	public void setAdmconfirmacionesList(List<ConfOperacion> admconfirmacionesList) {
		this.admconfirmacionesList = admconfirmacionesList;
	}

	public ConfOperacion getAdmconfirmacionSelec() {
		return admconfirmacionSelec;
	}

	public void setAdmconfirmacionSelec(ConfOperacion admconfirmacionSelec) {
		this.admconfirmacionSelec = admconfirmacionSelec;
	}

	public ConfOperacion getAdmconfirmacion() {
		return admconfirmacion;
	}

	public void setAdmconfirmacion(ConfOperacion admconfirmacion) {
		this.admconfirmacion = admconfirmacion;
	}

	public Long getEstructDesde() {
		return estructDesde;
	}

	public void setEstructDesde(Long estructDesde) {
		this.estructDesde = estructDesde;
	}

	public Long getEstructHasta() {
		return estructHasta;
	}

	public void setEstructHasta(Long estructHasta) {
		this.estructHasta = estructHasta;
	}

	public String getOficina() {
		return oficina;
	}

	public void setOficina(String oficina) {
		this.oficina = oficina;
	}

	public String getContrapartida() {
		return contrapartida;
	}

	public void setContrapartida(String contrapartida) {
		this.contrapartida = contrapartida;
	}

	
	
	public TipoContrapartida getTipoContrapa() {
		return tipoContrapa;
	}

	public void setTipoContrapa(TipoContrapartida tipoContrapa) {
		this.tipoContrapa = tipoContrapa;
	}

	public Idioma getIdiomaConfirmacion() {
		return idiomaConfirmacion;
	}

	public void setIdiomaConfirmacion(Idioma idiomaConfirmacion) {
		this.idiomaConfirmacion = idiomaConfirmacion;
	}

	public CanalConfirmacion getCanalConfirmacion() {
		return canalConfirmacion;
	}

	public void setCanalConfirmacion(CanalConfirmacion canalConfirmacion) {
		this.canalConfirmacion = canalConfirmacion;
	}

	public Producto getPdtoContable() {
		return pdtoContable;
	}

	public void setPdtoContable(Producto pdtoContable) {	
		this.pdtoContable = pdtoContable;	
	}

	public ProductoCatalogo getPdtoCatalogo() {
		return pdtoCatalogo;
	}

	public void setPdtoCatalogo(ProductoCatalogo pdtoCatalogo) {
		this.pdtoCatalogo = pdtoCatalogo;
	}

	public DescripcionEstadoConfirmacion getEstadoConfirmacion() {
		return estadoConfirmacion;
	}

	public void setEstadoConfirmacion(DescripcionEstadoConfirmacion estadoConfirmacion) {
		this.estadoConfirmacion = estadoConfirmacion;
	}

	public DescripcionSentido getSentidoConfirmacion() {
		return sentidoConfirmacion;
	}

	public void setSentidoConfirmacion(DescripcionSentido sentidoConfirmacion) {
		this.sentidoConfirmacion = sentidoConfirmacion;
	}
	
	public DescripcionTipoConfirmacion getTipoConfirmacion() {
		return tipoConfirmacion;
	}

	public void setTipoConfirmacion(DescripcionTipoConfirmacion tipoConfirmacion) {
		this.tipoConfirmacion = tipoConfirmacion;
	}

	/** Checkbox preconfirmado */
	protected boolean preconfirmado;

	/** Modo para saber si venimos de la agenda */
	protected String modo;
	
	

	public Long getNumOperDesde() {
		return numOperDesde;
	}

	public Long getNumOperHasta() {
		return numOperHasta;
	}

	public Date getFechaDesde() {
		return fechaDesde;
	}

	public Date getFechaHasta() {
		return fechaHasta;
	}

	public List<String> getValoresComboSitu() {
		return valoresComboSitu;
	}
	
	
	public void setNumOperDesde(Long numOperDesde) {
		this.numOperDesde = numOperDesde;
	}

	public void setNumOperHasta(Long numOperHasta) {
		this.numOperHasta = numOperHasta;
	}

	public void setFechaDesde(Date fechaDesde) {
		this.fechaDesde = fechaDesde;
	}

	public void setFechaHasta(Date fechaHasta) {
		this.fechaHasta = fechaHasta;
	}

	public void setValoresComboSitu(List<String> valoresComboSitu) {
		this.valoresComboSitu = valoresComboSitu;
	}

	public boolean isPreconfirmado() {
		return preconfirmado;
	}

	public void setPreconfirmado(boolean preconfirmado) {
		this.preconfirmado = preconfirmado;
	}

	public String getModo() {
		return modo;
	}

	public void setModo(String modo) {
		this.modo = modo;
	}

	public String getSeleccionar() {
		return seleccionar;
	}

	public void setSeleccionar(String seleccionar) {
		this.seleccionar = seleccionar;
	}

	public ProductoCatalogo getPdtoCatalogoBusqueda() {
		return pdtoCatalogoBusqueda;
	}

	public void setPdtoCatalogoBusqueda(ProductoCatalogo pdtoCatalogoBusqueda) {
		this.pdtoCatalogoBusqueda = pdtoCatalogoBusqueda;
	}
	
	public String getWatermark() {
		return watermark;
	}

	public void setWatermark(String watermark) {
		this.watermark = watermark;
	}

	public String getParamWater() {
		return paramWater;
	}

	public void setParamWater(String paramWater) {
		this.paramWater = paramWater;
	}

	public String getSuReferencia() {
		return suReferencia;
	}

	public void setSuReferencia(String suReferencia) {
		this.suReferencia = suReferencia;
	}

	public ConfOperacion getAdmconfirmacionSuRefer() {
		return admconfirmacionSuRefer;
	}

	public void setAdmconfirmacionSuRefer(ConfOperacion admconfirmacionSuRefer) {
		this.admconfirmacionSuRefer = admconfirmacionSuRefer;
	}

	public String getOnComplete() {
		return onComplete;
	}

	public void setOnComplete(String onComplete) {
		this.onComplete = onComplete;
	}

	public HistoricoOperacion gethOperReferencia() {
		return hOperReferencia;
	}

	public void sethOperReferencia(HistoricoOperacion hOperReferencia) {
		this.hOperReferencia = hOperReferencia;
	}

	public String getSuReferenciaBusc() {
		return suReferenciaBusc;
	}

	public void setSuReferenciaBusc(String suReferenciaBusc) {
		this.suReferenciaBusc = suReferenciaBusc;
	}


	
}
