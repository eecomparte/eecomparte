package com.atosorigin.deri.adminoper.ejercicio.action;

import java.math.BigDecimal;
import java.text.DecimalFormat;
import java.text.NumberFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.jboss.seam.ScopeType;
import org.jboss.seam.annotations.In;
import org.jboss.seam.annotations.Name;
import org.jboss.seam.annotations.Out;
import org.jboss.seam.annotations.Scope;
import org.jboss.seam.core.Conversation;
import org.jboss.seam.international.StatusMessage.Severity;

import com.atosorigin.common.action.GenericAction;
import com.atosorigin.common.constantes.Constantes;
import com.atosorigin.common.formvalidator.FormValidator;
import com.atosorigin.common.utils.GenericUtils;
import com.atosorigin.deri.adminoper.boletas.business.BoletasBo;
import com.atosorigin.deri.adminoper.ejercicio.business.EjercicioBo;
import com.atosorigin.deri.adminoper.ejercicio.screen.EjercicioPantalla;
import com.atosorigin.deri.common.dbLock.DbLockService;
import com.atosorigin.deri.common.parametrosPantalla.ParametrosManteje;
import com.atosorigin.deri.model.adminoper.Ejercicio;
import com.atosorigin.deri.model.adminoper.EjercicioId;
import com.atosorigin.deri.model.adminoper.HistoricoBarrera;
import com.atosorigin.deri.model.contrapartida.Contrapartida;
import com.atosorigin.deri.model.gestionoperaciones.HistoricoOperacion;
import com.atosorigin.deri.model.gestionoperaciones.HistoricoOperacionId;
import com.atosorigin.deri.model.parametrizacion.ParamCobroPago;
import com.atosorigin.deri.model.parametrizacion.ParamCobroPagoId;
import com.atosorigin.deri.util.ContrapartidaUtil;

@Name("ejercicioAction")
@Scope(ScopeType.CONVERSATION)
@FormValidator
public class EjercicioAction extends GenericAction {

	// oO[Variables y Constantes]Oo
	@In("#{ejercicioBo}")
	protected EjercicioBo ejercicioBo;
	
	@In(create=true)
	protected EjercicioPantalla ejercicioPantalla;
	
	
	@In(required = false, value = "ParametrosManteje")
	ParametrosManteje parametrosManteje;


	@In
	private ContrapartidaUtil contrapartidaUtil;

	@In("#{boletasBo}")
	private BoletasBo boletasBo;
	
	protected boolean pasaValidacionEjercer = false;
	protected boolean pasaValidacionNoEjercer = false;
	
	private String tipoOperacion;
		
	/** Inyección del servicio que gestiona los bloqueos de registros en base de datos */
	@In(create = true)
	protected DbLockService dbLockService;
	
	/** Inyección del objeto para la union con MANTPROD  */
	@In(required=false)
	@Out(required= false)
	String varModif;
	
	// oO[Métodos]Oo	

	public void init(){

		if(isPrimerAcceso() && !GenericUtils.isNullOrBlank(parametrosManteje)){
			String origen ="";
			Date fechaeje = null;
			String concepto ="";
			Date fechaope = null;
			Date fechatra = null;
			Date fecinitr = null;
			Date fecfintr = null;
			Date feultact = null;
			Long numeroOperacion = 0L;
			String tipoConcepto ="";
			String tipoOperacion ="";
			
			
			origen   = parametrosManteje.getModo();
			fechaeje = parametrosManteje.getFechaeje();
			
			if(!GenericUtils.isNullOrBlank(parametrosManteje.getConcepto())){
				concepto = parametrosManteje.getConcepto();
			}else{
				concepto  = "INT";
			}
			
			
			if (parametrosManteje.getHistoricoOperacion()!=null){
				fechaope = parametrosManteje.getHistoricoOperacion().getId().getFechaContratacion();
				fechatra = parametrosManteje.getHistoricoOperacion().getId().getFechaTratamiento();
				numeroOperacion = parametrosManteje.getHistoricoOperacion().getId().getNumeroOperacion(); 
				feultact = parametrosManteje.getHistoricoOperacion().getId().getFechaModificacion();
			
			
				Integer cmofFirma = CMOFNoFirmado(parametrosManteje.getHistoricoOperacion()); 
				if (1==cmofFirma ){
					statusMessages.add(Severity.WARN, "#{messages['mantoper.cancelacion.error.cmofFirmado']}");
				}else if (2==cmofFirma ){
					statusMessages.add(Severity.WARN, "#{messages['mantoper.cancelacion.error.novacionFirmado']}");
				}
				
			}
		    fecinitr = parametrosManteje.getFecinitr();
		    fecfintr = parametrosManteje.getFecfintr();
		    
			if(!GenericUtils.isNullOrBlank(parametrosManteje.getTipoConcepto())){
			    tipoConcepto = parametrosManteje.getTipoConcepto();
			}else{
				tipoConcepto = "OPC";
			}

		
			tipoOperacion = parametrosManteje.getTipoOperacion();
			
		
		    entraPantalla(origen, fechaeje, concepto, fechaope, fechatra, fecinitr, fecfintr, feultact, numeroOperacion, tipoConcepto, tipoOperacion);
		}
			
	}
	/**
	 * Primer método en ejecutarse, carga la página
	 */
	public void entraPantalla(String origen, Date fechaeje, String concepto, Date fechaope, Date fechatra, Date fecinitr, Date fecfintr, Date feultact, Long numeroOperacion, String tipoConcepto, String tipoOperacion){
		
		
		
		setPrimerAcceso(false);
		this.setTipoOperacion(tipoOperacion);

		if(GenericUtils.isNullOrBlank(ejercicioPantalla.getEjercicio())){
			ejercicioPantalla.setEjercicio(new Ejercicio(new EjercicioId()));
		}
		if(GenericUtils.isNullOrBlank(ejercicioPantalla.getHistoricoOperacionId())){
			ejercicioPantalla.setHistoricoOperacionId(new HistoricoOperacionId());
		}
		
		Date fechaSistema = ejercicioBo.obtenerFechaSistema();
		
		if(origen.equals(Constantes.ORIGEN_OPE) || origen.equals(Constantes.ORIGEN_PRODCOM)){
			ejercicioPantalla.getEjercicio().getId().setFechaEjercicio(fechaSistema);
		}
		
		ejercicioPantalla.getHistoricoOperacionId().setNumeroOperacion(numeroOperacion);
		ejercicioPantalla.getHistoricoOperacionId().setFechaContratacion(fechaope);
		ejercicioPantalla.getHistoricoOperacionId().setFechaModificacion(feultact);
		ejercicioPantalla.getHistoricoOperacionId().setFechaTratamiento(fechatra);
		
		ejercicioPantalla.setVistamanteje(ejercicioBo.obtenerDatos(ejercicioPantalla.getHistoricoOperacionId()));
		if (!GenericUtils.isNullOrBlank(ejercicioPantalla.getVistamanteje()) 
				&& !GenericUtils.isNullOrBlank(ejercicioPantalla.getVistamanteje().getEstado())){
			if(ejercicioPantalla.getVistamanteje().getEstado().equals("I")){
				statusMessages.add(Severity.ERROR, "#{messages['ejercicio.validacion.estado']}");
			}else{
				ejercicioPantalla.getEjercicio().getId().setFechaEjercicio(fechaSistema);
				if(origen.equals(Constantes.ORIGEN_OPE) || origen.equals(Constantes.ORIGEN_PRODCOM)){
					Long cuantos = ejercicioBo.comprobarCuantos(fechaope, numeroOperacion, fechaSistema);
					if(cuantos < 1L){
						ejercicioPantalla.getEjercicio().getId().setFechaEjercicio(ejercicioBo.obtenerCuantos(ejercicioPantalla.getHistoricoOperacionId().getFechaContratacion(), ejercicioPantalla.getHistoricoOperacionId().getNumeroOperacion(), fechaSistema));
					}
					ejercicioPantalla.setHistoricoTramos(ejercicioBo.obtenerHistoricoTramosOperacion(ejercicioPantalla.getHistoricoOperacionId(), ejercicioPantalla.getVistamanteje().getTipoOperacion()));

				}else{
					ejercicioPantalla.getEjercicio().getId().setFechaEjercicio(fechaeje);
					ejercicioPantalla.setHistoricoTramos(ejercicioBo.obtenerHistoricoTramosAgenda(numeroOperacion, feultact, fechatra, fechaope, ejercicioPantalla.getVistamanteje().getTipoOperacion(), fecinitr, fecfintr, concepto, tipoConcepto));
				}
				ejercicioPantalla.getEjercicio().getId().setTipoOperacion(ejercicioPantalla.getHistoricoTramos().getId().getTipoOperacion().getCodigo());
				ejercicioPantalla.getEjercicio().setFechaLiquidacion(ejercicioPantalla.getHistoricoTramos().getFechaLiquidacion());
				
//				ejercicioPantalla.getEjercicio().setDivisaEjercicio(ejercicioPantalla.getHistoricoTramos().getDivisaLiquidacion());
				if (GenericUtils.isNullOrBlank(ejercicioPantalla.getEjercicio().getDivisaLiquidacion())){
					ejercicioPantalla.getEjercicio().setDivisaLiquidacion(ejercicioPantalla.getHistoricoTramos().getDivisaLiquidacion());
				}
				
				ejercicioPantalla.getEjercicio().setImporte(ejercicioPantalla.getHistoricoTramos().getImporteOperacion());
				
				if (ejercicioPantalla.getEjercicio().getImporte()==null || BigDecimal.ZERO.equals(ejercicioPantalla.getEjercicio().getImporte())){
					ejercicioPantalla.getEjercicio().setImporte(ejercicioBo.obtenerImporte(ejercicioPantalla.getHistoricoOperacionId(), ejercicioPantalla.getVistamanteje().getTipoOperacion(), concepto, tipoConcepto, fecinitr, fecfintr, ejercicioPantalla.getEjercicio().getId().getFechaEjercicio(), null));
				}
			}
		}
	}

	/**
	 * Valida toda la pantalla
	 * @return
	 */
	public boolean validar(){
		if(GenericUtils.isNullOrBlank(ejercicioPantalla.getEjercicio().getId().getFechaEjercicio())){
			statusMessages.addToControl("fValorEjeTxt",Severity.ERROR,"#{messages['ejercicio.validacion.fvalor']}");
			return false;
		}
		if(GenericUtils.isNullOrBlank(ejercicioPantalla.getEjercicio().getFechaLiquidacion())){
			statusMessages.addToControl("fliqTxt",Severity.ERROR,"#{messages['ejercicio.validacion.fliqInfor']}");
			return false;
		}else if(ejercicioBo.esFestivo(ejercicioPantalla.getEjercicio().getFechaLiquidacion(), ejercicioPantalla.getEjercicio().getDivisaLiquidacion())){ //.getDivisaEjercicio())){
			statusMessages.addToControl("fliqTxt",Severity.ERROR,"#{messages['ejercicio.validacion.fliqFest']}");
			return false;
		}
		if(GenericUtils.isNullOrBlank(ejercicioPantalla.getEjercicio().getDivisaLiquidacion())){
				//.getDivisaEjercicio())){
			statusMessages.addToControl("divisaTxt",Severity.ERROR,"#{messages['ejercicio.validacion.divisa']}");
			return false;
		}
		if(GenericUtils.isNullOrBlank(ejercicioPantalla.getEjercicio().getImporte())){
			ejercicioPantalla.getEjercicio().setImporte(new BigDecimal(0));
		}
//		else if(ejercicioPantalla.getEjercicio().getImporte().floatValue() < 0L){
//			statusMessages.addToControl("importeTxt",Severity.ERROR,"#{messages['ejercicio.validacion.importe']}");
//			return false;
//		}
		HistoricoOperacion histoper = ejercicioBo.cargarOper(ejercicioPantalla.getHistoricoOperacionId());
		if (!comprobarEjerc(histoper)){
			return false;
		}
		return true;
	}
	
	/**
	 * Validaciones previas a ejercer
	 */
	public void validarEjercer(){
		if(validar()){
			pasaValidacionEjercer = true;
			if(ejercicioBo.comprobarEjercida(ejercicioPantalla.getHistoricoOperacionId())){
				statusMessages.add(Severity.ERROR, "#{messages['ejercicio.validacion.ejercida']}");
				pasaValidacionEjercer = false;
			}else{
				if(!ejercicioBo.verificarHistoricoFechaFormula(ejercicioPantalla.getHistoricoOperacionId(), ejercicioPantalla.getEjercicio().getId().getFechaEjercicio())){
					statusMessages.add(Severity.ERROR, "#{messages['ejercicio.validacion.fvalnovalida']}");
					pasaValidacionEjercer = false;
				}
			}
		}else{
			pasaValidacionEjercer = false;
		}
	}
	
	/**
	 * Validaciones previas a no ejercer
	 */
	public void validarNoEjercer(){
		if(validar()){
			pasaValidacionNoEjercer = true;
			if(!ejercicioBo.verificarHistoricoFechaFormula(ejercicioPantalla.getHistoricoOperacionId(), ejercicioPantalla.getEjercicio().getId().getFechaEjercicio())){
				statusMessages.add(Severity.ERROR, "#{messages['ejercicio.validacion.fvalnovalida']}");
				pasaValidacionNoEjercer = false;
			}
		}else{
			pasaValidacionNoEjercer = false;
		}
	}
	
	
	public boolean ejercerValidator(){
	
		HistoricoOperacion ho = ejercicioPantalla.getHistoricoTramos().getId().getHistoricoOperacion();
	
		if (ho.getProductoCatalogo()!=null && ho.getProductoCatalogo().getProdtrat()!=null &&
				"S".equals(ho.getProductoCatalogo().getProdtrat().getChkopcdiv())
				&& ho.getHistoricoOpcion()!=null && ho.getHistoricoOpcion().getModoEjercicio()!=null 
							&& "C".equals(ho.getHistoricoOpcion().getModoEjercicio().getCodigo())				
		){ 
			
			String codigoDivisa = null; 
			Short entioper;
			
			try {
				entioper = Short.valueOf(ho.getEntidad().getCodigo());
			} catch (Exception e) {
				entioper= 81;
			}
	
			codigoDivisa =  ejercicioPantalla.getEjercicio().getDivisaLiquidacion();
//			if ("P".equals(ejercicioPantalla.getEjercicio().getId().getTipoOperacion())){
//				codigoDivisa = ho.getDivisaLiquidacionPago().getId();
//			}else{
//				codigoDivisa = ho.getDivisaLiquidacionRecibo().getId();
//			}

			if (!ejercicioBo.existeParamCobroPago(Constantes.NOMBRE_PROYECTO_DERI,	ho.getProducto().getId(),
					ejercicioPantalla.getEjercicio().getId().getTipoOperacion(),codigoDivisa,ho.getContrapartida().getId(),entioper))		
			{
					statusMessages.add(Severity.WARN, "#{messages['boletas.dadesValidades.paramcyp2']}");
					return false;
			}
		
		}
		
	 return true;
	
	}

	public boolean comprobarEjerc(HistoricoOperacion histoper){
		Boolean existeBarreraI  = false;
		if (histoper.getHistoricoBarreras()!=null ){
			for (HistoricoBarrera barrera : histoper.getHistoricoBarreras()) {
	
				String tipbarp1 = barrera.getId().getTipbarp1();
				if(tipbarp1.endsWith("I")){
					existeBarreraI  = true;
					if (barrera.getFevaltoq() != null) {
						return true;
					} 
				}
			}
		}
		if (existeBarreraI){
			return false;	
		}else{
			return true;
		}
		
	}

	
	/**
	 * Ejerce
	 */
	public void ejercer(){
		SimpleDateFormat sdf1 = new SimpleDateFormat(Constantes.YYYYMMDD);
		NumberFormat formato = new DecimalFormat("0000000000000.0000");
		StringBuilder texto = new StringBuilder();
		
		texto.append(ejercicioPantalla.getVistamanteje().getTipoOperacion()).append(" ");
		texto.append(sdf1.format(ejercicioPantalla.getHistoricoTramos().getId().getFechaInicioTramo())).append(" ");
		texto.append(sdf1.format(ejercicioPantalla.getHistoricoTramos().getId().getFechaFinTramo())).append(" ");
		texto.append("INT").append(" ").append("OPC").append(" ");
		texto.append(GenericUtils.lpad(ejercicioPantalla.getHistoricoTramos().getCodigoFormula().getCodigoFormula().toString(), 5, '0')).append(" ");
		texto.append(ejercicioPantalla.getVistamanteje().getProducto()).append(" ");
		texto.append(sdf1.format(ejercicioPantalla.getEjercicio().getFechaLiquidacion())).append(" ");
		texto.append((formato.format(ejercicioPantalla.getEjercicio().getImporte().abs()).toString().replaceAll(",","")).trim()).append(" ");
//		if(ejercicioPantalla.getVistamanteje().getTipoOperacion().equals(ejercicioPantalla.getHistoricoTramos().getId().getTipoOperacion().getCodigo())){
		if(ejercicioPantalla.getEjercicio().getImporte().floatValue() < 0L){			
			texto.append("-").append(" ");
		}else{
			texto.append("+").append(" ");
		}
		texto.append(GenericUtils.rpad(ejercicioPantalla.getEjercicio().getDivisaLiquidacion(), 3, ' ')).append(" ");
//				.getDivisaEjercicio(), 3, ' ')).append(" ");
		texto.append(sdf1.format(ejercicioPantalla.getEjercicio().getId().getFechaEjercicio())).append(" ");
		if(GenericUtils.isNullOrBlank(ejercicioPantalla.getEjercicio().getObservaciones())){
			texto.append(GenericUtils.rpad(" ", 200, ' '));
		}else{
			texto.append(GenericUtils.rpad(ejercicioPantalla.getEjercicio().getObservaciones(), 200, ' '));
		}
		texto.append(GenericUtils.rpad(" ", 110, ' '));

		Long estructura  = null;
		if (ejercicioPantalla.getHistoricoTramos().getId().getHistoricoOperacion().getProductoCompuesto()!=null){
			estructura = ejercicioPantalla.getHistoricoTramos().getId().getHistoricoOperacion().getProductoCompuesto().getEstructu();	
		}
		
		
		//insertamos en agenda pasando el texto creado como parametro
		ejercicioBo.insertarAgenda(ejercicioBo.obtenerFechaSistema(), ejercicioPantalla.getHistoricoOperacionId().getNumeroOperacion(), ejercicioPantalla.getHistoricoOperacionId().getFechaContratacion(), new Date(), ejercicioPantalla.getVistamanteje().getProducto(), ejercicioPantalla.getVistamanteje().getUsuario(), texto.toString(), estructura);
		
		//se inserta en posiejer con Ejercicio.indicadorEjercicio a S
		ejercicioPantalla.getEjercicio().setIndicadorEjercicio("S");
//		if (ejercicioPantalla.getEjercicio().getDivisaEjercicio()!=null){
//			ejercicioPantalla.getEjercicio().setDivisaLiquidacion(ejercicioPantalla.getEjercicio().getDivisaEjercicio());
//		}
		ejercicioBo.insertarPosiejer(ejercicioPantalla.getEjercicio(), ejercicioPantalla.getHistoricoOperacionId(), ejercicioPantalla.getHistoricoTramos(), ejercicioPantalla.getVistamanteje().getUsuario());
		// SMM: Cuando se pulsa Ejercer se ha modificado, de modo que si se viene desde MANTPROD devuelve 'S' 
		varModif = Constantes.CONSTANTE_SI;  
		retornar();
	}
	
	/**
	 * No ejerce
	 */
	public void noEjercer(){
		//se inserta en posiejer con Ejercicio.indicadorEjercicio a N
		ejercicioPantalla.getEjercicio().setIndicadorEjercicio("N");
		ejercicioBo.insertarPosiejer(ejercicioPantalla.getEjercicio(), ejercicioPantalla.getHistoricoOperacionId(), ejercicioPantalla.getHistoricoTramos(), ejercicioPantalla.getVistamanteje().getUsuario());
		// SMM: Cuando se pulsa noEjercer se ha modificado, de modo que si se viene desde MANTPROD devuelve 'S' 
		varModif = Constantes.CONSTANTE_SI;  
		retornar();		
	}

	/**
	 * Comprueba si se ha cambiado el tipoImporteOperación, muestra mensaje si difiere de la recibida
	 */
	public void cambiaPata(){
		if(!ejercicioPantalla.getEjercicio().getId().getTipoOperacion().equals(this.getTipoOperacion())){
			statusMessages.add(Severity.INFO, "#{messages['ejercicio.validacion.cambioPata']}");
		}
	}
	
	/**
	 * Funcion que desbloquea el HistoricoOperacion y retorna la pantalla que MANTOPER o PRODCOM
	 */
	public void retornar(){
		dbLockService.desbloqueo(HistoricoOperacion.class, ejercicioPantalla.getHistoricoOperacionId());
		Conversation conversacion=Conversation.instance();
		conversacion.redirectToParent();
	}
	
	/**
	 * 
	 */
	public void salir(){		
		varModif = Constantes.CONSTANTE_NO;  
		retornar();
	}
	

	/*
	 * Comprueba si la contrapartida especificada tiene el CMOF firmado, solo
	 * para tipos de Contrapartida Cliente. Devuelve True o False.
	 * 
	 * FUNCTION F_CMOF_NO_FIRMADO RETURN BOOLEAN IS v_cont number; v_return
	 * boolean := false; BEGIN if Contrapartida is not null AND Contrapartida <>
	 * 'FDI' THEN
	 * 
	 * select count(1) into v_cont from gestio_tressoreria.contrapa where
	 * contrapa = Contrapartida and tipocont = 'C';
	 * 
	 * if v_cont > 0 then select count(1) into v_cont from
	 * gestio_tressoreria.docucont where contrapa = Contrapartida and codidocu =
	 * 'CMOF' and estadoco = 'F';
	 * 
	 * if v_cont=0 then v_return := true; else v_return := false; end if; end
	 * if; end if; return v_return;
	 * 
	 * EXCEPTION WHEN OTHERS THEN mostrar_mensaje('Error al comprobar si la
	 * contrapartida tiene el CMOF firmado: ' || sqlerrm); return (FALSE); END;
	 */
	private Integer CMOFNoFirmado(HistoricoOperacion ho) {
		// 0 - Sin errores
		// 1 - CMOF no firmado
		// 2 - Anexo no firmado
		
		try {
			if(!contrapartidaUtil.isInstanceOfContrapartida(ho.getContrapartida())){
				return 0;
			}

			if (ho.getProductoCatalogo()!=null && ho.getProductoCatalogo().getModelpro()!=null 
					&& "DED".equalsIgnoreCase(ho.getProductoCatalogo().getModelpro().getModelpro())){
			return 0;	
			}
			
			if (
				(ho.getContrapartida2()!=null && 
						(  "CAM-MIG".equals(ho.getContrapartida2().getId()) || "BMN-MIG".equals(ho.getContrapartida2().getId()) 
						|| "LBI-MIG".equals(ho.getContrapartida2().getId()) || "BCG-MIG".equals(ho.getContrapartida2().getId())		
						) ) ||
				(ho.getContrapartida()!=null && "CAAMES2AXXX".equals(ho.getContrapartida().getId()))
				){
				return 0;
			}

			Contrapartida contrapartida = contrapartidaUtil.castAsContrapartida(ho.getContrapartida());
			if (contrapartida != null && !"FDI".equalsIgnoreCase(contrapartida.getId())) {
				if (contrapartida.getTipoContrapartida()!=null && "C".equalsIgnoreCase(contrapartida.getTipoContrapartida().getId())) {
					Integer error = this.boletasBo.CMOFNoFirmadoAnexo(contrapartida, ho.getEntidad()); 
					if (error ==2 && !"E".equalsIgnoreCase(contrapartida.getTipoPersona())){
						return 0;
					}
					return error;
				}

			}
		} catch (Exception e) {
			return 0;
		}
		return 0;
	}

	
	
	
	// oO[Getters y Setters]Oo
	public boolean isPasaValidacionEjercer() {
		return pasaValidacionEjercer;
	}

	public void setPasaValidacionEjercer(boolean pasaValidacion) {
		this.pasaValidacionEjercer = pasaValidacion;
	}

	public boolean isPasaValidacionNoEjercer() {
		return pasaValidacionNoEjercer;
	}

	public void setPasaValidacionNoEjercer(boolean pasaValidacionNoEjercer) {
		this.pasaValidacionNoEjercer = pasaValidacionNoEjercer;
	}

	public void setTipoOperacion(String tipoOperacion) {
		this.tipoOperacion = tipoOperacion;
	}

	public String getTipoOperacion() {
		return tipoOperacion;
	}
	
}
