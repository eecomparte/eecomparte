package com.atosorigin.deri.adminoper.ejercicio.screen;

import org.jboss.seam.ScopeType;
import org.jboss.seam.annotations.Name;
import org.jboss.seam.annotations.Scope;

import com.atosorigin.deri.model.adminoper.Ejercicio;
import com.atosorigin.deri.model.adminoper.VistaMantEje;
import com.atosorigin.deri.model.gestionoperaciones.HistoricoOperacionId;
import com.atosorigin.deri.model.mercado.HistoricoTramos;

@Name("ejercicioPantalla")
@Scope(ScopeType.CONVERSATION)
public class EjercicioPantalla {

	protected Ejercicio ejercicio;
	
	protected VistaMantEje vistamanteje;
	
	protected HistoricoTramos historicoTramos;
	
	protected HistoricoOperacionId historicoOperacionId;
	
	public Ejercicio getEjercicio() {
		return ejercicio;
	}

	public void setEjercicio(Ejercicio ejercicio) {
		this.ejercicio = ejercicio;
	}

	public VistaMantEje getVistamanteje() {
		return vistamanteje;
	}

	public void setVistamanteje(VistaMantEje vistamanteje) {
		this.vistamanteje = vistamanteje;
	}

	public HistoricoTramos getHistoricoTramos() {
		return historicoTramos;
	}

	public void setHistoricoTramos(HistoricoTramos historicoTramos) {
		this.historicoTramos = historicoTramos;
	}

	public HistoricoOperacionId getHistoricoOperacionId() {
		return historicoOperacionId;
	}

	public void setHistoricoOperacionId(HistoricoOperacionId historicoOperacionId) {
		this.historicoOperacionId = historicoOperacionId;
	}

}
