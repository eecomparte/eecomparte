package com.atosorigin.deri.adminoper.gestionemir.action;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.List;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.Source;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamSource;
import javax.xml.validation.Schema;
import javax.xml.validation.SchemaFactory;
import javax.xml.validation.Validator;

import org.jboss.seam.ScopeType;
import org.jboss.seam.annotations.Create;
import org.jboss.seam.annotations.Factory;
import org.jboss.seam.annotations.In;
import org.jboss.seam.annotations.Name;
import org.jboss.seam.annotations.Out;
import org.jboss.seam.annotations.Scope;
import org.jboss.seam.core.Conversation;
import org.jboss.seam.core.ResourceBundle;
import org.jboss.seam.international.StatusMessage.Severity;
import org.jboss.seam.security.Identity;
import org.w3c.dom.Document;
import org.xml.sax.SAXException;

import com.atosorigin.common.action.ModoPantalla;
import com.atosorigin.common.action.PaginatedListAction;
import com.atosorigin.common.action.PaginationData;
import com.atosorigin.common.auditdata.AuditData;
import com.atosorigin.common.constantes.Constantes;
import com.atosorigin.common.formvalidator.FormValidator;
import com.atosorigin.common.utils.GenericUtils;
import com.atosorigin.deri.adminoper.gestionemir.business.EmirBo;
import com.atosorigin.deri.adminoper.gestionemir.screen.EmirPantalla;
import com.atosorigin.deri.common.dbLock.DbLockService;
import com.atosorigin.deri.contrapartida.buscadorContrapartida.action.BuscadorContrapartidaAction;
import com.atosorigin.deri.model.contrapartida.Contrapartida;
import com.atosorigin.deri.model.gestionemir.CabeceraEmir;
import com.atosorigin.deri.model.gestionemir.CabeceraEmirReturn;
import com.atosorigin.deri.model.gestionemir.CampoEmir;
import com.atosorigin.deri.model.gestionemir.DescripcionEstadoEmir;
import com.atosorigin.deri.model.gestionemir.DescripcionIndicadorSituacion;
import com.atosorigin.deri.model.gestionemir.DetalleEmir;
import com.atosorigin.deri.model.gestionemir.DetalleEmirId;
import com.atosorigin.deri.model.gestionemir.HistoricoCabeceraEmir;
import com.atosorigin.deri.model.gestionemir.ValoracionEmir;
import com.atosorigin.deri.model.gestionoperaciones.VistaOperacion;
import com.atosorigin.deri.util.MessageBoxAction;
import com.atosorigin.deri.util.MsgBoxAction;

@Name("emirAction")
@Scope(ScopeType.CONVERSATION)
@FormValidator
public class EmirAction extends PaginatedListAction {

	private static final String W3C_XML_SCHEMA_NS_URI = "http://www.w3.org/2001/XMLSchema";
	private static final String SCHEMA_LANGUAGE_CONSTANT = "http://java.sun.com/xml/jaxp/properties/schemaLanguage";
	private static final String SCHEMA_SOURCE_CONSTANT = "http://java.sun.com/xml/jaxp/properties/schemaSource";

	
	// oO[Variables y Constantes]Oo
	@In("#{emirBo}")
	protected EmirBo emirBo;
	
	@In(create=true)
	@Out
	protected EmirPantalla emirPantalla;
	
	protected boolean editarCampoRendered = false;
	protected String contenidoEdit;
	
	/** Inyección del servicio que gestiona los bloqueos de registros en base de datos */
	@In(create = true)
	protected DbLockService dbLockService;
	
	@In(create = true)
	private BuscadorContrapartidaAction buscadorContrapartidaAction;
	
	@Out(required = false, value = "emir.estados")
	List<DescripcionEstadoEmir> estadosList = null;
	
	@Out(required = false, value = "emir.tipoTransaccion")
	List<DescripcionIndicadorSituacion> tipoTransaccionList = null;
	
	
	
	@Out(required = false, value = "emirMessageBoxAction")
	private MessageBoxAction messageBoxActionEmir;
	
	@In(create = true)
	MsgBoxAction msgBoxAction;
	
	@Out(required = false, value = "emirMessageBoxActionContrapa")
	private MessageBoxAction messageBoxEmirAction;
	
	// oO[Métodos]Oo	
	@Create
	public void creacio(){
		if (messageBoxActionEmir==null){
			messageBoxActionEmir = new MessageBoxAction();
		}
		if (emirPantalla.getEstado()==null && isPrimerAcceso()){
			emirPantalla.setEstado(emirBo.recuperarEstado("TP"));
		}
	}
	
	public void init(){
		
		if (messageBoxActionEmir==null){
			messageBoxActionEmir = new MessageBoxAction();
		}
//		if (emirPantalla.getEstado()==null && isPrimerAcceso()){
//			emirPantalla.setEstado(emirBo.recuperarEstado("TP"));
//		}
		
		if(null==messageBoxEmirAction){
			messageBoxEmirAction = new MessageBoxAction();
		}
		
		refrescarLista();
	}

	public boolean existeSeleccion() {

		return !GenericUtils.isNullOrEmpty(emirPantalla.getListasSeleccionadas());
	}

	public boolean existenDatos() {

		return !GenericUtils.isNullOrEmpty(getDataTableList());
	}

	public void seleccionarLista(){ }
	
	@Out
	public Boolean getSelectedRow() {
		if (emirPantalla.getEmirSelec() != null && emirPantalla.getListasSeleccionadas() != null) {
			return contains(emirPantalla.getEmirSelec());
		} else {
			return false;
		}
	}

	public void setSelectedRow(Boolean selected) {
		if (selected) {
			 emirPantalla.getListasSeleccionadas().add((CabeceraEmir) emirPantalla.getEmirSelec());
		} else {
			 emirPantalla.getListasSeleccionadas().remove((CabeceraEmir) emirPantalla.getEmirSelec());
		}
	}
	
	public boolean contains(CabeceraEmir selectedCE){
		boolean ret = false;
		for (CabeceraEmir ce : emirPantalla.getListasSeleccionadas()) {
			if(ce.equals(selectedCE)){
				ret = true;
				break;
			}
		} 
		return ret; 
	}

	public void deseleccionarTodos(){
		emirPantalla.getListasSeleccionadas().clear();
	}

	public void seleccionarTodos(){
		int maxSelected;
		int tmpMaxResults = paginationData.getMaxResults();
		int tmpFirstResult = paginationData.getFirstResult();
		
		paginationData.setMaxResults(501);
		paginationData.setFirstResult(0);
		setExportExcel(false);
		List<CabeceraEmir> listaCabeceraEmir =null;
		if (emirPantalla.getEstado()==null || "PV".equalsIgnoreCase(emirPantalla.getEstado().getCodigoDatoEmir())){
			DescripcionEstadoEmir estado = emirBo.recuperarEstado("PV");
			listaCabeceraEmir = emirBo.obtenerCabeceraEmir(emirPantalla.getNumOper(), emirPantalla.getFechaEnvio(),
					emirPantalla.getContrapartida(), emirPantalla.getProyecto(), estado ,emirPantalla.getTipoTransaccion(),
					paginationData);			
		}
		
		if (listaCabeceraEmir == null){
			emirPantalla.getListasSeleccionadas().clear();	
		}else{
			
		
		int iteraciones = listaCabeceraEmir.size();
		if(listaCabeceraEmir.size() > 500){
			statusMessages.add(Severity.INFO, "#{messages['mantoper.seleccionados.primeros.cincuenta']}");
			iteraciones = 500;
			tmpFirstResult=0;
			maxSelected = 499;
		} else {
			maxSelected = listaCabeceraEmir.size()-1;
		}
		emirPantalla.getListasSeleccionadas().clear(); 
		for(int i = 0; i<iteraciones; i++){
			emirPantalla.getListasSeleccionadas().add(listaCabeceraEmir.get(i));
		}
		
		}
		paginationData.setMaxResults(tmpMaxResults);
		paginationData.setFirstResult(tmpFirstResult);
	}
	
	@SuppressWarnings("unchecked")
	@Override
	public void setDataTableList(List<?> dataTableList) {
		this.emirPantalla
				.setEmirList((List<CabeceraEmir>) dataTableList);
	}

	@Override
	public List<CabeceraEmir> getDataTableList() {
		return this.emirPantalla.getEmirList();
	}

	@Override
	public void refrescarListaExcel() {
		setExportExcel(true);

		List<CabeceraEmir> listaCabeceraEmir = emirBo.obtenerCabeceraEmir(emirPantalla.getNumOper(), emirPantalla.getFechaEnvio(),
				emirPantalla.getContrapartida(), emirPantalla.getProyecto(), emirPantalla.getEstado(),emirPantalla.getTipoTransaccion(),
				paginationData.getPaginationDataForExcel());			


		if (emirPantalla.getEmirList()!=null) {
			emirPantalla.getEmirList().clear();
			emirPantalla.getEmirList().addAll(listaCabeceraEmir);
		}else{
			emirPantalla.setEmirList(listaCabeceraEmir);
		}
		
	}

	@Override
	protected void refreshListInternal() {
		setExportExcel(false);
		List<CabeceraEmir> listaCabeceraEmir = emirBo.obtenerCabeceraEmir(emirPantalla.getNumOper(), emirPantalla.getFechaEnvio(),
				emirPantalla.getContrapartida(), emirPantalla.getProyecto(), emirPantalla.getEstado(),emirPantalla.getTipoTransaccion(),
				paginationData);			


		if (emirPantalla.getEmirList()!=null) {
			emirPantalla.getEmirList().clear();
			emirPantalla.getEmirList().addAll(listaCabeceraEmir);
		}else{
			emirPantalla.setEmirList(listaCabeceraEmir);
		}
			
		
	}

	public void cargarContrapartidas() {
		buscadorContrapartidaAction.buscar();
	}
	
	public void buscar() {
		deseleccionarTodos();
		paginationData.reset();
		setPrimerAcceso(false);	
		refrescarLista();	

	}
	
	public boolean buscarValidator() {
		
		boolean ret = true;
		
		if(emirPantalla.getNumOper() != null && emirPantalla.getNumOper().getLow() != null && emirPantalla.getNumOper().getHigh() != null) {
			if(emirPantalla.getNumOper().getLow() > emirPantalla.getNumOper().getHigh()) {
				statusMessages.add(Severity.ERROR, "#{messages['emir.messages.error.numOper']}");
				ret = false;
			}
		}
		if(emirPantalla.getFechaEnvio() != null && emirPantalla.getFechaEnvio().getLow() != null && emirPantalla.getFechaEnvio().getHigh() != null) {
			if(emirPantalla.getFechaEnvio().getLow().after(emirPantalla.getFechaEnvio().getHigh())) {
				statusMessages.add(Severity.ERROR, "#{messages['emir.messages.error.fechaEnvio']}");
				ret = false;
			}
		}
		return ret;
	}

	
	public void valoracion(){
		List<ValoracionEmir> listaValoraciones = emirBo.cargarValoracion(emirPantalla.getEmirSelec(),new PaginationData());
		emirPantalla.setValoracionList(listaValoraciones);
		
		emirPantalla.setModoPantalla(ModoPantalla.INSPECCION);
		setModoPantalla(ModoPantalla.INSPECCION);
		
	}
	
	public void logTransaccion(){
		List<HistoricoCabeceraEmir> listaCampos = emirBo.cargarLog(emirPantalla.getEmirSelec(),new PaginationData());
		emirPantalla.setLogList(listaCampos);
		emirPantalla.setModoPantalla(ModoPantalla.INSPECCION);
		setModoPantalla(ModoPantalla.INSPECCION);
		
	}

	//Que no esté pasando el batch  : 
	//select codatoem from  deri.emircodi where  codcampo =9999  y codatoem=’N’ y WS-proyecto =codatode
	//
	//Que la operación no esté bloqueda por otro usuario (tratar por deri.bloqueos como una operación normal)
	public boolean editTransaccionValidator() {
		boolean ret = true;
		
		//Escogemos el valor de pantalla pq ha de ser el mismo que el registro seleccionado
		if (emirBo.comprobarBatch(emirPantalla.getProyecto())) {
			statusMessages.add(Severity.ERROR, "#{messages['emir.messages.error.batch']}");
			ret = false;
		}
		if (!dbLockService.bloqueo(CabeceraEmir.class, emirPantalla.getEmirSelec().getId())) {
			statusMessages.add(Severity.ERROR, "#{messages['emir.messages.error.bloqueo']}");
			ret = false;
		}
			
		
		return ret;
	}
	
	public String editTransaccion(){
//		List<DetalleEmir> listaCampos =	new ArrayList(emirPantalla.getEmirSelec().getDetallesEmir()); 
//			emirBo.cargarCampos(emirPantalla.getEmirSelec());
		String ret = Constantes.FAIL;
//		DescripcionEstadoEmir estado = emirBo.recuperarEstado("PV");
		CabeceraEmirReturn emirRet = emirBo.modificarEmir(emirPantalla.getEmirSelec(),
				Identity.instance().getCredentials().getUsername());

		if (emirRet != null && emirRet.getRet() == 0 && emirRet.getCabeceraEmir()!=null){
			
			CabeceraEmir cabecera = emirRet.getCabeceraEmir();
//			cabecera.setEstado(estado);
			cabecera.setIndicadorReprocesada("S");
			cabecera.setUltimoRegistro("S");
			if ("ER".equalsIgnoreCase(emirPantalla.getEmirSelec().getEstado().getCodigoDatoEmir())){
				inicializarCampos(cabecera);
			}
			
			List<DetalleEmir> listaCampos =	new ArrayList(cabecera.getDetallesEmir());
			for (DetalleEmir campo : listaCampos ) {
				campo.setUltimoRegistro("S");
			}
			Collections.sort(listaCampos);
			emirPantalla.setCamposEmirList(listaCampos);
			emirPantalla.setEmirEditat(cabecera);
//			emirPantalla.getEmirList().remove(emirPantalla.getEmirSelec());
//			emirPantalla.getEmirList().add(cabecera);
//			emirPantalla.setEmirSelec(cabecera);
			emirPantalla.setModoPantalla(ModoPantalla.EDICION);
			setModoPantalla(ModoPantalla.EDICION);
			this.primerAcceso=true;
			ret = Constantes.SUCCESS;
			
		}else{
//			List<DetalleEmir> listaCampos =	new ArrayList(emirPantalla.getEmirSelec().getDetallesEmir());
//			emirPantalla.setCamposEmirList(listaCampos);
//			setModoPantalla(ModoPantalla.EDICION);
//			ret = Constantes.SUCCESS;
			if (emirRet != null){
				statusMessages.add(Severity.ERROR, emirRet.getCodError());	
//					String sa = emirBo.salirEmir("R", emirPantalla.getEmirSelec(),
//			Identity.instance().getCredentials().getUsername());

			}else{
				statusMessages.add(Severity.ERROR, "#{messages['emir.messages.error.package']}" );
			}
			
		}
		return ret;
	}
	
	public Boolean editable(String estado){
		return GenericUtils.in(estado, "PV","PD","ER","TE","CO"); 
	}
	
	public Boolean cancelTotal(CabeceraEmir cabecera) {
	//11/05/2015 SUP
		if (!GenericUtils.isNullOrBlank(cabecera.getIndicadorSituacion()) 
				&& "C".equalsIgnoreCase(cabecera.getIndicadorSituacion().getCodigoDatoEmir())){ 
			for (DetalleEmir campo : cabecera.getDetallesEmir()) {
				if (campo.getId().getCodigoDato().getCodigoDato()==108) {
					if ("C".equalsIgnoreCase(campo.getContenidoCampo())) {
						return true;
					}else {
						return false;
					}				
				}
			}	
			return false;
		}else {
			return false;
		}	
	}
	
	public Boolean descartable(String estado){
		return GenericUtils.in(estado, "PV","PD","PE"); 
	}

	public void verTransaccion(){
		List<DetalleEmir> listaCampos =	new ArrayList(emirPantalla.getEmirSelec().getDetallesEmir()); 
//			emirBo.cargarCampos(emirPantalla.getEmirSelec());
		Collections.sort(listaCampos);
		emirPantalla.setCamposEmirList(listaCampos);
		emirPantalla.setEmirEditat(emirPantalla.getEmirSelec());
		emirPantalla.setModoPantalla(ModoPantalla.INSPECCION);
		setModoPantalla(ModoPantalla.INSPECCION);
	}

	
	
	public void  prepareCancelar(){
		messageBoxActionEmir.init("emir.messages.cancelar.pregunta", "emirAction.onMessageBoxCancelarOk()",
		"emirAction.voidFunction()","resultadosConsulta,messagesPanel,tablaResultados");
	}

	public void onMessageBoxCancelarOk(){
		if (cancelarTransaccionValidator()){
			cancelarTransaccion();
		}
	}
	
	public void  prepareDescartar(){
		messageBoxActionEmir.init("emir.messages.descartar.pregunta", "emirAction.onMessageBoxDescartarOk()",
		"emirAction.voidFunction()","resultadosConsulta,messagesPanel,tablaResultados");
	}

	public void onMessageBoxDescartarOk(){
		if (descartarTransaccionValidator()){
			descartarTransaccion();
		}
	}
	
	
	public void prepareValidar(){
		messageBoxActionEmir.init("emir.messages.validar1.pregunta", "emirAction.onMessageBoxValidarOk()",
		"emirAction.voidFunction()","resultadosConsulta,messagesPanel,tablaResultados");
	}

	public void onMessageBoxValidarOk(){
		if (validarTransaccionValidator()){
			validarTransaccion();
		}
	}
	
	public void prepareValidarBatch(){
		messageBoxActionEmir.init("emir.messages.validar.pregunta", "emirAction.onMessageBoxValidarBatchOk()",
		"emirAction.voidFunction()","resultadosConsulta,messagesPanel");
	}
	
	public void onMessageBoxValidarBatchOk(){
		if (validarMasivoValidator()){
			validarMasivo();
		}
	}
	
	public void voidFunction(){
		msgBoxAction.voidFunction();
	}
	
	public boolean validarTransaccionValidator(){
		boolean ret = true;
		
		if (emirBo.comprobarBatch(emirPantalla.getProyecto())) {
			statusMessages.add(Severity.ERROR, "#{messages['emir.messages.error.batch']}");
			ret = false;
		}
		if (!dbLockService.bloqueo(CabeceraEmir.class, emirPantalla.getEmirSelec().getId())) {
			statusMessages.add(Severity.ERROR, "#{messages['emir.messages.error.bloqueo']}");
			ret = false;
		}
			
		
		return ret;
	}

	
	/**
	 * Creará una nueva situación de histórico (tablas DERI. EMIRCAB y DERI.EMIRDET) llamando al package de copia. 
	 * (El package copia todos los datos actualizando el usultact, feultact y numerope), 
	 * se pide confirmación (si hay selección múltiple la confirmación es para todas las operaciones validadas).
	 * 
	 *  Si se confirma la validación
	 *  	Se actualiza el  ESTADOCO a ‘PE’  (EMIRCAB)
	 *  	Se actualiza el  ULTIMREG  a ‘S’ (EMIRCAB y EMIRDET)
	 *  	Se actualiza el  ULTIMREG  del registro anterior  ‘N’ (EMIRCAB y EMIRDET)
	 *  
	 *  El resto de campos ya los ha informado el package  (USULTACT, FEULTACT y NUMEROPE)
	 *  Se valida que  todos los campos obligatorios estén informados (
	 *  Todos los CONTCAMP correspondientes a
	 *  EMIRDET. CODCAMPO =EMIRDECAM.CODCAMPO and EMIRDECAM.INDOBLIG =’S’
	 *  Deben ser <> null y <> spaces si no daremos error de validación)
	 *  Se hace commit (package)
	 *  Si NO se confirma la validación o no están todos los campos obligatorios informados, se hace rollback (package)
	 *  
	 *   
	 */
	public void validarTransaccion(){
		DescripcionEstadoEmir estado = emirBo.recuperarEstado("PE");
		CabeceraEmirReturn emirRet = emirBo.modificarEmir(emirPantalla.getEmirSelec(),
				Identity.instance().getCredentials().getUsername());

		if (emirRet != null && emirRet.getRet() == 0 && emirRet.getCabeceraEmir()!=null){
			CabeceraEmir cabecera = emirRet.getCabeceraEmir();
			//validar fichero XML
			boolean xmlValido = validarXml(emirRet.getCabeceraEmir());

			if (validarCampos(cabecera) && xmlValido){
				cabecera.setEstado(estado);
				emirBo.guardarCabecera(cabecera);
				emirBo.flush();

				//TODO validar el código con package para commit
				String sa = emirBo.salirEmir("C", emirPantalla.getEmirSelec(),
						Identity.instance().getCredentials().getUsername());
				
				refrescarLista();
			}else{//TODO validar el código con package para rollback
				String sa = emirBo.salirEmir("R", emirPantalla.getEmirSelec(),
						Identity.instance().getCredentials().getUsername());
				
				//Si no es válido el xml mostramos mensaje
				if(!xmlValido) {
					statusMessages.add(Severity.ERROR, "#{messages['emir.messages.error.validar.xml']}" );
				} else{
					statusMessages.add(Severity.ERROR, "#{messages['emir.messages.error.campoObligatorio']}" );
				}
					
			}
		}else{
			if (emirRet != null){
				statusMessages.add(Severity.ERROR, emirRet.getCodError());
//				String sa = emirBo.salirEmir("R", emirPantalla.getEmirSelec(),
//						Identity.instance().getCredentials().getUsername());

			}else{
				statusMessages.add(Severity.ERROR, "#{messages['emir.messages.error.package']}" );
			}

		}

		desbloqueo(emirPantalla.getEmirSelec());		
	}


	private boolean validarCampos(CabeceraEmir cabecera) {
		// TODO Auto-generated method stub
		
//		for (DetalleEmir campo : cabecera.getDetallesEmir()) {
//			if ("S".equalsIgnoreCase(campo.getIndicadorObligatorio()) &&
//					GenericUtils.isNullOrBlank(campo.getContenidoCampo())){
//				return false;
//			}
//		}
//		
//		
//		return true;
		
		Boolean tradeIdOblig = false;
		for (DetalleEmir campo : cabecera.getDetallesEmir()) {
			if ("S".equalsIgnoreCase(campo.getIndicadorObligatorio()) 
				&& GenericUtils.isNullOrBlank(campo.getContenidoCampo()) 
				&& campo.getId().getCodigoDato().getCodigoDato()!=51 
				&& campo.getId().getCodigoDato().getCodigoDato()!=52 ){

				return false;
			}
			
			if (campo.getId().getCodigoDato().getCodigoDato()==51 
					&& !GenericUtils.isNullOrBlank(campo.getContenidoCampo())){
				tradeIdOblig = true;
			}
			if (campo.getId().getCodigoDato().getCodigoDato()==52 
					&& !GenericUtils.isNullOrBlank(campo.getContenidoCampo())){
				tradeIdOblig = true;
			}
		}

		if (!tradeIdOblig){
			return false;
		}
		
		return true;
	
	}


	public void validarMasivo(){
	
	 for (CabeceraEmir emir : 	emirPantalla.getListasSeleccionadas()) {
		 
		 if (emir.getEstado()!=null && "PV".equalsIgnoreCase(emir.getEstado().getCodigoDatoEmir())){

			 if (dbLockService.bloqueo(CabeceraEmir.class, emir.getId())) {
			 
			 }else{
				statusMessages.add(Severity.ERROR, "#{messages['emir.messages.error.bloqueo']}");
				continue;
			 }
			 
		 
		 }else{
				statusMessages.add(Severity.ERROR, "#{messages['emir.messages.error.estadoValidar']}");
				continue;
		 }
	
		 emirPantalla.setEmirSelec(emir);
		 validarTransaccion(); 
	 }	
	}
	
	public boolean validarMasivoValidator(){
		boolean ret = true;
		
		if (emirBo.comprobarBatch(emirPantalla.getProyecto())) {
			statusMessages.add(Severity.ERROR, "#{messages['emir.messages.error.batch']}");
			ret = false;
		}
		
		return ret;
	}
	
	public boolean descartarTransaccionValidator(){

		boolean ret = true;
		
		if (emirBo.comprobarBatch(emirPantalla.getProyecto())) {
			statusMessages.add(Severity.ERROR, "#{messages['emir.messages.error.batch']}");
			ret = false;
		}
		if (!dbLockService.bloqueo(CabeceraEmir.class, emirPantalla.getEmirSelec().getId())) {
			statusMessages.add(Severity.ERROR, "#{messages['emir.messages.error.bloqueo']}");
			ret = false;
		}
			
		return ret;
		
	}

	/**
	 * Si se confirma el descarte
	 * 
	 * 		Se actualiza el  USULTACT  con el usuario de pantalla
	 * 		Se actualiza el  FEULTACT  con el timestamp
	 * 		Se actualiza el  ESTADOCO a ‘DE’  (EMIRCAB)
	 * 		Se actualiza el  ULTIMREG  a ‘N’ (EMIRCAB y EMIRDET)
	 * 		Se actualiza el  ULTIMREG  del registro anterior  a  ‘S’ (EMIRCAB y EMIRDET)  
	 * 		-Se recupera la situación anterior ya que el anterior registro es el que se marca como último-
	 * 
	 * Se hace commit (package)
	 * Si NO se confirma la validación, se sale sin modificar el registro
	 * Nota: en este caso NO damos de alta un registro en histórico sino que modificamos el registro 
	 * en cuestión directamente. Es el único caso.
	 * 
	 *  
	 */
	public void descartarTransaccion(){
		DescripcionEstadoEmir estado = emirBo.recuperarEstado("DE");
		CabeceraEmir cabecera = emirPantalla.getEmirSelec();
		
		cabecera.setEstado(estado);
		cabecera.getAuditData().setUsuarioUltimaModi(Identity.instance().getCredentials().getUsername());
		cabecera.getAuditData().setFechaUltimaModi(new Date());
		cabecera.setUltimoRegistro("N");
		
		for (DetalleEmir campo : cabecera.getDetallesEmir()) {
			campo.setUltimoRegistro("N");
			emirBo.guardarDetalle(campo);
		}
		
		emirBo.guardarCabecera(cabecera);
		
		CabeceraEmir cabeceraAnterior = emirBo.buscarRegistroAnterior(cabecera);
		
		cabeceraAnterior.setUltimoRegistro("S");
		
		for (DetalleEmir campo : cabeceraAnterior.getDetallesEmir()) {
			campo.setUltimoRegistro("S");
			emirBo.guardarDetalle(campo);
		}
		
		emirBo.guardarCabecera(cabeceraAnterior);
		emirBo.flush();
		desbloqueo(emirPantalla.getEmirSelec());
		refrescarLista();
	}
	

	public boolean cancelarTransaccionValidator(){
		boolean ret = true;
		
		if (emirBo.comprobarBatch(emirPantalla.getProyecto())) {
			statusMessages.add(Severity.ERROR, "#{messages['emir.messages.error.batch']}");
			ret = false;
		}
		if (!dbLockService.bloqueo(CabeceraEmir.class, emirPantalla.getEmirSelec().getId())) {
			statusMessages.add(Severity.ERROR, "#{messages['emir.messages.error.bloqueo']}");
			ret = false;
		}
			
		
		return ret;
		
	}

	/**
	 * Creará una nueva situación de histórico (tablas DERI. EMIRCAB y DERI.EMIRDET) 
	 * llamando al package de copia. (El package copia todos los datos actualizando el usultact, feultact y numerope), 
	 * se pide confirmación.
	 * 
	 *  Si se confirma la validación	
	 *  	Se actualiza el  ESTADOCO a ‘PV’  (EMIRCAB)
	 *  	Se actualiza el  INDSITUA a ‘C’  (EMIRCAB)
	 *  	Se inicializan los campos , FECHAENV, NUMENVIO, FECHAREC, NUMRECEP, REASCODE, CONTSTAT, RECOSTAT, TRANTYPE (EMIRCAB)
	 *  	Se actualiza el INDREPRO a ’S’
	 *  	Se actualiza el  ULTIMREG  a ‘S’  (EMIRCAB y EMIRDET)
	 *  	Se actualiza el  ULTIMREG  del registro anterior  ‘N’ (EMIRCAB y EMIRDET)
	 *  	Se actualiza el campo 2 (EMIRDET) a ‘Tradetermination’
	 *  	Se dan de alta los campos 97 y 98 en (EMIRDET) con los valores
	 *  		97  fecha del día en formato ‘YYYY-MM-DD’
	 *  		98 ‘E’
	 *  El resto de campos ya los ha informado el package  (USULTACT, FEULTACT y NUMEROPE)
	 *  Se hace commit (package)
	 *  Si NO se confirma la validación, se hace rollback (package)
	 *  
	 *  
	 *  
	 */
	public void cancelarTransaccion(){
		DescripcionEstadoEmir estado = emirBo.recuperarEstado("PV");
		DescripcionIndicadorSituacion indicadorSituacion = emirBo.recuperarIndicadorSituacion("C");
		
//		Boolean existe97 = false;
		Boolean existe108 = false;
		Boolean existe98 = false;
		Date dataUltimaModificacio = null;
		
		CabeceraEmirReturn emirRet = emirBo.modificarEmir(emirPantalla.getEmirSelec(),
				Identity.instance().getCredentials().getUsername());

		if (emirRet != null && emirRet.getRet() == 0 && emirRet.getCabeceraEmir()!=null){
			CabeceraEmir cabecera = emirRet.getCabeceraEmir();
		
				cabecera.setEstado(estado);
				cabecera.setIndicadorSituacion(indicadorSituacion);
				
				inicializarCampos(cabecera);
				cabecera.setIndicadorReprocesada("S");
				cabecera.setUltimoRegistro("S");
				
//				CabeceraEmir cabeceraAnterior = emirBo.buscarRegistroAnterior(cabecera);
	
				for (DetalleEmir campo : cabecera.getDetallesEmir()) {
					if (campo.getId().getCodigoDato().getCodigoDato() == 2){
						campo.setContenidoCampo("TradeTermination");
					}

					if (campo.getId().getCodigoDato().getCodigoDato() == 1){
						
						String numeroOpe = String.format("%06d", cabecera.getId().getNumeroRegistro());
						Integer longitud = campo.getContenidoCampo().length() - 6;
						campo.setContenidoCampo(campo.getContenidoCampo().substring(0, longitud).concat(numeroOpe));
						
					}
					
//					if (campo.getId().getCodigoDato().getCodigoDato() == 97){
//						
//						SimpleDateFormat sdf1 = new SimpleDateFormat(Constantes.YYYYMMDD10);
//						campo.setContenidoCampo(sdf1.format(new Date()));
//						existe97=true;
//					}

					if (campo.getId().getCodigoDato().getCodigoDato() == 108){
					campo.setContenidoCampo("E");
					existe108=true;
					}

					
					if (campo.getId().getCodigoDato().getCodigoDato() == 98){
						campo.setContenidoCampo("E");
						existe98=true;
					}
					dataUltimaModificacio = campo.getAuditData().getFechaUltimaModi();
					campo.setUltimoRegistro("S");
					emirBo.guardarDetalle(campo);
					
					if (campo.getId().getCodigoDato().getCodigoDato() == 63){
						emirBo.borrarDetalle(campo);
						continue;
					}
					
				}
			
//				if (!existe97){
//					CampoEmir campo = emirBo.recuperarCampo(97);
//					DetalleEmirId detalleId = new DetalleEmirId(cabecera, campo, 1);
//					DetalleEmir detalle = new DetalleEmir(detalleId);
//					SimpleDateFormat sdf1 = new SimpleDateFormat(Constantes.YYYYMMDD10);
//					detalle.setContenidoCampo(sdf1.format(new Date()));
//					detalle.setUltimoRegistro("S");
//					detalle.setIndicadorDatoModifManual("N");
//					detalle.setIndicadorDatoValoracion("N");
//					detalle.setIndicadorObligatorio("N");
//					detalle.setUsuarioUltimaModi(Identity.instance().getCredentials().getUsername());
//					detalle.setFechaUltimaModi(dataUltimaModificacio);
//					emirBo.guardarDetalle(detalle);
//				}

				if (!existe108){
					CampoEmir campo = emirBo.recuperarCampo(108);
					DetalleEmirId detalleId = new DetalleEmirId(cabecera, campo, 1);
					DetalleEmir detalle = new DetalleEmir(detalleId);
					detalle.setContenidoCampo("E");
					detalle.setUltimoRegistro("S");
					detalle.setIndicadorDatoModifManual("N");
					detalle.setIndicadorDatoValoracion("N");
					detalle.setIndicadorObligatorio("N");
					AuditData audit = new AuditData();
					audit.setFechaUltimaModi(dataUltimaModificacio);
					audit.setUsuarioUltimaModi(Identity.instance().getCredentials().getUsername());
					detalle.setAuditData(audit);
//					detalle.setUsuarioUltimaModi(Identity.instance().getCredentials().getUsername());
//					detalle.setFechaUltimaModi(dataUltimaModificacio);
					
					emirBo.guardarDetalle(detalle);
				}
				
				if (!existe98){
					CampoEmir campo = emirBo.recuperarCampo(98);
					DetalleEmirId detalleId = new DetalleEmirId(cabecera, campo, 1);
					DetalleEmir detalle = new DetalleEmir(detalleId);
					detalle.setContenidoCampo("E");
					detalle.setUltimoRegistro("S");
					detalle.setIndicadorDatoModifManual("N");
					detalle.setIndicadorDatoValoracion("N");
					detalle.setIndicadorObligatorio("N");
					AuditData audit = new AuditData();
					audit.setFechaUltimaModi(dataUltimaModificacio);
					audit.setUsuarioUltimaModi(Identity.instance().getCredentials().getUsername());
					detalle.setAuditData(audit);
//					detalle.setUsuarioUltimaModi(Identity.instance().getCredentials().getUsername());
//					detalle.setFechaUltimaModi(dataUltimaModificacio);
					
					emirBo.guardarDetalle(detalle);
				}
// SUP 18.06.2015				
			    emirBo.guardarCabecera(cabecera);
			    emirBo.flush();

				if (!emirBo.informaUtiCanc(cabecera,
						Identity.instance().getCredentials().getUsername())){
					
//					statusMessages.add(Severity.ERROR, emirRet.getCodError());
					String sa = emirBo.salirEmir("R", cabecera,
							Identity.instance().getCredentials().getUsername());
					statusMessages.add(Severity.ERROR, "#{messages['emir.messages.error.package']}" );
					if (sa!=null){
						statusMessages.add(Severity.INFO, sa); 
					}
					
				}else{
//				
//				    emirBo.guardarCabecera(cabecera);
//				    emirBo.flush();
				    String sa = emirBo.salirEmir("C", emirPantalla.getEmirSelec(),
					   	Identity.instance().getCredentials().getUsername());

				    if (sa!=null){
					    statusMessages.add(Severity.INFO, sa); 
				    }
				}
				refrescarLista();
		}else{
			if (emirRet != null){
				statusMessages.add(Severity.ERROR, emirRet.getCodError());
//				String sa = emirBo.salirEmir("R", emirPantalla.getEmirSelec(),
//						Identity.instance().getCredentials().getUsername());

			}else{
				statusMessages.add(Severity.ERROR, "#{messages['emir.messages.error.package']}" );
			}

		}
		
		desbloqueo(emirPantalla.getEmirSelec());
	}

	private void inicializarCampos(CabeceraEmir cabecera) {
		cabecera.setFechaEnvio(null);
		cabecera.setNumeroEnvio(null);
		cabecera.setFechaRecepcion(null);
		cabecera.setNumeroRecepcion(null);
		cabecera.setCodigoError(null);
		cabecera.setStatusContrato(null);
		cabecera.setStatusReconciliacion(null);
		cabecera.setTipoTransaccion(null);
	}
	
	public void editContenido(){
		editarCampoRendered = true;
		setContenidoEdit(emirPantalla.getCampoEmirSelec().getContenidoCampo());
	}
	
	public void guardarCampo(){
		emirPantalla.getCampoEmirSelec().setContenidoCampo(getContenidoEdit());
		editarCampoRendered = false;
	}
	
	public void salir() {
	if (modoPantalla != ModoPantalla.INSPECCION) 	{
		desbloqueo(emirPantalla.getEmirSelec());	
		}
		Conversation conversacion = Conversation.instance();
		//Volvemos a la anterior conversación
		if(conversacion.isNested()){
			conversacion.redirectToParent();
		} else {
			redirectToURL("/home.seam");
			conversacion.endAndRedirect();
		}
	}
	
	private void desbloqueo(CabeceraEmir bloqueado) {
			dbLockService.desbloqueo(CabeceraEmir.class, bloqueado.getId());

	}

	public boolean isEditarCampoRendered() {
		return editarCampoRendered;
	}

	public void setEditarCampoRendered(boolean editarCampoRendered) {
		this.editarCampoRendered = editarCampoRendered;
	}

	public String getContenidoEdit() {
		return contenidoEdit;
	}

	public void setContenidoEdit(String contenidoEdit) {
		this.contenidoEdit = contenidoEdit;
	}

	@Factory("emir.estados")
	public void initEstadosList() {
		estadosList = new ArrayList<DescripcionEstadoEmir>();
		estadosList =  emirBo.obtenerDescripcionEstadosEmir();
	}
	
	@Factory("emir.tipoTransaccion")
	public void initTipoTransaccionList() {
		tipoTransaccionList = new ArrayList<DescripcionIndicadorSituacion>();
		tipoTransaccionList =  emirBo.obtenerDescripcionIndicadorSituacion();
	}
	
	/**
	 * 
	 * @param cabecera
	 * @return
	 */
	private boolean validarXml(CabeceraEmir cabecera){
		// parse an XML document into a DOM tree
		try {
			File fiche = emirBo.generarFichero(cabecera);
			if (fiche == null)
				return true;

			DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
			dbf.setNamespaceAware(true); //Must enable namespace processing!! (sin esta línea no funciona)
			Document doc = null;

			try {
				DocumentBuilder parser = dbf.newDocumentBuilder();
				Document document = parser.parse(fiche);

				// create a SchemaFactory capable of understanding XML schemas
				SchemaFactory factory = SchemaFactory.newInstance(W3C_XML_SCHEMA_NS_URI);

				// load an XML schema
				//Source schemaFile = new StreamSource(getClass().getResourceAsStream("/extra/validaEmir.xsd"));
				Source schemaFile = new StreamSource(getClass().getResourceAsStream("/extra/validaEmir.xsd"));
				Schema schema = factory.newSchema(schemaFile);

				// create a Validator instance and validate document
				Validator validator = schema.newValidator();
				validator.validate(new DOMSource(document));				
				
				return true;

			} catch (ParserConfigurationException e) {
				e.printStackTrace();
			} catch (SAXException e) {
				e.printStackTrace();
			} catch (IOException e) {
				e.printStackTrace();
			}

		} catch (Exception ep) {

		}
		return false;
			
	}
	
	private Boolean primeraEjecucionInit=null;
	public void initEditar(){
		if (primeraEjecucionInit == null) {
			primeraEjecucionInit=true;
		}
		else{
			primeraEjecucionInit = false;
		}
		
		if(null==messageBoxEmirAction){
			messageBoxEmirAction = new MessageBoxAction();
		}
		
		if(primeraEjecucionInit){// && getModoPantalla().equals(ModoPantalla.EDICION)){
			
		}
	}
	
	/**
	 * Mostrar PopUp cuando una contrapartida está bloqueada (no bloqueante)
	 */
	public void onVerificarContrapartidaBloqueada() {
		String contrapartida = emirPantalla.getContrapartida();
		if (!GenericUtils.isNullOrBlank(contrapartida)){
			 Contrapartida contrapObtenida2 = emirBo.cargarContrapartida(contrapartida.toUpperCase());	
			if (null!=contrapObtenida2 && !GenericUtils.isNullOrBlank(contrapObtenida2.getIndBloqueo()) && "S".equalsIgnoreCase(contrapObtenida2.getIndBloqueo())){
				abrirPopUpContrapartidaBloqueada();
			}
		}
	}
	
	private void abrirPopUpContrapartidaBloqueada(){
		messageBoxEmirAction.init("emir.messages.contrapartida.bloqueada.texto", "liquidacionesAction.voidFunction()", null,"messageBoxPanelContrapa");
	}
	
	 public String getRowClasses(){
	    	StringBuilder builder = new StringBuilder();
	    	int i=0;
	    	
	    	Contrapartida contrapartidaObtenida = null;
	    	for(CabeceraEmir cabeceraActual : emirPantalla.getEmirList()){
	    		if(i>0){
					builder.append(",");
				}
	    		
	    		if(null!=cabeceraActual && null!=cabeceraActual.getContrapartida()){
	    			String idContrapartida = cabeceraActual.getContrapartida();
	    			if(null!=idContrapartida && idContrapartida.trim().length()>0){
	    				contrapartidaObtenida = emirBo.cargarContrapartida(idContrapartida.toUpperCase());
	    			}
	    		}
	    		
	    		if(i%2==0){
	    			if(null!=contrapartidaObtenida && !GenericUtils.isNullOrBlank(contrapartidaObtenida.getIndBloqueo()) && "S".equalsIgnoreCase(contrapartidaObtenida.getIndBloqueo())){
	    				builder.append("oddRowRed");
	    			}
	    			else{
	    				builder.append("oddRow");
	    			}
	    		}
	    		else{
	    			if(null!=contrapartidaObtenida && !GenericUtils.isNullOrBlank(contrapartidaObtenida.getIndBloqueo()) && "S".equalsIgnoreCase(contrapartidaObtenida.getIndBloqueo())){
	    				builder.append("evenRowRed");
	    			}
	    			else{
	    				builder.append("evenRow");
	    			}
	    		}
	    		i++;
	    		contrapartidaObtenida = null;
	    	}
	    	
	    	return builder.toString();
	    }
}
