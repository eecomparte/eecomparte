package com.atosorigin.deri.adminoper.gestionemir.action;

import java.io.UnsupportedEncodingException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.regex.Pattern;

import org.jboss.seam.ScopeType;
import org.jboss.seam.annotations.Create;
import org.jboss.seam.annotations.In;
import org.jboss.seam.annotations.Name;
import org.jboss.seam.annotations.Out;
import org.jboss.seam.annotations.Scope;
import org.jboss.seam.core.Conversation;
import org.jboss.seam.core.ResourceBundle;
import org.jboss.seam.international.StatusMessage.Severity;
import org.jboss.seam.security.Identity;

import com.atosorigin.common.action.ModoPantalla;
import com.atosorigin.common.action.PaginatedListAction;
import com.atosorigin.common.constantes.Constantes;
import com.atosorigin.common.formvalidator.FormValidator;
import com.atosorigin.common.utils.GenericUtils;
import com.atosorigin.deri.adminoper.gestionemir.business.EmirBo;
import com.atosorigin.deri.adminoper.gestionemir.screen.EmirPantalla;
import com.atosorigin.deri.common.dbLock.DbLockService;
import com.atosorigin.deri.model.contrapartida.Contrapartida;
import com.atosorigin.deri.model.gestionemir.CabeceraEmir;
import com.atosorigin.deri.model.gestionemir.DescripcionEstadoEmir;
import com.atosorigin.deri.model.gestionemir.DetalleEmir;
import com.atosorigin.deri.model.gestionemir.EmirCodi;
import com.atosorigin.deri.util.MessageBoxAction;
import com.atosorigin.deri.util.MsgBoxAction;

@Name("emirDetalleAction")
@Scope(ScopeType.CONVERSATION)
@FormValidator
public class EmirDetalleAction extends PaginatedListAction {

	// oO[Variables y Constantes]Oo
	@In("#{emirBo}")
	protected EmirBo emirBo;
	
	@In(create=true)
	protected EmirPantalla emirPantalla;
	
	private boolean mostrarCombo;
	protected boolean editarCampoRendered = false;
	
	/** Inyección del servicio que gestiona los bloqueos de registros en base de datos */
	@In(create = true)
	protected DbLockService dbLockService;
	
	public String campoNulos = "NULOS";
	
	@Out(required = false, value = "emirDetalleMessageBoxAction")
	private MessageBoxAction messageBoxActionEmir;
	
	
	@Out(required = false, value = "emirDetalle2MessageBoxAction")
	private MessageBoxAction messageBoxActionEmir2;
	
	/** Inyeccion del componente necesario para mostrar mensajes de decisión al usuario */
	@In(create = true)
	private MsgBoxAction msgBoxAction;
	
	private Boolean primeraEjecucionInit=null;
	// oO[Métodos]Oo	

	@Create
	public void init(){
		paginationData.setMaxResults(30);
		if (messageBoxActionEmir==null){
			messageBoxActionEmir = new MessageBoxAction();
		}
		if(messageBoxActionEmir2==null) messageBoxActionEmir2 = new MessageBoxAction();
		
		if (emirPantalla.getModoPantalla()!=null){
		setModoPantalla(emirPantalla.getModoPantalla());
		}
			
	}

	public boolean existeSeleccion() {

		return !GenericUtils.isNullOrEmpty(emirPantalla.getListasSeleccionadas());
	}

	public boolean existenDatos() {

		return !GenericUtils.isNullOrEmpty(getDataTableList());
	}

	public void seleccionarLista(){ }
	
//	@Out
//	public Boolean getSelectedRow() {
//		if (emirPantalla.getEmirSelec() != null && emirPantalla.getListasSeleccionadas() != null) {
//			return contains(emirPantalla.getEmirSelec());
//		} else {
//			return false;
//		}
//	}
//
//	public void setSelectedRow(Boolean selected) {
//		if (selected) {
//			 emirPantalla.getListasSeleccionadas().add((CabeceraEmir) emirPantalla.getEmirSelec());
//		} else {
//			 emirPantalla.getListasSeleccionadas().remove((CabeceraEmir) emirPantalla.getEmirSelec());
//		}
//	}
//	
//	public boolean contains(CabeceraEmir selectedCE){
//		boolean ret = false;
//		for (CabeceraEmir ce : emirPantalla.getListasSeleccionadas()) {
//			if(ce.equals(selectedCE)){
//				ret = true;
//				break;
//			}
//		} 
//		return ret; 
//	}
//
//	public void deseleccionarTodos(){
//		emirPantalla.getListasSeleccionadas().clear();
//	}
//
//	public void seleccionarTodos(){
//		int maxSelected;
//		int tmpMaxResults = paginationData.getMaxResults();
//		int tmpFirstResult = paginationData.getFirstResult();
//		
//		paginationData.setMaxResults(501);
//		paginationData.setFirstResult(0);
//		setExportExcel(false);
//		List<CabeceraEmir> listaCabeceraEmir =null;
//		if (emirPantalla.getEstado()==null || "PV".equalsIgnoreCase(emirPantalla.getEstado().getCodigoDatoEmir())){
//			DescripcionEstadoEmir estado = emirBo.recuperarEstado("PV");
//			listaCabeceraEmir = emirBo.obtenerCabeceraEmir(emirPantalla.getNumOper(), emirPantalla.getFechaEnvio(),
//					emirPantalla.getContrapartida(), emirPantalla.getProyecto(), estado ,emirPantalla.getTipoTransaccion(),
//					paginationData);			
//		}
//		
//		if (listaCabeceraEmir == null){
//			emirPantalla.getListasSeleccionadas().clear();	
//		}else{
//			
//		
//		int iteraciones = listaCabeceraEmir.size();
//		if(listaCabeceraEmir.size() > 500){
//			statusMessages.add(Severity.INFO, "#{messages['mantoper.seleccionados.primeros.cincuenta']}");
//			iteraciones = 500;
//			tmpFirstResult=0;
//			maxSelected = 499;
//		} else {
//			maxSelected = listaCabeceraEmir.size()-1;
//		}
//		emirPantalla.getListasSeleccionadas().clear(); 
//		for(int i = 0; i<iteraciones; i++){
//			emirPantalla.getListasSeleccionadas().add(listaCabeceraEmir.get(i));
//		}
//		
//		}
//		paginationData.setMaxResults(tmpMaxResults);
//		paginationData.setFirstResult(tmpFirstResult);
//	}
//	
	@SuppressWarnings("unchecked")
	@Override
	public void setDataTableList(List<?> dataTableList) {
		this.emirPantalla
				.setCamposEmirList((List<DetalleEmir>) dataTableList);
	}

	@Override
	public List<DetalleEmir> getDataTableList() {
		return this.emirPantalla.getCamposEmirList();
	}

	@Override
	public void refrescarListaExcel() {
		setExportExcel(true);
		List<DetalleEmir> listaCampos =	new ArrayList(emirPantalla.getEmirEditat().getDetallesEmir());
		Collections.sort(listaCampos);
		this.emirPantalla.setCamposEmirList(listaCampos);
	}

	@Override
	protected void refreshListInternal() {
		setExportExcel(false);
		List<DetalleEmir> listaCampos =	new ArrayList(emirPantalla.getEmirEditat().getDetallesEmir()); 
		Collections.sort(listaCampos);
		Integer ultimoRegistro;
		if (listaCampos.size()>= paginationData.getFirstResult() + paginationData.getMaxResults()+1){
			ultimoRegistro = paginationData.getFirstResult() + paginationData.getMaxResults()+1;
		}else{
			ultimoRegistro = listaCampos.size(); 
		}
//		listaCampos.subList(paginationData.getFirstResult(),ultimoRegistro);
		this.emirPantalla.setCamposEmirList(listaCampos.subList(paginationData.getFirstResult(),ultimoRegistro));
	}


	
	
	public Boolean editable(String estado){
		return GenericUtils.in(estado, "PV","PD","ER"); 
	}
	
	public Boolean descartable(String estado){
		return GenericUtils.in(estado, "PV","PD","PE"); 
	}

	public void verTransaccion(){
		List<DetalleEmir> listaCampos =	new ArrayList(emirPantalla.getEmirSelec().getDetallesEmir()); 
//			emirBo.cargarCampos(emirPantalla.getEmirSelec());
		emirPantalla.setCamposEmirList(listaCampos);
		emirPantalla.setModoPantalla(ModoPantalla.INSPECCION);
		setModoPantalla(ModoPantalla.INSPECCION);
	}

	


	private boolean validarCampos(CabeceraEmir cabecera) {
		// TODO Auto-generated method stub
		
		for (DetalleEmir campo : cabecera.getDetallesEmir()) {
			if ("S".equalsIgnoreCase(campo.getIndicadorObligatorio()) &&
					GenericUtils.isNullOrBlank(campo.getContenidoCampo())){
				return false;
			}
		}
		return true;
	}


	
	public boolean descartarTransaccionValidator(){

		boolean ret = true;
		
		if (emirBo.comprobarBatch(emirPantalla.getProyecto())) {
			statusMessages.add(Severity.ERROR, "#{messages['emir.messages.error.batch']}");
			ret = false;
		}
		if (!dbLockService.bloqueo(CabeceraEmir.class, emirPantalla.getEmirSelec().getId())) {
			statusMessages.add(Severity.ERROR, "#{messages['emir.messages.error.bloqueo']}");
			ret = false;
		}
			
		
		return ret;
		
	}


	private void inicializarCampos(CabeceraEmir cabecera) {
		cabecera.setFechaEnvio(null);
		cabecera.setNumeroEnvio(null);
		cabecera.setFechaRecepcion(null);
		cabecera.setNumeroRecepcion(null);
		cabecera.setCodigoError(null);
		cabecera.setStatusContrato(null);
		cabecera.setStatusReconciliacion(null);
		cabecera.setTipoTransaccion(null);
	}
	
	
	public List<EmirCodi> listaCodigosCampo(){
		if (emirPantalla.getCampoEmirSelec()==null || emirPantalla.getCampoEmirSelec().getId()==null){
			return null;
		}
		Integer codigoCampo = emirPantalla.getCampoEmirSelec().getId().getCodigoDato().getCodigoDato();
		return emirBo.listaCodigosCampo(codigoCampo);
	}
	
	public void editContenido(){
		List<EmirCodi> lista= listaCodigosCampo();
		if (lista==null || lista.size()==0){
			setMostrarCombo(false);
		}else{
			setMostrarCombo(true);
		}
		editarCampoRendered = true;
	}
	
	public void guardarCampo(){
		emirPantalla.getCampoEmirSelec().setIndicadorDatoModifManual("S");
		editarCampoRendered = false;
		
	}
	

	public boolean validarAceptar(){
		String mensaje;
		Boolean tradeIdOblig = false;
		for (DetalleEmir campo : emirPantalla.getEmirEditat().getDetallesEmir()) {
			if ("S".equalsIgnoreCase(campo.getIndicadorObligatorio()) 
				&& GenericUtils.isNullOrBlank(campo.getContenidoCampo()) 
				&& campo.getId().getCodigoDato().getCodigoDato()!=51 
				&& campo.getId().getCodigoDato().getCodigoDato()!=52 ){
				
				mensaje = ResourceBundle.instance().getString("emir.messages.error.campoObligatorio") + " (" 
				+ campo.getDescripcionExtendida() + " )" ;
				statusMessages.add(Severity.ERROR, mensaje);
				
//				statusMessages.add(Severity.ERROR, "#{messages['emir.messages.error.campoObligatorio']}");
				return false;
			}
			if ("S".equalsIgnoreCase(campo.getIndicadorObligatorio()) 
					&& campoNulos.equalsIgnoreCase(campo.getContenidoCampo()) 
					&& campo.getId().getCodigoDato().getCodigoDato()!=51 
					&& campo.getId().getCodigoDato().getCodigoDato()!=52 ){
					
					mensaje = ResourceBundle.instance().getString("emir.messages.error.campoObligatorio") + " (" 
					+ campo.getDescripcionExtendida() + " )" ;
					statusMessages.add(Severity.ERROR, mensaje);
					

					return false;
				}
			
			if (campo.getId().getCodigoDato().getCodigoDato()==51 
					&& !GenericUtils.isNullOrBlank(campo.getContenidoCampo())){
				tradeIdOblig = true;
			}
			if (campo.getId().getCodigoDato().getCodigoDato()==52 
					&& !GenericUtils.isNullOrBlank(campo.getContenidoCampo())){
				tradeIdOblig = true;
			}
			
			if (!campoNulos.equalsIgnoreCase(campo.getContenidoCampo()) && !comprobarFormato(campo)){
				return false;
			}
		}
		if (!tradeIdOblig){
			mensaje = ResourceBundle.instance().getString("emir.messages.error.tradeId");
			statusMessages.add(Severity.ERROR, mensaje);
			return false;
		}
		
		return true;
	}
	
	
	private boolean comprobarFormato(DetalleEmir campo) {
		String mensaje;
		if (campo.getContenidoCampo()==null ){
			return true;
		}
		
		if (campo.getContenidoCampo()!=null && (campo.getId().getCodigoDato().getLongitud()<campo.getContenidoCampo().length())){
			mensaje = ResourceBundle.instance().getString("emir.messages.error.longitud") + " (" 
			+ campo.getDescripcionExtendida() + " )" ;
			statusMessages.add(Severity.ERROR, mensaje);
			return false;
		}
//		Double.valueOf(campos[j]);  NumberFormat nf = NumberFormat.getInstance();        [-+]?[0-9]+[\\.[0-9]+]? System.out.println( nf.parse(text)
		if (campo.getContenidoCampo()!=null && "N".equalsIgnoreCase(campo.getId().getCodigoDato().getFormato()) && 
				!Pattern.matches("[-+]?[0-9]+(\\.[0-9]+)?",campo.getContenidoCampo())
				){
			mensaje = ResourceBundle.instance().getString("emir.messages.error.numerico") + " (" 
			+ campo.getDescripcionExtendida() + " )" ;
			statusMessages.add(Severity.ERROR, mensaje);
//			statusMessages.add(Severity.ERROR, "#{messages['emir.messages.error.numerico']}");
			return false;
		}
/* 
 * Formats Numerics
 *
 *	N1        13 enters, 5 decimals amb signe   +/-13n.5n
 * 			  999999999999999.99999 Valor Admitido para N1
 *	N2        10 enters sense signe OK 10n  
 *  N3        18 enters, 2 decimals amb signe +/-18n.2n
 *	N4        2 enters, 8 decimals amb signe  OK  +/-2n.8n
 *	N5        6 enters, 10 decimals sense signe 6n.10n
 *	N6        5 enters, 5 decimals sense signe OK 5n.5n
 *	N7        5 enters, 5 decimals amb signe OK +/-5n.5n
 *	N8        18 enters, 6 decimals sense signe 18n.6n
 *	N9 antic    18 enters, 2 decimals 18n.2n
 *  N9 nou    1 enters, 9 decimals amb signe +/-1n.9n
 *  NB		  11 enters, 7 decimals SENSE signe  11n.7n
 *  NC		  9 enters, 9 decimals SENSE signe  9n.9n
 *  ND		  7 enters, 3 decimals amb signe  +/-3n.7n  
*/
		
		/** H	Hora HH:MI:SSZ		 */
		
		if (campo.getContenidoCampo()!=null){

			//	N1        13 enters, 5 decimals amb signe   +/-13n.5n
			if ("N1".equalsIgnoreCase(campo.getId().getCodigoDato().getFormato()) && 
					!Pattern.matches("[-+]?[0-9]{1,13}(\\.[0-9]{1,5})+",campo.getContenidoCampo()) &&
					!"999999999999999.99999".equals(campo.getContenidoCampo())
					){
				mensaje = ResourceBundle.instance().getString("emir.messages.error.numericoN1") + " (" 
				+ campo.getDescripcionExtendida() + " )" ;
				statusMessages.add(Severity.ERROR, mensaje);
				return false;
			}
		
		//N2        10 enters sense signe OK 10n  
		if ("N2".equalsIgnoreCase(campo.getId().getCodigoDato().getFormato()) && 
				!Pattern.matches("[0-9]+",campo.getContenidoCampo())
				){
			mensaje = ResourceBundle.instance().getString("emir.messages.error.numericoN2") + " (" 
			+ campo.getDescripcionExtendida() + " )" ;
			statusMessages.add(Severity.ERROR, mensaje);
			return false;
		}

		
		
		// *  N3        18 enters, 2 decimals amb signe +/-18n.2n
		if ("N3".equalsIgnoreCase(campo.getId().getCodigoDato().getFormato()) && 
				!Pattern.matches("[-+]?[0-9]{1,18}(\\.[0-9]{1,2})+",campo.getContenidoCampo())
				){
			mensaje = ResourceBundle.instance().getString("emir.messages.error.numericoN3") + " (" 
			+ campo.getDescripcionExtendida() + " )" ;
			statusMessages.add(Severity.ERROR, mensaje);
			return false;
		}

		//		 *	N4        2 enters, 8 decimals amb signe  OK  +/-2n.8n
		if ("N4".equalsIgnoreCase(campo.getId().getCodigoDato().getFormato()) && 
				!Pattern.matches("[-+]?[0-9]{1,2}(\\.[0-9]{1,8})+",campo.getContenidoCampo())
				){
			mensaje = ResourceBundle.instance().getString("emir.messages.error.numericoN4") + " (" 
			+ campo.getDescripcionExtendida() + " )" ;
			statusMessages.add(Severity.ERROR, mensaje);
			return false;
		}

		//		 *	N5        6 enters, 10 decimals sense signe 6n.10n
		if ("N5".equalsIgnoreCase(campo.getId().getCodigoDato().getFormato()) && 
				!Pattern.matches("[0-9]{1,6}(\\.[0-9]{1,10})+",campo.getContenidoCampo())
				){
			mensaje = ResourceBundle.instance().getString("emir.messages.error.numericoN5") + " (" 
			+ campo.getDescripcionExtendida() + " )" ;
			statusMessages.add(Severity.ERROR, mensaje);
			return false;
		}

		//		 *	N6        5 enters, 5 decimals sense signe OK 5n.5n
		if ("N6".equalsIgnoreCase(campo.getId().getCodigoDato().getFormato()) && 
				!Pattern.matches("[0-9]{1,5}(\\.[0-9]{1,5})+",campo.getContenidoCampo())
				){
			mensaje = ResourceBundle.instance().getString("emir.messages.error.numericoN6") + " (" 
			+ campo.getDescripcionExtendida() + " )" ;
			statusMessages.add(Severity.ERROR, mensaje);
			return false;
		}

		//		 *	N7        5 enters, 5 decimals amb signe OK +/-5n.5n
		if ("N7".equalsIgnoreCase(campo.getId().getCodigoDato().getFormato()) && 
				!Pattern.matches("[-+]?[0-9]{1,5}(\\.[0-9]{1,5})+",campo.getContenidoCampo())
				){
			mensaje = ResourceBundle.instance().getString("emir.messages.error.numericoN7") + " (" 
			+ campo.getDescripcionExtendida() + " )" ;
			statusMessages.add(Severity.ERROR, mensaje);
			return false;
		}

		 //*	N8        18 enters, 6 decimals sense signe 18n.6n
		if ("N8".equalsIgnoreCase(campo.getId().getCodigoDato().getFormato()) && 
				!Pattern.matches("[0-9]{1,18}(\\.[0-9]{1,6})+",campo.getContenidoCampo())
				){
			mensaje = ResourceBundle.instance().getString("emir.messages.error.numericoN8") + " (" 
			+ campo.getDescripcionExtendida() + " )" ;
			statusMessages.add(Severity.ERROR, mensaje);
			return false;
		}

		//OBSOLET		 *	N9 nou    18 enters, 2 decimals 18n.2n
//		if ("N9".equalsIgnoreCase(campo.getId().getCodigoDato().getFormato()) && 
//				!Pattern.matches("[0-9]{1,18}(\\.[0-9]{1,2})+",campo.getContenidoCampo())
//				){
//			mensaje = ResourceBundle.instance().getString("emir.messages.error.numericoN9") + " (" 
//			+ campo.getDescripcionExtendida() + " )" ;
//			statusMessages.add(Severity.ERROR, mensaje);
//			return false;
//		}

		 //N9 nou    1 enters, 9 decimals amb signe +/-1n.9n
		if ("N9".equalsIgnoreCase(campo.getId().getCodigoDato().getFormato()) && 
				!Pattern.matches("[-+]?[0-9]{1}(\\.[0-9]{1,9})+",campo.getContenidoCampo())
				){
			mensaje = ResourceBundle.instance().getString("emir.messages.error.numericoN9") + " (" 
			+ campo.getDescripcionExtendida() + " )" ;
			statusMessages.add(Severity.ERROR, mensaje);
			return false;
		}



		//		NB		  11 enters, 7 decimals SENSE signe  11n.7n
		if ("NB".equalsIgnoreCase(campo.getId().getCodigoDato().getFormato()) && 
				!Pattern.matches("[0-9]{1,11}(\\.[0-9]{1,7})+",campo.getContenidoCampo())
				){
			mensaje = ResourceBundle.instance().getString("emir.messages.error.numericoNB") + " (" 
			+ campo.getDescripcionExtendida() + " )" ;
			statusMessages.add(Severity.ERROR, mensaje);
			return false;
		}
		

		//		NC		  9 enters, 9 decimals SENSE signe  9n.9n
		if ("NC".equalsIgnoreCase(campo.getId().getCodigoDato().getFormato()) && 
				!Pattern.matches("[0-9]{1,9}(\\.[0-9]{1,9})+",campo.getContenidoCampo())
				){
			mensaje = ResourceBundle.instance().getString("emir.messages.error.numericoNC") + " (" 
			+ campo.getDescripcionExtendida() + " )" ;
			statusMessages.add(Severity.ERROR, mensaje);
			return false;
		}

		//		ND		  7 enters, 3 decimals amb signe  3n.7n
		if ("ND".equalsIgnoreCase(campo.getId().getCodigoDato().getFormato()) && 
				!Pattern.matches("[-+]?[0-9]{1,3}(\\.[0-9]{1,7})+",campo.getContenidoCampo())
				){
			mensaje = ResourceBundle.instance().getString("emir.messages.error.numericoND") + " (" 
			+ campo.getDescripcionExtendida() + " )" ;
			statusMessages.add(Severity.ERROR, mensaje);
			return false;
		}
		
		//		NA		   15.5 amb signe +/-
//		if ("NA".equalsIgnoreCase(campo.getId().getCodigoDato().getFormato()) && 
//				!Pattern.matches("[-+]?[0-9]{1,15}(\\.[0-9]{1,5})+",campo.getContenidoCampo())
//				){
//			mensaje = ResourceBundle.instance().getString("emir.messages.error.numericoNA") + " (" 
//			+ campo.getDescripcionExtendida() + " )" ;
//			statusMessages.add(Severity.ERROR, mensaje);
//			return false;
//		}
		
		
		
		if ("D".equalsIgnoreCase(campo.getId().getCodigoDato().getFormato()) && 
				!esFechaValida(campo.getContenidoCampo())){
			mensaje = ResourceBundle.instance().getString("emir.messages.error.fecha") + " (" 
			+ campo.getDescripcionExtendida() + " )" ;
			statusMessages.add(Severity.ERROR, mensaje);
			return false;
		}
		
		if ("H".equalsIgnoreCase(campo.getId().getCodigoDato().getFormato()) && (!esHoraValida(campo.getContenidoCampo().substring(0,8))
			|| !"Z".equals(campo.getContenidoCampo().substring(8,9)	)) 
		){
			mensaje = ResourceBundle.instance().getString("emir.messages.error.horario") + " (" 
			+ campo.getDescripcionExtendida() + " )" ;
			statusMessages.add(Severity.ERROR, mensaje);
			return false;
		}
		
//		if ("H".equalsIgnoreCase(campo.getId().getCodigoDato().getFormato()) && 
//				!Pattern.matches("[0-9]{1,18}(\\.[0-9]{1,2})+",campo.getContenidoCampo())
//				){
//			mensaje = ResourceBundle.instance().getString("emir.messages.error.numericoN9") + " (" 
//			+ campo.getDescripcionExtendida() + " )" ;
//			statusMessages.add(Severity.ERROR, mensaje);
//			return false;
//		}
//		
//		if ("T".equalsIgnoreCase(campo.getId().getCodigoDato().getFormato()) && 
//				!Pattern.matches("[0-9]{1,18}(\\.[0-9]{1,2})+",campo.getContenidoCampo())
//				){
//			mensaje = ResourceBundle.instance().getString("emir.messages.error.numericoN9") + " (" 
//			+ campo.getDescripcionExtendida() + " )" ;
//			statusMessages.add(Severity.ERROR, mensaje);
//			return false;
//		}
//		
		//SMM 22/11/2016 A Letras Numeros : _ - . Sin espacios al principio
		// \w  	A word character: [a-zA-Z_0-9]
//		if ("A".equalsIgnoreCase(campo.getId().getCodigoDato().getFormato()) && 
//				!isEbcdic(campo.getContenidoCampo()) ){
//			mensaje = ResourceBundle.instance().getString("emir.messages.error.alfanumerico") + " (" 
//			+ campo.getDescripcionExtendida() + " )" ;
//			statusMessages.add(Severity.ERROR, mensaje);
////			statusMessages.add(Severity.ERROR, "#{messages['emir.messages.error.numerico']}");
//			return false;
//		}

		
		//Ejemplo 2014-02-11T11:13:42
		if ("T".equalsIgnoreCase(campo.getId().getCodigoDato().getFormato()) && 
				!isCampoTimestamp(campo.getContenidoCampo()) ){
			mensaje = ResourceBundle.instance().getString("emir.messages.error.timestamp") + " (" 
			+ campo.getDescripcionExtendida() + " )" ;
			statusMessages.add(Severity.ERROR, mensaje);
//			statusMessages.add(Severity.ERROR, "#{messages['emir.messages.error.numerico']}");
			return false;
		}

		
		if (campo.getId().getCodigoDato().getCodigoDato()==52 && !GenericUtils.isNullOrBlank(campo.getContenidoCampo())) {
			if (!Pattern.matches("[a-zA-Z0-9]+[a-zA-Z:\\-_\\.0-9]*[a-zA-Z0-9]+",campo.getContenidoCampo())						
					&& !Pattern.matches("[a-zA-Z0-9]+",campo.getContenidoCampo())	){
				
				mensaje = ResourceBundle.instance().getString("emir.messages.error.alfanumerico") + " (" 
				+ campo.getDescripcionExtendida() + " )" ;
				statusMessages.add(Severity.ERROR, mensaje);
//				statusMessages.add(Severity.ERROR, "#{messages['emir.messages.error.numerico']}");
				return false;
				}

		
		
		}
		
		
		
		}
		
		return true;
	}
	
	@SuppressWarnings("unused")
	private boolean isCampoTimestamp(String contenidoCampo){
		//Ejemplo 2014-02-11T11:13:42Z
		if(!esFechaValida(contenidoCampo.substring(0,10))) return false;
		
		if (!"T".equals(contenidoCampo.substring(10,11))) return false;
		
		if (!esHoraValida(contenidoCampo.substring(11,19))) return false;
		
		if (!"Z".equals(contenidoCampo.substring(19,20))) return false;
		
		return true;
	}
	
	private boolean esHoraValida(String contenidoCampo) {
//		  if (contenidoCampo == null || !contenidoCampo.matches("\\d{4}-[01]\\d-[0-3]\\d"))
//		        return false;
//		  
		    SimpleDateFormat df = new SimpleDateFormat("HH:mm:ss");
		    df.setLenient(false);
		    try {
		        df.parse(contenidoCampo);
		        return true;
		    } catch (Exception ex) {
		        return false;
		    }
	}
	
	@SuppressWarnings("unused")
	private boolean isEbcdic(String contenidoCampo){
		
		String ebcdic = "IBM-1047";
		try {
			byte[] result2= contenidoCampo.getBytes(ebcdic);
//			result2 = result2;
		} catch (UnsupportedEncodingException e) {
			return false;
		}
		return true;
		
//		   CoderResult result ;
//		CharsetDecoder ebcdicDecoder = Charset.forName("IBM1047").newDecoder();
//		ebcdicDecoder.onMalformedInput(CodingErrorAction.REPORT);
//		ebcdicDecoder.onUnmappableCharacter(CodingErrorAction.REPORT);
//
//		CharBuffer out = CharBuffer.wrap(new char[3200]);
//		 result = ebcdicDecoder.decode(ByteBuffer.wrap(contenidoCampo.getBytes()), out, true);
////		if (result.isError() || result.isOverflow() ||
////		    result.isUnderflow() || result.isMalformed() ||
////		    result.isUnmappable())
////		{
////		    System.out.println("Cannot decode EBCDIC");
////		}
////		else
//		{
//		     result = ebcdicDecoder.flush(out);
//		    if (result.isOverflow())
//		       System.out.println("Cannot decode EBCDIC");
//		    if (result.isUnderflow())
//		        System.out.println("Ebcdic decoded succefully ");
//		}
//		return true;
//		
	}
	
	
	private boolean esFechaValida(String contenidoCampo) {
		  if (contenidoCampo == null || !contenidoCampo.matches("\\d{4}-[01]\\d-[0-3]\\d"))
		        return false;
		    SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd");
		    df.setLenient(false);
		    try {
		        df.parse(contenidoCampo);
		        return true;
		    } catch (Exception ex) {
		        return false;
		    }
	}

	public String preAceptar(){

		messageBoxActionEmir.init("emir.modificarCorrecta", "emirDetalleAction.aceptar()",
				"emirDetalleAction.voidFunction()","resultadosConsulta,messagesPanel,messageBoxPanelAceptarEmir,tablaResultados");

		return "";
	}
	
	public String aceptar(){
		
		if (!validarAceptar()){
			return Constantes.FAIL;
		}
		
		if (modoPantalla != ModoPantalla.INSPECCION) 	{
			desbloqueo(emirPantalla.getEmirSelec());	
			}
		
		for (DetalleEmir campo : emirPantalla.getEmirEditat().getDetallesEmir()) {
			emirBo.guardarDetalle(campo);
		}
		
		DescripcionEstadoEmir estado = emirBo.recuperarEstado("PV");
		emirPantalla.getEmirEditat().setEstado(estado);
		emirBo.guardarCabecera(emirPantalla.getEmirEditat());
		emirBo.flush();
		String sa = emirBo.salirEmir("C", emirPantalla.getEmirEditat(),
				Identity.instance().getCredentials().getUsername());
		
		emirPantalla.setEmirSelec(null);emirPantalla.setCamposEmirList(null);
		return "TO_EMIR";
	}
	
	public void salir() {
	if (modoPantalla != ModoPantalla.INSPECCION) 	{
		desbloqueo(emirPantalla.getEmirSelec());	
		//ROLLBACK
		String sa = emirBo.salirEmir("R", emirPantalla.getEmirSelec(),
				Identity.instance().getCredentials().getUsername());
		emirPantalla.setEmirSelec(null);
		emirPantalla.setCamposEmirList(null);
	}
		
		
		Conversation conversacion = Conversation.instance();
		//Volvemos a la anterior conversación
		if(conversacion.isNested()){
			conversacion.redirectToParent();
		} else {
			redirectToURL("/home.seam");
			conversacion.endAndRedirect();
		}
	}
	
	private void desbloqueo(CabeceraEmir bloqueado) {
			dbLockService.desbloqueo(CabeceraEmir.class, bloqueado.getId());

	}

	public boolean isEditarCampoRendered() {
		return editarCampoRendered;
	}

	public void setEditarCampoRendered(boolean editarCampoRendered) {
		this.editarCampoRendered = editarCampoRendered;
	}

	public boolean isMostrarCombo() {
		return mostrarCombo;
	}

	public void setMostrarCombo(boolean mostrarCombo) {
		this.mostrarCombo = mostrarCombo;
	}

	public String obtenerDescripcion(DetalleEmir detalle){
		return emirBo.obtenerDescripcion(detalle);
	}

	public Boolean isTradeIdField(DetalleEmir detalle){
		if (detalle.getId().getCodigoDato().getCodigoDato()==51 || detalle.getId().getCodigoDato().getCodigoDato()==52){
			return true;
		}

		return false;
	}
	
	public void voidFunction(){
		msgBoxAction.voidFunction();
	}

	/**
	 * Mostrar PopUp cuando una contrapartida está bloqueada (no bloqueante)
	 */
	public void initDetalle() {
		if (primeraEjecucionInit == null) {
			primeraEjecucionInit=true;
		} 
		else{
			primeraEjecucionInit = false;
		}
		
		if(primeraEjecucionInit){		
			if(null!=emirPantalla.getEmirEditat() && null!=emirPantalla.getEmirEditat().getContrapartida()){
				String contrapartida = emirPantalla.getEmirEditat().getContrapartida();
				if (!GenericUtils.isNullOrBlank(contrapartida)){
					 Contrapartida contrapObtenida2 = emirBo.cargarContrapartida(contrapartida.toUpperCase());	
					if (null!=contrapObtenida2 && !GenericUtils.isNullOrBlank(contrapObtenida2.getIndBloqueo()) && "S".equalsIgnoreCase(contrapObtenida2.getIndBloqueo())){
						messageBoxActionEmir2.init("emir.messages.contrapartida.bloqueada.texto", "emirDetalleAction.voidFunction()", null, "messageBoxPanelContrapa");
					}
				}
			}
		}
	}

}
