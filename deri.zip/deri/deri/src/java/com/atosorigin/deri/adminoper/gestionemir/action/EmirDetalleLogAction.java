package com.atosorigin.deri.adminoper.gestionemir.action;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.regex.Pattern;

import java.lang.Object;
import org.jboss.seam.ScopeType;
import org.jboss.seam.annotations.Create;
import org.jboss.seam.annotations.In;
import org.jboss.seam.annotations.Name;
import org.jboss.seam.annotations.Out;
import org.jboss.seam.annotations.Scope;
import org.jboss.seam.core.Conversation;
import org.jboss.seam.core.ResourceBundle;
import org.jboss.seam.international.StatusMessage.Severity;
import org.jboss.seam.security.Identity;



import com.atosorigin.common.action.ModoPantalla;
import com.atosorigin.common.action.PaginatedListAction;
import com.atosorigin.common.constantes.Constantes;
import com.atosorigin.common.formvalidator.FormValidator;
import com.atosorigin.common.utils.GenericUtils;
import com.atosorigin.deri.adminoper.gestionemir.business.EmirBo;
import com.atosorigin.deri.adminoper.gestionemir.screen.EmirPantalla;
import com.atosorigin.deri.common.dbLock.DbLockService;
import com.atosorigin.deri.contrapartida.buscadorContrapartida.action.BuscadorContrapartidaAction;
import com.atosorigin.deri.model.gestionemir.CabeceraEmir;
import com.atosorigin.deri.model.gestionemir.CabeceraEmirId;
import com.atosorigin.deri.model.gestionemir.CabeceraEmirReturn;
import com.atosorigin.deri.model.gestionemir.CampoEmir;
import com.atosorigin.deri.model.gestionemir.DescripcionEstadoEmir;
import com.atosorigin.deri.model.gestionemir.DescripcionIndicadorSituacion;
import com.atosorigin.deri.model.gestionemir.DetalleEmir;
import com.atosorigin.deri.model.gestionemir.DetalleEmirId;
import com.atosorigin.deri.model.gestionemir.EmirCodi;
import com.atosorigin.deri.model.gestionemir.HistoricoDetalleEmir;
import com.atosorigin.deri.util.MessageBoxAction;

@Name("emirDetalleLogAction")
@Scope(ScopeType.CONVERSATION)
@FormValidator
public class EmirDetalleLogAction extends PaginatedListAction {

	// oO[Variables y Constantes]Oo
	@In("#{emirBo}")
	protected EmirBo emirBo;
	
	@In(create=true)
	protected EmirPantalla emirPantalla;
	
	private boolean mostrarCombo;
	protected boolean editarCampoRendered = false;
	
	/** Inyección del servicio que gestiona los bloqueos de registros en base de datos */
	@In(create = true)
	protected DbLockService dbLockService;
	

	
	@Out(required = false, value = "emirMessageBoxAction")
	private MessageBoxAction messageBoxActionEmir;
	
	// oO[Métodos]Oo	

	@Create
	public void init(){
		paginationData.setMaxResults(30);
		if (messageBoxActionEmir==null){
			messageBoxActionEmir = new MessageBoxAction();
		}
		
		if (emirPantalla.getModoPantalla()!=null){
		setModoPantalla(emirPantalla.getModoPantalla());
		}
			
	}

	public boolean existeSeleccion() {

		return !GenericUtils.isNullOrEmpty(emirPantalla.getListasSeleccionadas());
	}

	public boolean existenDatos() {

		return !GenericUtils.isNullOrEmpty(getDataTableList());
	}

	public void seleccionarLista(){ }
	
//	@Out
//	public Boolean getSelectedRow() {
//		if (emirPantalla.getEmirSelec() != null && emirPantalla.getListasSeleccionadas() != null) {
//			return contains(emirPantalla.getEmirSelec());
//		} else {
//			return false;
//		}
//	}
//
//	public void setSelectedRow(Boolean selected) {
//		if (selected) {
//			 emirPantalla.getListasSeleccionadas().add((CabeceraEmir) emirPantalla.getEmirSelec());
//		} else {
//			 emirPantalla.getListasSeleccionadas().remove((CabeceraEmir) emirPantalla.getEmirSelec());
//		}
//	}
//	
//	public boolean contains(CabeceraEmir selectedCE){
//		boolean ret = false;
//		for (CabeceraEmir ce : emirPantalla.getListasSeleccionadas()) {
//			if(ce.equals(selectedCE)){
//				ret = true;
//				break;
//			}
//		} 
//		return ret; 
//	}
//
//	public void deseleccionarTodos(){
//		emirPantalla.getListasSeleccionadas().clear();
//	}
//
//	public void seleccionarTodos(){
//		int maxSelected;
//		int tmpMaxResults = paginationData.getMaxResults();
//		int tmpFirstResult = paginationData.getFirstResult();
//		
//		paginationData.setMaxResults(501);
//		paginationData.setFirstResult(0);
//		setExportExcel(false);
//		List<CabeceraEmir> listaCabeceraEmir =null;
//		if (emirPantalla.getEstado()==null || "PV".equalsIgnoreCase(emirPantalla.getEstado().getCodigoDatoEmir())){
//			DescripcionEstadoEmir estado = emirBo.recuperarEstado("PV");
//			listaCabeceraEmir = emirBo.obtenerCabeceraEmir(emirPantalla.getNumOper(), emirPantalla.getFechaEnvio(),
//					emirPantalla.getContrapartida(), emirPantalla.getProyecto(), estado ,emirPantalla.getTipoTransaccion(),
//					paginationData);			
//		}
//		
//		if (listaCabeceraEmir == null){
//			emirPantalla.getListasSeleccionadas().clear();	
//		}else{
//			
//		
//		int iteraciones = listaCabeceraEmir.size();
//		if(listaCabeceraEmir.size() > 500){
//			statusMessages.add(Severity.INFO, "#{messages['mantoper.seleccionados.primeros.cincuenta']}");
//			iteraciones = 500;
//			tmpFirstResult=0;
//			maxSelected = 499;
//		} else {
//			maxSelected = listaCabeceraEmir.size()-1;
//		}
//		emirPantalla.getListasSeleccionadas().clear(); 
//		for(int i = 0; i<iteraciones; i++){
//			emirPantalla.getListasSeleccionadas().add(listaCabeceraEmir.get(i));
//		}
//		
//		}
//		paginationData.setMaxResults(tmpMaxResults);
//		paginationData.setFirstResult(tmpFirstResult);
//	}
//	
	@SuppressWarnings("unchecked")
	@Override
	public void setDataTableList(List<?> dataTableList) {
		this.emirPantalla
				.setCamposEmirLogList((List<HistoricoDetalleEmir>) dataTableList);
	}

	@Override
	public List<HistoricoDetalleEmir> getDataTableList() {
		return this.emirPantalla.getCamposEmirLogList();
	}

	@Override
	public void refrescarListaExcel() {
		setExportExcel(true);
		List<HistoricoDetalleEmir> listaCampos =	new ArrayList(emirPantalla.getEmirEditatLog().getHistoricoDetallesEmir());
		this.emirPantalla.setCamposEmirLogList(listaCampos);
	}

	@Override
	protected void refreshListInternal() {
		setExportExcel(false);
		List<HistoricoDetalleEmir> listaCampos =	new ArrayList(emirPantalla.getEmirEditatLog().getHistoricoDetallesEmir()); 
		Integer ultimoRegistro;
		if (listaCampos.size()>= paginationData.getFirstResult() + paginationData.getMaxResults()+1){
			ultimoRegistro = paginationData.getFirstResult() + paginationData.getMaxResults()+1;
		}else{
			ultimoRegistro = listaCampos.size(); 
		}
//		listaCampos.subList(paginationData.getFirstResult(),ultimoRegistro);
		this.emirPantalla.setCamposEmirLogList(listaCampos.subList(paginationData.getFirstResult(),ultimoRegistro));
	}


	
	
	public Boolean editable(String estado){
		return GenericUtils.in(estado, "PV","PD","ER"); 
	}
	
	public Boolean descartable(String estado){
		return GenericUtils.in(estado, "PV","PD","PE"); 
	}

//	public void verTransaccion(){
//		List<HistoricoDetalleEmir> listaCampos =	new ArrayList(emirPantalla.getEmirSelec().getDetallesEmir()); 
////			emirBo.cargarCampos(emirPantalla.getEmirSelec());
//		emirPantalla.setCamposEmirLogList(listaCampos);
//		emirPantalla.setModoPantalla(ModoPantalla.INSPECCION);
//		setModoPantalla(ModoPantalla.INSPECCION);
//	}

	


	private boolean validarCampos(CabeceraEmir cabecera) {
		// TODO Auto-generated method stub
		
		for (DetalleEmir campo : cabecera.getDetallesEmir()) {
			if ("S".equalsIgnoreCase(campo.getIndicadorObligatorio()) &&
					GenericUtils.isNullOrBlank(campo.getContenidoCampo())){
				return false;
			}
		}
		return true;
	}


	
	public boolean descartarTransaccionValidator(){

		boolean ret = true;
		
		if (emirBo.comprobarBatch(emirPantalla.getProyecto())) {
			statusMessages.add(Severity.ERROR, "#{messages['emir.messages.error.batch']}");
			ret = false;
		}
		if (!dbLockService.bloqueo(CabeceraEmir.class, emirPantalla.getEmirSelec().getId())) {
			statusMessages.add(Severity.ERROR, "#{messages['emir.messages.error.bloqueo']}");
			ret = false;
		}
			
		
		return ret;
		
	}


	private void inicializarCampos(CabeceraEmir cabecera) {
		cabecera.setFechaEnvio(null);
		cabecera.setNumeroEnvio(null);
		cabecera.setFechaRecepcion(null);
		cabecera.setNumeroRecepcion(null);
		cabecera.setCodigoError(null);
		cabecera.setStatusContrato(null);
		cabecera.setStatusReconciliacion(null);
		cabecera.setTipoTransaccion(null);
	}
	
	
	public List<EmirCodi> listaCodigosCampo(){
		if (emirPantalla.getCampoEmirSelec()==null || emirPantalla.getCampoEmirSelec().getId()==null){
			return null;
		}
		Integer codigoCampo = emirPantalla.getCampoEmirSelec().getId().getCodigoDato().getCodigoDato();
		return emirBo.listaCodigosCampo(codigoCampo);
	}
	
	public void editContenido(){
		List<EmirCodi> lista= listaCodigosCampo();
		if (lista==null || lista.size()==0){
			setMostrarCombo(false);
		}else{
			setMostrarCombo(true);
		}
		editarCampoRendered = true;
	}
	
	public void guardarCampo(){
		emirPantalla.getCampoEmirSelec().setIndicadorDatoModifManual("S");
		editarCampoRendered = false;
		
	}
	

	public boolean validarAceptar(){
		String mensaje;
		Boolean tradeIdOblig = false;
		for (DetalleEmir campo : emirPantalla.getEmirEditat().getDetallesEmir()) {
			if ("S".equalsIgnoreCase(campo.getIndicadorObligatorio()) 
				&& GenericUtils.isNullOrBlank(campo.getContenidoCampo()) 
				&& campo.getId().getCodigoDato().getCodigoDato()!=51 
				&& campo.getId().getCodigoDato().getCodigoDato()!=52 ){
				
				mensaje = ResourceBundle.instance().getString("emir.messages.error.campoObligatorio") + " (" 
				+ campo.getDescripcionExtendida() + " )" ;
				statusMessages.add(Severity.ERROR, mensaje);
				
//				statusMessages.add(Severity.ERROR, "#{messages['emir.messages.error.campoObligatorio']}");
				return false;
			}
			
			if (campo.getId().getCodigoDato().getCodigoDato()==51 
					&& !GenericUtils.isNullOrBlank(campo.getContenidoCampo())){
				tradeIdOblig = true;
			}
			if (campo.getId().getCodigoDato().getCodigoDato()==52 
					&& !GenericUtils.isNullOrBlank(campo.getContenidoCampo())){
				tradeIdOblig = true;
			}
			
			if (!comprobarFormato(campo)){
				return false;
			}
		}
		if (!tradeIdOblig){
			mensaje = ResourceBundle.instance().getString("emir.messages.error.tradeId");
			statusMessages.add(Severity.ERROR, mensaje);
			return false;
		}
		
		return true;
	}
	
	
	private boolean comprobarFormato(DetalleEmir campo) {
		String mensaje;
		if (campo.getContenidoCampo()==null ){
			return true;
		}
		
		if (campo.getContenidoCampo()!=null && (campo.getId().getCodigoDato().getLongitud()<campo.getContenidoCampo().length())){
			mensaje = ResourceBundle.instance().getString("emir.messages.error.longitud") + " (" 
			+ campo.getDescripcionExtendida() + " )" ;
			statusMessages.add(Severity.ERROR, mensaje);
			return false;
		}
//		Double.valueOf(campos[j]);  NumberFormat nf = NumberFormat.getInstance();        [-+]?[0-9]+[\\.[0-9]+]? System.out.println( nf.parse(text)
		if (campo.getContenidoCampo()!=null && "N".equalsIgnoreCase(campo.getId().getCodigoDato().getFormato()) && 
				!Pattern.matches("[-+]?[0-9]+(\\.[0-9]+)?",campo.getContenidoCampo())
				){
			mensaje = ResourceBundle.instance().getString("emir.messages.error.numerico") + " (" 
			+ campo.getDescripcionExtendida() + " )" ;
			statusMessages.add(Severity.ERROR, mensaje);
//			statusMessages.add(Severity.ERROR, "#{messages['emir.messages.error.numerico']}");
			return false;
		}
		return true;
	}

	public String aceptar(){
		
		if (!validarAceptar()){
			return Constantes.FAIL;
		}
		
		if (modoPantalla != ModoPantalla.INSPECCION) 	{
			desbloqueo(emirPantalla.getEmirSelec());	
			}
		
		for (DetalleEmir campo : emirPantalla.getEmirEditat().getDetallesEmir()) {
			emirBo.guardarDetalle(campo);
		}
		
		DescripcionEstadoEmir estado = emirBo.recuperarEstado("PV");
		emirPantalla.getEmirEditat().setEstado(estado);
		emirBo.guardarCabecera(emirPantalla.getEmirEditat());
		emirBo.flush();
		String sa = emirBo.salirEmir("C", emirPantalla.getEmirEditat(),
				Identity.instance().getCredentials().getUsername());
		
		emirPantalla.setEmirSelec(null);emirPantalla.setCamposEmirList(null);
		return Constantes.SUCCESS;
	}
	
	public void salir() {
	if (modoPantalla != ModoPantalla.INSPECCION) 	{
		desbloqueo(emirPantalla.getEmirSelec());	
		//ROLLBACK
		String sa = emirBo.salirEmir("R", emirPantalla.getEmirSelec(),
				Identity.instance().getCredentials().getUsername());
		emirPantalla.setEmirSelec(null);
		emirPantalla.setCamposEmirList(null);
	}
		
		
		Conversation conversacion = Conversation.instance();
		//Volvemos a la anterior conversación
		if(conversacion.isNested()){
			conversacion.redirectToParent();
		} else {
			redirectToURL("/home.seam");
			conversacion.endAndRedirect();
		}
	}
	
	private void desbloqueo(CabeceraEmir bloqueado) {
			dbLockService.desbloqueo(CabeceraEmir.class, bloqueado.getId());

	}

	public boolean isEditarCampoRendered() {
		return editarCampoRendered;
	}

	public void setEditarCampoRendered(boolean editarCampoRendered) {
		this.editarCampoRendered = editarCampoRendered;
	}

	public boolean isMostrarCombo() {
		return mostrarCombo;
	}

	public void setMostrarCombo(boolean mostrarCombo) {
		this.mostrarCombo = mostrarCombo;
	}

	public String obtenerDescripcion(HistoricoDetalleEmir detalle){
		return emirBo.obtenerDescripcion(detalle);
	}

	public Boolean isTradeIdField(HistoricoDetalleEmir detalle){
		if (detalle.getId().getCodigoDato().getCodigoDato()==51 || detalle.getId().getCodigoDato().getCodigoDato()==52){
			return true;
		}

		return false;
	}
}
