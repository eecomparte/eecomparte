package com.atosorigin.deri.adminoper.gestionemir.action;

import java.util.ArrayList;
import java.util.List;

import org.jboss.seam.ScopeType;
import org.jboss.seam.annotations.Create;
import org.jboss.seam.annotations.In;
import org.jboss.seam.annotations.Name;
import org.jboss.seam.annotations.Out;
import org.jboss.seam.annotations.Scope;
import org.jboss.seam.core.ResourceBundle;
import org.jboss.seam.international.StatusMessage.Severity;

import com.atosorigin.common.action.ModoPantalla;
import com.atosorigin.common.action.PaginatedListAction;
import com.atosorigin.common.formvalidator.FormValidator;
import com.atosorigin.common.utils.GenericUtils;
import com.atosorigin.deri.adminoper.boletas.action.BoletasAction.BoletasStates;
import com.atosorigin.deri.adminoper.gestionemir.business.EmirBo;
import com.atosorigin.deri.adminoper.gestionemir.screen.EmirPantalla;
import com.atosorigin.deri.common.dbLock.DbLockService;
import com.atosorigin.deri.contrapartida.buscadorContrapartida.action.BuscadorContrapartidaAction;
import com.atosorigin.deri.model.contrapartida.Contrapartida;
import com.atosorigin.deri.model.gestionemir.CabeceraEmir;
import com.atosorigin.deri.model.gestionemir.DetalleEmir;
import com.atosorigin.deri.model.gestionemir.HistoricoCabeceraEmir;
import com.atosorigin.deri.model.gestionemir.HistoricoDetalleEmir;
import com.atosorigin.deri.model.gestionoperaciones.HistoricoOperacion;
import com.atosorigin.deri.model.gestionoperaciones.VistaOperacion;
import com.atosorigin.deri.model.liquidaciones.VistaLiquidacion;
import com.atosorigin.deri.util.MessageBoxAction;
import com.atosorigin.deri.util.MsgBoxAction;

@Name("emirLogAction")
@Scope(ScopeType.CONVERSATION)
@FormValidator
public class EmirLogAction extends PaginatedListAction {

	// oO[Variables y Constantes]Oo
	@In("#{emirBo}")
	protected EmirBo emirBo;
	
	@In(create=true)
	protected EmirPantalla emirPantalla;
	
	/** Inyección del servicio que gestiona los bloqueos de registros en base de datos */
	@In(create = true)
	protected DbLockService dbLockService;
	
	@Out(required = false, value = "emirLogMessageBoxAction")
	private MessageBoxAction messageBoxActionEmirLog;
	
	/** Inyeccion del componente necesario para mostrar mensajes de decisión al usuario */
	@In(create = true)
	private MsgBoxAction msgBoxAction;
	
	private Boolean primeraEjecucionInit=null;
	
	// oO[Métodos]Oo	
	@Create
	public void init(){
		primeraEjecucionInit = null;
		
		if (emirPantalla.getModoPantalla()!=null){
			setModoPantalla(emirPantalla.getModoPantalla());
		}
	}

	@SuppressWarnings("unchecked")
	@Override
	public void setDataTableList(List<?> dataTableList) {
		this.emirPantalla
				.setLogList((List<HistoricoCabeceraEmir>) dataTableList);
	}

	@Override
	public List<HistoricoCabeceraEmir> getDataTableList() {
		return this.emirPantalla.getLogList();
	}

	@Override
	public void refrescarListaExcel() {
		setExportExcel(true);

		List<HistoricoCabeceraEmir> listaCabeceraEmir = emirBo.cargarLog(emirPantalla.getEmirSelec(),paginationData.getPaginationDataForExcel());
		
		if (emirPantalla.getLogList()!=null) {
			emirPantalla.getLogList().clear();
			emirPantalla.getLogList().addAll(listaCabeceraEmir);
		}else{
			emirPantalla.setLogList(listaCabeceraEmir);
		}
			
	}

	@Override
	protected void refreshListInternal() {
		setExportExcel(false);
		List<HistoricoCabeceraEmir> listaCabeceraEmir = emirBo.cargarLog(emirPantalla.getEmirSelec(),paginationData);
		
		if (emirPantalla.getLogList()!=null) {
			emirPantalla.getLogList().clear();
			emirPantalla.getLogList().addAll(listaCabeceraEmir);
		}else{
			emirPantalla.setLogList(listaCabeceraEmir);
		}
			
		
	}

	
	public void buscar() {

		paginationData.reset();
		setPrimerAcceso(false);	
		refrescarLista();	

	}
	
	public boolean buscarValidator() {
		
		boolean ret = true;
		
		if(emirPantalla.getNumOper() != null && emirPantalla.getNumOper().getLow() != null && emirPantalla.getNumOper().getHigh() != null) {
			if(emirPantalla.getNumOper().getLow() > emirPantalla.getNumOper().getHigh()) {
				statusMessages.add(Severity.ERROR, "#{messages['emir.messages.error.numOper']}");
				ret = false;
			}
		}
		if(emirPantalla.getFechaEnvio() != null && emirPantalla.getFechaEnvio().getLow() != null && emirPantalla.getFechaEnvio().getHigh() != null) {
			if(emirPantalla.getFechaEnvio().getLow().after(emirPantalla.getFechaEnvio().getHigh())) {
				statusMessages.add(Severity.ERROR, "#{messages['emir.messages.error.fechaEnvio']}");
				ret = false;
			}
		}
		return ret;
	}

	

	public void verTransaccion(){
		List<HistoricoDetalleEmir> listaCampos = new ArrayList(emirPantalla.getLogSelec().getHistoricoDetallesEmir());
		emirPantalla.setCamposEmirLogList(listaCampos);
		emirPantalla.setEmirEditatLog(emirPantalla.getLogSelec());
		emirPantalla.setModoPantalla(ModoPantalla.INSPECCION);
		setModoPantalla(ModoPantalla.INSPECCION);
	}

	
	public void salir() {
	if (modoPantalla != ModoPantalla.INSPECCION) 	{
		desbloqueo(emirPantalla.getEmirSelec());	
		}
	emirPantalla.setEmirSelec(null);
	}
	
	private void desbloqueo(CabeceraEmir bloqueado) {
			dbLockService.desbloqueo(CabeceraEmir.class, bloqueado.getId());

	}


	public void initLog(){
		if (primeraEjecucionInit == null) {
			primeraEjecucionInit=true;
		} 
		else{
			primeraEjecucionInit = false;
		}
		if(primeraEjecucionInit){
			
			if(null==messageBoxActionEmirLog) messageBoxActionEmirLog = new MessageBoxAction();
			
			if(null!=emirPantalla.getEmirSelec() && null!=emirPantalla.getEmirSelec().getContrapartida()){
				String contrapartida = emirPantalla.getEmirSelec().getContrapartida();
				if (!GenericUtils.isNullOrBlank(contrapartida)){
					 Contrapartida contrapObtenida2 = emirBo.cargarContrapartida(contrapartida.toUpperCase());	
					if (null!=contrapObtenida2 && !GenericUtils.isNullOrBlank(contrapObtenida2.getIndBloqueo()) && "S".equalsIgnoreCase(contrapObtenida2.getIndBloqueo())){
						messageBoxActionEmirLog.init("emir.messages.contrapartida.bloqueada.texto", "emirDetalleAction.voidFunction()", null, "messageBoxPanelContrapa");
					}
				}
			}
		}
	}
	
}
