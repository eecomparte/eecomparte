package com.atosorigin.deri.adminoper.gestionemir.action;

import java.util.ArrayList;
import java.util.List;

import org.jboss.seam.ScopeType;
import org.jboss.seam.annotations.Create;
import org.jboss.seam.annotations.In;
import org.jboss.seam.annotations.Name;
import org.jboss.seam.annotations.Out;
import org.jboss.seam.annotations.Scope;
import org.jboss.seam.core.ResourceBundle;
import org.jboss.seam.international.StatusMessage.Severity;

import com.atosorigin.common.action.ModoPantalla;
import com.atosorigin.common.action.PaginatedListAction;
import com.atosorigin.common.formvalidator.FormValidator;
import com.atosorigin.common.utils.GenericUtils;
import com.atosorigin.deri.adminoper.boletas.action.BoletasAction.BoletasStates;
import com.atosorigin.deri.adminoper.gestionemir.business.EmirBo;
import com.atosorigin.deri.adminoper.gestionemir.screen.EmirPantalla;
import com.atosorigin.deri.common.dbLock.DbLockService;
import com.atosorigin.deri.contrapartida.buscadorContrapartida.action.BuscadorContrapartidaAction;
import com.atosorigin.deri.model.contrapartida.Contrapartida;
import com.atosorigin.deri.model.gestionemir.CabeceraEmir;
import com.atosorigin.deri.model.gestionemir.DetalleEmir;
import com.atosorigin.deri.model.gestionemir.ValoracionEmir;
import com.atosorigin.deri.model.gestionoperaciones.HistoricoOperacion;
import com.atosorigin.deri.model.gestionoperaciones.VistaOperacion;
import com.atosorigin.deri.model.liquidaciones.VistaLiquidacion;
import com.atosorigin.deri.util.MessageBoxAction;
import com.atosorigin.deri.util.MsgBoxAction;

@Name("emirValoracionAction")
@Scope(ScopeType.CONVERSATION)
@FormValidator
public class EmirValoracionAction extends PaginatedListAction {

	// oO[Variables y Constantes]Oo
	@In("#{emirBo}")
	protected EmirBo emirBo;
	
	@In(create=true)
	protected EmirPantalla emirPantalla;
	
	/** Inyección del servicio que gestiona los bloqueos de registros en base de datos */
	@In(create = true)
	protected DbLockService dbLockService;
	
	@Out(required = false, value = "emirValoracionMessageBoxAction")
	private MessageBoxAction messageBoxActionEmirValoracion;
	
	/** Inyeccion del componente necesario para mostrar mensajes de decisión al usuario */
	@In(create = true)
	private MsgBoxAction msgBoxAction;
	
	private Boolean primeraEjecucionInit=null;
	
	// oO[Métodos]Oo	
	@Create
	public void init(){
		if (emirPantalla.getModoPantalla()!=null){
			setModoPantalla(emirPantalla.getModoPantalla());
			}
		
		if(null==messageBoxActionEmirValoracion) messageBoxActionEmirValoracion = new MessageBoxAction(); 
	}

	@SuppressWarnings("unchecked")
	@Override
	public void setDataTableList(List<?> dataTableList) {
		this.emirPantalla
				.setValoracionList((List<ValoracionEmir>) dataTableList);
	}

	@Override
	public List<ValoracionEmir> getDataTableList() {
		return this.emirPantalla.getValoracionList();
	}

	@Override
	public void refrescarListaExcel() {
		setExportExcel(true);

		List<ValoracionEmir> listaValoraciones = emirBo.cargarValoracion(emirPantalla.getEmirSelec(),paginationData.getPaginationDataForExcel());
		
		if (emirPantalla.getValoracionList()!=null) {
			emirPantalla.getValoracionList().clear();
			emirPantalla.getValoracionList().addAll(listaValoraciones);
		}else{
			emirPantalla.setValoracionList(listaValoraciones);
		}
			
	}

	@Override
	protected void refreshListInternal() {
		setExportExcel(false);
		List<ValoracionEmir> listaValoraciones = emirBo.cargarValoracion(emirPantalla.getEmirSelec(),paginationData);
		
		if (emirPantalla.getValoracionList()!=null) {
			emirPantalla.getValoracionList().clear();
			emirPantalla.getValoracionList().addAll(listaValoraciones);
		}else{
			emirPantalla.setValoracionList(listaValoraciones);
		}
			
		
	}

	
	public void salir() {
	if (modoPantalla != ModoPantalla.INSPECCION) 	{
		desbloqueo(emirPantalla.getEmirSelec());	
		}
	emirPantalla.setEmirSelec(null);
	}
	
	private void desbloqueo(CabeceraEmir bloqueado) {
			dbLockService.desbloqueo(CabeceraEmir.class, bloqueado.getId());

	}

	public void voidFunction(){
		msgBoxAction.voidFunction();
	}
	
	/**
	 * Mostrar PopUp cuando una contrapartida está bloqueada (no bloqueante)
	 */
	public void initValoracion() {
		if (primeraEjecucionInit == null) {
			primeraEjecucionInit=true;
		} 
		else{
			primeraEjecucionInit = false;
		}
		
		if(primeraEjecucionInit){		
			if(null!=emirPantalla.getContrapartida() && null!=emirPantalla.getContrapartida()){
				String contrapartida = emirPantalla.getContrapartida();
				if (!GenericUtils.isNullOrBlank(contrapartida)){
					 Contrapartida contrapObtenida2 = emirBo.cargarContrapartida(contrapartida.toUpperCase());	
					if (null!=contrapObtenida2 && !GenericUtils.isNullOrBlank(contrapObtenida2.getIndBloqueo()) && "S".equalsIgnoreCase(contrapObtenida2.getIndBloqueo())){
						messageBoxActionEmirValoracion.init("emir.messages.contrapartida.bloqueada.texto", "emirValoracionAction.voidFunction()", null, "messageBoxPanelContrapa");
					}
				}
			}
		}
	}

}
