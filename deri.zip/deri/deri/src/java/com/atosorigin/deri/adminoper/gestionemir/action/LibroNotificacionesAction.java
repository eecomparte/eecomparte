package com.atosorigin.deri.adminoper.gestionemir.action;

import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;

import org.jboss.seam.ScopeType;
import org.jboss.seam.annotations.Create;
import org.jboss.seam.annotations.In;
import org.jboss.seam.annotations.Name;
import org.jboss.seam.annotations.Out;
import org.jboss.seam.annotations.Scope;
import org.jboss.seam.core.ResourceBundle;
import org.jboss.seam.international.StatusMessage.Severity;

import com.atosorigin.common.action.PaginatedListAction;
import com.atosorigin.common.formvalidator.FormValidator;
import com.atosorigin.common.utils.GenericUtils;
import com.atosorigin.deri.adminoper.gestionemir.business.EmirBo;
import com.atosorigin.deri.adminoper.gestionemir.screen.LibroNotificacionesPantalla;
import com.atosorigin.deri.model.contrapartida.Contrapartida;
import com.atosorigin.deri.model.gestionemir.ParametroLibro;
import com.atosorigin.deri.util.MessageBoxAction;
import com.atosorigin.deri.util.MsgBoxAction;

@Name("libroNotificacionesAction")
@Scope(ScopeType.CONVERSATION)
@FormValidator
public class LibroNotificacionesAction extends PaginatedListAction {


	
	// oO[Variables y Constantes]Oo
	@In("#{emirBo}")
	protected EmirBo emirBo;
	
	@In(create=true)
	@Out
	protected LibroNotificacionesPantalla libroNotificacionesPantalla;
	
	public  Integer tamanyMax;

	@In(create = true)
	MsgBoxAction msgBoxAction;
	
	@Out(required = false, value = "libroNotificacionesMessageBoxAction")
	private MessageBoxAction messageBoxLibroNotificacionesAction;
	
	// oO[Métodos]Oo	
	@Create
	public void creacio(){
		tamanyMax = emirBo.recuperarTamanyMaximo();
		if(null==messageBoxLibroNotificacionesAction){
			messageBoxLibroNotificacionesAction = new MessageBoxAction();
		}
	}
	
	public void init(){
		
//		if (emirPantalla.getEstado()==null && isPrimerAcceso()){
//			emirPantalla.setEstado(emirBo.recuperarEstado("TP"));
//		}
		refrescarLista();
		

	}


	@SuppressWarnings("unchecked")
	@Override
	public void setDataTableList(List<?> dataTableList) {
		this.libroNotificacionesPantalla
				.setParamLibroList((List<ParametroLibro>) dataTableList);
	}

	@Override
	public List<ParametroLibro> getDataTableList() {
		return this.libroNotificacionesPantalla.getParamLibroList();
	}

	@Override
	public void refrescarListaExcel() {
		setExportExcel(true);

	
	}

	@Override
	protected void refreshListInternal() {
		setExportExcel(false);

	}


	public Boolean anadirValidator(){
		if (!GenericUtils.isNullOrBlank(libroNotificacionesPantalla.getContrapartida())&&
			!GenericUtils.isNullOrBlank(libroNotificacionesPantalla.getCodigoLei())){
			
				statusMessages.add(Severity.ERROR, "#{messages['libnotif.anadir.uncodigo']}");
				return false;
		}
		if (GenericUtils.isNullOrBlank(libroNotificacionesPantalla.getContrapartida())&&
				GenericUtils.isNullOrBlank(libroNotificacionesPantalla.getCodigoLei())){
				
					statusMessages.add(Severity.ERROR, "#{messages['libnotif.anadir.almenosuno']}");
					return false;
			}
		
		if (!GenericUtils.isNullOrBlank(libroNotificacionesPantalla.getParamLibroList()) &&
			libroNotificacionesPantalla.getParamLibroList().size() >= tamanyMax){
			
				statusMessages.add(Severity.ERROR, "#{messages['libnotif.anadir.maxparam']}");
				return false;
		}
		if (!GenericUtils.isNullOrBlank(libroNotificacionesPantalla.getContrapartida())
				&& !validarContrapa(libroNotificacionesPantalla.getContrapartida())){
				
					statusMessages.add(Severity.ERROR, "#{messages['libnotif.anadir.errorContra']}");
					return false;
		}
		if (!GenericUtils.isNullOrBlank(libroNotificacionesPantalla.getCodigoLei())
				&& !validarCodigoLei(libroNotificacionesPantalla.getCodigoLei())){
				
					statusMessages.add(Severity.ERROR, "#{messages['libnotif.anadir.errorLei']}");
					return false;
		}
		if (!GenericUtils.isNullOrBlank(libroNotificacionesPantalla.getParamLibroList())){
			if (!GenericUtils.isNullOrBlank(libroNotificacionesPantalla.getContrapartida())){
			
				for (ParametroLibro param : libroNotificacionesPantalla.getParamLibroList()) {
					if (param.getContrapartida().equalsIgnoreCase(libroNotificacionesPantalla.getContrapartida())){
						statusMessages.add(Severity.ERROR, "#{messages['libnotif.anadir.contraexiste']}");
						return false;
					}
				}
			}else{
				for (ParametroLibro param : libroNotificacionesPantalla.getParamLibroList()) {
					if (param.getCodigoLei().equalsIgnoreCase(libroNotificacionesPantalla.getCodigoLei())){
						statusMessages.add(Severity.ERROR, "#{messages['libnotif.anadir.leiexiste']}");
						return false;
					}
				}
			}
		}
		
	return true;
	}

	public void generarFichero(){
		
			String sqlTxt = ""; String sqlTxt2 = "";
			

			if (libroNotificacionesPantalla.getParamLibroList()!=null && libroNotificacionesPantalla.getParamLibroList().size()>0){
				
				for (ParametroLibro param : libroNotificacionesPantalla.getParamLibroList()) {
					if (!GenericUtils.isNullOrBlank(param.getContrapartida())){
//						sqlTxt= sqlTxt.concat("'").concat(param.getContrapartida()).concat("';");
						sqlTxt= sqlTxt.concat(param.getContrapartida()).concat(";");
					}else{
//						sqlTxt2= sqlTxt2.concat("'").concat(param.getCodigoLei()).concat("';");
						sqlTxt2= sqlTxt2.concat(param.getCodigoLei()).concat(";");
					}
					
				}
				
				Long peticion = emirBo.generarPeticionExcel(sqlTxt,sqlTxt2);

				String mensaje = ResourceBundle.instance().getString("liquidaciones.registros.validadosBatch") + " " + peticion ;
				statusMessages.add(Severity.INFO, mensaje);

			}
		
	}
	public void borrar(){
		libroNotificacionesPantalla.getParamLibroList().remove(libroNotificacionesPantalla.getParamLibroBorra());
	}
	
	private boolean validarCodigoLei(String codigoLei) {
		return emirBo.validarCodigoLei(codigoLei);
	}

	private boolean validarContrapa(String contrapartida) {
		// TODO Auto-generated method stub
		return emirBo.validarContrapa(contrapartida);
	}

	public void anadir(){
		ParametroLibro param = new ParametroLibro(1, libroNotificacionesPantalla.getContrapartida(), libroNotificacionesPantalla.getCodigoLei());
		if (GenericUtils.isNullOrBlank(libroNotificacionesPantalla.getParamLibroList())){
			libroNotificacionesPantalla.setParamLibroList(new ArrayList<ParametroLibro>());
		}
		libroNotificacionesPantalla.getParamLibroList().add(param);
	}

	public Integer getTamanyMax() {
		return tamanyMax;
	}

	public void setTamanyMax(Integer tamanyMax) {
		this.tamanyMax = tamanyMax;
	}

	public void voidFunction(){
		msgBoxAction.voidFunction();
	}
	
	/**
	 * Mostrar PopUp cuando una contrapartida está bloqueada (no bloqueante)
	 */
	public void onVerificarContrapartidaBloqueada() {
		String contrapartida = libroNotificacionesPantalla.getContrapartida();
		if (!GenericUtils.isNullOrBlank(contrapartida)){
			 Contrapartida contrapObtenida2 = emirBo.cargarContrapartida(contrapartida.toUpperCase());	
			if (null!=contrapObtenida2 && !GenericUtils.isNullOrBlank(contrapObtenida2.getIndBloqueo()) && "S".equalsIgnoreCase(contrapObtenida2.getIndBloqueo())){
				messageBoxLibroNotificacionesAction.init("emir.messages.contrapartida.bloqueada.texto", "libroNotificacionesAction.voidFunction()", null,"messageBoxPanelContrapa");
			}
		}
	}
	
}
