package com.atosorigin.deri.adminoper.gestionemir.screen;

import java.util.Date;
import java.util.HashSet;
import java.util.List;

import org.jboss.seam.ScopeType;
import org.jboss.seam.annotations.Name;
import org.jboss.seam.annotations.Scope;
import org.jboss.seam.annotations.datamodel.DataModel;
import org.jboss.seam.annotations.datamodel.DataModelSelection;

import com.atosorigin.common.action.ModoPantalla;
import com.atosorigin.common.utils.GenericUtils;
import com.atosorigin.deri.model.adminoper.GenericRange;
import com.atosorigin.deri.model.gestionemir.CabeceraEmir;
import com.atosorigin.deri.model.gestionemir.DescripcionEstadoEmir;
import com.atosorigin.deri.model.gestionemir.DescripcionIndicadorSituacion;
import com.atosorigin.deri.model.gestionemir.DescripcionTipoTransaccion;
import com.atosorigin.deri.model.gestionemir.DetalleEmir;
import com.atosorigin.deri.model.gestionemir.HistoricoCabeceraEmir;
import com.atosorigin.deri.model.gestionemir.HistoricoDetalleEmir;
import com.atosorigin.deri.model.gestionemir.ValoracionEmir;
import com.atosorigin.deri.model.gestionoperaciones.ConfOperacion;
import com.atosorigin.deri.model.gestionoperaciones.VistaOperacion;

@Name("emirPantalla")
@Scope(ScopeType.CONVERSATION)
public class EmirPantalla {

	private GenericRange<Long> numOper = new GenericRange<Long>("numoper", Long.class);
	private GenericRange<Date> fechaEnvio = new GenericRange<Date>("fechaEnvio", Date.class);
	private String contrapartida;
	private String proyecto ="DERI";
	private DescripcionIndicadorSituacion tipoTransaccion;
	private DescripcionEstadoEmir estado;

	private ModoPantalla modoPantalla;
	private String onComplete; 
	protected String contenidoEdit;
	
	/** Lista de datos para el grid. */
	@DataModel(value = "listaEmir")
	protected List<CabeceraEmir> emirList;

	/** Parametro seleccionado en el grid */
	@DataModelSelection(value = "listaEmir")
	protected CabeceraEmir emirSelec;

	@DataModel(value = "listaCamposEmir")
	protected List<DetalleEmir> camposEmirList;

	/** Parametro seleccionado en el grid */
	@DataModelSelection(value = "listaCamposEmir")
	protected DetalleEmir campoEmirSelec;	

	

	@DataModel(value = "listaCamposEmirLog")
	protected List<HistoricoDetalleEmir> camposEmirLogList;

	/** Parametro seleccionado en el grid */
	@DataModelSelection(value = "listaCamposEmirLog")
	protected HistoricoDetalleEmir campoEmirLogSelec;	
	

	@DataModel(value = "listaLog")
	protected List<HistoricoCabeceraEmir> logList;

	/** Parametro seleccionado en el grid */
	@DataModelSelection(value = "listaLog")
	protected HistoricoCabeceraEmir logSelec;	


	@DataModel(value = "valoracionList")
	protected List<ValoracionEmir> valoracionList;

	/** Parametro seleccionado en el grid */
	@DataModelSelection(value = "valoracionList")
	protected ValoracionEmir valoracionSelec;	
	
	private HashSet<CabeceraEmir> listasSeleccionadas = new HashSet<CabeceraEmir>();

	protected CabeceraEmir emirEditat;
	protected HistoricoCabeceraEmir emirEditatLog;
	
	
	public GenericRange<Long> getNumOper() {
		return numOper;
	}

	public void setNumOper(GenericRange<Long> numOper) {
		this.numOper = numOper;
	}

	public GenericRange<Date> getFechaEnvio() {
		return fechaEnvio;
	}

	public void setFechaEnvio(GenericRange<Date> fechaEnvio) {
		this.fechaEnvio = fechaEnvio;
	}

	public String getContrapartida() {
		return contrapartida;
	}

	public void setContrapartida(String contrapartida) {
		this.contrapartida = contrapartida;
	}

	public String getProyecto() {
		return proyecto;
	}

	public void setProyecto(String proyecto) {
		this.proyecto = proyecto;
	}

	public DescripcionIndicadorSituacion getTipoTransaccion() {
		return tipoTransaccion;
	}

	public void setTipoTransaccion(DescripcionIndicadorSituacion tipoTransaccion) {
		this.tipoTransaccion = tipoTransaccion;
	}

	public DescripcionEstadoEmir getEstado() {
		return estado;
	}

	public void setEstado(DescripcionEstadoEmir estado) {
		this.estado = estado;
	}

	public List<CabeceraEmir> getEmirList() {
		return emirList;
	}

	public void setEmirList(List<CabeceraEmir> emirList) {
		this.emirList = emirList;
	}

	public CabeceraEmir getEmirSelec() {
		return emirSelec;
	}

	public void setEmirSelec(CabeceraEmir emirSelec) {
		this.emirSelec = emirSelec;
	}

	public HashSet<CabeceraEmir> getListasSeleccionadas() {
		return listasSeleccionadas;
	}

	public void setListasSeleccionadas(HashSet<CabeceraEmir> listasSeleccionadas) {
		this.listasSeleccionadas = listasSeleccionadas;
	}

	public List<DetalleEmir> getCamposEmirList() {
		return camposEmirList;
	}

	public void setCamposEmirList(List<DetalleEmir> camposEmirList) {
		this.camposEmirList = camposEmirList;
	}

	public DetalleEmir getCampoEmirSelec() {
		return campoEmirSelec;
	}

	public void setCampoEmirSelec(DetalleEmir campoEmirSelec) {
		this.campoEmirSelec = campoEmirSelec;
	}


	
	public List<HistoricoDetalleEmir> getCamposEmirLogList() {
		return camposEmirLogList;
	}

	public void setCamposEmirLogList(List<HistoricoDetalleEmir> camposEmirLogList) {
		this.camposEmirLogList = camposEmirLogList;
	}

	public HistoricoDetalleEmir getCampoEmirLogSelec() {
		return campoEmirLogSelec;
	}

	public void setCampoEmirLogSelec(HistoricoDetalleEmir campoEmirLogSelec) {
		this.campoEmirLogSelec = campoEmirLogSelec;
	}


	
	public String getOnComplete() {
		return onComplete;
	}

	public void setOnComplete(String onComplete) {
		this.onComplete = onComplete;
	}

	public String getContenidoEdit() {
		return contenidoEdit;
	}

	public void setContenidoEdit(String contenidoEdit) {
		this.contenidoEdit = contenidoEdit;
	}

	public List<HistoricoCabeceraEmir> getLogList() {
		return logList;
	}

	public void setLogList(List<HistoricoCabeceraEmir> logList) {
		this.logList = logList;
	}

	public HistoricoCabeceraEmir getLogSelec() {
		return logSelec;
	}

	public void setLogSelec(HistoricoCabeceraEmir logSelec) {
		this.logSelec = logSelec;
	}

	public ModoPantalla getModoPantalla() {
		return modoPantalla;
	}

	public void setModoPantalla(ModoPantalla modoPantalla) {
		this.modoPantalla = modoPantalla;
	}

	public CabeceraEmir getEmirEditat() {
		return emirEditat;
	}

	public void setEmirEditat(CabeceraEmir emirEditat) {
		this.emirEditat = emirEditat;
	}
	
	public HistoricoCabeceraEmir getEmirEditatLog() {
		return emirEditatLog;
	}

	public void setEmirEditatLog(HistoricoCabeceraEmir emirEditatLog) {
		this.emirEditatLog = emirEditatLog;
	}

	public String getDescripcionEstado() {
		if ("ER".equalsIgnoreCase(this.emirEditat.getEstado().getCodigoDatoEmir()) 
				&& !GenericUtils.isNullOrBlank(this.emirEditat.getDescripcionError())){
			return this.emirEditat.getEstado().getDescripcion().concat(" - ").concat(this.emirEditat.getDescripcionError());
		}else{
			return this.emirEditat.getEstado().getDescripcion();
		}
	}

	public String getDescripcionEstadoLog() {
		if ("ER".equalsIgnoreCase(this.emirEditatLog.getEstado().getCodigoDatoEmir()) 
				&& !GenericUtils.isNullOrBlank(this.emirEditatLog.getDescripcionError())){
			return this.emirEditatLog.getEstado().getDescripcion().concat(" - ").concat(this.emirEditatLog.getDescripcionError());
		}else{
			return this.emirEditatLog.getEstado().getDescripcion();
		}
	}


	public List<ValoracionEmir> getValoracionList() {
		return valoracionList;
	}

	public void setValoracionList(List<ValoracionEmir> valoracionList) {
		this.valoracionList = valoracionList;
	}

	public ValoracionEmir getValoracionSelec() {
		return valoracionSelec;
	}

	public void setValoracionSelec(ValoracionEmir valoracionSelec) {
		this.valoracionSelec = valoracionSelec;
	}
}
