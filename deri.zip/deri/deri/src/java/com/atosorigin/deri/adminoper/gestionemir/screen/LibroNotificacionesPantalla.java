package com.atosorigin.deri.adminoper.gestionemir.screen;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashSet;
import java.util.List;

import org.jboss.seam.ScopeType;
import org.jboss.seam.annotations.Name;
import org.jboss.seam.annotations.Scope;
import org.jboss.seam.annotations.datamodel.DataModel;
import org.jboss.seam.annotations.datamodel.DataModelSelection;

import com.atosorigin.common.action.ModoPantalla;
import com.atosorigin.common.utils.GenericUtils;
import com.atosorigin.deri.model.adminoper.GenericRange;
import com.atosorigin.deri.model.gestionemir.CabeceraEmir;
import com.atosorigin.deri.model.gestionemir.DescripcionEstadoEmir;
import com.atosorigin.deri.model.gestionemir.DescripcionIndicadorSituacion;
import com.atosorigin.deri.model.gestionemir.DescripcionTipoTransaccion;
import com.atosorigin.deri.model.gestionemir.DetalleEmir;
import com.atosorigin.deri.model.gestionemir.HistoricoCabeceraEmir;
import com.atosorigin.deri.model.gestionemir.HistoricoDetalleEmir;
import com.atosorigin.deri.model.gestionemir.ParametroLibro;
import com.atosorigin.deri.model.gestionemir.ValoracionEmir;
import com.atosorigin.deri.model.gestionoperaciones.ConfOperacion;
import com.atosorigin.deri.model.gestionoperaciones.HistoricoFechaFormula;
import com.atosorigin.deri.model.gestionoperaciones.VistaOperacion;

@Name("libroNotificacionesPantalla")
@Scope(ScopeType.CONVERSATION)
public class LibroNotificacionesPantalla {

	private String contrapartida;
	private String codigoLei;


	
	protected ParametroLibro paramLibroBorra;
	
	/** Lista de datos para el grid. */
	@DataModel(value = "paramLibroList")
	protected List<ParametroLibro> paramLibroList;

	/** Parametro seleccionado en el grid */
	@DataModelSelection(value = "paramLibroList")
	protected ParametroLibro paramLibroSelec;

	private HashSet<CabeceraEmir> listasSeleccionadas = new HashSet<CabeceraEmir>();

	protected CabeceraEmir emirEditat;
	protected HistoricoCabeceraEmir emirEditatLog;
	
	

	public String getContrapartida() {
		return contrapartida;
	}

	public void setContrapartida(String contrapartida) {
		this.contrapartida = contrapartida;
	}

	public CabeceraEmir getEmirEditat() {
		return emirEditat;
	}

	public void setEmirEditat(CabeceraEmir emirEditat) {
		this.emirEditat = emirEditat;
	}
	
	public HistoricoCabeceraEmir getEmirEditatLog() {
		return emirEditatLog;
	}

	public void setEmirEditatLog(HistoricoCabeceraEmir emirEditatLog) {
		this.emirEditatLog = emirEditatLog;
	}

	public String getDescripcionEstado() {
		if ("ER".equalsIgnoreCase(this.emirEditat.getEstado().getCodigoDatoEmir()) 
				&& !GenericUtils.isNullOrBlank(this.emirEditat.getDescripcionError())){
			return this.emirEditat.getEstado().getDescripcion().concat(" - ").concat(this.emirEditat.getDescripcionError());
		}else{
			return this.emirEditat.getEstado().getDescripcion();
		}
	}

	public String getDescripcionEstadoLog() {
		if ("ER".equalsIgnoreCase(this.emirEditatLog.getEstado().getCodigoDatoEmir()) 
				&& !GenericUtils.isNullOrBlank(this.emirEditatLog.getDescripcionError())){
			return this.emirEditatLog.getEstado().getDescripcion().concat(" - ").concat(this.emirEditatLog.getDescripcionError());
		}else{
			return this.emirEditatLog.getEstado().getDescripcion();
		}
	}




	public String getCodigoLei() {
		return codigoLei;
	}

	public void setCodigoLei(String codigoLei) {
		this.codigoLei = codigoLei;
	}

	public List<ParametroLibro> getParamLibroList() {
		return paramLibroList;
	}

	public void setParamLibroList(List<ParametroLibro> paramLibroList) {
		this.paramLibroList = paramLibroList;
	}

	public ParametroLibro getParamLibroSelec() {
		return paramLibroSelec;
	}

	public void setParamLibroSelec(ParametroLibro paramLibroSelec) {
		this.paramLibroSelec = paramLibroSelec;
	}

	public ParametroLibro getParamLibroBorra() {
		return paramLibroBorra;
	}

	public void setParamLibroBorra(ParametroLibro paramLibroBorra) {
		this.paramLibroBorra = paramLibroBorra;
	}
}
