package com.atosorigin.deri.adminoper.infoProfit.action;

import java.io.IOException;
import java.sql.Blob;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.faces.context.FacesContext;
import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.persistence.EntityManager;
import javax.sql.DataSource;

import org.jboss.seam.ScopeType;
import org.jboss.seam.annotations.In;
import org.jboss.seam.annotations.Name;
import org.jboss.seam.annotations.Scope;
import org.jboss.seam.annotations.web.RequestParameter;
import org.jboss.seam.core.Conversation;
import org.jboss.seam.core.Manager;
import org.jboss.seam.document.ByteArrayDocumentData;
import org.jboss.seam.document.DocumentData;
import org.jboss.seam.document.DocumentStore;
import org.jboss.seam.document.DocumentData.DocumentType;
import org.jboss.seam.international.StatusMessage.Severity;
import org.jboss.seam.navigation.Pages;
import org.jboss.seam.security.Identity;
import org.springframework.jmx.export.annotation.ManagedOperation;
import org.springframework.jmx.export.annotation.ManagedOperationParameter;

import com.atosorigin.common.action.GenericAction;
import com.atosorigin.common.utils.GenericUtils;
import com.atosorigin.deri.adminoper.boletas.action.BoletasAction.BoletasStates;
import com.atosorigin.deri.adminoper.boletas.business.BoletasBo;
import com.atosorigin.deri.adminoper.infoProfit.screen.InfoProfitPantalla;
import com.atosorigin.deri.adminoper.infotext.screen.InfoTextPantalla;
import com.atosorigin.deri.common.dbLock.DbLockService;
import com.atosorigin.deri.model.adminoper.InformacionTexto;
import com.atosorigin.deri.model.gestionoperaciones.HistoricoOperacion;
import com.atosorigin.deri.model.gestionoperaciones.HistoricoOperacionId;
import com.atosorigin.deri.util.ConfiguracionDeri;
import com.atosorigin.deri.util.EntityUtil;

@Name("infoProfitAction")
@Scope(ScopeType.CONVERSATION)
public class InfoProfitAction extends GenericAction {
	

	@In(create = true, required = false)
	protected HistoricoOperacion historicoOperacion;

    
	@In(create=true,required = false)
	protected InfoProfitPantalla infoProfitPantalla;

	@In( required = false)
	private InformacionTexto informacionTexto;
	

	@In(required=false)
	private String forcedReturnView;
	
	@In
	private EntityManager entityManager;

	@In("#{boletasBo}")
	protected BoletasBo boletasBo;

	@RequestParameter("bdu") 
	private String bdu;
	
	public void aceptar(){
		
	}
	
	public void init(){
		if (!this.isPrimerAcceso()) return;
		this.setPrimerAcceso(false);
		infoProfitPantalla.setBdu(bdu);
		Connection result = null;
		ResultSet registres=null;
		PreparedStatement ps = null;
		PreparedStatement ps2 = null;
		byte[] blobUDF =null;
		String nomFitxer;
		String extFitxer;
		boolean registroEncontrado = false;
		
		try {
			
			Context initialContext = new InitialContext();
			  if ( initialContext != null){
				  DataSource datasource = (DataSource)initialContext.lookup("java:/jboss/profitDatasource");
//				  DataSource datasource = (DataSource)initialContext.lookup("java:/jboss/profitMexDatasource");
			  if (datasource != null) {
				  result = datasource.getConnection();
			  }
			  if (result!=null){
				 StringBuilder sb = new StringBuilder("select * from profit.qp_ktb_exoticidades where GLOBAL_ID = '");
				 sb.append(infoProfitPantalla.getBdu());sb.append("'");
//				 String bdutxt = "010000000002374052";
//				 bdutxt = "010000000002172450";
//				 sb.append(bdutxt);
				 ps = result.prepareStatement(sb.toString());
				 registres = ps.executeQuery();
				 
				 if (registres!=null){
					 while (registres.next()) {
						 registroEncontrado = true;
						 infoProfitPantalla.setInfoUDF(registres.getString("INFOTEXT_UDF"));
						 nomFitxer = registres.getString("NOMBRE_DOC");
						 extFitxer = registres.getString("EXTENSION_DOC");
						 if (!GenericUtils.isNullOrBlank(extFitxer)){
							 blobUDF = registres.getBytes("DOCUMENT");
							 infoProfitPantalla.setExtFitxer(extFitxer);
							 infoProfitPantalla.setNomFitxer(nomFitxer);
							 infoProfitPantalla.setBlobUDF(blobUDF);
							 infoProfitPantalla.setNoAnexo(false);
						 }
						 break;
					 }
				 }else{
					  return;
					  }
			
			  }else{
				  return;
			  }
			  }
			  
			  if (!registroEncontrado) return;
			  
			  	//select * from profit.qp_ktb_lit_prod nombre descripcion
				String formateaUDF = "";
			  	String[] lineas = infoProfitPantalla.getInfoUDF().split(";");
				for (int i = 0; i < lineas.length; i++) {
					String string = lineas[i];
					String lineaFinal="";
					
					try {
						String nombre = string.substring(0,string.indexOf("="));
						String valor = string.substring(string.indexOf("="));
						String descripcion="";
						
						
						 StringBuilder sb2 = new StringBuilder("select * from profit.qp_ktb_lit_prod where NOMBRE = '");
						 sb2.append(nombre+"'");
						 ps2 = result.prepareStatement(sb2.toString());
						 registres = ps2.executeQuery();
						
						 if (registres!=null){
							 while (registres.next()) {
								 descripcion = registres.getString("DESCRIPCION");
								 break;
							 }
						 }
						
						lineaFinal = descripcion.concat(valor);
					
					} catch (Exception e) {
						lineaFinal = string;
					}
					
					formateaUDF = formateaUDF.concat(lineaFinal).concat("\n");
				}
				infoProfitPantalla.setInfoUDF(formateaUDF);	
				//redirectExport(blobUDF);
				
		} catch (NamingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally{
			try {
				if (ps != null) { ps.close(); }
				if (!result.isClosed()){
						result.close();
				}
			} catch (Exception e) {
			}
		}
		
	}

	public String salirDirecto(){

	return null;
		
	}
	
private String doCommonRedirect() {
	
	
	if(forcedReturnView!=null){
		return doSalirRedirect();
	}
	
	
	Conversation conversacion=Conversation.instance();
	Conversation.instance().pop();
//	Conversation conversacion = Conversation.instance();
	//Volvemos al anterior
	conversacion.redirectToParent();
	return "";
}	

private String doSalirRedirect() {


		Conversation conversacion=Conversation.instance();
		Conversation.instance().pop();
		conversacion.redirectToParent();
		return "";

}



public HistoricoOperacion getHistoricoOperacion() {
	return historicoOperacion;
}



public void setHistoricoOperacion(HistoricoOperacion historicoOperacion) {
	this.historicoOperacion = historicoOperacion;
}

public String getBdu() {
	return bdu;
}

public void setBdu(String bdu) {
	this.bdu = bdu;
}


public void redirectExport(){

	if (GenericUtils.isNullOrBlank(infoProfitPantalla.getBlobUDF()) || GenericUtils.isNullOrBlank(infoProfitPantalla.getNomFitxer()) ||
			GenericUtils.isNullOrBlank(infoProfitPantalla.getExtFitxer())){
		return;
	}
	
	byte[] data =infoProfitPantalla.getBlobUDF();
	String viewId = Pages.getViewId(FacesContext.getCurrentInstance());

	String baseName =infoProfitPantalla.getNomFitxer();// Pages.getCurrentBaseName();
	DocumentType documType = new DocumentType(infoProfitPantalla.getExtFitxer(), "application/" + infoProfitPantalla.getExtFitxer());
	DocumentData documentData = new ByteArrayDocumentData(baseName,documType, data);
	documentData.setDisposition("attachment");
	documentData.setFilename(infoProfitPantalla.getNomFitxer() + "." + infoProfitPantalla.getExtFitxer());

	String id = DocumentStore.instance().newId();

	String url = DocumentStore.instance().preferredUrlForContent(baseName,
			documType.getExtension(), id);

	url = Manager.instance().encodeConversationId(url, viewId);

	DocumentStore.instance().saveData(id, documentData);

	try {
		FacesContext.getCurrentInstance().getExternalContext().redirect(url);
		FacesContext.getCurrentInstance().responseComplete();
	} catch (IOException e) {
		e.printStackTrace();
	}
}

}
