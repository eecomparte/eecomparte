package com.atosorigin.deri.adminoper.infoProfit.screen;

import org.jboss.seam.ScopeType;
import org.jboss.seam.annotations.Name;
import org.jboss.seam.annotations.Scope;
import org.jboss.seam.annotations.web.RequestParameter;

import com.atosorigin.deri.model.adminoper.InformacionTexto;

@Name("infoProfitPantalla")
@Scope(ScopeType.CONVERSATION)
public class InfoProfitPantalla {
	
	protected InformacionTexto infoText;
	@RequestParameter("bdu")  //same value as the 'name' in f:param
	private String bdu;
	
	private String infoUDF;
	private String nomFitxer;
	private String extFitxer;
	private byte[] blobUDF;
	private Boolean noAnexo = true;

	public InformacionTexto getInfoText() {
		return infoText;
	}

	public void setInfoText(InformacionTexto infoText) {
		this.infoText = infoText;
	}

	public String getBdu() {
		return bdu;
	}

	public void setBdu(String bdu) {
		this.bdu = bdu;
	}

	public String getInfoUDF() {
		return infoUDF;
	}

	public void setInfoUDF(String infoUDF) {
		this.infoUDF = infoUDF;
	}

	public String getNomFitxer() {
		return nomFitxer;
	}

	public void setNomFitxer(String nomFitxer) {
		this.nomFitxer = nomFitxer;
	}

	public String getExtFitxer() {
		return extFitxer;
	}

	public void setExtFitxer(String extFitxer) {
		this.extFitxer = extFitxer;
	}

	public byte[] getBlobUDF() {
		return blobUDF;
	}

	public void setBlobUDF(byte[] blobUDF) {
		this.blobUDF = blobUDF;
	}

	public Boolean getNoAnexo() {
		return noAnexo;
	}

	public void setNoAnexo(Boolean noAnexo) {
		this.noAnexo = noAnexo;
	} 

}
