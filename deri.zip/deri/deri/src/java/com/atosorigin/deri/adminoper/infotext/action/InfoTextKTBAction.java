package com.atosorigin.deri.adminoper.infotext.action;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.persistence.EntityManager;
import javax.sql.DataSource;

import org.jboss.seam.ScopeType;
import org.jboss.seam.annotations.In;
import org.jboss.seam.annotations.Name;
import org.jboss.seam.annotations.Scope;
import org.jboss.seam.core.Conversation;
import org.jboss.seam.international.StatusMessage.Severity;
import org.jboss.seam.security.Identity;

import com.atosorigin.common.action.GenericAction;
import com.atosorigin.common.utils.GenericUtils;
import com.atosorigin.deri.adminoper.boletas.action.BoletasAction.BoletasStates;
import com.atosorigin.deri.adminoper.boletas.business.BoletasBo;
import com.atosorigin.deri.adminoper.infotext.screen.InfoTextKTBPantalla;
import com.atosorigin.deri.common.dbLock.DbLockService;
import com.atosorigin.deri.model.gestionoperaciones.HistoricoOperacion;
import com.atosorigin.deri.model.gestionoperaciones.HistoricoOperacionId;
import com.atosorigin.deri.util.EntityUtil;

@Name("infoTextKTBAction")
@Scope(ScopeType.CONVERSATION)
public class InfoTextKTBAction extends GenericAction {
	

	@In(create = true)
	protected HistoricoOperacion historicoOperacion;

	@In(required=false)
	HistoricoOperacionId historicoOperacionBloqueadoId;
	
	@In(create = true)
	protected InfoTextKTBPantalla infoTextKTBPantalla;

	@In(value = "dbLockService", create = true)
	private DbLockService dbLockService;

	@In(required=false)
	private String forcedReturnView;
	
	@In
	private EntityManager entityManager;

	@In
	private BoletasStates boletaState;
	
	@In("#{boletasBo}")
	protected BoletasBo boletasBo;

	public void init(){
		Connection result = null;
		ResultSet registres=null;
		PreparedStatement ps = null;
		PreparedStatement ps2 = null;
		byte[] blobUDF =null;
		boolean registroEncontrado = false;
		
		if (GenericUtils.isNullOrBlank(historicoOperacion.getClaveExternaBDU())) {
			return;
		}
		
		try {
			
			Context initialContext = new InitialContext();
			  if ( initialContext != null){
				  DataSource datasource = (DataSource)initialContext.lookup("java:/jboss/profitDatasource");
//				  DataSource datasource = (DataSource)initialContext.lookup("java:/jboss/profitMexDatasource");
			  if (datasource != null) {
				  result = datasource.getConnection();
			  }
			  if (result!=null){
				 StringBuilder sb = new StringBuilder("select * from profit.qp_ktb_exoticidades where GLOBAL_ID = '");
				 sb.append(historicoOperacion.getClaveExternaBDU());sb.append("'");
//				 String bdutxt = "010000000002374052";
//				 bdutxt = "010000000002172450";
//				 020015000000001556 020015000000001492
//				 sb.append(bdutxt);
				 ps = result.prepareStatement(sb.toString());
				 registres = ps.executeQuery();
				 
				 if (registres!=null){
					 while (registres.next()) {
						 registroEncontrado = true;
						 infoTextKTBPantalla.setInfoText(registres.getString("INFOTEXT_KONDOR"));
						 break;
					 }
				 }else{
					  return;
					  }
			
			  }else{
				  return;
			  }
			  }
//			  
//			  if (!registroEncontrado) return;
//			  
//			  	//select * from profit.qp_ktb_lit_prod nombre descripcion
//				String formateaUDF = "";
//			  	String[] lineas = infoProfitPantalla.getInfoUDF().split(";");
//				for (int i = 0; i < lineas.length; i++) {
//					String string = lineas[i];
//					String lineaFinal="";
//					
//					try {
//						String nombre = string.substring(0,string.indexOf("="));
//						String valor = string.substring(string.indexOf("="));
//						String descripcion="";
//						
//						
//						 StringBuilder sb2 = new StringBuilder("select * from profit.qp_ktb_lit_prod where NOMBRE = '");
//						 sb2.append(nombre+"'");
//						 ps2 = result.prepareStatement(sb2.toString());
//						 registres = ps2.executeQuery();
//						
//						 if (registres!=null){
//							 while (registres.next()) {
//								 descripcion = registres.getString("DESCRIPCION");
//								 break;
//							 }
//						 }
//						
//						lineaFinal = descripcion.concat(valor);
//					
//					} catch (Exception e) {
//						lineaFinal = string;
//					}
//					
//					formateaUDF = formateaUDF.concat(lineaFinal).concat("\n");
//				}
//				infoProfitPantalla.setInfoUDF(formateaUDF);	
				//redirectExport(blobUDF);
				
		} catch (NamingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally{
			try {
				if (ps != null) { ps.close(); }
				if (!result.isClosed()){
						result.close();
				}
			} catch (Exception e) {
			}
		}
		
	}

	
	public void aceptar(){
		
	}
	


	public String salirDirecto(){

		if ( !BoletasStates.CONSULTA_BOLETA.equals( this.boletaState) ) {
			try {
				String result = boletasBo.salirOperacion("R", historicoOperacion, Identity.instance().getCredentials().getUsername());
				if (result != null) {
					String codigoValidacionErroneo = result;
					statusMessages.add(Severity.ERROR, "#{messages['boletas.edicion.error.salir.operacion']");
				}
				//FLM: boletas es un caso especial, si estamos en alta tenemos que saltar 2 parents quizas?
				return doCommonRedirect();
				//return doSalirRedirect();
			} finally {
				if (boletaState == BoletasStates.MODI_BOLETA) {
					dbLockService.desbloqueo(HistoricoOperacion.class, historicoOperacionBloqueadoId);
				}
			}

		} else { 
			return doCommonRedirect();
		}
		    

		
	}
	
private String doCommonRedirect() {
	
	
	if(forcedReturnView!=null){
		return doSalirRedirect();
	}
	if(boletaState==BoletasStates.ALTA_BOLETA){
		Conversation.instance().pop();
		return "salir";
	}
	
	Conversation conversacion=Conversation.instance();
	Conversation.instance().pop();
//	Conversation conversacion = Conversation.instance();
	//Volvemos al anterior
	conversacion.redirectToParent();
	return "";
}	

private String doSalirRedirect() {

	if ( BoletasStates.ALTA_BOLETA.equals( this.boletaState) ) {
		
    	Conversation nested =Conversation.instance();
    	Conversation.instance().pop();
    	Conversation.instance().pop();
    	
    	boolean dosSaltos= ( "/pages/adminoper/boletas/alta/altaOper.xhtml".equalsIgnoreCase( Conversation.instance().getViewId() ) );
    	
    
    	if(forcedReturnView!=null){
    		if(dosSaltos){
    			Conversation.instance().redirectToParent();
    			return "";
    		}else{
    			Conversation.instance().redirect();
    			return "";

    		}
		}
    	
    	nested.end(true);
    	if(EntityUtil.checkEntityExists(entityManager, historicoOperacion.getProductoCompuesto())){
    		return "/pages/gestionoperaciones/productocompuesto/mantProdCompuesto.xhtml";
    	}
		return "salir";
	} else {
		Conversation conversacion=Conversation.instance();
		Conversation.instance().pop();
		conversacion.redirectToParent();
		return "";
	}

}




}
