package com.atosorigin.deri.adminoper.infotext.screen;

import org.jboss.seam.ScopeType;
import org.jboss.seam.annotations.Name;
import org.jboss.seam.annotations.Scope;

import com.atosorigin.deri.model.adminoper.InformacionTexto;

@Name("infoTextKTBPantalla")
@Scope(ScopeType.CONVERSATION)
public class InfoTextKTBPantalla {
	
	protected String infoText;

	public String getInfoText() {
		return infoText;
	}

	public void setInfoText(String infoText) {
		this.infoText = infoText;
	} 

}
