package com.atosorigin.deri.adminoper.liquidaciones.action;

import org.jboss.seam.ScopeType;
import org.jboss.seam.annotations.In;
import org.jboss.seam.annotations.Name;
import org.jboss.seam.annotations.Scope;

import com.atosorigin.common.action.GenericAction;
import com.atosorigin.common.utils.GenericUtils;
import com.atosorigin.deri.adminoper.liquidaciones.screen.ConfirmarPantalla;
import com.atosorigin.deri.liquidaciones.business.LiquidacionesBo;
import com.atosorigin.deri.model.liquidaciones.ConfirmacionBancaria;
import com.atosorigin.deri.model.liquidaciones.Liquidacion;
import com.atosorigin.deri.model.liquidaciones.ReferenciaConfirmacion;
import com.atosorigin.deri.model.liquidaciones.VistaLiquidacion;

@Name("confirmarDetalleAction")
@Scope(ScopeType.CONVERSATION)
public class ConfirmarDetalleAction extends GenericAction {

	@In("#{liquidacionesBo}")
	protected LiquidacionesBo liquidacionesBo;
	
	@In(create = true)
	protected ConfirmarPantalla confirmarPantalla;
	
//	@In(value="#{vistaLiqui}", required=false)
	@In(value="vistaLiqui", required=false)
	protected VistaLiquidacion vistaLiquidacion;
	
	/**
	 * Carga los valores para la cabecera y llama a la función que carga el listado de la
	 * parte inferior de la pantalla
	 */
	public void cargarCabecera() {
		
		if(!GenericUtils.isNullOrBlank(vistaLiquidacion)) {
			
			confirmarPantalla.setProducto(vistaLiquidacion.getDescrProducto());
			confirmarPantalla.setFechaLiquidacion(vistaLiquidacion.getFechaliq());
			confirmarPantalla.setNumopes(Long.valueOf(vistaLiquidacion.getnCorrelaEstructura()));
			confirmarPantalla.setConcepto(vistaLiquidacion.getConcepto());
			confirmarPantalla.setCanal(vistaLiquidacion.getCanaliqi());
			confirmarPantalla.setContrapartida(vistaLiquidacion.getContrapa());
			confirmarPantalla.setDivisa(vistaLiquidacion.getDivisali());
			confirmarPantalla.setImporte(vistaLiquidacion.getImportel());
			this.refrescarLista();
		}
	
		//Cargamos el grid
		
		
	}
	
	public void getHeader(VistaLiquidacion vistaLiquidacion) {
		this.vistaLiquidacion = vistaLiquidacion;
		this.cargarCabecera();
	}
	
	/**
	 * Busca el detalle de los registros neteados. Realiza una select de la tabla de liquidaciones
	 * en los que corresponda el código de liquidación
	 */
	protected void refrescarLista() {
		if(!GenericUtils.isNullOrBlank(vistaLiquidacion)) {
			ConfirmacionBancaria confi = liquidacionesBo.cargarConfirmacion(vistaLiquidacion.getId());
			if(!GenericUtils.isNullOrBlank(confi)) {
				confirmarPantalla.setObservaciones(confi.getObservacion());
				confirmarPantalla.setReferenciaPago(confi.getReferenciaPago());
				ReferenciaConfirmacion refConfi = confi.getRefConf();
				if(!GenericUtils.isNullOrBlank(refConfi)) {
					confirmarPantalla.setReferenciaModelo(refConfi);
				}
			}
		}
		
	}



	public String getRowClasses(){
		StringBuilder builder = new StringBuilder();
		int i=0;
		for (Liquidacion vl : confirmarPantalla.getNeteadosList()) {
			if(i>0){
				builder.append(",");
			}
			if(vl.getLiqOriginal()!=null && vl.getLiqOriginal()!=vl){
				builder.append("resaltarRow");
			}
			else{
				if(i%2==0){
					builder.append("oddRow");
				}
				else{
					builder.append("evenRow");
				}
			}
			i++;
		}
		return builder.toString();
	}
	


}
