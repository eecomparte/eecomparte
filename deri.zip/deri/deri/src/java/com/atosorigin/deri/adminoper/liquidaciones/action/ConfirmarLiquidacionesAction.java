package com.atosorigin.deri.adminoper.liquidaciones.action;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map.Entry;

import javax.persistence.RollbackException;

import org.jboss.seam.ScopeType;
import org.jboss.seam.annotations.Factory;
import org.jboss.seam.annotations.In;
import org.jboss.seam.annotations.Name;
import org.jboss.seam.annotations.Out;
import org.jboss.seam.annotations.Scope;
import org.jboss.seam.core.Conversation;
import org.jboss.seam.core.ResourceBundle;
import org.jboss.seam.international.StatusMessage.Severity;
import org.jboss.seam.security.Credentials;
import org.jboss.seam.security.Identity;

import com.atosorigin.common.action.ModoPantalla;
import com.atosorigin.common.action.PaginatedListAction;
import com.atosorigin.common.action.PaginationData;
import com.atosorigin.common.auditdata.AuditData;
import com.atosorigin.common.constantes.Constantes;
import com.atosorigin.common.formvalidator.FormValidator;
import com.atosorigin.common.utils.GenericUtils;
import com.atosorigin.deri.adminoper.boletas.action.BoletasAction.BoletasStates;
import com.atosorigin.deri.adminoper.liquidaciones.screen.LiquidacionesPantalla;
import com.atosorigin.deri.common.dbLock.DbLockService;
import com.atosorigin.deri.liquidaciones.business.LiquidacionesBo;
import com.atosorigin.deri.liquidaciones.business.MensajesValidacion;
import com.atosorigin.deri.liquidaciones.business.MensajesValidacionId;
import com.atosorigin.deri.model.contrapartida.Contrapartida;
import com.atosorigin.deri.model.gestionoperaciones.HistoricoOperacion;
import com.atosorigin.deri.model.liquidaciones.Cesiones;
import com.atosorigin.deri.model.liquidaciones.CesionesId;
import com.atosorigin.deri.model.liquidaciones.ConfirmacionBancaria;
import com.atosorigin.deri.model.liquidaciones.Liquidacion;
import com.atosorigin.deri.model.liquidaciones.ReferenciaConfirmacion;
import com.atosorigin.deri.model.liquidaciones.Swift;
import com.atosorigin.deri.model.liquidaciones.SwiftId;
import com.atosorigin.deri.model.liquidaciones.VistaLiquidacion;
import com.atosorigin.deri.model.murex.ModeloProducto;
import com.atosorigin.deri.util.MessageBoxAction;
import com.atosorigin.deri.util.MsgBoxAction;

@Name("confirmarLiquidacionesAction")
@Scope(ScopeType.CONVERSATION)
@FormValidator
public class ConfirmarLiquidacionesAction extends PaginatedListAction implements java.io.Serializable{
	
	public static final String SITUALIQ_PDR = "PDR";
	public static final String SITUALIQ_PDE = "PDE";
	public static final String SITUALIQ_VEN = "VEN";
	
	@In("#{liquidacionesBo}")
	protected LiquidacionesBo liquidacionesBo;

	@In(create=true)
	protected LiquidacionesPantalla liquidacionesPantalla;
	
	@In Credentials credentials;
	
	protected Boolean validarHabilitado = false;
	protected Boolean desValidarHabilitado = false;
	protected boolean camposCalificarDisabled;
	protected boolean calificarRendered = false;
	protected boolean listaConfirmacionesRendered = false;
	protected boolean panelSwiftRendered;
	
	HashMap<MensajesValidacionId, MensajesValidacion> liquidacionesMsg;
	
	/** Inyección del servicio que gestiona los bloqueos de registros en base de datos */
	@In(create = true)
	protected DbLockService dbLockService;	
	
//	/** Inyeccion del componente necesario para mostrar mensajes de decisión al usuario */
//	@In(create = true)
//	private MsgBoxAction msgBoxAction;
//
//
	@In(create = true)
	private MsgBoxAction msgBoxAction;
	
	@Out(required = false, value = "confirmLiquidacionMessageBoxAction")
	private MessageBoxAction messageBoxConfLiquidacionAction;
	
	private List<VistaLiquidacion> liquidacionesBloqueadas;
	
	//Selección de 500 registros para el botón seleccionar todos.
	private List<VistaLiquidacion> listaTemp;
	
	//Para la union con datos generales alta BOLETAS
	@Out(required=false)
	private BoletasStates boletaState;
	
	//Para la union con datos generales alta BOLETAS
	@Out(required=false)
	HistoricoOperacion historicoOperacion;
	

	/*
	 * variables de contexto Integra con MANTANEX
	 */
	@Out(required=false)
	private String modoTratamiento;
		
	@Out(required=false)
	private String tipoAnexo;	

	@Out(required=false)
	private Date fechaLiquidacion2;	
	
	@Out(required = false, value="listaNombresModelo")
	protected List<ReferenciaConfirmacion> listReferencias;
	
	// oO[Métodos]Oo
	@Override
	public List<VistaLiquidacion> getDataTableList() { 
		return liquidacionesPantalla.getListaVistaLiqui();
	}
	
	
	
	
	public String guardarLiquidacionPago(){
		
		Liquidacion liquidacion = liquidacionesPantalla.getVistaLiqui();
//		liquidacion = llenarCamposPago();//Según alfons el proyecto nunca puede ser nulo...
		liquidacion.setSitualiq(SITUALIQ_PDE);
		liquidacionesBo.actualizarLiquidacion(liquidacion);
		liquidacionesBo.actualizarCesion(liquidacionesPantalla.getVistaLiqui());
		if(Constantes.CANAL_SWIFT.equals(liquidacion.getCanaliqi()) ){
			liquidacionesBo.actualizarSwift(liquidacion.getSwift().getFechaenv(), liquidacion);
		}
		return Constantes.CONSTANTE_SUCCESS;
		
	}
	
	public Liquidacion llenarCamposPago(){
//		Liquidacion liquidacion = new Liquidacion();
		
		//Según alfons el proyecto nunca puede ser nulo...
		/**
		 *    Si LiqPag_Swift.proyecto is null and LiqPag.formpago = 'SWF',
		      LiqPag_Swift.proyecto := 'DERI'
		      LiqPag_Swift.codliqui := VistaLiquidacion.codliqui
		      LiqPag_Swift.fechatra := VistaLiquidacion.fechatra
		      LiqPag_Swift.fechaliq := LiqPag.fproxliq
		      LiqPag_Swift.fechaope := LiqPag.fechaoper
		      LiqPag_Swift.ncorrela := LiqPag.ncorrela
		      LiqPag_Swift.tipopera := VistaLiquidacion.tipopera
		      LiqPag_Swift.codivisa := VistaLiquidacion.divisali
		      LiqPag_Swift.usultact := usuario
		      LiqPag_Swift.feultact := SYSDATE
		
		   Fin Si

		 */
		
		
		return null;
	}
	
	/** habilita o deshabilita el panel de swift */
	public void marcaSwift(){
		
		if(Constantes.CANAL_SWIFT.equalsIgnoreCase(liquidacionesPantalla.getVistaLiqui().getCanaliqi()) ||
		   Constantes.CANAL_TARGET.equalsIgnoreCase(liquidacionesPantalla.getVistaLiqui().getCanaliqi()) ){
			this.setPanelSwiftRendered(true);
		} else {
			this.setPanelSwiftRendered(false);
		}
	
	}

	
	@Override
	protected void refreshListInternal() {

		setExportExcel(false);		
		// Limpiamos checkbox
//		if(!GenericUtils.isNullOrBlank(this.liquidacionesPantalla.getSelectedLiquiIds())){
//			this.liquidacionesPantalla.getSelectedLiquiIds().clear();
//		}
//		
//		if (!GenericUtils.isNullOrBlank(this.liquidacionesPantalla.getSelectedLiquiDataList())){
//			this.liquidacionesPantalla.getSelectedLiquiDataList().clear();
//			this.liquidacionesPantalla.setSelecTodos(false);			
//		}		

		// SMM Si se modifica alguna seleccion verificar que no haya que modificar tambien listaSeleccionarTodos
		
					rellenarLista(paginationData);// Select_datos_liquidaciones (criterioSeleccion)
				}
			



	/**
	 * Carga la lista de Liquidaciones cuando venimos de la pantalla de Agenda o de Lista Operaciones
	 */
	public void initListaResultados(){
		setExportExcel(false);
		
		//Precargar la lista con Parametros liquidación si es la primera vez q entra
		//Si parametrosOutAgenda es nulo es que entramos desde el menú
		if (isPrimerAcceso()){
			buildListasProductos();
			liquidacionesPantalla.setEstadoLiqSelect(liquidacionesBo.cargarEstadoLiquidacion(Constantes.TIPO_ESTADO_PV));
			}
		}	

	
	
	
	public void rellenarLista(PaginationData paginationData){		
		
		List<VistaLiquidacion> listaVistaLiqui = liquidacionesBo.obtenerDatosLiquidacionesConf(liquidacionesPantalla.getModeloProductoSelect(), liquidacionesPantalla.getProdCatalSelect(),
				liquidacionesPantalla.getNumOperDesde(), liquidacionesPantalla.getNumOperHasta(), liquidacionesPantalla.getDivPagoSelect(),
				liquidacionesPantalla.getProdOperSelect(), liquidacionesPantalla.getFechaLiquidDesde(), liquidacionesPantalla.getFechaLiquidHasta(), 
				liquidacionesPantalla.getDivCobroSelect(), liquidacionesPantalla.getContrapartidaSelect(), 
				liquidacionesPantalla.getNumEstructDesde(), liquidacionesPantalla.getNumEstructHasta(), liquidacionesPantalla.getEstadoLiqSelect(),				
				liquidacionesPantalla.getSitCorrespSelect(), null, null,liquidacionesPantalla.getEstadoConf(), exportExcel , paginationData);			

		if (liquidacionesPantalla.getListaVistaLiqui()!=null) {
			liquidacionesPantalla.getListaVistaLiqui().clear();
			liquidacionesPantalla.getListaVistaLiqui().addAll(listaVistaLiqui);
		}else{
			liquidacionesPantalla.setListaVistaLiqui(listaVistaLiqui);
		}
			
			
	}
	
	@Override
	public void refrescarListaExcel() {		
		setExportExcel(true);
				
					rellenarLista(paginationData.getPaginationDataForExcel());
		}
		
	

	@SuppressWarnings("unchecked")
	@Override
	public void setDataTableList(List<?> dataTableList) {
		liquidacionesPantalla.setListaVistaLiqui((List<VistaLiquidacion>) dataTableList);
	}
	
	
	public boolean buscarValidator(){
		if (!GenericUtils.isNullOrBlank(liquidacionesPantalla.getFechaLiquidDesde()) && 
				!GenericUtils.isNullOrBlank(liquidacionesPantalla.getFechaLiquidHasta()) &&
				liquidacionesPantalla.getFechaLiquidDesde().after(liquidacionesPantalla.getFechaLiquidHasta())){
			statusMessages.add(Severity.ERROR, "#{messages['liquidaciones.error.fechaIniSuperior']}");
			return false;
		}
		if (!GenericUtils.isNullOrBlank(liquidacionesPantalla.getNumOperDesde()) && 
				!GenericUtils.isNullOrBlank(liquidacionesPantalla.getNumOperHasta()) &&
				liquidacionesPantalla.getNumOperDesde()>liquidacionesPantalla.getNumOperHasta()){
			statusMessages.add(Severity.ERROR, "#{messages['liquidaciones.error.ncorrelaIniSuperior']}");
			return false;
		}
		if (!GenericUtils.isNullOrBlank(liquidacionesPantalla.getNumEstructDesde()) && 
				!GenericUtils.isNullOrBlank(liquidacionesPantalla.getNumEstructHasta()) &&
				liquidacionesPantalla.getNumEstructDesde()>liquidacionesPantalla.getNumEstructHasta()){
			statusMessages.add(Severity.ERROR, "#{messages['liquidaciones.error.estruturaIniSuperior']}");
			return false;
		}
		if (!GenericUtils.isNullOrBlank(liquidacionesPantalla.getContrapartidaSelect())  
				 && !esContrapartidaBancaria(liquidacionesPantalla.getContrapartidaSelect())	){
			statusMessages.add(Severity.ERROR, "#{messages['liquidaciones.error.contrapaBanco']}");
			return false;
		}
		return true;
	}

	public void buscar(){		
		paginationData.reset();
		liquidacionesPantalla.setVieneAgenda(false);
		liquidacionesPantalla.setVieneOperaciones(false);
		liquidacionesPantalla.setTotalImportes(null);
		setPrimerAcceso(false);	
		this.listReferencias = null;
		refrescarLista();	
	}
	
	public void buildListasProductos(){		
		ModeloProducto modeloProducto = liquidacionesPantalla.getModeloProductoSelect();
		liquidacionesPantalla.setListaProdCatal(liquidacionesBo.obtenerProductoCatalogo(modeloProducto));
		liquidacionesPantalla.setListaProd(liquidacionesBo.obtenerProducto(modeloProducto));
	}

// ### FUNCIONES PARA GESTIONAR LOS CHECKBOX ###
	
	/**
	 * Cada vez que se selecciona/deselecciona una liquidaciones se actualiza la lista
	 * de las seleccionadas y se comprueba si están habilitados los botones validar y anular
	 */
	public void seleccionarLiquidaciones() {
//		this.getLiquidacionesSeleccionadas();		
	}
	
	/**
	 * Recorre la lista de liquidaciones y carga los elementos seleccionados OBSOLETA 1931

	public void getLiquidacionesSeleccionadas() {
		
		//Contiene todas las liquidaciones visibles
		List<VistaLiquidacion> liquidacionesList = liquidacionesPantalla.getListaVistaLiqui();
		
		VistaLiquidacion dataItem = null;
		
		int tamanyoLista = liquidacionesList.size();
		
		if (tamanyoLista > paginationData.getMaxResults()){ //Cuando hay paginación el último registro no se debe tener en cuenta
			tamanyoLista--;
		}
		
		//Recorremos toda la lista de liquidaciones, verificando cual está y no seleccionada
		//para asignarla a SelectedLiquiDataList
		for (int i = 0; i < tamanyoLista; i++){
			dataItem = liquidacionesList.get(i);
			
			if (!GenericUtils.isNullOrBlank(liquidacionesPantalla.getSelectedLiquiIds().get(dataItem.getId()))){
	            	
	        	if (liquidacionesPantalla.getSelectedLiquiIds().get(dataItem.getId()).booleanValue() 
	           			&& !liquidacionesPantalla.getSelectedLiquiDataList().contains(dataItem)) {
	           		
	           		liquidacionesPantalla.getSelectedLiquiDataList().add(dataItem);
	           		
//	           		if(liquidacionesPantalla.getSelectedLiquiDataList().size() == tamanyoLista){
//	           			liquidacionesPantalla.setSelecTodos(true);
//	           		}	           	
	           	}else if (!liquidacionesPantalla.getSelectedLiquiIds().get(dataItem.getId()).booleanValue() 
            			&& liquidacionesPantalla.getSelectedLiquiDataList().contains(dataItem)){
            		liquidacionesPantalla.getSelectedLiquiDataList().remove(dataItem);
            		liquidacionesPantalla.getSelectedLiquiIds().remove(dataItem.getId());
            		liquidacionesPantalla.setSelecTodos(false);
            	}
            }
			dataItem = null;
		}
    }
	 */	

	public Boolean getSelectedRow(){
		return this.liquidacionesPantalla.getSelectedLiquiDataList().contains(this.liquidacionesPantalla.getVistaLiquiSelect());
	}

	public void setSelectedRow(Boolean selected){
		if(selected){
			this.liquidacionesPantalla.getSelectedLiquiDataList().add(this.liquidacionesPantalla.getVistaLiquiSelect());
		}
		else{
			this.liquidacionesPantalla.getSelectedLiquiDataList().remove(this.liquidacionesPantalla.getVistaLiquiSelect());
			this.liquidacionesPantalla.setSelecTodos(false);
		}
	}
	
	
	
	/** Seleccionar o deseleccionar todos los checks del datagrid */
	public void seleccionarTodos(){
		
//		VistaLiquidacion vistaLiqui;
//
//		List<VistaLiquidacion> liquidacionesList = liquidacionesPantalla.getListaVistaLiqui();
//		int tamanyoLista = liquidacionesList.size();
//		
//		if (tamanyoLista > paginationData.getMaxResults()){ //Cuando hay paginación el último registro no se debe tener en cuenta
//			tamanyoLista--;
//		}
		
		//Lo primero es saber si tenemos que seleccionar o deseleccionar todos. 
		//1- Caso deseleccionar
		if(liquidacionesPantalla.getSelecTodos()){

			if(!GenericUtils.isNullOrBlank(this.liquidacionesPantalla.getSelectedLiquiDataList())){
				this.liquidacionesPantalla.getSelectedLiquiDataList().clear();
			}
			
//			if( liquidacionesPantalla.getSelectedLiquiIds()!=null ){
//				this.liquidacionesPantalla.getSelectedLiquiIds().clear();
//			}

//			for (int k = 0; k < tamanyoLista; k++ ){
//				vistaLiqui = liquidacionesList.get(k);
//				if(!GenericUtils.isNullOrBlank(liquidacionesPantalla.getSelectedLiquiIds()) && liquidacionesPantalla.getSelectedLiquiIds().get(vistaLiqui.getId())){
//					this.liquidacionesPantalla.getSelectedLiquiIds().remove(vistaLiqui.getId());
//				}
//			}
			
			this.liquidacionesPantalla.setSelecTodos(false);
						
		} else { //Caso seleccionar
			
			Integer minResul = paginationData.getFirstResult();
			Integer maxResul = paginationData.getMaxResults(); 
			int tamanyoLista = 0;
			VistaLiquidacion vistaLiqui;
			
			paginationData.setFirstResult(0);
			paginationData.setMaxResults(Constantes.MAX_RESULTS_SELECCION_TOTAL_2000);
			
			listaTemp = listaSeleccionarTodos();

			paginationData.setMaxResults(maxResul);
			paginationData.setFirstResult(minResul);
			
			if(!GenericUtils.isNullOrBlank(listaTemp)){
//				tamanyoLista = listaTemp.size();
//			
//			
//			for (int k = 0; k < tamanyoLista; k++ ){
//				vistaLiqui = listaTemp.get(k);
//				if(!GenericUtils.isNullOrBlank(this.liquidacionesPantalla.getSelectedLiquiIds()) && (GenericUtils.isNullOrBlank(liquidacionesPantalla.getSelectedLiquiIds().get(vistaLiqui.getId())) || !liquidacionesPantalla.getSelectedLiquiIds().get(vistaLiqui.getId()))){
//					this.liquidacionesPantalla.getSelectedLiquiIds().put(vistaLiqui.getId(), true);
//				}
//			}
				this.liquidacionesPantalla.getSelectedLiquiDataList().addAll(listaTemp);
			}
			this.liquidacionesPantalla.setSelecTodos(true);
		}
		
		//Guardamos en memoria las campañas seleccionadas
//		if(!GenericUtils.isNullOrBlank(this.liquidacionesPantalla.getSelectedLiquiDataList())){
//			this.liquidacionesPantalla.getSelectedLiquiDataList().clear();
//		}
//		
//		getLiquidacionesSeleccionadas();
//		
	}	
	// ### FIN CHECKBOX ###
	

	public void validarFaseErrores(){

		boolean hayMensajes = false;
		ArrayList<String> errores = new ArrayList<String>();
		int validados = liquidacionesPantalla.getRegistrosValidados();
		
		validados = validados + liquidacionesBo.tratamientoValidar(this.getLiquidacionesBloqueadas(),
				liquidacionesPantalla.getLiquidacionesMsg(),
				false,
				errores);	
		liquidacionesPantalla.setRegistrosValidados(validados);
		liquidacionesPantalla.getErrores().addAll(errores);

		for (Entry<MensajesValidacionId, MensajesValidacion> entry : liquidacionesMsg.entrySet()) {
			if (!entry.getValue().isHaSidoRespondido() &&  
				!Constantes.LIQUIDACION_VALIDADA.equals(entry.getKey().getLiquidacion().getEstado())) {
				
				hayMensajes= true;
			}
			
		}
//		for (Map.Entry mensaje : liquidacionesMsg.entrySet()) {
//			
//		}

		if (!hayMensajes) {
			listaConfirmacionesRendered = false;
			validarFase2();
		} else {
			listaConfirmacionesRendered = true;
		}		
		
	}
	
	/**
	 * Ejecuta la segunda fase de la validación, una vez el usuario ha respondido a todos los
	 * posibles mensajes de decisión	
	 */
	public void validarFase2(){
		ArrayList<String> errores = new ArrayList<String>();
		
		if (liquidacionesPantalla.getErrores()!=null) errores.addAll(liquidacionesPantalla.getErrores());
		
		int validados = liquidacionesPantalla.getRegistrosValidados();
		if (listaConfirmacionesRendered){ //cerramos el popup con la lista de confirmaciones
			setListaConfirmacionesRendered(false);
		}
		
		/* Recogemos el hashmap que tendrá los valores SI/NO escogidos por el usuario para cada mensaje
		 * de decisión y ejecutamos la lógica de validación completa, realizando las modificaciones en
		 * variables y en bbdd que se necesiten
		 */
		
//		int registrosValidados = liquidacionesBo.tratamientoValidar(this.getLiquidacionesBloqueadas(),
//							liquidacionesPantalla.getLiquidacionesMsg(),
//							false,
//							errores);
			  
		//Si se produjeron errores
		if (!GenericUtils.isNullOrBlank(errores) && !errores.isEmpty()){
			//Mostramos en el messagepanel todos los errores que se hayan producido
			
			List<String> duplicados = new ArrayList<String>();
			for (String error : errores) {
				if (!duplicados.contains(error)){
					duplicados.add(error);
					statusMessages.add(Severity.ERROR, error);
				}
		}
	}
	
		//Al terminar desbloqueamos todos los registros y desmarcamos los check
		for (VistaLiquidacion vistaLiquidacion : this.getLiquidacionesBloqueadas()) {
			dbLockService.desbloqueo(Liquidacion.class, vistaLiquidacion.getId());
			liquidacionesPantalla.getSelectedLiquiDataList().remove(vistaLiquidacion);
//			liquidacionesPantalla.getSelectedLiquiIds().remove(vistaLiquidacion.getId());
		}

		//Mostramos mensaje con el número de registros actualizados
		String mensaje = validados + " " + ResourceBundle.instance().getString("liquidaciones.registros.validados");
		statusMessages.add(Severity.INFO, mensaje);
		refrescarLista();
				
	}
			
	
	/**
	 * Realiza la desvalidación de una liquidación, es decir, pone su estado a 'Desvalidado'
	 * 
	 */
	public void desValidar(){
//		List<VistaLiquidacion> listaLiquidaciones =		liquidacionesPantalla.getSelectedLiquiDataList();
		int contadorValidadas = 0;
		for (VistaLiquidacion vistaLiq : liquidacionesPantalla.getSelectedLiquiDataList()) {
		
			if (Constantes.LIQUIDACION_VALIDADA.equals(vistaLiq.getEstado())) {

				if (this.bloquearLiquidacion(vistaLiq, "desvalidar")) {

					Liquidacion liquidacion = liquidacionesBo.cargar(vistaLiq.getId());
					vistaLiq.setEstado(Constantes.LIQUIDACION_PDTE_VALIDAR);
					try {
						vistaLiq.setEstado(Constantes.LIQUIDACION_VALIDADA);
						liquidacionesBo.desvalidarLiquidacion(liquidacion);
//						liquidacionesPantalla.getSelectedLiquiDataList().remove(vistaLiq);
						liquidacionesBo.flush();
						liquidacionesBo.cargar(liquidacion.getId());
						contadorValidadas++;
					} catch (RollbackException r) {
						statusMessages.add(Severity.ERROR, "#{messages['liquidaciones.error.rollback']}");
						throw new RollbackException();
					} finally {
						dbLockService.desbloqueo(Liquidacion.class, vistaLiq.getId());
					}
					
				}

			}
		}
		liquidacionesPantalla.getSelectedLiquiDataList().clear();
		statusMessages.addFromResourceBundle(Severity.INFO, "liquidaciones.info.desvalidadas", contadorValidadas);
		refrescarLista();
	}
	
	/**
	 * Método que se ejecuta cada vez que se entra en la página
	 */
	public void mostrarListado(){
		
	}
	
	/**
	 * Prepara para la edición de una liquidación
	 */
	public String editar(){
		
		liquidacionesPantalla.copiarSeleccionado();
		recuperarDatosLiquidacion();
		
		if(Constantes.CANAL_SWIFT.equalsIgnoreCase(liquidacionesPantalla.getVistaLiqui().getCanaliqi()) ||
		   Constantes.CANAL_TARGET.equalsIgnoreCase(liquidacionesPantalla.getVistaLiqui().getCanaliqi()) ){
			this.setPanelSwiftRendered(true);
		} else {
			this.setPanelSwiftRendered(false);
		}
		
		setModoPantalla(ModoPantalla.EDICION);
		generarCabecera();
		
		return liquidacionesPantalla.getVistaLiqui().getDescrTipOpera();
	
	}

	/** Construye la cadena de texto a mostrar en la cabecera */
	private void generarCabecera() {
		if("R".equalsIgnoreCase(liquidacionesPantalla.getVistaLiqui().getTipopera())){ //Si es recibo
			StringBuffer titulo = new StringBuffer();
			titulo.append(ResourceBundle.instance().getString("liquidaciones.detalle.recibo.titulo"));
			titulo.append(" ");
			titulo.append(liquidacionesPantalla.getVistaLiqui().getConcepto());
			liquidacionesPantalla.setCabecera(titulo.toString());
		}
	}

	/**
	 * Validaciones previas a la edición de la liquidación recibo.
	 * Los Campos de la cesión pueden estar todos vacios. Pero si hay algún campo informado, entonces
	 * los campos ENTIDDES, OFICIDES, DEPARDES, TIPOFICH, DIVISACE, OFIEMISOM, CODESTAD, CODIPAIS, 
	 * NIFTITUL son obligatorios
	 */
	public boolean guardarLiquidacionReciboValidator(){
		
		boolean esCorrecto = true;
		
		VistaLiquidacion vistaLiquidacion = liquidacionesPantalla.getVistaLiqui();
		Date fechamis = liquidacionesBo.obtenerFechaSistema(); //Recuperamos la fecha del sistema
		
		esCorrecto = validaCuenta(vistaLiquidacion);
		
		if ("SWF".equalsIgnoreCase(vistaLiquidacion.getCanaliqi())
				&& !GenericUtils.isNullOrBlank(vistaLiquidacion.getSwift().getFechaenv())){

			SimpleDateFormat sdf = new SimpleDateFormat(Constantes.DDMMYYYY);
			Date sysdate;
			Date fechaEnvio;
			
			try {
				sysdate = sdf.parse(sdf.format(new Date()));
				fechaEnvio = sdf.parse(sdf.format(vistaLiquidacion.getSwift().getFechaenv()));
			} catch (ParseException e) {
				sysdate = new Date();
				fechaEnvio = vistaLiquidacion.getSwift().getFechaenv();
			}
			
			if(fechaEnvio.compareTo(sysdate) < 0){
				esCorrecto = false;
				statusMessages.addToControl("fechaEnvTxt", Severity.ERROR, "#{messages['liquidaciones.error.fenv.incorrecta']}");
			}
			
		} else if ("50".equals(vistaLiquidacion.getGruconta()) &&  vistaLiquidacion.getOficonta() == 901 ){
			esCorrecto = false;
			statusMessages.addToControl("grupConCmb", Severity.ERROR, "#{messages['liquidaciones.error.grupcon.oficonta']}");
		
		} else if (((vistaLiquidacion.getFechaliq().getTime() - fechamis.getTime())/86400000L) < 0){
			esCorrecto = false;
			statusMessages.addToControlFromResourceBundle("fLiquiTxt", Severity.ERROR, "liquidaciones.error.fliq.incorrecta", fechamis);
		}
			
		return esCorrecto;
	}


	private boolean validaCuenta(VistaLiquidacion vistaLiquidacion) {
		boolean esCorrecto = true; 
		/* Los campos de la cuenta o están informados todos  o ninguno. */
		boolean ofiContaInformado = !GenericUtils.isNullOrBlank(vistaLiquidacion.getOficonta());
		boolean ctaContaInformado = !GenericUtils.isNullOrBlank(vistaLiquidacion.getCtaconta());
		boolean chkContaInformado = !GenericUtils.isNullOrBlank(vistaLiquidacion.getChkconta());
		boolean gruContaInformado = !GenericUtils.isNullOrBlank(vistaLiquidacion.getGruconta());
		
		boolean algunoInformado = ofiContaInformado || ctaContaInformado || chkContaInformado || gruContaInformado;
		boolean todosInformados = ofiContaInformado && ctaContaInformado && chkContaInformado && gruContaInformado;
		
		if (algunoInformado && !todosInformados){
			esCorrecto = false;
			statusMessages.add(Severity.ERROR, "#{messages['liquidaciones.error.cuenta.noinformados']}");
		}
		return esCorrecto;
	}
	
	/**
	 * Guarda el objeto liquidación con los cambios introducidos por el usuario en bbdd
	 */
	public String guardarLiquidacionRecibo(){
		
		VistaLiquidacion liqui = liquidacionesPantalla.getVistaLiqui();
		
		//SMM 20/10/2015
		if ("88".equalsIgnoreCase(liqui.getGruconta())){
			liqui.setSitualiq(SITUALIQ_PDR);	
		}else{
			liqui.setSitualiq(SITUALIQ_PDE);
		}
		
		liquidacionesBo.actualizarLiquidacion(liqui);
		liquidacionesBo.actualizarCesion(liquidacionesPantalla.getVistaLiqui());
		
		if ("SWF".equals(liqui.getCanaliqi())){
			Date fechaEnvio = liqui.getSwift().getFechaenv();
			Date fechaEnvioOriginal = liquidacionesBo.obtenerFechaEnvSwift(liqui.getId());
			
			//Si se ha cambiado la fecha de envío se actualiza el swift en bbdd
			if (!GenericUtils.isNullOrBlank(fechaEnvioOriginal) && !GenericUtils.isNullOrBlank(fechaEnvio)){
				
				long diffFechas = (fechaEnvio.getTime() - fechaEnvioOriginal.getTime())/86400000L;
				
				if (diffFechas != 0){
			liquidacionesBo.actualizarSwift(fechaEnvio, liqui);
		}
			}
		}
		
		return Constantes.CONSTANTE_SUCCESS;
	}
	
	/**
	 * 
	 * @return
	 */
	public void ver(){
//		
//		liquidacionesPantalla.copiarSeleccionado();
//		recuperarDatosLiquidacion();
//		generarCabecera();
//		setModoPantalla(ModoPantalla.INSPECCION);
//		
//		if(Constantes.CANAL_SWIFT.equalsIgnoreCase(liquidacionesPantalla.getVistaLiqui().getCanaliqi()) ||
//		   Constantes.CANAL_TARGET.equalsIgnoreCase(liquidacionesPantalla.getVistaLiqui().getCanaliqi()) ){
//			this.setPanelSwiftRendered(true);
//		} else {
//			this.setPanelSwiftRendered(false);
//		}
//		
//		return liquidacionesPantalla.getVistaLiqui().getDescrTipOpera();
		
	}

	public void descartar(){		
//		List<VistaLiquidacion> vistaLiquiList = liquidacionesPantalla.getSelectedLiquiDataList();
		if (!GenericUtils.isNullOrBlank(liquidacionesPantalla.getSelectedLiquiDataList()) && liquidacionesPantalla.getSelectedLiquiDataList().size()>0){
			for (VistaLiquidacion vl : liquidacionesPantalla.getSelectedLiquiDataList()){
				if (vl.getEstado().equals(Constantes.LIQUIDACION_PDTE_VALIDAR)||
						vl.getEstado().equals(Constantes.LIQUIDACION_VALIDADA)){
					
					if (!bloquearLiquidacion(vl, Constantes.LIQUIDACION_ACCION_DESCARTAR)){
						return;
					}else{
						liquidacionesBo.descartar(vl);
						dbLockService.desbloqueo(Liquidacion.class, vl.getId());
					}
				}
			}
		}
		liquidacionesPantalla.getSelectedLiquiDataList().clear();
		refrescarLista();
//		recargarLista();
//		rellenarLista(paginationData);
	}
	
	public boolean bloquearLiquidacion(VistaLiquidacion vistaLiquidacion, String accion){
		
		String tipoOpera = null;
		if (vistaLiquidacion.getDescrTipOpera().equals(Constantes.LIQUIDACION_TIPOPERA_P)){
			tipoOpera = Constantes.LIQUIDACION_TIPOPERA_PAGO;
		}else{
			tipoOpera = Constantes.LIQUIDACION_TIPOPERA_COBRO;
		}
		//si devuelve false es que el registro ya está bloqueado
		if (!dbLockService.bloqueo(Liquidacion.class, vistaLiquidacion.getId())){					
			statusMessages.addFromResourceBundle(Severity.ERROR,"liquidaciones.error.noBloqueo", vistaLiquidacion.getnCorrelaEstructura(), 
					vistaLiquidacion.getDescrProducto(), vistaLiquidacion.getFechaliq(), tipoOpera, vistaLiquidacion.getImportel(), accion);
			return false; 
		}else{
			Liquidacion liquidacion = liquidacionesBo.cargar(vistaLiquidacion.getId());
			if (GenericUtils.isNullOrBlank(liquidacion)){				
				statusMessages.addFromResourceBundle(Severity.ERROR,"liquidaciones.error.liquidacionInexistente", vistaLiquidacion.getnCorrelaEstructura(), 
						vistaLiquidacion.getDescrProducto(), vistaLiquidacion.getFechaliq(), tipoOpera, vistaLiquidacion.getImportel(), accion);
				dbLockService.desbloqueo(Liquidacion.class, vistaLiquidacion.getId());
				return false;
			}else{
				Date d1 = new Date(liquidacion.getAuditData().getFechaUltimaModi().getTime());
				Date d2 = new Date(vistaLiquidacion.getFeultact().getTime());
				if (d1.compareTo(d2)!=0){					
					statusMessages.addFromResourceBundle(Severity.ERROR,"liquidaciones.error.liquidacionYaModificada", vistaLiquidacion.getnCorrelaEstructura(), 
							vistaLiquidacion.getDescrProducto(), vistaLiquidacion.getFechaliq(), tipoOpera, vistaLiquidacion.getImportel(), accion, vistaLiquidacion.getFeultact());
					dbLockService.desbloqueo(Liquidacion.class, vistaLiquidacion.getId());
					return false;
				}
			}		
		}
		//El registro sigue bloqueado
		return true;
		
	}
	public Boolean getValidarHabilitado() {
		setValidarHabilitado(false);
		if (!GenericUtils.isNullOrBlank(liquidacionesPantalla.getSelectedLiquiDataList()) && 
				liquidacionesPantalla.getSelectedLiquiDataList().size()>0){
			for(VistaLiquidacion vl: liquidacionesPantalla.getSelectedLiquiDataList()){
				if (vl.getEstado().equals(Constantes.LIQUIDACION_PDTE_VALIDAR) && vl.getLiqOriginal()==null){
					setValidarHabilitado(true);
					break;
				}				
			}			
		}
		return validarHabilitado;
	}

	public void setValidarHabilitado(Boolean validarHabilitado) {
		this.validarHabilitado = validarHabilitado;
	}
	
	public Boolean getDesValidarHabilitado() {
		setDesValidarHabilitado(false);
		if (!GenericUtils.isNullOrBlank(liquidacionesPantalla.getSelectedLiquiDataList()) && 
				liquidacionesPantalla.getSelectedLiquiDataList().size()>0){
			for(VistaLiquidacion vl: liquidacionesPantalla.getSelectedLiquiDataList()){
				if (vl.getEstado().equals(Constantes.LIQUIDACION_VALIDADA)){
					setDesValidarHabilitado(true);
					break;
				}				
			}			
		}
		return desValidarHabilitado;
	}

	public void setDesValidarHabilitado(Boolean desValidarHabilitado) {
		this.desValidarHabilitado = desValidarHabilitado;
	}
	
	public void salir(){
		Conversation conversacion = Conversation.instance();
		//Volvemos a la anterior conversación
		if(conversacion.isNested()){
			conversacion.redirectToParent();
		} else {
			redirectToURL("/home.seam");
			conversacion.endAndRedirect();
		}
	}

	public void salir2(){
		refrescarLista();	
	}
	
	/**
	 * Función para llamar Boletas
	 */
	public String irOperaciones(){
		VistaLiquidacion vistaLiquidacion = liquidacionesPantalla.getVistaLiquiSelect();
		historicoOperacion = liquidacionesBo.obtenerHistoricoOperacion(vistaLiquidacion.getNcorrela(), vistaLiquidacion.getFechaope());
		
		if (historicoOperacion == null){
			statusMessages.add(Severity.WARN, "#{messages['liquidaciones.operacion.noexistente']}");
			return "";	
		}else {
			boletaState = BoletasStates.CONSULTA_BOLETA;
			return Constantes.CONSTANTE_SUCCESS;
		}
	}	
	
	/**
	 * Carga la liquidacion de base de datos para recuperar, si los hay, los datos de cesiones
	 * y de Swift. Si no los hay, mostrará los campos correspondientes vacíos en el formulario
	 */
	private void recuperarDatosLiquidacion() {
		
		//Recuperamos los datos de cesiones y swift para el registro seleccionado en el grid
		Liquidacion liquiAux = liquidacionesBo.cargar(liquidacionesPantalla.getVistaLiqui().getId());
		
		Cesiones cesionesLiquiSelec = liquiAux.getCesion();
		
		if(GenericUtils.isNullOrBlank(cesionesLiquiSelec)){
		
			Cesiones cesionAlta = new Cesiones(new CesionesId(liquiAux));
			VistaLiquidacion vistaLiq = liquidacionesPantalla.getVistaLiqui(); 
			
			AuditData auditData = new AuditData();
			auditData.setUsuarioUltimaModi(Identity.instance().getCredentials().getUsername());
			auditData.setFechaUltimaModi(new Date());
					
			cesionAlta.setAuditData(auditData);
			cesionAlta.setNcorrela(vistaLiq.getNcorrela());
			cesionAlta.setFechaope(vistaLiq.getFechaope());
			cesionAlta.setImportes(vistaLiq.getImportel());
		
			vistaLiq.setCesion(cesionAlta);

		} else {
			liquidacionesPantalla.getVistaLiqui().setCesion(cesionesLiquiSelec);
		}
		
		Swift swiftLiquiSelec = liquiAux.getSwift();
		
		if(GenericUtils.isNullOrBlank(swiftLiquiSelec)){
			
			Swift swiftAlta = new Swift(new SwiftId(liquiAux));
			VistaLiquidacion vistaLiq = liquidacionesPantalla.getVistaLiqui(); 

			swiftAlta.setFechaliq(vistaLiq.getFechaliq());
			swiftAlta.setNcorrela(vistaLiq.getNcorrela());
			swiftAlta.setFechaope(vistaLiq.getFechaope());
			swiftAlta.setTipopera(vistaLiq.getTipopera());
			swiftAlta.setCodivisa(vistaLiq.getDivisali());
		    
			liquidacionesPantalla.getVistaLiqui().setSwift(swiftAlta);
			
			
		} else {
			liquidacionesPantalla.getVistaLiqui().setSwift(swiftLiquiSelec);
		}
		
	}
	
	/** Abre el popup de calificar cobro */
	public void calificarCobro(){
		//Copiamos el seleccionado
		liquidacionesPantalla.copiarSeleccionado();
		
		String situliq = liquidacionesPantalla.getVistaLiqui().getSitualiq();
		
		//Deshabilitamos campos si es necesario
		if (SITUALIQ_PDR.equalsIgnoreCase(situliq) 
				|| SITUALIQ_VEN.equalsIgnoreCase(situliq)){
			this.camposCalificarDisabled = false;
		} else {
			this.camposCalificarDisabled = true;
		}
		
		String isForzar = liquidacionesPantalla.getVistaLiqui().getIndforza();
		
		//Asignamos el valor al chechbox
		if(Constantes.CONSTANTE_SI.equalsIgnoreCase(isForzar)){
			liquidacionesPantalla.setForzar(true);
		} else {
			liquidacionesPantalla.setForzar(false);
		}
		
		calificarRendered = true;
	}
	
	/**
	 * Realiza un update del registro correspondiente en la tabla deri.liquidac con los campos entrados
	 */
	public void guardarCalificarCobro(){
		
		VistaLiquidacion vista = liquidacionesPantalla.getVistaLiqui();
		
		if(liquidacionesPantalla.isForzar()){
			vista.setIndforza(Constantes.CONSTANTE_SI);
		} else {
			vista.setIndforza(Constantes.CONSTANTE_NO);
		}
		
		liquidacionesBo.actualizarCalificarCobro(vista);
		
		this.setCalificarRendered(false); //Cerramos el PopUp
	}
	
	public HashMap<MensajesValidacionId,MensajesValidacion> getItems() {
		return liquidacionesPantalla.getLiquidacionesMsg();
	}

	
	public List<MensajesValidacionId> getItemKeys() {
		List<MensajesValidacionId> keys = new ArrayList<MensajesValidacionId>();

//		keys.addAll(liquidacionesPantalla.getLiquidacionesMsg().keySet());

		for (Entry<MensajesValidacionId, MensajesValidacion> entry : liquidacionesPantalla.getLiquidacionesMsg().entrySet()) {
		
			if (!entry.getValue().isHaSidoRespondido()){
				keys.add(entry.getKey()); 
			}
			
		}
		
		return keys;
	}
	
	public LiquidacionesBo getLiquidacionesBo() {
		return liquidacionesBo;
	}

	public void setLiquidacionesBo(LiquidacionesBo liquidacionesBo) {
		this.liquidacionesBo = liquidacionesBo;
	}

	public LiquidacionesPantalla getLiquidacionesPantalla() {
		return liquidacionesPantalla;
	}

	public void setLiquidacionesPantalla(LiquidacionesPantalla liquidacionesPantalla) {
		this.liquidacionesPantalla = liquidacionesPantalla;
	}

	public DbLockService getDbLockService() {
		return dbLockService;
	}

	public void setDbLockService(DbLockService dbLockService) {
		this.dbLockService = dbLockService;
	}

	public boolean isCamposCalificarDisabled() {
		return camposCalificarDisabled;
	}

	public void setCamposCalificarDisabled(boolean camposCalificarDisabled) {
		this.camposCalificarDisabled = camposCalificarDisabled;
	}

	public boolean isCalificarRendered() {
		return calificarRendered;
	}

	public void setCalificarRendered(boolean calificarRendered) {
		this.calificarRendered = calificarRendered;
	}


	public boolean isPanelSwiftRendered() {
		return panelSwiftRendered;
	}


	public void setPanelSwiftRendered(boolean panelSwiftRendered) {
		this.panelSwiftRendered = panelSwiftRendered;
	}
	
	
	public List<VistaLiquidacion> getLiquidacionesBloqueadas() {
		return liquidacionesBloqueadas;
	}


	public void setLiquidacionesBloqueadas(
			List<VistaLiquidacion> liquidacionesBloqueadas) {
		this.liquidacionesBloqueadas = liquidacionesBloqueadas;
	}


	public boolean isListaConfirmacionesRendered() {
		return listaConfirmacionesRendered;
	}


	public void setListaConfirmacionesRendered(boolean listaConfirmacionesRendered) {
		this.listaConfirmacionesRendered = listaConfirmacionesRendered;
	}


	public HashMap<MensajesValidacionId, MensajesValidacion> getLiquidacionesMsg() {
		return liquidacionesMsg;
	}


	public void setLiquidacionesMsg(
			HashMap<MensajesValidacionId, MensajesValidacion> liquidacionesMsg) {
		this.liquidacionesMsg = liquidacionesMsg;
	}
	
	public void recargarLista(){
	refrescarLista();
	List<VistaLiquidacion> listaVistaLiqui = liquidacionesPantalla.getListaVistaLiqui();
	for (VistaLiquidacion vistaLiquidacion : listaVistaLiqui) {
		liquidacionesBo.cargar(vistaLiquidacion.getId());
		if (vistaLiquidacion.getId()!=null)
		liquidacionesBo.cargarConfirmacion(vistaLiquidacion.getId());
	}
	}
	
	public List<VistaLiquidacion> listaSeleccionarTodos(){
					return	liquidacionesBo.seleccionarDatosLiquidacionesConf(liquidacionesPantalla.getModeloProductoSelect(), liquidacionesPantalla.getProdCatalSelect(),
							liquidacionesPantalla.getNumOperDesde(), liquidacionesPantalla.getNumOperHasta(), liquidacionesPantalla.getDivPagoSelect(),
							liquidacionesPantalla.getProdOperSelect(), liquidacionesPantalla.getFechaLiquidDesde(), liquidacionesPantalla.getFechaLiquidHasta(), 
							liquidacionesPantalla.getDivCobroSelect(), liquidacionesPantalla.getContrapartidaSelect(), 
							liquidacionesPantalla.getNumEstructDesde(), liquidacionesPantalla.getNumEstructHasta(), liquidacionesPantalla.getEstadoLiqSelect(),				
							liquidacionesPantalla.getSitCorrespSelect(), null, null,"OK", exportExcel, paginationData);			

				}






	
	public List<VistaLiquidacion> getListaTemp() {
		return listaTemp;
	}


	public void setListaTemp(List<VistaLiquidacion> listaTemp) {
		this.listaTemp = listaTemp;
	}

	
	
	public String getRowClasses(){
		StringBuilder builder = new StringBuilder();
		int i=0;
		for (VistaLiquidacion vl : liquidacionesPantalla.getListaVistaLiqui()) {
			if(i>0){
				builder.append(",");
			}
			if(vl.getLiqOriginal()!=null){
				builder.append("resaltarRow");
			}
			else{
				if(i%2==0){
					builder.append("oddRow");
				}
				else{
					builder.append("evenRow");
				}
			}
			i++;
		}
		return builder.toString();
	}
	

	@Factory(value = "listaNombresModelo")
	public void obtenerNombresModelo() {
//		this.tipoErroresConciliacionList = erroresConciliacionBo.obtenerTiposErroresConciliacionSelect(erroresConciliacionPantalla.getFechaProceso(),erroresConciliacionPantalla.getTipoConciliacion(),erroresConciliacionPantalla.getIndicActividad());
		this.listReferencias = liquidacionesBo.obtenerListaReferencias(liquidacionesPantalla.getContrapartidaSelect());
	}

	public boolean confirmarValidator(){
		if (GenericUtils.isNullOrBlank(liquidacionesPantalla.getNombreReferencia())){
			statusMessages.add(Severity.ERROR,
			"#{messages['liquidaciones.error.nombre']}");
			return false;
		}
		return true;
	}
	
	public void confirmar(){
		
		
		if (!GenericUtils.isNullOrBlank(liquidacionesPantalla.getSelectedLiquiDataList()) && liquidacionesPantalla.getSelectedLiquiDataList().size()>0){
			ReferenciaConfirmacion referencia;
			if (liquidacionesPantalla.getReferenciaModelo()==null && !liquidacionesBo.existenciaNombre(liquidacionesPantalla.getNombreReferencia())){
//				insertarReferencia
//				obtenerID
//				obtenerContrapa
				Contrapartida contrapa = liquidacionesBo.cargarContrapartida(liquidacionesPantalla.getContrapartidaSelect());
				Integer id = liquidacionesBo.recuperarNuevoIndice();
				
				referencia = new ReferenciaConfirmacion(id, liquidacionesPantalla.getNombreReferencia(), liquidacionesPantalla.getTelefono(), liquidacionesPantalla.getEmail(), liquidacionesPantalla.getCanal(), contrapa);
				liquidacionesBo.guardarNuevoReferenciaConfirmacion(referencia);
			}else{
				if (liquidacionesPantalla.getReferenciaModelo()==null){
//No han seleccionado ningún Contacto pero este ya existe.
					liquidacionesPantalla.setReferenciaModelo(liquidacionesBo.cargarPorNombre(liquidacionesPantalla.getNombreReferencia()));
				}
				
				liquidacionesPantalla.getReferenciaModelo().setCanal(liquidacionesPantalla.getCanal());
				liquidacionesPantalla.getReferenciaModelo().setEmail(liquidacionesPantalla.getEmail());
				liquidacionesPantalla.getReferenciaModelo().setTelefono(liquidacionesPantalla.getTelefono());
				liquidacionesBo.guardarReferenciaConfirmacion(liquidacionesPantalla.getReferenciaModelo());
				referencia = liquidacionesPantalla.getReferenciaModelo(); 
			}

// 			Obtener Fecha Dia		
			Date fechaSistema = liquidacionesBo.obtenerFechaSistema();
			for (VistaLiquidacion vl : liquidacionesPantalla.getSelectedLiquiDataList()){
				Liquidacion liquidacion = (Liquidacion) vl;
				AuditData audit = new AuditData();
				ConfirmacionBancaria confirmacion = new ConfirmacionBancaria(liquidacion.getId(), "OK", liquidacion.getFechaope(), liquidacion.getNcorrela(), fechaSistema, liquidacionesPantalla.getObservaciones(), referencia, null);
				audit.setFechaUltimaModi(fechaSistema);
				audit.setUsuarioUltimaModi(credentials.getUsername());
				confirmacion.setAuditData(audit);
				if (GenericUtils.isNullOrBlank(vl.getEstadoConf())){
					liquidacionesBo.guardarNuevoConfirmacionBancaria(confirmacion);
				}else{
					liquidacionesBo.guardarConfirmacionBancaria(confirmacion);
				}
			}
		}
		liquidacionesBo.flushReferenciaConfirmacion();
		liquidacionesBo.flushConfirmacionBancaria();
		limpiarContacto();
		liquidacionesPantalla.getSelectedLiquiDataList().clear();
		recargarLista();	
		statusMessages.add(Severity.INFO,
		"#{messages['liquidaciones.confirmar.exito']}");

	}




	private void limpiarContacto() {
		liquidacionesPantalla.setNombreReferencia(null);
		liquidacionesPantalla.setTelefono(null);
		liquidacionesPantalla.setEmail(null);
		liquidacionesPantalla.setCanal(null);
		liquidacionesPantalla.setObservaciones(null);
		liquidacionesPantalla.setReferenciaModelo(null);
	}
	
	public boolean noConfirmarValidator(){
		if (GenericUtils.isNullOrBlank(liquidacionesPantalla.getNombreReferencia())){
			statusMessages.add(Severity.ERROR,
			"#{messages['liquidaciones.error.nombre']}");
			return false;
		}
		return true;
	}
	
	public void noConfirmar(){
		List<Liquidacion> listNoConf = new ArrayList<Liquidacion>();
			
		if (!GenericUtils.isNullOrBlank(liquidacionesPantalla.getSelectedLiquiDataList()) && liquidacionesPantalla.getSelectedLiquiDataList().size()>0){
			for (VistaLiquidacion vl : liquidacionesPantalla.getSelectedLiquiDataList()){
				if (GenericUtils.isNullOrBlank(vl.getEstadoConf())){
					listNoConf.add((Liquidacion)vl);
				}
				
			}
		}

		if (listNoConf.size()>0){
			ReferenciaConfirmacion referencia;
			if (liquidacionesPantalla.getReferenciaModelo()==null && !liquidacionesBo.existenciaNombre(liquidacionesPantalla.getNombreReferencia())){
//				insertarReferencia
//				obtenerID
//				obtenerContrapa
				Contrapartida contrapa = liquidacionesBo.cargarContrapartida(liquidacionesPantalla.getContrapartidaSelect());
				Integer id = liquidacionesBo.recuperarNuevoIndice();
				referencia = new ReferenciaConfirmacion(id, liquidacionesPantalla.getNombreReferencia(), liquidacionesPantalla.getTelefono(), liquidacionesPantalla.getEmail(), liquidacionesPantalla.getCanal(), contrapa);
				liquidacionesBo.guardarNuevoReferenciaConfirmacion(referencia);
			}else{
				liquidacionesPantalla.getReferenciaModelo().setCanal(liquidacionesPantalla.getCanal());
				liquidacionesPantalla.getReferenciaModelo().setEmail(liquidacionesPantalla.getEmail());
				liquidacionesPantalla.getReferenciaModelo().setTelefono(liquidacionesPantalla.getTelefono());
				liquidacionesBo.guardarReferenciaConfirmacion(liquidacionesPantalla.getReferenciaModelo());
				referencia = liquidacionesPantalla.getReferenciaModelo(); 
			}

// 			Obtener Fecha Dia		
			Date fechaSistema = liquidacionesBo.obtenerFechaSistema();
			for (Liquidacion liquidacion  : listNoConf){
				AuditData audit = new AuditData();
				ConfirmacionBancaria confirmacion = new ConfirmacionBancaria(liquidacion.getId(), "KO", liquidacion.getFechaope(), liquidacion.getNcorrela(), fechaSistema, liquidacionesPantalla.getObservaciones(), referencia, null);
				audit.setFechaUltimaModi(fechaSistema);
				audit.setUsuarioUltimaModi(credentials.getUsername());
				confirmacion.setAuditData(audit);
				liquidacionesBo.guardarNuevoConfirmacionBancaria(confirmacion);
			}
		}
		liquidacionesBo.flushReferenciaConfirmacion();
		liquidacionesBo.flushConfirmacionBancaria();
		limpiarContacto();
		liquidacionesPantalla.getSelectedLiquiDataList().clear();
		recargarLista();
		statusMessages.add(Severity.INFO,
		"#{messages['liquidaciones.noconfirmar.exito']}");

	}
	

	public void referenciaSelect(){
		if (!GenericUtils.isNullOrBlank(liquidacionesPantalla.getReferenciaModelo())){
				
				liquidacionesPantalla.setNombreReferencia(liquidacionesPantalla.getReferenciaModelo().getNombre());
				liquidacionesPantalla.setTelefono(liquidacionesPantalla.getReferenciaModelo().getTelefono());
				liquidacionesPantalla.setEmail(liquidacionesPantalla.getReferenciaModelo().getEmail());
				liquidacionesPantalla.setCanal(liquidacionesPantalla.getReferenciaModelo().getCanal());			
		}
	}

	public Boolean esContrapartidaBancaria(String contrapa){
		return liquidacionesBo.esContrapartidaBancaria(contrapa);
	}

	public void referenciaPago(){
		ConfirmacionBancaria confi = null;
		if(!GenericUtils.isNullOrBlank(liquidacionesPantalla.getVistaLiquiSelect())) {
			confi = liquidacionesBo.cargarConfirmacion(liquidacionesPantalla.getVistaLiquiSelect().getId());
		}
		
		if(!GenericUtils.isNullOrBlank(confi)) {
			confi.setReferenciaPago(liquidacionesPantalla.getReferenciaPago());
			liquidacionesBo.guardarConfirmacionBancaria(confi);
		}

		
//		if 	(!GenericUtils.isNullOrBlank(liquidacionesPantalla.getReferenciaPago())){
//			admconfirmacionesBo.guardarReferencia(admConfirmacionesPantalla.getAdmconfirmacionSuRefer().getOperacionID(), 
//					admConfirmacionesPantalla.getAdmconfirmacionSuRefer().getFechaContratacion(),admConfirmacionesPantalla.getSuReferencia());
//			HistoricoOperacion hOperReferencia = admConfirmacionesPantalla.gethOperReferencia();
//			admconfirmacionesBo.refrescarHO(admConfirmacionesPantalla.getAdmconfirmacionSuRefer(),hOperReferencia);
			
//		}
	}
	
	
	public void obtenerReferencia(){
		ConfirmacionBancaria confi = null;
		if(!GenericUtils.isNullOrBlank(liquidacionesPantalla.getVistaLiquiSelect())) {
			confi = liquidacionesBo.cargarConfirmacion(liquidacionesPantalla.getVistaLiquiSelect().getId());
		}
		
		if(!GenericUtils.isNullOrBlank(confi)) {
			liquidacionesPantalla.setReferenciaPago(confi.getReferenciaPago());
		}

//		final ConfOperacion cOperacion = admConfirmacionesPantalla
//		.getAdmconfirmacionSelec();
//	
//		historicoOperacion = admconfirmacionesBo.obtenerHistoricoOperacion(
//				cOperacion.getOperacionID(), cOperacion.getFechaContratacion());
//		
//		Contrapartida contrapa = admconfirmacionesBo.cargarContrapa(cOperacion.getOperacion().getContrapa());
////		oncomplete="{Richfaces.showModalPanel('suReferenciaPanel');}"
//	
//		if (Constantes.CONTRAPA_GRUPOBAN_CLIENTE.equalsIgnoreCase(contrapa.getGrupoBancario().getId())){
//			statusMessages.add(Severity.ERROR,"#{messages['admconfirmaciones.error.contrapanobanco']}");
//			setOnCompleteNo();
//		}else{
//			setOnCompleteSi();
//		}
//		
//		admConfirmacionesPantalla.sethOperReferencia(historicoOperacion);
//		admConfirmacionesPantalla.setSuReferencia(historicoOperacion.getSuReferencia());
//		admConfirmacionesPantalla.setAdmconfirmacionSuRefer(cOperacion);
	}
	
//	public void mensaje(String errorMensaje){
//		if (messageBoxAction==null){
//			messageBoxAction=new MessageBoxAction();
//		}
//		messageBoxAction.init(errorMensaje, "confirmarLiquidacionesAction.voidfunction()", "");
//	}
//
//	public void voidfunction(){
//		
//	}


	public String anexos(){
		String ret = Constantes.SUCCESS;
//		VistaOperacion vo = vistaOperacionSelected;
//		historicoOperacion = vo.getHistOper();
		modoTratamiento = Constantes.TIPOANEXO_MODO_E;
		tipoAnexo = Constantes.TIPOANEXO_LIQUIDACION;
		
		VistaLiquidacion vistaLiquidacion = liquidacionesPantalla.getVistaLiquiSelect();
		historicoOperacion = liquidacionesBo.obtenerHistoricoOperacion(vistaLiquidacion.getNcorrela(), vistaLiquidacion.getFechaope());
		if (historicoOperacion == null){
			statusMessages.add(Severity.WARN, "#{messages['liquidaciones.operacion.noexistente']}");
			return "";
		}
		fechaLiquidacion2= vistaLiquidacion .getFechaliq();
		return ret;
	}

	public Boolean unicoAnexo(VistaLiquidacion vistaLiquidacion){
		
		return liquidacionesBo.unicoAnexo(vistaLiquidacion.getNcorrela(),
				vistaLiquidacion.getFechaope(),vistaLiquidacion .getFechaliq(),paginationData);
		
	}
	
	public String anexosConsulta(){
		String ret = Constantes.SUCCESS;
		modoTratamiento = Constantes.TIPOANEXO_MODO_C;
		tipoAnexo = Constantes.TIPOANEXO_LIQUIDACION;
		
		VistaLiquidacion vistaLiquidacion = liquidacionesPantalla.getVistaLiquiSelect();
		historicoOperacion = liquidacionesBo.obtenerHistoricoOperacion(vistaLiquidacion.getNcorrela(), vistaLiquidacion.getFechaope());
		if (historicoOperacion == null){
			statusMessages.add(Severity.WARN, "#{messages['liquidaciones.operacion.noexistente']}");
			return "";
		}
		fechaLiquidacion2= vistaLiquidacion .getFechaliq();
		return ret;
	}

	public void init(){
		if(messageBoxConfLiquidacionAction==null){
			messageBoxConfLiquidacionAction = new MessageBoxAction();
		}
	}
	
	public void voidFunction(){
		msgBoxAction.voidFunction();
	}

	/**
	 * Mostrar PopUp cuando una contrapartida está bloqueada (no bloqueante)
	 */
	public void onVerificarContrapartidaBloqueada() {
		if(null!=liquidacionesPantalla.getContrapartidaSelect()){
			String idContrapa = liquidacionesPantalla.getContrapartidaSelect();
	    	Contrapartida contrapObtenida2 = null;
			if (!GenericUtils.isNullOrBlank(idContrapa)){
				contrapObtenida2 = liquidacionesBo.cargarContrapartida(idContrapa.toUpperCase());
				if (null!=contrapObtenida2 && !GenericUtils.isNullOrBlank(contrapObtenida2.getIndBloqueo()) && "S".equalsIgnoreCase(contrapObtenida2.getIndBloqueo())){
					messageBoxConfLiquidacionAction.init("liquidaciones.messages.contrapartida.bloqueada.texto", "confirmarLiquidacionesAction.voidFunction()", null,"messageBoxPanelContrapa");
				}
			}
		}
    }
}

