package com.atosorigin.deri.adminoper.liquidaciones.action;

import java.awt.Event;
import java.math.BigDecimal;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.HashMap;
import java.util.List;
import java.util.Map.Entry;

import javax.persistence.RollbackException;

import org.hibernate.SQLQuery;
import org.jboss.seam.ScopeType;
import org.jboss.seam.annotations.In;
import org.jboss.seam.annotations.Name;
import org.jboss.seam.annotations.Out;
import org.jboss.seam.annotations.Scope;
import org.jboss.seam.core.Conversation;
import org.jboss.seam.core.ResourceBundle;
import org.jboss.seam.international.StatusMessage.Severity;
import org.jboss.seam.security.Identity;

import com.atosorigin.common.action.ModoPantalla;
import com.atosorigin.common.action.PaginatedListAction;
import com.atosorigin.common.action.PaginationData;
import com.atosorigin.common.auditdata.AuditData;
import com.atosorigin.common.constantes.Constantes;
import com.atosorigin.common.formvalidator.FormValidator;
import com.atosorigin.common.utils.GenericUtils;
import com.atosorigin.deri.adminoper.boletas.action.BoletasAction.BoletasStates;
import com.atosorigin.deri.adminoper.boletas.business.BoletasBo;
import com.atosorigin.deri.adminoper.liquidaciones.screen.LiquidacionesPantalla;
import com.atosorigin.deri.common.dbLock.DbLockService;
import com.atosorigin.deri.common.parametrosPantalla.ParametrosOutAgenda;
import com.atosorigin.deri.liquidaciones.business.LiquidacionesBo;
import com.atosorigin.deri.liquidaciones.business.MensajesValidacion;
import com.atosorigin.deri.liquidaciones.business.MensajesValidacionId;
import com.atosorigin.deri.model.contrapartida.Contrapartida;
import com.atosorigin.deri.model.gestionoperaciones.HistoricoOperacion;
import com.atosorigin.deri.model.gestionoperaciones.Operacion;
import com.atosorigin.deri.model.liquidaciones.Cesiones;
import com.atosorigin.deri.model.liquidaciones.CesionesId;
import com.atosorigin.deri.model.liquidaciones.Liquidacion;
import com.atosorigin.deri.model.liquidaciones.Swift;
import com.atosorigin.deri.model.liquidaciones.SwiftId;
import com.atosorigin.deri.model.liquidaciones.VistaLiquidacion;
import com.atosorigin.deri.model.murex.ModeloProducto;
import com.atosorigin.deri.util.MessageBoxAction;
import com.atosorigin.deri.util.MsgBoxAction;

@Name("liquidacionesAction")
@Scope(ScopeType.CONVERSATION)
@FormValidator
public class LiquidacionesAction extends PaginatedListAction implements java.io.Serializable{
	
	private static final long serialVersionUID = 6628655655551155915L;
	
	public static final String SITUALIQ_PDR = "PDR";
	public static final String SITUALIQ_PDE = "PDE";
	public static final String SITUALIQ_VEN = "VEN";
	
	@In("#{liquidacionesBo}")
	protected LiquidacionesBo liquidacionesBo;

	@In("#{boletasBo}")
	protected BoletasBo boletasBo;
	
	@In(create=true)
	protected LiquidacionesPantalla liquidacionesPantalla;
	
	/**
	 * Inyección datos provenientes de Agenda o Lista de Operaciones
	 */
	@In(required = false, value="#{parametrosOutAgenda}")
	protected ParametrosOutAgenda parametrosOutAgenda;
	
	protected Boolean validarHabilitado = false;
	protected Boolean desValidarHabilitado = false;
	protected boolean camposCalificarDisabled;
	protected boolean calificarRendered = false;
	protected boolean listaConfirmacionesRendered = false;
	protected boolean panelSwiftRendered;
	private Integer ultimRegistre;
	
	HashMap<MensajesValidacionId, MensajesValidacion> liquidacionesMsg;
	
	/** Inyección del servicio que gestiona los bloqueos de registros en base de datos */
	@In(create = true)
	protected DbLockService dbLockService;	
	
	/** Inyeccion del componente necesario para mostrar mensajes de decisión al usuario */
	@In(create = true)
	private MsgBoxAction msgBoxAction;

	private List<VistaLiquidacion> liquidacionesBloqueadas;
	
	//Selección de 500 registros para el botón seleccionar todos.
	private List<VistaLiquidacion> listaTemp;
	
	//Para la union con datos generales alta BOLETAS
	@Out(required=false)
	private BoletasStates boletaState;
	
	//Para la union con datos generales alta BOLETAS
	@Out(required=false)
	HistoricoOperacion historicoOperacion;

	private Boolean primeraEjecucionInit=null;
	private Boolean primeraEjecucionModificarInit=null;
	
	@Out(required = false, value = "liquidacionesMessageBoxAction")
	private MessageBoxAction msgboxPanelLiquidContrapaBloq;
	
	// oO[Métodos]Oo
	@Override
	public List<VistaLiquidacion> getDataTableList() { 
		return liquidacionesPantalla.getListaVistaLiqui();
	}
	
	
	public boolean guardarLiquidacionPagoValidator(){		
		
		boolean esCorrecto = true;
		SimpleDateFormat sdf = new SimpleDateFormat(Constantes.DDMMYYYY);
		VistaLiquidacion vistaLiquidacion = liquidacionesPantalla.getVistaLiqui();
		//Date fechamis = liquidacionesBo.obtenerFechaSistema(); //Recuperamos la fecha del sistema
		
		esCorrecto = validaCuenta(vistaLiquidacion);
		
		Swift swift = vistaLiquidacion.getSwift();
		Date fechaHoy = new Date();
//		if (vistaLiquidacion.getImportel().compareTo(BigDecimal.ZERO) < 0 ){
//			statusMessages.add(Severity.ERROR, "#{messages['liquidaciones.error.importeNegativo']}");
//			esCorrecto = false;	
//		}
		if(Constantes.CANAL_SWIFT.equals(vistaLiquidacion.getCanaliqi())){
			if((!GenericUtils.isNullOrBlank(vistaLiquidacion.getSwift().getFechaenv())) 
					&& sdf.format(vistaLiquidacion.getSwift().getFechaenv()).compareTo(sdf.format(fechaHoy))< 0){
				statusMessages.add(Severity.ERROR, "#{messages['liquidaciones.error.swift.fechaAnterior']}");
				esCorrecto = false;	
			}else if(!compruebaCorrelativos(swift.getInterml1(), swift.getInterml2(), swift.getInterml3(), swift.getInterml4(), null, null)){
				statusMessages.add(Severity.ERROR, "#{messages['parametrosLiquidacion.error.textosNoCorrelativos']}");
				esCorrecto = false;
				
			}else if(!compruebaCorrelativos(swift.getBdbenel1(), swift.getBdbenel2(), swift.getBdbenel3(), swift.getBdbenel4(), null, null)){
				statusMessages.add(Severity.ERROR, "#{messages['liquidaciones.error.swift.fechaAnterior']}");
				esCorrecto = false;
			}else if(!compruebaCorrelativos(swift.getBbenefl1(), swift.getBbenefl2(), swift.getBbenefl3(), swift.getBbenefl4(), null, null)){
				statusMessages.add(Severity.ERROR, "#{messages['liquidaciones.error.swift.fechaAnterior']}");
				esCorrecto = false;
			}else if(!compruebaCorrelativos(swift.getObservl1(), swift.getObservl2(), swift.getObservl3(), swift.getObservl4(), swift.getObservl5(), swift.getObservl6())){
				statusMessages.add(Severity.ERROR, "#{messages['liquidaciones.error.swift.fechaAnterior']}");
				esCorrecto = false;
			}else if(!validaLineasByCodigo(swift.getIntercod(), swift.getIntercta() , swift.getInterml1(), swift.getInterml2(), swift.getInterml3(), swift.getInterml4())){
				statusMessages.add(Severity.ERROR, "#{messages['liquidaciones.error.errorCodigoTexto']}");
				esCorrecto = false;
			}else if(!validaLineasByCodigo(swift.getBdbencod(),swift.getBdbencta(), swift.getBdbenel1(), swift.getBdbenel2(), swift.getBdbenel3(), swift.getBdbenel4())){
				statusMessages.add(Severity.ERROR, "#{messages['liquidaciones.error.errorCodigoTexto']}");
				esCorrecto = false;
			}else if(!validaLineasByCodigo(swift.getBbenecod(),swift.getBbenecta(), swift.getBbenefl1(), swift.getBbenefl2(), swift.getBbenefl3(), swift.getBbenefl4())	){
				statusMessages.add(Severity.ERROR, "#{messages['liquidaciones.error.errorCodigoTexto']}");
				esCorrecto = false;
			}else if(GenericUtils.isNullOrBlank(swift.getTiddesti()) || 
					(( GenericUtils.isNullOrBlank(swift.getBbenecod()) || GenericUtils.isNullOrBlank(swift.getBbenecta()) )
					&& GenericUtils.isNullOrBlank(swift.getBbenefl1()))){
			
				statusMessages.add(Severity.ERROR, "#{messages['liquidaciones.error.obligatoriosSwift']}");
				esCorrecto = false;
			}
		}
		if("50".equals(vistaLiquidacion.getGruconta()) && "901".equals(vistaLiquidacion.getOficonta())){
			statusMessages.add(Severity.ERROR, "#{messages['liquidaciones.error.grupoContableErroneo']}");
			esCorrecto = false;
		}
		
		//if((!GenericUtils.isNullOrBlank(vistaLiquidacion.getFechaliq())) && vistaLiquidacion.getFechaliq().getTime() < fechamis.getTime()){
		//	statusMessages.addToControlFromResourceBundle("fLiquiTxt", Severity.ERROR, "liquidaciones.error.fliq.incorrecta", fechamis);
		//	esCorrecto = false;
		//}
	
		if(!GenericUtils.isNullOrBlank(vistaLiquidacion.getCesion()) && !GenericUtils.isNullOrBlank(vistaLiquidacion.getCesion().getEntiddes())){
			if (!liquidacionesBo.comprobarEntidad(vistaLiquidacion.getCesion().getEntiddes())){
				statusMessages.addToControlFromResourceBundle("txtentidadPg", Severity.ERROR, "liquidaciones.error.entidad", vistaLiquidacion.getCesion().getEntiddes());
				esCorrecto = false;
			}
		}
		
		return esCorrecto;
	}
	
	public boolean validaLineasByCodigo(String codigo, String cta,  String linea1, String linea2, String linea3, String linea4){
		boolean retorno = true;
		if(!GenericUtils.isNullOrBlank(codigo) && !GenericUtils.isNullOrBlank(cta)){
			if(!GenericUtils.isNullOrBlank(linea1) || !GenericUtils.isNullOrBlank(linea2) || !GenericUtils.isNullOrBlank(linea3) || !GenericUtils.isNullOrBlank(linea4)){
				retorno = false;
			}
		}
		return retorno;
	}
	
	
	public boolean compruebaCorrelativos(String texto1, String texto2, String texto3, String texto4, String texto5, String texto6){
		//Si son nulos, indica que no son del campo de observaciones. 
		boolean retorno = true;
		if(GenericUtils.isNullOrBlank(texto5) && GenericUtils.isNullOrBlank(texto6)){
			if((!GenericUtils.isNullOrBlank(texto1)) && (GenericUtils.isNullOrBlank(texto2)) && (!GenericUtils.isNullOrBlank(texto3) || !GenericUtils.isNullOrBlank(texto4)|| !GenericUtils.isNullOrBlank(texto5)|| !GenericUtils.isNullOrBlank(texto6))){
				retorno = false;
			}
			if((!GenericUtils.isNullOrBlank(texto1)) && (!GenericUtils.isNullOrBlank(texto2)) && 
					(GenericUtils.isNullOrBlank(texto3)) && (!GenericUtils.isNullOrBlank(texto4) || !GenericUtils.isNullOrBlank(texto5)|| !GenericUtils.isNullOrBlank(texto6))){
				
				retorno = false;
			}
			if((!GenericUtils.isNullOrBlank(texto1)) && (!GenericUtils.isNullOrBlank(texto2)) && 
					(!GenericUtils.isNullOrBlank(texto3)) && (GenericUtils.isNullOrBlank(texto4)) && ( !GenericUtils.isNullOrBlank(texto5)|| !GenericUtils.isNullOrBlank(texto6))){
				
				retorno = false;
			}
		}else{
			//tan solo tenemos que controlar los 4 primeros campos y obiamos el caso de que escriban el campo 1, el campo 2 y el campo 3...
			if((!GenericUtils.isNullOrBlank(texto1)) && (GenericUtils.isNullOrBlank(texto2)) && (!GenericUtils.isNullOrBlank(texto3) || !GenericUtils.isNullOrBlank(texto4))){
				retorno = false;
			}
			if((!GenericUtils.isNullOrBlank(texto1)) && (!GenericUtils.isNullOrBlank(texto2)) && 
					(GenericUtils.isNullOrBlank(texto3) && !GenericUtils.isNullOrBlank(texto4))){
				retorno = false;
			}
		}
		
		return retorno;
	}
	
	public String guardarLiquidacionPago(){
		
		Liquidacion liquidacion = liquidacionesPantalla.getVistaLiqui();
//		liquidacion = llenarCamposPago();//Según alfons el proyecto nunca puede ser nulo...
		liquidacion.setSitualiq(SITUALIQ_PDE);
		liquidacionesBo.actualizarLiquidacion(liquidacion);
		liquidacionesBo.actualizarCesion(liquidacionesPantalla.getVistaLiqui());
		if(Constantes.CANAL_SWIFT.equals(liquidacion.getCanaliqi()) ){
			liquidacionesBo.actualizarSwift(liquidacion.getSwift().getFechaenv(), liquidacion);
		}
		return Constantes.CONSTANTE_SUCCESS;
		
	}
	
	public Liquidacion llenarCamposPago(){
//		Liquidacion liquidacion = new Liquidacion();
		
		//Según alfons el proyecto nunca puede ser nulo...
		/**
		 *    Si LiqPag_Swift.proyecto is null and LiqPag.formpago = 'SWF',
		      LiqPag_Swift.proyecto := 'DERI'
		      LiqPag_Swift.codliqui := VistaLiquidacion.codliqui
		      LiqPag_Swift.fechatra := VistaLiquidacion.fechatra
		      LiqPag_Swift.fechaliq := LiqPag.fproxliq
		      LiqPag_Swift.fechaope := LiqPag.fechaoper
		      LiqPag_Swift.ncorrela := LiqPag.ncorrela
		      LiqPag_Swift.tipopera := VistaLiquidacion.tipopera
		      LiqPag_Swift.codivisa := VistaLiquidacion.divisali
		      LiqPag_Swift.usultact := usuario
		      LiqPag_Swift.feultact := SYSDATE
		
		   Fin Si

		 */
		
		
		return null;
	}
	
	/** habilita o deshabilita el panel de swift */
	public void marcaSwift(){
		
		if(Constantes.CANAL_SWIFT.equalsIgnoreCase(liquidacionesPantalla.getVistaLiqui().getCanaliqi()) ||
		   Constantes.CANAL_TARGET.equalsIgnoreCase(liquidacionesPantalla.getVistaLiqui().getCanaliqi()) ){
			this.setPanelSwiftRendered(true);
		} else {
			this.setPanelSwiftRendered(false);
		}
	
	}

	
	@Override
	protected void refreshListInternal() {

		setExportExcel(false);		
		// Limpiamos checkbox
//		if(!GenericUtils.isNullOrBlank(this.liquidacionesPantalla.getSelectedLiquiIds())){
//			this.liquidacionesPantalla.getSelectedLiquiIds().clear();
//		}
//		
//		if (!GenericUtils.isNullOrBlank(this.liquidacionesPantalla.getSelectedLiquiDataList())){
//			this.liquidacionesPantalla.getSelectedLiquiDataList().clear();
//			this.liquidacionesPantalla.setSelecTodos(false);			
//		}		

		// SMM Si se modifica alguna seleccion verificar que no haya que modificar tambien listaSeleccionarTodos
		
		if(this.liquidacionesPantalla.isVieneAgenda()){
			rellenarListaAgenda(paginationData,false);	
		} else {
			// SMM - cambio inc 655 		
			//Cuando llega aquí ya ha pasado el control de validarCasadasPantalla
			if (this.liquidacionesPantalla.getOpCasadasSelect()){
				rellenarListaCasadas(paginationData, false);				
			}else{
				//SMM: este if supuestamente no se ejecutará actualmente, ya que una vez que el usuario pulse buscar,
				//pierde el modo
				if (this.liquidacionesPantalla.isVieneOperaciones()){	//Supuestamente esto no se ejecutará actualmente			
					rellenarListaOperaciones(false, paginationData, false);	 //Select_datos_liquidaciones (criterioSeleccion)
				}else{				
					rellenarLista(paginationData,false);// Select_datos_liquidaciones (criterioSeleccion)
				}
			}
		}
	}


	public boolean validarCasadasPantalla(){
		LiquidacionesPantalla pantalla = this.liquidacionesPantalla;
		
		if (!GenericUtils.isNullOrBlank(pantalla.getNumOperDesde())
				&& !GenericUtils.isNullOrBlank(pantalla.getNumOperHasta())
				&& !GenericUtils.isNullOrBlank(pantalla.getFechaLiquidDesde())
				&& !GenericUtils.isNullOrBlank(pantalla.getFechaLiquidHasta())
			&& pantalla.getFechaLiquidDesde().compareTo(pantalla.getFechaLiquidHasta())==0)	{
			return true;
		}
		if (GenericUtils.isNullOrBlank(pantalla.getNumOperDesde())
				|| GenericUtils.isNullOrBlank(pantalla.getNumOperHasta())){
				if (GenericUtils.isNullOrBlank(pantalla.getFechaLiquidDesde())
					|| GenericUtils.isNullOrBlank(pantalla.getFechaLiquidHasta())){
					statusMessages.add(Severity.ERROR, "#{messages['liquidaciones.error.casadas.camposVacios']}");
					return false;
				}else{
					statusMessages.add(Severity.ERROR, "#{messages['liquidaciones.error.casadas.ncorrelaVacios']}");
					return false;
				}
		}
		if (GenericUtils.isNullOrBlank(pantalla.getFechaLiquidDesde())
				|| GenericUtils.isNullOrBlank(pantalla.getFechaLiquidHasta())){				
			statusMessages.add(Severity.ERROR, "#{messages['liquidaciones.error.casadas.fechaVacias']}");
			return false;
		}
		if (pantalla.getFechaLiquidDesde().compareTo(pantalla.getFechaLiquidHasta())!=0){
			statusMessages.add(Severity.ERROR, "#{messages['liquidaciones.error.casadas.fechasDiferentes']}");
			return false;			
		}
		return true;
	}
	
	/**
	 * Carga la lista de Liquidaciones cuando venimos de la pantalla de Agenda o de Lista Operaciones
	 */
	public void initListaResultados(){
		setExportExcel(false);
		
		//Precargar la lista con Parametros liquidación si es la primera vez q entra
		//Si parametrosOutAgenda es nulo es que entramos desde el menú
		if (isPrimerAcceso()){
			buildListasProductos();
			if (!GenericUtils.isNullOrBlank(parametrosOutAgenda)){
				if (!GenericUtils.isNullOrBlank(parametrosOutAgenda.getModo())
						&& parametrosOutAgenda.getModo().equals(Constantes.MODO_AGE)){
					liquidacionesPantalla.setVieneAgenda(true);
					rellenarListaAgenda(paginationData, false);				
				}else{
					if (!GenericUtils.isNullOrBlank(parametrosOutAgenda.getModo())
							&& parametrosOutAgenda.getModo().equals(Constantes.MODO_OPE)){						
						liquidacionesPantalla.setVieneOperaciones(true);						
						rellenarListaOperaciones(false, paginationData, false);
					}
				}
			}//SMM: si carga desde el menu inicializar el estado Liqui
			else{
				liquidacionesPantalla.setEstadoLiqSelect(liquidacionesBo.cargarEstadoLiquidacion(Constantes.TIPO_ESTADO_PV));
			}
		}	
	}
	
	public void rellenarListaAgenda(PaginationData paginationData, Boolean batch){
		List<VistaLiquidacion> listaVistaLiqui = liquidacionesPantalla.getListaVistaLiqui();	
		listaVistaLiqui = liquidacionesBo.obtenerDatosLiquidacionesAgenda(parametrosOutAgenda.getCodevent().shortValue(), 
				parametrosOutAgenda.getModeloPr(),parametrosOutAgenda.getProducto(), 
				parametrosOutAgenda.getNcorrelaIni(), parametrosOutAgenda.getNcorrelaFin(), 
				parametrosOutAgenda.getFechatraIni(), parametrosOutAgenda.getFechatraFin(), 
				parametrosOutAgenda.getEstadoEv(), batch, exportExcel, paginationData);	

		if (batch){
			procesoExcelBatch(listaVistaLiqui, "AGENDA");
		}

		liquidacionesPantalla.setListaVistaLiqui(listaVistaLiqui);		
	}
	
	public void rellenarListaOperaciones(boolean p_excel, PaginationData paginationData, Boolean batch){
		List<VistaLiquidacion> listaVistaLiqui = liquidacionesPantalla.getListaVistaLiqui();	
		listaVistaLiqui = liquidacionesBo.obtenerDatosLiquidaciones(null, null,
				parametrosOutAgenda.getNcorrelaIni(), null, null, null, null, null, 
				null, null, null, null, null, null, null, parametrosOutAgenda.getFechaOpe(),
				null, null, null, null, null, null, null,null,null,batch, p_excel, paginationData);	

		if (batch){
			//Ponemos Agenda porque los parametros son los mismos que en agenda.
			procesoExcelBatch(listaVistaLiqui, "OPERACIONES");
		}

		liquidacionesPantalla.setListaVistaLiqui(listaVistaLiqui);		
	}	
	
	public void rellenarLista(PaginationData paginationData, Boolean batch){		
		
		List<VistaLiquidacion> listaVistaLiqui = liquidacionesBo.obtenerDatosLiquidaciones(liquidacionesPantalla.getModeloProductoSelect(), liquidacionesPantalla.getProdCatalSelect(),
				liquidacionesPantalla.getNumOperDesde(), liquidacionesPantalla.getNumOperHasta(), liquidacionesPantalla.getDivPagoSelect(),
				liquidacionesPantalla.getProdOperSelect(), liquidacionesPantalla.getFechaLiquidDesde(), liquidacionesPantalla.getFechaLiquidHasta(), 
				liquidacionesPantalla.getDivCobroSelect(), liquidacionesPantalla.getContrapartidaSelect(), 
				liquidacionesPantalla.getNumEstructDesde(), liquidacionesPantalla.getNumEstructHasta(), liquidacionesPantalla.getEstadoLiqSelect(),				
				liquidacionesPantalla.getSitCorrespSelect(), liquidacionesPantalla.getOpCasadasSelect(), null, 
				liquidacionesPantalla.getGuidDesde(), liquidacionesPantalla.getGuidHasta(),
				liquidacionesPantalla.getClaveExternaDesde(), liquidacionesPantalla.getClaveExternaHasta(), liquidacionesPantalla.getImporteDesde() , liquidacionesPantalla.getImporteHasta(), 
				liquidacionesPantalla.getTipoContrapa(),liquidacionesPantalla.getSuReferencia(),liquidacionesPantalla.getIdConciliada(),batch, exportExcel , paginationData);			

		if (batch){
			procesoExcelBatch(listaVistaLiqui,"NORMAL");
//			Object obj1;
//			obj1 = liquidacionesPantalla.getNumOperDesde(); 
//			String l = "Long";
//			if (obj1 instanceof java.math.BigDecimal);
//			Long st =  (Long) obj1; 
//			l = "Long2";
		}
		
		if (liquidacionesPantalla.getListaVistaLiqui()!=null) {
			liquidacionesPantalla.getListaVistaLiqui().clear();
			liquidacionesPantalla.getListaVistaLiqui().addAll(listaVistaLiqui);
		}else{
			liquidacionesPantalla.setListaVistaLiqui(listaVistaLiqui);
		}
			
			
	}
	
	private void procesoExcelBatch(List<VistaLiquidacion> listaVistaLiqui,String caso) {
		String sqlTxt = null; String sustitucion = null; String sqlHeader = null;
				
		String caso2 = null;
		if ("OPERACIONES".equalsIgnoreCase(caso)){
			caso2 = "AGENDA";
		}else{
			caso2 = caso;
		}
		
		
		sqlHeader ="Prod.Op.;N;N.Oper/Estr;F.Liquid;Conc.;P/C;Importe;Div;Canal;Contrapartida;Estado;Sit.Corresp.;Proc.;Cl. Externa;Cl. GID;"+
		"NominaPa;NominaRe;EntiOper;OficinaBs;Fecha Conf;Dias Conf-Pago;Confirmada;Su Referencia;Conciliada;Grupo Contable";

		if (listaVistaLiqui!=null && listaVistaLiqui.size()>0){
			
			SQLQuery sql = listaVistaLiqui.get(0).getSqlQuery();
			sqlTxt = sql.getQueryString();
			for (String param : sql.getNamedParameters()) {
				sustitucion = obtenerSustitucion(param, caso2);
				param = ":".concat(param);
				
				sqlTxt =	sqlTxt.replaceAll(param , sustitucion);	
			}	
//			sql.getQueryString();
//			sql.getReturnAliases()
//			HashMap<K, V> parametros;
//			liquidacionesMsg = new HashMap<MensajesValidacionId, MensajesValidacion>();
		
			Long peticion = liquidacionesBo.generarPeticionExcel(sqlTxt,sqlHeader,caso);

			String mensaje = ResourceBundle.instance().getString("liquidaciones.registros.validadosBatch") + " " + peticion ;
			statusMessages.add(Severity.INFO, mensaje);

		}
	}


	private String obtenerSustitucion(String param, String caso) {
		
		
		SimpleDateFormat sdf = new SimpleDateFormat(Constantes.DDMMYYYY);
		SimpleDateFormat sdf2 = new SimpleDateFormat(Constantes.YYYYMMDD);
		
		
		if ("rownumMin".equalsIgnoreCase(param)){
			return paginationData.getPaginationDataForExcel().getFirstResult().toString();
		}else if ("rownumMax".equalsIgnoreCase(param)){
			return paginationData.getPaginationDataForExcel().getMaxResults().toString();
		}else if ("modelopr".equalsIgnoreCase(param)){
			if ("AGENDA".equals(caso)){
				return parametrosOutAgenda.getModeloPr()==null?"null":"'".concat(parametrosOutAgenda.getModeloPr().getModelpro()).concat("'");
			}
			return "'".concat(liquidacionesPantalla.getModeloProductoSelect().getModelpro()).concat("'");
		}else if ("producat".equalsIgnoreCase(param)){
			return liquidacionesPantalla.getProdCatalSelect().getProducat().toString();
		}else if ("situaliq".equalsIgnoreCase(param)){
			return "'".concat(liquidacionesPantalla.getSitCorrespSelect().getCodigo()).concat("'");
		}else if ("estadoco".equalsIgnoreCase(param)){
			return liquidacionesPantalla.getEstadoLiqSelect()==null?"null":"'".concat(liquidacionesPantalla.getEstadoLiqSelect().getCodigo()).concat("'");
		}else if ("producto".equalsIgnoreCase(param)){
			if ("AGENDA".equals(caso)){
				return parametrosOutAgenda.getProducto()==null?"null":"'".concat(parametrosOutAgenda.getProducto().getId()).concat("'");
			}
			return "'".concat(liquidacionesPantalla.getProdOperSelect().getId()).concat("'");
		}else if ("contrapa".equalsIgnoreCase(param)){
			return "'".concat(liquidacionesPantalla.getContrapartidaSelect()).concat("'");
		}else if ("divisapa".equalsIgnoreCase(param)){
			return "'".concat(liquidacionesPantalla.getDivPagoSelect().getId()).concat("'");
		}else if ("divisare".equalsIgnoreCase(param)){
			return "'".concat(liquidacionesPantalla.getDivCobroSelect().getId()).concat("'");
		}else if ("estructIni".equalsIgnoreCase(param)){
			return liquidacionesPantalla.getNumEstructDesde().toString();
		}else if ("estructFin".equalsIgnoreCase(param)){
			return  liquidacionesPantalla.getNumEstructHasta().toString();
		}else if ("ncorrelaIni".equalsIgnoreCase(param)){
			if ("AGENDA".equals(caso)){
				return (parametrosOutAgenda.getNcorrelaIni()==null?"null":parametrosOutAgenda.getNcorrelaIni().toString());
			}
			return (liquidacionesPantalla.getNumOperDesde()==null?"null":liquidacionesPantalla.getNumOperDesde().toString());
		}else if ("ncorrelaFin".equalsIgnoreCase(param)){
			if ("AGENDA".equals(caso)){
				return (parametrosOutAgenda.getNcorrelaFin()==null?"null":parametrosOutAgenda.getNcorrelaFin().toString());
			}
			return (liquidacionesPantalla.getNumOperHasta()==null?"null":liquidacionesPantalla.getNumOperHasta().toString()); 
		}else if ("claveBDUIni".equalsIgnoreCase(param)){
			return "'".concat(liquidacionesPantalla.getGuidDesde()).concat("'");
		}else if ("claveBDUFin".equalsIgnoreCase(param)){
			return "'".concat(liquidacionesPantalla.getGuidHasta()).concat("'");
		}else if ("claveExternaIni".equalsIgnoreCase(param)){
			return liquidacionesPantalla.getClaveExternaDesde().toString();
		}else if ("claveExternaFin".equalsIgnoreCase(param)){
			return liquidacionesPantalla.getClaveExternaHasta().toString();
		}else if ("fechaOpe".equalsIgnoreCase(param)){
			if ("AGENDA".equals(caso)){
				return	"'".concat(sdf.format(parametrosOutAgenda.getFechaOpe()).toString()).concat("'");
			}
			return "";
		}else if ("fechaLiqIni".equalsIgnoreCase(param)){
			return "'".concat(sdf.format(liquidacionesPantalla.getFechaLiquidDesde()).toString()).concat("'");
		}else if ("fechaLiqFin".equalsIgnoreCase(param)){
			return "'".concat(sdf.format(liquidacionesPantalla.getFechaLiquidHasta()).toString()).concat("'");
		}else if ("tipoContrapartida".equalsIgnoreCase(param)){
			return "'".concat(liquidacionesPantalla.getTipoContrapa().getId()).concat("'");
		}else if ("importeDesde".equalsIgnoreCase(param)){
			return liquidacionesPantalla.getImporteDesde().toString();
		}else if ("importeHasta".equalsIgnoreCase(param)){
			return liquidacionesPantalla.getImporteHasta().toString();
		}else if ("suReferencia".equalsIgnoreCase(param)){
			return "'".concat(liquidacionesPantalla.getSuReferencia()).concat("'");
		}else if ("idConciliada".equalsIgnoreCase(param)){
			return (liquidacionesPantalla.getIdConciliada()?"'S'":"null");
		}else if ("codEvent".equalsIgnoreCase(param)){
			return parametrosOutAgenda.getCodevent().toString(); 
//			return "1";
		}else if ("fechaMis".equalsIgnoreCase(param)){
			Date fechamis = liquidacionesBo.obtenerFechaSistema(); //Recuperamos la fecha del sistema
			return	"'".concat(sdf2.format(fechamis).toString()).concat("'");
		}else if ("fechaTraFin".equalsIgnoreCase(param)){
			return	"'".concat(sdf.format(parametrosOutAgenda.getFechatraFin()).toString()).concat("'");
		}else if ("fechaTraIni".equalsIgnoreCase(param)){
			return	"'".concat(sdf.format(parametrosOutAgenda.getFechatraIni()).toString()).concat("'");
		}else if ("estadoEv".equalsIgnoreCase(param)){
			return "'".concat(parametrosOutAgenda.getEstadoEv()).concat("'");
		}else if ("estadoConfirmacion".equalsIgnoreCase(param)){
			return "1";
		}else{
			return "1";		
		}
//		return null;
	}


	/**
	 * Recupera la lista de liquidaciones Casadas y calcula su importe
	 * @param paginationData
	 */
	public void rellenarListaCasadas(PaginationData paginationData, Boolean batch){	
		LiquidacionesPantalla pantalla = this.liquidacionesPantalla;
		
		
		List<VistaLiquidacion> listaVistaLiqui = liquidacionesBo.obtenerLiquidacionesCasadas(pantalla.getFechaLiquidDesde(), pantalla.getFechaLiquidHasta(), pantalla.getNumOperDesde(), pantalla.getEstadoLiqSelect(),batch, exportExcel, paginationData);					

		if (batch){
			procesoExcelBatch(listaVistaLiqui, "CASADAS");
		}

		liquidacionesPantalla.setListaVistaLiqui(listaVistaLiqui);
		liquidacionesPantalla.setTotalImportes(liquidacionesBo.calcularImporteCasadas(pantalla.getFechaLiquidDesde(), pantalla.getFechaLiquidHasta(), pantalla.getNumOperDesde()));
	}
	
	@Override
	public void refrescarListaExcel() {		
		setExportExcel(true);
				
		if(this.liquidacionesPantalla.isVieneAgenda()){
			rellenarListaAgenda(paginationData.getPaginationDataForExcel(),false);			
		} else if (this.liquidacionesPantalla.getOpCasadasSelect()){
				rellenarListaCasadas(paginationData.getPaginationDataForExcel(), false);				
				}else{
				if (this.liquidacionesPantalla.isVieneOperaciones()){
					rellenarListaOperaciones(true, paginationData.getPaginationDataForExcel(), false);
				}else{
					rellenarLista(paginationData.getPaginationDataForExcel(),false);
				}
		}
		
	}

	public void excelBatch() {		
		setExportExcel(true);
		
		if(this.liquidacionesPantalla.isVieneAgenda()){
			rellenarListaAgenda(paginationData.getPaginationDataForExcel(),true);			
		} else if (this.liquidacionesPantalla.getOpCasadasSelect()){
				rellenarListaCasadas(paginationData.getPaginationDataForExcel(), true);				
				}else{
				if (this.liquidacionesPantalla.isVieneOperaciones()){
					rellenarListaOperaciones(true, paginationData.getPaginationDataForExcel(), true);
				}else{
					rellenarLista(paginationData.getPaginationDataForExcel(), true);
				}
		}
	}

	
	@SuppressWarnings("unchecked")
	@Override
	public void setDataTableList(List<?> dataTableList) {
		liquidacionesPantalla.setListaVistaLiqui((List<VistaLiquidacion>) dataTableList);
	}
	
	
	public boolean buscarValidator(){
		if (!GenericUtils.isNullOrBlank(liquidacionesPantalla.getFechaLiquidDesde()) && 
				!GenericUtils.isNullOrBlank(liquidacionesPantalla.getFechaLiquidHasta()) &&
				liquidacionesPantalla.getFechaLiquidDesde().after(liquidacionesPantalla.getFechaLiquidHasta())){
			statusMessages.add(Severity.ERROR, "#{messages['liquidaciones.error.fechaIniSuperior']}");
			return false;
		}
		if (!GenericUtils.isNullOrBlank(liquidacionesPantalla.getNumOperDesde()) && 
				!GenericUtils.isNullOrBlank(liquidacionesPantalla.getNumOperHasta()) &&
				liquidacionesPantalla.getNumOperDesde()>liquidacionesPantalla.getNumOperHasta()){
			statusMessages.add(Severity.ERROR, "#{messages['liquidaciones.error.ncorrelaIniSuperior']}");
			return false;
		}
		if (!GenericUtils.isNullOrBlank(liquidacionesPantalla.getNumEstructDesde()) && 
				!GenericUtils.isNullOrBlank(liquidacionesPantalla.getNumEstructHasta()) &&
				liquidacionesPantalla.getNumEstructDesde()>liquidacionesPantalla.getNumEstructHasta()){
			statusMessages.add(Severity.ERROR, "#{messages['liquidaciones.error.estruturaIniSuperior']}");
			return false;
		}
		if (liquidacionesPantalla.getOpCasadasSelect()){
			return validarCasadasPantalla();
		}
		return true;
	}

	public void buscar(){		
		ultimRegistre = 0;
		paginationData.reset();
		this.liquidacionesPantalla.getSelectedLiquiDataList().clear();
		this.liquidacionesPantalla.setSelecTodos(false);
		liquidacionesPantalla.setVieneAgenda(false);
		liquidacionesPantalla.setVieneOperaciones(false);
		liquidacionesPantalla.setTotalImportes(null);
		setPrimerAcceso(false);	
		refrescarLista();	
	}
	
	public void buildListasProductos(){		
		ModeloProducto modeloProducto = liquidacionesPantalla.getModeloProductoSelect();
		liquidacionesPantalla.setListaProdCatal(liquidacionesBo.obtenerProductoCatalogo(modeloProducto));
		liquidacionesPantalla.setListaProd(liquidacionesBo.obtenerProducto(modeloProducto));
	}

// ### FUNCIONES PARA GESTIONAR LOS CHECKBOX ###
	
	/**
	 * Cada vez que se selecciona/deselecciona una liquidaciones se actualiza la lista
	 * de las seleccionadas y se comprueba si están habilitados los botones validar y anular
	 */
	public void seleccionarLiquidaciones() {
//		this.getLiquidacionesSeleccionadas();		
	}
	
	/**
	 * Recorre la lista de liquidaciones y carga los elementos seleccionados OBSOLETA 1931

	public void getLiquidacionesSeleccionadas() {
		
		//Contiene todas las liquidaciones visibles
		List<VistaLiquidacion> liquidacionesList = liquidacionesPantalla.getListaVistaLiqui();
		
		VistaLiquidacion dataItem = null;
		
		int tamanyoLista = liquidacionesList.size();
		
		if (tamanyoLista > paginationData.getMaxResults()){ //Cuando hay paginación el último registro no se debe tener en cuenta
			tamanyoLista--;
		}
		
		//Recorremos toda la lista de liquidaciones, verificando cual está y no seleccionada
		//para asignarla a SelectedLiquiDataList
		for (int i = 0; i < tamanyoLista; i++){
			dataItem = liquidacionesList.get(i);
			
			if (!GenericUtils.isNullOrBlank(liquidacionesPantalla.getSelectedLiquiIds().get(dataItem.getId()))){
	            	
	        	if (liquidacionesPantalla.getSelectedLiquiIds().get(dataItem.getId()).booleanValue() 
	           			&& !liquidacionesPantalla.getSelectedLiquiDataList().contains(dataItem)) {
	           		
	           		liquidacionesPantalla.getSelectedLiquiDataList().add(dataItem);
	           		
//	           		if(liquidacionesPantalla.getSelectedLiquiDataList().size() == tamanyoLista){
//	           			liquidacionesPantalla.setSelecTodos(true);
//	           		}	           	
	           	}else if (!liquidacionesPantalla.getSelectedLiquiIds().get(dataItem.getId()).booleanValue() 
            			&& liquidacionesPantalla.getSelectedLiquiDataList().contains(dataItem)){
            		liquidacionesPantalla.getSelectedLiquiDataList().remove(dataItem);
            		liquidacionesPantalla.getSelectedLiquiIds().remove(dataItem.getId());
            		liquidacionesPantalla.setSelecTodos(false);
            	}
            }
			dataItem = null;
		}
    }
	 */	

	public Boolean getSelectedRow(){
		return this.liquidacionesPantalla.getSelectedLiquiDataList().contains(this.liquidacionesPantalla.getVistaLiquiSelect());
	}

	public void setSelectedRow(Boolean selected){
		if(selected){
			this.liquidacionesPantalla.getSelectedLiquiDataList().add(this.liquidacionesPantalla.getVistaLiquiSelect());
		}
		else{
			this.liquidacionesPantalla.getSelectedLiquiDataList().remove(this.liquidacionesPantalla.getVistaLiquiSelect());
			this.liquidacionesPantalla.setSelecTodos(false);
		}
	}
	
	
	
	/** Seleccionar o deseleccionar todos los checks del datagrid */
	public void seleccionarTodos(){
		
//		VistaLiquidacion vistaLiqui;
//
//		List<VistaLiquidacion> liquidacionesList = liquidacionesPantalla.getListaVistaLiqui();
//		int tamanyoLista = liquidacionesList.size();
//		
//		if (tamanyoLista > paginationData.getMaxResults()){ //Cuando hay paginación el último registro no se debe tener en cuenta
//			tamanyoLista--;
//		}
		
		//Lo primero es saber si tenemos que seleccionar o deseleccionar todos. 
		//1- Caso deseleccionar
		if(liquidacionesPantalla.getSelecTodos()){

			if(!GenericUtils.isNullOrBlank(this.liquidacionesPantalla.getSelectedLiquiDataList())){
				this.liquidacionesPantalla.getSelectedLiquiDataList().clear();
			}
			
//			if( liquidacionesPantalla.getSelectedLiquiIds()!=null ){
//				this.liquidacionesPantalla.getSelectedLiquiIds().clear();
//			}

//			for (int k = 0; k < tamanyoLista; k++ ){
//				vistaLiqui = liquidacionesList.get(k);
//				if(!GenericUtils.isNullOrBlank(liquidacionesPantalla.getSelectedLiquiIds()) && liquidacionesPantalla.getSelectedLiquiIds().get(vistaLiqui.getId())){
//					this.liquidacionesPantalla.getSelectedLiquiIds().remove(vistaLiqui.getId());
//				}
//			}
			
			this.liquidacionesPantalla.setSelecTodos(false);
						
		} else { //Caso seleccionar
			
			Integer minResul = paginationData.getFirstResult();
			Integer maxResul = paginationData.getMaxResults(); 
			int tamanyoLista = 0;
			VistaLiquidacion vistaLiqui;
			
			paginationData.setFirstResult(0);
			paginationData.setMaxResults(Constantes.MAX_RESULTS_SELECCION_TOTAL_2000);
			
			listaTemp = listaSeleccionarTodos();

			paginationData.setMaxResults(maxResul);
			paginationData.setFirstResult(minResul);
			
			if(!GenericUtils.isNullOrBlank(listaTemp)){
//				tamanyoLista = listaTemp.size();
//			
//			
//			for (int k = 0; k < tamanyoLista; k++ ){
//				vistaLiqui = listaTemp.get(k);
//				if(!GenericUtils.isNullOrBlank(this.liquidacionesPantalla.getSelectedLiquiIds()) && (GenericUtils.isNullOrBlank(liquidacionesPantalla.getSelectedLiquiIds().get(vistaLiqui.getId())) || !liquidacionesPantalla.getSelectedLiquiIds().get(vistaLiqui.getId()))){
//					this.liquidacionesPantalla.getSelectedLiquiIds().put(vistaLiqui.getId(), true);
//				}
//			}
				this.liquidacionesPantalla.getSelectedLiquiDataList().addAll(listaTemp);
			}
			this.liquidacionesPantalla.setSelecTodos(true);
		}
		
		//Guardamos en memoria las campañas seleccionadas
//		if(!GenericUtils.isNullOrBlank(this.liquidacionesPantalla.getSelectedLiquiDataList())){
//			this.liquidacionesPantalla.getSelectedLiquiDataList().clear();
//		}
//		
//		getLiquidacionesSeleccionadas();
//		
	}	
	// ### FIN CHECKBOX ###
	
	/**
	 * Recoge la lista de liquidaciones seleccionadas y las bloquea para que nadie más pueda
	 * editarlas. Si alguna ya está bloqueada, se muestra un mensaje al usuario indicándole los
	 * motivos por los que no puede validarla
	 */
	public void preValidar (){
		
		boolean hayBloqueadas = false;
		liquidacionesBloqueadas = new ArrayList<VistaLiquidacion>();
		
		//recorremos la lista de liquidaciones seleccionadas
		for (VistaLiquidacion vistaLiquidacion : liquidacionesPantalla.getSelectedLiquiDataList()) {
			//bloqueamos los registros marcados que tengan estado pendiente de validar
			if (Constantes.LIQUIDACION_PDTE_VALIDAR.equals(vistaLiquidacion.getEstado())){
				if (bloquearLiquidacion(vistaLiquidacion, Constantes.LIQUIDACION_ACCION_VALIDAR)){
					liquidacionesBloqueadas.add(vistaLiquidacion);
				} else {
					hayBloqueadas = true;
				}
			}
		}
		
		/* Si no había registros bloqueados, mostramos mensaje de confirmación al usuario para que decida
		 * si quiere continuar con la validacion. Si dice que no, o había registros bloqueados, se llama
		 * a salirSinValidar para finalizar la ejecución y desbloquear todos los registros previamente bloqueados
		 */
		if (!hayBloqueadas){
			msgBoxAction.mostrarMsg("#{liquidacionesAction.validarFase1}", "#{liquidacionesAction.salirSinValidar}", ResourceBundle.instance().getString("liquidaciones.confirmar.validar"));
		} else {
			salirSinValidar();
		}
	}
	

	public void preValidarBatch (){
			msgBoxAction.mostrarMsg("#{liquidacionesAction.validarBatch}", "#{liquidacionesAction.salirSinValidar}", ResourceBundle.instance().getString("liquidaciones.confirmar.validar"));
	}


	public void validarBatch (){
		Long peticion= liquidacionesBo.tratamientoValidarBatch(liquidacionesPantalla.getSelectedLiquiDataList());
		//Mostramos mensaje con el número de registros actualizados
		this.liquidacionesPantalla.getSelectedLiquiDataList().clear();
		String mensaje = ResourceBundle.instance().getString("liquidaciones.registros.validadosBatch") + " " + peticion ;
		statusMessages.add(Severity.INFO, mensaje);
	}

	
	
	/**
	 * Necesario para salir sin validar cuando el usuario cancela el proceso desde un messageBox de decisión
	 * Desbloquea todos los registros previamente bloqueados
	 */
	public void salirSinValidar(){
		
		if (this.getLiquidacionesBloqueadas()!=null){
			for (VistaLiquidacion vistaLiquidacion : this.getLiquidacionesBloqueadas()) {
				dbLockService.desbloqueo(Liquidacion.class, vistaLiquidacion.getId());
			}
		}
		
		if(listaConfirmacionesRendered){
			setListaConfirmacionesRendered(false);
		}
		
		if (liquidacionesPantalla.getLiquidacionesMsg()!=null) {
			liquidacionesPantalla.getLiquidacionesMsg().clear();
		}
	}
	
	/**
	 * Realiza la validación de una liquidación, es decir, pone su estado a 'Validado'
	 * hace una primera pasada, comprobando si hay algún mensaje de decisión que mostrar
	 * al usuario. Si no lo hay, procede a la validación invocando a validarFase2. Si hay
	 * mensajes, redirige a una pantalla donde se muestran al usuario dichos mensajes para
	 * que tome una decisión por cada uno de ellos.
	 */
	public void validarFase1(){
		
		/* Instanciamos un nuevo hashmap donde guardaremos la información sobre los mensajes a mostrar para
		 * cada liquidación, así como la decisión adoptada por el usuario
		 * (al principio por defecto marcamos todas como NO)
		 */
		liquidacionesMsg = new HashMap<MensajesValidacionId, MensajesValidacion>();
		liquidacionesPantalla.setErrores(new ArrayList<String>());
		liquidacionesPantalla.setLiquidacionesMsg(liquidacionesMsg);
		
		/*
		 * Hacemos una primera pasada por los métodos de validar sin ejecutar ninguna transacción
		 * en la base de datos. Lo que hacemos es para cada liquidación, hacer todas las comprobaciones
		 * e ir almacenando todos los mensajes de decisión que se deban mostrar al usuario, sin hacer
		 * ningún cambio ni en las variables locales ni en base de datos.
		 */
		liquidacionesBo.tratamientoValidar(this.getLiquidacionesBloqueadas(), liquidacionesMsg, true, null);
		
		/* Si no tenemos ningún mensaje que mostrar ejecutamos una segunda pasada a los métodos de validar
		 * pero esta vez llevamos a cabo las modificaciones que sean necesarias tanto sobre las variables
		 * locales como en base de datos */
		if (liquidacionesMsg.isEmpty()) {
			ArrayList<String> errores = new ArrayList<String>();
			if (liquidacionesPantalla.getErrores()!=null) errores.addAll(liquidacionesPantalla.getErrores());
			int valid = 0;
			listaConfirmacionesRendered = false;
			valid = liquidacionesBo.tratamientoValidar(this.getLiquidacionesBloqueadas(), liquidacionesMsg, false, errores);
			liquidacionesPantalla.setRegistrosValidados(valid);
			liquidacionesPantalla.setErrores(errores);
			validarFase2();
		} else {
			/*
			 * Mostraremos al usuario una pantalla donde se listen para cada liquidación todas las decisiones
			 * que debe tomar. Con las decisiones que tome modificaremos los elementos del HashMap como
			 * sea necesario. Habrá un botón aceptar que al ser pulsado llamará a validarFase2 y a partir de
			 * ahí se trabajará como en el caso de que no hubiera mensajes que mostrar
			 */
			liquidacionesPantalla.setRegistrosValidados(0);
			listaConfirmacionesRendered = true;
		}
		
/*		
		 * Retornamos success si no hay mensajes a mostrar, para que después de validar se quede en
		 * la misma pantalla. Retornamos failure si hay algún mensaje a mostrar, para que vaya a la
		 * pantalla donde el usuario verá todos los mensajes de decisión que debe responder
*/
	}

	public void validarFaseErrores(){

		boolean hayMensajes = false;
		ArrayList<String> errores = new ArrayList<String>();
		int validados = liquidacionesPantalla.getRegistrosValidados();
		
		validados = validados + liquidacionesBo.tratamientoValidar(this.getLiquidacionesBloqueadas(),
				liquidacionesPantalla.getLiquidacionesMsg(),
				false,
				errores);	
		liquidacionesPantalla.setRegistrosValidados(validados);
		liquidacionesPantalla.getErrores().addAll(errores);

		for (Entry<MensajesValidacionId, MensajesValidacion> entry : liquidacionesMsg.entrySet()) {
			if (!entry.getValue().isHaSidoRespondido() &&  
				!Constantes.LIQUIDACION_VALIDADA.equals(entry.getKey().getLiquidacion().getEstado())) {
				
				hayMensajes= true;
			}
			
		}
//		for (Map.Entry mensaje : liquidacionesMsg.entrySet()) {
//			
//		}

		if (!hayMensajes) {
			listaConfirmacionesRendered = false;
			validarFase2();
		} else {
			listaConfirmacionesRendered = true;
		}		
		
	}
	
	/**
	 * Ejecuta la segunda fase de la validación, una vez el usuario ha respondido a todos los
	 * posibles mensajes de decisión	
	 */
	public void validarFase2(){
		ArrayList<String> errores = new ArrayList<String>();
		
		if (liquidacionesPantalla.getErrores()!=null) errores.addAll(liquidacionesPantalla.getErrores());
		
		int validados = liquidacionesPantalla.getRegistrosValidados();
		if (listaConfirmacionesRendered){ //cerramos el popup con la lista de confirmaciones
			setListaConfirmacionesRendered(false);
		}
		
		/* Recogemos el hashmap que tendrá los valores SI/NO escogidos por el usuario para cada mensaje
		 * de decisión y ejecutamos la lógica de validación completa, realizando las modificaciones en
		 * variables y en bbdd que se necesiten
		 */
		
//		int registrosValidados = liquidacionesBo.tratamientoValidar(this.getLiquidacionesBloqueadas(),
//							liquidacionesPantalla.getLiquidacionesMsg(),
//							false,
//							errores);
			  
		//Si se produjeron errores
		if (!GenericUtils.isNullOrBlank(errores) && !errores.isEmpty()){
			//Mostramos en el messagepanel todos los errores que se hayan producido
			
			List<String> duplicados = new ArrayList<String>();
			for (String error : errores) {
				if (!duplicados.contains(error)){
					duplicados.add(error);
					statusMessages.add(Severity.ERROR, error);
				}
		}
	}
	
		//Al terminar desbloqueamos todos los registros y desmarcamos los check
		for (VistaLiquidacion vistaLiquidacion : this.getLiquidacionesBloqueadas()) {
			dbLockService.desbloqueo(Liquidacion.class, vistaLiquidacion.getId());
			liquidacionesPantalla.getSelectedLiquiDataList().remove(vistaLiquidacion);
//			liquidacionesPantalla.getSelectedLiquiIds().remove(vistaLiquidacion.getId());
		}

		//Mostramos mensaje con el número de registros actualizados
		String mensaje = validados + " " + ResourceBundle.instance().getString("liquidaciones.registros.validados");
		statusMessages.add(Severity.INFO, mensaje);
		refrescarLista();
				
	}
			
	
	/**
	 * Realiza la desvalidación de una liquidación, es decir, pone su estado a 'Desvalidado'
	 * 
	 */
	public void desValidar(){
//		List<VistaLiquidacion> listaLiquidaciones =		liquidacionesPantalla.getSelectedLiquiDataList();
		int contadorValidadas = 0;
		for (VistaLiquidacion vistaLiq : liquidacionesPantalla.getSelectedLiquiDataList()) {
		
			if (Constantes.LIQUIDACION_VALIDADA.equals(vistaLiq.getEstado()) && vistaLiq.getLiqOriginal()==null) {

				if (this.bloquearLiquidacion(vistaLiq, "desvalidar")) {

					Liquidacion liquidacion = liquidacionesBo.cargar(vistaLiq.getId());
					
					if (comprobarDesvalidacion(liquidacion)){
						statusMessages.addFromResourceBundle(Severity.WARN,"liquidaciones.warning.desvalidar", vistaLiq.getnCorrelaEstructura(),liquidacion.getId().getCodliqui());
					}
					
					
						vistaLiq.setEstado(Constantes.LIQUIDACION_PDTE_VALIDAR);
						try {
							vistaLiq.setEstado(Constantes.LIQUIDACION_VALIDADA);
							liquidacionesBo.desvalidarLiquidacion(liquidacion);
	//						liquidacionesPantalla.getSelectedLiquiDataList().remove(vistaLiq);
							liquidacionesBo.flush();
							liquidacionesBo.cargar(liquidacion.getId());
							contadorValidadas++;
						} catch (RollbackException r) {
							statusMessages.add(Severity.ERROR, "#{messages['liquidaciones.error.rollback']}");
							throw new RollbackException();
						} finally {
							dbLockService.desbloqueo(Liquidacion.class, vistaLiq.getId());
						}
					
					
				}
			}
		}
		liquidacionesPantalla.getSelectedLiquiDataList().clear();
		statusMessages.addFromResourceBundle(Severity.INFO, "liquidaciones.info.desvalidadas", contadorValidadas);
		refrescarLista();
	}


	private Boolean comprobarDesvalidacion(Liquidacion liquidacion) {
		//Avisos DESVALIDAR
		//liquidaciones.warning.desvalidar
		
		Date fechamis=null ;
		
		//SMM 18/03/2016
		if (Constantes.LIQ_ENVIADA.equalsIgnoreCase(liquidacion.getSitualiq())){
			return true;
		}

		if (liquidacionesBo.esProductoRAD(liquidacion.getProducto())){ 

			if (Constantes.CANAL_SWIFT.equalsIgnoreCase(liquidacion.getCanaliqi())){
				
				fechamis = liquidacionesBo.obtenerFechaSistema(); //Recuperamos la fecha del sistema
				if (fechamis.after(liquidacion.getSwift().getFechaenv())){
					return true;
				}
				
			}
			
		}else{
/**
 * 							CTA P/C	D-1 (FECHALIQ-1)	Fecha Liquidación = Fecha dia
 *  						TAR Pago	D-1 (FECHALIQ-1)	Fecha Liquidación = Fecha dia
 *  						TAR Cobro	D (FECHALIQ)	No corresponde
 *  						SW  P/C	FECHAENV (SWMT0202)	Fecha día > FECHAENV
 */
			if (Constantes.CANAL_CLIENTE.equalsIgnoreCase(liquidacion.getCanaliqi())){
				fechamis = liquidacionesBo.obtenerFechaSistema(); //Recuperamos la fecha del sistema	
				if (liquidacion.getFechaliq().equals(fechamis)){
					return true;
				}
			}else if (Constantes.CANAL_TARGET.equalsIgnoreCase(liquidacion.getCanaliqi())){
				if (Constantes.LIQUIDACION_TIPOPERA_P.equalsIgnoreCase(liquidacion.getTipopera())){
					fechamis = liquidacionesBo.obtenerFechaSistema(); //Recuperamos la fecha del sistema	
					if (liquidacion.getFechaliq().equals(fechamis)){
						return true;
					}
				}
			}else if (Constantes.CANAL_SWIFT.equalsIgnoreCase(liquidacion.getCanaliqi())){
				fechamis = liquidacionesBo.obtenerFechaSistema(); //Recuperamos la fecha del sistema
				if (fechamis.after(liquidacion.getSwift().getFechaenv())){
					return true;
				}
			}
		
		}
		
		return false;
	}
	
	/**
	 * Método que se ejecuta cada vez que se entra en la página
	 */
	public void mostrarListado(){
		
	}
	
	/**
	 * Prepara para la edición de una liquidación
	 */
	public String editar(){
		
		liquidacionesPantalla.copiarSeleccionado();
		recuperarDatosLiquidacion();
		
		if(Constantes.CANAL_SWIFT.equalsIgnoreCase(liquidacionesPantalla.getVistaLiqui().getCanaliqi()) ||
		   Constantes.CANAL_TARGET.equalsIgnoreCase(liquidacionesPantalla.getVistaLiqui().getCanaliqi()) ){
			this.setPanelSwiftRendered(true);
		} else {
			this.setPanelSwiftRendered(false);
		}
		
		setModoPantalla(ModoPantalla.EDICION);
		generarCabecera();
		
		return liquidacionesPantalla.getVistaLiqui().getDescrTipOpera();
	
	}

	/** Construye la cadena de texto a mostrar en la cabecera */
	private void generarCabecera() {
		if("R".equalsIgnoreCase(liquidacionesPantalla.getVistaLiqui().getTipopera())){ //Si es recibo
			StringBuffer titulo = new StringBuffer();
			titulo.append(ResourceBundle.instance().getString("liquidaciones.detalle.recibo.titulo"));
			titulo.append(" ");
			titulo.append(liquidacionesPantalla.getVistaLiqui().getConcepto());
			liquidacionesPantalla.setCabecera(titulo.toString());
		}
	}

	/**
	 * Validaciones previas a la edición de la liquidación recibo.
	 * Los Campos de la cesión pueden estar todos vacios. Pero si hay algún campo informado, entonces
	 * los campos ENTIDDES, OFICIDES, DEPARDES, TIPOFICH, DIVISACE, OFIEMISOM, CODESTAD, CODIPAIS, 
	 * NIFTITUL son obligatorios
	 */
	public boolean guardarLiquidacionReciboValidator(){
		
		boolean esCorrecto = true;
		
		VistaLiquidacion vistaLiquidacion = liquidacionesPantalla.getVistaLiqui();
		//Date fechamis = liquidacionesBo.obtenerFechaSistema(); //Recuperamos la fecha del sistema
		
		esCorrecto = validaCuenta(vistaLiquidacion);
		
//		if (vistaLiquidacion.getImportel().compareTo(BigDecimal.ZERO) < 0 ){
//			statusMessages.add(Severity.ERROR, "#{messages['liquidaciones.error.importeNegativo']}");
//			esCorrecto = false;	
//		}
		
		if ("SWF".equalsIgnoreCase(vistaLiquidacion.getCanaliqi())
				&& !GenericUtils.isNullOrBlank(vistaLiquidacion.getSwift().getFechaenv())){

			SimpleDateFormat sdf = new SimpleDateFormat(Constantes.DDMMYYYY);
			Date sysdate;
			Date fechaEnvio;
			
			try {
				sysdate = sdf.parse(sdf.format(new Date()));
				fechaEnvio = sdf.parse(sdf.format(vistaLiquidacion.getSwift().getFechaenv()));
			} catch (ParseException e) {
				sysdate = new Date();
				fechaEnvio = vistaLiquidacion.getSwift().getFechaenv();
			}
			
			if(fechaEnvio.compareTo(sysdate) < 0){
				esCorrecto = false;
				statusMessages.addToControl("fechaEnvTxt", Severity.ERROR, "#{messages['liquidaciones.error.fenv.incorrecta']}");
			}
			
		} else if ("50".equals(vistaLiquidacion.getGruconta()) &&  vistaLiquidacion.getOficonta() == 901 ){
			esCorrecto = false;
			statusMessages.addToControl("grupConCmb", Severity.ERROR, "#{messages['liquidaciones.error.grupcon.oficonta']}");
		
		} //else if (((vistaLiquidacion.getFechaliq().getTime() - fechamis.getTime())/86400000L) < 0){
		//	esCorrecto = false;
		//	statusMessages.addToControlFromResourceBundle("fLiquiTxt", Severity.ERROR, "liquidaciones.error.fliq.incorrecta", fechamis);
		//}
			
		if(!GenericUtils.isNullOrBlank(vistaLiquidacion.getCesion()) && !GenericUtils.isNullOrBlank(vistaLiquidacion.getCesion().getEntiddes())){
			if (!liquidacionesBo.comprobarEntidad(vistaLiquidacion.getCesion().getEntiddes())){
				statusMessages.addToControlFromResourceBundle("txtentidadRb", Severity.ERROR, "liquidaciones.error.entidad", vistaLiquidacion.getCesion().getEntiddes());
				esCorrecto = false;
			}
		}

			
		return esCorrecto;
	}


	private boolean validaCuenta(VistaLiquidacion vistaLiquidacion) {
		boolean esCorrecto = true; 
		/* Los campos de la cuenta o están informados todos  o ninguno. */
		boolean ofiContaInformado = !GenericUtils.isNullOrBlank(vistaLiquidacion.getOficonta());
		boolean ctaContaInformado = !GenericUtils.isNullOrBlank(vistaLiquidacion.getCtaconta());
		boolean chkContaInformado = !GenericUtils.isNullOrBlank(vistaLiquidacion.getChkconta());
		boolean gruContaInformado = !GenericUtils.isNullOrBlank(vistaLiquidacion.getGruconta());
		
		boolean algunoInformado = ofiContaInformado || ctaContaInformado || chkContaInformado || gruContaInformado;
		boolean todosInformados = ofiContaInformado && ctaContaInformado && chkContaInformado && gruContaInformado;
		
		if (algunoInformado && !todosInformados){
			esCorrecto = false;
			statusMessages.add(Severity.ERROR, "#{messages['liquidaciones.error.cuenta.noinformados']}");
			return esCorrecto;
		}
		
		if (!liquidacionesBo.validaCuenta(vistaLiquidacion)){
			esCorrecto = false;
			statusMessages.add(Severity.ERROR, "#{messages['liquidaciones.error.cuenta.noparametrizada']}");
		}
		return esCorrecto;
	}
	
	/**
	 * Guarda el objeto liquidación con los cambios introducidos por el usuario en bbdd
	 */
	public String guardarLiquidacionRecibo(){
		
		VistaLiquidacion liqui = liquidacionesPantalla.getVistaLiqui();

		//SMM 20/10/2015
		if ("88".equalsIgnoreCase(liqui.getGruconta())){
			liqui.setSitualiq(SITUALIQ_PDR);	
		}else{
			liqui.setSitualiq(SITUALIQ_PDE);
		}
		
		liquidacionesBo.actualizarLiquidacion(liqui);
		liquidacionesBo.actualizarCesion(liquidacionesPantalla.getVistaLiqui());
		
		if ("SWF".equals(liqui.getCanaliqi())){
			Date fechaEnvio = liqui.getSwift().getFechaenv();
			Date fechaEnvioOriginal = liquidacionesBo.obtenerFechaEnvSwift(liqui.getId());
			
			//Si se ha cambiado la fecha de envío se actualiza el swift en bbdd
			if (!GenericUtils.isNullOrBlank(fechaEnvioOriginal) && !GenericUtils.isNullOrBlank(fechaEnvio)){
				
				long diffFechas = (fechaEnvio.getTime() - fechaEnvioOriginal.getTime())/86400000L;
				
				if (diffFechas != 0){
			liquidacionesBo.actualizarSwift(fechaEnvio, liqui);
		}
			}
		}
		
		return Constantes.CONSTANTE_SUCCESS;
	}
	
	/**
	 * 
	 * @return
	 */
	public String ver(){
		
		liquidacionesPantalla.copiarSeleccionado();
		recuperarDatosLiquidacion();
		generarCabecera();
		setModoPantalla(ModoPantalla.INSPECCION);
		
		if(Constantes.CANAL_SWIFT.equalsIgnoreCase(liquidacionesPantalla.getVistaLiqui().getCanaliqi()) ||
		   Constantes.CANAL_TARGET.equalsIgnoreCase(liquidacionesPantalla.getVistaLiqui().getCanaliqi()) ){
			this.setPanelSwiftRendered(true);
		} else {
			this.setPanelSwiftRendered(false);
		}
		
		return liquidacionesPantalla.getVistaLiqui().getDescrTipOpera();
		
	}

	public void descartar(){		
//		List<VistaLiquidacion> vistaLiquiList = liquidacionesPantalla.getSelectedLiquiDataList();
		Boolean estadoIncorrecto = false;
		if (!GenericUtils.isNullOrBlank(liquidacionesPantalla.getSelectedLiquiDataList()) && liquidacionesPantalla.getSelectedLiquiDataList().size()>0){
			for (VistaLiquidacion vl : liquidacionesPantalla.getSelectedLiquiDataList()){
				if (vl.getEstado().equals(Constantes.LIQUIDACION_PDTE_VALIDAR)||
						(vl.getEstado().equals(Constantes.LIQUIDACION_VALIDADA) && vl.getLiqOriginal()==null)){
					if (!bloquearLiquidacion(vl, Constantes.LIQUIDACION_ACCION_DESCARTAR)){
						return;
					}else{
						liquidacionesBo.descartar(vl);
						dbLockService.desbloqueo(Liquidacion.class, vl.getId());
					}
				}else{
						estadoIncorrecto = true;
				}
			}
		}
		if (estadoIncorrecto){
			statusMessages.addFromResourceBundle(Severity.WARN,"liquidacion.descartar.aviso");	
		}
		liquidacionesPantalla.getSelectedLiquiDataList().clear();
		refrescarLista();
//		recargarLista();
//		rellenarLista(paginationData);
	}
	
	public boolean bloquearLiquidacion(VistaLiquidacion vistaLiquidacion, String accion){
		
		String tipoOpera = null;
		if (vistaLiquidacion.getDescrTipOpera().equals(Constantes.LIQUIDACION_TIPOPERA_P)){
			tipoOpera = Constantes.LIQUIDACION_TIPOPERA_PAGO;
		}else{
			tipoOpera = Constantes.LIQUIDACION_TIPOPERA_COBRO;
		}
		//si devuelve false es que el registro ya está bloqueado
		if (!dbLockService.bloqueo(Liquidacion.class, vistaLiquidacion.getId())){					
			statusMessages.addFromResourceBundle(Severity.ERROR,"liquidaciones.error.noBloqueo", vistaLiquidacion.getnCorrelaEstructura(), 
					vistaLiquidacion.getDescrProducto(), vistaLiquidacion.getFechaliq(), tipoOpera, vistaLiquidacion.getImportel(), accion);
			return false; 
		}else{
			Liquidacion liquidacion = liquidacionesBo.cargar(vistaLiquidacion.getId());
			if (GenericUtils.isNullOrBlank(liquidacion)){				
				statusMessages.addFromResourceBundle(Severity.ERROR,"liquidaciones.error.liquidacionInexistente", vistaLiquidacion.getnCorrelaEstructura(), 
						vistaLiquidacion.getDescrProducto(), vistaLiquidacion.getFechaliq(), tipoOpera, vistaLiquidacion.getImportel(), accion);
				dbLockService.desbloqueo(Liquidacion.class, vistaLiquidacion.getId());
				return false;
//			}else if(liquidacion.getCodliqco()==null){
//				if (liquidacion.getTipoNeting()==null){
//					if(!liquidacionesBo.existeTramo(liquidacion)){
//						//comprobamos que la liquidación tiene un tramo asociado
//						statusMessages.addFromResourceBundle(Severity.ERROR,"liquidaciones.error.liquidacionSinTramo", vistaLiquidacion.getnCorrelaEstructura(), 
//								vistaLiquidacion.getDescrProducto(), vistaLiquidacion.getFechaliq(), tipoOpera, vistaLiquidacion.getImportel(), accion);
//						dbLockService.desbloqueo(Liquidacion.class, vistaLiquidacion.getId());
//						return false;
//					}
//				}else{
//					// comprobamos que todas las liquidaciones que componen la neteada tienen un tramo asociado
//					if(!liquidacionesBo.existeTramosHijas(liquidacion)){
//						statusMessages.addFromResourceBundle(Severity.ERROR,"liquidaciones.error.liquidacionSinTramoHijas", vistaLiquidacion.getnCorrelaEstructura(), 
//								vistaLiquidacion.getDescrProducto(), vistaLiquidacion.getFechaliq(), tipoOpera, vistaLiquidacion.getImportel(), accion);
//						dbLockService.desbloqueo(Liquidacion.class, vistaLiquidacion.getId());
//						return false;						
//					}
//				}
				
		
			}else{
				Date d1 = new Date(liquidacion.getAuditData().getFechaUltimaModi().getTime());
				Date d2 = new Date(vistaLiquidacion.getFeultact().getTime());
				if (d1.compareTo(d2)!=0){					
					statusMessages.addFromResourceBundle(Severity.ERROR,"liquidaciones.error.liquidacionYaModificada", vistaLiquidacion.getnCorrelaEstructura(), 
							vistaLiquidacion.getDescrProducto(), vistaLiquidacion.getFechaliq(), tipoOpera, vistaLiquidacion.getImportel(), accion, vistaLiquidacion.getFeultact());
					dbLockService.desbloqueo(Liquidacion.class, vistaLiquidacion.getId());
					return false;
				}
			}		
		}
		//El registro sigue bloqueado
		return true;
		
	}
	public Boolean getValidarHabilitado() {
		setValidarHabilitado(false);
		if (!GenericUtils.isNullOrBlank(liquidacionesPantalla.getSelectedLiquiDataList()) && 
				liquidacionesPantalla.getSelectedLiquiDataList().size()>0){
			for(VistaLiquidacion vl: liquidacionesPantalla.getSelectedLiquiDataList()){
				if (vl.getEstado().equals(Constantes.LIQUIDACION_PDTE_VALIDAR)){
					setValidarHabilitado(true);
					break;
				}				
			}			
		}
		return validarHabilitado;
	}

	public void setValidarHabilitado(Boolean validarHabilitado) {
		this.validarHabilitado = validarHabilitado;
	}
	
	public Boolean getDesValidarHabilitado() {
		setDesValidarHabilitado(false);
		if (!GenericUtils.isNullOrBlank(liquidacionesPantalla.getSelectedLiquiDataList()) && 
				liquidacionesPantalla.getSelectedLiquiDataList().size()>0){
			for(VistaLiquidacion vl: liquidacionesPantalla.getSelectedLiquiDataList()){
				if (vl.getEstado().equals(Constantes.LIQUIDACION_VALIDADA) && vl.getLiqOriginal()==null ){
					setDesValidarHabilitado(true);
					break;
				}				
			}			
		}
		return desValidarHabilitado;
	}

	public void setDesValidarHabilitado(Boolean desValidarHabilitado) {
		this.desValidarHabilitado = desValidarHabilitado;
	}
	
	public void salir(){
		Conversation conversacion = Conversation.instance();
		//Volvemos a la anterior conversación
		if(conversacion.isNested()){
			conversacion.redirectToParent();
		} else {
			redirectToURL("/home.seam");
			conversacion.endAndRedirect();
		}
	}

	public void salir2(){
		nuevoAccesoDetalle();
		refrescarLista();
	}
	
	/**
	 * Función para llamar Boletas
	 */
	public String irOperaciones(){
		VistaLiquidacion vistaLiquidacion = liquidacionesPantalla.getVistaLiquiSelect();
		historicoOperacion = liquidacionesBo.obtenerHistoricoOperacion(vistaLiquidacion.getNcorrela(), vistaLiquidacion.getFechaope());
		
		if (historicoOperacion == null){
			statusMessages.add(Severity.WARN, "#{messages['liquidaciones.operacion.noexistente']}");
			return "";	
		}else {
			boletaState = BoletasStates.CONSULTA_BOLETA;
			return Constantes.CONSTANTE_SUCCESS;
		}
	}	
	
	/**
	 * Carga la liquidacion de base de datos para recuperar, si los hay, los datos de cesiones
	 * y de Swift. Si no los hay, mostrará los campos correspondientes vacíos en el formulario
	 */
	private void recuperarDatosLiquidacion() {
		
		//Recuperamos los datos de cesiones y swift para el registro seleccionado en el grid
		Liquidacion liquiAux = liquidacionesBo.cargar(liquidacionesPantalla.getVistaLiqui().getId());
		
		Cesiones cesionesLiquiSelec = liquiAux.getCesion();
		
		if(GenericUtils.isNullOrBlank(cesionesLiquiSelec)){
		
			Cesiones cesionAlta = new Cesiones(new CesionesId(liquiAux));
			VistaLiquidacion vistaLiq = liquidacionesPantalla.getVistaLiqui(); 
			
			AuditData auditData = new AuditData();
			auditData.setUsuarioUltimaModi(Identity.instance().getCredentials().getUsername());
			auditData.setFechaUltimaModi(new Date());
					
			cesionAlta.setAuditData(auditData);
			cesionAlta.setNcorrela(vistaLiq.getNcorrela());
			cesionAlta.setFechaope(vistaLiq.getFechaope());
			cesionAlta.setImportes(vistaLiq.getImportel());
		
			vistaLiq.setCesion(cesionAlta);

		} else {
			liquidacionesPantalla.getVistaLiqui().setCesion(cesionesLiquiSelec);
		}
		
		Swift swiftLiquiSelec = liquiAux.getSwift();
		
		if(GenericUtils.isNullOrBlank(swiftLiquiSelec)){
			
			Swift swiftAlta = new Swift(new SwiftId(liquiAux));
			VistaLiquidacion vistaLiq = liquidacionesPantalla.getVistaLiqui(); 

			swiftAlta.setFechaliq(vistaLiq.getFechaliq());
			swiftAlta.setNcorrela(vistaLiq.getNcorrela());
			swiftAlta.setFechaope(vistaLiq.getFechaope());
			swiftAlta.setTipopera(vistaLiq.getTipopera());
			swiftAlta.setCodivisa(vistaLiq.getDivisali());
		    
			liquidacionesPantalla.getVistaLiqui().setSwift(swiftAlta);
			
			
		} else {
			liquidacionesPantalla.getVistaLiqui().setSwift(swiftLiquiSelec);
		}
		
	}
	
	/** Abre el popup de calificar cobro */
	public void calificarCobro(){
		//Copiamos el seleccionado
		liquidacionesPantalla.copiarSeleccionado();
		
		String situliq = liquidacionesPantalla.getVistaLiqui().getSitualiq();
		
		//Deshabilitamos campos si es necesario
		if (SITUALIQ_PDR.equalsIgnoreCase(situliq) 
				|| SITUALIQ_VEN.equalsIgnoreCase(situliq)){
			this.camposCalificarDisabled = false;
		} else {
			this.camposCalificarDisabled = true;
		}
		
		String isForzar = liquidacionesPantalla.getVistaLiqui().getIndforza();
		
		//Asignamos el valor al chechbox
		if(Constantes.CONSTANTE_SI.equalsIgnoreCase(isForzar)){
			liquidacionesPantalla.setForzar(true);
		} else {
			liquidacionesPantalla.setForzar(false);
		}
		
		calificarRendered = true;
	}
	
	
	public boolean guardarCalificarCobroValidator(){
		
		boolean esCorrecto = true;
		
		VistaLiquidacion vista = liquidacionesPantalla.getVistaLiqui();
		
		if (GenericUtils.isNullOrZero(vista.getImpforza()) && 
				(!GenericUtils.isNullOrZero(vista.getImpforza2()) ||
				 !GenericUtils.isNullOrZero(vista.getImpforza3()) ||
				 !GenericUtils.isNullOrZero(vista.getImpforza4()) 
				)
		){
			statusMessages.add(Severity.ERROR, "#{messages['liquidaciones.error.importesDifLiq']}");
			esCorrecto = false;
		}else if (GenericUtils.isNullOrZero(vista.getImpforza2()) && 
				(!GenericUtils.isNullOrZero(vista.getImpforza3()) ||
				 !GenericUtils.isNullOrZero(vista.getImpforza4()) 
				)
		){

			statusMessages.add(Severity.ERROR, "#{messages['liquidaciones.error.importesDifLiq']}");
			esCorrecto = false;
 
		}else if (GenericUtils.isNullOrZero(vista.getImpforza3()) && 
				 !GenericUtils.isNullOrZero(vista.getImpforza4()) 
		){
			statusMessages.add(Severity.ERROR, "#{messages['liquidaciones.error.importesDifLiq']}");
			esCorrecto = false;

		}
		
		
		return esCorrecto;
	}	
	/**
	 * Realiza un update del registro correspondiente en la tabla deri.liquidac con los campos entrados
	 */
	public void guardarCalificarCobro(){
		
		VistaLiquidacion vista = liquidacionesPantalla.getVistaLiqui();
		
		if(liquidacionesPantalla.isForzar()){
			vista.setIndforza(Constantes.CONSTANTE_SI);
		} else {
			vista.setIndforza(Constantes.CONSTANTE_NO);
		}
		
		liquidacionesBo.actualizarCalificarCobro(vista);
		
		this.setCalificarRendered(false); //Cerramos el PopUp
	}
	
	public HashMap<MensajesValidacionId,MensajesValidacion> getItems() {
		return liquidacionesPantalla.getLiquidacionesMsg();
	}

	
	public List<MensajesValidacionId> getItemKeys() {
		List<MensajesValidacionId> keys = new ArrayList<MensajesValidacionId>();

//		keys.addAll(liquidacionesPantalla.getLiquidacionesMsg().keySet());

		for (Entry<MensajesValidacionId, MensajesValidacion> entry : liquidacionesPantalla.getLiquidacionesMsg().entrySet()) {
		
			if (!entry.getValue().isHaSidoRespondido()){
				keys.add(entry.getKey()); 
			}
			
		}
		
		return keys;
	}
	
	public LiquidacionesBo getLiquidacionesBo() {
		return liquidacionesBo;
	}

	public void setLiquidacionesBo(LiquidacionesBo liquidacionesBo) {
		this.liquidacionesBo = liquidacionesBo;
	}

	public LiquidacionesPantalla getLiquidacionesPantalla() {
		return liquidacionesPantalla;
	}

	public void setLiquidacionesPantalla(LiquidacionesPantalla liquidacionesPantalla) {
		this.liquidacionesPantalla = liquidacionesPantalla;
	}

	public DbLockService getDbLockService() {
		return dbLockService;
	}

	public void setDbLockService(DbLockService dbLockService) {
		this.dbLockService = dbLockService;
	}

	public boolean isCamposCalificarDisabled() {
		return camposCalificarDisabled;
	}

	public void setCamposCalificarDisabled(boolean camposCalificarDisabled) {
		this.camposCalificarDisabled = camposCalificarDisabled;
	}
	
	public boolean isNullorZero(BigDecimal importe){
		return GenericUtils.isNullOrZero(importe);
	}

	public void onChangeImpforza(){
		 if (GenericUtils.isNullOrZero(liquidacionesPantalla.getVistaLiqui().getImpforza())){
			 liquidacionesPantalla.getVistaLiqui().setImpforza2(null);
			 liquidacionesPantalla.getVistaLiqui().setImpforza3(null);
			 liquidacionesPantalla.getVistaLiqui().setImpforza4(null);
		 }
	}
	
	public void onChangeImpforza2(){
		 if (GenericUtils.isNullOrZero(liquidacionesPantalla.getVistaLiqui().getImpforza2())){
			 liquidacionesPantalla.getVistaLiqui().setImpforza3(null);
			 liquidacionesPantalla.getVistaLiqui().setImpforza4(null);
		 }
	}

	public void onChangeImpforza3(){
		 if (GenericUtils.isNullOrZero(liquidacionesPantalla.getVistaLiqui().getImpforza3())){
			 liquidacionesPantalla.getVistaLiqui().setImpforza4(null);
		 }
	}
	
	
	public boolean isCalificarRendered() {
		return calificarRendered;
	}

	public void setCalificarRendered(boolean calificarRendered) {
		this.calificarRendered = calificarRendered;
	}


	public boolean isPanelSwiftRendered() {
		return panelSwiftRendered;
	}


	public void setPanelSwiftRendered(boolean panelSwiftRendered) {
		this.panelSwiftRendered = panelSwiftRendered;
	}
	
	
	public List<VistaLiquidacion> getLiquidacionesBloqueadas() {
		return liquidacionesBloqueadas;
	}


	public void setLiquidacionesBloqueadas(
			List<VistaLiquidacion> liquidacionesBloqueadas) {
		this.liquidacionesBloqueadas = liquidacionesBloqueadas;
	}


	public boolean isListaConfirmacionesRendered() {
		return listaConfirmacionesRendered;
	}


	public void setListaConfirmacionesRendered(boolean listaConfirmacionesRendered) {
		this.listaConfirmacionesRendered = listaConfirmacionesRendered;
	}


	public HashMap<MensajesValidacionId, MensajesValidacion> getLiquidacionesMsg() {
		return liquidacionesMsg;
	}


	public void setLiquidacionesMsg(
			HashMap<MensajesValidacionId, MensajesValidacion> liquidacionesMsg) {
		this.liquidacionesMsg = liquidacionesMsg;
	}
	
	public void recargarLista(){
	refrescarLista();
	List<VistaLiquidacion> listaVistaLiqui = liquidacionesPantalla.getListaVistaLiqui();
	for (VistaLiquidacion vistaLiquidacion : listaVistaLiqui) {
		liquidacionesBo.cargar(vistaLiquidacion.getId());
	}
	}
	
	public List<VistaLiquidacion> listaSeleccionarTodos(){
		if(this.liquidacionesPantalla.isVieneAgenda()){
			return liquidacionesBo.obtenerDatosLiquidacionesAgenda(parametrosOutAgenda.getCodevent().shortValue(), 
					parametrosOutAgenda.getModeloPr(),parametrosOutAgenda.getProducto(), 
					parametrosOutAgenda.getNcorrelaIni(), parametrosOutAgenda.getNcorrelaFin(), 
					parametrosOutAgenda.getFechatraIni(), parametrosOutAgenda.getFechatraFin(), 
					parametrosOutAgenda.getEstadoEv(), false,exportExcel, paginationData);	 
		} else {
			// SMM - cambio inc 655 		
			//Cuando llega aquí ya ha pasado el control de validarCasadasPantalla
			if (this.liquidacionesPantalla.getOpCasadasSelect()){
				LiquidacionesPantalla pantalla = this.liquidacionesPantalla;
				return liquidacionesBo.obtenerLiquidacionesCasadas(pantalla.getFechaLiquidDesde(), pantalla.getFechaLiquidHasta(), pantalla.getNumOperDesde(), pantalla.getEstadoLiqSelect(),false,exportExcel, paginationData);					
			}else{
				//SMM: este if supuestamente no se ejecutará actualmente, ya que una vez que el usuario pulse buscar,
				//pierde el modo
				if (this.liquidacionesPantalla.isVieneOperaciones()){	//Supuestamente esto no se ejecutará actualmente			
					return liquidacionesBo.obtenerDatosLiquidaciones(null, null,
							parametrosOutAgenda.getNcorrelaIni(), null, null, null, null, null, 
							null, null, null, null, null, null, null, parametrosOutAgenda.getFechaOpe(),null, null, null, null, null, null,null, null,null,false,exportExcel, paginationData);	

				}else{				
					return	liquidacionesBo.obtenerDatosLiquidaciones(liquidacionesPantalla.getModeloProductoSelect(), liquidacionesPantalla.getProdCatalSelect(),
							liquidacionesPantalla.getNumOperDesde(), liquidacionesPantalla.getNumOperHasta(), liquidacionesPantalla.getDivPagoSelect(),
							liquidacionesPantalla.getProdOperSelect(), liquidacionesPantalla.getFechaLiquidDesde(), liquidacionesPantalla.getFechaLiquidHasta(), 
							liquidacionesPantalla.getDivCobroSelect(), liquidacionesPantalla.getContrapartidaSelect(), 
							liquidacionesPantalla.getNumEstructDesde(), liquidacionesPantalla.getNumEstructHasta(), liquidacionesPantalla.getEstadoLiqSelect(),				
							liquidacionesPantalla.getSitCorrespSelect(), liquidacionesPantalla.getOpCasadasSelect(), null,
							liquidacionesPantalla.getGuidDesde(), liquidacionesPantalla.getGuidHasta(),
							liquidacionesPantalla.getClaveExternaDesde(), liquidacionesPantalla.getClaveExternaHasta(), liquidacionesPantalla.getImporteDesde() , liquidacionesPantalla.getImporteHasta(), 
							liquidacionesPantalla.getTipoContrapa(), liquidacionesPantalla.getSuReferencia(), liquidacionesPantalla.getIdConciliada(),false, exportExcel, paginationData);			
				}
			}
		}
	}



	
	public List<VistaLiquidacion> getListaTemp() {
		return listaTemp;
	}


	public void setListaTemp(List<VistaLiquidacion> listaTemp) {
		this.listaTemp = listaTemp;
	}

	public static int getDayOfTheWeek(Date d){
		GregorianCalendar cal = new GregorianCalendar();
		cal.setTime(d);
		return cal.get(Calendar.DAY_OF_WEEK);		
	}
	
	public Boolean esFestivaLiquidacion(VistaLiquidacion liqui){
	try {
		if (("VA".equals(liqui.getEstado()) || "PV".equals(liqui.getEstado()))&& 
				(liquidacionesBo.esFestivo(liqui.getFechaliq(),liqui.getDivisali()) ||
				getDayOfTheWeek(liqui.getFechaliq())==7 || getDayOfTheWeek(liqui.getFechaliq())==1)
			){
				return true;
		}
				return false;
	} catch (Exception e) {
		return false;
	}	
	}
	
	public String getRowClasses(){
		StringBuilder builder = new StringBuilder();
		int i=0;
		for (VistaLiquidacion vl : liquidacionesPantalla.getListaVistaLiqui()) {
			Contrapartida contrapartida;
			String idContrapartida = vl.getContrapa();
			contrapartida = liquidacionesBo.cargarContrapartida(idContrapartida.toUpperCase());	
			
			if(i>0){
				builder.append(",");
			}
			
			if(vl.getLiqOriginal()!=null){
				if (esFestivaLiquidacion(vl)){
					if (null!=contrapartida && !GenericUtils.isNullOrBlank(contrapartida.getIndBloqueo()) && "S".equalsIgnoreCase(contrapartida.getIndBloqueo())){
						builder.append("redResaltadoRowLiq");
					}
					else{
						builder.append("redResaltadoRow");
					}
				}else{
					if (null!=contrapartida && !GenericUtils.isNullOrBlank(contrapartida.getIndBloqueo()) && "S".equalsIgnoreCase(contrapartida.getIndBloqueo())){
						builder.append("resaltarRowLiq");
					}
					else{
						builder.append("resaltarRow");
					}
				}
				
			}else{
				if (esFestivaLiquidacion(vl)){
					if (null!=contrapartida && !GenericUtils.isNullOrBlank(contrapartida.getIndBloqueo()) && "S".equalsIgnoreCase(contrapartida.getIndBloqueo())){
						builder.append("redRowLiq");
					}
					else{
						builder.append("redRow");
					}
				}else{
					
					if(i%2==0){
						if (null!=contrapartida && !GenericUtils.isNullOrBlank(contrapartida.getIndBloqueo()) && "S".equalsIgnoreCase(contrapartida.getIndBloqueo())){
							builder.append("oddRowRedLiq");
						}
						else{
							builder.append("oddRow");
						}
					}
					else{
						if (null!=contrapartida && !GenericUtils.isNullOrBlank(contrapartida.getIndBloqueo()) && "S".equalsIgnoreCase(contrapartida.getIndBloqueo())){
							builder.append("eventRowRedLiq");
						}
						else{
							builder.append("evenRow");
						}
					}

				}
			}
			i++;
			contrapartida = null;
		}
		return builder.toString();
	}
	
	
	@Override
	public boolean isLastExists() {
		return true;
	}
	
	
	public Integer contarRegistros(){
		Integer comptadorRegistres = new Integer(0);
		
		if(this.liquidacionesPantalla.isVieneAgenda()){
			
			List<VistaLiquidacion> listaVistaLiqui = liquidacionesPantalla.getListaVistaLiqui();	
			listaVistaLiqui = liquidacionesBo.obtenerDatosLiquidacionesAgenda(parametrosOutAgenda.getCodevent().shortValue(), 
					parametrosOutAgenda.getModeloPr(),parametrosOutAgenda.getProducto(), 
					parametrosOutAgenda.getNcorrelaIni(), parametrosOutAgenda.getNcorrelaFin(), 
					parametrosOutAgenda.getFechatraIni(), parametrosOutAgenda.getFechatraFin(), 
					parametrosOutAgenda.getEstadoEv(), null, exportExcel, paginationData);
			
			comptadorRegistres = listaVistaLiqui.get(0).getNumeroRegistros();

		} else {
			if (this.liquidacionesPantalla.getOpCasadasSelect()){
				
				LiquidacionesPantalla pantalla = this.liquidacionesPantalla;
				List<VistaLiquidacion> listaVistaLiqui = liquidacionesBo.obtenerLiquidacionesCasadas(pantalla.getFechaLiquidDesde(), 
						pantalla.getFechaLiquidHasta(), pantalla.getNumOperDesde(), pantalla.getEstadoLiqSelect(),null, 
						exportExcel, paginationData);					
				comptadorRegistres = listaVistaLiqui.get(0).getNumeroRegistros();
				
			}else{
				if (this.liquidacionesPantalla.isVieneOperaciones()){	//Supuestamente esto no se ejecutará actualmente			
					
					List<VistaLiquidacion> listaVistaLiqui = liquidacionesPantalla.getListaVistaLiqui();	
					listaVistaLiqui = liquidacionesBo.obtenerDatosLiquidaciones(null, null,
							parametrosOutAgenda.getNcorrelaIni(), null, null, null, null, null, 
							null, null, null, null, null, null, null, parametrosOutAgenda.getFechaOpe(),
							null, null, null, null, null, null, null,null,null,null, false, paginationData);	
					
					comptadorRegistres = listaVistaLiqui.get(0).getNumeroRegistros();
					
				}else{				
					List<VistaLiquidacion> listaVistaLiqui = liquidacionesBo.obtenerDatosLiquidaciones(liquidacionesPantalla.getModeloProductoSelect(), liquidacionesPantalla.getProdCatalSelect(),
							liquidacionesPantalla.getNumOperDesde(), liquidacionesPantalla.getNumOperHasta(), liquidacionesPantalla.getDivPagoSelect(),
							liquidacionesPantalla.getProdOperSelect(), liquidacionesPantalla.getFechaLiquidDesde(), liquidacionesPantalla.getFechaLiquidHasta(), 
							liquidacionesPantalla.getDivCobroSelect(), liquidacionesPantalla.getContrapartidaSelect(), 
							liquidacionesPantalla.getNumEstructDesde(), liquidacionesPantalla.getNumEstructHasta(), liquidacionesPantalla.getEstadoLiqSelect(),				
							liquidacionesPantalla.getSitCorrespSelect(), liquidacionesPantalla.getOpCasadasSelect(), null, 
							liquidacionesPantalla.getGuidDesde(), liquidacionesPantalla.getGuidHasta(),
							liquidacionesPantalla.getClaveExternaDesde(), liquidacionesPantalla.getClaveExternaHasta(), liquidacionesPantalla.getImporteDesde() , liquidacionesPantalla.getImporteHasta(), 
							liquidacionesPantalla.getTipoContrapa(),liquidacionesPantalla.getSuReferencia(),liquidacionesPantalla.getIdConciliada(),null, exportExcel , paginationData);			
					
					comptadorRegistres = listaVistaLiqui.get(0).getNumeroRegistros();

				}
			}
		}
		
		return comptadorRegistres;
	}
	
	public void last(){
		if ( GenericUtils.isNullOrBlank(ultimRegistre) || ultimRegistre == 0 ){
			ultimRegistre = contarRegistros();//prepareOperacionesListCount();
		}
		goLast(ultimRegistre);
	}

	public Integer getUltimRegistre() {
		return ultimRegistre;
	}

	public void setUltimRegistre(Integer ultimRegistre) {
		this.ultimRegistre = ultimRegistre;
	}
	
	
	public void initDetalle(){
		if (primeraEjecucionInit == null) {
			primeraEjecucionInit=true;
		} 
		else{
			primeraEjecucionInit = false;
		}
		
		if(primeraEjecucionInit){
		
			if(null!=liquidacionesPantalla.getVistaLiqui()){
				VistaLiquidacion vistaLiquidacion = liquidacionesPantalla.getVistaLiqui();
				String idContrapartida = vistaLiquidacion.getContrapa();
				if (!GenericUtils.isNullOrBlank(idContrapartida)){
					 Contrapartida contrapObtenida2 = liquidacionesBo.cargarContrapartida(idContrapartida.toUpperCase());	
					if (null!=contrapObtenida2 && !GenericUtils.isNullOrBlank(contrapObtenida2.getIndBloqueo()) && "S".equalsIgnoreCase(contrapObtenida2.getIndBloqueo())){
						iniciarPopUpContrapartidaBloqueada();
					}
				}
			}
		}
	}
	
	public void init(){
		primeraEjecucionInit = null;
		primeraEjecucionModificarInit = null;
		
		if (msgboxPanelLiquidContrapaBloq==null){
			msgboxPanelLiquidContrapaBloq = new MessageBoxAction();
		}
	}
	
	public void initModificar(){
		if (primeraEjecucionModificarInit == null) {
			primeraEjecucionModificarInit=true;
		} 
		else{
			primeraEjecucionModificarInit = false;
		}
		
		if(primeraEjecucionModificarInit){
			if(null!=liquidacionesPantalla.getVistaLiqui() && null!= liquidacionesPantalla.getVistaLiqui().getContrapa()){
				String idContrapartida = liquidacionesPantalla.getVistaLiqui().getContrapa();
				if (!GenericUtils.isNullOrBlank(idContrapartida)){
					 Contrapartida contrapObtenida2 = liquidacionesBo.cargarContrapartida(idContrapartida.toUpperCase());	
					if (null!=contrapObtenida2 && !GenericUtils.isNullOrBlank(contrapObtenida2.getIndBloqueo()) && "S".equalsIgnoreCase(contrapObtenida2.getIndBloqueo())){
						iniciarPopUpContrapartidaBloqueada();
					}
				}
			}
		}
	}

	public void voidFunction(){
		msgBoxAction.voidFunction();
	}

	/**
	 * Mostrar PopUp cuando una contrapartida está bloqueada (no bloqueante)
	 */
	public void onVerificarContrapartidaBloqueada() {
		if(null!=liquidacionesPantalla.getContrapartidaSelect())
		{
			String contrapartida = liquidacionesPantalla.getContrapartidaSelect();
			if (!GenericUtils.isNullOrBlank(contrapartida)){
				 Contrapartida contrapObtenida2 = liquidacionesBo.cargarContrapartida(contrapartida.toUpperCase());	
				if (null!=contrapObtenida2 && !GenericUtils.isNullOrBlank(contrapObtenida2.getIndBloqueo()) && "S".equalsIgnoreCase(contrapObtenida2.getIndBloqueo())){
					iniciarPopUpContrapartidaBloqueada();
				}
			}
		}
	}
	
	private void iniciarPopUpContrapartidaBloqueada(){
		msgboxPanelLiquidContrapaBloq.init("liquidaciones.messages.contrapartida.bloqueada.texto", "liquidacionesAction.voidFunction()", null, "messageBoxPanelContrapa");
	}
	
	public void nuevoAccesoDetalle(){
		primeraEjecucionInit = null;
	}
	

	public boolean estaBloqueada(String nCorrela, String fechaOperacion){
		if (!GenericUtils.isNullOrBlank(nCorrela) && !GenericUtils.isNullOrBlank(fechaOperacion)){
			Date date;
			DateFormat format = new SimpleDateFormat("yyyy-MM-dd");
			try {
				date = format.parse(fechaOperacion);
			} catch (ParseException e) {
				return false;
			}
			
			 Operacion operacion = boletasBo.getOperacionByNCorrelaAndFechaOper(new Long(nCorrela), date);
			 if(null!=operacion){ 
			 	Contrapartida contrapObtenida2 = (Contrapartida) operacion.getContrapartida();
				if (null!=contrapObtenida2 && !GenericUtils.isNullOrBlank(contrapObtenida2.getIndBloqueo()) && "S".equalsIgnoreCase(contrapObtenida2.getIndBloqueo())){
					return true;
				}
			 }
		}
		return false;
	}

}

