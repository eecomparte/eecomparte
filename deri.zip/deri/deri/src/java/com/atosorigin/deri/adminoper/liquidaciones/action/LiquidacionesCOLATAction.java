package com.atosorigin.deri.adminoper.liquidaciones.action;

import java.math.BigDecimal;
import java.rmi.RemoteException;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.persistence.RollbackException;
import javax.sql.DataSource;

import org.hibernate.SQLQuery;
import org.jboss.seam.ScopeType;
import org.jboss.seam.annotations.In;
import org.jboss.seam.annotations.Name;
import org.jboss.seam.annotations.Out;
import org.jboss.seam.annotations.Scope;
import org.jboss.seam.core.Conversation;
import org.jboss.seam.core.ResourceBundle;
import org.jboss.seam.international.StatusMessage.Severity;
import org.jboss.seam.international.StatusMessages;
import org.jboss.seam.security.Identity;

import com.atosorigin.common.action.ModoPantalla;
import com.atosorigin.common.action.PaginatedListAction;
import com.atosorigin.common.action.PaginationData;
import com.atosorigin.common.auditdata.AuditData;
import com.atosorigin.common.constantes.Constantes;
import com.atosorigin.common.formvalidator.FormValidator;
import com.atosorigin.common.utils.GenericUtils;
import com.atosorigin.deri.adminoper.boletas.action.BoletasAction.BoletasStates;
import com.atosorigin.deri.adminoper.liquidaciones.screen.LiquidacionesCOLATPantalla;
import com.atosorigin.deri.common.dbLock.DbLockService;
import com.atosorigin.deri.common.parametrosPantalla.ParametrosOutAgenda;
import com.atosorigin.deri.dao.adminoper.boletas.CallableTemplate;
import com.atosorigin.deri.dao.adminoper.boletas.CallableTemplate.CallableExecuter;
import com.atosorigin.deri.liquidaciones.business.LiquidacionesBo;
import com.atosorigin.deri.liquidaciones.business.MensajesValidacion;
import com.atosorigin.deri.liquidaciones.business.MensajesValidacionId;
import com.atosorigin.deri.model.contrapartida.Contrapartida;
import com.atosorigin.deri.model.dbblock.DbBloqueo;
import com.atosorigin.deri.model.gestionoperaciones.HistoricoOperacion;
import com.atosorigin.deri.model.liquidaciones.Cesiones;
import com.atosorigin.deri.model.liquidaciones.CesionesId;
import com.atosorigin.deri.model.liquidaciones.Liquidacion;
import com.atosorigin.deri.model.liquidaciones.Liquidacion2Cover;
import com.atosorigin.deri.model.liquidaciones.ModeloColat;
import com.atosorigin.deri.model.liquidaciones.Swift;
import com.atosorigin.deri.model.liquidaciones.SwiftId;
import com.atosorigin.deri.model.liquidaciones.VistaLiquidacion;
import com.atosorigin.deri.util.MessageBoxAction;
import com.atosorigin.deri.util.MsgBoxAction;
import com.bancsabadell.xmlns.proteo.SharedResources.ErrorSchema.FaultInfo;
import com.bs.proteo.soa.service.proteo.xs7977.xs7977.domain.message.Xs7977Response;
import com.bs.proteo.soa.service.proteo.xs7977.ServicioXs7977;
import com.example.www.UserLogin_operation1.ServicioLogin;

@Name("liquidacionesCOLATAction")
@Scope(ScopeType.CONVERSATION)
@FormValidator
public class LiquidacionesCOLATAction extends PaginatedListAction {

	public static final String SITUALIQ_PDR = "PDR";
	public static final String SITUALIQ_PDE = "PDE";
	public static final String SITUALIQ_VEN = "VEN";

	@In("#{liquidacionesBo}")
	protected LiquidacionesBo liquidacionesBo;

	@In(create = true)
	protected LiquidacionesCOLATPantalla liquidacionesCOLATPantalla;
	
	static String sessionid2cover = "";
	
	/**
	 * Inyección datos provenientes de Agenda o Lista de Operaciones
	 */
	@In(required = false, value = "#{parametrosOutAgenda}")
	protected ParametrosOutAgenda parametrosOutAgenda;

	@Out(required = false, value = "liquidacionesCOLATMessageBoxAction")
	private MessageBoxAction messageBoxLiquidacionesCOLATAction;

	protected Boolean validarHabilitado = false;
	protected Boolean desValidarHabilitado = false;
	protected boolean camposCalificarDisabled;
	protected boolean calificarRendered = false;
	protected boolean listaConfirmacionesRendered = false;
	protected boolean panelSwiftRendered;
	protected String projecte = Constantes.NOMBRE_PROYECTO_COLAT;
	private Integer ultimRegistre;


	private Boolean primeraEjecucionInit=null;
	private Boolean primeraEjecucionRecibo=null;
	
	HashMap<MensajesValidacionId, MensajesValidacion> liquidacionesMsg;

	/**
	 * Inyección del servicio que gestiona los bloqueos de registros en base de
	 * datos
	 */
	@In(create = true)
	protected DbLockService dbLockService;

	/**
	 * Inyeccion del componente necesario para mostrar mensajes de decisión al
	 * usuario
	 */
	@In(create = true)
	private MsgBoxAction msgBoxAction;

	private List<VistaLiquidacion> liquidacionesBloqueadas;

	// Selección de 500 registros para el botón seleccionar todos.
	private List<VistaLiquidacion> listaTemp;

	// Para la union con datos generales alta BOLETAS
	@Out(required = false)
	private BoletasStates boletaState;

	// Para la union con datos generales alta BOLETAS
	@Out(required = false)
	HistoricoOperacion historicoOperacion;

	// oO[Métodos]Oo
	@Override
	public List<VistaLiquidacion> getDataTableList() {
		return liquidacionesCOLATPantalla.getListaVistaLiqui();
	}

	public boolean guardarLiquidacionPagoValidator() {

		boolean esCorrecto = true;

		VistaLiquidacion vistaLiquidacion = liquidacionesCOLATPantalla
				.getVistaLiqui();
		//Date fechamis = liquidacionesBo.obtenerFechaSistema(); // Recuperamos la
																// fecha del
																// sistema

		esCorrecto = validaCuenta(vistaLiquidacion);

		Swift swift = vistaLiquidacion.getSwift();
		Date fechaHoy = new Date();
		if (Constantes.CANAL_SWIFT.equals(vistaLiquidacion.getCanaliqi())) {
			if ((!GenericUtils.isNullOrBlank(vistaLiquidacion.getSwift()
					.getFechaenv()))
					&& vistaLiquidacion.getSwift().getFechaenv().getTime() < fechaHoy
							.getTime()) {
				statusMessages
						.add(Severity.ERROR,
								"#{messages['liquidaciones.error.swift.fechaAnterior']}");
				esCorrecto = false;
			} else if (!compruebaCorrelativos(swift.getInterml1(), swift
					.getInterml2(), swift.getInterml3(), swift.getInterml4(),
					null, null)) {
				statusMessages
						.add(Severity.ERROR,
								"#{messages['parametrosLiquidacion.error.textosNoCorrelativos']}");
				esCorrecto = false;

			} else if (!compruebaCorrelativos(swift.getBdbenel1(), swift
					.getBdbenel2(), swift.getBdbenel3(), swift.getBdbenel4(),
					null, null)) {
				statusMessages
						.add(Severity.ERROR,
								"#{messages['liquidaciones.error.swift.fechaAnterior']}");
				esCorrecto = false;
			} else if (!compruebaCorrelativos(swift.getBbenefl1(), swift
					.getBbenefl2(), swift.getBbenefl3(), swift.getBbenefl4(),
					null, null)) {
				statusMessages
						.add(Severity.ERROR,
								"#{messages['liquidaciones.error.swift.fechaAnterior']}");
				esCorrecto = false;
			} else if (!compruebaCorrelativos(swift.getObservl1(), swift
					.getObservl2(), swift.getObservl3(), swift.getObservl4(),
					swift.getObservl5(), swift.getObservl6())) {
				statusMessages
						.add(Severity.ERROR,
								"#{messages['liquidaciones.error.swift.fechaAnterior']}");
				esCorrecto = false;
			} else if (!validaLineasByCodigo(swift.getIntercod(), swift
					.getIntercta(), swift.getInterml1(), swift.getInterml2(),
					swift.getInterml3(), swift.getInterml4())) {
				statusMessages.add(Severity.ERROR,
						"#{messages['liquidaciones.error.errorCodigoTexto']}");
				esCorrecto = false;
			} else if (!validaLineasByCodigo(swift.getBdbencod(), swift
					.getBdbencta(), swift.getBdbenel1(), swift.getBdbenel2(),
					swift.getBdbenel3(), swift.getBdbenel4())) {
				statusMessages.add(Severity.ERROR,
						"#{messages['liquidaciones.error.errorCodigoTexto']}");
				esCorrecto = false;
			} else if (!validaLineasByCodigo(swift.getBbenecod(), swift
					.getBbenecta(), swift.getBbenefl1(), swift.getBbenefl2(),
					swift.getBbenefl3(), swift.getBbenefl4())) {
				statusMessages.add(Severity.ERROR,
						"#{messages['liquidaciones.error.errorCodigoTexto']}");
				esCorrecto = false;
			} else if (GenericUtils.isNullOrBlank(swift.getTiddesti())
					|| ((GenericUtils.isNullOrBlank(swift.getBbenecod()) || GenericUtils
							.isNullOrBlank(swift.getBbenecta())) && GenericUtils
							.isNullOrBlank(swift.getBbenefl1()))) {

				statusMessages.add(Severity.ERROR,
						"#{messages['liquidaciones.error.obligatoriosSwift']}");
				esCorrecto = false;
			}
		}
		if ("50".equals(vistaLiquidacion.getGruconta())
				&& "901".equals(vistaLiquidacion.getOficonta())) {
			statusMessages.add(Severity.ERROR,
					"#{messages['liquidaciones.error.grupoContableErroneo']}");
			esCorrecto = false;
		}

		//if ((!GenericUtils.isNullOrBlank(vistaLiquidacion.getFechaliq()))
		//		&& vistaLiquidacion.getFechaliq().getTime() < fechamis
		//				.getTime()) {
		//	statusMessages.addToControlFromResourceBundle("fLiquiTxt",
		//			Severity.ERROR, "liquidaciones.error.fliq.incorrecta",
		//			fechamis);
		//	esCorrecto = false;
		//}

		if (!GenericUtils.isNullOrBlank(vistaLiquidacion.getCesion())
				&& !GenericUtils.isNullOrBlank(vistaLiquidacion.getCesion()
						.getEntiddes())) {
			if (!liquidacionesBo.comprobarEntidad(vistaLiquidacion.getCesion()
					.getEntiddes())) {
				statusMessages.addToControlFromResourceBundle("txtentidadPg",
						Severity.ERROR, "liquidaciones.error.entidad",
						vistaLiquidacion.getCesion().getEntiddes());
				esCorrecto = false;
			}
		}

		return esCorrecto;
	}

	public boolean validaLineasByCodigo(String codigo, String cta,
			String linea1, String linea2, String linea3, String linea4) {
		boolean retorno = true;
		if (!GenericUtils.isNullOrBlank(codigo)
				&& !GenericUtils.isNullOrBlank(cta)) {
			if (!GenericUtils.isNullOrBlank(linea1)
					|| !GenericUtils.isNullOrBlank(linea2)
					|| !GenericUtils.isNullOrBlank(linea3)
					|| !GenericUtils.isNullOrBlank(linea4)) {
				retorno = false;
			}
		}
		return retorno;
	}

	public boolean compruebaCorrelativos(String texto1, String texto2,
			String texto3, String texto4, String texto5, String texto6) {
		// Si son nulos, indica que no son del campo de observaciones.
		boolean retorno = true;
		if (GenericUtils.isNullOrBlank(texto5)
				&& GenericUtils.isNullOrBlank(texto6)) {
			if ((!GenericUtils.isNullOrBlank(texto1))
					&& (GenericUtils.isNullOrBlank(texto2))
					&& (!GenericUtils.isNullOrBlank(texto3)
							|| !GenericUtils.isNullOrBlank(texto4)
							|| !GenericUtils.isNullOrBlank(texto5) || !GenericUtils
							.isNullOrBlank(texto6))) {
				retorno = false;
			}
			if ((!GenericUtils.isNullOrBlank(texto1))
					&& (!GenericUtils.isNullOrBlank(texto2))
					&& (GenericUtils.isNullOrBlank(texto3))
					&& (!GenericUtils.isNullOrBlank(texto4)
							|| !GenericUtils.isNullOrBlank(texto5) || !GenericUtils
							.isNullOrBlank(texto6))) {

				retorno = false;
			}
			if ((!GenericUtils.isNullOrBlank(texto1))
					&& (!GenericUtils.isNullOrBlank(texto2))
					&& (!GenericUtils.isNullOrBlank(texto3))
					&& (GenericUtils.isNullOrBlank(texto4))
					&& (!GenericUtils.isNullOrBlank(texto5) || !GenericUtils
							.isNullOrBlank(texto6))) {

				retorno = false;
			}
		} else {
			// tan solo tenemos que controlar los 4 primeros campos y obiamos el
			// caso de que escriban el campo 1, el campo 2 y el campo 3...
			if ((!GenericUtils.isNullOrBlank(texto1))
					&& (GenericUtils.isNullOrBlank(texto2))
					&& (!GenericUtils.isNullOrBlank(texto3) || !GenericUtils
							.isNullOrBlank(texto4))) {
				retorno = false;
			}
			if ((!GenericUtils.isNullOrBlank(texto1))
					&& (!GenericUtils.isNullOrBlank(texto2))
					&& (GenericUtils.isNullOrBlank(texto3) && !GenericUtils
							.isNullOrBlank(texto4))) {
				retorno = false;
			}
		}

		return retorno;
	}

	public String guardarLiquidacionPago() {

		Liquidacion liquidacion = liquidacionesCOLATPantalla.getVistaLiqui();
		// liquidacion = llenarCamposPago();//Según alfons el proyecto nunca
		// puede ser nulo...
		liquidacion.setSitualiq(SITUALIQ_PDE);
		liquidacionesBo.actualizarLiquidacion(liquidacion,
				liquidacionesCOLATPantalla.getProyecto());
		liquidacionesBo.actualizarCesion(liquidacionesCOLATPantalla
				.getVistaLiqui());
		if (Constantes.CANAL_SWIFT.equals(liquidacion.getCanaliqi())) {
			liquidacionesBo.actualizarSwift(liquidacion.getSwift()
					.getFechaenv(), liquidacion);
		}
		refrescarLista();
		return Constantes.CONSTANTE_SUCCESS;

	}

	public Liquidacion llenarCamposPago() {
		// Liquidacion liquidacion = new Liquidacion();

		// Según alfons el proyecto nunca puede ser nulo...
		/**
		 * Si LiqPag_Swift.proyecto is null and LiqPag.formpago = 'SWF',
		 * LiqPag_Swift.proyecto := 'DERI' LiqPag_Swift.codliqui :=
		 * VistaLiquidacion.codliqui LiqPag_Swift.fechatra :=
		 * VistaLiquidacion.fechatra LiqPag_Swift.fechaliq := LiqPag.fproxliq
		 * LiqPag_Swift.fechaope := LiqPag.fechaoper LiqPag_Swift.ncorrela :=
		 * LiqPag.ncorrela LiqPag_Swift.tipopera := VistaLiquidacion.tipopera
		 * LiqPag_Swift.codivisa := VistaLiquidacion.divisali
		 * LiqPag_Swift.usultact := usuario LiqPag_Swift.feultact := SYSDATE
		 * 
		 * Fin Si
		 */

		return null;
	}

	/** habilita o deshabilita el panel de swift */
	public void marcaSwift() {

		if (Constantes.CANAL_SWIFT.equalsIgnoreCase(liquidacionesCOLATPantalla
				.getVistaLiqui().getCanaliqi())
				|| Constantes.CANAL_TARGET
						.equalsIgnoreCase(liquidacionesCOLATPantalla
								.getVistaLiqui().getCanaliqi())) {
			this.setPanelSwiftRendered(true);
		} else {
			this.setPanelSwiftRendered(false);
		}

	}

	@Override
	protected void refreshListInternal() {

		setExportExcel(false);
		rellenarLista(paginationData, false);
	}

	/**
	 * Carga la lista de Liquidaciones cuando venimos de la pantalla de Agenda o
	 * de Lista Operaciones
	 */
	public void initListaResultados() {
		setExportExcel(false);
		liquidacionesCOLATPantalla.setProyecto(Constantes.APLICACION_COLAT);

		// Precargar la lista con Parametros liquidación si es la primera vez q
		// entra
		// Si parametrosOutAgenda es nulo es que entramos desde el menú
		if (isPrimerAcceso()) {
			buildListasProductos();
			liquidacionesCOLATPantalla.setEstadoLiqSelect(liquidacionesBo
					.cargarEstadoLiquidacion(Constantes.TIPO_ESTADO_PV));

		}
	}

	public void rellenarLista(PaginationData paginationData, Boolean batch) {

		List<VistaLiquidacion> listaVistaLiqui = liquidacionesBo
				.obtenerDatosLiquidacionesColat(liquidacionesCOLATPantalla
						.getProdCatalSelect(), liquidacionesCOLATPantalla
						.getNumOperDesde(), liquidacionesCOLATPantalla
						.getNumOperHasta(), liquidacionesCOLATPantalla
						.getDivPagoSelect(), liquidacionesCOLATPantalla
						.getFechaLiquidDesde(), liquidacionesCOLATPantalla
						.getFechaLiquidHasta(), liquidacionesCOLATPantalla
						.getDivCobroSelect(), liquidacionesCOLATPantalla
						.getContrapartidaSelect(), liquidacionesCOLATPantalla
						.getEstadoLiqSelect(), liquidacionesCOLATPantalla
						.getSitCorrespSelect(), liquidacionesCOLATPantalla
						.getImporteDesde(), liquidacionesCOLATPantalla
						.getImporteHasta(), liquidacionesCOLATPantalla
						.getTipoContrapa(), batch, exportExcel, paginationData);

		if (liquidacionesCOLATPantalla.getListaVistaLiqui() != null) {
			liquidacionesCOLATPantalla.getListaVistaLiqui().clear();
			liquidacionesCOLATPantalla.getListaVistaLiqui().addAll(
					listaVistaLiqui);
		} else {
			liquidacionesCOLATPantalla.setListaVistaLiqui(listaVistaLiqui);
		}

	}

	private void procesoExcelBatch(List<VistaLiquidacion> listaVistaLiqui,
			String caso) {
		String sqlTxt = null;
		String sustitucion = null;
		String sqlHeader = null;

		String caso2 = null;
		if ("OPERACIONES".equalsIgnoreCase(caso)) {
			caso2 = "AGENDA";
		} else {
			caso2 = caso;
		}

		sqlHeader = "Prod.Op.;N;N.Oper/Estr;F.Liquid;Conc.;P/C;Importe;Div;Canal;Contrapartida;Estado;Sit.Corresp.;Proc.;Cl. Externa;Cl. GID;"
				+ "NominaPa;NominaRe;EntiOper;OficinaBs;Fecha Conf;Dias Conf-Pago;Confirmada;Su Referencia;Conciliada";

		if (listaVistaLiqui != null && listaVistaLiqui.size() > 0) {

			SQLQuery sql = listaVistaLiqui.get(0).getSqlQuery();
			sqlTxt = sql.getQueryString();
			for (String param : sql.getNamedParameters()) {
				sustitucion = obtenerSustitucion(param, caso2);
				param = ":".concat(param);

				sqlTxt = sqlTxt.replaceAll(param, sustitucion);
			}
			Long peticion = liquidacionesBo.generarPeticionExcel(sqlTxt,
					sqlHeader, caso);

			String mensaje = ResourceBundle.instance().getString(
					"liquidaciones.registros.validadosBatch")
					+ " " + peticion;
			statusMessages.add(Severity.INFO, mensaje);

		}
	}

	private String obtenerSustitucion(String param, String caso) {

		SimpleDateFormat sdf = new SimpleDateFormat(Constantes.DDMMYYYY);
		SimpleDateFormat sdf2 = new SimpleDateFormat(Constantes.YYYYMMDD);

		if ("rownumMin".equalsIgnoreCase(param)) {
			return paginationData.getPaginationDataForExcel().getFirstResult()
					.toString();
		} else if ("rownumMax".equalsIgnoreCase(param)) {
			return paginationData.getPaginationDataForExcel().getMaxResults()
					.toString();
		} else if ("modelopr".equalsIgnoreCase(param)) {
			if ("AGENDA".equals(caso)) {
				return parametrosOutAgenda.getModeloPr() == null ? "null"
						: "'"
								.concat(
										parametrosOutAgenda.getModeloPr()
												.getModelpro()).concat("'");
			}
			return "'".concat(
					liquidacionesCOLATPantalla.getModeloProductoSelect()
							.getCodigo()).concat("'");
		} else if ("situaliq".equalsIgnoreCase(param)) {
			return "'".concat(
					liquidacionesCOLATPantalla.getSitCorrespSelect()
							.getCodigo()).concat("'");
		} else if ("estadoco".equalsIgnoreCase(param)) {
			return liquidacionesCOLATPantalla.getEstadoLiqSelect() == null ? "null"
					: "'".concat(
							liquidacionesCOLATPantalla.getEstadoLiqSelect()
									.getCodigo()).concat("'");
		} else if ("contrapa".equalsIgnoreCase(param)) {
			return "'".concat(
					liquidacionesCOLATPantalla.getContrapartidaSelect())
					.concat("'");
		} else if ("divisapa".equalsIgnoreCase(param)) {
			return "'".concat(
					liquidacionesCOLATPantalla.getDivPagoSelect().getId())
					.concat("'");
		} else if ("divisare".equalsIgnoreCase(param)) {
			return "'".concat(
					liquidacionesCOLATPantalla.getDivCobroSelect().getId())
					.concat("'");
		} else if ("estructIni".equalsIgnoreCase(param)) {
			return liquidacionesCOLATPantalla.getNumEstructDesde().toString();
		} else if ("estructFin".equalsIgnoreCase(param)) {
			return liquidacionesCOLATPantalla.getNumEstructHasta().toString();
		} else if ("ncorrelaIni".equalsIgnoreCase(param)) {
			if ("AGENDA".equals(caso)) {
				return (parametrosOutAgenda.getNcorrelaIni() == null ? "null"
						: parametrosOutAgenda.getNcorrelaIni().toString());
			}
			return (liquidacionesCOLATPantalla.getNumOperDesde() == null ? "null"
					: liquidacionesCOLATPantalla.getNumOperDesde().toString());
		} else if ("ncorrelaFin".equalsIgnoreCase(param)) {
			if ("AGENDA".equals(caso)) {
				return (parametrosOutAgenda.getNcorrelaFin() == null ? "null"
						: parametrosOutAgenda.getNcorrelaFin().toString());
			}
			return (liquidacionesCOLATPantalla.getNumOperHasta() == null ? "null"
					: liquidacionesCOLATPantalla.getNumOperHasta().toString());
		} else if ("claveBDUIni".equalsIgnoreCase(param)) {
			return "'".concat(liquidacionesCOLATPantalla.getGuidDesde())
					.concat("'");
		} else if ("claveBDUFin".equalsIgnoreCase(param)) {
			return "'".concat(liquidacionesCOLATPantalla.getGuidHasta())
					.concat("'");
		} else if ("claveExternaIni".equalsIgnoreCase(param)) {
			return liquidacionesCOLATPantalla.getClaveExternaDesde().toString();
		} else if ("claveExternaFin".equalsIgnoreCase(param)) {
			return liquidacionesCOLATPantalla.getClaveExternaHasta().toString();
		} else if ("fechaOpe".equalsIgnoreCase(param)) {
			if ("AGENDA".equals(caso)) {
				return "'".concat(
						sdf.format(parametrosOutAgenda.getFechaOpe())
								.toString()).concat("'");
			}
			return "";
		} else if ("fechaLiqIni".equalsIgnoreCase(param)) {
			return "'".concat(
					sdf
							.format(
									liquidacionesCOLATPantalla
											.getFechaLiquidDesde()).toString())
					.concat("'");
		} else if ("fechaLiqFin".equalsIgnoreCase(param)) {
			return "'".concat(
					sdf
							.format(
									liquidacionesCOLATPantalla
											.getFechaLiquidHasta()).toString())
					.concat("'");
		} else if ("tipoContrapartida".equalsIgnoreCase(param)) {
			return "'".concat(
					liquidacionesCOLATPantalla.getTipoContrapa().getId())
					.concat("'");
		} else if ("importeDesde".equalsIgnoreCase(param)) {
			return liquidacionesCOLATPantalla.getImporteDesde().toString();
		} else if ("importeHasta".equalsIgnoreCase(param)) {
			return liquidacionesCOLATPantalla.getImporteHasta().toString();
		} else if ("suReferencia".equalsIgnoreCase(param)) {
			return "'".concat(liquidacionesCOLATPantalla.getSuReferencia())
					.concat("'");
		} else if ("idConciliada".equalsIgnoreCase(param)) {
			return (liquidacionesCOLATPantalla.getIdConciliada() ? "'S'"
					: "null");
		} else if ("codEvent".equalsIgnoreCase(param)) {
			return parametrosOutAgenda.getCodevent().toString();
			// return "1";
		} else if ("fechaMis".equalsIgnoreCase(param)) {
			Date fechamis = liquidacionesBo.obtenerFechaSistema(); // Recuperamos
																	// la fecha
																	// del
																	// sistema
			return "'".concat(sdf2.format(fechamis).toString()).concat("'");
		} else if ("fechaTraFin".equalsIgnoreCase(param)) {
			return "'"
					.concat(
							sdf.format(parametrosOutAgenda.getFechatraFin())
									.toString()).concat("'");
		} else if ("fechaTraIni".equalsIgnoreCase(param)) {
			return "'"
					.concat(
							sdf.format(parametrosOutAgenda.getFechatraIni())
									.toString()).concat("'");
		} else if ("estadoEv".equalsIgnoreCase(param)) {
			return "'".concat(parametrosOutAgenda.getEstadoEv()).concat("'");
		} else if ("estadoConfirmacion".equalsIgnoreCase(param)) {
			return "1";
		} else {
			return "1";
		}
	}

	@Override
	public void refrescarListaExcel() {
		setExportExcel(true);
		rellenarLista(paginationData.getPaginationDataForExcel(), false);
	}

	public void excelBatch() {
		setExportExcel(true);
		rellenarLista(paginationData.getPaginationDataForExcel(), true);
	}

	@SuppressWarnings("unchecked")
	@Override
	public void setDataTableList(List<?> dataTableList) {
		liquidacionesCOLATPantalla
				.setListaVistaLiqui((List<VistaLiquidacion>) dataTableList);
	}
	
	
	public boolean buscarValidator() {
		if (!GenericUtils.isNullOrBlank(liquidacionesCOLATPantalla
				.getFechaLiquidDesde())
				&& !GenericUtils.isNullOrBlank(liquidacionesCOLATPantalla
						.getFechaLiquidHasta())
				&& liquidacionesCOLATPantalla.getFechaLiquidDesde().after(
						liquidacionesCOLATPantalla.getFechaLiquidHasta())) {
			statusMessages.add(Severity.ERROR,
					"#{messages['liquidaciones.error.fechaIniSuperior']}");
			return false;
		}
		if (!GenericUtils.isNullOrBlank(liquidacionesCOLATPantalla
				.getNumOperDesde())
				&& !GenericUtils.isNullOrBlank(liquidacionesCOLATPantalla
						.getNumOperHasta())
				&& liquidacionesCOLATPantalla.getNumOperDesde() > liquidacionesCOLATPantalla
						.getNumOperHasta()) {
			statusMessages.add(Severity.ERROR,
					"#{messages['liquidaciones.error.ncorrelaIniSuperior']}");
			return false;
		}
		if (!GenericUtils.isNullOrBlank(liquidacionesCOLATPantalla
				.getNumEstructDesde())
				&& !GenericUtils.isNullOrBlank(liquidacionesCOLATPantalla
						.getNumEstructHasta())
				&& liquidacionesCOLATPantalla.getNumEstructDesde() > liquidacionesCOLATPantalla
						.getNumEstructHasta()) {
			statusMessages.add(Severity.ERROR,
					"#{messages['liquidaciones.error.estruturaIniSuperior']}");
			return false;
		}
		return true;
	}

	public void buscar() throws InterruptedException {

		if (!liquidacionesBo.crearBloqueo2Cover()) {
			statusMessages.addFromResourceBundle(Severity.ERROR, "Otro usuario está realizando la búsqueda.");
		} else {
			ultimRegistre = 0;
			paginationData.reset();
			this.liquidacionesCOLATPantalla.getSelectedLiquiDataList().clear();
			this.liquidacionesCOLATPantalla.setSelecTodos(false);
			setPrimerAcceso(false);		
			liquidar2Cover();
			refrescarLista();
			liquidacionesBo.desBloqueo2Cover();			
		}
	}

	public void buildListasProductos() {
		ModeloColat modeloProducto = liquidacionesCOLATPantalla
				.getModeloProductoSelect();
	}

	// ### FUNCIONES PARA GESTIONAR LOS CHECKBOX ###

	/**
	 * Cada vez que se selecciona/deselecciona una liquidaciones se actualiza la
	 * lista de las seleccionadas y se comprueba si están habilitados los
	 * botones validar y anular
	 */
	public void seleccionarLiquidaciones() {

	}

	public Boolean getSelectedRow() {
		this.liquidacionesCOLATPantalla.getSelectedLiquiDataList().size();
		return this.liquidacionesCOLATPantalla
				.getSelectedLiquiDataList()
				.contains(this.liquidacionesCOLATPantalla.getVistaLiquiSelect());
	}

	public void setSelectedRow(Boolean selected) {
		if (selected) {
			this.liquidacionesCOLATPantalla.getSelectedLiquiDataList().add(
					this.liquidacionesCOLATPantalla.getVistaLiquiSelect());
		} else {
			this.liquidacionesCOLATPantalla.getSelectedLiquiDataList().remove(
					this.liquidacionesCOLATPantalla.getVistaLiquiSelect());
			this.liquidacionesCOLATPantalla.setSelecTodos(false);
		}
	}

	/** Seleccionar o deseleccionar todos los checks del datagrid */
	public void seleccionarTodos() {

		// Lo primero es saber si tenemos que seleccionar o deseleccionar todos.
		// 1- Caso deseleccionar
		if (liquidacionesCOLATPantalla.getSelecTodos()) {

			if (!GenericUtils.isNullOrBlank(this.liquidacionesCOLATPantalla
					.getSelectedLiquiDataList())) {
				this.liquidacionesCOLATPantalla.getSelectedLiquiDataList()
						.clear();
			}

			this.liquidacionesCOLATPantalla.setSelecTodos(false);

		} else { // Caso seleccionar

			Integer minResul = paginationData.getFirstResult();
			Integer maxResul = paginationData.getMaxResults();
			int tamanyoLista = 0;
			VistaLiquidacion vistaLiqui;

			paginationData.setFirstResult(0);
			paginationData
					.setMaxResults(Constantes.MAX_RESULTS_SELECCION_TOTAL_2000);

			listaTemp = listaSeleccionarTodos();

			paginationData.setMaxResults(maxResul);
			paginationData.setFirstResult(minResul);

			if (!GenericUtils.isNullOrBlank(listaTemp)) {
				this.liquidacionesCOLATPantalla.getSelectedLiquiDataList()
						.addAll(listaTemp);
			}
			this.liquidacionesCOLATPantalla.setSelecTodos(true);
		}
	}

	// ### FIN CHECKBOX ###

	public void preLiquidar() {

		msgBoxAction.mostrarMsg("#{liquidacionesCOLATAction.liquidar}",
				"#{liquidacionesCOLATAction.salirSinValidar}",
				ResourceBundle.instance().getString(
						"liquidaciones.confirmar.liquidar"));
	}
	
	public void preLiquidarManual() {

		msgBoxAction.mostrarMsg("#{liquidacionesCOLATAction.liquidarManual}",
				"#{liquidacionesCOLATAction.salirSinValidar}",
				ResourceBundle.instance().getString(
						"liquidaciones.confirmar.liquidarmanual"));
	}
	
	/**
	 * Recoge la lista de liquidaciones seleccionadas y las bloquea para que
	 * nadie más pueda editarlas. Si alguna ya está bloqueada, se muestra un
	 * mensaje al usuario indicándole los motivos por los que no puede validarla
	 */
	public void preValidar() {

		boolean hayBloqueadas = false;
		liquidacionesBloqueadas = new ArrayList<VistaLiquidacion>();

		// recorremos la lista de liquidaciones seleccionadas
		for (VistaLiquidacion vistaLiquidacion : liquidacionesCOLATPantalla
				.getSelectedLiquiDataList()) {
			// bloqueamos los registros marcados que tengan estado pendiente de
			// validar
			if (Constantes.LIQUIDACION_PDTE_VALIDAR.equals(vistaLiquidacion
					.getEstado())) {
				if (bloquearLiquidacion(vistaLiquidacion,
						Constantes.LIQUIDACION_ACCION_VALIDAR)) {
					liquidacionesBloqueadas.add(vistaLiquidacion);
				} else {
					hayBloqueadas = true;
				}
			}
		}

		/*
		 * Si no había registros bloqueados, mostramos mensaje de confirmación
		 * al usuario para que decida si quiere continuar con la validacion. Si
		 * dice que no, o había registros bloqueados, se llama a salirSinValidar
		 * para finalizar la ejecución y desbloquear todos los registros
		 * previamente bloqueados
		 */
		if (!hayBloqueadas) {
			msgBoxAction.mostrarMsg("#{liquidacionesCOLATAction.validarFase1}",
					"#{liquidacionesCOLATAction.salirSinValidar}",
					ResourceBundle.instance().getString(
							"liquidaciones.confirmar.validar"));
		} else {
			salirSinValidar();
		}
	}

	/**
	 * Necesario para salir sin validar cuando el usuario cancela el proceso
	 * desde un messageBox de decisión Desbloquea todos los registros
	 * previamente bloqueados
	 */
	public void salirSinValidar() {

		if (this.getLiquidacionesBloqueadas() != null) {
			for (VistaLiquidacion vistaLiquidacion : this
					.getLiquidacionesBloqueadas()) {
				dbLockService.desbloqueo(Liquidacion.class, vistaLiquidacion
						.getId());
			}
		}

		if (listaConfirmacionesRendered) {
			setListaConfirmacionesRendered(false);
		}

		if (liquidacionesCOLATPantalla.getLiquidacionesMsg() != null) {
			liquidacionesCOLATPantalla.getLiquidacionesMsg().clear();
		}
	}

	/**
	 * Realiza la validación de una liquidación, es decir, pone su estado a
	 * 'Validado' hace una primera pasada, comprobando si hay algún mensaje de
	 * decisión que mostrar al usuario. Si no lo hay, procede a la validación
	 * invocando a validarFase2. Si hay mensajes, redirige a una pantalla donde
	 * se muestran al usuario dichos mensajes para que tome una decisión por
	 * cada uno de ellos.
	 */
	public void validarFase1() {

		/*
		 * Instanciamos un nuevo hashmap donde guardaremos la información sobre
		 * los mensajes a mostrar para cada liquidación, así como la decisión
		 * adoptada por el usuario (al principio por defecto marcamos todas como
		 * NO)
		 */
		liquidacionesMsg = new HashMap<MensajesValidacionId, MensajesValidacion>();
		liquidacionesCOLATPantalla.setErrores(new ArrayList<String>());
		liquidacionesCOLATPantalla.setLiquidacionesMsg(liquidacionesMsg);

		/*
		 * Hacemos una primera pasada por los métodos de validar sin ejecutar
		 * ninguna transacción en la base de datos. Lo que hacemos es para cada
		 * liquidación, hacer todas las comprobaciones e ir almacenando todos
		 * los mensajes de decisión que se deban mostrar al usuario, sin hacer
		 * ningún cambio ni en las variables locales ni en base de datos.
		 */
		liquidacionesBo.tratamientoValidar(this.getLiquidacionesBloqueadas(),
				liquidacionesMsg, true, null, Constantes.NOMBRE_PROYECTO_COLAT);

		/*
		 * Si no tenemos ningún mensaje que mostrar ejecutamos una segunda
		 * pasada a los métodos de validar pero esta vez llevamos a cabo las
		 * modificaciones que sean necesarias tanto sobre las variables locales
		 * como en base de datos
		 */
		if (liquidacionesMsg.isEmpty()) {
			ArrayList<String> errores = new ArrayList<String>();
			if (liquidacionesCOLATPantalla.getErrores() != null)
				errores.addAll(liquidacionesCOLATPantalla.getErrores());
			int valid = 0;
			listaConfirmacionesRendered = false;
			valid = liquidacionesBo.tratamientoValidar(this
					.getLiquidacionesBloqueadas(), liquidacionesMsg, false,
					errores,Constantes.NOMBRE_PROYECTO_COLAT);
			liquidacionesCOLATPantalla.setRegistrosValidados(valid);
			liquidacionesCOLATPantalla.setErrores(errores);
			validarFase2();
		} else {
			/*
			 * Mostraremos al usuario una pantalla donde se listen para cada
			 * liquidación todas las decisiones que debe tomar. Con las
			 * decisiones que tome modificaremos los elementos del HashMap como
			 * sea necesario. Habrá un botón aceptar que al ser pulsado llamará
			 * a validarFase2 y a partir de ahí se trabajará como en el caso de
			 * que no hubiera mensajes que mostrar
			 */
			liquidacionesCOLATPantalla.setRegistrosValidados(0);
			listaConfirmacionesRendered = true;
		}

		/*
		 * Retornamos success si no hay mensajes a mostrar, para que después de
		 * validar se quede en la misma pantalla. Retornamos failure si hay
		 * algún mensaje a mostrar, para que vaya a la pantalla donde el usuario
		 * verá todos los mensajes de decisión que debe responder
		 */
	}

	public void validarFaseErrores() {

		boolean hayMensajes = false;
		ArrayList<String> errores = new ArrayList<String>();
		int validados = liquidacionesCOLATPantalla.getRegistrosValidados();

		validados = validados
				+ liquidacionesBo.tratamientoValidar(this
						.getLiquidacionesBloqueadas(),
						liquidacionesCOLATPantalla.getLiquidacionesMsg(),
						false, errores,Constantes.NOMBRE_PROYECTO_COLAT);
		liquidacionesCOLATPantalla.setRegistrosValidados(validados);
		liquidacionesCOLATPantalla.getErrores().addAll(errores);

		for (Entry<MensajesValidacionId, MensajesValidacion> entry : liquidacionesMsg
				.entrySet()) {
			if (!entry.getValue().isHaSidoRespondido()
					&& !Constantes.LIQUIDACION_VALIDADA.equals(entry.getKey()
							.getLiquidacion().getEstado())) {

				hayMensajes = true;
			}

		}
		if (!hayMensajes) {
			listaConfirmacionesRendered = false;
			validarFase2();
		} else {
			listaConfirmacionesRendered = true;
		}

	}

	/**
	 * Ejecuta la segunda fase de la validación, una vez el usuario ha
	 * respondido a todos los posibles mensajes de decisión
	 */
	public void validarFase2() {
		ArrayList<String> errores = new ArrayList<String>();

		if (liquidacionesCOLATPantalla.getErrores() != null)
			errores.addAll(liquidacionesCOLATPantalla.getErrores());

		int validados = liquidacionesCOLATPantalla.getRegistrosValidados();
		if (listaConfirmacionesRendered) { // cerramos el popup con la lista de
											// confirmaciones
			setListaConfirmacionesRendered(false);
		}

		/*
		 * Recogemos el hashmap que tendrá los valores SI/NO escogidos por el
		 * usuario para cada mensaje de decisión y ejecutamos la lógica de
		 * validación completa, realizando las modificaciones en variables y en
		 * bbdd que se necesiten
		 */

		// Si se produjeron errores
		if (!GenericUtils.isNullOrBlank(errores) && !errores.isEmpty()) {
			// Mostramos en el messagepanel todos los errores que se hayan
			// producido

			List<String> duplicados = new ArrayList<String>();
			for (String error : errores) {
				if (!duplicados.contains(error)) {
					duplicados.add(error);
					statusMessages.add(Severity.ERROR, error);
				}
			}
		}

		// Al terminar desbloqueamos todos los registros y desmarcamos los check
		for (VistaLiquidacion vistaLiquidacion : this
				.getLiquidacionesBloqueadas()) {
			dbLockService.desbloqueo(Liquidacion.class, vistaLiquidacion
					.getId());
			liquidacionesCOLATPantalla.getSelectedLiquiDataList().remove(
					vistaLiquidacion);
			// liquidacionesCOLATPantalla.getSelectedLiquiIds().remove(vistaLiquidacion.getId());
		}

		// Mostramos mensaje con el número de registros actualizados
		String mensaje = validados
				+ " "
				+ ResourceBundle.instance().getString(
						"liquidaciones.registros.validados");
		statusMessages.add(Severity.INFO, mensaje);
		refrescarLista();

	}

	/**
	 * Realiza la desvalidación de una liquidación, es decir, pone su estado a
	 * 'Desvalidado'
	 * 
	 */
	public void desValidarColat() {
		int contadorValidadas = 0;
		for (VistaLiquidacion vistaLiq : liquidacionesCOLATPantalla
				.getSelectedLiquiDataList()) {

			if (Constantes.LIQUIDACION_VALIDADA.equals(vistaLiq.getEstado())
					&& vistaLiq.getLiqOriginal() == null) {

				if (this.bloquearLiquidacion(vistaLiq, "desvalidar")) {

					Liquidacion liquidacion = liquidacionesBo.cargar(vistaLiq
							.getId());
					vistaLiq.setEstado(Constantes.LIQUIDACION_PDTE_VALIDAR);
					try {
						vistaLiq.setEstado(Constantes.LIQUIDACION_VALIDADA);
						liquidacionesBo.desvalidarLiquidacion(liquidacion);
						// liquidacionesCOLATPantalla.getSelectedLiquiDataList().remove(vistaLiq);
						liquidacionesBo.flush();
						liquidacionesBo.cargar(liquidacion.getId());
						contadorValidadas++;
					} catch (RollbackException r) {
						statusMessages.add(Severity.ERROR,
								"#{messages['liquidaciones.error.rollback']}");
						throw new RollbackException();
					} finally {
						dbLockService.desbloqueo(Liquidacion.class, vistaLiq
								.getId());
					}

				}

			}
		}
		liquidacionesCOLATPantalla.getSelectedLiquiDataList().clear();
		statusMessages.addFromResourceBundle(Severity.INFO,
				"liquidaciones.info.desvalidadas", contadorValidadas);
		refrescarLista();
	}

	/**
	 * Método que se ejecuta cada vez que se entra en la página
	 */
	public void mostrarListado() {

	}

	/**
	 * Prepara para la edición de una liquidación
	 */
	public String editar() {

		liquidacionesCOLATPantalla.copiarSeleccionado();
		recuperarDatosLiquidacion();

		if (Constantes.CANAL_SWIFT.equalsIgnoreCase(liquidacionesCOLATPantalla
				.getVistaLiqui().getCanaliqi())
				|| Constantes.CANAL_TARGET
						.equalsIgnoreCase(liquidacionesCOLATPantalla
								.getVistaLiqui().getCanaliqi())) {
			this.setPanelSwiftRendered(true);
		} else {
			this.setPanelSwiftRendered(false);
		}

		setModoPantalla(ModoPantalla.EDICION);
		generarCabecera();

		return liquidacionesCOLATPantalla.getVistaLiqui().getDescrTipOpera();

	}

	/** Construye la cadena de texto a mostrar en la cabecera */
	private void generarCabecera() {
		if ("R".equalsIgnoreCase(liquidacionesCOLATPantalla.getVistaLiqui()
				.getTipopera())) { // Si es recibo
			StringBuffer titulo = new StringBuffer();
			titulo.append(ResourceBundle.instance().getString(
					"liquidaciones.detalle.recibo.titulo"));
			titulo.append(" ");
			titulo.append(liquidacionesCOLATPantalla.getVistaLiqui()
					.getConcepto());
			liquidacionesCOLATPantalla.setCabecera(titulo.toString());
		}
	}

	/**
	 * Validaciones previas a la edición de la liquidación recibo. Los Campos de
	 * la cesión pueden estar todos vacios. Pero si hay algún campo informado,
	 * entonces los campos ENTIDDES, OFICIDES, DEPARDES, TIPOFICH, DIVISACE,
	 * OFIEMISOM, CODESTAD, CODIPAIS, NIFTITUL son obligatorios
	 */
	public boolean guardarLiquidacionReciboValidator() {

		boolean esCorrecto = true;

		VistaLiquidacion vistaLiquidacion = liquidacionesCOLATPantalla
				.getVistaLiqui();
		//Date fechamis = liquidacionesBo.obtenerFechaSistema(); // Recuperamos la
																// fecha del
																// sistema

		esCorrecto = validaCuenta(vistaLiquidacion);

		if ("SWF".equalsIgnoreCase(vistaLiquidacion.getCanaliqi())
				&& !GenericUtils.isNullOrBlank(vistaLiquidacion.getSwift()
						.getFechaenv())) {

			SimpleDateFormat sdf = new SimpleDateFormat(Constantes.DDMMYYYY);
			Date sysdate;
			Date fechaEnvio;

			try {
				sysdate = sdf.parse(sdf.format(new Date()));
				fechaEnvio = sdf.parse(sdf.format(vistaLiquidacion.getSwift()
						.getFechaenv()));
			} catch (ParseException e) {
				sysdate = new Date();
				fechaEnvio = vistaLiquidacion.getSwift().getFechaenv();
			}

			if (fechaEnvio.compareTo(sysdate) < 0) {
				esCorrecto = false;
				statusMessages.addToControl("fechaEnvTxt", Severity.ERROR,
						"#{messages['liquidaciones.error.fenv.incorrecta']}");
			}

		} else if ("50".equals(vistaLiquidacion.getGruconta())
				&& vistaLiquidacion.getOficonta() == 901) {
			esCorrecto = false;
			statusMessages.addToControl("grupConCmb", Severity.ERROR,
					"#{messages['liquidaciones.error.grupcon.oficonta']}");

		} //else if (((vistaLiquidacion.getFechaliq().getTime() - fechamis
		//		.getTime()) / 86400000L) < 0) {
		//	esCorrecto = false;
		//	statusMessages.addToControlFromResourceBundle("fLiquiTxt",
		//			Severity.ERROR, "liquidaciones.error.fliq.incorrecta",
		//			fechamis);
		//}

		if (!GenericUtils.isNullOrBlank(vistaLiquidacion.getCesion())
				&& !GenericUtils.isNullOrBlank(vistaLiquidacion.getCesion()
						.getEntiddes())) {
			if (!liquidacionesBo.comprobarEntidad(vistaLiquidacion.getCesion()
					.getEntiddes())) {
				statusMessages.addToControlFromResourceBundle("txtentidadRb",
						Severity.ERROR, "liquidaciones.error.entidad",
						vistaLiquidacion.getCesion().getEntiddes());
				esCorrecto = false;
			}
		}

		return esCorrecto;
	}

	private boolean validaCuenta(VistaLiquidacion vistaLiquidacion) {
		boolean esCorrecto = true;
		/* Los campos de la cuenta o están informados todos o ninguno. */
		boolean ofiContaInformado = !GenericUtils
				.isNullOrBlank(vistaLiquidacion.getOficonta());
		boolean ctaContaInformado = !GenericUtils
				.isNullOrBlank(vistaLiquidacion.getCtaconta());
		boolean chkContaInformado = !GenericUtils
				.isNullOrBlank(vistaLiquidacion.getChkconta());
		boolean gruContaInformado = !GenericUtils
				.isNullOrBlank(vistaLiquidacion.getGruconta());

		boolean algunoInformado = ofiContaInformado || ctaContaInformado
				|| chkContaInformado || gruContaInformado;
		boolean todosInformados = ofiContaInformado && ctaContaInformado
				&& chkContaInformado && gruContaInformado;

		if (algunoInformado && !todosInformados) {
			esCorrecto = false;
			statusMessages.add(Severity.ERROR,
					"#{messages['liquidaciones.error.cuenta.noinformados']}");
		}
		return esCorrecto;
	}

	/**
	 * Guarda el objeto liquidación con los cambios introducidos por el usuario
	 * en bbdd
	 */
	public String guardarLiquidacionRecibo() {

		VistaLiquidacion liqui = liquidacionesCOLATPantalla.getVistaLiqui();

		//SMM 20/10/2015
		if ("88".equalsIgnoreCase(liqui.getGruconta())){
			liqui.setSitualiq(SITUALIQ_PDR);	
		}else{
			liqui.setSitualiq(SITUALIQ_PDE);
		}
		

		liquidacionesBo.actualizarLiquidacion(liqui, liquidacionesCOLATPantalla
				.getProyecto());
		liquidacionesBo.actualizarCesion(liquidacionesCOLATPantalla
				.getVistaLiqui());

		if ("SWF".equals(liqui.getCanaliqi())) {
			Date fechaEnvio = liqui.getSwift().getFechaenv();
			Date fechaEnvioOriginal = liquidacionesBo
					.obtenerFechaEnvSwift(liqui.getId());

			// Si se ha cambiado la fecha de envío se actualiza el swift en bbdd
			if (!GenericUtils.isNullOrBlank(fechaEnvioOriginal)
					&& !GenericUtils.isNullOrBlank(fechaEnvio)) {

				long diffFechas = (fechaEnvio.getTime() - fechaEnvioOriginal
						.getTime()) / 86400000L;

				if (diffFechas != 0) {
					liquidacionesBo.actualizarSwift(fechaEnvio, liqui);
				}
			}
		}

		return Constantes.CONSTANTE_SUCCESS;
	}

	/**
	 * 
	 * @return
	 */
	public String ver() {

		liquidacionesCOLATPantalla.copiarSeleccionado();
		recuperarDatosLiquidacion();
		generarCabecera();
		setModoPantalla(ModoPantalla.INSPECCION);

		if (Constantes.CANAL_SWIFT.equalsIgnoreCase(liquidacionesCOLATPantalla
				.getVistaLiqui().getCanaliqi())
				|| Constantes.CANAL_TARGET
						.equalsIgnoreCase(liquidacionesCOLATPantalla
								.getVistaLiqui().getCanaliqi())) {
			this.setPanelSwiftRendered(true);
		} else {
			this.setPanelSwiftRendered(false);
		}

		return liquidacionesCOLATPantalla.getVistaLiqui().getDescrTipOpera();

	}

	public void descartarColat() {
		Boolean estadoIncorrecto = false;
		if (!GenericUtils.isNullOrBlank(liquidacionesCOLATPantalla
				.getSelectedLiquiDataList())
				&& liquidacionesCOLATPantalla.getSelectedLiquiDataList().size() > 0) {
			for (VistaLiquidacion vl : liquidacionesCOLATPantalla
					.getSelectedLiquiDataList()) {
				if (vl.getEstado().equals(Constantes.LIQUIDACION_PDTE_VALIDAR)
						|| (vl.getEstado().equals(
								Constantes.LIQUIDACION_VALIDADA) && vl
								.getLiqOriginal() == null)) {
					if (!bloquearLiquidacion(vl,
							Constantes.LIQUIDACION_ACCION_DESCARTAR)) {
						return;
					} else {
						liquidacionesBo.descartarColat(vl);
						dbLockService.desbloqueo(Liquidacion.class, vl.getId());
					}
				} else {
					estadoIncorrecto = true;
				}
			}
		}
		if (estadoIncorrecto) {
			statusMessages.addFromResourceBundle(Severity.WARN,
					"liquidacion.descartar.aviso");
		}
		liquidacionesCOLATPantalla.getSelectedLiquiDataList().clear();
		refrescarLista();
	}

	public boolean bloquearLiquidacion(VistaLiquidacion vistaLiquidacion,
			String accion) {

		String tipoOpera = null;
		if (vistaLiquidacion.getDescrTipOpera().equals(
				Constantes.LIQUIDACION_TIPOPERA_P)) {
			tipoOpera = Constantes.LIQUIDACION_TIPOPERA_PAGO;
		} else {
			tipoOpera = Constantes.LIQUIDACION_TIPOPERA_COBRO;
		}
		// si devuelve false es que el registro ya está bloqueado
		if (!dbLockService.bloqueo(Liquidacion.class, vistaLiquidacion.getId())) {
			statusMessages.addFromResourceBundle(Severity.ERROR,
					"liquidaciones.error.noBloqueo", vistaLiquidacion
							.getnCorrelaEstructura(), vistaLiquidacion
							.getDescrProducto(),
					vistaLiquidacion.getFechaliq(), tipoOpera, vistaLiquidacion
							.getImportel(), accion);
			return false;
		} else {
			Liquidacion liquidacion = liquidacionesBo.cargar(vistaLiquidacion
					.getId());
			if (GenericUtils.isNullOrBlank(liquidacion)) {
				statusMessages.addFromResourceBundle(Severity.ERROR,
						"liquidaciones.error.liquidacionInexistente",
						vistaLiquidacion.getnCorrelaEstructura(),
						vistaLiquidacion.getDescrProducto(), vistaLiquidacion
								.getFechaliq(), tipoOpera, vistaLiquidacion
								.getImportel(), accion);
				dbLockService.desbloqueo(Liquidacion.class, vistaLiquidacion
						.getId());
				return false;
			} else {
				Date d1 = new Date(liquidacion.getAuditData()
						.getFechaUltimaModi().getTime());
				Date d2 = new Date(vistaLiquidacion.getFeultact().getTime());
				if (d1.compareTo(d2) != 0) {
					statusMessages.addFromResourceBundle(Severity.ERROR,
							"liquidaciones.error.liquidacionYaModificada",
							vistaLiquidacion.getnCorrelaEstructura(),
							vistaLiquidacion.getDescrProducto(),
							vistaLiquidacion.getFechaliq(), tipoOpera,
							vistaLiquidacion.getImportel(), accion,
							vistaLiquidacion.getFeultact());
					dbLockService.desbloqueo(Liquidacion.class,
							vistaLiquidacion.getId());
					return false;
				}
			}
		}
		// El registro sigue bloqueado
		return true;

	}

	public Boolean getValidarHabilitado() {
		setValidarHabilitado(false);
		if (!GenericUtils.isNullOrBlank(liquidacionesCOLATPantalla
				.getSelectedLiquiDataList())
				&& liquidacionesCOLATPantalla.getSelectedLiquiDataList().size() > 0) {
			for (VistaLiquidacion vl : liquidacionesCOLATPantalla
					.getSelectedLiquiDataList()) {
				if (vl.getEstado().equals(Constantes.LIQUIDACION_PDTE_VALIDAR)) {
					setValidarHabilitado(true);
					break;
				}
			}
		}
		return validarHabilitado;
	}

	public void setValidarHabilitado(Boolean validarHabilitado) {
		this.validarHabilitado = validarHabilitado;
	}

	public Boolean getDesValidarHabilitado() {
		setDesValidarHabilitado(false);
		if (!GenericUtils.isNullOrBlank(liquidacionesCOLATPantalla
				.getSelectedLiquiDataList())
				&& liquidacionesCOLATPantalla.getSelectedLiquiDataList().size() > 0) {
			for (VistaLiquidacion vl : liquidacionesCOLATPantalla
					.getSelectedLiquiDataList()) {
				if (vl.getEstado().equals(Constantes.LIQUIDACION_VALIDADA)
						&& vl.getLiqOriginal() == null) {
					setDesValidarHabilitado(true);
					break;
				}
			}
		}
		return desValidarHabilitado;
	}

	public void setDesValidarHabilitado(Boolean desValidarHabilitado) {
		this.desValidarHabilitado = desValidarHabilitado;
	}

	public void salir() {
		Conversation conversacion = Conversation.instance();
		// Volvemos a la anterior conversación
		if (conversacion.isNested()) {
			conversacion.redirectToParent();
		} else {
			redirectToURL("/home.seam");
			conversacion.endAndRedirect();
		}
	}

	public void salir2() {
		refrescarLista();
	}

	/**
	 * Carga la liquidacion de base de datos para recuperar, si los hay, los
	 * datos de cesiones y de Swift. Si no los hay, mostrará los campos
	 * correspondientes vacíos en el formulario
	 */
	private void recuperarDatosLiquidacion() {

		// Recuperamos los datos de cesiones y swift para el registro
		// seleccionado en el grid
		Liquidacion liquiAux = liquidacionesBo
				.cargar(liquidacionesCOLATPantalla.getVistaLiqui().getId());

		Cesiones cesionesLiquiSelec = liquiAux.getCesion();

		if (GenericUtils.isNullOrBlank(cesionesLiquiSelec)) {

			Cesiones cesionAlta = new Cesiones(new CesionesId(liquiAux));
			VistaLiquidacion vistaLiq = liquidacionesCOLATPantalla
					.getVistaLiqui();

			AuditData auditData = new AuditData();
			auditData.setUsuarioUltimaModi(Identity.instance().getCredentials()
					.getUsername());
			auditData.setFechaUltimaModi(new Date());

			cesionAlta.setAuditData(auditData);
			cesionAlta.setNcorrela(vistaLiq.getNcorrela());
			cesionAlta.setFechaope(vistaLiq.getFechaope());
			cesionAlta.setImportes(vistaLiq.getImportel());

			vistaLiq.setCesion(cesionAlta);

		} else {
			liquidacionesCOLATPantalla.getVistaLiqui().setCesion(
					cesionesLiquiSelec);
		}

		Swift swiftLiquiSelec = liquiAux.getSwift();

		if (GenericUtils.isNullOrBlank(swiftLiquiSelec)) {

			Swift swiftAlta = new Swift(new SwiftId(liquiAux));
			VistaLiquidacion vistaLiq = liquidacionesCOLATPantalla
					.getVistaLiqui();

			swiftAlta.setFechaliq(vistaLiq.getFechaliq());
			swiftAlta.setNcorrela(vistaLiq.getNcorrela());
			swiftAlta.setFechaope(vistaLiq.getFechaope());
			swiftAlta.setTipopera(vistaLiq.getTipopera());
			swiftAlta.setCodivisa(vistaLiq.getDivisali());

			liquidacionesCOLATPantalla.getVistaLiqui().setSwift(swiftAlta);

		} else {
			liquidacionesCOLATPantalla.getVistaLiqui()
					.setSwift(swiftLiquiSelec);
		}

	}

	/** Abre el popup de calificar cobro */
	public void calificarCobro() {
		// Copiamos el seleccionado
		liquidacionesCOLATPantalla.copiarSeleccionado();

		String situliq = liquidacionesCOLATPantalla.getVistaLiqui()
				.getSitualiq();

		// Deshabilitamos campos si es necesario
		if (SITUALIQ_PDR.equalsIgnoreCase(situliq)
				|| SITUALIQ_VEN.equalsIgnoreCase(situliq)) {
			this.camposCalificarDisabled = false;
		} else {
			this.camposCalificarDisabled = true;
		}

		String isForzar = liquidacionesCOLATPantalla.getVistaLiqui()
				.getIndforza();

		// Asignamos el valor al chechbox
		if (Constantes.CONSTANTE_SI.equalsIgnoreCase(isForzar)) {
			liquidacionesCOLATPantalla.setForzar(true);
		} else {
			liquidacionesCOLATPantalla.setForzar(false);
		}

		calificarRendered = true;
	}
	
	
	public boolean guardarCalificarCobroValidator(){
		
		boolean esCorrecto = true;
		
		VistaLiquidacion vista = liquidacionesCOLATPantalla.getVistaLiqui();
		
		if (GenericUtils.isNullOrZero(vista.getImpforza()) && 
				(!GenericUtils.isNullOrZero(vista.getImpforza2()) ||
				 !GenericUtils.isNullOrZero(vista.getImpforza3()) ||
				 !GenericUtils.isNullOrZero(vista.getImpforza4()) 
				)
		){
			statusMessages.add(Severity.ERROR, "#{messages['liquidaciones.error.importesDifLiq']}");
			esCorrecto = false;
		}else if (GenericUtils.isNullOrZero(vista.getImpforza2()) && 
				(!GenericUtils.isNullOrZero(vista.getImpforza3()) ||
				 !GenericUtils.isNullOrZero(vista.getImpforza4()) 
				)
		){

			statusMessages.add(Severity.ERROR, "#{messages['liquidaciones.error.importesDifLiq']}");
			esCorrecto = false;
 
		}else if (GenericUtils.isNullOrZero(vista.getImpforza3()) && 
				 !GenericUtils.isNullOrZero(vista.getImpforza4()) 
		){
			statusMessages.add(Severity.ERROR, "#{messages['liquidaciones.error.importesDifLiq']}");
			esCorrecto = false;

		}
		
		
		return esCorrecto;
	}	
	
	/**
	 * Realiza un update del registro correspondiente en la tabla deri.liquidac
	 * con los campos entrados
	 */
	public void guardarCalificarCobro() {

		VistaLiquidacion vista = liquidacionesCOLATPantalla.getVistaLiqui();

		if (liquidacionesCOLATPantalla.isForzar()) {
			vista.setIndforza(Constantes.CONSTANTE_SI);
		} else {
			vista.setIndforza(Constantes.CONSTANTE_NO);
		}

		liquidacionesBo.actualizarCalificarCobro(vista);

		this.setCalificarRendered(false); // Cerramos el PopUp
	}

	public HashMap<MensajesValidacionId, MensajesValidacion> getItems() {
		return liquidacionesCOLATPantalla.getLiquidacionesMsg();
	}

	public List<MensajesValidacionId> getItemKeys() {
		List<MensajesValidacionId> keys = new ArrayList<MensajesValidacionId>();

		for (Entry<MensajesValidacionId, MensajesValidacion> entry : liquidacionesCOLATPantalla
				.getLiquidacionesMsg().entrySet()) {

			if (!entry.getValue().isHaSidoRespondido()) {
				keys.add(entry.getKey());
			}

		}

		return keys;
	}

	public LiquidacionesBo getLiquidacionesBo() {
		return liquidacionesBo;
	}

	public void setLiquidacionesBo(LiquidacionesBo liquidacionesBo) {
		this.liquidacionesBo = liquidacionesBo;
	}

	public LiquidacionesCOLATPantalla getliquidacionesCOLATPantalla() {
		return liquidacionesCOLATPantalla;
	}

	public void setliquidacionesCOLATPantalla(
			LiquidacionesCOLATPantalla liquidacionesCOLATPantalla) {
		this.liquidacionesCOLATPantalla = liquidacionesCOLATPantalla;
	}

	public DbLockService getDbLockService() {
		return dbLockService;
	}

	public void setDbLockService(DbLockService dbLockService) {
		this.dbLockService = dbLockService;
	}

	public boolean isCamposCalificarDisabled() {
		return camposCalificarDisabled;
	}

	public void setCamposCalificarDisabled(boolean camposCalificarDisabled) {
		this.camposCalificarDisabled = camposCalificarDisabled;
	}

	public boolean isNullorZero(BigDecimal importe){
		return GenericUtils.isNullOrZero(importe);
	}

	public void onChangeImpforza(){
		 if (GenericUtils.isNullOrZero(liquidacionesCOLATPantalla.getVistaLiqui().getImpforza())){
			 liquidacionesCOLATPantalla.getVistaLiqui().setImpforza2(null);
			 liquidacionesCOLATPantalla.getVistaLiqui().setImpforza3(null);
			 liquidacionesCOLATPantalla.getVistaLiqui().setImpforza4(null);
		 }
	}
	
	public void onChangeImpforza2(){
		 if (GenericUtils.isNullOrZero(liquidacionesCOLATPantalla.getVistaLiqui().getImpforza2())){
			 liquidacionesCOLATPantalla.getVistaLiqui().setImpforza3(null);
			 liquidacionesCOLATPantalla.getVistaLiqui().setImpforza4(null);
		 }
	}

	public void onChangeImpforza3(){
		 if (GenericUtils.isNullOrZero(liquidacionesCOLATPantalla.getVistaLiqui().getImpforza3())){
			 liquidacionesCOLATPantalla.getVistaLiqui().setImpforza4(null);
		 }
	}
	

	
	public boolean isCalificarRendered() {
		return calificarRendered;
	}

	public void setCalificarRendered(boolean calificarRendered) {
		this.calificarRendered = calificarRendered;
	}

	public boolean isPanelSwiftRendered() {
		return panelSwiftRendered;
	}

	public void setPanelSwiftRendered(boolean panelSwiftRendered) {
		this.panelSwiftRendered = panelSwiftRendered;
	}

	public List<VistaLiquidacion> getLiquidacionesBloqueadas() {
		return liquidacionesBloqueadas;
	}

	public void setLiquidacionesBloqueadas(
			List<VistaLiquidacion> liquidacionesBloqueadas) {
		this.liquidacionesBloqueadas = liquidacionesBloqueadas;
	}

	public boolean isListaConfirmacionesRendered() {
		return listaConfirmacionesRendered;
	}

	public void setListaConfirmacionesRendered(
			boolean listaConfirmacionesRendered) {
		this.listaConfirmacionesRendered = listaConfirmacionesRendered;
	}

	public HashMap<MensajesValidacionId, MensajesValidacion> getLiquidacionesMsg() {
		return liquidacionesMsg;
	}

	public void setLiquidacionesMsg(
			HashMap<MensajesValidacionId, MensajesValidacion> liquidacionesMsg) {
		this.liquidacionesMsg = liquidacionesMsg;
	}

	public void recargarLista() {
		refrescarLista();
		List<VistaLiquidacion> listaVistaLiqui = liquidacionesCOLATPantalla
				.getListaVistaLiqui();
		for (VistaLiquidacion vistaLiquidacion : listaVistaLiqui) {
			liquidacionesBo.cargar(vistaLiquidacion.getId());
		}
	}

	public List<VistaLiquidacion> listaSeleccionarTodos() {
		return liquidacionesBo.obtenerDatosLiquidacionesColat(
				liquidacionesCOLATPantalla.getProdCatalSelect(),
				liquidacionesCOLATPantalla.getNumOperDesde(),
				liquidacionesCOLATPantalla.getNumOperHasta(),
				liquidacionesCOLATPantalla.getDivPagoSelect(),
				liquidacionesCOLATPantalla.getFechaLiquidDesde(),
				liquidacionesCOLATPantalla.getFechaLiquidHasta(),
				liquidacionesCOLATPantalla.getDivCobroSelect(),
				liquidacionesCOLATPantalla.getContrapartidaSelect(),
				liquidacionesCOLATPantalla.getEstadoLiqSelect(),
				liquidacionesCOLATPantalla.getSitCorrespSelect(),
				liquidacionesCOLATPantalla.getImporteDesde(),
				liquidacionesCOLATPantalla.getImporteHasta(),
				liquidacionesCOLATPantalla.getTipoContrapa(), false,
				exportExcel, paginationData);
	}

	public List<VistaLiquidacion> getListaTemp() {
		return listaTemp;
	}

	public void setListaTemp(List<VistaLiquidacion> listaTemp) {
		this.listaTemp = listaTemp;
	}

	public static int getDayOfTheWeek(Date d){
		GregorianCalendar cal = new GregorianCalendar();
		cal.setTime(d);
		return cal.get(Calendar.DAY_OF_WEEK);		
	}
	
	public Boolean esFestivaLiquidacion(VistaLiquidacion liqui){
	try {
		if (("VA".equals(liqui.getEstado()) || "PV".equals(liqui.getEstado()))&& 
				(liquidacionesBo.esFestivo(liqui.getFechaliq(),liqui.getDivisali()) ||
				getDayOfTheWeek(liqui.getFechaliq())==7 || getDayOfTheWeek(liqui.getFechaliq())==1)
			){
				return true;
		}
				return false;
	} catch (Exception e) {
		return false;
	}	
	}
	
	public String getRowClasses() {
		StringBuilder builder = new StringBuilder();
		int i = 0;
		for (VistaLiquidacion vl : liquidacionesCOLATPantalla.getListaVistaLiqui()) {

			Contrapartida contrapartida;
			String idContrapartida = vl.getContrapa();
			contrapartida = liquidacionesBo.cargarContrapartida(idContrapartida.toUpperCase());	
			
			if (i > 0) {
				builder.append(",");
			}
			
			if(vl.getLiqOriginal()!=null){
				if (esFestivaLiquidacion(vl)){
					if (null!=contrapartida && !GenericUtils.isNullOrBlank(contrapartida.getIndBloqueo()) && "S".equalsIgnoreCase(contrapartida.getIndBloqueo())){
						builder.append("redResaltadoRowLiq");
					}
					else{
						builder.append("redResaltadoRow");
					}
				}else{
					if (null!=contrapartida && !GenericUtils.isNullOrBlank(contrapartida.getIndBloqueo()) && "S".equalsIgnoreCase(contrapartida.getIndBloqueo())){
						builder.append("resaltarRowLiq");
					}
					else{
						builder.append("resaltarRow");
					}
				}
				
			}else{
				if (esFestivaLiquidacion(vl)){
					if (null!=contrapartida && !GenericUtils.isNullOrBlank(contrapartida.getIndBloqueo()) && "S".equalsIgnoreCase(contrapartida.getIndBloqueo())){
						builder.append("redRowLiq");
					}
					else{
						builder.append("redRow");
					}
				}else{
					
					if(i%2==0){
						if (null!=contrapartida && !GenericUtils.isNullOrBlank(contrapartida.getIndBloqueo()) && "S".equalsIgnoreCase(contrapartida.getIndBloqueo())){
							builder.append("oddRowRedLiq");
						}
						else{
							builder.append("oddRow");
						}
					}
					else{
						if (null!=contrapartida && !GenericUtils.isNullOrBlank(contrapartida.getIndBloqueo()) && "S".equalsIgnoreCase(contrapartida.getIndBloqueo())){
							builder.append("eventRowRedLiq");
						}
						else{
							builder.append("evenRow");
						}
					}

				}
			}			
			i++;
		}
		return builder.toString();
	}

	@Override
	public boolean isLastExists() {
		return true;
	}

	public Integer contarRegistros() {
		Integer comptadorRegistres = new Integer(0);

		List<VistaLiquidacion> listaVistaLiqui = liquidacionesBo
				.obtenerDatosLiquidacionesColat(liquidacionesCOLATPantalla
						.getProdCatalSelect(), liquidacionesCOLATPantalla
						.getNumOperDesde(), liquidacionesCOLATPantalla
						.getNumOperHasta(), liquidacionesCOLATPantalla
						.getDivPagoSelect(), liquidacionesCOLATPantalla
						.getFechaLiquidDesde(), liquidacionesCOLATPantalla
						.getFechaLiquidHasta(), liquidacionesCOLATPantalla
						.getDivCobroSelect(), liquidacionesCOLATPantalla
						.getContrapartidaSelect(), liquidacionesCOLATPantalla
						.getEstadoLiqSelect(), liquidacionesCOLATPantalla
						.getSitCorrespSelect(), liquidacionesCOLATPantalla
						.getImporteDesde(), liquidacionesCOLATPantalla
						.getImporteHasta(), liquidacionesCOLATPantalla
						.getTipoContrapa(), null, exportExcel, paginationData);

		comptadorRegistres = listaVistaLiqui.get(0).getNumeroRegistros();

		return comptadorRegistres;
	}

	public void last() {
		if (GenericUtils.isNullOrBlank(ultimRegistre) || ultimRegistre == 0) {
			ultimRegistre = contarRegistros();
		}
		goLast(ultimRegistre);
	}

	public Integer getUltimRegistre() {
		return ultimRegistre;
	}

	public void setUltimRegistre(Integer ultimRegistre) {
		this.ultimRegistre = ultimRegistre;
	}

	public String getProjecte() {
		return projecte;
	}

	public void setProjecte(String projecte) {
		this.projecte = projecte;
	}


	public void voidFunction(){
		msgBoxAction.voidFunction();
	}
	

	
	public void init(){
		primeraEjecucionInit = null;
		primeraEjecucionRecibo = null;
		
		if(null==messageBoxLiquidacionesCOLATAction){
			messageBoxLiquidacionesCOLATAction = new MessageBoxAction();
		}
	}
	
	public void initEditar(){
		if (primeraEjecucionInit == null) {
			primeraEjecucionInit=true;
		} 
		else{
			primeraEjecucionInit = false;
		}
		
		if(primeraEjecucionInit){// && modoPantalla.equals(ModoPantalla.EDICION)){
			VistaLiquidacion vistaLiquidacion = liquidacionesCOLATPantalla.getVistaLiqui();
			String idContrapartida = vistaLiquidacion.getContrapa();
			if (!GenericUtils.isNullOrBlank(idContrapartida)){
				Contrapartida contrapartida = liquidacionesBo.cargarContrapartida(idContrapartida.toUpperCase());	
				if (null!=contrapartida && !GenericUtils.isNullOrBlank(contrapartida.getIndBloqueo()) && "S".equalsIgnoreCase(contrapartida.getIndBloqueo())){
					abrirPopUpContrapartidaBloqueada();
				}
			}
		}
	}
	
	/**
	 * Mostrar PopUp cuando una contrapartida está bloqueada (no bloqueante)
	 */
	public void onVerificarContrapartidaBloqueada() {
		if(null!=liquidacionesCOLATPantalla.getContrapartidaSelect()){
			String contrapartida = liquidacionesCOLATPantalla.getContrapartidaSelect();
			if (!GenericUtils.isNullOrBlank(contrapartida)){
				 Contrapartida contrapObtenida2 = liquidacionesBo.cargarContrapartida(contrapartida.toUpperCase());	
				if (null!=contrapObtenida2 && !GenericUtils.isNullOrBlank(contrapObtenida2.getIndBloqueo()) && "S".equalsIgnoreCase(contrapObtenida2.getIndBloqueo())){
					abrirPopUpContrapartidaBloqueada();
				}
			}
		}
	}
	
	private void abrirPopUpContrapartidaBloqueada(){
		messageBoxLiquidacionesCOLATAction.init(ResourceBundle.instance().getString("liquidaciones.messages.contrapartida.bloqueada.texto"), "liquidacionesCOLATAction.voidFunction()", null,"messageBoxPanelContrapa");
	}
	
	public void initReciboColat(){
		if (primeraEjecucionRecibo == null) {
			primeraEjecucionRecibo=true;
		} 
		else{
			primeraEjecucionRecibo = false;
		}
		
		if(primeraEjecucionRecibo && null!=liquidacionesCOLATPantalla.getVistaLiqui() && null!=liquidacionesCOLATPantalla.getVistaLiqui().getContrapa()){
			String idContrapartida = liquidacionesCOLATPantalla.getVistaLiqui().getContrapa();
			if (!GenericUtils.isNullOrBlank(idContrapartida)){
				 Contrapartida contrapObtenida2 = liquidacionesBo.cargarContrapartida(idContrapartida.toUpperCase());	
				if (null!=contrapObtenida2 && !GenericUtils.isNullOrBlank(contrapObtenida2.getIndBloqueo()) && "S".equalsIgnoreCase(contrapObtenida2.getIndBloqueo())){
					abrirPopUpContrapartidaBloqueada();
				}
			}
		}
	}
	
	public void liquidar(){
		
		//String sessionid = "";
		
		Map<String,String> parametros =	liquidacionesBo.getParametrosBDD();
		Map<String,String> parametrosLogin = liquidacionesBo.getParametrosLogin();
		//sessionid = liquidacionesBo.getSessionIdValido();

		ServicioLogin l = new ServicioLogin();
		ServicioXs7977 t = new ServicioXs7977();
		int contadorLiquidadas = 0;
		String referencia = null;
		
		try {
			/*if(sessionid2cover.equals("-1") ||	sessionid2cover.equals("-2")){
				sessionid2cover = "";
			}
			if(sessionid2cover == ""){*/
				sessionid2cover = l.login(parametrosLogin);
				//liquidacionesBo.updateSessionId(sessionid);
			//}
			System.out.println("SESSION ID: " + sessionid2cover);
		} catch (Exception e) {
			e.printStackTrace();
			statusMessages.add(Severity.ERROR, "Error en la llamada al servicio de login." );
		}
		
		boolean hayBloqueadas = false;
		liquidacionesBloqueadas = new ArrayList<VistaLiquidacion>();
		
		//recorremos la lista de liquidaciones seleccionadas
		for (VistaLiquidacion vistaLiquidacion : liquidacionesCOLATPantalla.getSelectedLiquiDataList()) {
			//bloqueamos los registros marcados que tengan estado pendiente de validar
			if (Constantes.LIQUIDACION_VALIDADA.equals(vistaLiquidacion.getEstado())){
				if (bloquearLiquidacion(vistaLiquidacion, Constantes.LIQUIDACION_ACCION_LIQUIDAR)){
					liquidacionesBloqueadas.add(vistaLiquidacion);
				} else {
					hayBloqueadas = true;
				}
			}
		}
		
		/* Si no había registros bloqueados, mostramos mensaje de confirmación al usuario para que decida
		 * si quiere continuar con la validacion. Si dice que no, o había registros bloqueados, se llama
		 * a salirSinValidar para finalizar la ejecución y desbloquear todos los registros previamente bloqueados
		 */
		if (hayBloqueadas){
			salirSinValidar();
		} else {
			for (VistaLiquidacion vistaLiq : liquidacionesBloqueadas) {
				if (Constantes.LIQUIDACION_VALIDADA.equals(vistaLiq.getEstado()) && "P".equals(vistaLiq.getDescrTipOpera()) && ("SWF".equals(vistaLiq.getCanaliqi()) || "TAR".equals(vistaLiq.getCanaliqi()) )) 
				{
						dbLockService.bloqueo(Liquidacion.class, vistaLiq.getId());
						Liquidacion liquidacion = liquidacionesBo.cargar(vistaLiq.getId());
						Contrapartida contrapa = liquidacionesBo.getContrapa(liquidacion.getContrapa());
						Date[] fechas;		
						String respuestaTexto = null;
						String respuestaEstado = null;
						
						Date today = null, fechaenv = null;
						if(contrapa != null){
							referencia = parametros.get("APPID")+t.formatearFecha(null,"yyMMddHHmmss")+String.format("%02d",contadorLiquidadas);
							//referencia = t.formatearFecha(null,"yyMMddHHmmss")+String.format("%02d",contadorLiquidadas);
							contadorLiquidadas++;
							try {					
								Swift swift = liquidacion.getSwift();
								
								fechas = liquidacionesBo.obtenerFechasColat(swift.getCodivisa()); //1-FECHAMIS 2-FECHAMIS1 3-FECHAMIS2			
								
								today = fechas[0];
								fechaenv = liquidacionesBo.obtenerFechaEnvSwift(liquidacion.getId());
								
								Calendar c = Calendar.getInstance();
								c.setTime(today);
								c.add(Calendar.DATE, 10);
								Date today10 = c.getTime();
								
								// Solo liquida si fechaliq <= fechamis+10 && fechaenv <= fechaliq
								if((!liquidacion.getFechaliq().after(today10) && !fechaenv.after(liquidacion.getFechaliq())) || fechaenv.equals(today)){
								
									Xs7977Response respuesta = t.liquidarXs7977(liquidacion, parametros, referencia, contrapa, sessionid2cover, liquidacionesBo, fechas);
								
									respuestaTexto = respuesta.getOutputData().getXs7977OEpa().getTxtresult();
									respuestaEstado = respuesta.getOutputData().getXs7977OEpa().getEstado();
									
									/*System.out.println("------------ SALIDA ------------");
									System.out.println("CODIASIG: " + respuesta.getOutputData().getXs7977OEpa().getCodiasig());
									System.out.println("CODICOMP: " + respuesta.getOutputData().getXs7977OEpa().getCodicomp());
									System.out.println("CTNOSVOS: " + respuesta.getOutputData().getXs7977OEpa().getCtnosvos());
									System.out.println("ESTADO: " + respuesta.getOutputData().getXs7977OEpa().getEstado());
									System.out.println("FVALOR: " + respuesta.getOutputData().getXs7977OEpa().getFvalor());
									System.out.println("MENSWIFT: " + respuesta.getOutputData().getXs7977OEpa().getMenswift());
									System.out.println("P53: " + respuesta.getOutputData().getXs7977OEpa().getP53ACorresp());
									System.out.println("P54: " + respuesta.getOutputData().getXs7977OEpa().getP54ACorresr());
									System.out.println("TIPONV: " + respuesta.getOutputData().getXs7977OEpa().getTipoNv());
									System.out.println("TXTRESULT: " + respuestaTexto);*/
								} else if (liquidacion.getFechaliq().after(today10)) {
									statusMessages.add(Severity.ERROR, "No se ha podido liquidar la operación " + vistaLiq.getNcorrela() + ". La fecha de liquidación es posterior a la fecha del sistema + 10 días.");
								} else if (fechaenv.after(liquidacion.getFechaliq())) {
									statusMessages.add(Severity.ERROR, "No se ha podido liquidar la operación " + vistaLiq.getNcorrela() + ". La fecha de envio es posterior a la fecha de liquidación.");
								} else {
									statusMessages.add(Severity.ERROR, "No se ha podido liquidar la operación " + vistaLiq.getNcorrela() + ".");
								}
								
							} catch (FaultInfo e) {
								e.printStackTrace();
								statusMessages.clear();
								statusMessages.add(Severity.ERROR,e.getCommonFault().getFaultMessage());
							} catch (RemoteException e) {
								e.printStackTrace();
								statusMessages.clear();
								statusMessages.add(Severity.ERROR,e.getMessage());
							} catch (Exception e) {
								e.printStackTrace();
								statusMessages.clear();
								statusMessages.add(Severity.ERROR, "Error en la llamada al servicio de pagos." );
							}
						} else{
							respuestaEstado = "noContrapa";
						}
						//respuestaEstado = "00";
						if (respuestaEstado != null){
							if (respuestaEstado.contains("00")){
								System.out.println("liquidacion "+contadorLiquidadas+" ["+ liquidacion.getNcorrela()+"]("+liquidacion.getImportel()+"):"+" - "+respuestaTexto);
								vistaLiq.setEstado(Constantes.LIQUIDACION_LIQUIDADA);
								liquidacion.setEstado(Constantes.LIQUIDACION_LIQUIDADA);
								liquidacion.setSitualiq("VEN");
								liquidacionesBo.contabilizarLiquidacion(liquidacion); //p_conta_liquidac()
								liquidacion.setReferpagos(referencia);
								liquidacion.setDescpagos(null);
								liquidacion.setFechacon(today);
								liquidacionesBo.actualizarEstadoLiquidacion(liquidacion);
							} else if (respuestaEstado.contains("noContrapa")){
								statusMessages.add(Severity.ERROR, "No se ha podido liquidar la operación " + vistaLiq.getNcorrela() + ". La contrapartida " + vistaLiq.getContrapa() + " no existe." );
							}else {
								System.out.println("liquidacion "+contadorLiquidadas+" ["+ liquidacion.getNcorrela()+"]("+liquidacion.getImportel()+"):"+" - "+respuestaTexto);
								vistaLiq.setEstado(Constantes.LIQUIDACION_ERROR);
								liquidacion.setEstado(Constantes.LIQUIDACION_ERROR);
								liquidacion.setSitualiq("INC");
								liquidacion.setReferpagos(null);
								liquidacion.setDescpagos(respuestaTexto);
								liquidacionesBo.actualizarCobrosLiquidacion(liquidacion);
							}
						}
							dbLockService.desbloqueo(Liquidacion.class, vistaLiq.getId());
				}
			}
		}
		liquidacionesBloqueadas.clear();
		liquidacionesCOLATPantalla.getSelectedLiquiDataList().clear();
		//TODO		statusMessages.addFromResourceBundle(Severity.INFO,	"liquidaciones.info.liquidadas", contadorLiquidadas);
		refrescarLista();
		
	}
	
	public void liquidarManual (){
		liquidacionesCOLATPantalla.copiarSeleccionado();
		
		Liquidacion liquidacion = liquidacionesBo
				.cargar(liquidacionesCOLATPantalla.getVistaLiqui().getId());

		Date fechamis = liquidacionesBo.obtenerFechamis(liquidacionesCOLATPantalla.getProyecto());
				
		//liquidacionesBo.grabarLiquidacionoManual(vistaLiq.getId(), fechamis);
		
		//vistaLiq.setEstado(Constantes.LIQUIDACION_LIQUIDADA);
		liquidacion.setEstado(Constantes.LIQUIDACION_LIQUIDADA);
		liquidacion.setSitualiq("ENM");
		liquidacion.setFechacon(fechamis);
		liquidacion.setDescpagos(null);

		liquidacionesBo.contabilizarLiquidacion (liquidacion); //p_conta_liquidac()
		liquidacionesBo.actualizarEstadoLiquidacion(liquidacion);
		
		refrescarLista();
	}
	
	public void liquidar2Cover () {
				
		Connection result = null;
		ResultSet registres=null;
		PreparedStatement ps = null;
		DataSource datasource = null;
		Object obj;
		List <Liquidacion2Cover> listaliq2cover = new ArrayList<Liquidacion2Cover>();
		Liquidacion2Cover liq2Cover = null;
		
		Integer coverOK1 = 0;
		Integer coverOK2 = 0;
		Integer coverOK3 = 0;
		Integer coverFAIL1 = 0;
		Integer coverFAIL2 = 0;
		Integer coverFAIL3 = 0;
		
		try {
		  Context initialContext = new InitialContext();
		  if ( initialContext != null){
			  obj = initialContext.lookup("java:/jboss/CoverDS");
			  datasource = (DataSource) obj;
			  if (datasource != null) {
				  result = datasource.getConnection();
			  }
			  if (result!=null){
				StringBuilder sb = new StringBuilder("select TipoLiquidacion, FechaLiquidacion, ImporteLiquidar, SentidoLiquidacion, " +
				 										"IdInternalContrato, DivisaLiquidacion, FechaInsercion, IdLiq, Estado, " +
				 										"Volcado, SwiftCptyInt, ModificadoVolcado " +
				 										"from dbo.SettlementsOnline where Volcado <> 1");
				ps = result.prepareStatement(sb.toString());
				registres = ps.executeQuery();
				 
				 if (registres!=null){
					 while (registres.next()) {
						 
						 liq2Cover = new Liquidacion2Cover (
									registres.getString ("TipoLiquidacion"),
									registres.getDate ("FechaLiquidacion"),
									registres.getBigDecimal ("ImporteLiquidar"),
									registres.getString ("SentidoLiquidacion"),
									registres.getInt ("IdInternalContrato"),
									registres.getString ("DivisaLiquidacion"),
									registres.getDate ("FechaInsercion"),
									registres.getInt ("IdLiq"),
									registres.getInt ("Estado"),
									registres.getInt ("Volcado"),
									registres.getString ("SwiftCptyInt"),
									registres.getInt ("ModificadoVolcado")
							);
						 listaliq2cover.add(liq2Cover);
					 }
				}
			  }
		  }
		} catch (NamingException e) {
			  statusMessages.add(Severity.INFO + " ERROR 1 = " + e.getMessage());
			e.printStackTrace();
		} catch (SQLException e) {
			  statusMessages.add(Severity.INFO + " ERROR 2 = " + e.getMessage());
			e.printStackTrace();
		} catch (Exception e) {
			  statusMessages.add(Severity.INFO + " ERROR 3 = " + e.getMessage());
			e.printStackTrace();
		}finally{
			try {
				if (ps != null) { ps.close(); }
				if (!result.isClosed()){
						result.close();
				}
			} catch (Exception e) {
			}
		}
		//Tratamiento liquidaciones desde 2Cover	
		for (Liquidacion2Cover l2c : listaliq2cover){
			if (liquidacionesBo.crearliq2cover(l2c)) {
				switch (l2c.getEstado()) {
					case 1: coverOK1++; break;
					case 2: coverOK2++; break;
					case 3: coverOK3++; break;
					default: break;
				}
				l2c.setVolcado(1);
			}else{
				switch (l2c.getEstado()) {
					case 1: coverFAIL1++; break;
					case 2: coverFAIL2++; break;
					case 3: coverFAIL3++; break;
					default: break;
				}
			}
		}
		//Update de las liquidaciones correctas a 2cover
		if (coverOK1 + coverOK2 + coverOK3 > 0){
			try {
				Context initialContext = new InitialContext();
				  if ( initialContext != null){
					  obj = initialContext.lookup("java:/jboss/CoverDS");
					  datasource = (DataSource) obj;
					  if (datasource != null) {
						  result = datasource.getConnection();
					  }
					  if (result!=null){

						StringBuilder sb = new StringBuilder("update dbo.SettlementsOnline set Volcado = 1 where 1 = 0");
						
						for (Liquidacion2Cover l2c : listaliq2cover){
							if (l2c.getVolcado() == 1){

								String fechaliq = " and FechaLiquidacion is null " ;
								String sentido = " and SentidoLiquidacion is null " ;
								if(l2c.getFechaliquidacion() != null){
									fechaliq = " and FechaLiquidacion = '" + l2c.getFechaliquidacion().toString() + "'";
								}
								if(l2c.getSentido() != null){
									sentido = " and SentidoLiquidacion = '" + l2c.getSentido() +"'";
								}
								
								sb.append(" or ( IdInternalContrato = " + l2c.getIdContrato() +
												" and IdLiq = " + l2c.getIdGestion() +
												" and TipoLiquidacion = '" + l2c.getTipoliquidacion() +"'"+
												sentido +
												" and DivisaLiquidacion = '" + l2c.getDivisa() +"'"+ 
												fechaliq +
												//" and FechaInsercion = " + l2c.getFechaInsercion() + 
												//" and FechaInsercion = " + new java.sql.Timestamp (l2c.getFechaInsercion().getTime()) +
												")");
							}

						}
						ps = result.prepareStatement(sb.toString());
						//ps.executeQuery();

						ps.execute();
						}
				  }
				} catch (NamingException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				} catch (Exception e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}finally{
					try {
						if (ps != null) { ps.close(); }
						if (!result.isClosed()){
								result.close();
						}
					} catch (Exception e) {
					}
				}
		}
		/*System.out.println("\nLiquidaciones 2Cover (A liquidar) OK:"+coverOK1+"\n" +
				"Liquidaciones 2Cover (Liquidadas) OK:"+coverOK2+"\n"+
				"Liquidaciones 2Cover (Descartadas) OK:"+coverOK3+"\n\n"+
				"Liquidaciones 2Cover (A liquidar) Error:"+coverFAIL1+"\n"+
				"Liquidaciones 2Cover (Liquidadas) Error:"+coverFAIL2+"\n"+
				"Liquidaciones 2Cover (Descartadas) Error:"+coverFAIL3+"\n");*/
	}
}
