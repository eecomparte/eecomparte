package com.atosorigin.deri.adminoper.liquidaciones.action;

import java.math.BigDecimal;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.jboss.seam.ScopeType;
import org.jboss.seam.annotations.In;
import org.jboss.seam.annotations.Name;
import org.jboss.seam.annotations.Out;
import org.jboss.seam.annotations.Scope;
import org.jboss.seam.international.StatusMessage.Severity;
import org.jboss.seam.security.Credentials;
import org.springframework.beans.BeanUtils;

import com.atosorigin.common.action.GenericAction;
import com.atosorigin.common.auditdata.AuditData;
import com.atosorigin.common.constantes.Constantes;
import com.atosorigin.common.formvalidator.FormValidator;
import com.atosorigin.common.utils.GenericUtils;
import com.atosorigin.deri.adminoper.liquidaciones.screen.CorreccionPantalla;
import com.atosorigin.deri.adminoper.liquidaciones.screen.LiquidacionesPantalla;
import com.atosorigin.deri.liquidaciones.business.LiquidacionesBo;
import com.atosorigin.deri.model.agenda.Agenda;
import com.atosorigin.deri.model.agenda.AgendaId;
import com.atosorigin.deri.model.gestionoperaciones.HistoricoOperacion;
import com.atosorigin.deri.model.liquidaciones.Liquidacion;
import com.atosorigin.deri.model.liquidaciones.LiquidacionId;
import com.atosorigin.deri.model.liquidaciones.LiquidacionModificada;
import com.atosorigin.deri.model.liquidaciones.VistaLiquidacion;
import com.atosorigin.deri.util.MessageBoxAction;

@Name("modifLiquidacionAction")
@Scope(ScopeType.CONVERSATION)
@FormValidator
public class ModifLiquidacionAction extends GenericAction {

	@In("#{liquidacionesBo}")
	protected LiquidacionesBo liquidacionesBo;
	
	@In(create = true)
	protected CorreccionPantalla correccionPantalla;
	
	@In(value="vistaLiqui", required=false)
	protected VistaLiquidacion vistaLiquidacion;
	
	@In
	protected LiquidacionesPantalla liquidacionesPantalla;
	
	@In Credentials credentials;
	
	@Out(required = false, value = "modifLiquidacionMessageBoxAction")
	private MessageBoxAction messageBoxAction;
	
	private String cerrarPanelAceptar;
	
//	public Boolean cargarCabeceraValidator(){
//		return false;
//	}
	/**
	 * Carga los valores para la cabecera y llama a la función que carga el listado de la
	 * parte inferior de la pantalla
	 */

	public Boolean cargarCabeceraValidator() {
		if (vistaLiquidacion==null){
			vistaLiquidacion =  liquidacionesPantalla.getVistaLiquiSelect();
		}
		if (liquidacionesBo.existeCorrecion(vistaLiquidacion)){
			statusMessages.add(Severity.ERROR,
			"#{messages['liquidaciones.error.rectificar.existe']}");
			setOnCompleteNo();
			return false;
		}
		SimpleDateFormat sdf = new SimpleDateFormat(Constantes.YYYYMMDD);
		if ((sdf.format(vistaLiquidacion.getFechaliq()).compareTo(sdf.format(new Date()))>=0)){
			statusMessages.add(Severity.ERROR,
			"#{messages['liquidaciones.error.rectificar.fechaLiquidacion']}");
			setOnCompleteNo();
			return false;
		}
		setOnCompleteSi();
		return true;
	}
	
	public void cargarCabecera() {
		
		if(!GenericUtils.isNullOrBlank(vistaLiquidacion)) {
			cerrarPanelNo();			
			correccionPantalla.setProducto(vistaLiquidacion.getDescrProducto());
			correccionPantalla.setFechaLiquidacion(vistaLiquidacion.getFechaliq());
			correccionPantalla.setNumopes(Long.valueOf(vistaLiquidacion.getnCorrelaEstructura()));
			correccionPantalla.setConcepto(vistaLiquidacion.getConcepto());
			correccionPantalla.setCanal(vistaLiquidacion.getCanaliqi());
			correccionPantalla.setContrapartida(vistaLiquidacion.getContrapa());
			correccionPantalla.setDivisa(vistaLiquidacion.getDivisali());
			correccionPantalla.setImporte(vistaLiquidacion.getImportel());
			correccionPantalla.setFechaLiquidacionCorregida(null);
			this.refrescarLista();
		}
	
		//Cargamos el grid
		
		
	}
	
	public void getHeader(VistaLiquidacion vistaLiquidacion) {
		this.vistaLiquidacion = vistaLiquidacion;
		this.cargarCabecera();
	}
	
	/**
	 * Busca el detalle de los registros neteados. Realiza una select de la tabla de liquidaciones
	 * en los que corresponda el código de liquidación
	 */
	protected void refrescarLista() {
		
		
		if ("I".equalsIgnoreCase(vistaLiquidacion.getTipoNeting()) || "E".equalsIgnoreCase(vistaLiquidacion.getTipoNeting())){

			List<Liquidacion> listaResultados = liquidacionesBo.obtenerNeteo(vistaLiquidacion.getCodliqui(), vistaLiquidacion.getFechatra());
			this.correccionPantalla.setNeteadosList(convertirLista(listaResultados));
			
		
//			Calendar c2 = new GregorianCalendar(2010, 10, 8);
////			c2.set(2010, 10, 8,0,0,0,0);
////			LiquidacionId idTemp = new LiquidacionId(Constantes.APLICACION_DERI,c2.getTime(),3L);
//			Liquidacion liqGrab = liquidacionesBo.cogerLiqui(3L, c2.getTime());
//			LiquidacionId idTemp2 = new LiquidacionId(Constantes.APLICACION_DERI,vistaLiquidacion.getFechatra(),vistaLiquidacion.getCodliqui());
//			Liquidacion liquinova = liquidacionesBo.cargar(idTemp2);
//			liquinova.setCodliqco(3L);
//			liquinova.setFetraco(c2.getTime());
//			liquidacionesBo.modificar(liquinova);
//			liquidacionesBo.flush();
			
		}else {
			
			List<Liquidacion> listaResultados = new ArrayList<Liquidacion>();
			
			listaResultados.add((Liquidacion) vistaLiquidacion);
			this.correccionPantalla.setNeteadosList(convertirLista(listaResultados));
			

		}
	}


	private List<LiquidacionModificada> convertirLista(List<Liquidacion> listaLiquidaciones){
		
		List<LiquidacionModificada> listaModif = new ArrayList<LiquidacionModificada>();
		
		for (Liquidacion liquidacion : listaLiquidaciones) {
			LiquidacionModificada temp = new LiquidacionModificada();
			temp.setNuevoImporte(liquidacion.getImportel());
			temp.setLiq(liquidacion);
			listaModif.add(temp);
		}
		return listaModif;	
	}

	
	public Boolean aceptarValidator(){
		
		if (correccionPantalla.getFechaLiquidacionCorregida()==null){
//			statusMessages.addToControl("fechaLiquidacionCorregida", Severity.ERROR, "#{messages['liquidaciones.rectificar.sinfecha']");
			mensaje("liquidaciones.rectificar.sinfecha");
			return false;
		}
			
		List<LiquidacionModificada> listaModif = correccionPantalla.getNeteadosList();
		
		for (LiquidacionModificada lm: listaModif) {

			if (lm.getNuevoImporte()==null){
//				mensaje("liquidaciones.error.rectificar.nuevoimporte");
//				return false;		
				lm.setNuevoImporte(BigDecimal.ZERO);
				
			}

//			if (BigDecimal.ZERO.compareTo(lm.getNuevoImporte()) == 1){
////				Negativo
//				mensaje("liquidaciones.error.rectificar.nuevoimporte");
//				return false;
//			}
			
			if (!lm.getNuevoImporte().equals(lm.getLiq().getImportel())){
				cerrarPanelSi();
				return true;
			}
		}
		statusMessages.add(Severity.ERROR,
				"#{messages['liquidaciones.error.rectificar.iguales']}");
		cerrarPanelSi();
		return false;
	}
	
	public void aceptar(){
		
		List<LiquidacionModificada> listaModif = correccionPantalla.getNeteadosList();
		List<Liquidacion> listaCorregidas = new ArrayList<Liquidacion>();
		Liquidacion neteoLiq = null;
		Date fechamis = liquidacionesBo.obtenerFechaSistema(); //Recuperamos la fecha del sistema
		BigDecimal importeRecibo = BigDecimal.ZERO;
		BigDecimal importePago = BigDecimal.ZERO;
		BigDecimal diferencia = BigDecimal.ZERO;
		
		for (LiquidacionModificada lm: listaModif) {
			if (lm.getNuevoImporte()!=null){
				diferencia = lm.getNuevoImporte().subtract(lm.getLiq().getImportel());
				if (diferencia.compareTo(BigDecimal.ZERO) != -1 ){
					// Nuevo Importe MAYOR que el original. Será en el mismo sentido que la liquidacion original
					diferencia = diferencia.abs();
					listaCorregidas.add(generarLiquidacion(fechamis,lm.getLiq(),diferencia,0,"NO"));

					if ("P".equalsIgnoreCase(lm.getLiq().getTipopera())){
						importePago = importePago.add(diferencia);
					}else{
						importeRecibo = importeRecibo.add(diferencia);
					}
					
				}else{

					// Nuevo Importe MENOR que el original. Se debe cambiar el sentido de la operacion
					// Ya no se cambia el sentido se graba con importe negativo.
//					diferencia = diferencia.abs();
//					listaCorregidas.add(generarLiquidacion(fechamis,lm.getLiq(),diferencia,1,"NO"));
					listaCorregidas.add(generarLiquidacion(fechamis,lm.getLiq(),diferencia,0,"NO"));
					
					diferencia = diferencia.abs();
					if ("P".equalsIgnoreCase(lm.getLiq().getTipopera())){
						importeRecibo = importeRecibo.add(diferencia);
					}else{
						importePago = importePago.add(diferencia);
					}

//Nueva funcionalidad, En caso de liquidacion individual negativa, generaremos un registro de neteo 
					
					//Si ya existe neteo, no deberemos hacer nada.
					if (vistaLiquidacion==null){
						vistaLiquidacion =  liquidacionesPantalla.getVistaLiquiSelect();
					}
					if (!"I".equalsIgnoreCase(vistaLiquidacion.getTipoNeting()) 
							&& !"E".equalsIgnoreCase(vistaLiquidacion.getTipoNeting())){
					//No existia neteo, generamos uno propìo	
						diferencia = diferencia.abs();
						neteoLiq = generarLiquidacion(fechamis,lm.getLiq(),diferencia,1,"SI");
						for (Liquidacion liquidacion : listaCorregidas) {
							liquidacion.setNumeroLiquidacionAG(neteoLiq.getId().getCodliqui());
							liquidacion.setFechaLiquidacionAg(fechamis);
						}
					}
				
				
				
				
				
				
				
				
				
				}
			}	
		}
		
		if (vistaLiquidacion==null){
			vistaLiquidacion =  liquidacionesPantalla.getVistaLiquiSelect();
		}
		if ("I".equalsIgnoreCase(vistaLiquidacion.getTipoNeting()) || "E".equalsIgnoreCase(vistaLiquidacion.getTipoNeting())){

			diferencia = importePago.subtract(importeRecibo);
			
			if ( (diferencia.compareTo(BigDecimal.ZERO) != -1 && "P".equalsIgnoreCase(vistaLiquidacion.getTipopera())) || 
				 (diferencia.compareTo(BigDecimal.ZERO) == -1  && "R".equalsIgnoreCase(vistaLiquidacion.getTipopera()))
				){
				neteoLiq = generarLiquidacion(fechamis,vistaLiquidacion,diferencia.abs(),0,"SI");
			}else{
				neteoLiq = generarLiquidacion(fechamis,vistaLiquidacion,diferencia.abs(),1,"SI");
			}

			
			for (Liquidacion liquidacion : listaCorregidas) {
				liquidacion.setNumeroLiquidacionAG(neteoLiq.getId().getCodliqui());
				liquidacion.setFechaLiquidacionAg(fechamis);
			}
			
		}
		if (neteoLiq != null){
			liquidacionesBo.insertar(neteoLiq);	
			liquidacionesBo.insertarEvento(generarEvento(fechamis,neteoLiq));
		}
		
		for (Liquidacion liquidacion : listaCorregidas) {
			liquidacionesBo.insertar(liquidacion);
			if (neteoLiq == null){
				liquidacionesBo.insertarEvento(generarEvento(fechamis,liquidacion));
			}
		}
		
		liquidacionesBo.flush();
		liquidacionesBo.flushAgenda();
		
		statusMessages.add(Severity.INFO,
		"#{messages['liquidaciones.rectificar.exito']}");
		
	}

	// Sentido:
	// 1 - Cambiar el sentido de la operación
	// 0 - Mismo sentido operación original.
	public Liquidacion generarLiquidacion(Date fechamis, Liquidacion liquidacion, BigDecimal importe, Integer sentido,String neteo){

		Liquidacion nueva = new Liquidacion();
		LiquidacionId nuevaId = new LiquidacionId();
		AuditData audit = new AuditData();
		Integer contador = liquidacionesBo.getNumContadorLiquidacion(fechamis);
		
		audit.setFechaUltimaModi(fechamis);
		audit.setUsuarioUltimaModi(credentials.getUsername());
		
		nuevaId.setProyecto(Constantes.APLICACION_DERI);
		nuevaId.setFechatra(fechamis);
		nuevaId.setCodliqui(contador);
		
		BeanUtils.copyProperties(liquidacion,nueva);	
		nueva.setId(nuevaId);
		
//		if (GenericUtils.isNullOrZero(nueva.getProducat())){
//			log.info("Producat NUL");
//			if (!GenericUtils.isNullOrZero(liquidacion.getProducat())){
//				log.info(liquidacion.getProducat().toString());
//			}else{
//				log.info("Producat Origen NUL");	
//			}
//		}
//		if (GenericUtils.isNullOrBlank(nueva.getDivisatr())){
//			log.info("Divisa NUL");
//			if (GenericUtils.isNullOrBlank(liquidacion.getDivisatr())){
//				log.info(liquidacion.getDivisatr());	
//			}else{
//				log.info("Divisa Origen NUL");	
//			}
//
//		}
		
		nueva.setEstado("NT");
		nueva.setFechaest(fechamis);
		nueva.setFechaliq(correccionPantalla.getFechaLiquidacionCorregida());
		nueva.setImportel(importe);
		nueva.setFechacon(null);
		nueva.setAuditData(audit);
		nueva.setLiqOriginal(liquidacion);
		nueva.setFetraco(liquidacion.getId().getFechatra());
		nueva.setCodliqco(liquidacion.getId().getCodliqui());
		nueva.setCesion(null);
		nueva.setSwift(null);
		
		nueva.setSitualiq(null);
		nueva.setRefliqui(null);
		nueva.setImpcouti(null);
		nueva.setIndforza(null);
		nueva.setImpforza(null);
		nueva.setDescatri(null);
		
		
		if (sentido ==1){
		//TODO
			HistoricoOperacion ho = liquidacionesBo.obtenerHistoricoOperacion(liquidacion.getNcorrela(),liquidacion.getFechaope());
			
			if ("P".equalsIgnoreCase(liquidacion.getTipopera())){
				
				nueva.setCanaliqi(ho.getCanalLiquidacionRecibo().getCodigo());
				nueva.setTipopera("R");
			}else{
				nueva.setCanaliqi(ho.getCanalLiquidacionPago().getCodigo());
				nueva.setTipopera("P");
			}
			
			
			nueva.setEntidcon(null);
			nueva.setOficonta(null);
			nueva.setGruconta(null);
			nueva.setCtaconta(null);
			nueva.setChkconta(null);
			
		}

		if ("NO".equalsIgnoreCase(neteo)){
			nueva.setTipoNeting(null);
		}else{
			nueva.setTipoNeting("I");
		}
		
		return nueva;
	}
	
	
	public Agenda generarEvento(Date fechamis,Liquidacion liquidacion){
		
		Agenda nuevoEvento = new Agenda();
		AuditData audit = new AuditData();
		
		
		Integer numeroEvento = liquidacionesBo.getNumEvento(fechamis);
		
		
		AgendaId eventoId = new AgendaId(fechamis, numeroEvento);
	
		
		audit.setFechaUltimaModi(fechamis);
		audit.setUsuarioUltimaModi(credentials.getUsername());
		
		nuevoEvento.setAuditData(audit);
		
		nuevoEvento.setId(eventoId);
		nuevoEvento.setCodigoEvento(Short.decode("3605"));
		nuevoEvento.setIndicadorTrataEvento("S");
		nuevoEvento.setEstadoEvento("P");
		nuevoEvento.setNivelVisibilidad("000");
		nuevoEvento.setOperacionId(liquidacion.getNcorrela());
		nuevoEvento.setFechaOperacion(liquidacion.getFechaope());
		nuevoEvento.setCodAviso(null);
		nuevoEvento.setCodLiquidacion(liquidacion.getId().getCodliqui());
		nuevoEvento.setFechatraliquidacion(liquidacion.getId().getFechatra());
		nuevoEvento.setEstructuraId(liquidacion.getEstructu());
		nuevoEvento.setCampanyaId(null);
		nuevoEvento.setCodIndice(null);
		nuevoEvento.setfTipo_a_Fijar(null);
		nuevoEvento.setCodConfirmacion(null);
		nuevoEvento.setCodDocumento(null);
		nuevoEvento.setProducto(null);
		
		//TODO
		nuevoEvento.setProducto(null);
		
		String datosGen = construirDatosGen(liquidacion.getId().getCodliqui(),liquidacion.getId().getFechatra(),liquidacion.getFechaope(),liquidacion.getEstructu() );
		nuevoEvento.setDatosGenerales(datosGen);
		return nuevoEvento;
	}


	public void setOnCompleteNo() {
			liquidacionesPantalla.setOnComplete("$('modifPanel').component.hide();return false;");
	}

	public void setOnCompleteSi() {
		liquidacionesPantalla.setOnComplete("$('modifPanel').component.show();");
	}

	public String getCerrarPanelAceptar() {
		return cerrarPanelAceptar;
	}

	public void setCerrarPanelAceptar(String cerrarPanelAceptar) {
		this.cerrarPanelAceptar = cerrarPanelAceptar;
	}

	public void cerrarPanelSi() {
		this.cerrarPanelAceptar = "$('modifPanel').component.hide();";
	}

	public void cerrarPanelNo() {
		this.cerrarPanelAceptar = "$('modifPanel').component.show();";
	}

	public String construirDatosGen(Long codliqui, Date fechatra, Date fechaope, Long estructu){
		
		SimpleDateFormat sdf1 = new SimpleDateFormat(Constantes.YYYYMMDD);
		String sfechatra;
		String sfechaope;

		if (fechatra == null){
			sfechatra = "00000000";
		}else{
			sfechatra = sdf1.format(fechatra);	
		}

		if (fechaope==null){
			sfechaope = "00000000";
		}else{
			sfechaope = sdf1.format(fechaope);
		}
		
		
		StringBuilder sb = new StringBuilder();
		
		sb.append(GenericUtils.lpad(codliqui.toString(),12,"0"));
		sb.append(" ");
		sb.append(sfechatra);
		sb.append(" ");
		sb.append(sfechaope);
		sb.append(" ");
		if (estructu!=null){
			sb.append(GenericUtils.lpad(estructu.toString(),12,"0"));	
		}else{
			sb.append("000000000000");	
		}
		
		// 12 + 1 + 8 + 1 + 8 + 1 + 12 = 43 **  400 - 43 = 357 
		sb.append(GenericUtils.rpad("", 357, " "));
		
		return sb.toString();
	}
	
	public void mensaje(String errorMensaje){
		if (messageBoxAction==null){
			messageBoxAction=new MessageBoxAction();
		}
		messageBoxAction.init(errorMensaje, "modifLiquidacionAction.voidfunction()", "");
	}

	public void voidfunction(){
		
	}
}
