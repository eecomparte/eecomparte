package com.atosorigin.deri.adminoper.liquidaciones.action;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

import org.jboss.seam.ScopeType;
import org.jboss.seam.annotations.In;
import org.jboss.seam.annotations.Name;
import org.jboss.seam.annotations.Out;
import org.jboss.seam.annotations.Scope;

import com.atosorigin.common.action.GenericAction;
import com.atosorigin.common.utils.GenericUtils;
import com.atosorigin.deri.adminoper.liquidaciones.screen.LiquidacionesPantalla;
import com.atosorigin.deri.adminoper.liquidaciones.screen.NeteosPantalla;
import com.atosorigin.deri.liquidaciones.business.LiquidacionesBo;
import com.atosorigin.deri.model.contrapartida.Contrapartida;
import com.atosorigin.deri.model.liquidaciones.Liquidacion;
import com.atosorigin.deri.model.liquidaciones.VistaLiquidacion;
import com.atosorigin.deri.util.MessageBoxAction;
import com.atosorigin.deri.util.MsgBoxAction;

@Name("neteosAction")
@Scope(ScopeType.CONVERSATION)
public class NeteosAction extends GenericAction {

	@In(create = true)
	private MsgBoxAction msgBoxAction;
	
	@Out(required = false, value = "neteosMessageBoxAction")
	private MessageBoxAction messageBoxNeteosAction;
	
	@In("#{liquidacionesBo}")
	protected LiquidacionesBo liquidacionesBo;
	
	@In(create = true)
	protected NeteosPantalla neteosPantalla;
	
//	@In(value="#{vistaLiqui}", required=false)
	@In(value="vistaLiqui", required=false)
	protected VistaLiquidacion vistaLiquidacion;
	
	private Boolean primeraEjecucionInit=null;
	
	/**
	 * Carga los valores para la cabecera y llama a la función que carga el listado de la
	 * parte inferior de la pantalla
	 */
	public void cargarCabecera() {
		
		if(!GenericUtils.isNullOrBlank(vistaLiquidacion)) {
			
			neteosPantalla.setProducto(vistaLiquidacion.getDescrProducto());
			neteosPantalla.setFechaLiquidacion(vistaLiquidacion.getFechaliq());
			neteosPantalla.setNumopes(vistaLiquidacion.getnCorrelaEstructura());
			neteosPantalla.setConcepto(vistaLiquidacion.getConcepto());
			neteosPantalla.setCanal(vistaLiquidacion.getCanaliqi());
			neteosPantalla.setContrapartida(vistaLiquidacion.getContrapa());
			neteosPantalla.setDivisa(vistaLiquidacion.getDivisali());
			neteosPantalla.setImporte(vistaLiquidacion.getImportel());
			this.refrescarLista();
		}
	
		//Cargamos el grid
	}
	
	/**
	 * Carga los valores para la cabecera y llama a la función que carga el listado de la
	 * parte inferior de la pantalla
	 */
	public void cargarCabecera2() {
		
		cargarCabecera();
	
		//Cargamos el grid
		if(null==messageBoxNeteosAction) messageBoxNeteosAction = new MessageBoxAction();
		messageBoxNeteosAction.init("liquidaciones.messages.contrapartida.bloqueada.texto", "neteosAction.voidFunction()", null, "messageBoxPanelNeteosContrapa");

	}
	
	public void getHeader(VistaLiquidacion vistaLiquidacion) {
		this.vistaLiquidacion = vistaLiquidacion;
		this.cargarCabecera();
	}
	
	/**
	 * Busca el detalle de los registros neteados. Realiza una select de la tabla de liquidaciones
	 * en los que corresponda el código de liquidación
	 */
	protected void refrescarLista() {
		
		
		if (("I".equalsIgnoreCase(vistaLiquidacion.getTipoNeting()) || "E".equalsIgnoreCase(vistaLiquidacion.getTipoNeting()))
				&& vistaLiquidacion.getLiqOriginal() == null){
			List<Liquidacion> listaResultados = liquidacionesBo.obtenerNeteo(vistaLiquidacion.getCodliqui(), vistaLiquidacion.getFechatra());
			this.neteosPantalla.setNeteadosList(listaResultados);
			
		
//			Calendar c2 = new GregorianCalendar(2010, 10, 8);
////			c2.set(2010, 10, 8,0,0,0,0);
////			LiquidacionId idTemp = new LiquidacionId(Constantes.APLICACION_DERI,c2.getTime(),3L);
//			Liquidacion liqGrab = liquidacionesBo.cogerLiqui(3L, c2.getTime());
//			LiquidacionId idTemp2 = new LiquidacionId(Constantes.APLICACION_DERI,vistaLiquidacion.getFechatra(),vistaLiquidacion.getCodliqui());
//			Liquidacion liquinova = liquidacionesBo.cargar(idTemp2);
//			liquinova.setCodliqco(3L);
//			liquinova.setFetraco(c2.getTime());
//			liquidacionesBo.modificar(liquinova);
//			liquidacionesBo.flush();
			
		}else if (("I".equalsIgnoreCase(vistaLiquidacion.getTipoNeting()) || "E".equalsIgnoreCase(vistaLiquidacion.getTipoNeting()))
				&& vistaLiquidacion.getLiqOriginal() != null){

			List<Liquidacion> listaResultados = liquidacionesBo.obtenerNeteo(vistaLiquidacion.getCodliqui(), vistaLiquidacion.getFechatra());
			
			List<Liquidacion> listaOriginales = new ArrayList<Liquidacion>();
			Liquidacion liqOrig = vistaLiquidacion.getLiqOriginal();
			if (esNeteo(liqOrig)){
				listaOriginales =  liquidacionesBo.obtenerNeteo(liqOrig.getId().getCodliqui(), liqOrig.getId().getFechatra());
			}else{
				listaOriginales.add(liqOrig);
			}
			
			List<Liquidacion> listaTmp = new ArrayList<Liquidacion>();

			while (liqOrig.getLiqOriginal()!=null && liqOrig.getLiqOriginal() != liqOrig){
				
				liqOrig = liqOrig.getLiqOriginal();

				if (esNeteo(liqOrig)){
					listaTmp =  liquidacionesBo.obtenerNeteo(liqOrig.getId().getCodliqui(), liqOrig.getId().getFechatra());
				}else{
					listaTmp.add(liqOrig);
				}
//				listaTmp = liquidacionesBo.obtenerNeteo(liqOrig.getId().getCodliqui(), liqOrig.getId().getFechatra());

				if (listaOriginales!=null){
					listaOriginales.addAll(listaTmp );
				}else{
					listaOriginales = listaTmp;
				}
			}
			
			if (listaResultados!=null){
				listaResultados.addAll(listaOriginales);
			}else{
				listaResultados = listaOriginales;
			}
			this.neteosPantalla.setNeteadosList(listaResultados);

			BigDecimal importeTotal = BigDecimal.ZERO;
			for (Liquidacion liq : listaResultados) {
				if ("P".equalsIgnoreCase(liq.getTipopera())){
					importeTotal = importeTotal.add(liq.getImportel()); 
				}else{
					importeTotal = importeTotal.subtract(liq.getImportel());
				}
			}
			this.neteosPantalla.setImporte(importeTotal.abs());
			
			
			
		}else if (!"I".equalsIgnoreCase(vistaLiquidacion.getTipoNeting()) && !"E".equalsIgnoreCase(vistaLiquidacion.getTipoNeting())
				&& vistaLiquidacion.getLiqOriginal() != null){
			List<Liquidacion> listaResultados = new ArrayList<Liquidacion>();
			//			(Liquidacion) vistaLiquidacion
			
			listaResultados.add((Liquidacion) vistaLiquidacion);
			Liquidacion liqOrig = vistaLiquidacion.getLiqOriginal();
			listaResultados.add(liqOrig);
			while (liqOrig.getLiqOriginal()!=null && liqOrig.getLiqOriginal() != liqOrig){
				liqOrig = liqOrig.getLiqOriginal();
				listaResultados.add(liqOrig);	
			}
			this.neteosPantalla.setNeteadosList(listaResultados);
			BigDecimal importeTotal = BigDecimal.ZERO;
			for (Liquidacion liq : listaResultados) {
				if ("P".equalsIgnoreCase(liq.getTipopera())){
					importeTotal = importeTotal.add(liq.getImportel()); 
				}else{
					importeTotal = importeTotal.subtract(liq.getImportel());
				}
			}
			this.neteosPantalla.setImporte(importeTotal.abs());

		}
//		List<Liquidacion> listaOriginales = null; 
//		for (Liquidacion liquidacion : listaResultados) {
//			if (liquidacion.getLiqOriginal()!=null){
//				listaOriginales = liquidacionesBo.obtenerNeteo(liquidacion.getLiqOriginal().getId().getCodliqui(), liquidacion.getLiqOriginal().getId().getFechatra());
//			}
//		}
//		listaResultados.addAll(listaOriginales);
//		this.neteosPantalla.setNeteadosList(listaResultados);
	}



	public String getRowClasses(){
		StringBuilder builder = new StringBuilder();
		int i=0;
		for (Liquidacion vl : neteosPantalla.getNeteadosList()) {
			if(i>0){
				builder.append(",");
			}
			if(vl.getLiqOriginal()!=null && vl.getLiqOriginal()!=vl){
				builder.append("resaltarRow");
			}
			else{
				if(i%2==0){
					builder.append("oddRow");
				}
				else{
					builder.append("evenRow");
				}
			}
			i++;
		}
		return builder.toString();
	}
	
	public Boolean esNeteo(Liquidacion liquidacion){
		 if (("I".equalsIgnoreCase(liquidacion.getTipoNeting()) || "E".equalsIgnoreCase(liquidacion.getTipoNeting()))){
			 return true;
		 }else{
			 return false;	 
		 }
	}
	
	public void onValidarContrapartidaBloqueada(){
		if (primeraEjecucionInit == null) {
			primeraEjecucionInit=true;
		} 
		else{
			primeraEjecucionInit = false;
		}
		
		
		
		
		if(null==messageBoxNeteosAction) messageBoxNeteosAction = new MessageBoxAction();
		
//		if(primeraEjecucionInit){
//			String idContrapartida = neteosPantalla.getContrapartida();
//			if (!GenericUtils.isNullOrBlank(idContrapartida)){
//				 Contrapartida contrapObtenida2 = liquidacionesBo.cargarContrapartida(idContrapartida.toUpperCase());	
//				if (null!=contrapObtenida2 && !GenericUtils.isNullOrBlank(contrapObtenida2.getIndBloqueo()) && "S".equalsIgnoreCase(contrapObtenida2.getIndBloqueo())){
					//messageBoxNeteosAction.init("liquidaciones.messages.contrapartida.bloqueada.texto", "neteosAction.voidFunction()", null, "messageBoxPanelNeteosContrapa");
//				}
//				else{
//					liquidacionesPantalla.setOnComplete("$('neteosPanel').component.show();");
//				}
//			}
//			else{
//				liquidacionesPantalla.setOnComplete("$('neteosPanel').component.show();");
//			}

		//}
	}
	
	@In(create=true)
	protected LiquidacionesPantalla liquidacionesPantalla;
	
	public void voidFunction(){
		msgBoxAction.voidFunction();
	}
	
	public String retornaPanel(){
		return "{#{rich:component('neteosPanel')}.show()}";
	}

}
