package com.atosorigin.deri.adminoper.liquidaciones.screen;

import java.math.BigDecimal;
import java.util.Date;
import java.util.List;

import org.jboss.seam.ScopeType;
import org.jboss.seam.annotations.Name;
import org.jboss.seam.annotations.Scope;
import org.jboss.seam.annotations.datamodel.DataModel;

import com.atosorigin.deri.model.liquidaciones.Liquidacion;
import com.atosorigin.deri.model.liquidaciones.ReferenciaConfirmacion;

@Name("confirmarPantalla")
@Scope(ScopeType.CONVERSATION)
public class ConfirmarPantalla {

	protected String producto;
	protected Date fechaLiquidacion;
	protected Long numopes;
	protected String concepto;
	protected String canal;
	protected String contrapartida;
	protected String divisa;
	protected BigDecimal importe;
	
	protected Long referenciaPago;
	
	protected ReferenciaConfirmacion referenciaModelo;
	protected String nombreModelo;
	protected String nombreReferencia;                                                                                                                                                                                 
	protected String telefono;
	protected String email;
	protected String observaciones;

	
	protected Date fechaLiquidacionCorregida;
	/** Lista de datos para el grid. */
	@DataModel(value = "listaDtNeteados")
	protected List<Liquidacion> neteadosList;
	
	public String getProducto() {
		return producto;
	}

	public Date getFechaLiquidacion() {
		return fechaLiquidacion;
	}

	public Long getNumopes() {
		return numopes;
	}

	public String getCanal() {
		return canal;
	}

	public String getContrapartida() {
		return contrapartida;
	}

	public String getDivisa() {
		return divisa;
	}

	public BigDecimal getImporte() {
		return importe;
	}

	public void setProducto(String producto) {
		this.producto = producto;
	}

	public void setFechaLiquidacion(Date fechaLiquidacion) {
		this.fechaLiquidacion = fechaLiquidacion;
	}

	public void setNumopes(Long numopes) {
		this.numopes = numopes;
	}

	public void setCanal(String canal) {
		this.canal = canal;
	}

	public void setContrapartida(String contrapartida) {
		this.contrapartida = contrapartida;
	}

	public void setDivisa(String divisa) {
		this.divisa = divisa;
	}

	public void setImporte(BigDecimal importe) {
		this.importe = importe;
	}

	public List<Liquidacion> getNeteadosList() {
		return neteadosList;
	}

	public void setNeteadosList(List<Liquidacion> neteadosList) {
		this.neteadosList = neteadosList;
	}

	public String getConcepto() {
		return concepto;
	}

	public void setConcepto(String concepto) {
		this.concepto = concepto;
	}

	public Date getFechaLiquidacionCorregida() {
		return fechaLiquidacionCorregida;
	}

	public void setFechaLiquidacionCorregida(Date fechaLiquidacionCorregida) {
		this.fechaLiquidacionCorregida = fechaLiquidacionCorregida;
	}

	public ReferenciaConfirmacion getReferenciaModelo() {
		return referenciaModelo;
	}

	public void setReferenciaModelo(ReferenciaConfirmacion referenciaModelo) {
		this.referenciaModelo = referenciaModelo;
	}

	public String getNombreModelo() {
		return nombreModelo;
	}

	public void setNombreModelo(String nombreModelo) {
		this.nombreModelo = nombreModelo;
	}

	public String getNombreReferencia() {
		return nombreReferencia;
	}

	public void setNombreReferencia(String nombreReferencia) {
		this.nombreReferencia = nombreReferencia;
	}

	public String getTelefono() {
		return telefono;
	}

	public void setTelefono(String telefono) {
		this.telefono = telefono;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getObservaciones() {
		return observaciones;
	}

	public void setObservaciones(String observaciones) {
		this.observaciones = observaciones;
	}

	public Long getReferenciaPago() {
		return referenciaPago;
	}

	public void setReferenciaPago(Long referenciaPago) {
		this.referenciaPago = referenciaPago;
	}

}
