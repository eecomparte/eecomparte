package com.atosorigin.deri.adminoper.liquidaciones.screen;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;

import org.jboss.seam.ScopeType;
import org.jboss.seam.annotations.Name;
import org.jboss.seam.annotations.Out;
import org.jboss.seam.annotations.Scope;
import org.jboss.seam.annotations.datamodel.DataModel;
import org.jboss.seam.annotations.datamodel.DataModelSelection;

import com.atosorigin.deri.liquidaciones.business.MensajesValidacion;
import com.atosorigin.deri.liquidaciones.business.MensajesValidacionId;
import com.atosorigin.deri.model.catalogo.Producto;
import com.atosorigin.deri.model.contrapartida.TipoContrapartida;
import com.atosorigin.deri.model.liquidaciones.DescripcionEstadoLiquidacion;
import com.atosorigin.deri.model.liquidaciones.DescripcionSituacionLiquidacion;
import com.atosorigin.deri.model.liquidaciones.ReferenciaConfirmacion;
import com.atosorigin.deri.model.liquidaciones.VistaLiquidacion;
import com.atosorigin.deri.model.murex.ModeloProducto;
import com.atosorigin.deri.model.murex.ProductoCatalogo;
import com.atosorigin.deri.model.parametrizacion.Divisa;

@Name("liquidacionesPantalla")
@Scope(ScopeType.CONVERSATION)
public class LiquidacionesPantalla {
	
	/**
	 * CRITERIOS DE SELECCION - INI
	 */
	protected ModeloProducto modeloProductoSelect;
	protected ProductoCatalogo prodCatalSelect;
	protected Long numOperDesde;
	protected Long numOperHasta;
	
	protected Divisa divPagoSelect;
	protected Producto prodOperSelect;
	protected Date fechaLiquidDesde;
	protected Date fechaLiquidHasta;
	
	protected Divisa divCobroSelect;
	protected String contrapartidaSelect;
	protected Long numEstructDesde;
	protected Long numEstructHasta;	
	protected Long claveExternaDesde;
	protected Long claveExternaHasta;	
	protected String guidDesde;
	protected String guidHasta;	
	protected BigDecimal importeDesde;
	protected BigDecimal importeHasta;	

	
	protected DescripcionEstadoLiquidacion estadoLiqSelect;
	protected DescripcionSituacionLiquidacion sitCorrespSelect;
	protected Boolean opCasadasSelect;
	protected BigDecimal totalImportes;
	protected TipoContrapartida tipoContrapa;
	

	protected String estadoConf;
		
	/** CRITERIOS CONTACTOS PANTALLA CONFIRMACION LIQUIDACIONES
	 * 
	 */
	protected ReferenciaConfirmacion referenciaModelo;
	protected String nombreModelo;
	protected String nombreReferencia;                                                                                                                                                                                 
	protected String telefono;
	protected String email;
	protected String canal;
	protected String observaciones;
	protected String suReferencia;
	protected Boolean idConciliada;
	
	protected Long referenciaPago;
		
	/**
	 * CRITERIOS DE SELECCION - FIN
	 */
	
	//Cabecera
	protected String cabecera;
	
	private String onComplete;
	
	@Out(value="listaProdCatal", required=false)
	protected List<ProductoCatalogo> listaProdCatal;
	
	@Out(value="listaProd", required=false)
	protected List<Producto> listaProd;	
	
	@DataModel(value="listaDtVistaLiqui")
	protected List<VistaLiquidacion> listaVistaLiqui;
	
	// Seguramente sera necesario sacar este objeto en otra pantalla
	HashMap<MensajesValidacionId, MensajesValidacion> liquidacionesMsg;
	
	/** Variable boolean para saber si venimos de la Agenda */
	protected boolean vieneAgenda;	
	
	/** Variable boolean para saber si venimos de Lista Operaciones */
	protected boolean vieneOperaciones;
	
	protected int registrosValidados = 0;
	protected ArrayList<String> errores = new ArrayList<String>();
	
	public boolean isVieneAgenda() {
		return vieneAgenda;
	}

	public void setVieneAgenda(boolean vieneAgenda) {
		this.vieneAgenda = vieneAgenda;
	}

	public HashMap<MensajesValidacionId, MensajesValidacion> getLiquidacionesMsg() {
		return liquidacionesMsg;
	}

	public void setLiquidacionesMsg(
			HashMap<MensajesValidacionId, MensajesValidacion> liquidacionesMsg) {
		this.liquidacionesMsg = liquidacionesMsg;
	}

	@Out(required=false, value="vistaLiqui")
	protected VistaLiquidacion vistaLiqui;
	
	protected boolean swiftTarget = true;

	@DataModelSelection(value="listaDtVistaLiqui")
	protected VistaLiquidacion vistaLiquiSelect;
	
	/**
	 * Selección checkbox Liquidaciones
	 */
//	protected Map<LiquidacionId, Boolean> selectedLiquiIds = new HashMap<LiquidacionId, Boolean>();
	protected HashSet<VistaLiquidacion> selectedLiquiDataList = new HashSet<VistaLiquidacion>();
	protected boolean selecTodos;
	
	/** Checkbox forzar de Calificar Cobro */
	protected boolean forzar;
	
	public ModeloProducto getModeloProductoSelect() {
		return modeloProductoSelect;
	}

	public ProductoCatalogo getProdCatalSelect() {
		return prodCatalSelect;
	}

	public Long getNumOperDesde() {
		return numOperDesde;
	}

	public Long getNumOperHasta() {
		return numOperHasta;
	}

	public Divisa getDivPagoSelect() {
		return divPagoSelect;
	}

	public Producto getProdOperSelect() {
		return prodOperSelect;
	}

	public Date getFechaLiquidDesde() {
		return fechaLiquidDesde;
	}

	public Date getFechaLiquidHasta() {
		return fechaLiquidHasta;
	}

	public Divisa getDivCobroSelect() {
		return divCobroSelect;
	}

	public String getContrapartidaSelect() {
		return contrapartidaSelect;
	}

	public Long getNumEstructDesde() {
		return numEstructDesde;
	}

	public Long getNumEstructHasta() {
		return numEstructHasta;
	}

	public DescripcionEstadoLiquidacion getEstadoLiqSelect() {
		return estadoLiqSelect;
	}

	public DescripcionSituacionLiquidacion getSitCorrespSelect() {
		return sitCorrespSelect;
	}

	public Boolean getOpCasadasSelect() {
		return opCasadasSelect;
	}

	public BigDecimal getTotalImportes() {
		return totalImportes;
	}

	public void setModeloProductoSelect(ModeloProducto modeloProductoSelect) {
		this.modeloProductoSelect = modeloProductoSelect;
	}

	public void setProdCatalSelect(ProductoCatalogo prodCatalSelect) {
		this.prodCatalSelect = prodCatalSelect;
	}

	public void setNumOperDesde(Long numOperDesde) {
		this.numOperDesde = numOperDesde;
	}

	public void setNumOperHasta(Long numOperHasta) {
		this.numOperHasta = numOperHasta;
	}

	public void setDivPagoSelect(Divisa divPagoSelect) {
		this.divPagoSelect = divPagoSelect;
	}

	public void setProdOperSelect(Producto prodOperSelect) {
		this.prodOperSelect = prodOperSelect;
	}

	public void setFechaLiquidDesde(Date fechaLiquidDesde) {
		this.fechaLiquidDesde = fechaLiquidDesde;
	}

	public void setFechaLiquidHasta(Date fechaLiquidHasta) {
		this.fechaLiquidHasta = fechaLiquidHasta;
	}

	public void setDivCobroSelect(Divisa divCobroSelect) {
		this.divCobroSelect = divCobroSelect;
	}

	public void setContrapartidaSelect(String contrapartidaSelect) {
		this.contrapartidaSelect = contrapartidaSelect;
	}

	public void setNumEstructDesde(Long numEstructDesde) {
		this.numEstructDesde = numEstructDesde;
	}

	public void setNumEstructHasta(Long numEstructHasta) {
		this.numEstructHasta = numEstructHasta;
	}

	public void setEstadoLiqSelect(DescripcionEstadoLiquidacion estadoLiqSelect) {
		this.estadoLiqSelect = estadoLiqSelect;
	}

	public void setSitCorrespSelect(DescripcionSituacionLiquidacion sitCorrespSelect) {
		this.sitCorrespSelect = sitCorrespSelect;
	}

	public void setOpCasadasSelect(Boolean opCasadasSelect) {
		this.opCasadasSelect = opCasadasSelect;
	}

	public void setTotalImportes(BigDecimal totalImportes) {
		this.totalImportes = totalImportes;
	}

	public List<ProductoCatalogo> getListaProdCatal() {
		return listaProdCatal;
	}

	public void setListaProdCatal(List<ProductoCatalogo> listaProdCatal) {
		this.listaProdCatal = listaProdCatal;
	}
	
	public List<Producto> getListaProd() {
		return listaProd;
	}

	public void setListaProd(List<Producto> listaProd) {
		this.listaProd = listaProd;
	}
		
	public List<VistaLiquidacion> getListaVistaLiqui() {
		return listaVistaLiqui;
	}

	public void setListaVistaLiqui(List<VistaLiquidacion> listaVistaLiqui) {
		this.listaVistaLiqui = listaVistaLiqui;
	}

//	public Map<LiquidacionId, Boolean> getSelectedLiquiIds() {
//		return selectedLiquiIds;
//	}
//
//	public void setSelectedLiquiIds(Map<LiquidacionId, Boolean> selectedLiquiIds) {
//		this.selectedLiquiIds = selectedLiquiIds;
//	}

	public HashSet<VistaLiquidacion> getSelectedLiquiDataList() {
		return selectedLiquiDataList;
	}

	public boolean getSelecTodos() {
		return selecTodos;
	}

	public void setSelectedLiquiDataList(
			HashSet<VistaLiquidacion> selectedLiquiDataList) {
		this.selectedLiquiDataList = selectedLiquiDataList;
	}

	public void setSelecTodos(boolean selecTodos) {
		this.selecTodos = selecTodos;
	}

	public VistaLiquidacion getVistaLiquiSelect() {
		return vistaLiquiSelect;
	}

	public void setVistaLiquiSelect(VistaLiquidacion vistaLiquiSelect) {
		this.vistaLiquiSelect = vistaLiquiSelect;
	}

	public VistaLiquidacion getVistaLiqui() {
		return vistaLiqui;
	}

	public void setVistaLiqui(VistaLiquidacion vistaLiqui) {
		this.vistaLiqui = vistaLiqui;
	}

	public boolean isSwiftTarget() {
		return swiftTarget;
	}

	public void setSwiftTarget(boolean swiftTarget) {
		this.swiftTarget = swiftTarget;
	}
	
	public void copiarSeleccionado(){
		vistaLiqui = vistaLiquiSelect;

	}

	public String getCabecera() {
		return cabecera;
	}

	public void setCabecera(String cabecera) {
		this.cabecera = cabecera;
	}

	public boolean isForzar() {
		return forzar;
	}

	public void setForzar(boolean forzar) {
		this.forzar = forzar;
	}

	public boolean isVieneOperaciones() {
		return vieneOperaciones;
	}

	public void setVieneOperaciones(boolean vieneOperaciones) {
		this.vieneOperaciones = vieneOperaciones;
	}

	public int getRegistrosValidados() {
		return registrosValidados;
	}

	public void setRegistrosValidados(int registrosValidados) {
		this.registrosValidados = registrosValidados;
	}

	public ArrayList<String> getErrores() {
		return errores;
	}

	public void setErrores(ArrayList<String> errores) {
		this.errores = errores;
	}


	public String getOnComplete() {
		return onComplete;
	}

	public void setOnComplete(String onComplete) {
		this.onComplete = onComplete;
	}

	public String getEstadoConf() {
		return estadoConf;
	}

	public void setEstadoConf(String estadoConf) {
		this.estadoConf = estadoConf;
	}

	public String getNombreModelo() {
		return nombreModelo;
	}

	public void setNombreModelo(String nombreModelo) {
		this.nombreModelo = nombreModelo;
	}

	public String getNombreReferencia() {
		return nombreReferencia;
	}

	public void setNombreReferencia(String nombreReferencia) {
		this.nombreReferencia = nombreReferencia;
	}

	public String getTelefono() {
		return telefono;
	}

	public void setTelefono(String telefono) {
		this.telefono = telefono;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getCanal() {
		return canal;
	}

	public void setCanal(String canal) {
		this.canal = canal;
	}

	public String getObservaciones() {
		return observaciones;
	}

	public void setObservaciones(String observaciones) {
		this.observaciones = observaciones;
	}

	public ReferenciaConfirmacion getReferenciaModelo() {
		return referenciaModelo;
	}

	public void setReferenciaModelo(ReferenciaConfirmacion referenciaModelo) {
		this.referenciaModelo = referenciaModelo;
	}
	public TipoContrapartida getTipoContrapa() {
		return tipoContrapa;
	}

	public void setTipoContrapa(TipoContrapartida tipoContrapa) {
		this.tipoContrapa = tipoContrapa;
	}

	public Long getClaveExternaDesde() {
		return claveExternaDesde;
	}

	public void setClaveExternaDesde(Long claveExternaDesde) {
		this.claveExternaDesde = claveExternaDesde;
	}

	public Long getClaveExternaHasta() {
		return claveExternaHasta;
	}

	public void setClaveExternaHasta(Long claveExternaHasta) {
		this.claveExternaHasta = claveExternaHasta;
	}

	public String getGuidDesde() {
		return guidDesde;
	}

	public void setGuidDesde(String guidDesde) {
		this.guidDesde = guidDesde;
	}

	public String getGuidHasta() {
		return guidHasta;
	}

	public void setGuidHasta(String guidHasta) {
		this.guidHasta = guidHasta;
	}

	public BigDecimal getImporteDesde() {
		return importeDesde;
	}

	public void setImporteDesde(BigDecimal importeDesde) {
		this.importeDesde = importeDesde;
	}

	public BigDecimal getImporteHasta() {
		return importeHasta;
	}

	public void setImporteHasta(BigDecimal importeHasta) {
		this.importeHasta = importeHasta;
	}

	public Long getReferenciaPago() {
		return referenciaPago;
	}

	public void setReferenciaPago(Long referenciaPago) {
		this.referenciaPago = referenciaPago;
	}

	public String getSuReferencia() {
		return suReferencia;
	}

	public void setSuReferencia(String suReferencia) {
		this.suReferencia = suReferencia;
	}

	public Boolean getIdConciliada() {
		return idConciliada;
	}

	public void setIdConciliada(Boolean idConciliada) {
		this.idConciliada = idConciliada;
	}

	
}
