package com.atosorigin.deri.adminoper.mantOperaciones.action;

import java.math.BigDecimal;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import javax.persistence.EntityManager;

import org.jboss.seam.ScopeType;
import org.jboss.seam.annotations.Factory;
import org.jboss.seam.annotations.In;
import org.jboss.seam.annotations.Name;
import org.jboss.seam.annotations.Out;
import org.jboss.seam.annotations.Scope;
import org.jboss.seam.core.Conversation;
import org.jboss.seam.core.ResourceBundle;
import org.jboss.seam.international.StatusMessage;
import org.jboss.seam.international.StatusMessage.Severity;
import org.jboss.seam.security.Credentials;
import org.jboss.seam.security.Identity;

import com.atosorigin.common.action.GenericAction;
import com.atosorigin.common.constantes.Constantes;
import com.atosorigin.common.formvalidator.FormValidator;
import com.atosorigin.common.utils.GenericUtils;
import com.atosorigin.deri.adminoper.boletas.action.BoletasAction.BoletasStates;
import com.atosorigin.deri.adminoper.boletas.business.BoletasBo;
import com.atosorigin.deri.adminoper.mantOperaciones.screen.CancelacionPantalla;
import com.atosorigin.deri.adminoper.mantoper.business.CancelacionBo;
import com.atosorigin.deri.adminoper.mantoper.business.MantOperBo;
import com.atosorigin.deri.common.dbLock.DbLockService;
import com.atosorigin.deri.model.adminoper.Autoriza;
import com.atosorigin.deri.model.adminoper.CancelacionParcial;
import com.atosorigin.deri.model.adminoper.CancelacionParcialId;
import com.atosorigin.deri.model.adminoper.CancelarOperacionReturn;
import com.atosorigin.deri.model.adminoper.DescripcionTradeOnTv;
import com.atosorigin.deri.model.adminoper.ModiNcorrelaReturn;
import com.atosorigin.deri.model.adminoper.NominalTramoReturn;
import com.atosorigin.deri.model.adminoper.NormaIVParam;
import com.atosorigin.deri.model.adminoper.RelProductoTransaccion;
import com.atosorigin.deri.model.adminoper.VistaMantEje;
import com.atosorigin.deri.model.common.PkgReturnBase;
import com.atosorigin.deri.model.contrapartida.AbstractContrapartida;
import com.atosorigin.deri.model.contrapartida.Contrapartida;
import com.atosorigin.deri.model.gestionoperaciones.HistoricoOperacion;
import com.atosorigin.deri.model.gestionoperaciones.OperacionId;
import com.atosorigin.deri.util.EntityUtil;
import com.atosorigin.deri.util.FormatUtil;

@Name("cancelacionAction")
@Scope(ScopeType.CONVERSATION)
@FormValidator
public class CancelacionAction extends GenericAction {

    @In Credentials credentials;
	
//	@In(required=false)
//	private VistaOperacion vistaOperacionSelected;
	
	@In("#{cancelacionBo}")
	private CancelacionBo cancelacionBo;

	@In("#{boletasBo}")
	private BoletasBo boletasBo;
	
	@In("#{mantOperBo}")
	private MantOperBo mantOperBo;
	
	@In
	private CancelacionPantalla cancelacionPantalla;
	
	@In(required=false)
	private String modifCanc;

	
	@In
	private FormatUtil formatUtil;
	
	@In
	@Out
	private HistoricoOperacion historicoOperacion;
	
	/** Inyección del servicio que gestiona los bloqueos de registros en base de datos */
	@In(create = true)
	protected DbLockService dbLockService;
	
	@In("EntityUtil")
	private EntityUtil entityUtil;
	
	@In
	private EntityManager entityManager;
	
	@Out(required=false)
	private BoletasStates boletaState;
	
	@Out
	private Date fechamis = new Date();
	
	/** Inyección del objeto para la union con MANTPROD  */
	@In(required=false)
	@Out(required= false)
	String varModif;
	
	// Globales
	private String tppapago;
	private String tppareci;
	
	private Date fechaModificacion = null;
	
	private Boolean filaBloqueada = false;
	// Mensajes por pantalla
	private boolean mostrarMensaje = false;
	private StringBuilder mensajeConfirmacion = new StringBuilder();
	private boolean respuesta = false;
	private String accion = "validar";
	private boolean primeraVez = true;
	
	//SMM 30/05/2018
	private String tipoCliente = null;
	
	public void init(){
		if (primeraVez){
			if ("S".equalsIgnoreCase(modifCanc)){
				tipoCancelacionParcial();
				obtenerNominalTramoAction();
				obtenerTipoCliente();
				calculoNormaIV();
			}
			// SCM: LO HACEMOS EN MANTOPER
			//dbLockService.bloqueo(HistoricoOperacion.class, historicoOperacion.getId());
			primeraVez = false;
		}
	}
	private Boolean esContrapartidaBancaria(AbstractContrapartida contrapa) {
		
		if (contrapa == null) return true;
		
		if(entityUtil.checkEntityExists(contrapa)){
			AbstractContrapartida abstractContrapartida = entityUtil.unwrapProxy(contrapa, AbstractContrapartida.class);
			if (abstractContrapartida != null && abstractContrapartida instanceof Contrapartida) {
				Contrapartida contrapartida = (Contrapartida) abstractContrapartida;
				if (entityUtil.checkEntityExists(contrapartida.getGrupoBancario()) && "CLIENTES".equals(contrapartida.getGrupoBancario().getId())) {
					return false;
					
				}
			}
		}
		return true;
	

	}

	public boolean aceptarValidator(){
		boolean esCorrecto = true;
		mostrarMensaje = false;
		cjtoCamposError.clear();
//		Date dtFecvalcan = formatUtil.getDate(cancelacionPantalla.getFecvalcan());
		fechamis = cancelacionBo.obtenerFechamis();
		Date dtFechaliq = formatUtil.getDate(cancelacionPantalla.getFechaliq());

//		MECAP 36691 FECHA CANCELACION
		Date dtFechaCan = formatUtil.getDate(cancelacionPantalla.getFechacan());
		
		Calendar calFechamis = Calendar.getInstance();
		calFechamis.setTime(fechamis);
		calFechamis.add(Calendar.DAY_OF_MONTH, 7);
		Date dtFechamis2 = calFechamis.getTime();
		
		String chkccirs = cancelacionBo.obtenerChkccirs(historicoOperacion.getProductoCatalogo().getProducat());

		//en la pantalla de Cancelaciones no se debe permitir margen de cancelación si la contrpartida es bancaria
		if((cancelacionPantalla.getImpcanof() != null || cancelacionPantalla.getDivicoof() != null) && esContrapartidaBancaria(historicoOperacion.getContrapartida())){
			
			statusMessages.add(StatusMessage.Severity.ERROR, "#{messages['boletas.dadesValidades.contrabancaria']}");
			esCorrecto = false;
			
		}else 
			if(cancelacionPantalla.getDivicoof() != null && 
			!validarDivisa(cancelacionPantalla.getDivicoof())) {
			esCorrecto = false;
		} else if(cancelacionPantalla.getDiprican() != null && 
			!validarDivisa(cancelacionPantalla.getDiprican())) {
			esCorrecto = false;
		} else if(cancelacionPantalla.getTipocanc() == null) {
			statusMessages.add(StatusMessage.Severity.ERROR, "#{messages['mantOper.cancelacion.error.tipocanc.obligatorio']}");
			cjtoCamposError.add("tipo");
			esCorrecto = false;
		} else if (cancelacionPantalla.getFecvalcan() == null) {
			statusMessages.add(StatusMessage.Severity.ERROR, "#{messages['mantOper.cancelacion.error.fecvalcan.obligatorio']}");
			esCorrecto = false;
		} else if(cancelacionPantalla.getSentamor() == null && "P".equalsIgnoreCase(cancelacionPantalla.getTipocanc())) {
			statusMessages.add(StatusMessage.Severity.ERROR, "#{messages['mantOper.cancelacion.error.sentoamor.obligatorio']}");
			esCorrecto = false;
		} else if("P".equalsIgnoreCase(cancelacionPantalla.getTipocanc())&& 
				(cancelacionPantalla.getAmortiza() == null || cancelacionPantalla.getAmortiza().compareTo(new BigDecimal(0)) == 0)) {
			statusMessages.add(StatusMessage.Severity.ERROR, "#{messages['mantOper.cancelacion.error.amortiza.obligatorio']}");
			esCorrecto = false;
		} else if ("P".equalsIgnoreCase(cancelacionPantalla.getTipocanc()) && cancelacionPantalla.getAmortiza().compareTo(cancelacionPantalla.getNomitota()) >= 0) {
			statusMessages.add(StatusMessage.Severity.ERROR, "#{messages['mantOper.cancelacion.error.amortiza.superiorigual']}");
			esCorrecto = false;
		} else if(((!GenericUtils.isNullOrBlank(cancelacionPantalla.getImprican()) && !BigDecimal.ZERO.equals(cancelacionPantalla.getImprican()) ) ||!GenericUtils.isNullOrBlank(cancelacionPantalla.getFechaliq())) 
				&&
				(GenericUtils.isNullOrBlank(cancelacionPantalla.getTiprican())|| GenericUtils.isNullOrBlank(cancelacionPantalla.getDiprican()) ||
				 GenericUtils.isNullOrBlank(cancelacionPantalla.getImprican()) ||GenericUtils.isNullOrBlank(cancelacionPantalla.getFechaliq())))

//		} else if((!GenericUtils.isNullOrBlank(cancelacionPantalla.getTiprican())|| !GenericUtils.isNullOrBlank(cancelacionPantalla.getDiprican()) ||
//				!GenericUtils.isNullOrBlank(cancelacionPantalla.getImprican()) ||!GenericUtils.isNullOrBlank(cancelacionPantalla.getFechaliq())) 
//				&&
//				(GenericUtils.isNullOrBlank(cancelacionPantalla.getTiprican())|| GenericUtils.isNullOrBlank(cancelacionPantalla.getDiprican()) ||
//				 GenericUtils.isNullOrBlank(cancelacionPantalla.getImprican()) ||GenericUtils.isNullOrBlank(cancelacionPantalla.getFechaliq())))
			{ if (GenericUtils.isNullOrBlank(cancelacionPantalla.getTiprican())){
				statusMessages.add(StatusMessage.Severity.ERROR, "#{messages['mantOper.cancelacion.error.indicadorPC.obligatorio']}");
				esCorrecto = false;
			} else if(GenericUtils.isNullOrBlank(cancelacionPantalla.getImprican())) {
				statusMessages.add(StatusMessage.Severity.ERROR, "#{messages['mantOper.cancelacion.error.importePC.obligatorio']}");				
				esCorrecto = false;
			} else if(GenericUtils.isNullOrBlank(cancelacionPantalla.getDiprican())) {
				statusMessages.add(StatusMessage.Severity.ERROR, "#{messages['mantOper.cancelacion.error.divisaPC.obligatorio']}");
				esCorrecto = false;
			} else if(GenericUtils.isNullOrBlank(cancelacionPantalla.getFechaliq())) {
				statusMessages.add(StatusMessage.Severity.ERROR, "#{messages['mantOper.cancelacion.error.fechaliq.obligatorio']}");
				esCorrecto = false;
			}
//MECAP 36691 FECHA CANCELACION
//		} else if(dtFecvalcan.before(fechamis)) {
//			statusMessages.add(StatusMessage.Severity.ERROR, "#{messages['mantOper.cancelacion.error.fecvalcan.igualsuperior']}");
//			esCorrecto = false;
//		} else if(dtFecvalcan.compareTo(dtFechamis2) >= 0) {
//			statusMessages.add(StatusMessage.Severity.ERROR, "#{messages['mantOper.cancelacion.error.fechasuperiorsemana']}");
//			esCorrecto = false;

		
		} else if(dtFechaCan.before(fechamis)) {
			statusMessages.add(StatusMessage.Severity.ERROR, "#{messages['mantOper.cancelacion.error.fecvalcan.igualsuperior']}");
			esCorrecto = false;
//		} else if(dtFecvalcan.compareTo(dtFechaCan) > 0) {
//			statusMessages.add(StatusMessage.Severity.ERROR, "#{messages['mantOper.cancelacion.error.fecvalcanSuperior.fechacan']}");
//			esCorrecto = false;

		} else if(!validarFechaLiquidacion(cancelacionPantalla.getFechaliq(),dtFechaliq,dtFechaCan,fechamis)){
				esCorrecto = false;
					
		} else if("S".equalsIgnoreCase(chkccirs) && "P".equalsIgnoreCase(cancelacionPantalla.getTipocanc()) && 
				(cancelacionPantalla.getAmortizap() == null || cancelacionPantalla.getAmortizap().compareTo(new BigDecimal(0)) == 0)) {
			statusMessages.add(StatusMessage.Severity.ERROR, "#{messages['mantOper.cancelacion.error.amortiza.cobro.obligatorio']}");
			esCorrecto = false;

		} else if(!GenericUtils.isNullOrBlank(cancelacionPantalla.getFechaEjec()) && !validarTimeStamp(cancelacionPantalla.getFechaEjec())){
			statusMessages.add(StatusMessage.Severity.ERROR, "#{messages['mantOper.cancelacion.error.formatoFechaEjec']}");
			esCorrecto = false;
		} else if (!validarCamposReporteTR()){
			statusMessages.add(StatusMessage.Severity.ERROR, "#{messages['mantOper.cancelacion.error.reporteTR']}");
			esCorrecto = false;
		} else if(cancelacionPantalla.getTiprican() != null) {
			if(tppareci != null && "P".equalsIgnoreCase(cancelacionPantalla.getTiprican())) {
				if (respuesta) {
	            	resetMensajes();
	            	esCorrecto = false;
	            }
			} else if(tppapago != null && "C".equalsIgnoreCase(cancelacionPantalla.getTiprican())) {
				if (respuesta) {
					resetMensajes();
					esCorrecto = false;
	            }
			}
		}
		
		return esCorrecto;
	}
	
	private boolean validarCamposReporteTR(){
		String pattern = "dd/mm/yyyy";
		SimpleDateFormat format = new SimpleDateFormat(pattern);
		Date fechaComparacion = null;
	 
		try {
			fechaComparacion = format.parse("03/01/2018");
		} catch (ParseException e) {
			fechaComparacion = new Date(2018, 1, 3);
		}
			
		
//Si es interna no hace falta validarlo.
	if (mantOperBo.esOperacionInterna(historicoOperacion)){
		return true;		
	}
	
	if (GenericUtils.isNullOrBlank(cancelacionPantalla.getUsuarioDecisor()) || GenericUtils.isNullOrBlank(cancelacionPantalla.getUsuarioEjecutor()) 
			|| GenericUtils.isNullOrBlank(cancelacionPantalla.getFechaEjec())){

		if ((!GenericUtils.isNullOrBlank(historicoOperacion.getProducto()) && !GenericUtils.isNullOrBlank(historicoOperacion.getProducto().getIndicadorClase2())
			&& GenericUtils.in(historicoOperacion.getProducto().getIndicadorClase2(),"RF","EQUI","CDS","CDI","RV")
			&& historicoOperacion.getId().getFechaContratacion().after(fechaComparacion)) 
			|| (!GenericUtils.isNullOrBlank(cancelacionPantalla.getTradeTv()) &&  "S".equalsIgnoreCase(cancelacionPantalla.getTradeTv().getCodigo())) 
			|| !GenericUtils.isNullOrBlank(historicoOperacion.getMicTv())){
		
		return false;
		}
		
	}
		return true;
	}
	
	private boolean validarFechaLiquidacion(String fechaliq, Date dtFechaliq, Date dtFechaCan, Date fechamis2){
		 if(!GenericUtils.isNullOrBlank(fechaliq)){
			 	if (dtFechaliq.compareTo(dtFechaCan) < 0) {
					statusMessages.add(StatusMessage.Severity.ERROR, "#{messages['mantOper.cancelacion.error.fechaliq.igualosuperior']}");
					return false;
			   }else if(dtFechaliq.compareTo(fechamis) < 0) {
					statusMessages.add(StatusMessage.Severity.ERROR, "#{messages['mantOper.cancelacion.error.fechaliq.igualsuperior']}");
					return false;
			   }
	}
	
		   return true;
	}
	
	
	private boolean esFechaValida(String contenidoCampo) {
		  if (contenidoCampo == null || !contenidoCampo.matches("\\d{4}-[01]\\d-[0-3]\\d"))
		        return false;
		    SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd");
		    df.setLenient(false);
		    try {
		        df.parse(contenidoCampo);
		        return true;
		    } catch (Exception ex) {
		        return false;
		    }
	}

	
	
	private boolean esHoraValida(String contenidoCampo) {
//		  if (contenidoCampo == null || !contenidoCampo.matches("\\d{4}-[01]\\d-[0-3]\\d"))
//		        return false;
//		  
		    SimpleDateFormat df = new SimpleDateFormat("HH:mm:ss");
		    df.setLenient(false);
		    try {
		        df.parse(contenidoCampo);
		        return true;
		    } catch (Exception ex) {
		        return false;
		    }
	}
	
	private boolean validarTimeStamp(String fechaEjec) {
		//Ejemplo 1999-09-29T15:12:59.132498
		
		if (fechaEjec.length() != 26) return false;
		
		if(!esFechaValida(fechaEjec.substring(0,10))) return false;
		
		if (!"T".equals(fechaEjec.substring(10,11))) return false;
		
		if (!esHoraValida(fechaEjec.substring(11,19))) return false;
		
		if (!".".equalsIgnoreCase(fechaEjec.substring(19,20))) return false;
		
		if (!fechaEjec.substring(20,26).matches("\\d{6}")) return false;
		
		return true;
	}
	
	
	public void aceptar() {
		
//		if((GenericUtils.isNullOrBlank(cancelacionPantalla.getImprican()) 
//				|| BigDecimal.ZERO.equals(cancelacionPantalla.getImprican()) ) 
//				&& GenericUtils.isNullOrBlank(cancelacionPantalla.getFechaliq())){
//			
//			cancelacionPantalla.setTiprican(null);
//			cancelacionPantalla.setDiprican(null);
//		}
		
		// COMPROBAR OPERACION PDTE. AGENDA
		if(operacionPdtAgenda() == 0 && "N".equals(modifCanc)) { //false
			statusMessages.add(StatusMessage.Severity.INFO, "#{messages['mantOper.cancelacion.error.operacionPendienteProcesar']}",
					historicoOperacion.getId().getNumeroOperacion(),historicoOperacion.getFechaValor(),
					historicoOperacion.getFechaVencimiento());
		} else {
			// COMPROBAR LIQUIDACIONES
			comprobarLiquidaciones();	
		}
	}
	
	public void continuarAceptar() {
		// Venimos de preguntarle al usuario si continuaba o no
		resetMensajes();
		// COMPROBAR FEULTACT ÚLTIMO REGISTRO
		Date feultact = cancelacionBo.obtenerMaxFeultact(historicoOperacion.getId().getNumeroOperacion(),historicoOperacion.getId().getFechaContratacion());
		if(feultact.compareTo(historicoOperacion.getId().getFechaModificacion()) != 0) {
			// DESBLOQUEAR
			dbLockService.desbloqueo(HistoricoOperacion.class, historicoOperacion.getId());
			statusMessages.add(StatusMessage.Severity.ERROR, "#{messages['mantOper.cancelacion.error.operacion.bloqueada']}",
					historicoOperacion.getId().getNumeroOperacion(),historicoOperacion.getId().getFechaContratacion());
		} else {
			// BLOQUEAR

			accion = "confirmar";
			mostrarMensaje = true;
			if(cancelacionPantalla.getTipocanc().equalsIgnoreCase("T"))
				mensajeConfirmacion.append(ResourceBundle.instance().getString("mantOper.cancelacion.success.confirmacion"));
			else
				mensajeConfirmacion.append(ResourceBundle.instance().getString("mantOper.cancelacionParcial.success.confirmacion"));
			
//			dbLockService.bloqueo(HistoricoOperacion.class, historicoOperacion.getId());
			// HACE UNA COPIA DE _TODO_ LO RELACIONADO CON LA,OPERACIÓN EN CURSO
			// FIXME da error
//			ModiNcorrelaReturn modiNcorrelaReturn = cancelacionBo.modiNcorrela(historicoOperacion,credentials.getUsername());
//			if(modiNcorrelaReturn != null) {
//				// FIXME da error
//				CancelarOperacionReturn cancelarOperacionReturn = cancelacionBo.cancelarOperacion(modiNcorrelaReturn.getFeultact(),historicoOperacion.getId().getFechaModificacion(),cancelacionPantalla.getTipocanc(),
//						cancelacionPantalla.getSentamor(),formatUtil.getDate(cancelacionPantalla.getFechacan()),formatUtil.getDate(cancelacionPantalla.getFecvalcan()),
//						formatUtil.getDate(cancelacionPantalla.getFechaliq()),cancelacionPantalla.getTiprican(),cancelacionPantalla.getImprican(),cancelacionPantalla.getDiprican(),
//						cancelacionPantalla.getImpcanof(),cancelacionPantalla.getDivicoof(),cancelacionPantalla.getAmortiza(),cancelacionPantalla.getAmortizap(),
//						cancelacionPantalla.getNominalt(),cancelacionPantalla.getNomitotap(),cancelacionPantalla.getNomitota(),cancelacionPantalla.getNominaltp(),
//						cancelacionPantalla.getObservac(),credentials.getUsername(),historicoOperacion);
//				
//				setFechaModificacion(modiNcorrelaReturn.getFeultact());
//				
//				if(cancelarOperacionReturn != null) {
////					if("P".equalsIgnoreCase(cancelarOperacionReturn.getCodError())) {
//					if(cancelarOperacionReturn.getRet() == 0) {
//						accion = "aceptar";
//						mostrarMensaje = true;
//						mensajeConfirmacion.append(ResourceBundle.instance().getString("mantOper.cancelacion.success.confirmacion"));
//					} else {
//						accion = "error";
//						mostrarMensaje = true;
//						if (cancelarOperacionReturn.getMensajeError()!=null){
//							mensajeConfirmacion.append(cancelarOperacionReturn.getMensajeError());	
//						}else{
//							mensajeConfirmacion.append(ResourceBundle.instance().getString("mantOper.cancelacion.error.desconocido"));	
//						}
//						
//					}
//				}
//			}
		}
	}
	
	public void continuarAceptarFinal(){
		
		resetMensajes();
		
		ModiNcorrelaReturn modiNcorrelaReturn = null;
		// FEULTACT
		
		
		
		if("PV".equalsIgnoreCase(historicoOperacion.getEstado().getCodigo()) && 
				("P".equalsIgnoreCase(historicoOperacion.getUltimaAccion().getCodigo()) ||
						"C".equalsIgnoreCase(historicoOperacion.getUltimaAccion().getCodigo()))) {
			Date feultact = cancelacionBo.obtenerFeultactVA(historicoOperacion);
			modiNcorrelaReturn = cancelacionBo.modiNcorrela(historicoOperacion,feultact,credentials.getUsername());
		} else {
			modiNcorrelaReturn = cancelacionBo.modiNcorrela(historicoOperacion,credentials.getUsername());
		}
		
		
		if (modiNcorrelaReturn == null || !GenericUtils.isNullOrBlank(modiNcorrelaReturn.getCodError()) || modiNcorrelaReturn.getRet()!=0){
			accion = "error";
			mostrarMensaje = true;
			if (modiNcorrelaReturn != null && !GenericUtils.isNullOrBlank(modiNcorrelaReturn.getCodError())  ){
				mensajeConfirmacion.append(modiNcorrelaReturn.getCodError());	
			}else{
				mensajeConfirmacion.append(ResourceBundle.instance().getString("mantOper.cancelacion.error.packagemodif"));
			}
		}else{
			
		
			setFechaModificacion(modiNcorrelaReturn.getFeultact());
			
			CancelarOperacionReturn cancelarOperacionReturn = cancelacionBo.cancelarOperacion(modiNcorrelaReturn.getFeultact(),historicoOperacion.getId().getFechaModificacion(),cancelacionPantalla.getTipocanc(),
					cancelacionPantalla.getSentamor(),formatUtil.getDate(cancelacionPantalla.getFechacan()),formatUtil.getDate(cancelacionPantalla.getFecvalcan()),
					formatUtil.getDate(cancelacionPantalla.getFechaliq()),cancelacionPantalla.getTiprican(),cancelacionPantalla.getImprican(),cancelacionPantalla.getDiprican(),
					cancelacionPantalla.getImpcanof(),cancelacionPantalla.getDivicoof(),cancelacionPantalla.getAmortiza(),cancelacionPantalla.getAmortizap(),
					cancelacionPantalla.getNominalt(),cancelacionPantalla.getNomitotap(),cancelacionPantalla.getNomitota(),cancelacionPantalla.getNominaltp(),
					cancelacionPantalla.getImportePrimaSub(), cancelacionPantalla.getMotivoCancel(), cancelacionPantalla.getClaveMurexRelacionada(),
					cancelacionPantalla.getIndiPostNegociacionOTC1(),cancelacionPantalla.getIndiPostNegociacionOTC2(),
					cancelacionPantalla.getIndiPostNegociacionOTC3(),cancelacionPantalla.getIndiPostNegociacionOTC4(),
					cancelacionPantalla.getIndiPostNegociacionOTC5(),cancelacionPantalla.getUsuarioDecisor(),cancelacionPantalla.getUsuarioEjecutor(),
					cancelacionPantalla.getFechaEjec(),cancelacionPantalla.getTradeTv(),cancelacionPantalla.getComplexTradeId(),
					cancelacionPantalla.getIsinInstrumento(),
					cancelacionPantalla.getValorActual(),cancelacionPantalla.getValorAnual(),cancelacionPantalla.getIndicadorNormaIV(),
					cancelacionPantalla.getObservac(),credentials.getUsername(),historicoOperacion);
			
			if(cancelarOperacionReturn != null) {
	//			if("P".equalsIgnoreCase(cancelarOperacionReturn.getCodError())) {
				if(cancelarOperacionReturn.getRet() == 0) {
					accion = "aceptar";
					mostrarMensaje = true;
					if(cancelacionPantalla.getTipocanc().equalsIgnoreCase("T"))
						mensajeConfirmacion.append(ResourceBundle.instance().getString("mantOper.cancelacion.success.cancelada"));
					else
						mensajeConfirmacion.append(ResourceBundle.instance().getString("mantOper.cancelacionParcial.success.cancelada"));
				} else {
					accion = "error";
					mostrarMensaje = true;
					if (cancelarOperacionReturn.getMensajeError()!=null){
						mensajeConfirmacion.append(cancelarOperacionReturn.getMensajeError());	
					}else{
						mensajeConfirmacion.append(ResourceBundle.instance().getString("mantOper.cancelacion.error.desconocido"));	
					}
					
				}
			}else{
				accion = "error";
				mostrarMensaje = true;
				mensajeConfirmacion.append(ResourceBundle.instance().getString("mantOper.cancelacion.error.package"));
			}
		}
	}
	
	public String comitarAceptar(boolean bol) {
		if(bol) {
			// TODO: se hará la actualizacion de la agenda y el COMMIT
			// PKG_MANTOPER.P_INSERT_CANCEL_AGENDOTC(V_SYSDATE);
			salirNcorrela("C");
			
			varModif = Constantes.CONSTANTE_SI;
			Conversation conv = Conversation.instance();
			if(conv != null && conv.isNested()){
				conv.redirectToParent();
			}
			
			return Constantes.CONSTANTE_SUCCESS;
		} else {
			varModif = Constantes.CONSTANTE_NO;
			salirNcorrela("R");
			// rollback
			return null;
		}
	}
	
	public void salir() {
		resetMensajes();
		dbLockService.desbloqueo(HistoricoOperacion.class, historicoOperacion.getId());
		varModif = Constantes.CONSTANTE_NO;
		Conversation conv = Conversation.instance();
		if(conv != null && conv.isNested()){
			conv.redirectToParent();
		}
		
//		salirNcorrela("R");
	}
	
	private void salirNcorrela(String accion) {
//		cancelacionBo.salirNcorrela(accion,historicoOperacion,credentials.getUsername());

		if (getFechaModificacion()!=null){
			cancelacionBo.salirNcorrelaFeUltAct(accion,historicoOperacion, credentials.getUsername(),getFechaModificacion());	
		}else{
			cancelacionBo.salirNcorrela(accion,historicoOperacion,credentials.getUsername());	
		}
		resetMensajes();
		dbLockService.desbloqueo(HistoricoOperacion.class, historicoOperacion.getId());
		primeraVez = true;
	}
	
	private int operacionPdtAgenda() {
		return cancelacionBo.operacionPdtAgenda(historicoOperacion);
	}
	
	
	public boolean  packageValidaciones(String error){
		
		StringBuffer errorCode = new StringBuffer();
		//SMM 14/06/2018 warn
		StringBuffer warn = new StringBuffer();
	
		//SMM 14/06/2018 warn
//	 if (!cancelacionBo.packageValidaciones(historicoOperacion,Identity.instance().getCredentials().getUsername(),Constantes.ORDEN_CANCELAR,errorCode)){	
	 if (!cancelacionBo.packageValidaciones(historicoOperacion,Identity.instance().getCredentials().getUsername(),Constantes.ORDEN_CANCELAR,errorCode,warn)){
		 error=errorCode.toString();
		 return false;
	}
	 	 return true;
	}
	

	private void comprobarLiquidaciones() {
		String error = "";
		resetMensajes();
		int count = cancelacionBo.cuantasLiquidaciones(historicoOperacion.getId().getNumeroOperacion(), "VA");
		if(count > 0){ 
//		&& ( historicoOperacion.getProductoCompuesto() == null || historicoOperacion.getProductoCompuesto().getEstructu() == 0)) { 
			// mostrar Mensaje pregunta('La operación tiene liquidaciones validadas. ¿Desea continuar?')
			accion = "cancelar";
			mostrarMensaje = true;
			mensajeConfirmacion.append(ResourceBundle.instance().getString("mantOper.cancelacion.error.liquidaciones"));
		//SMM 31/10/2017
		} else if (!packageValidaciones(error)){
			accion = "cancelar";
			mostrarMensaje = true;
			mensajeConfirmacion.append(ResourceBundle.instance().getString("mantOper.cancelacion.fail.confirmacion").concat(error));
		} else {
			continuarAceptar();
		}
	}
	
	public void validarTiprican() {
		if (historicoOperacion.getProductoCatalogo().getModelpro()==null || !Constantes.MODELO_OPCION.equalsIgnoreCase(historicoOperacion.getProductoCatalogo().getModelpro().getModelpro())){
		mensajeConfirmacion = new StringBuilder();
		accion = "validar";
		if(tppapago == null || tppareci == null) {
			RelProductoTransaccion relProductoTransaccion = cancelacionBo.obtenerRelProductoTransaccion(historicoOperacion.getProductoCatalogo(),historicoOperacion.getTransaccion());
			if(relProductoTransaccion != null) {
				tppapago = relProductoTransaccion.getTppapago();
				tppareci = relProductoTransaccion.getTppareci();
			}
		}
		if(!(tppareci != null && tppapago != null )){
			if(tppareci != null && "P".equalsIgnoreCase(cancelacionPantalla.getTiprican())) {
				// Mostrar mensaje pregunta('La prima para una opción de compra debería ser de Cobro. ¿Desea modificar el campo?');
				mostrarMensaje = true;
				mensajeConfirmacion.append(ResourceBundle.instance().getString("mantOper.cancelacion.error.tiprican.tppareci"));
			} else if(tppapago != null && "R".equalsIgnoreCase(cancelacionPantalla.getTiprican())) {
				// Mostrar mensaje pregunta('La prima para una opción de venta debería ser de Pago. ¿Desea modificar el campo?');
				mostrarMensaje = true;
				mensajeConfirmacion.append(ResourceBundle.instance().getString("mantOper.cancelacion.error.tiprican.tppapago"));
			}
		}
		}
	}
	
	private boolean validarDivisa(String codivisa) {
		if(codivisa != null && (historicoOperacion.getProductoCatalogo().getModelpro()==null || 
			!Constantes.MODELO_OPCION.equalsIgnoreCase(historicoOperacion.getProductoCatalogo().getModelpro().getModelpro()))) {
			PkgReturnBase valdivisaReturn = cancelacionBo.validarDivisa(historicoOperacion, formatUtil.getDate(cancelacionPantalla.getFecvalcan()),cancelacionPantalla.getSentamor(), 
					codivisa, cancelacionPantalla.getTipocanc());
			if(valdivisaReturn != null) {
				if(1 == valdivisaReturn.getRet()) {
					statusMessages.add(StatusMessage.Severity.ERROR, valdivisaReturn.getCodError());
					return false;
				}
			}
		}
		return true;
	}
	
	public void cambiarSentidoAmortizacion() {
		obtenerNominalTramoAction();
	}
	
	public void cambiarFecvalcan() {
		obtenerNominalTramoAction();
	}
	
	public void cambiarImporteAmortizacion() {
		if(cancelacionPantalla.getNomitota() != null && cancelacionPantalla.getAmortiza() != null &&
				cancelacionPantalla.getAmortiza().compareTo(cancelacionPantalla.getNomitota()) < 0) {
			cancelacionPantalla.setNominalt(cancelacionPantalla.getNomitota().subtract(cancelacionPantalla.getAmortiza()));
		}
		
		
		if(cancelacionPantalla.getNomitota() != null && cancelacionPantalla.getAmortizap() != null &&
				cancelacionPantalla.getAmortizap().compareTo(cancelacionPantalla.getNomitota()) < 0) {
			cancelacionPantalla.setNominaltp(cancelacionPantalla.getNomitota().subtract(cancelacionPantalla.getAmortizap()));
		}

	}
	
	public void cambiarTipoCancelacion() {
		String tipoCancelacion = cancelacionPantalla.getTipocanc();
		if(tipoCancelacion != null) {
			if(tipoCancelacion.equalsIgnoreCase("T")) {
				// CANCELACIÓN TOTAL
				// Queda Fijado El Sentamor Segun El Producto De La Operación
				cancelacionPantalla.setSentamor(null);
				cancelacionPantalla.setActivarSentoamor(false);
				cancelacionPantalla.setAmortiza(null);
				// Ocultamos Estos Campos Que Sólo Tienen Sentido Para Cancelación Parcial
				cancelacionPantalla.setAmortizap(null);
				cancelacionPantalla.setActivarAmortiza(false);
				cancelacionPantalla.setMostrarAmortizap(false);
				cancelacionPantalla.setMostrarNominaltp(false);
			} else {
				tipoCancelacionParcial();
			}
			cancelacionPantalla.setAmortiza(new BigDecimal(0));
			cancelacionPantalla.setAmortizap(new BigDecimal(0));
			cancelacionPantalla.setNominalt(new BigDecimal(0));
			cancelacionPantalla.setNominaltp(new BigDecimal(0));
			cancelacionPantalla.setNomitota(new BigDecimal(0));
			obtenerNominalTramoAction();
		} else {
			resetPantalla();
		}
	}

	private void tipoCancelacionParcial() {
		// CANCELACIÓN PARCIAL
		// Queda Fijado El Sentamor Segun El Producto De La Operación
		// ret[0] = sentoamor
		// ret[1] = patas
		String[] ret = cancelacionBo.obtenerSentidoAmortizacion(historicoOperacion.getId().getNumeroOperacion(), historicoOperacion.getId().getFechaContratacion(), historicoOperacion.getId().getFechaModificacion());
		// INICI TEST
//				ret[0] = "P";
//				ret[1] = "2";
		// FI TEST
		cancelacionPantalla.setSentamor(ret[0]);
		if("2".equalsIgnoreCase(ret[1])) {
			cancelacionPantalla.setMostrarAmortizap(true);
			cancelacionPantalla.setMostrarNominaltp(true);
			cancelacionPantalla.setLabelAmortiza(CancelacionPantalla.LABEL_AMORTIZADO_COBRO);
			cancelacionPantalla.setLabelNominalt(CancelacionPantalla.LABEL_NOMINAL_COBRO);
		}
		if (cancelacionPantalla.getTipocanc()!=null && "P".equals(cancelacionPantalla.getTipocanc())){
			cancelacionPantalla.setActivarAmortiza(true);
			cancelacionPantalla.setActivarSentoamor(false);			
		}else{
			cancelacionPantalla.setActivarAmortiza(false);
		}
			


	}

	private void resetPantalla() {
		cancelacionPantalla.setAmortiza(new BigDecimal(0));
		cancelacionPantalla.setAmortizap(new BigDecimal(0));
		cancelacionPantalla.setNominalt(new BigDecimal(0));
		cancelacionPantalla.setNominaltp(new BigDecimal(0));
		cancelacionPantalla.setNomitota(new BigDecimal(0));
		
		cancelacionPantalla.setMostrarAmortizap(false);
		cancelacionPantalla.setMostrarNominaltp(false);
		
		cancelacionPantalla.setActivarAmortiza(true);
		cancelacionPantalla.setActivarSentoamor(false);

		cancelacionPantalla.setLabelAmortiza(CancelacionPantalla.LABEL_AMORTIZADO);
		cancelacionPantalla.setLabelNominalt(CancelacionPantalla.LABEL_NOMINAL);
		
		resetMensajes();
	}
	
	private void resetMensajes() {
		mostrarMensaje = false;
		mensajeConfirmacion = new StringBuilder();
		respuesta = false;
		accion = "";
		fechaModificacion = null;
	}

	private void obtenerNominalTramoAction() {
		// LLAMAR PKG MANTOPER		
		NominalTramoReturn nominalTramoReturn = cancelacionBo.obtenerNominalTramo(historicoOperacion,cancelacionPantalla.getSentamor(),
				cancelacionPantalla.getTipocanc(),cancelacionPantalla.getAmortiza(),cancelacionPantalla.getAmortizap(),
				cancelacionPantalla.getNominalt(),cancelacionPantalla.getNominaltp(),cancelacionPantalla.getNomitota(),
				cancelacionPantalla.getNomitotap());
		if(nominalTramoReturn != null) {
			cancelacionPantalla.setAmortiza(nominalTramoReturn.getAmortiza());
			cancelacionPantalla.setAmortizap(nominalTramoReturn.getAmortizap());
			cancelacionPantalla.setNominalt(nominalTramoReturn.getNominalt());
			cancelacionPantalla.setNominaltp(nominalTramoReturn.getNominaltp());
			cancelacionPantalla.setNomitota(nominalTramoReturn.getNomitota());
			cancelacionPantalla.setNomitotap(nominalTramoReturn.getNomitotap());
			if(!GenericUtils.isNullOrBlank(nominalTramoReturn.getCodError())) {
				statusMessages.add(StatusMessage.Severity.INFO, nominalTramoReturn.getCodError());
			}
		}
		if (historicoOperacion !=null){
			CancelacionParcialId id = new CancelacionParcialId(historicoOperacion.getId().getFechaTratamiento(), historicoOperacion.getId().getNumeroOperacion(), historicoOperacion.getId().getFechaContratacion(), historicoOperacion.getId().getFechaModificacion());
			CancelacionParcial cancelacion = cancelacionBo.cargarCancelacion(id);
			if (cancelacion !=null){	
		
			cancelacionPantalla.setMotivoCancel(cancelacion.getMotivoCancel());
			cancelacionPantalla.setImportePrimaSub(cancelacion.getImportePrimaSub());
			cancelacionPantalla.setClaveMurexRelacionada(cancelacion.getClaveMurexRelacionada());
		
			}
		}
		
	}

	public Boolean getFilaBloqueada() {
		return filaBloqueada;
	}

	public boolean isRespuesta() {
		return respuesta;
	}

	public void setRespuesta(boolean respuesta) {
		mostrarMensaje = false;
		this.respuesta = respuesta;
	}

	public StringBuilder getMensajeConfirmacion() {
		return mensajeConfirmacion;
	}

	public void setMensajeConfirmacion(StringBuilder mensajeConfirmacion) {
		this.mensajeConfirmacion = mensajeConfirmacion;
	}

	public boolean isMostrarMensaje() {
		return mostrarMensaje;
	}

	public void setMostrarMensaje(boolean mostrarMensaje) {
		this.mostrarMensaje = mostrarMensaje;
	}

	public String getAccion() {
		return accion;
	}

	public void setAccion(String accion) {
		this.accion = accion;
	}

	public Date getFechaModificacion() {
		return fechaModificacion;
	}

	public void setFechaModificacion(Date fechaModificacion) {
		this.fechaModificacion = fechaModificacion;
	}

	@Factory("ListatradetvCanc")
	public List<DescripcionTradeOnTv> listaDescripcionTradeOnTv() {
			return boletasBo.getDescripcionTradeOnTv();
	}
	
	public void onMargenChange(){
		calculoNormaIV();
	}

	public boolean disableNormaIV(){
		
		if (GenericUtils.isNullOrBlank(tipoCliente)){
			obtenerTipoCliente();
		}
		
		if ("MN".equalsIgnoreCase(tipoCliente)){
			return false;
		}
//		if (!hasMifidTab() || GenericUtils.isNullOrBlank(autorizaOperacion) || GenericUtils.isNullOrBlank(autorizaOperacion.getTipoclie()) ||
//				!"MN".equalsIgnoreCase(autorizaOperacion.getTipoclie().getCodigo())){
//			
//			return true;
//		}	
		
		
		
		return true;	
	}
	
	private String obtenerTipoCliente(){
		
	Autoriza autorizaOperacion = null; 
	OperacionId id = new OperacionId(historicoOperacion.getId().getFechaContratacion(), historicoOperacion.getId().getNumeroOperacion());
	
	if (GenericUtils.isNullOrBlank(tipoCliente)){
		if (autorizaOperacion == null ) { 
			autorizaOperacion = entityManager.find(Autoriza.class, id);
			if (autorizaOperacion != null) {
				entityManager.refresh(autorizaOperacion);	
			}
		}
		
		if (!GenericUtils.isNullOrBlank(autorizaOperacion) && !GenericUtils.isNullOrBlank(autorizaOperacion.getTipoclie())){
			
			tipoCliente = autorizaOperacion.getTipoclie().getCodigo();
			return tipoCliente;
		}

	}
	
	return null;
	
	}
	
	public void calculoNormaIV(){
		
		if (GenericUtils.isNullOrBlank(cancelacionPantalla.getImpcanof()) || GenericUtils.isNullOrBlank(cancelacionPantalla.getDivicoof())) return;
		
		if (GenericUtils.isNullOrBlank(tipoCliente)){
			obtenerTipoCliente();
		}
		
		if ("MN".equalsIgnoreCase(tipoCliente)){
			
		
		
			StringBuffer errorCode = new StringBuffer();
			String tipoCalculo = "C";
			NormaIVParam paramNormaIV = new NormaIVParam();
			
			paramNormaIV.setImpcanof(cancelacionPantalla.getImpcanof());
			paramNormaIV.setDivisacoof(cancelacionPantalla.getDivicoof());
			paramNormaIV.setFechaCancelacion(GenericUtils.deStringToDate(cancelacionPantalla.getFechacan()));
		
		//if (false){
			if (!mantOperBo.calculoNormaIV(historicoOperacion,paramNormaIV,tipoCalculo, errorCode)){
				statusMessages.add(Severity.WARN, "#{messages['boletas.packageNormaIV']}" + errorCode.toString());
			}else{
				
				cancelacionPantalla.setValorActual(paramNormaIV.getValorActual());
				cancelacionPantalla.setValorAnual(paramNormaIV.getValorAnual());
				
				comprobarAvisoNormaIV();
			}
	
		}
		
	}
	
	public void comprobarAvisoNormaIV() {
		
		if (!GenericUtils.isNullOrBlank(cancelacionPantalla.getValorActual()) && !GenericUtils.isNullOrBlank(cancelacionPantalla.getValorAnual()) ){
			
			NormaIVParam umbrales = boletasBo.obtenerUmbralesNormaIV();
			
			if (umbrales!=null){
				//-1, 0, or 1 as this BigDecimal is numerically less than, equal to, or greater than val.
				if (cancelacionPantalla.getValorActual().compareTo(umbrales.getUmbralValorActual())>0 || cancelacionPantalla.getValorAnual().compareTo(umbrales.getUmbralValorAnual())>0){
					cancelacionPantalla.setIndicadorNormaIV(true);
				}else{
					cancelacionPantalla.setIndicadorNormaIV(false);
				}
			}else{
				if (cancelacionPantalla.getValorActual().compareTo(new BigDecimal(5))>0 || 
						cancelacionPantalla.getValorAnual().compareTo(new BigDecimal(0.6))>0){
					cancelacionPantalla.setIndicadorNormaIV(true);
				}else{
					cancelacionPantalla.setIndicadorNormaIV(false);
				}
			}

		}
	}


}
