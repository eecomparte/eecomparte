package com.atosorigin.deri.adminoper.mantOperaciones.action;

import java.math.BigDecimal;

import org.jboss.seam.ScopeType;
import org.jboss.seam.annotations.In;
import org.jboss.seam.annotations.Name;
import org.jboss.seam.annotations.Out;
import org.jboss.seam.annotations.Scope;
import org.jboss.seam.international.StatusMessage;
import org.jboss.seam.security.Credentials;

import com.atosorigin.common.action.GenericAction;
import com.atosorigin.common.constantes.Constantes;
import com.atosorigin.common.utils.GenericUtils;
import com.atosorigin.deri.adminoper.mantOperaciones.screen.CancelacionPantalla;
import com.atosorigin.deri.adminoper.mantoper.business.CancelacionBo;
import com.atosorigin.deri.model.adminoper.CancelacionParcial;
import com.atosorigin.deri.model.adminoper.CancelacionParcialId;
import com.atosorigin.deri.model.adminoper.NominalTramoReturn;
import com.atosorigin.deri.model.gestionoperaciones.HistoricoOperacion;

@Name("cancelacionDetalleAction")
@Scope(ScopeType.CONVERSATION)
public class CancelacionDetalleAction extends GenericAction{

	private static final long serialVersionUID = -6531936794522619171L;

	@In Credentials credentials;

	@In("#{cancelacionBo}")
	private CancelacionBo cancelacionBo;

	@In
	private CancelacionPantalla cancelacionPantalla;

	@In(required=true)
	private HistoricoOperacion historicoOperacionDetalle;
	
	/** Inyección del objeto para la union con MANTPROD  */
	@In(required=false)
	@Out(required= false)
	String varModif;
	
	private boolean primeraVez = true;
	
	public CancelacionDetalleAction(){}
	
	public void init(){
		if (primeraVez){
			tipoCancelacionParcial();
			obtenerNominalTramoAction();
			primeraVez = false;
		}
	}

	public void salir() {
		resetPantalla();
		varModif = Constantes.CONSTANTE_NO;
	}

	private void tipoCancelacionParcial() {

		String[] ret = cancelacionBo.obtenerSentidoAmortizacion(historicoOperacionDetalle.getId().getNumeroOperacion(), historicoOperacionDetalle.getId().getFechaContratacion(), historicoOperacionDetalle.getId().getFechaModificacion());
		cancelacionPantalla.setSentamor(ret[0]);
		if("2".equalsIgnoreCase(ret[1])) {
			cancelacionPantalla.setMostrarAmortizap(true);
			cancelacionPantalla.setMostrarNominaltp(true);
			cancelacionPantalla.setLabelAmortiza(CancelacionPantalla.LABEL_AMORTIZADO_COBRO);
			cancelacionPantalla.setLabelNominalt(CancelacionPantalla.LABEL_NOMINAL_COBRO);
		}
		if (cancelacionPantalla.getTipocanc()!=null && "P".equals(cancelacionPantalla.getTipocanc())){
			cancelacionPantalla.setActivarAmortiza(true);
			cancelacionPantalla.setActivarSentoamor(false);			
		}else{
			cancelacionPantalla.setActivarAmortiza(false);
		}
	}

	private void resetPantalla() {
		cancelacionPantalla.setAmortiza(new BigDecimal(0));
		cancelacionPantalla.setAmortizap(new BigDecimal(0));
		cancelacionPantalla.setNominalt(new BigDecimal(0));
		cancelacionPantalla.setNominaltp(new BigDecimal(0));
		cancelacionPantalla.setNomitota(new BigDecimal(0));
		
		cancelacionPantalla.setMostrarAmortizap(false);
		cancelacionPantalla.setMostrarNominaltp(false);
		
		cancelacionPantalla.setActivarAmortiza(true);
		cancelacionPantalla.setActivarSentoamor(false);

		cancelacionPantalla.setLabelAmortiza(CancelacionPantalla.LABEL_AMORTIZADO);
		cancelacionPantalla.setLabelNominalt(CancelacionPantalla.LABEL_NOMINAL);
	}

	private void obtenerNominalTramoAction() {
		NominalTramoReturn nominalTramoReturn = cancelacionBo.obtenerNominalTramo(historicoOperacionDetalle,cancelacionPantalla.getSentamor(),
				cancelacionPantalla.getTipocanc(),cancelacionPantalla.getAmortiza(),cancelacionPantalla.getAmortizap(),
				cancelacionPantalla.getNominalt(),cancelacionPantalla.getNominaltp(),cancelacionPantalla.getNomitota(),
				cancelacionPantalla.getNomitotap());
		
		if(nominalTramoReturn != null) {
			cancelacionPantalla.setAmortiza(nominalTramoReturn.getAmortiza());
			cancelacionPantalla.setAmortizap(nominalTramoReturn.getAmortizap());
			cancelacionPantalla.setNominalt(nominalTramoReturn.getNominalt());
			cancelacionPantalla.setNominaltp(nominalTramoReturn.getNominaltp());
			cancelacionPantalla.setNomitota(nominalTramoReturn.getNomitota());
			cancelacionPantalla.setNomitotap(nominalTramoReturn.getNomitotap());
			if(!GenericUtils.isNullOrBlank(nominalTramoReturn.getCodError())) {
				statusMessages.add(StatusMessage.Severity.INFO, nominalTramoReturn.getCodError());
			}
		}
		
		if (historicoOperacionDetalle !=null){
			CancelacionParcialId id = new CancelacionParcialId(historicoOperacionDetalle.getId().getFechaTratamiento(), historicoOperacionDetalle.getId().getNumeroOperacion(), historicoOperacionDetalle.getId().getFechaContratacion(), historicoOperacionDetalle.getId().getFechaModificacion());
			CancelacionParcial cancelacion = cancelacionBo.cargarCancelacion(id);
			if (cancelacion !=null){	
				cancelacionPantalla.setMotivoCancel(cancelacion.getMotivoCancel());
				cancelacionPantalla.setImportePrimaSub(cancelacion.getImportePrimaSub());
				cancelacionPantalla.setClaveMurexRelacionada(cancelacion.getClaveMurexRelacionada());
			}
		}
	}
}
