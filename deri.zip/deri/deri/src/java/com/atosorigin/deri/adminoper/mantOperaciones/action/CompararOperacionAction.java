package com.atosorigin.deri.adminoper.mantOperaciones.action;

import java.util.ArrayList;
import java.util.List;

import javax.faces.context.FacesContext;
import javax.servlet.http.HttpServletRequest;

import org.jboss.seam.ScopeType;
import org.jboss.seam.annotations.Factory;
import org.jboss.seam.annotations.In;
import org.jboss.seam.annotations.Name;
import org.jboss.seam.annotations.Out;
import org.jboss.seam.annotations.Scope;
import org.jboss.seam.annotations.datamodel.DataModel;
import org.jboss.seam.annotations.datamodel.DataModelSelection;

import com.atosorigin.common.action.PaginatedListAction;
import com.atosorigin.deri.adminoper.boletas.business.BoletasBo;
import com.atosorigin.deri.adminoper.mantoper.business.LogOperacionBo;
import com.atosorigin.deri.adminoper.mantoper.business.MantOperBo;
import com.atosorigin.deri.gestionoperaciones.compararoperacion.business.ComparaOperacionBo;
import com.atosorigin.deri.model.gestionoperaciones.ComparaDatos;
import com.atosorigin.deri.model.gestionoperaciones.ComparaOperacion;
import com.atosorigin.deri.model.gestionoperaciones.HistoricoOperacion;


@Name("compararOperacionAction")
@Scope(ScopeType.CONVERSATION)

public class CompararOperacionAction extends PaginatedListAction implements java.io.Serializable{

	private static final long serialVersionUID = 1L;


	@In(required=true)
	@Out
	private HistoricoOperacion historicoOperacion;

	@In("#{mantOperBo}")
	private MantOperBo mantOperBo;
	@In("#{boletasBo}")
	private BoletasBo boletasBo;
	@In("#{logOperacionBo}")
	private LogOperacionBo logOperacionBo;
	
	@In("#{comparaOperacionBo}")
	private ComparaOperacionBo comparaOperacionBo;
	
	@DataModel(value = "listaComparacionOp")
	private List<ComparaOperacion> listaComparacionList = null;

	@DataModelSelection(value = "listaComparacionOp")
	private ComparaOperacion listaComparacionSelected;

	@In(required=true)
	private ComparaDatos comparaDatos;
	
	public CompararOperacionAction(){
	}
	
	
	@Override
	public List<ComparaOperacion> getDataTableList() {
		return this.getListaComparacionList();
	}

	@Override
	protected void refreshListInternal() {
		setExportExcel(false);
		listaComparacionList = null;
	}

	@Override
	public void refrescarListaExcel() {
		setExportExcel(true);
	}
	

	@SuppressWarnings("unchecked")
	@Override
	public void setDataTableList(List<?> dataTableList) {
		this.setListaComparacionList(((List<ComparaOperacion>)dataTableList));
	}



	
	@Factory(value = "listaComparacionOp")
	public void initListaOperaciones() {
		if(listaComparacionList==null){
			listaComparacionList = new ArrayList<ComparaOperacion>();
		}
		listaComparacionList.clear();
//		listaComparacionList.addAll((List<HistoricoOperacion>)logOperacionBo.obtenerLogOperacion(historicoOperacion));
	}

	public HistoricoOperacion getHistoricoOperacion() {
		return historicoOperacion;
	}

	public void setHistoricoOperacion(HistoricoOperacion historicoOperacion) {
		this.historicoOperacion = historicoOperacion;
	}

	public MantOperBo getMantOperBo() {
		return mantOperBo;
	}

	public void setMantOperBo(MantOperBo mantOperBo) {
		this.mantOperBo = mantOperBo;
	}

	public BoletasBo getBoletasBo() {
		return boletasBo;
	}

	public void setBoletasBo(BoletasBo boletasBo) {
		this.boletasBo = boletasBo;
	}

	public LogOperacionBo getLogOperacionBo() {
		return logOperacionBo;
	}

	public void setLogOperacionBo(LogOperacionBo logOperacionBo) {
		this.logOperacionBo = logOperacionBo;
	}


	public List<ComparaOperacion> getListaComparacionList() {
		return listaComparacionList;
	}

	public void setListaComparacionList(List<ComparaOperacion> listaComparacionList) {
		this.listaComparacionList = listaComparacionList;
	}

	public ComparaOperacion getListaComparacionSelected() {
		return listaComparacionSelected;
	}

	public void setListaComparacionSelected(
			ComparaOperacion listaComparacionSelected) {
		this.listaComparacionSelected = listaComparacionSelected;
	}

	public void salir(){
		//TODO Se debe borrar el contenido de la tabla para la petición X
		comparaOperacionBo.borrarDatos(getSessionId());
		
	}



	public String getRowClasses(){
		StringBuilder builder = new StringBuilder();
		int i=0;
		for (ComparaOperacion compara : listaComparacionList) {
			if(i>0){
				builder.append(",");
			}
			
// BOLETA - CALENDARIO - INDICES			
//			if(vl.getLiqOriginal()!=null){
//				builder.append("resaltarRow");
//			}
			else{
				if(i%2==0){
					builder.append("oddRow");
				}
				else{
					builder.append("evenRow");
				}
			}
			i++;
		}
		return builder.toString();
	}
	

	/**
	 * Gets the session id.
	 * 
	 * @return the session id
	 */
	private String getSessionId() {
		HttpServletRequest request = (HttpServletRequest)FacesContext.getCurrentInstance().getExternalContext().getRequest();
		return request.getSession().getId();
	}
	

   public void init(){
	   listaComparacionList =   comparaOperacionBo.obtenerDatos(comparaDatos.getHistoricoOperacionA(),comparaDatos.getHistoricoOperacionB(),getSessionId());	   
   }
}
