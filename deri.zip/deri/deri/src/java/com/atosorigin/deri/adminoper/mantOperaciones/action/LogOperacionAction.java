package com.atosorigin.deri.adminoper.mantOperaciones.action;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.jboss.seam.ScopeType;
import org.jboss.seam.annotations.Factory;
import org.jboss.seam.annotations.In;
import org.jboss.seam.annotations.Name;
import org.jboss.seam.annotations.Out;
import org.jboss.seam.annotations.Scope;
import org.jboss.seam.annotations.datamodel.DataModel;
import org.jboss.seam.annotations.datamodel.DataModelSelection;

import com.atosorigin.common.action.PaginatedListAction;
import com.atosorigin.common.constantes.Constantes;
import com.atosorigin.common.excelexporter.CustomExcelExporter;
import com.atosorigin.deri.adminoper.boletas.action.BoletasAction.BoletasStates;
import com.atosorigin.deri.adminoper.boletas.business.BoletasBo;
import com.atosorigin.deri.adminoper.cancelacionparcial.business.CancelacionParcialBo;
import com.atosorigin.deri.adminoper.mantOperaciones.screen.CancelacionPantalla;
import com.atosorigin.deri.adminoper.mantoper.business.CancelacionBo;
import com.atosorigin.deri.adminoper.mantoper.business.LogOperacionBo;
import com.atosorigin.deri.adminoper.mantoper.business.MantOperBo;
import com.atosorigin.deri.model.adminoper.CancelacionParcial;
import com.atosorigin.deri.model.gestionoperaciones.ComparaDatos;
import com.atosorigin.deri.model.gestionoperaciones.HistoricoOperacion;


@Name("logOperacionAction")
@Scope(ScopeType.CONVERSATION)

public class LogOperacionAction extends PaginatedListAction implements java.io.Serializable{

	private static final long serialVersionUID = 1L;

	@In(required=false)
	private BoletasStates boletaState;
	
	@In(required=true)
	@Out
	private HistoricoOperacion historicoOperacion;

	@In("#{mantOperBo}")
	private MantOperBo mantOperBo;
	
	@In("#{boletasBo}")
	private BoletasBo boletasBo;
	
	@In("#{cancelacionParcialBo}")
	private CancelacionParcialBo cancelacionParcialBo;
	
	@In("#{logOperacionBo}")
	private LogOperacionBo logOperacionBo;
	
	@In(value="#{customExcelExporter}")
	protected CustomExcelExporter customExcelExporter;
		
	@DataModel(value = "logOperacion.listaResultados")
	private List<HistoricoOperacion> listaOperacionesList = null;

	@DataModelSelection(value = "logOperacion.listaResultados")
	private HistoricoOperacion HistoricoOperacionSelected;

	@Out
	private ComparaDatos comparaDatos = new ComparaDatos();
	
	@In(create = true)
	@Out(required = false)
	private CancelacionPantalla cancelacionPantalla;
	
	@In("#{cancelacionBo}")
	private CancelacionBo cancelacionBo;
	
	@Out
	private HistoricoOperacion historicoOperacionDetalle = new HistoricoOperacion();
	
	/** Logger */
	protected Log logger = LogFactory.getLog(LogOperacionAction.class);
	
	public LogOperacionAction(){
	}
	
	public String consultaOperacion(){
		historicoOperacion = HistoricoOperacionSelected;
		boletasBo.prepareConsultaCorrela(HistoricoOperacionSelected);
		boletaState = BoletasStates.CONSULTA_BOLETA;
		return Constantes.SUCCESS;
	}
	
	@Override
	public List<HistoricoOperacion> getDataTableList() {
		return this.getListaOperacionesList();
	}

	@Override
	protected void refreshListInternal() {
		setExportExcel(false);
		listaOperacionesList = null;
	}

	@Override
	public void refrescarListaExcel() {
		setExportExcel(true);
	}
	
	@SuppressWarnings("unchecked")
	@Override
	public void setDataTableList(List<?> dataTableList) {
		this.setListaOperacionesList(((List<HistoricoOperacion>)dataTableList));
	}

	public void excel(){
		//llamar a refrescar lista excel
		customExcelExporter.generarExcel("tablaDetalle:detalle", this);
	}
	
	@Factory(value = "logOperacion.listaResultados")
	public void initListaOperaciones() {
		if(listaOperacionesList==null){
			listaOperacionesList = new ArrayList<HistoricoOperacion>();
		}
		listaOperacionesList.clear();
		listaOperacionesList.addAll((List<HistoricoOperacion>)logOperacionBo.obtenerLogOperacion(historicoOperacion));
	}

	public BoletasStates getBoletaState() {
		return boletaState;
	}

	public void setBoletaState(BoletasStates boletaState) {
		this.boletaState = boletaState;
	}

	public HistoricoOperacion getHistoricoOperacion() {
		return historicoOperacion;
	}

	public void setHistoricoOperacion(HistoricoOperacion historicoOperacion) {
		this.historicoOperacion = historicoOperacion;
	}

	public MantOperBo getMantOperBo() {
		return mantOperBo;
	}

	public void setMantOperBo(MantOperBo mantOperBo) {
		this.mantOperBo = mantOperBo;
	}

	public BoletasBo getBoletasBo() {
		return boletasBo;
	}

	public void setBoletasBo(BoletasBo boletasBo) {
		this.boletasBo = boletasBo;
	}

	public LogOperacionBo getLogOperacionBo() {
		return logOperacionBo;
	}

	public void setLogOperacionBo(LogOperacionBo logOperacionBo) {
		this.logOperacionBo = logOperacionBo;
	}

	public CustomExcelExporter getCustomExcelExporter() {
		return customExcelExporter;
	}

	public void setCustomExcelExporter(CustomExcelExporter customExcelExporter) {
		this.customExcelExporter = customExcelExporter;
	}

	public List<HistoricoOperacion> getListaOperacionesList() {
		return listaOperacionesList;
	}

	public void setListaOperacionesList(List<HistoricoOperacion> listaOperacionesList) {
		this.listaOperacionesList = listaOperacionesList;
	}

	public HistoricoOperacion getHistoricoOperacionSelected() {
		return HistoricoOperacionSelected;
	}

	public void setHistoricoOperacionSelected(HistoricoOperacion historicoOperacionSelected) {
		HistoricoOperacionSelected = historicoOperacionSelected;
	}


	private HashSet<HistoricoOperacion> listasSeleccionadas = new HashSet<HistoricoOperacion>();

	public Boolean getSelectedRow(){
		return listasSeleccionadas.contains(getHistoricoOperacionSelected());
	}

	public void setSelectedRow(Boolean selected){
		if(selected){
			if (listasSeleccionadas.size()< 2){
				listasSeleccionadas.add(getHistoricoOperacionSelected());	
			}
		}
		else{
			listasSeleccionadas.remove(getHistoricoOperacionSelected());
//			listaSuscripcionesPantalla.setSeleccionTotal(false);
		}
	}
	
	public void seleccionarLista(){

	}

	public Boolean isCompararEnabled(){
		return (listasSeleccionadas.size()!= 2);
	}
	public void comparar(){
		//Obtener registros?
		//PKG nos devuelve datos y número de petición.
		//Pasar operaciones a otra pantalla
		int i = 0;
		for (HistoricoOperacion operacion : listasSeleccionadas) {
			
			if (i==0){
				comparaDatos.setHistoricoOperacionA(operacion);	
			}else{
				comparaDatos.setHistoricoOperacionB(operacion);	
			}
			
			i++;
		}
		
	}
	
	public HashSet<HistoricoOperacion> getListasSeleccionadas() {
		return listasSeleccionadas;
	}

	public void setListasSeleccionadas(
			HashSet<HistoricoOperacion> listasSeleccionadas) {
		this.listasSeleccionadas = listasSeleccionadas;
	}
	
	public String consultaCancelacionDetalle(HistoricoOperacion hist){
		historicoOperacionDetalle = hist;
		boletasBo.prepareConsultaCorrela(historicoOperacionDetalle);
		return prepararCancelarDetalle();
	}

	public String prepararCancelarDetalle() {
		cancelacionPantalla.reset();
		
		//No queremos la fecha actual ya que no la vamos a modificar, queremos recuperar la fecha en que se realizó la cancelación. 
		//Date fechamis = cancelacionBo.obtenerFechamis();
		//cancelacionPantalla.setFechacan(fechamis);

		if (historicoOperacionDetalle.getDivisaMargenOficina() != null) {
			cancelacionPantalla.setDivicoof(historicoOperacionDetalle.getDivisaMargenOficina().getId());
		}
		
		logger.info("prepararCancelarDetalle:\n"
				.concat("\t\t NCorrela: " + historicoOperacionDetalle.getId().getNumeroOperacion()+"\n")
				.concat("\t\t F.Operación: " + historicoOperacionDetalle.getId().getFechaContratacion()+"\n")
				.concat("\t\t F.Tratamiento: " + historicoOperacionDetalle.getId().getFechaTratamiento()+"\n")
				.concat("\t\t F.Ult Actualización: " + historicoOperacionDetalle.getId().getFechaModificacion()));
		
		CancelacionParcial cp = cancelacionParcialBo.obtenerCancelacionParcial(historicoOperacionDetalle.getId().getNumeroOperacion(), historicoOperacionDetalle.getId().getFechaContratacion(), historicoOperacionDetalle.getId().getFechaModificacion(),historicoOperacionDetalle.getId().getFechaTratamiento());
		
		if (cp != null) {
			//SMM MECAP-36691 FECHA CANCELACION
//			cancelacionPantalla.setFecvalcan(cp.getFechaCancelacion());
			cancelacionPantalla.setFecvalcan(cp.getFechaValor());
			cancelacionPantalla.setFechacan(cp.getFechaCancelacion());
			
			//05/03/2019 SMM
			cancelacionPantalla.setMotivoCancel(cp.getMotivoCancel());
			

			
			cancelacionPantalla.setFechaliq(cp.getFechaLiquidacionPrima());
			cancelacionPantalla.setTiprican(cp.getTipoPrima());
			cancelacionPantalla.setImprican(cp.getImportePrima());
			cancelacionPantalla.setImpcanof(cp.getImporteMargenCancelacion());
			cancelacionPantalla.setDiprican(cp.getDivisa());
			cancelacionPantalla.setTipocanc(cp.getTipoCancelacion());
			cancelacionPantalla.setSentamor(cp.getPataAmortizada());
			
			String chkccirs = cancelacionBo.obtenerChkccirs(historicoOperacionDetalle.getProductoCatalogo().getProducat());

			cancelacionPantalla.setIndiPostNegociacionOTC1(cp.getIndiPostNegociacionOTC1());
			cancelacionPantalla.setIndiPostNegociacionOTC2(cp.getIndiPostNegociacionOTC2());
			cancelacionPantalla.setIndiPostNegociacionOTC3(cp.getIndiPostNegociacionOTC3());
			cancelacionPantalla.setIndiPostNegociacionOTC4(cp.getIndiPostNegociacionOTC4());
			cancelacionPantalla.setIndiPostNegociacionOTC5(cp.getIndiPostNegociacionOTC5());
			cancelacionPantalla.setUsuarioDecisor(cp.getUsuarioDecisor());
			cancelacionPantalla.setUsuarioEjecutor(cp.getUsuarioEjecutor());
			cancelacionPantalla.setFechaEjec(cp.getFechaEjec());
			cancelacionPantalla.setTradeTv(cp.getTradeTv());
			cancelacionPantalla.setComplexTradeId(cp.getComplexTradeId());
			cancelacionPantalla.setIsinInstrumento(cp.getIsinInstrumento());

			cancelacionPantalla.setValorActual(cp.getValorActual());
			cancelacionPantalla.setValorAnual(cp.getValorAnual());
			cancelacionPantalla.setIndicadorNormaIV(cp.getIndicadorNormaIV());

			if ("S".equalsIgnoreCase(chkccirs) && "P".equalsIgnoreCase(cp.getTipoCancelacion())) {

				cancelacionPantalla.setNominaltp(cp.getNominalPago());
				cancelacionPantalla.setNominalt(cp.getNominalRecibo());
				cancelacionPantalla.setAmortizap(cp.getImporteAmortizarPago());
				cancelacionPantalla.setAmortiza(cp.getImporteAmortizarRecibo());

			} else {

				if (cp.getPataAmortizada() == null || "A".equalsIgnoreCase(cp.getPataAmortizada())) {
					cancelacionPantalla.setNominalt(cp.getNominalRecibo());
					cancelacionPantalla.setAmortiza(cp.getImporteAmortizarRecibo());
				} else if ("P".equalsIgnoreCase(cp.getPataAmortizada())) {
					cancelacionPantalla.setNominalt(cp.getNominalPago());
					cancelacionPantalla.setAmortiza(cp.getImporteAmortizarPago());
				} else {
					cancelacionPantalla.setNominalt(cp.getNominalRecibo());
					cancelacionPantalla.setAmortiza(cp.getImporteAmortizarRecibo());
				}
			}
		}

		cancelacionPantalla.setObservac(historicoOperacionDetalle.getObservacionesCancelacion());
		cancelacionPantalla.setNomitota(BigDecimal.ZERO);

		return "TO_CANCELACION_DETALLE";
	}
}
