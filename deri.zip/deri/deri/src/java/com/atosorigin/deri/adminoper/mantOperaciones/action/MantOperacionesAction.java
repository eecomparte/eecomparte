package com.atosorigin.deri.adminoper.mantOperaciones.action;

import java.math.BigDecimal;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import java.util.Set;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceException;
import javax.transaction.Status;
import javax.transaction.UserTransaction;

import org.hibernate.SQLQuery;
import org.hibernate.annotations.Type;
import org.jboss.seam.ScopeType;
import org.jboss.seam.annotations.Factory;
import org.jboss.seam.annotations.In;
import org.jboss.seam.annotations.Name;
import org.jboss.seam.annotations.Out;
import org.jboss.seam.annotations.Scope;
import org.jboss.seam.annotations.datamodel.DataModel;
import org.jboss.seam.annotations.datamodel.DataModelSelection;
import org.jboss.seam.core.Conversation;
import org.jboss.seam.core.ResourceBundle;
import org.jboss.seam.international.StatusMessage.Severity;
import org.jboss.seam.security.Identity;

import com.atosorigin.common.action.PaginatedListAction;
import com.atosorigin.common.constantes.Constantes;
import com.atosorigin.common.formvalidator.FormValidator;
import com.atosorigin.common.utils.GenericUtils;
import com.atosorigin.deri.adminoper.boletas.action.BoletasAction.BoletasStates;
import com.atosorigin.deri.adminoper.boletas.business.BoletasBo;
import com.atosorigin.deri.adminoper.mantOperaciones.screen.CancelacionPantalla;
import com.atosorigin.deri.adminoper.mantoper.business.CancelacionBo;
import com.atosorigin.deri.adminoper.mantoper.business.MantOperBo;
import com.atosorigin.deri.adminoper.mantoqe.business.MantoqeBarreraBo;
import com.atosorigin.deri.common.authentication.CustomIdentity;
import com.atosorigin.deri.common.dbLock.DbLockService;
import com.atosorigin.deri.common.parametrosPantalla.ParametrosManteje;
import com.atosorigin.deri.common.parametrosPantalla.ParametrosMantoper;
import com.atosorigin.deri.dao.adminoper.boletas.AltaCorrelaResult;
import com.atosorigin.deri.dao.mercado.DescripcionFormula;
import com.atosorigin.deri.model.adminoper.Autoriza;
import com.atosorigin.deri.model.adminoper.BusquedaOperacion;
import com.atosorigin.deri.model.adminoper.CancelacionParcial;
import com.atosorigin.deri.model.adminoper.DescripcionEstiloOpcion;
import com.atosorigin.deri.model.adminoper.DescripcionTradeOnTv;
import com.atosorigin.deri.model.adminoper.GenericRange;
import com.atosorigin.deri.model.adminoper.HistoricoBarrera;
import com.atosorigin.deri.model.adminoper.HistoricoOpcion;
import com.atosorigin.deri.model.adminoper.IndicadorConfirmacion;
import com.atosorigin.deri.model.adminoper.NivelOperacion;
import com.atosorigin.deri.model.adminoper.RelProductoTransaccion;
import com.atosorigin.deri.model.catalogo.DescripcionSituacion;
import com.atosorigin.deri.model.catalogo.Producto;
import com.atosorigin.deri.model.contrapartida.Contrapartida;
import com.atosorigin.deri.model.contrapartida.TipoContrapartida;
import com.atosorigin.deri.model.gestionoperaciones.DescripcionEstadoOperacion;
import com.atosorigin.deri.model.gestionoperaciones.DescripcionTransaccionOperacion;
import com.atosorigin.deri.model.gestionoperaciones.HistoricoBarreraReturn;
import com.atosorigin.deri.model.gestionoperaciones.HistoricoOperacion;
import com.atosorigin.deri.model.gestionoperaciones.HistoricoOperacionId;
import com.atosorigin.deri.model.gestionoperaciones.MantoqeGlobal;
import com.atosorigin.deri.model.gestionoperaciones.Operacion;
import com.atosorigin.deri.model.gestionoperaciones.OperacionCasada;
import com.atosorigin.deri.model.gestionoperaciones.OperacionId;
import com.atosorigin.deri.model.gestionoperaciones.VistaOperacion;
import com.atosorigin.deri.model.gestionoperaciones.VistaOperacion.VistaOperacionBTN;
import com.atosorigin.deri.model.murex.ModeloProducto;
import com.atosorigin.deri.model.murex.ProcedenciaProducto;
import com.atosorigin.deri.model.murex.ProductoCatalogo;
import com.atosorigin.deri.model.murex.RelProductoFormula;
import com.atosorigin.deri.model.parametrizacion.Divisa;
import com.atosorigin.deri.util.ContrapartidaUtil;
import com.atosorigin.deri.util.EntityUtil;
import com.atosorigin.deri.util.ErrorMessage;
import com.atosorigin.deri.util.InterceptExceptions;
import com.atosorigin.deri.util.MessageBoxAction;
import com.atosorigin.deri.util.MsgBoxAction;
import com.atosorigin.deri.util.ErrorMessage.TypeError;

@Name("mantOperacionesAction")
@Scope(ScopeType.CONVERSATION)
@InterceptExceptions
@FormValidator
public class MantOperacionesAction extends PaginatedListAction implements java.io.Serializable {

	private static final long serialVersionUID = 4371127399433844329L;
	
	/* IN's y OUT's */
	
	@In
	private EntityManager entityManager;
	
	@In(create = true)
	MsgBoxAction msgBoxAction;
	@In("#{mantOperBo}")
	private MantOperBo mantOperBo;
	@In("#{boletasBo}")
	private BoletasBo boletasBo;
	@In("#{cancelacionBo}")
	private CancelacionBo cancelacionBo;
	
	@In("#{mantoqeBarreraBo}")
	private MantoqeBarreraBo mantoqeBarreraBo;
	
	@In
	private ContrapartidaUtil contrapartidaUtil;
	
	@In(create = true) /* Inyección del servicio que gestiona los bloqueos de registros en base de datos */
	private DbLockService dbLockService;
	@In(required=false)/* Para la union con producto compuestos */
	protected VistaOperacion vistaOperacionProdComp;
	@Out(required = false)
	private HistoricoOperacion historicoOperacion;
	@Out(required = false)
	private HistoricoOperacionId historicoOperacionBloqueadoId;
	@Out(required = false)
	@In(required = false )//Se pasa el valor desde productos compuestos
	private BoletasStates boletaState;
	@In(required = false, value = "parametrosMantOper")
	@Out(required = false, value = "parametrosMantOper")
	private ParametrosMantoper parametrosMantOper;
	@Out(required = false, value = "modo")
	private String modoConfirmacion;
	@In(create = true)
	@Out(required = false)
	private CancelacionPantalla cancelacionPantalla;
	@Out
	private String modifCanc = "N";
	
	@Out(required = false, value = "ParametrosManteje")
	ParametrosManteje parametrosManteje;
	
	@Out(value="origen")
	private String origen = Constantes.MODO_OPE;
	@In("org.jboss.seam.core.locale")	
	private Locale locale;
	@Out(required=false)
	protected List<Operacion> listaOpOut = new ArrayList<Operacion>();
	/* CAMPS DE LES FACTORIES */
	@Out(required = false, value = "mantOperaciones.procedencia")
	List<ProcedenciaProducto> procedenciaProductoList = null;
	@Out(required = false, value = "mantOperaciones.modelo")
	List<ModeloProducto> modeloProductoList = null;
	@Out(required = false, value = "mantOperaciones.productoCatalogo")
	List<ProductoCatalogo> productoCatalogoList = null;
	@Out(required = false, value = "mantOperaciones.productoOperacion")
	List<Producto> productoOperacionList = null;
	@Out(required = false, value = "mantOperaciones.divisa")
	List<Divisa> divisasList = null;
	@Out(required = false, value = "mantOperaciones.transaccion")
	List<DescripcionTransaccionOperacion> transaccionesList = null;
	@Out(required = false, value = "mantOperaciones.nivCaptura")
	List<NivelOperacion> nivCapturaList = null;
	@Out(required = false, value = "mantOperaciones.tipoContrapa")
	List<TipoContrapartida> tipoContrapartidasList = null;
	@Out(required = false, value = "mantOperaciones.situacion")
	List<BusquedaOperacion> busquedaOperacionesList = null;
	@Out(required = false, value = "mantOperaciones.formula")
	List<DescripcionFormula> descripcionFormulaList = null;
	
	@Out(required=false)
	private Boolean refreshPending=false;
	
	@Out(required = false, value = "mantOperMessageBoxAction")
	private MessageBoxAction messageBoxActionMO;
	
	/*
    * variables de contexto Integra con MANTANEX
    */
	@Out(required=false)
	private String modoTratamiento;
	
	@Out(required=false)
	private String tipoAnexo;	
	
	@Out(value = "origenPantalla")
	private String origenPantalla = "MO";

	/* CAMPOS DE PRESENTACION */
	private ProcedenciaProducto procedencia;
	private ModeloProducto modelo;
	private ProductoCatalogo productoCatalogo;
	private Producto productoOperacion;
	private DescripcionTransaccionOperacion transaccionOperacion;
	private NivelOperacion nivelOperacion;
	private String contrapartida;
	private TipoContrapartida tipoContrapa;
	private Divisa divisaPago;
	private Divisa divisaCobro;
	private BusquedaOperacion situacion;
	private DescripcionFormula formula;
	private String suReferencia;

	private Boolean cobertura =false;
	private Boolean pendienteConf = false;
	private Boolean estructura =false;
	private Boolean campana =false;

	private int maxSelected;

	private Integer ultimRegistre;
	
	private GenericRange<Long> numOper = new GenericRange<Long>("numoper", Long.class);
	private GenericRange<Date> fechaVal = new GenericRange<Date>("fechaval", Date.class);
	private GenericRange<Date> fechaVen = new GenericRange<Date>("fechaven", Date.class);
	private GenericRange<Date> fechaOpe = new GenericRange<Date>("fechaope", Date.class);
	private GenericRange<Long> numEstructu = new GenericRange<Long>("estructu", Long.class);
	private GenericRange<Long> clExterna = new GenericRange<Long>("clexterna", Long.class);
	private GenericRange<String> clBduGid = new GenericRange<String>("clbdugid", String.class);
	private GenericRange<Date> fechaCan = new GenericRange<Date>("fechacan", Date.class);

	@DataModel(value = "mantOperaciones.listaResultados")
	private List<VistaOperacion> listaOperacionesList = null;

	@DataModelSelection(value = "mantOperaciones.listaResultados")
	private VistaOperacion vistaOperacionSelected;

	private HashSet<VistaOperacion> listasSeleccionadas = new HashSet<VistaOperacion>();

	@DataModel(value = "mantOperaciones.listaErrores")
	private List<ErrorMessage> listaErrores = new ArrayList<ErrorMessage>();

	private String msgBoxHeaderListaErrores;
	private String msgBoxHeaderResultado;
	public String getMsgBoxHeaderResultado() {
		return msgBoxHeaderResultado;
	}

	public void setMsgBoxHeaderResultado(String msgBoxHeaderResultado) {
		this.msgBoxHeaderResultado = msgBoxHeaderResultado;
	}

	private String msgBoxNoProcessable;
	private boolean msgBoxFinalStep = false;
	private boolean msgBoxMessageMode = false;
	private String msgBoxWidth = "350";

	public String consultar() {
		historicoOperacion = vistaOperacionSelected.getHistOper();
		mantOperBo.refreshHistDeri(historicoOperacion);
		if ( ! mantOperBo.validateLastFechaModificacion(historicoOperacion)){
			statusMessages.add(Severity.ERROR , "Se ha modificado este historico, vuelva a realizar la busqueda para continuar");
			return Constantes.FAIL;
		}
		//boletasBo.prepareConsultaCorrela(historicoOperacion);
		boletaState = BoletasStates.CONSULTA_BOLETA;
		return Constantes.SUCCESS;
	}

	
	public String mostrarCalendario() {
		log.info("CALENDAR");
		historicoOperacion = vistaOperacionSelected.getHistOper();
		mantOperBo.refreshHistDeri(historicoOperacion);
		if ( ! mantOperBo.validateLastFechaModificacion(historicoOperacion)){
			statusMessages.add(Severity.ERROR , "Se ha modificado este historico, vuelva a realizar la busqueda para continuar");
			return Constantes.FAIL;
		}
		//boletasBo.prepareConsultaCorrela(historicoOperacion);
		boletaState = BoletasStates.CONSULTA_BOLETA;
		
		return Constantes.SUCCESS;
	}

	public void visualizarLogOperaciones() {
		historicoOperacion = vistaOperacionSelected.getHistOper();
		boletaState = BoletasStates.CONSULTA_BOLETA;
		modoConfirmacion = Constantes.MODO_OPE;
	}

	public void buscar() {
		
		ultimRegistre = 0;
		listaOperacionesList = null; // Provocamos que la factory se vuelva a regenerar
		paginationData.reset(); // Como regeneramos la lista, tambien reiniciamos el paginationData
		listasSeleccionadas.clear(); // Si buscamos perdemos las operaciones seleccionadas
		// Limpiamos los parametros ya que buscamos directamente
		initParametrosMantOper();
		//Forzamos a que sea en modo OPER al haber pulsado el botón buscar.
		parametrosMantOper.setModo(Constantes.MODO_OPE);
		setPrimerAcceso(false);
	}
	
	public boolean buscarValidator() {
		boolean ret = true;
		
		if(numOper != null && numOper.getLow() != null && numOper.getHigh() != null) {
			if(numOper.getLow() > numOper.getHigh()) {
				statusMessages.add(Severity.ERROR, "#{messages['mantOper.messages.error.numOper']}");
				ret = false;
			}
		}
		if(fechaVal != null && fechaVal.getLow() != null && fechaVal.getHigh() != null) {
			if(fechaVal.getLow().after(fechaVal.getHigh())) {
				statusMessages.add(Severity.ERROR, "#{messages['mantOper.messages.error.fechaValor']}");
				ret = false;
			}
		}
		if(fechaVen != null && fechaVen.getLow() != null && fechaVen.getHigh() != null) {
			if(fechaVen.getLow().after(fechaVen.getHigh())) {
				statusMessages.add(Severity.ERROR, "#{messages['mantOper.messages.error.fechaVto']}");
				ret = false;
			}
		}
		if(fechaOpe != null && fechaOpe.getLow() != null && fechaOpe.getHigh() != null) {
			if(fechaOpe.getLow().after(fechaOpe.getHigh())) {
				statusMessages.add(Severity.ERROR, "#{messages['mantOper.messages.error.fechaOpe']}");
				ret = false;
			}
		}
		if(numEstructu != null && numEstructu.getLow() != null && numEstructu.getHigh() != null) {
			if(numEstructu.getLow() > numEstructu.getHigh()) {
				statusMessages.add(Severity.ERROR, "#{messages['mantOper.messages.error.numEstructu']}");
				ret = false;
			}
		}
		if(clExterna != null && clExterna.getLow() != null && clExterna.getHigh() != null) {
			if(clExterna.getLow() > clExterna.getHigh()) {
				statusMessages.add(Severity.ERROR, "#{messages['mantOper.messages.error.clExterna']}");
				ret = false;
			}
		}
		if(fechaCan != null && fechaCan.getLow() != null && fechaCan.getHigh() != null) {
			if(fechaCan.getLow().after(fechaCan.getHigh())) {
				statusMessages.add(Severity.ERROR, "#{messages['mantOper.messages.error.fechaCan']}");
				ret = false;
			}
		}

		
//		if(clBduGid != null && clBduGid.getLow() != null && clBduGid.getHigh() != null) {
//			if(clBduGid.getLow() > clBduGid.getHigh()) {
//				statusMessages.add(Severity.ERROR, "#{messages['mantOper.messages.error.clBduGid']}");
//				ret = false;
//			}
//		}

		
		return ret;
	}
	
	public void buscarRefresco() {
		listaOperacionesList = null; // Probocamos que la factory se vuelva a regenerar
//		paginationData.reset(); // Como regeneramos la lista, tambien reiniciamos el paginationData
		listasSeleccionadas.clear(); // Si buscamos perdemos las operaciones seleccionadas
		// Limpiamos los parametros ya que buscamos directamente
		initParametrosMantOper();
		setPrimerAcceso(false);
	}
	
	public void salir(){
		Conversation conversacion = Conversation.instance();
		//Volvemos a la anterior conversación
		if(conversacion.isNested()){
			conversacion.redirectToParent();
		} else {
			redirectToURL("/home.seam");
			conversacion.endAndRedirect();
		}
	}

	public void init(){
		//Salva Mensaje para validar Operaciones.
		if (messageBoxActionMO==null){
			messageBoxActionMO = new MessageBoxAction();
		}
			
		if(listaOperacionesList!=null && refreshPending){
			buscarRefresco();
			refreshPending=false;
		}
	}
	
	
	public void onMessageBoxRetrocederOk(){
		prepareRetrocederDos();
	}

	public void prepareRetroceder(){
		messageBoxActionMO.init("mantOper.messages.retroceder.pregunta", "mantOperacionesAction.onMessageBoxRetrocederOk()",
		"mantOperacionesAction.voidFunction()","helperPanel");
	}
	public void prepareRetrocederDos(){
		if(listasSeleccionadas.size() > 0){
			listaErrores.clear();
			if(!parametrosMantOper.getModo().equals(Constantes.MODO_OPM)){
				for (VistaOperacion vo : listasSeleccionadas) {
					try{
						String estadoco = vo.getHistOper().getEstado().getCodigo();
						String indsitua = vo.getHistOper().getUltimaAccion().getCodigo();
						//retrocesión del resto de operaciones descomentar esta línea y borrar la siguiente
						if(estadoco.equals("PV") && GenericUtils.in(indsitua, "M","P","C","T","E","J")){
							if(vo.getHistOper().getCampanya() != null && vo.getHistOper().getUltimaAccion().getCodigo().equals("C") &&
								   mantOperBo.validateCampanasAndLiquidaciones(vo.getHistOper()) && indsitua.equals("C")){										  
								   addWarning(vo,ResourceBundle.instance().getString("mantOper.messages.retroceder.campanasLiquidaciones"));
								   calculateRetroceder(vo.getHistOper());
							
							} else if (mantOperBo.validateCampanasAndLiquidaciones(vo.getHistOper()) && 
									(indsitua.equals("C")|| indsitua.equals("P") || indsitua.equals("M"))) {
								   addWarning(vo,ResourceBundle.instance().getString("mantOper.messages.retroceder.LiquidacionesValidadas"));
								   calculateRetroceder(vo.getHistOper());
							}else {
								if(mantOperBo.validateProductoCompuesto(vo.getHistOper())){ //true -> Mostramos mensaje producto Compuesto
									addError(vo,ResourceBundle.instance().getString("mantOper.messages.retroceder.productoCompuesto"));
									//Eliminamos la seleccion
								} else {
									calculateRetroceder(vo.getHistOper());
								}
							}						
						}else{
							addError(vo,ResourceBundle.instance().getString("mantOper.messages.retroceder.estado"));
						}
							
					}catch (NullPointerException e) {
						e.printStackTrace();
						addError(vo,ResourceBundle.instance().getString("mantOper.messages.generic.noInfo"));
					}catch (Exception e) {
						e.printStackTrace();
						addError(vo,ResourceBundle.instance().getString("mantOper.messages.generic.noInfo"));
					}
				}
			}
			if(listaErrores.size() == 0){ //No tenemos ningun error podemos validar
				retroceder();
			}else{
				msgBoxFirstStep();
				prepareMsgBox("retroceder");
			}
		} else {
		}
	}

	//*************************TODO!!!!
	private void calculateRetroceder(HistoricoOperacion historicoOperacion){
		if (mantOperBo.validatePendientesAgendaValid(historicoOperacion)) {
			addError(historicoOperacion, ResourceBundle.instance().getString("mantOper.messages.retroceder.agenda"));
		} else if (mantOperBo.validateExistenciaAgendaValid(historicoOperacion)){
			addError(historicoOperacion, ResourceBundle.instance().getString("mantOper.messages.retroceder.evento"));
		} else {
			if (!dbLockService.bloqueo(HistoricoOperacion.class, historicoOperacion.getId())) {
				addError(historicoOperacion, ResourceBundle.instance().getString("mantOper.messages.retroceder.blocked"));
			} else {
				if (!mantOperBo.validateLastFechaModificacion(historicoOperacion)) {
					dbLockService.desbloqueo(HistoricoOperacion.class, historicoOperacion.getId());
					addError(historicoOperacion, ResourceBundle.instance().getString("mantOper.messages.retroceder.noLastUpdate"));
				} else {
					// Llamariamos a la funcion de validar Real
					println("Retrocedemos ncorrela: " + historicoOperacion.getId().getNumeroOperacion() + ", F.Ope: "
							+ historicoOperacion.getId().getFechaModificacion());
				}
			}
		}
	}

	public void retroceder() {
		int operValidadas = 0;
		limpiarErrores();
		this.msgBoxHeaderResultado ="";
		
		StringBuffer errorCode;
		for (VistaOperacion vo : listasSeleccionadas) {
			if(!tieneErrores(vo)){
				errorCode = new StringBuffer();
				if (!mantOperBo.callRetroceder(vo.getHistOper(), Identity.instance().getCredentials().getUsername(), errorCode)) {
					addError(vo.getHistOper(), ResourceBundle.instance().getString("mantOper.messages.retroceder.cantValidate") + errorCode.toString());
				}else{
					operValidadas++;
				}
				dbLockService.desbloqueo(HistoricoOperacion.class, vo.getHistOper().getId());
			} else {
				addError(vo.getHistOper(), ResourceBundle.instance().getString("mantOper.messages.retroceder.noSelection"));
			}
		}
		if (listaErrores.size() > 0) {
			msgBoxFinalStep();
			this.msgBoxHeaderResultado = "Total de operaciones retrocedidas: "+ operValidadas ; 			
			prepareMsgBox("validarFinal");
		} else {			
			msgBoxFinalStep();
			this.msgBoxHeaderResultado = "Total de operaciones retrocedidas: "+ operValidadas ;
			prepareMsgBox("validarFinal");			
		}
		
		listasSeleccionadas.clear();
		actualizarListaOperaciones(listaOperacionesList); //limpiamos la factory

	}
	
	public void retrocederDesbloquear() {
		for (VistaOperacion vo : listasSeleccionadas) {
			dbLockService.desbloqueo(HistoricoOperacion.class, vo.getHistOper().getId());
		}
	}
	
	public void onMessageBoxValidarOk(){
		prepareValidarDos();
	}

	public void onMessageBoxValidarBatchOk(){
		validarBatch();
	}
	
	public void prepareValidar(){
		if (!mantOperBo.isAgendaCorriendo()){
			statusMessages.add(Severity.ERROR, "#{messages['mantoper.agendaParadaValidar']}" );
		}else{
		messageBoxActionMO.init("mantOper.messages.validar.pregunta", "mantOperacionesAction.onMessageBoxValidarOk()",
		"mantOperacionesAction.voidFunction()","helperPanel");
		}
	}

	public void prepareValidarBatch(){
		if (!mantOperBo.isAgendaCorriendo()){
			statusMessages.add(Severity.ERROR, "#{messages['mantoper.agendaParadaValidar']}" );
		}else{

		messageBoxActionMO.init("mantOper.messages.validar.pregunta", "mantOperacionesAction.onMessageBoxValidarBatchOk()",
		"mantOperacionesAction.voidFunction()","helperPanel, resultadosConsulta");

		}
	}
	
	public void prepareValidarDos(){
		if(listasSeleccionadas.size() > 0){
			listaErrores.clear();
			if(!parametrosMantOper.getModo().equals(Constantes.MODO_OPM)){
				for (VistaOperacion vo : listasSeleccionadas) {
					try{
						String estadoco = vo.getHistOper().getEstado().getCodigo();
						String indsitua = vo.getHistOper().getUltimaAccion().getCodigo();
						if(estadoco.equals("PV")){
							if(mantOperBo.validateProductoCompuesto(vo.getHistOper())){ //true -> Mostramos mensaje producto Compuesto
								addError(vo,ResourceBundle.instance().getString("mantOper.messages.validar.productoCompuesto"));
								//Eliminamos la seleccion
								//SMM 04/07/2018 Aviso Validacion Cancelaciones Minoristas
								//Warning - Clients minoristas, usuari integracio RUT*, pvc pvp (cancelacions) y validar sense entrar a la pantalla
							} else if ((indsitua.equals("C")|| indsitua.equals("P")) 
//									&& vo.getHistOper().getUsuario().startsWith("RUT") 
									&& !validarUsuario(vo.getHistOper().getUsuario())
									&& !mantOperBo.esOperacionInterna(vo.getHistOper()) 
									&& esClienteMinorista(vo.getHistOper())	) {
									   addError(vo,ResourceBundle.instance().getString("mantOper.messages.validar.minorista"));
								
								 
							} else {
							
							if(vo.getHistOper().getCampanya() != null && vo.getHistOper().getUltimaAccion().getCodigo().equals("C") &&
							   mantOperBo.validateCampanasAndLiquidaciones(vo.getHistOper()) && indsitua.equals("C")){
								   
								   addWarning(vo,ResourceBundle.instance().getString("mantOper.messages.validar.campanasLiquidaciones"));
							} 
							
							if (mantOperBo.validateCampanasAndLiquidaciones(vo.getHistOper()) && 
									(indsitua.equals("C")|| indsitua.equals("P") || indsitua.equals("M")) ) {
								   addWarning(vo,ResourceBundle.instance().getString("mantOper.messages.validar.LiquidacionesValidadas"));
							
							} 
							
//							if (esContrapaCliente(vo.getHistOper()) && !GenericUtils.isNullOrBlank(vo.getHistOper().getProductoCatalogo()) && 
//									( vo.getHistOper().getProductoCatalogo().getProducat().equals(4L) ||
//									  vo.getHistOper().getProductoCatalogo().getProducat().equals(1751201L) )
//										){ 
//								   addWarning(vo,ResourceBundle.instance().getString("mantOper.messages.validar.irsNegativo"));
//							
//							}
							
							
								calculateValidar(vo.getHistOper());
							
							}
						}else{
							addError(vo,ResourceBundle.instance().getString("mantOper.messages.validar.estado"));
						}
							
					}catch (NullPointerException e) {
						e.printStackTrace();
						addError(vo,ResourceBundle.instance().getString("mantOper.messages.generic.noInfo"));
					}catch (Exception e) {
						e.printStackTrace();
						addError(vo,ResourceBundle.instance().getString("mantOper.messages.generic.noInfo"));
					}
				}
			}
			if(listaErrores.size() == 0){ //No tenemos ningun error podemos validar
				validar();
			}else{
				msgBoxFirstStep();
				prepareMsgBox("validar");
			}
		} else {
		}
	}

	private boolean esClienteMinorista(HistoricoOperacion histOper) {
		Autoriza autorizaOperacion = null;
		
		OperacionId id = new OperacionId(histOper.getId().getFechaContratacion(), histOper.getId().getNumeroOperacion());
		autorizaOperacion = entityManager.find(Autoriza.class, id);
		
		
		if (GenericUtils.isNullOrBlank(autorizaOperacion) || GenericUtils.isNullOrBlank(autorizaOperacion.getTipoclie()) ||
				!"MN".equalsIgnoreCase(autorizaOperacion.getTipoclie().getCodigo())){
			
			return false;
		}
		
		return true;
		
	}

	private boolean validarUsuario(String usuario) {
		
		if (GenericUtils.isNullOrBlank(mantOperBo.buscarUsuarioUsername(usuario))){
			return false;
		}else{
			return true;	
		}
		
	}
	
	public void validar() {
		int operValidadas = 0;
		limpiarErrores();
		this.msgBoxHeaderResultado ="";
		
		StringBuffer errorCode;
//		
		//SMM 21/11/2011 TIMEOUT
		UserTransaction ut = null;

		ut = ((javax.transaction.UserTransaction)org.jboss.seam.transaction.Transaction.instance());
			
		try {
			if (ut.getStatus()== Status.STATUS_ACTIVE){
				ut.commit();
				}
			ut.setTransactionTimeout(3000);
			ut.begin();
			entityManager.joinTransaction();
			
	
		//SMM 21/11/2011 TIMEOUT1
//		
		for (VistaOperacion vo : listasSeleccionadas) {
			if(!tieneErrores(vo)){
				errorCode = new StringBuffer();
				if (!mantOperBo.callValidar(vo.getHistOper(), Identity.instance().getCredentials().getUsername(), errorCode)) {
					addError(vo.getHistOper(), ResourceBundle.instance().getString("mantOper.messages.validar.cantValidate") + errorCode.toString());
				}else{
					operValidadas++;
				}
				dbLockService.desbloqueo(HistoricoOperacion.class, vo.getHistOper().getId());
			} else {
				addError(vo.getHistOper(), ResourceBundle.instance().getString("mantOper.messages.validar.noSelection"));
			}
		}
		if (listaErrores.size() > 0) {
			prepareMsgBox("validarFinal");
		} else {
			if(operValidadas>0){
				msgBoxFinalStep(true);
				listasSeleccionadas.clear();
				String msgValidadas = String.valueOf(operValidadas) + ResourceBundle.instance().getString("mantOper.messages.validadas");
				messageBoxActionMO.initString(msgValidadas, "mantOperacionesAction.voidFunction()","", 
						"helperPanel,messagesPanel,mantOperacionesForm,messageBoxPanelValidar," +
						"msgboxPanelMantOper,resultadosConsulta");
			}

		}
//
		int transactionTimeoutSeconds = 300;
        ((javax.transaction.UserTransaction)org.jboss.seam.transaction.Transaction.instance()).setTransactionTimeout(transactionTimeoutSeconds);

		msgBoxFinalStep(true);actualizarListaOperaciones(listaOperacionesList); //limpiamos la factory
//		
//		
		//SMM TIMEOUT2
		
		} catch (Exception e) {
			e.printStackTrace();
			try {
				ut.rollback();
			} catch (Exception e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
		}finally{
		try {
			if (ut.getStatus()!= Status.STATUS_ACTIVE){
				ut.setTransactionTimeout(300);
				ut.begin();
				entityManager.joinTransaction();
				}
		} catch (Exception e) {
			e.printStackTrace();
		}
		}
		//SMM TIMEOUT3
	}

	public void validarDesbloquear() {
		for (VistaOperacion vo : listasSeleccionadas) {
			dbLockService.desbloqueo(HistoricoOperacion.class, vo.getHistOper().getId());
		}
	}

	private void validarBatch(){
		if(listasSeleccionadas!=null && listasSeleccionadas.size() > 0){
			Long peticion = mantOperBo.tratamientoValidarBatch(listasSeleccionadas);
			String mensaje = ResourceBundle.instance().getString("liquidaciones.registros.validadosBatch") + " " + peticion ;
			statusMessages.add(Severity.INFO, mensaje);
			listasSeleccionadas.clear();
		}
	}
	
	private void calculateValidar(HistoricoOperacion historicoOperacion){
		
		
		StringBuffer errorCode = new StringBuffer();
		//SMM 14/06/2018 warm
		StringBuffer warn = new StringBuffer();
		
		if (mantOperBo.validatePendientesAgendaValid(historicoOperacion)) {
			addError(historicoOperacion, ResourceBundle.instance().getString("mantOper.messages.validar.agenda"));
		} else if (mantOperBo.validateExistenciaAgendaValid(historicoOperacion)){
			addError(historicoOperacion, ResourceBundle.instance().getString("mantOper.messages.validar.evento"));
//SMM 14/06/2018 warn		
//		} else if (!mantOperBo.packageValidaciones(historicoOperacion,Identity.instance().getCredentials().getUsername(),Constantes.ORDEN_VALIDAR,errorCode)){
//			addError(historicoOperacion, ResourceBundle.instance().getString("mantOper.messages.modificar.noSelection") + errorCode.toString());
		} else if (!mantOperBo.packageValidaciones(historicoOperacion,Identity.instance().getCredentials().getUsername(),Constantes.ORDEN_VALIDAR,errorCode,warn)){
			
			if (!GenericUtils.isNullOrBlank(warn) && "99".equals(warn.toString())){
//				addWarning(historicoOperacion, ResourceBundle.instance().getString("mantOper.messages.modificar.noSelection") + errorCode.toString());
				addWarning(historicoOperacion, errorCode.toString());
			}else{
			addError(historicoOperacion, ResourceBundle.instance().getString("mantOper.messages.modificar.noSelection") + errorCode.toString());
			}
			
		} else {
			if (!dbLockService.bloqueo(HistoricoOperacion.class, historicoOperacion.getId())) {
				addError(historicoOperacion, ResourceBundle.instance().getString("mantOper.messages.validar.blocked"));
			} else {
				if (!mantOperBo.validateLastFechaModificacion(historicoOperacion)) {
					dbLockService.desbloqueo(HistoricoOperacion.class, historicoOperacion.getId());
					addError(historicoOperacion, ResourceBundle.instance().getString("mantOper.messages.validar.noLastUpdate"));
				} else {
					// Llamariamos a la funcion de validar Real
					println("Validamos ncorrela: " + historicoOperacion.getId().getNumeroOperacion() + ", F.Ope: "
							+ historicoOperacion.getId().getFechaModificacion());
				}
			}
		}
	}

	
	public String confirmar() {
		this.msgBoxHeaderResultado = "";
		listaErrores.clear();
		if (!parametrosMantOper.getModo().equals(Constantes.MODO_OPM)) {
			VistaOperacion vo = vistaOperacionSelected;
			//Validamos si se puede confirmar esta operación
			if(mantOperBo.calculoNumConfirmacionesDeOperacion(vo.getNcorrela())==0){
				addError(vo,ResourceBundle.instance().getString("mantOper.messages.validar.sin.pendientes"));
			}else{

				try {
					String estadoco = vo.getHistOper().getEstado().getCodigo();
					String indsitua = vo.getHistOper().getUltimaAccion().getCodigo();
					if (estadoco.equals("CA") || estadoco.equals("AN") || (estadoco.equals("VA") && indsitua != "E" && indsitua != "T")) {
						if (mantOperBo.validateNumConfirmaciones(vo.getHistOper())) {
							modoConfirmacion = Constantes.MODO_OPE;
							historicoOperacion = vo.getHistOper();
							return Constantes.SUCCESS;
						}
					} else {
						addError(vo, "No podemos confirmar esta operación");
					}
				} catch (NullPointerException e) {
				}
			}
		}
		if (listaErrores.size() != 0){
			msgBoxFinalStep();
			prepareMsgBox("modificar");
		}
		return Constantes.FAIL;
	}
	public void transaccionDesbloquear(){
		msgBoxAction.voidFunction();
	}

	public void primasDesbloquear(){
		msgBoxAction.voidFunction();
	}
	
	public String prepareAnexos(){
//		String ret = Constantes.FAIL;
		String ret = Constantes.SUCCESS;
		VistaOperacion vo = vistaOperacionSelected;
		historicoOperacion = vo.getHistOper();
		modoTratamiento = Constantes.TIPOANEXO_MODO_E;
		tipoAnexo = Constantes.TIPOANEXO_OPERACION;
		return ret;
	}
	
	public String preparePrimas(){
		
		/**
		 * Se realizarán unas validaciones (estado operación viva, operación sin prima previa¿?, operación que permita 
		 * prima, eventos ok). Si ya hay prima, ¿qué hacer?, ¿permitir si no está liquidada?
		 * 
		 * a select * from deri.relproat where codiatri = 6 
		 * Se llamará al package de ¿modif_ncorrela?, para que haga la copia de los históricos
		 * 
		 * Conectará con una nueva pantalla
		 * 
		 */
		
		historicoOperacionBloqueadoId = null;
		VistaOperacion vo = vistaOperacionSelected;
		this.msgBoxHeaderResultado = "";
		String ret = Constantes.FAIL;
		listaErrores.clear();
		msgBoxAction.voidFunction();
		
		if (!mantOperBo.validatePrimasImplicitas(vo.getHistOper()) 
				&& vo.getHistOper().getProductoCatalogo()!=null 
				&& vo.getHistOper().getProductoCatalogo().getProceden()!=null
				&& !"DE".equals(vo.getHistOper().getProductoCatalogo().getProceden().getProceden())) {
			addError(vo.getHistOper(), ResourceBundle.instance().getString("mantOper.messages.modificar.primas"));
		} else
		if (mantOperBo.validatePendAgendaModifCancelAnul(vo.getHistOper())) {
			addError(vo.getHistOper(), ResourceBundle.instance().getString("mantOper.messages.modificar.agenda"));
		} else if (mantOperBo.validatePendientesAgendaEvento(vo.getHistOper(),"2202") && 
				"VA".equalsIgnoreCase(vo.getHistOper().getEstado().getCodigo()) &&
				"M".equalsIgnoreCase(vo.getHistOper().getUltimaAccion().getCodigo())) {
			addError(vo.getHistOper(), ResourceBundle.instance().getString("mantOper.messages.modificar.agenda"));
		} else {
			if (!mantOperBo.validateLastFechaModificacion(vo.getHistOper())) {
				addError(vo.getHistOper(), ResourceBundle.instance().getString("mantOper.messages.modificar.noLastUpdate"));
			} else {
				if (isProductoEQS() && "PV".equalsIgnoreCase(vo.getHistOper().getEstado().getCodigo())){
					addError(vo.getHistOper(), ResourceBundle.instance().getString("mantOper.messages.modificar.primasEQSPV"));
				}else{
					if (!dbLockService.bloqueo(HistoricoOperacion.class, vo.getHistOper().getId())) {
						addError(vo.getHistOper(), ResourceBundle.instance().getString("mantOper.messages.modificar.blocked"));
					} else {
						HistoricoOperacion histOper = vistaOperacionSelected.getHistOper();
						historicoOperacionBloqueadoId= histOper.getId();
						entityManager.refresh(histOper);
						//Invoca al package 
						AltaCorrelaResult result = boletasBo.prepareModificacionCorrela(histOper);
						
						
						if(result==null){
							addError(historicoOperacion, ResourceBundle.instance().getString("mantOper.messages.modifica.error"));
						}
						historicoOperacion=result.getHistoricoOperacion();
						boletaState = BoletasStates.MODI_BOLETA;
						
					}
				}
			}
		}
		if (listaErrores.size() == 0){ // No tenemos ningun error podemos modificar
			refreshPending=true;
			if (isProductoEQS()){
				ret = "EQS";
			}else{
				ret = Constantes.SUCCESS;	
			}
			
		}else {
			msgBoxFinalStep();
			prepareMsgBox("primas");
		}
		return ret;
//		return null;
	}
	
	/**
	 * Producto EQS.  Código de producto de catálogo  1751204. Revisarlo en deri.prodtrat, 
	 * serán aquellos productos que tengan CHKEQUIT = ‘S’
	 * 
	 * Operación de Cobertura. Grupo contable  todos aquello grupos contables que comienzan por un número.
	 * ( De forma más técnica Si tipcober no es null y es CO es cobertura y  Si tipcober es null y el grupo 
	 * contable empieza por número o es = ‘FB’ es cobertura)
	 * 
	 * Sólo operaciones de mercado (gestio_tressoreria.contrapa.tipocont = ‘B’)
	 * @return
	 */
	public boolean isProductoEQS(){
		VistaOperacion vo = vistaOperacionSelected;
		HistoricoOperacion histOper = vo.getHistOper();

		if (histOper.getProductoCatalogo() != null && histOper.getProductoCatalogo().getProdtrat() !=null 
			&& "S".equalsIgnoreCase(histOper.getProductoCatalogo().getProdtrat().getChkequit())
			){
			return true;
		}else{
			return false;
		}
		
//			&& histOper.getContrapartida() !=null &&
//			(  
//					(GenericUtils.isNullOrBlank(histOper.getCodigoCobertura()) 
//							&& !GenericUtils.isNullOrBlank(histOper.getGrupoContableCode()) &&
//							( histOper.getGrupoContableCode().matches("[0-9].*") 
//									|| "FB".equalsIgnoreCase(histOper.getGrupoContableCode())))
//					||
//					
//					(!GenericUtils.isNullOrBlank(histOper.getCodigoCobertura()) 
//							&& "CO".equalsIgnoreCase(histOper.getCodigoCobertura().getCodigo()))
//			)
//		){
//			
//				
//					//Se añade control para verificar que la contrapartida este en la tabla CONTRAPA.
//					if (EntityUtil.checkEntityExists(entityManager, histOper.getContrapartida()) 
//							&& histOper.getContrapartida() instanceof Contrapartida) {
//					
//						Contrapartida contrapa = (Contrapartida)histOper.getContrapartida();
//						if (!GenericUtils.isNullOrBlank(contrapa.getTipoContrapartida()) &&
//								"B".equalsIgnoreCase(contrapa.getTipoContrapartida().getId())){
//							
//							return true;			
//						}
//					}
//
//		
//		return false;
//	}else{
//		return false;
//	}
	
	}


	
	public String transaccion(){
		historicoOperacionBloqueadoId = null;
		VistaOperacion vo = vistaOperacionSelected;
		this.msgBoxHeaderResultado = "";
		String ret = Constantes.FAIL;
		listaErrores.clear();
		msgBoxAction.voidFunction();
		
		if (mantOperBo.validatePendAgendaModifCancelAnul(vo.getHistOper())) {
			addError(vo.getHistOper(), ResourceBundle.instance().getString("mantOper.messages.modificar.agenda"));
		} else if (mantOperBo.validatePendientesAgendaEvento(vo.getHistOper(),"2202") && 
				"VA".equalsIgnoreCase(vo.getHistOper().getEstado().getCodigo()) &&
				"M".equalsIgnoreCase(vo.getHistOper().getUltimaAccion().getCodigo())) {
			addError(vo.getHistOper(), ResourceBundle.instance().getString("mantOper.messages.modificar.agenda"));
		} else {
			if (!mantOperBo.validateLastFechaModificacion(vo.getHistOper())) {
				addError(vo.getHistOper(), ResourceBundle.instance().getString("mantOper.messages.modificar.noLastUpdate"));
			} else {
				if (!dbLockService.bloqueo(HistoricoOperacion.class, vo.getHistOper().getId())) {
					addError(vo.getHistOper(), ResourceBundle.instance().getString("mantOper.messages.modificar.blocked"));
				} else {
					HistoricoOperacion histOper = vistaOperacionSelected.getHistOper();
					historicoOperacionBloqueadoId= histOper.getId();
					entityManager.refresh(histOper);
					//Invoca al package 
					AltaCorrelaResult result = boletasBo.prepareCambioTransaccion(histOper);
					
					
					if(result==null){
						addError(historicoOperacion, ResourceBundle.instance().getString("mantOper.messages.modifica.error"));
					}
					historicoOperacion=result.getHistoricoOperacion();
					boletaState = BoletasStates.MODI_BOLETA;
					
				}
			}
		}
		if (listaErrores.size() == 0){ // No tenemos ningun error podemos modificar
			refreshPending=true;
//			ret = Constantes.SUCCESS;
			ret = "TRANSACCION";
		}else {
			msgBoxFinalStep();
			prepareMsgBox("transaccion");
		}
		return ret;
	}
	
	public String prepareTransaccion(){
		
	
		historicoOperacionBloqueadoId = null;
		VistaOperacion vo = vistaOperacionSelected;
		this.msgBoxHeaderResultado = "";
		String ret = Constantes.FAIL;
		listaErrores.clear();
		
		 if (mantOperBo.validateLiquidacionesPendientes(vo.getHistOper())){
			 addWarning(vo.getHistOper(), ResourceBundle.instance().getString("mantOper.messages.validar.LiquidacionesValidadas")); 
				msgBoxFinalStep(true);
				prepareMsgBox("transaccion");

		 } else{
			return transaccion();
		 }
//		 
//		if (mantOperBo.validatePendAgendaModifCancelAnul(vo.getHistOper())) {
//			addError(vo.getHistOper(), ResourceBundle.instance().getString("mantOper.messages.modificar.agenda"));
//		} else if (mantOperBo.validatePendientesAgendaEvento(vo.getHistOper(),"2202") && 
//				"VA".equalsIgnoreCase(vo.getHistOper().getEstado().getCodigo()) &&
//				"M".equalsIgnoreCase(vo.getHistOper().getUltimaAccion().getCodigo())) {
//			addError(vo.getHistOper(), ResourceBundle.instance().getString("mantOper.messages.modificar.agenda"));
//		} else {
//			if (!mantOperBo.validateLastFechaModificacion(vo.getHistOper())) {
//				addError(vo.getHistOper(), ResourceBundle.instance().getString("mantOper.messages.modificar.noLastUpdate"));
//			} else {
//				if (!dbLockService.bloqueo(HistoricoOperacion.class, vo.getHistOper().getId())) {
//					addError(vo.getHistOper(), ResourceBundle.instance().getString("mantOper.messages.modificar.blocked"));
//				} else {
//					HistoricoOperacion histOper = vistaOperacionSelected.getHistOper();
//					historicoOperacionBloqueadoId= histOper.getId();
//					entityManager.refresh(histOper);
//					//Invoca al package 
//					AltaCorrelaResult result = boletasBo.prepareCambioTransaccion(histOper);
//					
//					
//					if(result==null){
//						addError(historicoOperacion, ResourceBundle.instance().getString("mantOper.messages.modifica.error"));
//					}
//					historicoOperacion=result.getHistoricoOperacion();
//					boletaState = BoletasStates.MODI_BOLETA;
//					
//				}
//			}
//		}
//		if (listaErrores.size() == 0){ // No tenemos ningun error podemos modificar
//			refreshPending=true;
//			ret = Constantes.SUCCESS;
//		}else {
//			msgBoxFinalStep();
//			prepareMsgBox("transaccion");
//		}
		return ret;
	}
	
	public String prepareModificar(){
		historicoOperacionBloqueadoId = null;
		VistaOperacion vo = vistaOperacionSelected;
		this.msgBoxHeaderResultado = "";
		String ret = Constantes.FAIL;
		listaErrores.clear();
		//Es modificable esta operacion?
		if(mantOperBo.calculoNumOrdenesDeOperacion(vo.getNcorrela())!=0){
			addError(vo.getHistOper(), ResourceBundle.instance().getString("mantOper.messages.modificar.noModificable"));
		}
		else if (mantOperBo.validatePendAgendaModifCancelAnul(vo.getHistOper())) {
			addError(vo.getHistOper(), ResourceBundle.instance().getString("mantOper.messages.modificar.agenda"));
		} else if (mantOperBo.validatePendientesAgendaEvento(vo.getHistOper(),"2202") && 
				"VA".equalsIgnoreCase(vo.getHistOper().getEstado().getCodigo()) &&
				"M".equalsIgnoreCase(vo.getHistOper().getUltimaAccion().getCodigo())) {
			addError(vo.getHistOper(), ResourceBundle.instance().getString("mantOper.messages.modificar.agenda"));
		} else {
			if (!mantOperBo.validateLastFechaModificacion(vo.getHistOper())) {
				addError(vo.getHistOper(), ResourceBundle.instance().getString("mantOper.messages.modificar.noLastUpdate"));
			} else {
				String usuarioBloqueo = dbLockService.bloqueoBoleta(HistoricoOperacion.class, vo.getHistOper().getId());
				if (!GenericUtils.isNullOrBlank(usuarioBloqueo)) {
					addError(vo.getHistOper(), ResourceBundle.instance().getString("mantOper.messages.modificar.blockedUser").concat(" ").concat(usuarioBloqueo));
				} else {
					HistoricoOperacion histOper = vistaOperacionSelected.getHistOper();
					historicoOperacionBloqueadoId= histOper.getId();
					entityManager.refresh(histOper);
					//Invoca al package 
					AltaCorrelaResult result = boletasBo.prepareModificacionCorrela(histOper);
					
					
					if(result==null){
						addError(historicoOperacion, ResourceBundle.instance().getString("mantOper.messages.modifica.error"));
					}
					historicoOperacion=result.getHistoricoOperacion();

					IndicadorConfirmacion confirmacion = entityManager.find(IndicadorConfirmacion.class, new OperacionId(historicoOperacion.getId().getFechaContratacion(), historicoOperacion.getId().getNumeroOperacion()));
					if (confirmacion!=null)	entityManager.refresh(confirmacion);
					
					
					boletaState = BoletasStates.MODI_BOLETA;
					
				}
			}
		}
		if (listaErrores.size() == 0){ // No tenemos ningun error podemos modificar
			refreshPending=true;
			ret = Constantes.SUCCESS;
		}else {
			msgBoxFinalStep();
			prepareMsgBox("modificar");
		}
		return ret;
	}

	
	public void onMessageBoxAnularOk(){
		prepareAnularDos();
	}
	public void prepareAnular(){
	messageBoxActionMO.init("mantOper.messages.anular.pregunta", "mantOperacionesAction.onMessageBoxAnularOk()",
			"mantOperacionesAction.voidFunction()","helperPanel");
	}
	
	public void prepareAnularDos(){
		listaErrores.clear();
		if (listasSeleccionadas.size() > 0) {
			if (!parametrosMantOper.getModo().equals(Constantes.MODO_OPM)) {
				for (VistaOperacion vo : listasSeleccionadas) {
					try {
						String estadoco = vo.getHistOper().getEstado().getCodigo();						
						if(!estadoco.equals("CA") && !estadoco.equals("AN") && !estadoco.equals("VE")){ 
							if (mantOperBo.validateCampanasAndLiquidaciones(vo.getHistOper())) { //true -> tenemos campanas/liquidaciones					
								addWarning(vo,ResourceBundle.instance().getString("mantOper.messages.anular.campanasLiquidaciones"));
							} else if(mantOperBo.validateProductoCompuesto(vo.getHistOper())){ //true -> Mostramos mensaje producto Compuesto
								addError(vo,ResourceBundle.instance().getString("mantOper.messages.validar.productoCompuesto"));
							}
							// Como queremos calcular todos los errores y warnings siempre procesaremos la lista de anulaciones
							calculateAnular(vo.getHistOper());
						} else {
							addError(vo,ResourceBundle.instance().getString("mantOper.messages.anular.no.liquid"));
						}
					} catch (NullPointerException e) {
						addError(vo,ResourceBundle.instance().getString("mantOper.messages.generic.noInfo"));
					}catch (Exception e) {
						e.printStackTrace();
						addError(vo,ResourceBundle.instance().getString("mantOper.messages.generic.noInfo"));
					}
				}
			}
		} else {
			addError(new HistoricoOperacion(),ResourceBundle.instance().getString("mantOper.messages.listaVacia"));
		}
		if(listaErrores.size() == 0){ //No tenemos ningun error podemos validar
			anular();
		}else{
			msgBoxFirstStep();
			prepareMsgBox("anular");
		}	
	}
	
	public void anularDesbloquear() {
		for (VistaOperacion vo : listasSeleccionadas) {
			dbLockService.desbloqueo(HistoricoOperacion.class, vo.getHistOper().getId());
		}
	}
	
	public void anular(){
		limpiarErrores(); // Eliminamos los registros que no se pueden validar.
		StringBuffer errorCode;
		int total=0;
		for (VistaOperacion vo : listasSeleccionadas) {
			if(!tieneErrores(vo)){
				errorCode = new StringBuffer();
				if (!mantOperBo.callAnular(vo.getHistOper(), Identity.instance().getCredentials().getUsername(), errorCode)) {
					addError(vo.getHistOper(), ResourceBundle.instance().getString("mantOper.messages.anular.cantAnular") + errorCode.toString());
				} else
					total++;
				dbLockService.desbloqueo(HistoricoOperacion.class, vo.getHistOper().getId());
			} else {
				addError(vo,ResourceBundle.instance().getString("mantOper.messages.anular.noSelection"));
			}
		}
		//FLM; Al final se tiene que mostrar el total de anulaciones
		if (listaErrores.size() > 0) {
			msgBoxFinalStep();
			this.msgBoxHeaderResultado = "Total de operaciones anuladas: "+ total ; 
			//msgBoxAction.setMensaje("Total de operaciones anuladas: "+ total );			
			prepareMsgBox("validarFinal");
		} else {			
			msgBoxFinalStep();
			this.msgBoxHeaderResultado = "Total de operaciones anuladas: "+ total ;
			prepareMsgBox("validarFinal");			
			//msgBoxAction.setMensaje("Total de operaciones anuladas: "+ total );
			//msgBoxAction.mostrarMsg("#{mantOperacionesAction.voidFunction()}", "#{mantOperacionesAction.voidFunction()}", "Total de operaciones anuladas: "+ total , true);
		}
		listasSeleccionadas.clear();
		actualizarListaOperaciones(listaOperacionesList); //limpiamos la factory
	}
	
	private void actualizarListaOperaciones(List<VistaOperacion> listaOps){
		/*for (VistaOperacion vo : listaOps) {
			mantOperBo.refreshHistDeri(vo.getHistOper());
		}*/
		listaOperacionesList = null;
	}
	
	private void calculateAnular(HistoricoOperacion historicoOperacion) {
		String indsitua = historicoOperacion.getUltimaAccion().getCodigo();
		if (indsitua.equals("N")) {
			addError(historicoOperacion,ResourceBundle.instance().getString("mantOper.messages.anular.pendienteValidar"));
		}else if (mantOperBo.validatePendientesAgendaValid(historicoOperacion) || mantOperBo.validatePendAgendaModifCancelAnul(historicoOperacion)) {
			addError(historicoOperacion, ResourceBundle.instance().getString("mantOper.messages.anular.agenda"));
		} else {
			if (!dbLockService.bloqueo(HistoricoOperacion.class, historicoOperacion.getId())) {
				addError(historicoOperacion, ResourceBundle.instance().getString("mantOper.messages.anular.blocked"));
			} else {
				if (!mantOperBo.validateLastFechaModificacion(historicoOperacion)) {
					dbLockService.desbloqueo(HistoricoOperacion.class, historicoOperacion.getId());
					addError(historicoOperacion, ResourceBundle.instance().getString("mantOper.messages.anular.noLastUpdate"));
				} else {
					// Llamariamos a la funcion de validar Real
					println("Anulamos ncorrela: " + historicoOperacion.getId().getNumeroOperacion() + ", F.Ope: " + historicoOperacion.getId().getFechaModificacion());
				}
			}
		}
	}
	
	public void prepareLigar(){
		msgBoxMessageMode("calculateLigar",ResourceBundle.instance().getString("mantOper.messages.ligar.pregunta"));
	}
	
	public String calculateLigar() {
		listaErrores.clear();
		listaOpOut.clear();
		
		for (VistaOperacion vo : listasSeleccionadas) {
			OperacionCasada operCasa = mantOperBo.getOperCasada(vo.getHistOper());
			Long agrupacionMercadoAnterior = 0L;
			List<Long> agrupaMercadoList = new ArrayList<Long>();
			List<Long> agrupaClienteList = new ArrayList<Long>();
			if(operCasa != null){
				if(GenericUtils.isNullOrBlank(operCasa.getClaseOperacion()) && !(operCasa.getClaseOperacion().equals("CL") || operCasa.getClaseOperacion().equals("ME"))){
					addError(vo,ResourceBundle.instance().getString("mantOper.messages.ligar.noMercadoCliente"));
				}
				if(!GenericUtils.isNullOrBlank(operCasa.getAgrupacionMercado()) && !(agrupacionMercadoAnterior.equals(0L)) && agrupacionMercadoAnterior != operCasa.getAgrupacionMercado()){
					addError(vo,ResourceBundle.instance().getString("mantOper.messages.ligar.mercadosDiferentes"));
				} else {
					agrupacionMercadoAnterior = operCasa.getAgrupacionMercado();
					if(!agrupaMercadoList.contains(operCasa.getAgrupacionCliente())){
						if(!GenericUtils.isNullOrBlank(operCasa.getAgrupacionCliente())){
							agrupaClienteList.add(operCasa.getAgrupacionCliente());
						}
						listaOpOut.add(new Operacion(new OperacionId(vo.getHistOper().getId().getFechaContratacion(), vo.getHistOper().getId().getNumeroOperacion())));
					}
				}
			} else {
				addError(vo,ResourceBundle.instance().getString("mantOper.messages.ligar.noMercadoCliente"));
			}
		}
		if(listaErrores.size() == 0 && listaOpOut.size() > 0){
			ArrayList<String> params = new ArrayList<String>(); 
			ArrayList<String> values = new ArrayList<String>();
			params.add("origen");
			values.add("NO_CASADAS");
			// No mostrem missatge! Al retornar de la pantalla OPERCASA mostrava el missatge de confirmació.
			msgBoxAction.noMostrarMensaje();
			redirectToURL("/pages/gestionoperaciones/casaroperaciones/busquedaOperacionACasar.xhtml",params, values);
		}else{
			this.msgBoxHeaderResultado ="";
			listaOpOut.clear();
			msgBoxFinalStep();
			prepareMsgBox("voidFunction");
		}
		return Constantes.FAIL;
	}


	public String prepareEjercicio() {
		String ret = Constantes.FAIL;
		Date fechamis = mantOperBo.getFechamis();
		String datosGen ="";
		listaErrores.clear();
		VistaOperacion vo = vistaOperacionSelected;
		if (vo != null) {
			historicoOperacion = vo.getHistOper();
			
			DescripcionEstadoOperacion estado = historicoOperacion.getEstado();
			if (estado != null) {
				if ("VA".equalsIgnoreCase(estado.getCodigo()) ||"VE".equalsIgnoreCase(estado.getCodigo())|| !mantOperBo.validatePendientesAgendaModif(historicoOperacion)) {

					if (!operacionOpcPendienteActivarAgenda(Constantes.TIPO_EVENTO_EJERCICIO)){ 
						if (existenFechasValidasEjercicio(fechamis) && 
							mantOperBo.ajustarFecha(fechamis,3,divisaOpcion()).compareTo(historicoOperacion.getFechaVencimiento())<0)
						{ 						
							parametrosManteje = new ParametrosManteje();
							
							parametrosManteje.setModo(Constantes.MODO_OPE);
							parametrosManteje.setHistoricoOperacion(historicoOperacion);
							
							if (Constantes.MODO_AGE.equals(parametrosMantOper.getModo())) {

								datosGen = mantOperBo.obtenerDatosGen(parametrosMantOper.getCodevent(), historicoOperacion.getId().getNumeroOperacion(), fechamis, historicoOperacion.getId().getFechaContratacion());
								if (!"NO DATOS".equals(datosGen) && !GenericUtils.isNullOrBlank(datosGen)){
							
									SimpleDateFormat sdf = new SimpleDateFormat(Constantes.YYYYMMDD);	
									
									parametrosManteje.setModo(Constantes.MODO_AGE);
									try {
										parametrosManteje.setTipoOperacion(datosGen.substring(0, 1));
										parametrosManteje.setConcepto(datosGen.substring(20, 23));
										parametrosManteje.setTipoConcepto(datosGen.substring(24, 27));
										parametrosManteje.setFecfintr(sdf.parse(datosGen.substring(11, 19)));
										parametrosManteje.setFechaeje(sdf.parse(datosGen.substring(28, 36)));
										parametrosManteje.setFecinitr(sdf.parse(datosGen.substring(2, 10)));
									} catch (Exception e) {
										datosGen = "ERROR";
										addWarning(historicoOperacion, ResourceBundle.instance().getString("mantOper.messages.ejercicio.datosgen"));
									}

								
								}else{
									datosGen = "ERROR";
									addWarning(historicoOperacion, ResourceBundle.instance().getString("mantOper.messages.ejercicio.datosgen"));
								}
							}

							
							if (!"ERROR".equals(datosGen)){
								if (!dbLockService.bloqueo(HistoricoOperacion.class, vo.getHistOper().getId())) {
									addError(vo.getHistOper(), ResourceBundle.instance().getString("mantOper.messages.modificar.blocked"));
								} else {
									ret = Constantes.SUCCESS;
								}
							}
						
						}else{
							if (fechamis.compareTo(historicoOperacion.getFechaVencimiento()) > 0 ){
								addWarning(historicoOperacion, ResourceBundle.instance().getString("mantOper.messages.ejercicio.expirada"));
							}else{
								addWarning(historicoOperacion, ResourceBundle.instance().getString("mantOper.messages.ejercicio.validas"));
							}
						}
						
					}else{
						addWarning(historicoOperacion, ResourceBundle.instance().getString("mantOper.messages.ejercicio.eventopdt"));
					}

				} else {
					addWarning(historicoOperacion, ResourceBundle.instance().getString("mantOper.messages.validar.agenda"));
				}
			}
		}
		if(listaErrores.size() > 0){
			this.msgBoxHeaderResultado ="";
			msgBoxFinalStep();
			prepareMsgBox("voidFunction");
		}
		return ret;
	}

	private Boolean existenFechasValidasEjercicio(Date fechaProcesoDeri){
		return true;
//		
//		HistoricoOpcion historicoOpcion = historicoOperacion.getHistoricoOpcion();
//		if(historicoOpcion != null) {
//			String estado = historicoOpcion.getEstado();
//			if(estado != null) {
//				int cuantosSituparm = mantOperBo.cuantosSituparm(historicoOperacion,fechaProcesoDeri);
//				if ( cuantosSituparm > 0 ) return true; 
//			}
//		}	
//		return false;	
	}
	
	public String prepareEjercParc() {
//		Obsoleta 
		String ret = Constantes.FAIL;
		VistaOperacion vo = vistaOperacionSelected;
		if (vo != null) {
			historicoOperacion = vo.getHistOper();
			DescripcionEstadoOperacion estado = historicoOperacion.getEstado();
			if (estado != null) {
				if ("VA".equalsIgnoreCase(estado.getCodigo()) || !mantOperBo.validatePendientesAgendaModif(historicoOperacion)) {
					dbLockService.bloqueo(HistoricoOperacion.class, historicoOperacion.getId());
					ret = Constantes.SUCCESS;
				} else {
					addWarning(historicoOperacion, ResourceBundle.instance().getString("mantOper.messages.validar.agenda"));
				}
			}
		}
		if(listaErrores.size() > 0){
			this.msgBoxHeaderResultado ="";
			msgBoxFinalStep();
			prepareMsgBox("voidFunction");
		}
		return ret;
	}

	public String prepareToqueBarrera() {
		VistaOperacion vo = vistaOperacionSelected;
		listaErrores.clear();
		String ret = Constantes.FAIL;
		if(vo != null) {
			historicoOperacion = vo.getHistOper();
			DescripcionEstadoOperacion estado = historicoOperacion.getEstado();
			if(estado != null) {
				if("VA".equalsIgnoreCase(estado.getCodigo()) || !mantOperBo.validatePendientesAgendaModif(historicoOperacion)) {
					if(!operacionOpcPendienteActivarAgenda(Constantes.TIPO_EVENTO_BARRERA)) {
						if(existeFechaValidaToqueBarreras()) {
							dbLockService.bloqueo(HistoricoOperacion.class, historicoOperacion.getId());
							ret = Constantes.SUCCESS;
						} else {
							//No existen fechas de barrera válidas a fecha de hoy para la operación
							addError(historicoOperacion,ResourceBundle.instance().getString("mantOper.messages.toqueBarrera.noFechas"));
						}
					} else {
						//Operación pendiente de procesar por la agenda. Vuelva a intentarlo en unos minutos
						addError(historicoOperacion,ResourceBundle.instance().getString("mantOper.messages.toqueBarrera.agenda"));
					}
				}
			}
		}
		if(listaErrores.size() > 0){
			this.msgBoxHeaderResultado ="";
			msgBoxFinalStep();
			prepareMsgBox("toqueBarrera");
		}
		return ret;
	}
	


	public boolean verificaPositoqe(Date fechatoque, HistoricoOperacion historicoOperacion, String tipoOperacion, Date fechaInicioTramo,
			Date fechaFinTramo, String barrera) {
		int count = mantoqeBarreraBo.cuantosPositoqe(historicoOperacion,tipoOperacion, fechaInicioTramo,fechaFinTramo, barrera, fechatoque);

		if (count > 0) {
			return false;
		} else {
			return true;
		}
	}

	
	public String verificaFechatoq(Date fechatoque, HistoricoOperacion historicoOperacion, Date fechaInicioTramo,
			Date fechaFinTramo) {
//		String tipoBarrera  = obtenerTipoBarrera(historicoOperacion);
//		if (Constantes.MANTOQE_TIPO_E.equalsIgnoreCase(tipoBarrera)) {
//			int cuantos = mantoqeBarreraBo.cuantosSituparm(historicoOperacion, fechatoque);
//			if (cuantos == 0) {
//				return ResourceBundle.instance().getString("mantOper.toqueBarrera.fechaToque.noTocable");
//			}
//		} else {
			if (fechatoque.compareTo(fechaInicioTramo) > -1
					&& fechatoque.compareTo(fechaFinTramo) < 1) {
				// null
			} else {
				if (fechatoque.compareTo(fechaInicioTramo) > 1) {
					fechatoque = fechaInicioTramo;
				} else {
					return ResourceBundle.instance().getString("mantOper.toqueBarrera.fechaToque.intervalos");
				}
			}
//		}
		return "";
	}
	
	
	private String obtenerTipoBarrera(HistoricoOperacion ho) {

		//Sabemos que solo hay una barrera.
		
		Iterator<HistoricoBarrera> iter = ho.getHistoricoBarreras().iterator();
		HistoricoBarrera hb = iter.next();
		
		return hb.getTipobarr();
	}

	public void prepareNoToqueTodos() {
		messageBoxActionMO.init("mantOper.messages.notoque.pregunta", "mantOperacionesAction.onMessageBoxNoToqueOk()",
				"mantOperacionesAction.voidFunction()","helperPanel");
	}

	public void prepareToqueTodos() {
		messageBoxActionMO.init("mantOper.messages.toque.pregunta", "mantOperacionesAction.onMessageBoxToqueOk()",
		"mantOperacionesAction.voidFunction()","helperPanel");
		
	}

	public void onMessageBoxToqueOk(){
		prepareToqueTodosDos();
	}

	public void onMessageBoxNoToqueOk(){
		prepareNoToqueTodosDos();
	}
	
	public void prepareNoToqueTodosDos() {
		if(listasSeleccionadas.size() > 0){
			listaErrores.clear();
			if(!parametrosMantOper.getModo().equals(Constantes.MODO_OPM)){
				for (VistaOperacion vo : listasSeleccionadas) {
					try{
						if(vo != null) {
							historicoOperacion = vo.getHistOper();
							DescripcionEstadoOperacion estado = historicoOperacion.getEstado();
							if(estado != null) {
								if("VA".equalsIgnoreCase(estado.getCodigo()) || !mantOperBo.validatePendientesAgendaModif(historicoOperacion) 
										&& comprobarToque(historicoOperacion)) {
									if(!operacionOpcPendienteActivarAgenda(Constantes.TIPO_EVENTO_BARRERA)) {
//										if(existenFechasValidasTBarr()) {
//											HistoricoBarreraReturn barrera = unicaBarrera(historicoOperacion); 
//											if (barrera!=null){
											String datosGen = mantOperBo.recuperarDatosGen(historicoOperacion);
											
											Date fechamis = mantOperBo.getFechamis();
											String tipoOperacion = datosGen.substring(0, 1);
											SimpleDateFormat sdf = new SimpleDateFormat(Constantes.YYYYMMDD );
											Date fechaInicio = null ;Date fechaFin=null;
											fechaInicio = sdf.parse(datosGen.substring(2, 10));
											fechaFin = sdf.parse(datosGen.substring(11, 19));
											String tipBarP1 = datosGen.substring(43, 45);

										if(fechaInicio!= null && fechamis.compareTo(fechaInicio) >= 0) {
	
										if (historicoOperacion.getHistoricoBarreras()!=null ){

//										&& historicoOperacion.getHistoricoBarreras().size() == 2){
												//Solo interesa la primera no puede haber mas.	
//												Iterator<HistoricoBarrera>  iteradorRebate = historicoOperacion.getHistoricoBarreras().iterator();
												HistoricoBarrera hbRebate =null;
//												= iteradorRebate.next();
												
												for (HistoricoBarrera barrera : historicoOperacion.getHistoricoBarreras()) {
												 
												 if ( barrera.getId().getTipbarp1().equals(tipBarP1) && 
												 	  barrera.getId().getTipopera().equals(tipoOperacion)){
														
														hbRebate = barrera; 	  
												 	    continue;
												 	  } 
												}
													
												if (!GenericUtils.isNullOrBlank(hbRebate)){
												
//												String barrera = hbRebate.getId().getTipbarp1();
//												if (historicoOperacion.getHistoricoOpcion()!=null && "A".equalsIgnoreCase(historicoOperacion.getHistoricoOpcion().getEstado())){
//													barreraIO  = "O";
//												}else{
//													barreraIO  = historicoOperacion.getHistoricoOpcion().getEstado();
//												}
												
												if( verificaPositoqe(fechamis, historicoOperacion, tipoOperacion,fechaInicio,fechaFin,tipBarP1)){

													String error = verificaFechatoq(fechamis, historicoOperacion, fechaInicio,fechaFin);
													if(GenericUtils.isNullOrBlank(error)){
//														//REALIZAR TOQUE
												
														if (!dbLockService.bloqueo(HistoricoOperacion.class, historicoOperacion.getId())) {
															addError(historicoOperacion, ResourceBundle.instance().getString("mantOper.messages.validar.blocked"));
														}

													}else{
														addError(historicoOperacion,error);
													}
														
												}else{
													addError(historicoOperacion,ResourceBundle.instance().getString("mantOper.messages.toqueBarrera.positoque"));
												}												

											}else{
											// NO ENCUENTRA BARREARA PARA DATOS GEN
												addError(historicoOperacion,ResourceBundle.instance().getString("mantOper.messages.toqueBarrera.agenda"));
												}
											}else{
//												addError(historicoOperacion,ResourceBundle.instance().getString("mantOper.messages.toqueBarrera.soloUna"));
												addError(historicoOperacion,ResourceBundle.instance().getString("mantOper.messages.toqueBarrera.niUna"));
												
											}
																			
										} else {
											//No existen fechas de barrera válidas a fecha de hoy para la operación
											addError(historicoOperacion,ResourceBundle.instance().getString("mantOper.messages.toqueBarrera.noFechas"));
										}
									} else {
										//Operación pendiente de procesar por la agenda. Vuelva a intentarlo en unos minutos
										addError(historicoOperacion,ResourceBundle.instance().getString("mantOper.messages.retroceder.agenda"));
									}
							}
						}
					}
					
					}catch (NullPointerException e) {
						e.printStackTrace();
						addError(vo,ResourceBundle.instance().getString("mantOper.messages.generic.noInfo"));
					}catch (Exception e) {
						e.printStackTrace();
						addError(vo,ResourceBundle.instance().getString("mantOper.messages.generic.noInfo"));
					}
				}
			}
			if(listaErrores.size() == 0){ //No tenemos ningun error podemos validar
				noToque();
			}else{
				msgBoxFirstStep();
				prepareMsgBox("noToque");
			}
		} else {
		}
		
	}
	
	private HistoricoBarreraReturn unicaBarrera(HistoricoOperacion historicoOperacion){
		List<HistoricoBarreraReturn>  barreraList = mantoqeBarreraBo.obtenerBarrera(historicoOperacion);
		
		if (barreraList == null || barreraList.size()!=1){
			return null;
		}else{
			return barreraList.get(0);	
		}
		
		
	}
	
	private MantoqeGlobal obtenerDatosGlobales(HistoricoOperacion historicoOperacion){
	MantoqeGlobal mantoq = mantoqeBarreraBo.obtenerDatosGlobales(historicoOperacion);
	return mantoq;
	}
	
	public void prepareToqueTodosDos() {
		Date fechamis = mantOperBo.getFechamis();
		if(listasSeleccionadas.size() > 0){
			listaErrores.clear();
			if(!parametrosMantOper.getModo().equals(Constantes.MODO_OPM)){
				for (VistaOperacion vo : listasSeleccionadas) {
					try{
						if(vo != null) {
							historicoOperacion = vo.getHistOper();
							DescripcionEstadoOperacion estado = historicoOperacion.getEstado();
							if(estado != null) {
								if("VA".equalsIgnoreCase(estado.getCodigo()) || !mantOperBo.validatePendientesAgendaModif(historicoOperacion)) {
									if(!operacionOpcPendienteActivarAgenda(Constantes.TIPO_EVENTO_BARRERA)) {
//										if(existenFechasValidasTBarr()) {
//											HistoricoBarreraReturn barrera = unicaBarrera(historicoOperacion); 
											String datosGen = mantOperBo.recuperarDatosGen(historicoOperacion);

											String tipoOperacion = datosGen.substring(0, 1);
											SimpleDateFormat sdf = new SimpleDateFormat(Constantes.YYYYMMDD );
											Date fechaInicio = null ;Date fechaFin=null;
											fechaInicio = sdf.parse(datosGen.substring(2, 10));
											fechaFin = sdf.parse(datosGen.substring(11, 19));
											String tipBarP1 = datosGen.substring(43, 45);
											
											if(fechaInicio!= null && fechamis.compareTo(fechaInicio) >= 0) {
												
											if (historicoOperacion.getHistoricoBarreras()!=null) {
//												&& historicoOperacion.getHistoricoBarreras().size() == 1){
											
												
	
//												MantoqeGlobal mantoq = obtenerDatosGlobales(historicoOperacion);

												//Comprobamos que no tenga importe REBATE
												
//												Iterator<HistoricoBarrera>  iteradorRebate = historicoOperacion.getHistoricoBarreras().iterator();
//												
//												//Solo interesa la primera no puede haber mas.
//												HistoricoBarrera hbRebate = iteradorRebate.next();
												HistoricoBarrera hbRebate =null;
												for (HistoricoBarrera barrera : historicoOperacion.getHistoricoBarreras()) {
													 
													 if ( barrera.getId().getTipbarp1().equals(tipBarP1) && 
													 	  barrera.getId().getTipopera().equals(tipoOperacion)){
															
															hbRebate = barrera; 	  
													 	    continue;
													 	  } 
													}
														
												if (!GenericUtils.isNullOrBlank(hbRebate)){
													
												if (GenericUtils.isNullOrZero(hbRebate.getImprebat())) {
													
												
												
//												String barrera =hbRebate.getId().getTipbarp1();
//												if (historicoOperacion.getHistoricoOpcion()!=null && "A".equalsIgnoreCase(historicoOperacion.getHistoricoOpcion().getEstado())){
//													barreraIO  = "O";
//												}else{
//													barreraIO  = historicoOperacion.getHistoricoOpcion().getEstado();
//												}
												
												if( verificaPositoqe(fechamis, historicoOperacion, tipoOperacion,fechaInicio,fechaFin,tipBarP1)){

													String error = verificaFechatoq(fechamis, historicoOperacion, fechaInicio,fechaFin);
													if(GenericUtils.isNullOrBlank(error)){
//														//REALIZAR TOQUE
												
														if (!dbLockService.bloqueo(HistoricoOperacion.class, historicoOperacion.getId())) {
															addError(historicoOperacion, ResourceBundle.instance().getString("mantOper.messages.validar.blocked"));
														}

													}else{
														addError(historicoOperacion,error);
													}
														
												}else{
													addError(historicoOperacion,ResourceBundle.instance().getString("mantOper.messages.toqueBarrera.positoque"));
												}
	
												}else{
													// TIENE IMPORTE REBATE
													addError(historicoOperacion,ResourceBundle.instance().getString("mantOper.messages.toqueBarrera.importeRebate"));
												}
												
												}else{
													//NO ENCUENTRA DATOSGEN - BARRERA
													addError(historicoOperacion,ResourceBundle.instance().getString("mantOper.messages.toqueBarrera.agenda"));
												}
													}else{
//														addError(historicoOperacion,ResourceBundle.instance().getString("mantOper.messages.toqueBarrera.soloUna"));
														addError(historicoOperacion,ResourceBundle.instance().getString("mantOper.messages.toqueBarrera.niUna"));

													}
										} else {
											//No existen fechas de barrera válidas a fecha de hoy para la operación
											addError(historicoOperacion,ResourceBundle.instance().getString("mantOper.messages.toqueBarrera.noFechas"));
										}
									} else {
										//Operación pendiente de procesar por la agenda. Vuelva a intentarlo en unos minutos
										addError(historicoOperacion,ResourceBundle.instance().getString("mantOper.messages.toqueBarrera.agenda"));
									}
								}
							}
						}
					}catch (NullPointerException e) {
						e.printStackTrace();
						addError(vo,ResourceBundle.instance().getString("mantOper.messages.generic.noInfo"));
					}catch (Exception e) {
						e.printStackTrace();
						addError(vo,ResourceBundle.instance().getString("mantOper.messages.generic.noInfo"));
					}
				}
			}
			if(listaErrores.size() == 0){ //No tenemos ningun error podemos validar
				toque();
			}else{
				msgBoxFirstStep();
				prepareMsgBox("toque");
			}
		} else {
		}
	}
	
	
	public  void toqueDesbloquear(){
		for (VistaOperacion vo : listasSeleccionadas) {
			dbLockService.desbloqueo(HistoricoOperacion.class, vo.getHistOper().getId());
		}
	}
	
	public  void noToqueDesbloquear(){
		for (VistaOperacion vo : listasSeleccionadas) {
			dbLockService.desbloqueo(HistoricoOperacion.class, vo.getHistOper().getId());
		}
	}
	
	public void toque(){
		int operTocadas = 0;
		limpiarErrores();
		this.msgBoxHeaderResultado ="";
		
		StringBuffer errorCode;
		for (VistaOperacion vo : listasSeleccionadas) {
			if(!tieneErrores(vo)){
				errorCode = new StringBuffer();
				try {
				//SMM 19/10/2011 Se coge la fecha del evento.
				//Se cambia porque se dejan eventos sin solventar de un dia para otro y luego se mataban los del último dia					
//				Date fechaToque = mantOperBo.getFechamis();
				historicoOperacion = vo.getHistOper();
				String datosGen = mantOperBo.recuperarDatosGen(historicoOperacion);

				
				/**				
				10 WS-DATOSGEN-2004 REDEFINES WS-DATOSGEN.
				15 WS-TIPOPERA-2004 PIC X(01). 
				15 FILLER PIC X(01). 
				15 WS-FECINITR-2004 PIC 9(08). 
				15 FILLER PIC X(01). 
				15 WS-FECFINTR-2004 PIC 9(08). 
				15 FILLER PIC X(01). 
				15 WS-CONCEPTO-2004 PIC X(03). 
				15 FILLER PIC X(01). 
				15 WS-TIPCONCE-2004 PIC X(03). 
				15 FILLER PIC X(01). 
				15 WS-FECHAPLI-2004 PIC 9(08). 
				15 FILLER PIC X(01). 
				15 WS-CODFORMU-2004 PIC 9(05). 
				15 FILLER PIC X(01). 
				15 WS-TIPBARP1-2004 PIC X(02). 
				15 FILLER PIC X(01). 
				15 WS-NIVEBARR-2004 PIC 9(05)V9(12). 
				15 FILLER PIC X(01). 
				15 WS-PRECIOBA-2004 PIC 9(05)V9(12). 
				15 FILLER PIC X(01). 
				15 WS-PRODUCTO-2004 PIC X(06). 
				*** 15 FILLER PIC X(280). 
				15 FILLER PIC X(01). 
				15 WS-ORDENBAR-2004 PIC 9(03). 
				15 FILLER PIC X(308). 
				 */
				

				
				
				
//				HistoricoBarreraReturn barrera = unicaBarrera(historicoOperacion);
//				MantoqeGlobal mantoq = obtenerDatosGlobales(historicoOperacion);
//				insertarPositoque(historicoOperacion, fechamis, barrera, mantoq, Constantes.MANTOQE_S);
				
				//Conversion DatosGen
				String tipoOperacion = datosGen.substring(0, 1);
				String tipBarP1 = datosGen.substring(43, 45);
				String concepto = datosGen.substring(20, 23);
				String tipconcep = datosGen.substring(24, 27);
				String codFormula = datosGen.substring(37, 42);
				String producto = datosGen.substring(82, 88);
				Short ordenBarr = Short.parseShort(datosGen.substring(89, 92));
				
				String compuesto = datosGen.substring(46, 51).concat(".").concat(datosGen.substring(51, 63));
				Double tempEntera = Double.valueOf(compuesto); 
				BigDecimal nivebarr = BigDecimal.valueOf(tempEntera);
				compuesto = datosGen.substring(64, 69).concat(".").concat(datosGen.substring(69, 81));
				tempEntera = Double.valueOf(compuesto);
				BigDecimal precio = BigDecimal.valueOf(tempEntera);
				
				
				SimpleDateFormat sdf = new SimpleDateFormat(Constantes.YYYYMMDD );
				
				
				Date fechaInicio = null ;Date fechaFin=null;
				Date fechaToque=null;
		
					fechaInicio = sdf.parse(datosGen.substring(2, 10));
					fechaFin = sdf.parse(datosGen.substring(11, 19));
					fechaToque = sdf.parse(datosGen.substring(28, 36));
					
				
				
				StringBuffer sb = new StringBuffer();
				String filler = " ";
				
				String stringRebat = montarStringRebate(historicoOperacion);
				
				sb.append(tipoOperacion).append(filler).append(datosGen.substring(2, 10)).append(filler).append(datosGen.substring(11, 19))
				.append(filler).append(concepto).append(filler).append(tipconcep).append(filler).append(datosGen.substring(28, 36))
				.append(filler).append(codFormula).append(filler).append(tipBarP1).append(filler).append(datosGen.substring(46, 63)).append(filler)
				.append(producto).append(filler).append(datosGen.substring(64, 81)).append(filler).append(stringRebat)
				.append(filler).append(datosGen.substring(89, 92)).append(GenericUtils.rpad("", 57, " "));
				
				/**
				 *15 WS-TIPOPERA-1006   PIC  X(001).
                 15 FILLER             PIC  X(001).
                 15 WS-FECINITR-1006   PIC  9(008).
                 15 FILLER             PIC  X(001).
                 15 WS-FECFINTR-1006   PIC  9(008).
                 15 FILLER             PIC  X(001).
                 15 WS-CONCEPTO-1006   PIC  X(003).
                 15 FILLER             PIC  X(001).
                 15 WS-TIPCONCE-1006   PIC  X(003).
                 15 FILLER             PIC  X(001).
                 15 WS-FECHATOQ-1006   PIC  9(008).
                 15 FILLER             PIC  X(001).
                 15 WS-CODFORMU-1006   PIC  9(005).
                 15 FILLER             PIC  X(001).
                 15 WS-TIPBARP1-1006   PIC  X(002).
                 15 FILLER             PIC  X(001).
                 15 WS-NIVEBARR-1006   PIC  9(005)V9(12).
                 15 FILLER             PIC  X(001).
                 15 WS-PRODUCTO-1006   PIC  X(006).
                 15 FILLER             PIC  X(001).
                 15 WS-PRECIOBA-1006   PIC  9(005)V9(12).
                 15 FILLER             PIC  X(001).
                 15 WS-IMPREBAT-1006   PIC  9(013)V9(04).
                 15 FILLER             PIC  X(001).
                 15 WS-SIGNOREB-1006   PIC  X(001).
                 15 FILLER             PIC  X(001).
                 15 WS-DIVIREBA-1006   PIC  X(003).
                 15 FILLER             PIC  X(001).
                 15 WS-FECREBAT-1006   PIC  9(008).
                 15 FILLER             PIC  X(001).
                 15 WS-MODECONF-1006   PIC  X(012).
                 15 FILLER             PIC  X(001).
                 15 WS-INDCONTB-1006   PIC  X(001).
                 15 FILLER             PIC  X(001).
                 15 WS-INDCORTB-1006   PIC  X(001).
                 15 FILLER             PIC  X(001).
                 15 WS-OBSERVAC-1006   PIC  X(200).
                 15 FILLER             PIC  X(001).
                 15 WS-ORDENBAR-1006   PIC  9(03).
                 15 FILLER             PIC  X(057).
				 */
				
				
				String stringEvento = sb.toString(); 
				
				String retorno = mantoqeBarreraBo.insertarAgendoTCconRet(fechaToque, (int)1006, producto, 
						historicoOperacion, stringEvento, Identity.instance().getCredentials().getUsername());
				
				if (retorno!= null){
					throw new Exception(retorno);
				}else{
					
					mantoqeBarreraBo.insertarPositoqe(historicoOperacion, fechaInicio, fechaFin, 
							tipBarP1, fechaToque, precio, Identity.instance().getCredentials().getUsername(), 
							tipoOperacion,Constantes.MANTOQE_S, ordenBarr);
					
					operTocadas++;	
				}
				
				
				} catch (Exception e) {
					// TODO Auto-generated catch block
					addError(vo.getHistOper(), ResourceBundle.instance().getString("mantOper.messages.tocar.cantTocar") + e.getMessage());
//					e.printStackTrace();
				} finally{
					dbLockService.desbloqueo(HistoricoOperacion.class, vo.getHistOper().getId());					
				}

			} else {
				addError(vo.getHistOper(), ResourceBundle.instance().getString("mantOper.messages.toque.noSelection"));
			}
		}
		if (listaErrores.size() > 0) {
			msgBoxFinalStep(true);
			prepareMsgBox("noToqueFinal");
		} else {
			if(operTocadas>0){
				msgBoxFinalStep(true);
				listasSeleccionadas.clear();
				String msgTocadas = String.valueOf(operTocadas) + ResourceBundle.instance().getString("mantOper.messages.tocadas");
				messageBoxActionMO.initString(msgTocadas, "mantOperacionesAction.voidFunction()","", 
						"helperPanel,messagesPanel,mantOperacionesForm,messageBoxPanelToque," +
						"msgboxPanelMantOper,resultadosConsulta");
			}
			msgBoxFinalStep(true);actualizarListaOperaciones(listaOperacionesList); //limpiamos la factory
		}
		
	}

	private String montarStringRebate(HistoricoOperacion ho) {
		// TODO Auto-generated method stub

		Iterator<HistoricoBarrera>  iterador = ho.getHistoricoBarreras().iterator();
		
		HistoricoBarrera hb = iterador.next();
		
		
		String signo;

		if (hb.getId().getTipopera()==null){
			signo = Constantes.MANTOQE_SIGNO_MAS;
		}else if (hb.getId().getTipopera().equals(Constantes.MANTOQE_PATA_P)) {
			signo = Constantes.MANTOQE_SIGNO_MENOS;
		} else {
			signo = Constantes.MANTOQE_SIGNO_MAS;
		}


		
		StringBuffer sb = new StringBuffer();
		String filler = " ";
		
		BigDecimal importeRebate =	hb.getImprebat();
		Number nvlImporteRebate = (Number) ((BigDecimal)GenericUtils.nvl(importeRebate, new BigDecimal(0))).multiply(new BigDecimal(10000));//forzamos 4 decimales
		String toCharNumberNvlImporteRebate = GenericUtils.to_char(nvlImporteRebate);
		String replacedToCharNumberNvlImporteRebate = GenericUtils.lpad(GenericUtils.replace(toCharNumberNvlImporteRebate, ".", ""),17,"0");

		
		String pantallaDivisa = hb.getDivireba();
		String nvlPantallaDivisa = (String) GenericUtils.nvl(pantallaDivisa, "");
		String rpadNvlPantallaDivisa = GenericUtils.rpad(nvlPantallaDivisa, 3, " ");
		
		SimpleDateFormat sdf1 = new SimpleDateFormat(Constantes.YYYYMMDD);
		Date pantallaFechaRebate = hb.getFecrebat();
		String toCharPantallaFechaRebate = null;
		if (pantallaFechaRebate !=null){
			toCharPantallaFechaRebate = sdf1.format(pantallaFechaRebate);
		}
		String nvlToCharPantallaFechaRebate = (String) GenericUtils.nvl(toCharPantallaFechaRebate, "00000000");

		String modeconf = hb.getModeconf();
		String nvlModeconf = (String) GenericUtils.nvl(modeconf, "");
		String rpadNvlModeconf = GenericUtils.rpad(nvlModeconf, 12, " ");
		
		
		
		String indcontb = hb.getIndcontb();
		String nvlIndcontb = (String) GenericUtils.nvl(indcontb , "");
		String rpadNvlIndcontb = GenericUtils.rpad(nvlIndcontb, 1, " ");

		String indcortb = hb.getIndcortb();
		String nvlIndcortb = (String) GenericUtils.nvl(indcortb , "");
		String rpadNvlIndcortb = GenericUtils.rpad(nvlIndcortb, 1, " ");
		
		String pantallaObservaciones = hb.getObservac();
		String nvlPantallaObservaciones = (String) GenericUtils.nvl(pantallaObservaciones, "");
		String rpadNvlPantallaObservaciones = GenericUtils.rpad(nvlPantallaObservaciones, 200, " ");

		
		
		sb.append(replacedToCharNumberNvlImporteRebate).append(filler).append(signo).append(filler).append(rpadNvlPantallaDivisa)
		.append(filler).append(nvlToCharPantallaFechaRebate).append(filler).append(rpadNvlModeconf).append(filler)
		.append(rpadNvlIndcontb).append(filler).append(rpadNvlIndcortb).append(filler).append(rpadNvlPantallaObservaciones);

		
		

//		sb.append(rpadNvlPantallaObservaciones + " ");


		/*
		 15 WS-IMPREBAT-1006   PIC  9(013)V9(04).
         15 FILLER             PIC  X(001).
         15 WS-SIGNOREB-1006   PIC  X(001).
         15 FILLER             PIC  X(001).
         15 WS-DIVIREBA-1006   PIC  X(003).
         15 FILLER             PIC  X(001).
         15 WS-FECREBAT-1006   PIC  9(008).
         15 FILLER             PIC  X(001).
         15 WS-MODECONF-1006   PIC  X(012).
         15 FILLER             PIC  X(001).
         15 WS-INDCONTB-1006   PIC  X(001).
         15 FILLER             PIC  X(001).
         15 WS-INDCORTB-1006   PIC  X(001).
         15 FILLER             PIC  X(001).
         15 WS-OBSERVAC-1006   PIC  X(200).
         */
		
		return sb.toString();
	}

	private void insertarPositoque(HistoricoOperacion historicoOperacion2, Date fechamis,
			HistoricoBarreraReturn barrera, MantoqeGlobal mantoq, String indiToque) {
		String tipoOperacion = mantoq.getTipoOperacion()!=null?mantoq.getTipoOperacion():mantoq.getTipoPera();		
		BigDecimal precioeje = mantoqeBarreraBo.obtenerPrecio(historicoOperacion,
						tipoOperacion,
						barrera.getFeciniba(), barrera.getFecfinba(),
						mantoq.getBarreraIO(),
						fechamis);
		Short ordenBarr;
		if (barrera.getOrdenBarr() == 0){
			ordenBarr = Short.valueOf("1");
		}else{
			ordenBarr = Short.valueOf(Integer.toString(barrera.getOrdenBarr()));	
		}
		
		mantoqeBarreraBo.insertarPositoqe(historicoOperacion, barrera.getFeciniba(), barrera.getFecfinba(), 
				barrera.getTipBarP1(), fechamis, precioeje, Identity.instance().getCredentials().getUsername(), 
				tipoOperacion,indiToque, ordenBarr);
	}
	
	public  void noToque(){
		int operNoTocadas = 0;
		limpiarErrores();
		this.msgBoxHeaderResultado ="";
		
		StringBuffer errorCode;
		for (VistaOperacion vo : listasSeleccionadas) {
			if(!tieneErrores(vo)){
				errorCode = new StringBuffer();
				try {
				//SMM 19/10/2011 Se coge la fecha del evento.
				//Se cambia porque se dejan eventos sin solventar de un dia para otro y luego se mataban los del último dia					
//				Date fechaToque = mantOperBo.getFechamis();
				historicoOperacion = vo.getHistOper();
				String datosGen = mantOperBo.recuperarDatosGen(historicoOperacion);

				
				/**
				10 WS-DATOSGEN-2003 REDEFINES WS-DATOSGEN.
				15 WS-TIPOPERA-2003 PIC X(01).
				15 FILLER PIC X(01).
				15 WS-FECINITR-2003 PIC 9(08).
				15 FILLER PIC X(01).
				15 WS-FECFINTR-2003 PIC 9(08).
				15 FILLER PIC X(01).
				15 WS-CONCEPTO-2003 PIC X(03).
				15 FILLER PIC X(01).
				15 WS-TIPCONCE-2003 PIC X(03).
				15 FILLER PIC X(01).
				15 WS-FECHAPLI-2003 PIC 9(08).
				15 FILLER PIC X(01).
				15 WS-CODFORMU-2003 PIC 9(05).
				15 FILLER PIC X(01).
				15 WS-TIPBARP1-2003 PIC X(02).
				15 FILLER PIC X(01).
				15 WS-NIVEBARR-2003 PIC 9(05)V9(12).
				15 FILLER PIC X(01).
				15 WS-PRECIOBA-2003 PIC 9(05)V9(12). 
				15 FILLER PIC X(01). 
				15 WS-PRODUCTO-2003 PIC X(06).
				*** 15 FILLER PIC X(280). 
				15 FILLER PIC X(01). 
				15 WS-ORDENBAR-2003 PIC 9(03).
				15 FILLER PIC X(308). 
				
				 */

				
				
//				HistoricoBarreraReturn barrera = unicaBarrera(historicoOperacion);
//				MantoqeGlobal mantoq = obtenerDatosGlobales(historicoOperacion);
//				insertarPositoque(historicoOperacion, fechamis, barrera, mantoq, Constantes.MANTOQE_S);
				
				//Conversion DatosGen
				String tipoOperacion = datosGen.substring(0, 1);
				String tipBarP1 = datosGen.substring(43, 45);
				String concepto = datosGen.substring(20, 23);
				String tipconcep = datosGen.substring(24, 27);
				String codFormula = datosGen.substring(37, 42);
				String producto = datosGen.substring(82, 88);
				Short ordenBarr = Short.parseShort(datosGen.substring(89, 92));
				
				String compuesto = datosGen.substring(46, 51).concat(".").concat(datosGen.substring(51, 63));
				Double tempEntera = Double.valueOf(compuesto); 
				BigDecimal nivebarr = BigDecimal.valueOf(tempEntera);
				compuesto = datosGen.substring(64, 69).concat(".").concat(datosGen.substring(69, 81));
				tempEntera = Double.valueOf(compuesto);
				BigDecimal precio = BigDecimal.valueOf(tempEntera);
				
				
				SimpleDateFormat sdf = new SimpleDateFormat(Constantes.YYYYMMDD );
				
				
				Date fechaInicio = null ;Date fechaFin=null;
				Date fechaToque=null;
		
					fechaInicio = sdf.parse(datosGen.substring(2, 10));
					fechaFin = sdf.parse(datosGen.substring(11, 19));
					fechaToque = sdf.parse(datosGen.substring(28, 36));
					
					//SMM Cambiamos insert a positoque SOLO SI EVENTO VA BIEN
					
				StringBuffer sb = new StringBuffer();
				String filler = " ";
				
				sb.append(tipoOperacion).append(filler).append(datosGen.substring(2, 10)).append(filler).append(datosGen.substring(11, 19))
				.append(filler).append(concepto).append(filler).append(tipconcep).append(filler).append(datosGen.substring(28, 36))
				.append(filler).append(tipBarP1).append(filler).append(producto).append(filler)
				.append(datosGen.substring(89, 92)).append(GenericUtils.rpad("", 350, " "));
				
				/**
				 *10 WS-DATOSGEN-1007    REDEFINES   WS-DATOSGEN.
                 15 WS-TIPOPERA-1007   PIC  X(001).
                 15 FILLER             PIC  X(001).
                 15 WS-FECINITR-1007   PIC  9(008).
                 15 FILLER             PIC  X(001).
                 15 WS-FECFINTR-1007   PIC  9(008).
                 15 FILLER             PIC  X(001).
                 15 WS-CONCEPTO-1007   PIC  X(003).
                 15 FILLER             PIC  X(001).
                 15 WS-TIPCONCE-1007   PIC  X(003).
                 15 FILLER             PIC  X(001).
                 15 WS-FECHATOQ-1007   PIC  9(008).
                 15 FILLER             PIC  X(001).
                 15 WS-TIPOBARP1-1007  PIC  X(002).
                 15 FILLER             PIC  X(001).
                 15 WS-PRODUCTO-1007   PIC  X(006).
                 15 FILLER             PIC  X(001).
                 15 WS-ORDENBAR-1007   PIC  9(003).
                 15 FILLER             PIC  X(350).
				  */
				
				
				String stringEvento = sb.toString(); 
				
				String retorno = mantoqeBarreraBo.insertarAgendoTCconRet(fechaToque, (int)1007, producto, 
						historicoOperacion, stringEvento, Identity.instance().getCredentials().getUsername());
				
				if (retorno!= null){
					throw new Exception(retorno);
				}else{
					
					mantoqeBarreraBo.insertarPositoqe(historicoOperacion, fechaInicio, fechaFin, 
							tipBarP1, fechaToque, precio, Identity.instance().getCredentials().getUsername(), 
							tipoOperacion,Constantes.MANTOQE_N, ordenBarr);
					
					operNoTocadas++;	
				}
				
				
				} catch (Exception e) {
					// TODO Auto-generated catch block
					addError(vo.getHistOper(), ResourceBundle.instance().getString("mantOper.messages.tocar.cantTocar") + e.getMessage());
//					e.printStackTrace();
				} finally{
					dbLockService.desbloqueo(HistoricoOperacion.class, vo.getHistOper().getId());					
				}
				
			} else {
				addError(vo.getHistOper(), ResourceBundle.instance().getString("mantOper.messages.noToque.noSelection"));
			}
		}
		if (listaErrores.size() > 0) {
			msgBoxFinalStep(true);
			prepareMsgBox("noToqueFinal");
		} else {
			if(operNoTocadas>0){
				msgBoxFinalStep(true);
				listasSeleccionadas.clear();
				String msgNoTocadas = String.valueOf(operNoTocadas) + ResourceBundle.instance().getString("mantOper.messages.noTocadas");
				messageBoxActionMO.initString(msgNoTocadas, "mantOperacionesAction.voidFunction()","", 
						"helperPanel,messagesPanel,mantOperacionesForm,messageBoxPanelToque," +
						"msgboxPanelMantOper,resultadosConsulta");
			}
			msgBoxFinalStep(true);actualizarListaOperaciones(listaOperacionesList); //limpiamos la factory
		}


	
	}
	
	public void noToqueFinal(){
		msgBoxFinalStep(true);
		listasSeleccionadas.clear();
		actualizarListaOperaciones(listaOperacionesList); //limpiamos la factory
	}
	
	public void noToqueFinalDesbloquear(){
		msgBoxFinalStep(true);
		listasSeleccionadas.clear();
		actualizarListaOperaciones(listaOperacionesList); //limpiamos la factory
	}

	

	private boolean existeFechaValidaToqueBarreras() {
		Date fechamis = mantOperBo.getFechamis();
		
		Set<HistoricoBarrera> historicoBarreras = historicoOperacion.getHistoricoBarreras();
		for (HistoricoBarrera historicoBarrera : historicoBarreras) {
			if(historicoBarrera.getFevaltoq() == null	&& historicoBarrera.getFeciniba() != null) {
					if(fechamis.compareTo(historicoBarrera.getFeciniba()) >= 0) {
						return true;
					}
				}
			}

		return false;
	}
	
	private boolean existenFechasValidasTBarr() {
		HistoricoOpcion historicoOpcion = historicoOperacion.getHistoricoOpcion();
		if(historicoOpcion != null) {
			String estado = historicoOpcion.getEstado();
			if(estado != null) {
				String tipoBarrera = null;
				Date fechaInicioBarrera = null;
				String tipoOperacion = historicoOpcion.getTipoOperacion();
				if("A".equalsIgnoreCase(estado)) {
					Set<HistoricoBarrera> historicoBarreras = historicoOperacion.getHistoricoBarreras();
					for (HistoricoBarrera historicoBarrera : historicoBarreras) {
						String tipopera = historicoBarrera.getId().getTipopera();
						String tipbarp1 = historicoBarrera.getId().getTipbarp1();
						if(tipoOperacion.equalsIgnoreCase(tipopera) && tipbarp1.endsWith("O") && historicoBarrera.getFevaltoq() == null) {
							tipoBarrera = historicoBarrera.getTipobarr();
							fechaInicioBarrera = historicoBarrera.getFeciniba();
						}
					}
				} else if("I".equalsIgnoreCase(estado)) {
					Set<HistoricoBarrera> historicoBarreras = historicoOperacion.getHistoricoBarreras();
					for (HistoricoBarrera historicoBarrera : historicoBarreras) {
						String tipopera = historicoBarrera.getId().getTipopera();
						String tipbarp1 = historicoBarrera.getId().getTipbarp1();
						if(tipoOperacion.equalsIgnoreCase(tipopera) && tipbarp1.endsWith("I") && historicoBarrera.getFevaltoq() == null) {
							tipoBarrera = historicoBarrera.getTipobarr();
							fechaInicioBarrera = historicoBarrera.getFeciniba();
						}
					}
				}
				Date fechamis = mantOperBo.getFechamis();

//				if("I".equalsIgnoreCase(tipoBarrera)) {
					if(fechaInicioBarrera != null) {
						if(fechamis.compareTo(fechaInicioBarrera) >= 0) {
							return true;
						}
					}
//				} else if("E".equalsIgnoreCase(tipoBarrera)) {
//					int cuantosSituparm = mantOperBo.cuantosSituparm(historicoOperacion,fechamis);
//					if(cuantosSituparm > 0) {
//						return true;
//					}
//				}
			}
		}
		return false;
	}
	
	private boolean operacionOpcPendienteActivarAgenda(String tipoEvento) {
		int numeroRegistros = 0;
		if(Constantes.TIPO_EVENTO_BARRERA.equalsIgnoreCase(tipoEvento)) {
			numeroRegistros = mantOperBo.cuantosEventos(historicoOperacion,Constantes.TIPO_EVENTO_BARRERA);
		} else if(Constantes.TIPO_EVENTO_EJERCICIO.equalsIgnoreCase(tipoEvento)) {
			numeroRegistros = mantOperBo.cuantosEventos(historicoOperacion,Constantes.TIPO_EVENTO_EJERCICIO);
		}
		if(numeroRegistros <= 1) {
			return false;
		}
		return true;
	}

	

	public String prepareCancelarParcial(){
		
		historicoOperacion = vistaOperacionSelected.getHistOper();
		Integer cmofFirma = CMOFNoFirmado(historicoOperacion); 
		
		if (0==cmofFirma){
		return cancelarParcial();
		}else{
		if (1==cmofFirma ){
			messageBoxActionMO.init("mantoper.cancelacion.warn.cmofFirmado", "mantOperacionesAction.cancelarParcial()",
					"mantOperacionesAction.voidFunction()","helperPanel");
		}else if (2==cmofFirma ){
			messageBoxActionMO.init("mantoper.cancelacion.warn.novacionFirmado", "mantOperacionesAction.cancelarParcial()",
					"mantOperacionesAction.voidFunction()","helperPanel");
		}
		}
		return "";
	}
	
	public String cancelarParcial() {
		listaErrores.clear();
		historicoOperacion = vistaOperacionSelected.getHistOper();
			
		
//		Integer cmofFirma = CMOFNoFirmado(historicoOperacion); 
//		if (0==cmofFirma){
			
		
		if(dbLockService.bloqueo(HistoricoOperacion.class, historicoOperacion.getId())) {
			if (!mantOperBo.validatePendAgendaModifCancelAnul(historicoOperacion)) {
			
				cancelacionPantalla.reset();
				Date fechamis = cancelacionBo.obtenerFechamis();
				setModifCanc("S");
				cancelacionPantalla.setFechacan(fechamis);
				
//				if (historicoOperacion.getImporteMargenCancelacion()!=null){
//					cancelacionPantalla.setImpcanof(historicoOperacion.getImporteMargenCancelacion());	
//				}
				if (historicoOperacion.getDivisaMargenOficina()!=null){
					cancelacionPantalla.setDivicoof(historicoOperacion.getDivisaMargenOficina().getId());
				}
				
				CancelacionParcial cp = mantOperBo.cargarUltimaCancelacion(historicoOperacion.getId().getNumeroOperacion(),historicoOperacion.getId().getFechaContratacion());
				if (cp !=null){
					// MECAP 36691 Cancelaciones
					cancelacionPantalla.setFechacan(cp.getFechaCancelacion());
					cancelacionPantalla.setFecvalcan(cp.getFechaValor());
					cancelacionPantalla.setFechaliq(cp.getFechaLiquidacionPrima());
					cancelacionPantalla.setTiprican(cp.getTipoPrima());
					
//					cancelacionPantalla.setMotivoCancel(cp.getMotivoCancel());
//					cancelacionPantalla.setImportePrimaSub(cp.getImportePrimaSub());
//					cancelacionPantalla.setClaveMurexRelacionada(cp.getClaveMurexRelacionada());
//					
					if(cp.getImportePrima()!=null){
						cancelacionPantalla.setImprican(cp.getImportePrima());	
					}
					
					if (cp.getImporteMargenCancelacion()!=null){
					cancelacionPantalla.setImpcanof(cp.getImporteMargenCancelacion());	
					}

					cancelacionPantalla.setDiprican(cp.getDivisa());
					cancelacionPantalla.setTipocanc(cp.getTipoCancelacion());
				
					cancelacionPantalla.setSentamor(cp.getPataAmortizada());
					String chkccirs = cancelacionBo.obtenerChkccirs(historicoOperacion.getProductoCatalogo().getProducat());
					
					
					cancelacionPantalla.setIndiPostNegociacionOTC1(cp.getIndiPostNegociacionOTC1());
					cancelacionPantalla.setIndiPostNegociacionOTC2(cp.getIndiPostNegociacionOTC2());
					cancelacionPantalla.setIndiPostNegociacionOTC3(cp.getIndiPostNegociacionOTC3());
					cancelacionPantalla.setIndiPostNegociacionOTC4(cp.getIndiPostNegociacionOTC4());
					cancelacionPantalla.setIndiPostNegociacionOTC5(cp.getIndiPostNegociacionOTC5());
					

					cancelacionPantalla.setUsuarioDecisor(cp.getUsuarioDecisor());
					cancelacionPantalla.setUsuarioEjecutor(cp.getUsuarioEjecutor());
					
					cancelacionPantalla.setFechaEjec(cp.getFechaEjec());
					
					cancelacionPantalla.setTradeTv(cp.getTradeTv());
					cancelacionPantalla.setComplexTradeId(cp.getComplexTradeId());
					cancelacionPantalla.setIsinInstrumento(cp.getIsinInstrumento());
					
					cancelacionPantalla.setValorActual(cp.getValorActual());
					cancelacionPantalla.setValorAnual(cp.getValorAnual());
					cancelacionPantalla.setIndicadorNormaIV(cp.getIndicadorNormaIV());
					
					
					if ("S".equalsIgnoreCase(chkccirs) &&  "P".equalsIgnoreCase(cp.getTipoCancelacion())){
		
						cancelacionPantalla.setNominaltp(cp.getNominalPago());  	  	  	
						cancelacionPantalla.setNominalt(cp.getNominalRecibo());
						cancelacionPantalla.setAmortizap(cp.getImporteAmortizarPago());  	
						cancelacionPantalla.setAmortiza(cp.getImporteAmortizarRecibo());
			  
					}else{
						
							if (cp.getPataAmortizada()==null || "A".equalsIgnoreCase(cp.getPataAmortizada())){  
								cancelacionPantalla.setNominalt(cp.getNominalRecibo());
								cancelacionPantalla.setAmortiza(cp.getImporteAmortizarRecibo());
							}else if ("P".equalsIgnoreCase(cp.getPataAmortizada())){ 
								cancelacionPantalla.setNominalt(cp.getNominalPago());
								cancelacionPantalla.setAmortiza(cp.getImporteAmortizarPago());
							}else{
								cancelacionPantalla.setNominalt(cp.getNominalRecibo());
								cancelacionPantalla.setAmortiza(cp.getImporteAmortizarRecibo());
							}
					}
				}
	
				cancelacionPantalla.setObservac(historicoOperacion.getObservacionesCancelacion());
				cancelacionPantalla.setNomitota(BigDecimal.ZERO); 
				refreshPending=true;
				
				return "TO_CANCELARPARCIAL";
				//return Constantes.SUCCESS;
			
			}else{
				addError(historicoOperacion, ResourceBundle.instance().getString("mantOper.cancelacion.error.agenda"));
				this.msgBoxHeaderResultado ="";
				msgBoxFinalStep();
				prepareMsgBox("cancelar");
				return Constantes.FAIL;
			}
				
		} else {
			addError(historicoOperacion, ResourceBundle.instance().getString("mantoper.cancelacion.error.bloqueada"));
			this.msgBoxHeaderResultado ="";
			msgBoxFinalStep();
			prepareMsgBox("cancelar");
			return Constantes.FAIL;
		}			
		
		
//		}else{
//			if (1==cmofFirma ){
//				addError(historicoOperacion, ResourceBundle.instance().getString("mantoper.cancelacion.error.cmofFirmado"));
//				this.msgBoxHeaderResultado ="";
//				msgBoxFinalStep();
//				prepareMsgBox("cancelar");
//			}else if (2==cmofFirma ){
//				addError(historicoOperacion, ResourceBundle.instance().getString("mantoper.cancelacion.error.novacionFirmado"));
//				this.msgBoxHeaderResultado ="";
//				msgBoxFinalStep();
//				prepareMsgBox("cancelar");
//			}
//			return Constantes.FAIL;
//		}
	
	}

	public String prepareCancelar(){
		
		historicoOperacion = vistaOperacionSelected.getHistOper();
		Integer cmofFirma = CMOFNoFirmado(historicoOperacion); 
		
		if (0==cmofFirma){
		return cancelar();
		}else{
			if (1==cmofFirma ){
			messageBoxActionMO.init("mantoper.cancelacion.warn.cmofFirmado", "mantOperacionesAction.cancelar()",
					"mantOperacionesAction.voidFunction()","helperPanel");
			}else if (2==cmofFirma ){
			messageBoxActionMO.init("mantoper.cancelacion.warn.novacionFirmado", "mantOperacionesAction.cancelar()",
					"mantOperacionesAction.voidFunction()","helperPanel");
			}
		}
		return "";
	}
	 public String cancelar() {
		listaErrores.clear();
		this.msgBoxHeaderResultado ="";
		
		historicoOperacion = vistaOperacionSelected.getHistOper();
		
//		Integer cmofFirma 	= CMOFNoFirmado(historicoOperacion); 
//		
//		if (0==cmofFirma){
		
		if(dbLockService.bloqueo(HistoricoOperacion.class, historicoOperacion.getId())) {
			if (!mantOperBo.validatePendAgendaModifCancelAnul(historicoOperacion)) {
				cancelacionPantalla.reset();
				Date fechamis = cancelacionBo.obtenerFechamis();
				Date fechaValor = historicoOperacion.getFechaValor();
				cancelacionPantalla.setFechacan(fechamis);
// MECAP 36691 Cancelaciones
//				if (fechaValor != null && fechaValor.after(fechamis)) {
//					cancelacionPantalla.setFecvalcan(fechaValor);
//				} else {
					cancelacionPantalla.setFecvalcan(fechamis);
//				}
				cancelacionPantalla.setObservac(historicoOperacion.getObservacionesCancelacion());
				refreshPending=true;
				setModifCanc("N");
				return "TO_CANCELAR";
				//return Constantes.SUCCESS;
			}else{
					addError(historicoOperacion, ResourceBundle.instance().getString("mantOper.cancelacion.error.agenda"));
					msgBoxFinalStep();
					prepareMsgBox("cancelar");
					return Constantes.FAIL;
			}
		} else {
			addError(historicoOperacion, ResourceBundle.instance().getString("mantoper.cancelacion.error.bloqueada"));
			msgBoxFinalStep();
			prepareMsgBox("cancelar");
			return Constantes.FAIL;
		}
		
//		}else{
//			if (1==cmofFirma ){
//				addError(historicoOperacion, ResourceBundle.instance().getString("mantoper.cancelacion.error.cmofFirmado"));
//				msgBoxFinalStep();
//				prepareMsgBox("cancelar");
//			}else if (2==cmofFirma ){
//				addError(historicoOperacion, ResourceBundle.instance().getString("mantoper.cancelacion.error.novacionFirmado"));
//				msgBoxFinalStep();
//				prepareMsgBox("cancelar");
//		}
//			return Constantes.FAIL;
//		}
	}

	@Override
	public List<?> getDataTableList() {
		return listaOperacionesList;
	}

	@Override
	protected void refreshListInternal() {
		/*
		 * Para que el paginador funcione correctamente, tenemos que provocar
		 * que la factory vuelva a regenerarse para ello estableceremos la
		 * variable que contiene la lista a null.
		 */
		//listaOperacionesList = null;
		initListaResultados();
	}

	@Override
	public void refrescarListaExcel() {
		setExportExcel(true);
		
		//RBS - Incidencia 973
		listaOperacionesList.clear();
		initParametrosMantOper();
		if (parametrosMantOper.getModo().equals(Constantes.MODO_OPE)) {
			listaOperacionesList.addAll(mantOperBo.getListaOperaciones(paginationData.getPaginationDataForExcel(), procedencia, modelo, productoCatalogo, productoOperacion,
					transaccionOperacion, nivelOperacion, contrapartida, tipoContrapa, divisaPago, divisaCobro, situacion, formula, cobertura,
					pendienteConf, estructura, campana, numOper, fechaVal, fechaVen, fechaOpe, numEstructu, clExterna, clBduGid, suReferencia, fechaCan, false));
		} else {
			if (parametrosMantOper.getModo().equals(Constantes.MODO_AGE)) {
				listaOperacionesList.addAll(mantOperBo.getListaOperacionesAGE(paginationData.getPaginationDataForExcel(), parametrosMantOper.getCodcampa(), parametrosMantOper
						.getCodevent(), parametrosMantOper.getProducto(), parametrosMantOper.getNcorrelaIni(), parametrosMantOper.getNcorrelaFin(),
//						parametrosMantOper.getFechatra(), parametrosMantOper.getEstadoev(), parametrosMantOper.getNumorden()));
						parametrosMantOper.getFechatra(), parametrosMantOper.getEstadoev(), parametrosMantOper.getNumorden(), parametrosMantOper.getTipoBarrera(),false));
			} else if (parametrosMantOper.getModo().equals(Constantes.MODO_CAM)) {
				listaOperacionesList.addAll(mantOperBo.getListaOperacionesCAM(paginationData.getPaginationDataForExcel(), parametrosMantOper.getCodcampa(), parametrosMantOper
						.getNumorden(),false));
			} else if (parametrosMantOper.getModo().equals(Constantes.MODO_OPM)){
				listaOperacionesList.addAll(mantOperBo.getListaOperacionesOPM(paginationData.getPaginationDataForExcel(), parametrosMantOper.getCodcampa(),false));
			}
		}
		// FIN incidencia 973
	}

	public void excelBatch() {
		setExportExcel(true);
		List<VistaOperacion> listaOperaciones = new ArrayList<VistaOperacion>();
		initParametrosMantOper();
		if (parametrosMantOper.getModo().equals(Constantes.MODO_OPE)) {
			listaOperaciones = mantOperBo.getListaOperaciones(paginationData.getPaginationDataForExcel(), procedencia, modelo, productoCatalogo, productoOperacion,
					transaccionOperacion, nivelOperacion, contrapartida, tipoContrapa, divisaPago, divisaCobro, situacion, formula, cobertura,
					pendienteConf, estructura, campana, numOper, fechaVal, fechaVen, fechaOpe, numEstructu, clExterna, clBduGid, suReferencia, fechaCan, true);
			procesoExcelBatch(listaOperaciones,"OPE");
		} else {
			if (parametrosMantOper.getModo().equals(Constantes.MODO_AGE)) {
				listaOperaciones = mantOperBo.getListaOperacionesAGE(paginationData.getPaginationDataForExcel(), parametrosMantOper.getCodcampa(), parametrosMantOper
						.getCodevent(), parametrosMantOper.getProducto(), parametrosMantOper.getNcorrelaIni(), parametrosMantOper.getNcorrelaFin(),
						parametrosMantOper.getFechatra(), parametrosMantOper.getEstadoev(), parametrosMantOper.getNumorden(), parametrosMantOper.getTipoBarrera(),true);
				procesoExcelBatch(listaOperaciones,"AGE");
			} else if (parametrosMantOper.getModo().equals(Constantes.MODO_CAM)) {
				listaOperaciones = mantOperBo.getListaOperacionesCAM(paginationData.getPaginationDataForExcel(), parametrosMantOper.getCodcampa(), parametrosMantOper
						.getNumorden(),true);
				procesoExcelBatch(listaOperaciones,"CAM");
			} else if (parametrosMantOper.getModo().equals(Constantes.MODO_OPM)){
				listaOperaciones = mantOperBo.getListaOperacionesOPM(paginationData.getPaginationDataForExcel(), parametrosMantOper.getCodcampa(),true);
				procesoExcelBatch(listaOperaciones,"OPM");
			}
		}
	}

	private void procesoExcelBatch(List<VistaOperacion> listaOperaciones,String caso) {
		String sqlTxt = null; String sustitucion = null; String sqlHeader = null;
		
		
		sqlHeader ="Prod. Cat.;Prod. Op.;E;Num. Oper.;Sit.;Tran.;F. Contr.;F. Valor.;F. Vto.;Contrapartida;Nominal;" +
				"D P;D C;Proc;Cl. Externa;Usuario;Entidad;SuRefer";
		

		if (listaOperaciones!=null && listaOperaciones.size()>0){
			
			SQLQuery sql = listaOperaciones.get(0).getSqlQuery();
			sqlTxt = sql.getQueryString();
			for (String param : sql.getNamedParameters()) {
				sustitucion = obtenerSustitucion(param, caso);
				param = ":".concat(param);
				
				sqlTxt =	sqlTxt.replaceAll(param , sustitucion);	
			}	
		
			Long peticion = mantOperBo.generarPeticionExcel(sqlTxt,sqlHeader);

			String mensaje = ResourceBundle.instance().getString("liquidaciones.registros.validadosBatch") + " " + peticion ;
			statusMessages.add(Severity.INFO, mensaje);

		}
	}

	private String obtenerSustitucion(String param, String caso) {
		
		
		SimpleDateFormat sdf = new SimpleDateFormat(Constantes.DDMMYYYY);
//		SimpleDateFormat sdf2 = new SimpleDateFormat(Constantes.YYYYMMDD);

		if ("rownumMin".equalsIgnoreCase(param)){
			return paginationData.getPaginationDataForExcel().getFirstResult().toString();
		}else if ("rownumMax".equalsIgnoreCase(param)){
			return paginationData.getPaginationDataForExcel().getMaxResults().toString();
		}else if ("parameterCODCAMPA".equalsIgnoreCase(param)){
				return "'".concat(parametrosMantOper.getCodcampa()).concat("'");
		}else if ("codcampaParam".equalsIgnoreCase(param)){
				return "'".concat(parametrosMantOper.getCodcampa()).concat("'");
		}else if ("parameterNUMORDEN".equalsIgnoreCase(param)){
			return parametrosMantOper.getNumorden().toString();
		}else if ("parameterCODEVENT".equalsIgnoreCase(param)){
			return parametrosMantOper.getCodevent().toString();
		}else if ("parameterNCORRELA_INI".equalsIgnoreCase(param)){
			if ("AGE".equals(caso)){
				return parametrosMantOper.getNcorrelaIni()==null?"null":parametrosMantOper.getNcorrelaIni().toString();
			}else{
				return parametrosMantOper.getNcorrelaIni().toString();
			}
		}else if ("parameterNCORRELA_FIN".equalsIgnoreCase(param)){
			if ("AGE".equals(caso)){
				return parametrosMantOper.getNcorrelaFin()==null?"null":parametrosMantOper.getNcorrelaFin().toString();
			}else{
				return parametrosMantOper.getNcorrelaFin().toString();
			}
		}else if ("parameterFECHATRA".equalsIgnoreCase(param)){
			return "'".concat(sdf.format(parametrosMantOper.getFechatra()).toString()).concat("'");
		}else if ("parameterPRODUCTO".equalsIgnoreCase(param)){
			return parametrosMantOper.getProducto()==null?"null":"'".concat(parametrosMantOper.getProducto().getId()).concat("'");
		}else if ("parameterESTADOEV".equalsIgnoreCase(param)){
			return "'".concat(parametrosMantOper.getEstadoev()).concat("'");
		}else if ("parameterTIPOBARRERA".equalsIgnoreCase(param)){
			return "'".concat(parametrosMantOper.getTipoBarrera()).concat("'");
		}else if ("modeloProd".equalsIgnoreCase(param)){
			return "'".concat(modelo.getModelpro()).concat("'");
		}else if ("tipoContrapartida".equalsIgnoreCase(param)){
			return "'".concat(tipoContrapa.getId()).concat("'");
		}else if ("productoOperacion".equalsIgnoreCase(param)){
			return "'".concat("").concat("'");
		}else if ("productoCatalogo".equalsIgnoreCase(param)){
			return productoCatalogo.getProducat().toString();
		}else if ("procedenciaProducto".equalsIgnoreCase(param)){
			return "'".concat(procedencia.getProceden()).concat("'");
		}else if ("divisaPago".equalsIgnoreCase(param)){
			return "'".concat(divisaPago.getId()).concat("'");
		}else if ("divisaRecibo".equalsIgnoreCase(param)){
			return "'".concat(divisaCobro.getId()).concat("'");
		}else if ("contrapa".equalsIgnoreCase(param)){
			return "'".concat(contrapartida).concat("'");
		}else if ("nivCaptura".equalsIgnoreCase(param)){
			return "'".concat(nivelOperacion.getCodigo()).concat("'");
		}else if ("suReferencia".equalsIgnoreCase(param)){
			return "'".concat(suReferencia).concat("'");
		}else if ("transaccion".equalsIgnoreCase(param)){
			return "'".concat(transaccionOperacion.getCodigo()).concat("'");
		}else if ("formula".equalsIgnoreCase(param)){
			return formula.getCodigoFormula().toString();
		}else if ("numOperMin".equalsIgnoreCase(param)){
			return numOper.getLow().toString();
		}else if ("numOperMax".equalsIgnoreCase(param)){
			return numOper.getHigh().toString();
		}else if ("fechaOpeMin".equalsIgnoreCase(param)){
			return "'".concat(sdf.format(fechaOpe.getLow()).toString()).concat("'");
		}else if ("fechaOpeMax".equalsIgnoreCase(param)){
			return "'".concat(sdf.format(fechaOpe.getHigh()).toString()).concat("'");
		}else if ("fechaValMin".equalsIgnoreCase(param)){
			return "'".concat(sdf.format(fechaVal.getLow()).toString()).concat("'");
		}else if ("fechaValMax".equalsIgnoreCase(param)){
			return "'".concat(sdf.format(fechaVal.getHigh()).toString()).concat("'");
		}else if ("fechaVenMin".equalsIgnoreCase(param)){
			return "'".concat(sdf.format(fechaVen.getLow()).toString()).concat("'");
		}else if ("fechaVenMax".equalsIgnoreCase(param)){
			return "'".concat(sdf.format(fechaVen.getHigh()).toString()).concat("'");
		}else if ("pendienteConf".equalsIgnoreCase(param)){
			return "'".concat(GenericUtils.SNBooleanNotNull(pendienteConf)).concat("'");
		}else if ("estructura".equalsIgnoreCase(param)){
			return "'".concat(GenericUtils.SNBooleanNotNull(estructura)).concat("'");
		}else if ("campana".equalsIgnoreCase(param)){
			return "'".concat(GenericUtils.SNBooleanNotNull(campana)).concat("'");
		}else if ("cobertura".equalsIgnoreCase(param)){
			return "'".concat(GenericUtils.SNBooleanNotNull(cobertura)).concat("'");
		}else if ("situacion".equalsIgnoreCase(param)){
			return "'".concat(situacion.getCodigo()).concat("'");
		}else if ("clExternaMin".equalsIgnoreCase(param)){
			return clExterna.getLow().toString();
		}else if ("clExternaMax".equalsIgnoreCase(param)){
			return clExterna.getHigh().toString();
		}else if ("estructuraMin".equalsIgnoreCase(param)){
			return numEstructu.getLow().toString();
		}else if ("estructuraMax".equalsIgnoreCase(param)){
			return numEstructu.getHigh().toString();
		}else if ("claveBduMin".equalsIgnoreCase(param)){
			return "'".concat(clBduGid.getLow()).concat("'");
		}else if ("claveBduMax".equalsIgnoreCase(param)){
			return "'".concat(clBduGid.getHigh()).concat("'");
		}else if ("fechaCanMin".equalsIgnoreCase(param)){
			return "'".concat(sdf.format(fechaCan.getLow()).toString()).concat("'");
		}else if ("fechaCanMax".equalsIgnoreCase(param)){
			return "'".concat(sdf.format(fechaCan.getHigh()).toString()).concat("'");
		}else{
			return "1";		
		}

	}

	@SuppressWarnings("unchecked")
	@Override
	public void setDataTableList(List<?> dataTableList) {
		listaOperacionesList = (List<VistaOperacion>) dataTableList;
	}

	@Out
	public Boolean getSelectedRow() {
		if (vistaOperacionSelected != null && listasSeleccionadas != null) {
			return contains(vistaOperacionSelected);
		} else {
			return false;
		}
	}

	public void setSelectedRow(Boolean selected) {
		if (selected) {
			listasSeleccionadas.add((VistaOperacion) vistaOperacionSelected);
		} else {
			listasSeleccionadas.remove((VistaOperacion) vistaOperacionSelected);
		}
	}
	
	public boolean contains(VistaOperacion voSelected){
		boolean ret = false;
		for (VistaOperacion vo : listasSeleccionadas) {
			if(vo.equals(voSelected)){
				ret = true;
				break;
			}
		} 
		return ret; 
	}
	
	public void seleccionarLista(){ }

	public void selectAll() {
		//listasSeleccionadas.addAll(listaOperacionesList);
//		Long numOperaciones = mantOperBo.getNumeroOperaciones(paginationData, procedencia, modelo,
//				productoCatalogo, productoOperacion, transaccionOperacion,
//				nivelOperacion, contrapartida, tipoContrapa, divisaPago,
//				divisaCobro, situacion, formula, cobertura, pendienteConf,
//				estructura, campana, numOper, fechaVal, fechaVen, fechaOpe,
//				numEstructu, clExterna);
		
		int tmpMaxResults = paginationData.getMaxResults();
		int tmpFirstResult = paginationData.getFirstResult();
		paginationData.setMaxResults(501);
		paginationData.setFirstResult(0);
		List<VistaOperacion> prepareOperacionesList = prepareOperacionesList();
		int iteraciones = prepareOperacionesList.size();
		if(prepareOperacionesList.size() > 500){
			statusMessages.add(Severity.INFO, "#{messages['mantoper.seleccionados.primeros.cincuenta']}");
			iteraciones = 500;
			tmpFirstResult=0;
			maxSelected = 499;
		} else {
			maxSelected = prepareOperacionesList.size()-1;
		}
		listasSeleccionadas.clear(); 
		for(int i = 0; i<iteraciones; i++){
			listasSeleccionadas.add(prepareOperacionesList.get(i));
		}
		paginationData.setMaxResults(tmpMaxResults);
		paginationData.setFirstResult(tmpFirstResult);
		
	}

	public void deSelectAll() {
		//Este metodo borra Todos y punto
		listasSeleccionadas.clear();  //.removeAll(listaOperacionesList);
		maxSelected = 0;
	}

	public void voidFunction(){
		msgBoxAction.voidFunction();
	}
	
	/*************************************************************************************************/
	/*********************************** MANEGADOR D'ERRORS ********************************************/
	/*************************************************************************************************/

	@SuppressWarnings("unused")
	private boolean addWarning(VistaOperacion vo) {
		return addWarning(vo.getHistOper(), "");
	}

	private boolean addWarning(VistaOperacion vo, String message) {
		return addWarning(vo.getHistOper(), message);
	}

	@SuppressWarnings("unused")
	private boolean addWarning(HistoricoOperacion ho) {
		return addWarning(ho, "");
	}

	private boolean addWarning(HistoricoOperacion ho, String message) {
		SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
		return listaErrores.add(new ErrorMessage(TypeError.WARNING, ho.getId().getNumeroOperacion().toString(), sdf.format(ho.getId()
				.getFechaContratacion()), message, ho));
	}
	
	@SuppressWarnings("unused")
	private boolean addError(VistaOperacion vo) {
		return addError(vo.getHistOper(), "");
	}

	private boolean addError(VistaOperacion vo, String message) {
		return addError(vo.getHistOper(), message);
	}

	@SuppressWarnings("unused")
	private boolean addError(HistoricoOperacion ho) {
		return addError(ho, "");
	}

	private boolean addError(HistoricoOperacion ho, String message) {
		if(isWarning(ho)){
			removeMessage(ho);
		}
		SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
		if (ho.getId()==null){
			return listaErrores.add(new ErrorMessage(TypeError.ERROR, message, sdf.format(new Date()), message, ho));
			
		}		
		return listaErrores.add(new ErrorMessage(TypeError.ERROR, ho.getId().getNumeroOperacion().toString(), sdf.format(ho.getId()
				.getFechaContratacion()), message, ho));
	}

	private void limpiarErrores(boolean allErrors) {
		for (ErrorMessage em : listaErrores) {
			VistaOperacion voAux = null;
			if(em.getTypeError().equals(TypeError.ERROR) || allErrors){
				for (VistaOperacion vo : listasSeleccionadas) {
					if (em.getHo().equals(vo.getHistOper())) {
						voAux = vo;
						break;
					}
				}
				if (voAux != null) {
					listasSeleccionadas.remove(voAux);
				}
			}
		}
		listaErrores.clear();
	}
	
	private void limpiarErrores() {
		limpiarErrores(false);
	}
	
	@SuppressWarnings("unused")
	private boolean isWarning(VistaOperacion vo){
		return isWarning(vo.getHistOper());
	}
	private boolean isWarning(HistoricoOperacion ho){
		for (ErrorMessage em : listaErrores) {
			if(em.getTypeError().equals(TypeError.WARNING)){
				if (em.getHo().equals(ho)) {
					return true;
				}
			}
		}
		return false;
	}
	
	@SuppressWarnings("unused")
	private boolean removeMessage(VistaOperacion vo){
		return removeMessage(vo.getHistOper());
	}
	private boolean removeMessage(HistoricoOperacion ho){
		for (ErrorMessage em : listaErrores) {
			if(em.getHo().equals(ho)){
				return listaErrores.remove(em);
			}
		}
		return false;
	}
	
	private boolean tieneErrores(VistaOperacion vo){
		return tieneErrores(vo.getHistOper());
	}
	private boolean tieneErrores(HistoricoOperacion ho){
		for (ErrorMessage em : listaErrores) {
			if(em.getTypeError().equals(TypeError.ERROR)){
				if (em.getHo().equals(ho)) {
					return true;
				}
			}
		}
		return false;
	}
	
	private void prepareMsgBox(String accion) {
		if (listaErrores.size() > 0) {
			Collections.sort(listaErrores, new Comparator<ErrorMessage>() {
				public int compare(ErrorMessage o1, ErrorMessage o2) {
					return o1.getTypeError().getSortNumber().compareTo(o2.getTypeError().getSortNumber());
				}
			});
			msgBoxNoProcessable = ResourceBundle.instance().getString("mantOper.messages." + accion + ".noSelection");
			msgBoxHeaderListaErrores = ResourceBundle.instance().getString("mantOper.messages.no." + accion + "");
			if (!msgBoxFinalStep) {
				msgBoxAction.mostrarMsg("#{mantOperacionesAction." + accion + "()}", "#{mantOperacionesAction." + accion + "Desbloquear()}", "");
			} else {
				msgBoxAction.mostrarMsg("#{mantOperacionesAction." + accion + "()}", "#{mantOperacionesAction.voidFunction()}", "");
			}

		}
	}

	private void msgBoxMessageMode(String accion, String message){
		msgBoxMessageMode = true;
		msgBoxHeaderListaErrores = message;
		msgBoxAction.mostrarMsg("#{mantOperacionesAction." + accion + "()}", "#{mantOperacionesAction.voidFunction()}", "");
	}
	
	private void msgBoxFirstStep() {
		msgBoxMessageMode = false;
		msgBoxFinalStep = false;
		msgBoxWidth = "450";
	}

	private void msgBoxFinalStep(){
		msgBoxFinalStep(false);
	}
	private void msgBoxFinalStep(boolean finalMessage) {
		msgBoxMessageMode = false;
		msgBoxFinalStep = true;
		msgBoxWidth = "700";
		msgBoxAction.setVoidFunction(true);
		if(finalMessage){
			msgBoxFinalStep = false;
			msgBoxAction.noMostrarMensaje();
		}else 
		{
			msgBoxAction.setMostrarMensaje(true);
		}
		
	}
	
	private void println(String message){
		System.out.println(message);
	}
	/*************************************************************************************************/
	/************************************* ACTIVACIO BOTONS ********************************************/
	/*************************************************************************************************/

	public boolean btnModificacion(VistaOperacion vo) {
		boolean ret = true;
		
		if (!parametrosMantOper.getModo().equals(Constantes.MODO_OPM)) {
			try {
				
				if (vo.getEstructu() !=null && vo.getEstructu() == 'E') return false;
				
				String estadoco = vo.getHistOper().getEstado().getCodigo();
				String indsitua = vo.getHistOper().getUltimaAccion().getCodigo();
				if(estadoco.equals("CA") || estadoco.equals("AN") || estadoco.equals("VE") || estadoco.equals("EJ") || estadoco.equals("EX") || (estadoco.equals("PV") && !indsitua.equals("M") && !indsitua.equals("A"))){
					ret = false;
				}
				if (vo.getHistOper().getIndicadorOperacionModelo()) {
					if((vo.getNumOrdenes() > 0)){
						ret = false;
					}
					/* Ahora se Calcula en la Query principal
					 * if(mantOperBo.validateOrdenesModificacion(vo.getHistOper())) { ret = false; }
					 */
				}
			} catch (NullPointerException e) {
				ret = false;
			}
		} else {
			ret = false;
		}
		return ret;
	}

	public boolean btnConfirmacion(VistaOperacion vo) {
		boolean ret = false;
		if (!parametrosMantOper.getModo().equals(Constantes.MODO_OPM)) {
			try {
				if (vo.getEstructu() !=null && vo.getEstructu() == 'E') return false;
				
				String estadoco = vo.getHistOper().getEstado().getCodigo();
				String indsitua = vo.getHistOper().getUltimaAccion().getCodigo();
				if (estadoco.equals("CA") || estadoco.equals("AN") || (estadoco.equals("VA") && indsitua != "E" && indsitua != "T")) {
					ret = vo.getNumConfirmaciones()>0;
					//ret = mantOperBo.validateNumConfirmaciones(vo.getHistOper());
				} else {
					// No se muestra el boton
				}
			} catch (NullPointerException e) {
				// No se muestra el boton
			}
		}
		return ret;
	}

	public boolean btnTipoCancelacion(String tipo/* Canc o Modif_canc */, VistaOperacion vo) {
		boolean ret = false;
		if (!parametrosMantOper.getModo().equals(Constantes.MODO_OPM)) {
			Long prodCatal = null;
			//FLM: No todas las operaciones tienen producto catalogo, sólo para que no falle
			try {
				if (vo.getEstructu() !=null && vo.getEstructu() == 'E') return false;
				
				prodCatal = vo.getHistOper().getProductoCatalogo().getProducat();				
			} finally {
				if (prodCatal==null)
					return false;
			}
			if (prodCatal != 2 && prodCatal != 1751213 && prodCatal != 1751214) {
				try {
					String estadoco = vo.getHistOper().getEstado().getCodigo();
					String indsitua = vo.getHistOper().getUltimaAccion().getCodigo();
					if (estadoco.equals("VA") && !"E".equals(indsitua) 
//							&& !"T".equals(indsitua)
							) {
						//Tenemos Cancelacion, validamos si se corresponde por el tipo
						if(tipo.equals("Canc")) ret = true;
					} else if (estadoco.equals("PV") && ("C".equals(indsitua) || "P".equals(indsitua))) {
						// Tenemos Cancelacion Parcial
						if(tipo.equals("Modif_canc")) ret = true;
					}
				} catch (NullPointerException e) { }
			}
		}
		return ret;
	}


	
//	IF P_modelo IN ('OPC', 'EQU') and (VistaOperacion.estadoco in ('VA',’EX’,’VE’) and
//			(P_inestliq <> 'S') and P_estadoopc = ‘A’  and MODO<>’OPM’
//			END-IF

	public boolean btnEjercicio(VistaOperacion vo) {
		HistoricoOperacion ho = vo.getHistOper();
		try{
//			if (vo.getEstructu() !=null && vo.getEstructu() == 'E') return false;
			
			DescripcionEstadoOperacion estado = ho.getEstado();
			ProductoCatalogo producat = ho.getProductoCatalogo();
			String estadoOpc = "";
			String indsitua="";
			DescripcionSituacion descripcionSituacion  =ho.getUltimaAccion();
			
			if( !GenericUtils.isNullOrBlank(descripcionSituacion)){
				indsitua=descripcionSituacion.getCodigo();

			}
			
			
			if (ho.getHistoricoOpcion() != null) {
				estadoOpc = ho.getHistoricoOpcion().getEstado();
				estadoOpc = "A"; //TEMPORAL
			}
			String inestliq = devuelveCampoInestliq();

			if (estado != null && estado != null && producat != null) {
				ModeloProducto modelpro = producat.getModelpro();
				if (modelpro != null) {
					boolean botoEjercicio = (("OPC".equalsIgnoreCase(modelpro.getModelpro()) || "EQU".equalsIgnoreCase(modelpro.getModelpro())) && 
							("VA".equalsIgnoreCase(estado.getCodigo()) || "VE".equalsIgnoreCase(estado.getCodigo()) 
							|| ("EX".equalsIgnoreCase(estado.getCodigo()) && !"E".equalsIgnoreCase(indsitua)))	&&
							"A".equalsIgnoreCase(estadoOpc)&&
							!"S".equalsIgnoreCase(inestliq) &&
							!Constantes.MODO_OPM.equalsIgnoreCase(parametrosMantOper.getModo()));
					
					if (botoEjercicio){
						botoEjercicio = comprobarEjerc(ho);	
					}
					return  botoEjercicio;
				} 
			}
		} catch (Exception e) { }
		return false;
	}
	

	public boolean comprobarEjerc(HistoricoOperacion histoper){
		Boolean existeBarreraI  = false;
		if (histoper.getHistoricoBarreras()!=null ){
			for (HistoricoBarrera barrera : histoper.getHistoricoBarreras()) {
	
				String tipbarp1 = barrera.getId().getTipbarp1();
				if(tipbarp1.endsWith("I")){
					existeBarreraI  = true;
					if (barrera.getFevaltoq() != null) {
						return true;
					} 
				}
			}
		}
		if (existeBarreraI){
			return false;	
		}else{
			return true;
		}
		
	}

	
	public boolean btnEjerciciosParciales(VistaOperacion vo) {
		HistoricoOperacion ho = vo.getHistOper();
		try{
			if (vo.getEstructu() !=null && vo.getEstructu() == 'E') return false;
			
			DescripcionEstadoOperacion estado = ho.getEstado();
			DescripcionSituacion ultimaAccion = ho.getUltimaAccion();
			ProductoCatalogo producat = ho.getProductoCatalogo();
			DescripcionEstiloOpcion estilo = null;
		
			if (ho.getHistoricoOpcion() != null) {
				estilo = ho.getHistoricoOpcion().getEstiloOpcion();
			}
			String inestliq = devuelveCampoInestliq();
			if (estado != null && estado != null && ultimaAccion != null && producat != null) {
				ModeloProducto modelpro = producat.getModelpro();
				if (modelpro != null) {
					return ("OPC".equalsIgnoreCase(modelpro.getModelpro()) && 
							"VA".equalsIgnoreCase(estado.getCodigo()) &&
							!"S".equalsIgnoreCase(inestliq) &&
							!"E".equalsIgnoreCase(ultimaAccion.getCodigo())&&
							!"E".equalsIgnoreCase((estilo==null)?Constantes.CADENA_VACIA:estilo.getCodigo()) &&
							!Constantes.MODO_OPM.equalsIgnoreCase(parametrosMantOper.getModo()));
				} 
			}
		} catch (Exception e) { }
		return false;
	}
	
	public boolean btnToqueBarrera(VistaOperacion vo) {
		historicoOperacion = vo.getHistOper();
		try{
//			if (vo.getEstructu() !=null && vo.getEstructu() == 'E') return false;
			
			DescripcionEstadoOperacion estado = historicoOperacion.getEstado();
			DescripcionSituacion ultimaAccion = historicoOperacion.getUltimaAccion();
			ProductoCatalogo producat = historicoOperacion.getProductoCatalogo();
			String inestliq = devuelveCampoInestliq();
			
			if(estado != null && estado != null && ultimaAccion != null && producat != null) {
				ModeloProducto modelpro = producat.getModelpro();
				if(modelpro != null) {
					boolean botoToque = (("OPC".equalsIgnoreCase(modelpro.getModelpro()) ||
							"EQU".equalsIgnoreCase(modelpro.getModelpro())) &&
							"VA".equalsIgnoreCase(estado.getCodigo()) &&
							!"S".equalsIgnoreCase(inestliq) &&
							!"E".equalsIgnoreCase(ultimaAccion.getCodigo())&&
							!Constantes.MODO_OPM.equalsIgnoreCase(parametrosMantOper.getModo()));
					//SMM 10/05/2015
					if (botoToque){
						botoToque = comprobarToque(historicoOperacion);
					}
					return botoToque;
				
				} 
			}
		} catch (Exception e) { }
		return false;
	}
	
	public boolean comprobarToque(HistoricoOperacion histoper){
		if (histoper.getHistoricoBarreras()!=null ){
			for (HistoricoBarrera barrera : histoper.getHistoricoBarreras()) {
	
//				String tipbarp1 = barrera.getId().getTipbarp1();
//				tipbarp1.endsWith("I") &&
				if( barrera.getFevaltoq() == null) {
					return true;
				} 
			}
		}
		
		return false;
	}
	
	private String devuelveCampoInestliq() {
		String tipopera = null;
		if (historicoOperacion.getHistoricoOpcion() != null) {
			tipopera = historicoOperacion.getHistoricoOpcion().getTipoOperacion();
		}
		if (tipopera != null) {
			DescripcionFormula formula = null;
			if ("P".equalsIgnoreCase(tipopera)) {
				formula = historicoOperacion.getFormulaPago();
			} else if ("R".equalsIgnoreCase(tipopera)) {
				formula = historicoOperacion.getFormulaRecibo();
			}

			if (formula != null) {
				String inestliq = formula.getIndicadorCalendarioLiquidacion();
				if (inestliq != null) {
					return inestliq;
				}
				return "X";
			}
		}
		return "S";
	}

	private Divisa divisaOpcion() {
		String tipopera = null;
		Divisa divisa = null;
		if (historicoOperacion.getHistoricoOpcion() != null) {
			tipopera = historicoOperacion.getHistoricoOpcion().getTipoOperacion();
		}
		if (tipopera != null) {
			if ("P".equalsIgnoreCase(tipopera)) {
				divisa = historicoOperacion.getDivisaPago();
			} else if ("R".equalsIgnoreCase(tipopera)) {
				divisa = historicoOperacion.getDivisaRecibo();
			}
		}
		return divisa;
	}	
	private void initParametrosMantOper() {
		if (parametrosMantOper == null) {
			parametrosMantOper = new ParametrosMantoper();
			parametrosMantOper.setModo(Constantes.MODO_OPE);
		}
	}

	/*************************************************************************************************/
	/***************************************** FACTORY's ***********************************************/
	/*************************************************************************************************/
	@Factory(value = "mantOperaciones.procedencia")
	public void initProcedenciaProducto() {
		procedenciaProductoList = mantOperBo.getProcedencia();
	}

	@Factory(value = "mantOperaciones.modelo")
	public void initModeloProducto() {
		modeloProductoList = mantOperBo.getModelo();
	}

	@Factory(value = "mantOperaciones.productoCatalogo")
	public void initProductoCatalogo() {
		productoCatalogoList = new ArrayList<ProductoCatalogo>();
		productoCatalogoList = mantOperBo.getProductoCatalogos(procedencia, modelo);
	}

	@Factory(value = "mantOperaciones.productoOperacion")
	public void initProductoOperacion() {
		productoOperacionList = new ArrayList<Producto>();
		if (productoCatalogo != null) {
			productoOperacionList = mantOperBo.getProductoOperacion(productoCatalogo);
		} else {
			productoOperacionList = mantOperBo.getProductoOperacion(null);
		}
	}

	@Factory(value = "mantOperaciones.divisa")
	public void initDivisa() {
		divisasList = mantOperBo.getDivisas();
	}

	@Factory("mantOperaciones.transaccion")
	public void initDescripcionTransaccionOperacionList() {
		transaccionesList = new ArrayList<DescripcionTransaccionOperacion>();
		if (productoCatalogo != null) {
			Set<RelProductoTransaccion> transSet = productoCatalogo.getProductoTransacciones();
			for (RelProductoTransaccion relProductoTransaccion : transSet) {
				transaccionesList.add(relProductoTransaccion.getId().getTranoper());
			}
		} else {
			transaccionesList = mantOperBo.getDescripcionTransaccionOperacions();
		}
	}

	@Factory("mantOperaciones.nivCaptura")
	public void initNivelCaptura() {
		nivCapturaList = new ArrayList<NivelOperacion>();
		nivCapturaList = mantOperBo.getNivelOperacion();
	}

	@Factory("mantOperaciones.tipoContrapa")
	public void initTipoContrapartida() {
		tipoContrapartidasList = new ArrayList<TipoContrapartida>();
		tipoContrapartidasList = mantOperBo.getTipoContrapa();
	}

	@Factory("mantOperaciones.situacion")
	public void initSituacionOperacion() {
		busquedaOperacionesList = new ArrayList<BusquedaOperacion>();
		busquedaOperacionesList = mantOperBo.getBusquedaOperaciones();
	}

	@Factory("mantOperaciones.formula")
	public void initDescripcionFormula() {
		descripcionFormulaList = new ArrayList<DescripcionFormula>();
		if (productoCatalogo != null) {
			Set<RelProductoFormula> formuSet = productoCatalogo.getProductoFormulas();
			for (RelProductoFormula relProductoFormula : formuSet) {
				descripcionFormulaList.add(relProductoFormula.getId().getCodformu());
			}
		} else {
			descripcionFormulaList = mantOperBo.getDescripcionFormula();
		}
	}

	@Factory("mantOperaciones.listaResultados")
	public void initListaResultados() {
		if(isPrimerAcceso() && GenericUtils.isNullOrBlank(parametrosMantOper)){
//			setPrimerAcceso(false);
			listaOperacionesList = new ArrayList<VistaOperacion>();
			return;
		}
		try {
//			log.info("init 1");
			listaOperacionesList = prepareOperacionesList();
			
			log.info("INIT BOTONS");
			for(VistaOperacion vo : listaOperacionesList){
				if(btnModificacion(vo)) vo.getHasEstate().add(VistaOperacionBTN.MODIFICAR);
				if(btnConfirmacion(vo)) vo.getHasEstate().add(VistaOperacionBTN.CONFIRMAR);
				if(btnTipoCancelacion("Canc", vo)) vo.getHasEstate().add(VistaOperacionBTN.CANC);
				if(btnTipoCancelacion("Modif_canc", vo)) vo.getHasEstate().add(VistaOperacionBTN.CANC_MODIF);
				if(btnToqueBarrera(vo)) vo.getHasEstate().add(VistaOperacionBTN.TOQUEBARRERA);
//				if(btnEjerciciosParciales(vo)) vo.getHasEstate().add(VistaOperacionBTN.EJECPARC);
				if(btnEjercicio(vo)) vo.getHasEstate().add(VistaOperacionBTN.EJERCICIO);
				if(vo.getPersistenceException()!=null){
					PersistenceException exception = vo.getPersistenceException();
					statusMessages.add(Severity.ERROR, exception.getMessage(),exception);
				}
			}
//			log.info("END BOTONS/INIT 1");
		} catch (Exception e) {
			// TODO: handle exception
			statusMessages.add(Severity.ERROR, e.getMessage(),e);
			listaOperacionesList = new ArrayList<VistaOperacion>();
		}
	}

	private List<VistaOperacion> prepareOperacionesList() {
		setExportExcel(false);
		List<VistaOperacion> listaOperacionesList  = new ArrayList<VistaOperacion>();
		initParametrosMantOper();
		if (parametrosMantOper.getModo().equals(Constantes.MODO_OPE)) {
			List<VistaOperacion> listaOperaciones = mantOperBo.getListaOperaciones(paginationData, procedencia, modelo, productoCatalogo, productoOperacion,
					transaccionOperacion, nivelOperacion, contrapartida, tipoContrapa, divisaPago, divisaCobro, situacion, formula, cobertura,
					pendienteConf, estructura, campana, numOper, fechaVal, fechaVen, fechaOpe, numEstructu, clExterna, clBduGid, suReferencia, fechaCan, false);
			if(listaOperaciones!=null){
				listaOperacionesList = listaOperaciones;
				setPrimerAcceso(false);
			}
		} else {
			if (parametrosMantOper.getModo().equals(Constantes.MODO_AGE)) {
				List<VistaOperacion> listaOperacionesAGE = mantOperBo.getListaOperacionesAGE(paginationData, parametrosMantOper.getCodcampa(), parametrosMantOper
						.getCodevent(), parametrosMantOper.getProducto(), parametrosMantOper.getNcorrelaIni(), parametrosMantOper.getNcorrelaFin(),
//						parametrosMantOper.getFechatra(), parametrosMantOper.getEstadoev(), parametrosMantOper.getNumorden());
						parametrosMantOper.getFechatra(), parametrosMantOper.getEstadoev(), parametrosMantOper.getNumorden(), parametrosMantOper.getTipoBarrera(),false);
				if(listaOperacionesAGE!=null){
					listaOperacionesList.addAll(listaOperacionesAGE);
				}
			} else if (parametrosMantOper.getModo().equals(Constantes.MODO_CAM)) {
				List<VistaOperacion> listaOperacionesCAM = mantOperBo.getListaOperacionesCAM(paginationData, parametrosMantOper.getCodcampa(), parametrosMantOper
						.getNumorden(),false);
				if(listaOperacionesList!=null){
					listaOperacionesList.addAll(listaOperacionesCAM);
					setPrimerAcceso(false);
				}
			} else if (parametrosMantOper.getModo().equals(Constantes.MODO_OPM)){
				List<VistaOperacion> listaOperacionesOPM = mantOperBo.getListaOperacionesOPM(paginationData, parametrosMantOper.getCodcampa(),false);
				if(listaOperacionesOPM!=null){
					listaOperacionesList.addAll(listaOperacionesOPM);
					setPrimerAcceso(false);
				}
			}
		}
		return listaOperacionesList;
	}


	private Integer prepareOperacionesListCount() {
		Integer comptadorRegistres = new Integer(0);
		initParametrosMantOper();
		
		if (parametrosMantOper.getModo().equals(Constantes.MODO_OPE)) {
			List<VistaOperacion> listaOperaciones = mantOperBo.getListaOperaciones(paginationData, procedencia, modelo, productoCatalogo, productoOperacion,
					transaccionOperacion, nivelOperacion, contrapartida, tipoContrapa, divisaPago, divisaCobro, situacion, formula, cobertura,
					pendienteConf, estructura, campana, numOper, fechaVal, fechaVen, fechaOpe, numEstructu, clExterna, clBduGid, suReferencia, fechaCan, null);
			comptadorRegistres = listaOperaciones.get(0).getNumeroRegistros();
		} else {
			if (parametrosMantOper.getModo().equals(Constantes.MODO_AGE)) {
				List<VistaOperacion> listaOperacionesAGE = mantOperBo.getListaOperacionesAGE(paginationData, parametrosMantOper.getCodcampa(), parametrosMantOper
						.getCodevent(), parametrosMantOper.getProducto(), parametrosMantOper.getNcorrelaIni(), parametrosMantOper.getNcorrelaFin(),
//						parametrosMantOper.getFechatra(), parametrosMantOper.getEstadoev(), parametrosMantOper.getNumorden());
						parametrosMantOper.getFechatra(), parametrosMantOper.getEstadoev(), parametrosMantOper.getNumorden(), parametrosMantOper.getTipoBarrera(),null);
				if(listaOperacionesAGE!=null){
					comptadorRegistres = listaOperacionesAGE.get(0).getNumeroRegistros();
				}
			} else if (parametrosMantOper.getModo().equals(Constantes.MODO_CAM)) {
				List<VistaOperacion> listaOperacionesCAM = mantOperBo.getListaOperacionesCAM(paginationData, parametrosMantOper.getCodcampa(), parametrosMantOper
						.getNumorden(),null);
				if(listaOperacionesList!=null){
					comptadorRegistres = listaOperacionesCAM.get(0).getNumeroRegistros();
					setPrimerAcceso(false);
				}
			} else if (parametrosMantOper.getModo().equals(Constantes.MODO_OPM)){
				List<VistaOperacion> listaOperacionesOPM = mantOperBo.getListaOperacionesOPM(paginationData, parametrosMantOper.getCodcampa(),null);
				if(listaOperacionesOPM!=null){
					comptadorRegistres = listaOperacionesOPM.get(0).getNumeroRegistros();
					setPrimerAcceso(false);
				}
			}
		}
		return comptadorRegistres;
	}

	/*
	 * Comprueba si la contrapartida especificada tiene el CMOF firmado, solo
	 * para tipos de Contrapartida Cliente. Devuelve True o False.
	 * 
	 * FUNCTION F_CMOF_NO_FIRMADO RETURN BOOLEAN IS v_cont number; v_return
	 * boolean := false; BEGIN if Contrapartida is not null AND Contrapartida <>
	 * 'FDI' THEN
	 * 
	 * select count(1) into v_cont from gestio_tressoreria.contrapa where
	 * contrapa = Contrapartida and tipocont = 'C';
	 * 
	 * if v_cont > 0 then select count(1) into v_cont from
	 * gestio_tressoreria.docucont where contrapa = Contrapartida and codidocu =
	 * 'CMOF' and estadoco = 'F';
	 * 
	 * if v_cont=0 then v_return := true; else v_return := false; end if; end
	 * if; end if; return v_return;
	 * 
	 * EXCEPTION WHEN OTHERS THEN mostrar_mensaje('Error al comprobar si la
	 * contrapartida tiene el CMOF firmado: ' || sqlerrm); return (FALSE); END;
	 */
	private Integer CMOFNoFirmado(HistoricoOperacion ho) {
		// 0 - Sin errores
		// 1 - CMOF no firmado
		// 2 - Anexo no firmado
		
		try {
			if(!contrapartidaUtil.isInstanceOfContrapartida(ho.getContrapartida())){
				return 0;
			}

			if (ho.getProductoCatalogo()!=null && ho.getProductoCatalogo().getModelpro()!=null 
					&& "DED".equalsIgnoreCase(ho.getProductoCatalogo().getModelpro().getModelpro())){
			return 0;	
			}
			
			if (
				(ho.getContrapartida2()!=null && 
						(  "CAM-MIG".equals(ho.getContrapartida2().getId()) || "BMN-MIG".equals(ho.getContrapartida2().getId()) 
						|| "LBI-MIG".equals(ho.getContrapartida2().getId()) || "BCG-MIG".equals(ho.getContrapartida2().getId())		
						) ) ||
				(ho.getContrapartida()!=null && "CAAMES2AXXX".equals(ho.getContrapartida().getId()))
				){
				return 0;
			}

			Contrapartida contrapartida = contrapartidaUtil.castAsContrapartida(ho.getContrapartida());
			if (contrapartida != null && !"FDI".equalsIgnoreCase(contrapartida.getId())) {
				if (contrapartida.getTipoContrapartida()!=null && "C".equalsIgnoreCase(contrapartida.getTipoContrapartida().getId())) {
					Integer error = this.boletasBo.CMOFNoFirmadoAnexo(contrapartida, ho.getEntidad()); 
					if (error ==2 && !"E".equalsIgnoreCase(contrapartida.getTipoPersona())){
						return 0;
					}
					return error;
				}

			}
		} catch (Exception e) {
			return 0;
		}
		return 0;
	}

	public boolean esContrapaCliente(HistoricoOperacion historicoOperacion){
		 
		if (historicoOperacion.getContrapartida()!=null && 
		!"FDI".equalsIgnoreCase(historicoOperacion.getContrapartida().getId()) && 
		!"MODELO".equalsIgnoreCase(historicoOperacion.getContrapartida().getId()) &&
		(historicoOperacion.getGrupoContable()==null || (historicoOperacion.getGrupoContable()!=null &&
				!"XX".equalsIgnoreCase(historicoOperacion.getGrupoContable().getId().getGrupoContable())) )
		&& ( historicoOperacion.getCodigoCobertura() ==null ||
			( historicoOperacion.getCodigoCobertura() !=null &&  !"IN".equalsIgnoreCase(historicoOperacion.getCodigoCobertura().getCodigo()))) 
		) {
	
				
			if (historicoOperacion.getContrapartida() instanceof Contrapartida) {
				Contrapartida contrapartida = (Contrapartida) historicoOperacion.getContrapartida();
			
				if ("CLIENTES".equals(contrapartida.getGrupoBancario().getId())) {
						if (!checkOperacionCAM(historicoOperacion)){
							return true;	
						}
				}
			}
		}
		
		return false;
	}
	
	private boolean checkOperacionCAM(HistoricoOperacion historicoOperacion) {
		
		if (historicoOperacion.getContrapartida2()!=null && 
				(		"CAM-IN".equals(historicoOperacion.getContrapartida2().getId()) ||
						"CAM-PV".equals(historicoOperacion.getContrapartida2().getId()) ||
						"CAM-MIG".equals(historicoOperacion.getContrapartida2().getId()) ||
						"BMN-IN".equals(historicoOperacion.getContrapartida2().getId()) ||
						"BMN-PV".equals(historicoOperacion.getContrapartida2().getId()) ||
						"BMN-MIG".equals(historicoOperacion.getContrapartida2().getId()) ||
						"LBI-IN".equals(historicoOperacion.getContrapartida2().getId()) ||
						"LBI-PV".equals(historicoOperacion.getContrapartida2().getId()) ||
						"LBI-MIG".equals(historicoOperacion.getContrapartida2().getId()) ||
						"BCG-IN".equals(historicoOperacion.getContrapartida2().getId()) ||
						"BCG-PV".equals(historicoOperacion.getContrapartida2().getId()) ||
						"BCG-MIG".equals(historicoOperacion.getContrapartida2().getId()) 
				)
			){
			return true;	
		}
		
		return false;	
		
	}
	
	
	
	/*************************************************************************************************/
	/****************************************** EVENTS *************************************************/
	/*************************************************************************************************/
	public void onProductoCatalogoChange() {
		if(!GenericUtils.isNullOrBlank(productoOperacionList)){
			productoOperacionList=null;	
		}
		if(!GenericUtils.isNullOrBlank(transaccionesList)){
			transaccionesList=null;	
		}
		if(!GenericUtils.isNullOrBlank(descripcionFormulaList)){
			descripcionFormulaList=null;	
		}
	}

	public void onProcedenciaProductoChange() {
		if(!GenericUtils.isNullOrBlank(productoCatalogoList)){
			productoCatalogoList=null;	
		}
		
		onProductoCatalogoChange();
	}

	public void onModeloProductoChange() {
		if(!GenericUtils.isNullOrBlank(productoCatalogoList)){
			productoCatalogoList=null;	
		}
		
		onProductoCatalogoChange();
	}

	/*************************************************************************************************/
	/************************************ GETTERS Y SETTERS ********************************************/
	/*************************************************************************************************/
	public MantOperBo getMantOperBo() {
		return mantOperBo;
	}

	public void setMantOperBo(MantOperBo mantOperBo) {
		this.mantOperBo = mantOperBo;
	}

	public BoletasBo getBoletasBo() {
		return boletasBo;
	}

	public void setBoletasBo(BoletasBo boletasBo) {
		this.boletasBo = boletasBo;
	}

	public CancelacionBo getCancelacionBo() {
		return cancelacionBo;
	}

	public void setCancelacionBo(CancelacionBo cancelacionBo) {
		this.cancelacionBo = cancelacionBo;
	}

	public HistoricoOperacion getHistoricoOperacion() {
		return historicoOperacion;
	}

	public void setHistoricoOperacion(HistoricoOperacion historicoOperacion) {
		this.historicoOperacion = historicoOperacion;
	}

	public BoletasStates getBoletaState() {
		return boletaState;
	}

	public void setBoletaState(BoletasStates boletaState) {
		this.boletaState = boletaState;
	}

	public ParametrosMantoper getParametrosMantoper() {
		return parametrosMantOper;
	}

	public void setParametrosMantoper(ParametrosMantoper parametrosMantoper) {
		this.parametrosMantOper = parametrosMantoper;
	}

	public String getModifCanc() {
		return modifCanc;
	}

	public void setModifCanc(String modifCanc) {
		this.modifCanc = modifCanc;
	}

	public ProcedenciaProducto getProcedencia() {
		return procedencia;
	}

	public void setProcedencia(ProcedenciaProducto procedencia) {
		this.procedencia = procedencia;
	}

	public ModeloProducto getModelo() {
		return modelo;
	}

	public void setModelo(ModeloProducto modelo) {
		this.modelo = modelo;
	}

	public ProductoCatalogo getProductoCatalogo() {
		return productoCatalogo;
	}

	public void setProductoCatalogo(ProductoCatalogo productoCatalogo) {
		this.productoCatalogo = productoCatalogo;
	}

	public Producto getProductoOperacion() {
		return productoOperacion;
	}

	public void setProductoOperacion(Producto productoOperacion) {
		this.productoOperacion = productoOperacion;
	}

	public DescripcionTransaccionOperacion getTransaccionOperacion() {
		return transaccionOperacion;
	}

	public void setTransaccionOperacion(DescripcionTransaccionOperacion transaccionOperacion) {
		this.transaccionOperacion = transaccionOperacion;
	}

	public Divisa getDivisaPago() {
		return divisaPago;
	}

	public void setDivisaPago(Divisa divisaPago) {
		this.divisaPago = divisaPago;
	}

	public Divisa getDivisaCobro() {
		return divisaCobro;
	}

	public void setDivisaCobro(Divisa divisaCobro) {
		this.divisaCobro = divisaCobro;
	}

	public HashSet<VistaOperacion> getListasSeleccionadas() {
		return listasSeleccionadas;
	}

	public void setListasSeleccionadas(HashSet<VistaOperacion> listasSeleccionadas) {
		this.listasSeleccionadas = listasSeleccionadas;
	}

	public List<VistaOperacion> getListaOperacionesList() {
		return listaOperacionesList;
	}

	public void setListaOperacionesList(List<VistaOperacion> listaOperacionesList) {
		this.listaOperacionesList = listaOperacionesList;
	}

	public VistaOperacion getVistaOperacionSelected() {
		return vistaOperacionSelected;
	}

	public void setVistaOperacionSelected(VistaOperacion vistaOperacionSelected) {
		this.vistaOperacionSelected = vistaOperacionSelected;
	}

	public NivelOperacion getNivelOperacion() {
		return nivelOperacion;
	}

	public void setNivelOperacion(NivelOperacion nivelOperacion) {
		this.nivelOperacion = nivelOperacion;
	}

	public String getContrapartida() {
		return contrapartida;
	}

	public void setContrapartida(String contrapartida) {
		this.contrapartida = contrapartida;
	}

	public TipoContrapartida getTipoContrapa() {
		return tipoContrapa;
	}

	public void setTipoContrapa(TipoContrapartida tipoContrapa) {
		this.tipoContrapa = tipoContrapa;
	}

	public String getSuReferencia() {
		return suReferencia;
	}

	public void setSuReferencia(String suReferencia) {
		this.suReferencia = suReferencia;
	}

	public BusquedaOperacion getSituacion() {
		return situacion;
	}

	public void setSituacion(BusquedaOperacion situacion) {
		this.situacion = situacion;
	}

	public DescripcionFormula getFormula() {
		return formula;
	}

	public void setFormula(DescripcionFormula formula) {
		this.formula = formula;
	}

	public String getModoConfirmacion() {
		return modoConfirmacion;
	}

	public void setModoConfirmacion(String modoConfirmacion) {
		this.modoConfirmacion = modoConfirmacion;
	}

	@Type(type = "SNNull")
	public Boolean getCobertura() {
		return cobertura;
	}

	public void setCobertura(Boolean cobertura) {
		this.cobertura = cobertura;
	}

	@Type(type = "SNNull")
	public Boolean getPendienteConf() {
		return pendienteConf;
	}

	public void setPendienteConf(Boolean pendienteConf) {
		this.pendienteConf = pendienteConf;
	}

	@Type(type = "SNNull")
	public Boolean getEstructura() {
		return estructura;
	}

	public void setEstructura(Boolean estructura) {
		this.estructura = estructura;
	}

	@Type(type = "SNNull")
	public Boolean getCampana() {
		return campana;
	}

	public void setCampana(Boolean campana) {
		this.campana = campana;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}

	public GenericRange<Long> getNumOper() {
		return numOper;
	}

	public void setNumOper(GenericRange<Long> numOper) {
		this.numOper = numOper;
	}

	public GenericRange<Date> getFechaVal() {
		return fechaVal;
	}

	public void setFechaVal(GenericRange<Date> fechaVal) {
		this.fechaVal = fechaVal;
	}

	public GenericRange<Date> getFechaVen() {
		return fechaVen;
	}

	public void setFechaVen(GenericRange<Date> fechaVen) {
		this.fechaVen = fechaVen;
	}

	public GenericRange<Date> getFechaOpe() {
		return fechaOpe;
	}

	public void setFechaOpe(GenericRange<Date> fechaOpe) {
		this.fechaOpe = fechaOpe;
	}

	public GenericRange<Long> getNumEstructu() {
		return numEstructu;
	}

	public void setNumEstructu(GenericRange<Long> numEstructu) {
		this.numEstructu = numEstructu;
	}

	public GenericRange<Long> getClExterna() {
		return clExterna;
	}

	public void setClExterna(GenericRange<Long> clExterna) {
		this.clExterna = clExterna;
	}

	public GenericRange<String> getClBduGid() {
		return clBduGid;
	}

	public void setClBduGid(GenericRange<String> clBduGid) {
		this.clBduGid = clBduGid;
	}

	public GenericRange<Date> getFechaCan() {
		return fechaCan;
	}

	public void setFechaCan(GenericRange<Date> fechaCan) {
		this.fechaCan = fechaCan;
	}

	public MsgBoxAction getMsgBoxAction() {
		return msgBoxAction;
	}

	public void setMsgBoxAction(MsgBoxAction msgBoxAction) {
		this.msgBoxAction = msgBoxAction;
	}

	public DbLockService getDbLockService() {
		return dbLockService;
	}

	public void setDbLockService(DbLockService dbLockService) {
		this.dbLockService = dbLockService;
	}

	public String getMsgBoxHeaderListaErrores() {
		return msgBoxHeaderListaErrores;
	}

	public void setMsgBoxHeaderListaErrores(String msgBoxHeaderListaErrores) {
		this.msgBoxHeaderListaErrores = msgBoxHeaderListaErrores;
	}

	public void setListaErrores(List<ErrorMessage> listaErrores) {
		this.listaErrores = listaErrores;
	}

	public String getMsgBoxNoProcessable() {
		return msgBoxNoProcessable;
	}

	public void setMsgBoxNoProcessable(String msgBoxNoProcessable) {
		this.msgBoxNoProcessable = msgBoxNoProcessable;
	}

	public boolean isMsgBoxFinalStep() {
		return msgBoxFinalStep;
	}

	public void setMsgBoxFinalStep(boolean msgBoxFinalStep) {
		this.msgBoxFinalStep = msgBoxFinalStep;
	}

	public String getMsgBoxWidth() {
		return msgBoxWidth;
	}

	public void setMsgBoxWidth(String msgBoxWidth) {
		this.msgBoxWidth = msgBoxWidth;
	}

	public boolean isMsgBoxMessageMode() {
		return msgBoxMessageMode;
	}

	public void setMsgBoxMessageMode(boolean msgBoxMessageMode) {
		this.msgBoxMessageMode = msgBoxMessageMode;
	}

	public List<ModeloProducto> getModeloProductoList() {
		return modeloProductoList;
	}

	public void setModeloProductoList(List<ModeloProducto> modeloProductoList) {
		this.modeloProductoList = modeloProductoList;
	}

	public List<ProductoCatalogo> getProductoCatalogoList() {
		return productoCatalogoList;
	}

	public void setProductoCatalogoList(List<ProductoCatalogo> productoCatalogoList) {
		this.productoCatalogoList = productoCatalogoList;
	}

	public int getMaxSelected() {
		return maxSelected;
	}

	public void setMaxSelected(int maxSelected) {
		this.maxSelected = maxSelected;
	}

	@Override
	public boolean isLastExists() {
		return true;
	}
	
	public void last(){
		if ( GenericUtils.isNullOrBlank(ultimRegistre) || ultimRegistre == 0 ){
			ultimRegistre = prepareOperacionesListCount();
		}
		goLast(ultimRegistre);
	}

	public Integer getUltimRegistre() {
		return ultimRegistre;
	}

	public void setUltimRegistre(Integer ultimRegistre) {
		this.ultimRegistre = ultimRegistre;
	}
	

	// montar String Evento para TOQUE de barrera
//	public String montarStringEvento(HistoricoOperacion historicoOperacion2, Date fechamis, HistoricoBarreraReturn barrera, MantoqeGlobal mantoq) {
//		
//		String tipoOperacion = mantoq.getTipoOperacion()!=null?mantoq.getTipoOperacion():mantoq.getTipoPera();		
//		
//		String signo;
//		if (barrera.getPata()==null){
//			signo = Constantes.MANTOQE_SIGNO_MAS;
//		}else if (barrera.getPata().equals(Constantes.MANTOQE_PATA_P)) {
//			signo = Constantes.MANTOQE_SIGNO_MENOS;
//		} else {
//			signo = Constantes.MANTOQE_SIGNO_MAS;
//		}
//
//		SimpleDateFormat sdf1 = new SimpleDateFormat(Constantes.YYYYMMDD);
//	
//		Date d1 = null;
//		Date d2 = null;
//		
//		d1 = barrera.getFeciniba();
//		d2 = barrera.getFecfinba();
//
//		String s1 = sdf1.format(d1);
//		String s2 = sdf1.format(d2);
//		StringBuilder sb = new StringBuilder();
//
//		sb.append(tipoOperacion);
//		sb.append(" ");
//		sb.append(s1);
//		sb.append(" ");
//		sb.append(s2);
//		sb.append(" ");
//		sb.append(Constantes.MANTOQE_INT+" ");
//		sb.append(Constantes.MANTOQE_OPC+" ");
//		sb.append(GenericUtils.to_char(fechamis,Constantes.YYYYMMDD));
//		sb.append(" ");
//		sb.append(GenericUtils.lpad(mantoqeGlobal.getCodigoFormulario(), 5, "0"));
//		sb.append(" ");
//		sb.append(barrera.getTipBarP1()); // tipo barrera
//		sb.append(" ");
//		
//		BigDecimal formatoDecimal =new BigDecimal("1000000000000");//12 decimales
//				
//		BigDecimal nivelBarrera = barrera.getNivebarr();
//		BigDecimal nvlNivelBarrera = (BigDecimal) GenericUtils.nvl(nivelBarrera, new BigDecimal("0"));
//		Number numberNvlNivelBarrera = nvlNivelBarrera.multiply(formatoDecimal);
//		String toCharNumberNvlNivelBarrera = GenericUtils.to_char(numberNvlNivelBarrera);
//		String replacedToCharNumberNvlNivelBarrera = GenericUtils.lpad(GenericUtils.replace(toCharNumberNvlNivelBarrera, ".", ""),17,"0");
//		sb.append(replacedToCharNumberNvlNivelBarrera);
//		sb.append(" ");
//		
//		sb.append(historicoOperacion.getProducto().getId()); // producto
//		sb.append(" ");
//
//		
//		BigDecimal pantallaPrecio = mantoqePantalla.getVistaMantoqe().getPrecio();
//		Number nvlPantallaPrecio = (Number)(GenericUtils.nvl(pantallaPrecio, new BigDecimal(0))).multiply(formatoDecimal);
//		String toCharNumberNvlPantallaPrecio = GenericUtils.to_char(nvlPantallaPrecio);
//		String replacedToCharNumberNvlPantallaPrecio = GenericUtils.lpad(GenericUtils.replace(toCharNumberNvlPantallaPrecio, ".", ""),17,"0");
//		sb.append(replacedToCharNumberNvlPantallaPrecio);
//		sb.append(" ");
//		BigDecimal importeRebate = mantoqePantalla.getVistaMantoqe().getHistoricoBarrera().getImprebat();
//		Number nvlImporteRebate = (Number) ((BigDecimal)GenericUtils.nvl(importeRebate, new BigDecimal(0))).multiply(new BigDecimal(10000));//forzamos 4 decimales
//		String toCharNumberNvlImporteRebate = GenericUtils.to_char(nvlImporteRebate);
//		String replacedToCharNumberNvlImporteRebate = GenericUtils.lpad(GenericUtils.replace(toCharNumberNvlImporteRebate, ".", ""),17,"0");
//		sb.append(replacedToCharNumberNvlImporteRebate);
//		sb.append(" ");
//		sb.append(signo + " ");
//		String pantallaDivisa = mantoqePantalla.getVistaMantoqe().getMantoqeReturn().getDivisano();
//		String nvlPantallaDivisa = (String) GenericUtils.nvl(pantallaDivisa, "");
//		String rpadNvlPantallaDivisa = GenericUtils.rpad(nvlPantallaDivisa, 3, " ");
//		sb.append(rpadNvlPantallaDivisa);
//		sb.append(" ");
//		Date pantallaFechaRebate = mantoqePantalla.getVistaMantoqe().getHistoricoBarreraReturn().getFechaRebat();
//		String toCharPantallaFechaRebate = null;
//		if (pantallaFechaRebate !=null){
//			toCharPantallaFechaRebate = GenericUtils.to_char(pantallaFechaRebate);
//		}
//		String nvlToCharPantallaFechaRebate = (String) GenericUtils.nvl(toCharPantallaFechaRebate, "00000000");
//		sb.append(nvlToCharPantallaFechaRebate + " ");
//		String pantallaObservaciones = mantoqePantalla.getVistaMantoqe().getHistoricoBarreraReturn().getObservac();
//		String nvlPantallaObservaciones = (String) GenericUtils.nvl(pantallaObservaciones, "");
//		String rpadNvlPantallaObservaciones = GenericUtils.rpad(nvlPantallaObservaciones, 200, " ");
//		sb.append(rpadNvlPantallaObservaciones + " ");
//		if (barrera.getOrdenBarr() == 0){
//			sb.append("001");
//		}else {
//			sb.append(GenericUtils.lpad(Integer.toString(barrera.getOrdenBarr()),3,"0"));	
//		}
//		sb.append(GenericUtils.rpad("", 57, " "));
//		
//		return sb.toString();
//
//	}	
	
    public void onVerificarContrapartidaBloqueada() {
    	Contrapartida contrapObtenida2;
		if (!GenericUtils.isNullOrBlank(contrapartida)){
			contrapObtenida2 = mantOperBo.cargarContrapartida(contrapartida.toUpperCase());	
			if (null!=contrapObtenida2 && !GenericUtils.isNullOrBlank(contrapObtenida2.getIndBloqueo()) && "S".equalsIgnoreCase(contrapObtenida2.getIndBloqueo())){
				messageBoxActionMO.init("mantOper.messages.contrapartida.bloqueada.texto", "mantOperacionesAction.voidFunction()",
						null,"messageBoxPanelContrapa");
			}
		}
    }

    public String getRowClasses(){
    	StringBuilder builder = new StringBuilder();
    	int i=0;
    	
    	Contrapartida contrapartidaObtenida = null;
    	//Boolean lastRed = false;
    	for(VistaOperacion operacionActual : listaOperacionesList){
    		if(i>0){
				builder.append(",");
			}
    		
    		if(null!=operacionActual.getHistOper() && null!=operacionActual.getHistOper().getContrapartida()){
    			if(operacionActual.getHistOper().getContrapartida() instanceof Contrapartida){
    				contrapartidaObtenida = (Contrapartida) operacionActual.getHistOper().getContrapartida();
    			}
    		}
    		
    		//Si la contrapartida está bloqueada pintamos el registro de la tabla rojo.
    		/*if (null!=contrapartidaObtenida && !GenericUtils.isNullOrBlank(contrapartidaObtenida.getIndBloqueo()) && "S".equalsIgnoreCase(contrapartidaObtenida.getIndBloqueo())){
    			//Cambiamos el tipo de rojo para no tener 2 registros seguidos con el mismo rojo.
    			if(lastRed){
    				builder.append("redRowSoft");
    				//builder.append("rich-calendar-today");
    				lastRed = false;
    			}
    			else{
    				//Se cambia el color para mostrar el texto rojo cuando la contrapartida está bloqueada.
    				//Si se quiere alternar el color en varias contrapartidas bloqueadas seguidas, ajustar el color del ELSE por otro
    				//builder.append("rich-calendar-today");
    				builder.append("redRowSoft");
    				lastRed = true;
    			}
			}
    		else*/
    		{
    			if(i%2==0){
    				if(null!=contrapartidaObtenida && !GenericUtils.isNullOrBlank(contrapartidaObtenida.getIndBloqueo()) && "S".equalsIgnoreCase(contrapartidaObtenida.getIndBloqueo())){
    					builder.append("oddRowRed");
    				}
    				else{
    					builder.append("oddRow");
    				}
    			}
    			else{
    				if(null!=contrapartidaObtenida && !GenericUtils.isNullOrBlank(contrapartidaObtenida.getIndBloqueo()) && "S".equalsIgnoreCase(contrapartidaObtenida.getIndBloqueo())){
    					builder.append("evenRowRed");
    				}
    				else{
    					builder.append("evenRow");
    				}
    			}
    			//lastRed = false;
    		}
    		i++;
    		contrapartidaObtenida = null;
    	}

    	return builder.toString();
    }
	

	
}
	