package com.atosorigin.deri.adminoper.mantOperaciones.action;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.jboss.seam.ScopeType;
import org.jboss.seam.annotations.Factory;
import org.jboss.seam.annotations.In;
import org.jboss.seam.annotations.Name;
import org.jboss.seam.annotations.Out;
import org.jboss.seam.annotations.Scope;
import org.jboss.seam.core.Conversation;
import org.jboss.seam.core.ResourceBundle;
import org.jboss.seam.international.StatusMessage;
import org.jboss.seam.international.StatusMessage.Severity;
import org.jboss.seam.security.Credentials;
import org.jboss.seam.security.Identity;

import com.atosorigin.common.action.GenericAction;
import com.atosorigin.common.constantes.Constantes;
import com.atosorigin.common.formvalidator.FormValidator;
import com.atosorigin.common.utils.GenericUtils;
import com.atosorigin.deri.adminoper.boletas.action.BoletasAction.BoletasStates;
import com.atosorigin.deri.adminoper.boletas.business.BoletasBusinessException;
import com.atosorigin.deri.adminoper.mantOperaciones.screen.PrimasPantalla;
import com.atosorigin.deri.adminoper.mantoper.business.PrimasBo;
import com.atosorigin.deri.common.dbLock.DbLockService;
import com.atosorigin.deri.model.adminoper.DescripcionTipoOperacionHistderi;
import com.atosorigin.deri.model.gestionoperaciones.DescripcionEstadoOperacion;
import com.atosorigin.deri.model.gestionoperaciones.HistoricoOperacion;
import com.atosorigin.deri.model.gestionoperaciones.HistoricoOperacionId;
import com.atosorigin.deri.model.mercado.HistoricoTramos;
import com.atosorigin.deri.model.mercado.HistoricoTramosId;
import com.atosorigin.deri.model.murex.ModeloProducto;
import com.atosorigin.deri.model.parametrizacion.Divisa;
import com.atosorigin.deri.util.FormatUtil;

@Name("primasAction")
@Scope(ScopeType.CONVERSATION)
@FormValidator
public class PrimasAction extends GenericAction {

    @In Credentials credentials;
	
//	@In(required=false)
//	private VistaOperacion vistaOperacionSelected;
	
	@In("#{primasBo}")
	private PrimasBo primasBo;
	
	
	@In("#{primasPantalla}")
	private PrimasPantalla primasPantalla;
	
	
	@In(required=false)
	private String modifCanc;
	
	@In
	private FormatUtil formatUtil;
	
	@In
	@Out
	private HistoricoOperacion historicoOperacion;
	
	@In
	private HistoricoOperacionId historicoOperacionBloqueadoId;
	
	/** Inyección del servicio que gestiona los bloqueos de registros en base de datos */
	@In(create = true)
	protected DbLockService dbLockService;
	
	@Out(required=false)
	private BoletasStates boletaState;
	
	@Out
	private Date fechamis = new Date();

	@Out(required = false, value = "listaDivisasPrimas")
	List<Divisa> divisasList = null;

	
	/** Inyección del objeto para la union con MANTPROD  */
	@In(required=false)
	@Out(required= false)
	String varModif;
	
	// Globales
	private String tppapago;
	private String tppareci;
	
	private Date fechaModificacion = null;
	
	private Boolean filaBloqueada = false;
	// Mensajes por pantalla
	private boolean mostrarMensaje = false;
	private StringBuilder mensajeConfirmacion = new StringBuilder();
	private boolean respuesta = false;
	private String accion = "validar";
	private boolean primeraVez = true;
	
	public void init(){
		if (primeraVez){
			operacionAPantalla();
			primasPantalla.setClase("PRI");
//			if (historicoOperacion.getFechaValorPrimaImplicita()==null){
////				historicoOperacion.setFechaValorPrimaImplicita(historicoOperacion.getFechaValor());
//				primasPantalla.setFechaValorPrimaImplicita(historicoOperacion.getFechaValor());
//			}else{
//				primasPantalla.setFechaValorPrimaImplicita(historicoOperacion.getFechaValorPrimaImplicita());
//			}

			primeraVez = false;
		}
	}
	
	private Date obtenerFechamis() {
		return primasBo.obtenerFechamis();
	}

	public boolean aceptarValidator(){
		boolean esCorrecto = true;
		cjtoCamposError.clear();

		return esCorrecto;
	}

	public void aceptar() {
		// COMPROBAR OPERACION PDTE. AGENDA
		if(operacionPdtAgenda() == 0 && "N".equals(modifCanc)) { //false
			statusMessages.add(StatusMessage.Severity.INFO, "#{messages['mantOper.cancelacion.error.operacionPendienteProcesar']}",
					historicoOperacion.getId().getNumeroOperacion(),historicoOperacion.getFechaValor(),
					historicoOperacion.getFechaVencimiento());
		} else {
			// COMPROBAR LIQUIDACIONES
			comprobarLiquidaciones();	
		}
	}
	
	public void continuarAceptar() {
		// Venimos de preguntarle al usuario si continuaba o no
		resetMensajes();
		// COMPROBAR FEULTACT ÚLTIMO REGISTRO
		Date feultact = primasBo.obtenerMaxFeultact(historicoOperacion.getId().getNumeroOperacion(),historicoOperacion.getId().getFechaContratacion());
		if(feultact.compareTo(historicoOperacion.getId().getFechaModificacion()) != 0) {
			// DESBLOQUEAR

			if(historicoOperacionBloqueadoId!=null){
				dbLockService.desbloqueo(HistoricoOperacion.class, historicoOperacionBloqueadoId);
			}else{
				dbLockService.desbloqueo(HistoricoOperacion.class, historicoOperacion.getId());	
			}
			
			statusMessages.add(StatusMessage.Severity.ERROR, "#{messages['mantOper.cancelacion.error.operacion.bloqueada']}",
					historicoOperacion.getId().getNumeroOperacion(),historicoOperacion.getId().getFechaContratacion());
		} else {
			// BLOQUEAR
		}
	}
	
	public String comitarAceptar(boolean bol) {
		if(bol) {
			// TODO: se hará la actualizacion de la agenda y el COMMIT
			// PKG_MANTOPER.P_INSERT_CANCEL_AGENDOTC(V_SYSDATE);

			
				
			try{
				salirNcorrela("C");
				primasBo.grabarEventosBoleta(historicoOperacion, "M", Identity.instance().getCredentials().getUsername());
			}catch (BoletasBusinessException e) {
				statusMessages.add(Severity.ERROR, "#{messages['boletas.edicion.error.grabar.eventos']");
				salirNcorrela("R");
			}
			
			varModif = Constantes.CONSTANTE_SI;
			if(historicoOperacionBloqueadoId!=null){
				dbLockService.desbloqueo(HistoricoOperacion.class, historicoOperacionBloqueadoId);
			}else{
				dbLockService.desbloqueo(HistoricoOperacion.class, historicoOperacion.getId());	
			}
						
			return Constantes.CONSTANTE_SUCCESS;
		} else {
			varModif = Constantes.CONSTANTE_NO;
			salirNcorrela("R");
			// rollback
			return null;
		}
	}
	
	private void persistir() {
		
		
	}

	public void salir() {
		salirNcorrela("R");
//		resetMensajes();
//		dbLockService.desbloqueo(HistoricoOperacion.class, historicoOperacion.getId());
		varModif = Constantes.CONSTANTE_NO;
		Conversation conv = Conversation.instance();
		if(conv != null && conv.isNested()){
			conv.redirectToParent();
		}
		
//		salirNcorrela("R");
	}
	
	private void salirNcorrela(String accion) {
//		primasBo.salirNcorrela(accion,historicoOperacion,credentials.getUsername());

		if (getFechaModificacion()!=null){
			primasBo.salirNcorrelaFeUltAct(accion,historicoOperacion, credentials.getUsername(),getFechaModificacion());	
		}else{
			primasBo.salirNcorrela(accion,historicoOperacion,credentials.getUsername());	
		}
		resetMensajes();
		if(historicoOperacionBloqueadoId!=null){
			dbLockService.desbloqueo(HistoricoOperacion.class, historicoOperacionBloqueadoId);
		}else{
			dbLockService.desbloqueo(HistoricoOperacion.class, historicoOperacion.getId());	
		}
		primeraVez = true;
	}
	
	private int operacionPdtAgenda() {
		return primasBo.operacionPdtAgenda(historicoOperacion);
	}
	
	private void comprobarLiquidaciones() {
		resetMensajes();
		int count = primasBo.cuantasLiquidaciones(historicoOperacion.getId().getNumeroOperacion(), "VA");
		if(count > 0 && ( historicoOperacion.getProductoCompuesto() == null || historicoOperacion.getProductoCompuesto().getEstructu() == 0)) { 
			// mostrar Mensaje pregunta('La operación tiene liquidaciones validadas. ¿Desea continuar?')
			accion = "cancelar";
			mostrarMensaje = true;
			mensajeConfirmacion.append(ResourceBundle.instance().getString("mantOper.cancelacion.error.liquidaciones"));
		} else {
			continuarAceptar();
		}
	}
	
	

	private void resetMensajes() {
		mostrarMensaje = false;
		mensajeConfirmacion = new StringBuilder();
		respuesta = false;
		accion = "";
		fechaModificacion = null;
	}


	public Boolean getFilaBloqueada() {
		return filaBloqueada;
	}

	public boolean isRespuesta() {
		return respuesta;
	}

	public void setRespuesta(boolean respuesta) {
		mostrarMensaje = false;
		this.respuesta = respuesta;
	}

	public StringBuilder getMensajeConfirmacion() {
		return mensajeConfirmacion;
	}

	public void setMensajeConfirmacion(StringBuilder mensajeConfirmacion) {
		this.mensajeConfirmacion = mensajeConfirmacion;
	}

	public boolean isMostrarMensaje() {
		return mostrarMensaje;
	}

	public void setMostrarMensaje(boolean mostrarMensaje) {
		this.mostrarMensaje = mostrarMensaje;
	}

	public String getAccion() {
		return accion;
	}

	public void setAccion(String accion) {
		this.accion = accion;
	}

	public Date getFechaModificacion() {
		return fechaModificacion;
	}

	public void setFechaModificacion(Date fechaModificacion) {
		this.fechaModificacion = fechaModificacion;
	}

	public boolean guardarValidator(){
		boolean ret = true;
//		
//			S’hauria de predefinir els següents conceptes per tal d’evitar errors:
//			o	Tomado (COMD)  Ampliació Nominal  COBRO
//			o	Tomado  Amortització Nominal  PAGO
//			o	Prestado  Ampliació Nominal PAGO
//			o	Prestado  Amortització Nominal  COBRO

		
		if ("RTO".equals(primasPantalla.getClase()) && "P".equalsIgnoreCase(primasPantalla.getTipoPrimaImplicita()) ){
			statusMessages.add(Severity.ERROR, "#{messages['mantOper.messages.modificar.primasRTO']}");
			ret = false;
			return ret;	
		}
		
		if ("COMD".equalsIgnoreCase(historicoOperacion.getTransaccion().getCodigo())){
			if ( ("AMO".equals(primasPantalla.getClase()) && "R".equalsIgnoreCase(primasPantalla.getTipoPrimaImplicita()))
			||	 ("AMP".equals(primasPantalla.getClase()) && "P".equalsIgnoreCase(primasPantalla.getTipoPrimaImplicita()))
				){
				statusMessages.add(Severity.ERROR, "#{messages['mantOper.messages.modificar.primasTRAN']}");
				ret = false;
				return ret;	
			}
		}else{
			if ( ("AMO".equals(primasPantalla.getClase()) && "P".equalsIgnoreCase(primasPantalla.getTipoPrimaImplicita()))
			||	 ("AMP".equals(primasPantalla.getClase()) && "R".equalsIgnoreCase(primasPantalla.getTipoPrimaImplicita()))
						){
						statusMessages.add(Severity.ERROR, "#{messages['mantOper.messages.modificar.primasTRAN']}");
						ret = false;
						return ret;	
					}
		}
		
		return ret;
	}
	
	public void guardar(){
//		historicoOperacion.setFechaValorPrimaImplicita(historicoOperacion.getFechaValor());
		
//		, en el caso de Amortizaciones y Ampliaciones, modificará los tramos futuros del calendario 
//		aumentando o disminuyendo el Nominal vivo de la operación con el importe introducido.
//		

		DescripcionEstadoOperacion estado = primasBo.getEstado("PV");
		historicoOperacion.setEstado(estado);

		
		if ("IMP".equals(primasPantalla.getClase()) || "RTO".equals(primasPantalla.getClase()) || "DIV".equals(primasPantalla.getClase())){

			if ("IMP".equals(primasPantalla.getClase())){
			pantallaAOperacion();	
			}
			generarTramo("PRI",primasPantalla.getClase());
			primasBo.persistir(historicoOperacion);
			comitarAceptar(true);
			
			Conversation conv = Conversation.instance();
			if(conv != null && conv.isNested()){
				conv.redirectToParent();
			}

		}else if ("AMO".equals(primasPantalla.getClase())){

			generarTramo("AMO","AMO");
			StringBuffer errorCode = new StringBuffer();
			
			//17/01/2014. Quitar la llamada al package de modificar calendario para productos dédalo
			if (!historicoOperacion.getProducto().getIndDerivado().equals("D") && !primasBo.callModificarCalendario(historicoOperacion,primasPantalla.getClase(), primasPantalla.getTipoPrimaImplicita(),
					primasPantalla.getImportePrimaImplicita(), primasPantalla.getDivisaPrimaImplicita(),
					primasPantalla.getFechaValorPrimaImplicita(),Identity.instance().getCredentials().getUsername(), errorCode)){
				if (!GenericUtils.isNullOrBlank(errorCode)){
					statusMessages.addFromResourceBundle(Severity.ERROR, "mantOper.messages.modificar.calendarioPrimas", errorCode.toString());	
				}else{
					statusMessages.add(Severity.ERROR, "#{messages['mantOper.messages.modificar.calendarioPrimas']}");
				}
//				comitarAceptar(false);
			}else{
				comitarAceptar(true);
				
				Conversation conv = Conversation.instance();
				if(conv != null && conv.isNested()){
					conv.redirectToParent();
				}

			}
			
		}else if ("AMP".equals(primasPantalla.getClase())){

			generarTramo("AMP","AMP");
			StringBuffer errorCode = new StringBuffer();
			//17/01/2014. Quitar la llamada al package de modificar calendario para productos dédalo
			if (!historicoOperacion.getProducto().getIndDerivado().equals("D") && !primasBo.callModificarCalendario(historicoOperacion,primasPantalla.getClase(), primasPantalla.getTipoPrimaImplicita(),
					primasPantalla.getImportePrimaImplicita(), primasPantalla.getDivisaPrimaImplicita(),
					primasPantalla.getFechaValorPrimaImplicita(),Identity.instance().getCredentials().getUsername(), errorCode)){

				if (!GenericUtils.isNullOrBlank(errorCode)){
					statusMessages.addFromResourceBundle(Severity.ERROR, "mantOper.messages.modificar.calendarioPrimas", errorCode.toString());
				}else{
					statusMessages.add(Severity.ERROR, "#{messages['mantOper.messages.modificar.calendarioPrimas']}");
				}
//				comitarAceptar(false);
			}else{
				comitarAceptar(true);
				
				Conversation conv = Conversation.instance();
				if(conv != null && conv.isNested()){
					conv.redirectToParent();
				}

			}
			
		}
		
	}

	private void generarTramo(String concepto, String tipoConcepto) {
		HistoricoTramos oldTramo = primasBo.caragrPrimaExistente(historicoOperacion);
		
		DescripcionTipoOperacionHistderi tipoOpera = primasBo.getTipoOperacion(primasPantalla.getTipoPrimaImplicita());
		Date fechaFinTramo=null;
//		if ("IMP".equalsIgnoreCase(tipoConcepto)){
		if ("IMP".equalsIgnoreCase(tipoConcepto) || "DIV".equalsIgnoreCase(tipoConcepto)){			
			fechaFinTramo =historicoOperacion.getFechaVencimiento();
		}else{
			fechaFinTramo =primasPantalla.getFechaValorPrimaImplicita();
		}
		HistoricoTramosId id = new HistoricoTramosId(historicoOperacion, tipoOpera, 
				primasPantalla.getFechaValorPrimaImplicita(),fechaFinTramo, concepto, tipoConcepto);
		HistoricoTramos tramo = new HistoricoTramos(id);

		
		if ("IMP".equalsIgnoreCase(tipoConcepto)){
			tramo.setFechaLiquidacion(null);
			tramo.setDivisaLiquidacion(null);
		}else{
			tramo.setFechaLiquidacion(primasPantalla.getFechaValorPrimaImplicita());
			tramo.setDivisaLiquidacion(primasPantalla.getDivisaPrimaImplicita().getId());
		}

		

		
		tramo.setImporteOperacion(primasPantalla.getImportePrimaImplicita());
		tramo.setDivisaTramo(primasPantalla.getDivisaPrimaImplicita());
		
		if ("P".equals(tramo.getId().getTipoOperacion().getCodigo())){
			if (historicoOperacion.getTipoCurvaPago()!= null && historicoOperacion.getTipoCurvaPago().getTipocurv()!=null){
				tramo.setTipoCurvaTramo(historicoOperacion.getTipoCurvaPago().getTipocurv());	
			}else{
				tramo.setTipoCurvaTramo("000");
			}
			
		}else{
			if (historicoOperacion.getTipoCurvaRecibo()!= null && historicoOperacion.getTipoCurvaRecibo().getTipocurv()!=null){
				tramo.setTipoCurvaTramo(historicoOperacion.getTipoCurvaRecibo().getTipocurv());
			}else{
				tramo.setTipoCurvaTramo("000");
			}
		}
		
		tramo.setIndicNulo(null);
		tramo.setIndicadorTramoIrregular("N");	
		tramo.setUltimaOperacionRealizada(historicoOperacion.getUltimaAccion().getCodigo());
		tramo.setProducto(historicoOperacion.getProducto().getId());
		tramo.setTransaccionOper(historicoOperacion.getTransaccion().getCodigo());
		tramo.setCodigoLiquidacion(null);
		tramo.setComplementoCodLiqui(null);
		tramo.setNominalParaCalculo(null);
		tramo.setNominalAmortizado(null);
		tramo.setIndicadorLiquiAmortizacion(null);
		tramo.setDiferenciaDias((short) 0);
		tramo.setBaseDeCalculoDias(null);

		//p_tramo.FECCALIQ := pkg_calendar_utiles.f_AJUSTAR_FECHA_INF (p_tramo.FECINITR, 3, p_tramo.DIVISATR);
		tramo.setFechaCalculoLiquidacion(primasBo.ajustarFechaInf(tramo.getId().getFechaInicioTramo(),3,tramo.getDivisaTramo())); 
		
		tramo.setFechaValorDelTipo(null);
		tramo.setFechaInformarImporte(null);
		tramo.setStrikeCFC(BigDecimal.ZERO);
		tramo.setPorcentajeTipoInteres(BigDecimal.ZERO);
		tramo.setSpreadOperacion(BigDecimal.ZERO);
		tramo.setCodigoFormula(null);
		tramo.setUsuario(credentials.getUsername());
		tramo.setNivelBarrera(BigDecimal.ZERO);
		tramo.setIndicadorTipindiv(primasBo.cargarDescIndifiva("F")); 
		tramo.setEstadoTramo("VA");
	  
		primasBo.persistirTramo(tramo);
		if(oldTramo != null){
			if(!tramo.getId().equals(oldTramo.getId()))
			primasBo.borrarTramo(oldTramo);
		}
	}

	public void pantallaAOperacion(){
		historicoOperacion.setFechaValorPrimaImplicita(primasPantalla.getFechaValorPrimaImplicita());
		historicoOperacion.setDivisaPrimaImplicita(primasPantalla.getDivisaPrimaImplicita());
		historicoOperacion.setImportePrimaImplicita(primasPantalla.getImportePrimaImplicita());
		historicoOperacion.setTipoPrimaImplicita(primasPantalla.getTipoPrimaImplicita());
			
	}
	
	public void onConceptoChange(){
		if ("IMP".equals(primasPantalla.getClase())){
			if (historicoOperacion.getFechaValorPrimaImplicita()==null){
				primasPantalla.setFechaValorPrimaImplicita(historicoOperacion.getFechaValor());
			}else{
				primasPantalla.setFechaValorPrimaImplicita(historicoOperacion.getFechaValorPrimaImplicita());
			}
		}
	}
	
	public void operacionAPantalla(){

//	Solo para el caso de Primas Implicitas, se informará este valor cuando seleccione el tipo de Concepto	
//	primasPantalla.setFechaValorPrimaImplicita(historicoOperacion.getFechaValorPrimaImplicita());

	primasPantalla.setDivisaPrimaImplicita(historicoOperacion.getDivisaPrimaImplicita());
	primasPantalla.setImportePrimaImplicita(historicoOperacion.getImportePrimaImplicita());
	primasPantalla.setTipoPrimaImplicita(historicoOperacion.getTipoPrimaImplicita());
	
	}

	@Factory(value = "listaDivisasPrimas")
	public void initListaDivisas() {
		this.divisasList = new ArrayList<Divisa>();
		
		if (historicoOperacion.getDivisaPago()!=null){
			divisasList.add(historicoOperacion.getDivisaPago());
			if (historicoOperacion.getDivisaRecibo()!=null && 
				!historicoOperacion.getDivisaRecibo().getId().equalsIgnoreCase(historicoOperacion.getDivisaPago().getId())){
				divisasList.add(historicoOperacion.getDivisaRecibo());	
			}
		}else if (historicoOperacion.getDivisaRecibo()!=null){
			divisasList.add(historicoOperacion.getDivisaRecibo());
		}

	}

	public boolean esEquityOption(){
		
		if (!GenericUtils.isNullOrBlank(historicoOperacion) && !GenericUtils.isNullOrBlank(historicoOperacion.getProducto()) 
				&&  "RV".equalsIgnoreCase(historicoOperacion.getProducto().getIndicadorClase2()) ){
			return true;
}
		
		return false;	
	}

}