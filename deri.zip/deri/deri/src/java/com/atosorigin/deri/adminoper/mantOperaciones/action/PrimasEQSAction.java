package com.atosorigin.deri.adminoper.mantOperaciones.action;

import java.math.BigDecimal;
import java.math.BigInteger;
import java.math.RoundingMode;
import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.List;

import javax.persistence.EntityNotFoundException;


import org.jboss.seam.ScopeType;
import org.jboss.seam.annotations.Factory;
import org.jboss.seam.annotations.In;
import org.jboss.seam.annotations.Name;
import org.jboss.seam.annotations.Out;
import org.jboss.seam.annotations.Scope;
import org.jboss.seam.core.Conversation;
import org.jboss.seam.core.ResourceBundle;
import org.jboss.seam.international.StatusMessage;
import org.jboss.seam.international.StatusMessage.Severity;
import org.jboss.seam.security.Credentials;
import org.jboss.seam.security.Identity;
import com.atosorigin.common.action.GenericAction;
import com.atosorigin.common.auditdata.AuditData;
import com.atosorigin.common.constantes.Constantes;
import com.atosorigin.common.formvalidator.FormValidator;
import com.atosorigin.common.utils.GenericUtils;
import com.atosorigin.deri.adminoper.boletas.action.BoletasAction.BoletasStates;
import com.atosorigin.deri.adminoper.boletas.business.BoletasBo;
import com.atosorigin.deri.adminoper.boletas.business.BoletasBusinessException;
import com.atosorigin.deri.adminoper.mantOperaciones.screen.PrimasEQSPantalla;
import com.atosorigin.deri.adminoper.mantoper.business.CancelacionBo;
import com.atosorigin.deri.adminoper.mantoper.business.PrimasBo;
import com.atosorigin.deri.common.dbLock.DbLockService;
import com.atosorigin.deri.model.adminoper.CanalConfDefecto;
import com.atosorigin.deri.model.adminoper.CanalConfDefectoId;
import com.atosorigin.deri.model.adminoper.CanalConfirmacion;
import com.atosorigin.deri.model.adminoper.CancelarOperacionReturn;
import com.atosorigin.deri.model.adminoper.DescripcionTipoCancelacion;
import com.atosorigin.deri.model.adminoper.DescripcionTipoOperacionHistderi;
import com.atosorigin.deri.model.adminoper.IndicadorConfirmacion;
import com.atosorigin.deri.model.catalogo.DescripcionSituacion;
import com.atosorigin.deri.model.common.Idioma;
import com.atosorigin.deri.model.contrapartida.AbstractContrapartida;
import com.atosorigin.deri.model.contrapartida.Contrapartida;
import com.atosorigin.deri.model.gestionoperaciones.DescripcionEstadoOperacion;
import com.atosorigin.deri.model.gestionoperaciones.FechaFormula;
import com.atosorigin.deri.model.gestionoperaciones.HistoricoFechaFormula;
import com.atosorigin.deri.model.gestionoperaciones.HistoricoOperacion;
import com.atosorigin.deri.model.gestionoperaciones.HistoricoOperacionId;
import com.atosorigin.deri.model.gestionoperaciones.LogPrimasEQS;
import com.atosorigin.deri.model.gestionoperaciones.LogPrimasEQSId;
import com.atosorigin.deri.model.gestionoperaciones.OperacionId;
import com.atosorigin.deri.model.liquidaciones.Liquidacion;
import com.atosorigin.deri.model.liquidaciones.LiquidacionId;
import com.atosorigin.deri.model.mercado.HistoricoTramos;
import com.atosorigin.deri.model.mercado.HistoricoTramosId;
import com.atosorigin.deri.model.mercado.TramosTable;
import com.atosorigin.deri.model.parametrizacion.Divisa;
import com.atosorigin.deri.util.FormatUtil;

@Name("primasEQSAction")
@Scope(ScopeType.CONVERSATION)
@FormValidator
public class PrimasEQSAction extends GenericAction {

    @In Credentials credentials;

//	@In(required=false)
//	private VistaOperacion vistaOperacionSelected;

	@In("#{primasBo}")
	private PrimasBo primasBo;

	@In("#{cancelacionBo}")
	private CancelacionBo cancelacionBo;

	@In("#{boletasBo}")
	private BoletasBo boletasBo;

	@In("#{primasEQSPantalla}")
	private PrimasEQSPantalla primasPantalla;


	@In(required=false)
	private String modifCanc;

	@In
	private FormatUtil formatUtil;

	@In
	@Out
	private HistoricoOperacion historicoOperacion;

	@In
	private HistoricoOperacionId historicoOperacionBloqueadoId;

	/** Inyección del servicio que gestiona los bloqueos de registros en base de datos */
	@In(create = true)
	protected DbLockService dbLockService;

	@Out(required=false)
	private BoletasStates boletaState;

	@Out
	private Date fechamis = new Date();

	@Out(required = false, value = "listaDivisasPrimasEQS")
	List<Divisa> divisasList = null;


	/** Inyección del objeto para la union con MANTPROD  */
	@In(required=false)
	@Out(required= false)
	String varModif;

	// Globales
	private String tppapago;
	private String tppareci;

	private Date fechaModificacion = null;

	private Boolean filaBloqueada = false;
	// Mensajes por pantalla
	private boolean mostrarMensaje = false;
	private StringBuilder mensajeConfirmacion = new StringBuilder();
	private boolean respuesta = false;
	private String accion = "validar";
	private boolean primeraVez = true;

	private boolean depositoDoble=false;
	private Date fechaFinTramoNominalA=null;
	private Boolean cancelacionExitosa;
	private Date fechaMaxAMPO;

	public void init(){
		if (primeraVez){

			fechamis = obtenerFechamis();
			fechaMaxAMPO =obtenerMaxFechaAMPO();
			cancelacionExitosa = false;
			fechaFinTramoNominalA = primasBo.esDepositoDoble(historicoOperacion);
			if (!GenericUtils.isNullOrBlank(fechaFinTramoNominalA)){
				depositoDoble=true;
			}

			operacionAPantalla();
			primasPantalla.setClase("PRI");
//			if (historicoOperacion.getFechaValorPrimaImplicita()==null){
////				historicoOperacion.setFechaValorPrimaImplicita(historicoOperacion.getFechaValor());
//				primasPantalla.setFechaValorPrimaImplicita(historicoOperacion.getFechaValor());
//			}else{
//				primasPantalla.setFechaValorPrimaImplicita(historicoOperacion.getFechaValorPrimaImplicita());
//			}
			primeraVez = false;
		}
	}

	private Date obtenerFechamis() {
		return primasBo.obtenerFechamis();
	}

	public boolean aceptarValidator(){
		boolean esCorrecto = true;
		cjtoCamposError.clear();

		return esCorrecto;
	}

	public void aceptar() {
		// COMPROBAR OPERACION PDTE. AGENDA
		if(operacionPdtAgenda() == 0 && "N".equals(modifCanc)) { //false
			statusMessages.add(StatusMessage.Severity.INFO, "#{messages['mantOper.cancelacion.error.operacionPendienteProcesar']}",
					historicoOperacion.getId().getNumeroOperacion(),historicoOperacion.getFechaValor(),
					historicoOperacion.getFechaVencimiento());
		} else {
			// COMPROBAR LIQUIDACIONES
			comprobarLiquidaciones();
		}
	}

	public void continuarAceptar() {
		// Venimos de preguntarle al usuario si continuaba o no
		resetMensajes();
		// COMPROBAR FEULTACT ÚLTIMO REGISTRO
		Date feultact = primasBo.obtenerMaxFeultact(historicoOperacion.getId().getNumeroOperacion(),historicoOperacion.getId().getFechaContratacion());
		if(feultact.compareTo(historicoOperacion.getId().getFechaModificacion()) != 0) {
			// DESBLOQUEAR
			if(historicoOperacionBloqueadoId!=null){
				dbLockService.desbloqueo(HistoricoOperacion.class, historicoOperacionBloqueadoId);
			}else{
				dbLockService.desbloqueo(HistoricoOperacion.class, historicoOperacion.getId());
			}
			statusMessages.add(StatusMessage.Severity.ERROR, "#{messages['mantOper.cancelacion.error.operacion.bloqueada']}",
					historicoOperacion.getId().getNumeroOperacion(),historicoOperacion.getId().getFechaContratacion());
		} else {
			// BLOQUEAR
		}
	}

	public String comitarAceptar(boolean bol) {
		if(bol) {
			// TODO: se hará la actualizacion de la agenda y el COMMIT
			// PKG_MANTOPER.P_INSERT_CANCEL_AGENDOTC(V_SYSDATE);



			try{
				salirNcorrela("C");
				if (GenericUtils.isNullOrBlank(cancelacionExitosa)
						|| !cancelacionExitosa){
					System.out.println("Cancelacion sin exito");
					//En caso de haber llamado al pkg de Cancelacion Parcial no llamar a grabar eventos
					primasBo.grabarEventosBoleta(historicoOperacion, "M", Identity.instance().getCredentials().getUsername());
				}

			}catch (BoletasBusinessException e) {
				statusMessages.add(Severity.ERROR, "#{messages['boletas.edicion.error.grabar.eventos']");
				salirNcorrela("R");
			}

			varModif = Constantes.CONSTANTE_SI;
			if(historicoOperacionBloqueadoId!=null){
				dbLockService.desbloqueo(HistoricoOperacion.class, historicoOperacionBloqueadoId);
			}else{
				dbLockService.desbloqueo(HistoricoOperacion.class, historicoOperacion.getId());
			}

			return Constantes.CONSTANTE_SUCCESS;
		} else {
			varModif = Constantes.CONSTANTE_NO;
			salirNcorrela("R");
			// rollback
			return Constantes.CONSTANTE_SUCCESS;
		}
	}

	private void persistir() {


	}

	public void salir() {
		salirNcorrela("R");
//		resetMensajes();
//		dbLockService.desbloqueo(HistoricoOperacion.class, historicoOperacion.getId());
		varModif = Constantes.CONSTANTE_NO;
		Conversation conv = Conversation.instance();
		if(conv != null && conv.isNested()){
			conv.redirectToParent();
		}

//		salirNcorrela("R");
	}

	private void salirNcorrela(String accion) {
//		primasBo.salirNcorrela(accion,historicoOperacion,credentials.getUsername());

		if (getFechaModificacion()!=null){
			primasBo.salirNcorrelaFeUltAct(accion,historicoOperacion, credentials.getUsername(),getFechaModificacion());
		}else{
			primasBo.salirNcorrela(accion,historicoOperacion,credentials.getUsername());
		}
		resetMensajes();

		if(historicoOperacionBloqueadoId!=null){
			dbLockService.desbloqueo(HistoricoOperacion.class, historicoOperacionBloqueadoId);
		}else{
			dbLockService.desbloqueo(HistoricoOperacion.class, historicoOperacion.getId());
		}

		primeraVez = true;
	}

	private int operacionPdtAgenda() {
		return primasBo.operacionPdtAgenda(historicoOperacion);
	}

	private void comprobarLiquidaciones() {
		resetMensajes();
		int count = primasBo.cuantasLiquidaciones(historicoOperacion.getId().getNumeroOperacion(), "VA");
		if(count > 0 && ( historicoOperacion.getProductoCompuesto() == null || historicoOperacion.getProductoCompuesto().getEstructu() == 0)) {
			// mostrar Mensaje pregunta('La operación tiene liquidaciones validadas. ¿Desea continuar?')
			accion = "cancelar";
			mostrarMensaje = true;
			mensajeConfirmacion.append(ResourceBundle.instance().getString("mantOper.cancelacion.error.liquidaciones"));
		} else {
			continuarAceptar();
		}
	}



	private void resetMensajes() {
		mostrarMensaje = false;
		mensajeConfirmacion = new StringBuilder();
		respuesta = false;
		accion = "";
		fechaModificacion = null;
	}


	public Boolean getFilaBloqueada() {
		return filaBloqueada;
	}

	public boolean isRespuesta() {
		return respuesta;
	}

	public void setRespuesta(boolean respuesta) {
		mostrarMensaje = false;
		this.respuesta = respuesta;
	}

	public StringBuilder getMensajeConfirmacion() {
		return mensajeConfirmacion;
	}

	public void setMensajeConfirmacion(StringBuilder mensajeConfirmacion) {
		this.mensajeConfirmacion = mensajeConfirmacion;
	}

	public boolean isMostrarMensaje() {
		return mostrarMensaje;
	}

	public void setMostrarMensaje(boolean mostrarMensaje) {
		this.mostrarMensaje = mostrarMensaje;
	}

	public String getAccion() {
		return accion;
	}

	public void setAccion(String accion) {
		this.accion = accion;
	}

	public Date getFechaModificacion() {
		return fechaModificacion;
	}

	public void setFechaModificacion(Date fechaModificacion) {
		this.fechaModificacion = fechaModificacion;
	}

	public boolean guardarValidator(){
		boolean ret = true;
//
//			S’hauria de predefinir els següents conceptes per tal d’evitar errors:
//			o	Tomado (COMD)  Ampliació Nominal  COBRO
//			o	Tomado  Amortització Nominal  PAGO
//			o	Prestado  Ampliació Nominal PAGO
//			o	Prestado  Amortització Nominal  COBRO


		if ("RTO".equals(primasPantalla.getClase()) && "P".equalsIgnoreCase(primasPantalla.getTipoPrimaImplicita()) ){
			statusMessages.add(Severity.ERROR, "#{messages['mantOper.messages.modificar.primasRTO']}");
			ret = false;
			return ret;
		}

	if ("AMO".equals(primasPantalla.getClase()) || "AMP".equals(primasPantalla.getClase())){

	   if (historicoOperacion.getFechaValor().before(primasPantalla.getFechaValorAMPO())){

			   if ("AMO".equals(primasPantalla.getClase())){
				   //PVP SOLO CANCELACIONES PARCIALES
				   if (!GenericUtils.isNullOrBlank(primasPantalla.getTipoConfirmacion())&&
						   "MOD".equalsIgnoreCase(primasPantalla.getTipoConfirmacion())){

					   statusMessages.add(Severity.ERROR, "#{messages['mantOper.messages.modificar.tipoConfirmacionError']}");
					   ret = false;
					   return ret;
				   }

			   }else if (!GenericUtils.isNullOrBlank(primasPantalla.getTipoConfirmacion())&&
					   "CAN".equalsIgnoreCase(primasPantalla.getTipoConfirmacion())){
					//PVM SOLO MODIFICACIONES Y HA SELECCIONADO CANCELACION PARCIAL
						statusMessages.add(Severity.ERROR, "#{messages['mantOper.messages.modificar.tipoConfirmacionError']}");
						ret = false;
						return ret;
			   }


	   }else if (!GenericUtils.isNullOrBlank(primasPantalla.getTipoConfirmacion())&&
			   "CAN".equalsIgnoreCase(primasPantalla.getTipoConfirmacion())){
		//PVM SOLO MODIFICACIONES Y HA SELECCIONADO CANCELACION PARCIAL
			statusMessages.add(Severity.ERROR, "#{messages['mantOper.messages.modificar.tipoConfirmacionError']}");
			ret = false;
			return ret;
	   }

//		if ("COMD".equalsIgnoreCase(historicoOperacion.getTransaccion().getCodigo())){
//			if ( ("AMO".equals(primasPantalla.getClase()) && "R".equalsIgnoreCase(primasPantalla.getTipoPrimaImplicitaAMPO()))
//			||	 ("AMP".equals(primasPantalla.getClase()) && "P".equalsIgnoreCase(primasPantalla.getTipoPrimaImplicitaAMPO()))
//				){
//				statusMessages.add(Severity.ERROR, "#{messages['mantOper.messages.modificar.primasTRAN']}");
//				ret = false;
//				return ret;
//			}
//		}else{
//			if ( ("AMO".equals(primasPantalla.getClase()) && "P".equalsIgnoreCase(primasPantalla.getTipoPrimaImplicitaAMPO()))
//			||	 ("AMP".equals(primasPantalla.getClase()) && "R".equalsIgnoreCase(primasPantalla.getTipoPrimaImplicitaAMPO()))
//						){
//						statusMessages.add(Severity.ERROR, "#{messages['mantOper.messages.modificar.primasTRAN']}");
//						ret = false;
//						return ret;
//					}
//		}


		if (!GenericUtils.isNullOrBlank(primasPantalla.getFechaValorAMPO())
				&& primasPantalla.getFechaValorAMPO().after(historicoOperacion.getFechaVencimiento()))
			{
				statusMessages.add(Severity.ERROR, "#{messages['boletas.pestanas.primas.errorFecha']}");
				ret = false;
				return ret;
			}else if  (!GenericUtils.isNullOrBlank(primasPantalla.getFechaValorAMPO()) &&
					!GenericUtils.isNullOrBlank(fechaMaxAMPO) && primasPantalla.getFechaValorAMPO().before(fechaMaxAMPO)){

				statusMessages.addFromResourceBundle(Severity.ERROR, "boletas.pestanas.primas.errorFechaDos", fechaMaxAMPO);
				ret = false;
				return ret;

			}



			if (!GenericUtils.isNullOrBlank(primasPantalla.getImporteAmoImplicita()) &&
					(GenericUtils.isNullOrBlank(primasPantalla.getTipoPrimaImplicitaAMPO()) ||
					 GenericUtils.isNullOrBlank(primasPantalla.getPorcentajePrimaImplicitaAMO()) ||
					 GenericUtils.isNullOrBlank(primasPantalla.getDivisaPrimaImplicitaAMPO()) ||
					 GenericUtils.isNullOrBlank(primasPantalla.getFechaAmoImplicita()) )
			){
				statusMessages.add(Severity.ERROR, "#{messages['mantOper.messages.errorDatos.primaImplicita']}");
				ret = false;
				return ret;
			}


			if (!GenericUtils.isNullOrBlank(primasPantalla.getImporteAmoCupon()) &&
					(GenericUtils.isNullOrBlank(primasPantalla.getTipoCupon()) ||
					 GenericUtils.isNullOrBlank(primasPantalla.getDivisaPrimaCupon()) ||
					 GenericUtils.isNullOrBlank(primasPantalla.getPorcentajePrimaCupon()) ||
					 GenericUtils.isNullOrBlank(primasPantalla.getFechaAmoCupon()) )
			){
				statusMessages.add(Severity.ERROR, "#{messages['mantOper.messages.errorDatos.primaCupon']}");
				ret = false;
				return ret;
			}

			if (!GenericUtils.isNullOrBlank(primasPantalla.getImporteAmoPrimaUpfront()) &&
					(GenericUtils.isNullOrBlank(primasPantalla.getTipoPrimaUpfront()) ||
					 GenericUtils.isNullOrBlank(primasPantalla.getDivisaPrimaPrimaUpfront()) ||
					 GenericUtils.isNullOrBlank(primasPantalla.getFechaAmoPrimaUpfront()) )
			){
				statusMessages.add(Severity.ERROR, "#{messages['mantOper.messages.errorDatos.primaUpfront']}");
				ret = false;
				return ret;
			}

			if (!GenericUtils.isNullOrBlank(primasPantalla.getImporteAmoPrimaCancel()) &&
					(GenericUtils.isNullOrBlank(primasPantalla.getTipoPrimaCancel()) ||
					 GenericUtils.isNullOrBlank(primasPantalla.getDivisaPrimaPrimaCancel()) ||
					 GenericUtils.isNullOrBlank(primasPantalla.getFechaAmoPrimaCancel()) )
			){
				statusMessages.add(Severity.ERROR, "#{messages['mantOper.messages.errorDatos.primaCancel']}");
				ret = false;
				return ret;
			}


		}

		return ret;
	}

	public void guardar(){
//		historicoOperacion.setFechaValorPrimaImplicita(historicoOperacion.getFechaValor());

//		, en el caso de Amortizaciones y Ampliaciones, modificará los tramos futuros del calendario
//		aumentando o disminuyendo el Nominal vivo de la operación con el importe introducido.
//

		DescripcionEstadoOperacion estado = primasBo.getEstado("PV");
		historicoOperacion.setEstado(estado);



		 Boolean primaUpFrontDisabled;
		Boolean primaCancelDisabled;


		if ("IMP".equals(primasPantalla.getClase()) || "RTO".equals(primasPantalla.getClase())){

			grabarRegistroLog();
			pantallaAOperacion();
			generarTramo("PRI",primasPantalla.getClase());
			primasBo.persistir(historicoOperacion);
			comitarAceptar(true);

			Conversation conv = Conversation.instance();
			if(conv != null && conv.isNested()){
				conv.redirectToParent();
			}

		}else if ("AMO".equals(primasPantalla.getClase())){

//			calcular();
			grabarRegistroLog();

			if (!GenericUtils.isNullOrBlank(primasPantalla.getSpreadFinal()) && !primasPantalla.getSpreadFinal().equals(primasPantalla.getSpread())
					&& !primasPantalla.getSpreadFinalRead()){

				primasBo.actualizarSpread(historicoOperacion,primasPantalla.getFechaValorAMPO(),primasPantalla.getNominalA(),primasPantalla.getNominalB(),
						primasPantalla.getSpreadFinal(), primasPantalla.getPataSpread()	);

			}

			List<HistoricoTramos> tramosLiquidados = new ArrayList<HistoricoTramos>();

			List<HistoricoTramos> tramosLiqtmp = primasBo.actualizarNominales(historicoOperacion,primasPantalla.getFechaValorAMPO(),primasPantalla.getNominalA(),primasPantalla.getNominalFinalA(),
					primasPantalla.getNominalB(),primasPantalla.getNominalFinalB());

			if (!GenericUtils.isNullOrBlank(tramosLiqtmp) && tramosLiqtmp.size() > 0){
				tramosLiquidados.addAll(tramosLiqtmp);
			}

			pantallaAOperacion();

			if (!GenericUtils.isNullOrZero(primasPantalla.getImporteAmoImplicita()) &&
					!primasPantalla.getPrimaImplicitaDisabled()){

				HistoricoTramos tramoImplicita = primasBo.obtenerTramoImplicita(historicoOperacion);

				tramoImplicita.setDivisaTramo(primasPantalla.getDivisaPrimaImplicitaAMPO());
				tramoImplicita.setImporteOperacion(primasPantalla.getImporteAmoImplicita());
				//primasPantalla.setTipoPrimaImplicitaAMPO(tramoImplicita.getId().getTipoOperacion().getCodigo());
				//primasPantalla.setFechaAmoImplicita(tramoImplicita.getId().getFechaInicioTramo());

				primasBo.persistirTramo(tramoImplicita);

				if	(!GenericUtils.isNullOrBlank(tramoImplicita.getCodigoLiquidacion())){
					tramosLiquidados.add(tramoImplicita);
				}

			}

			//Cupon
			if (!GenericUtils.isNullOrZero(primasPantalla.getImporteAmoCupon()) &&
					!primasPantalla.getPrimaCuponDisabled()){

				HistoricoTramos tramoCupon= primasBo.obtenerTramoCupon(historicoOperacion);

				tramoCupon.setDivisaTramo(primasPantalla.getDivisaPrimaCupon());
				tramoCupon.setImporteOperacion(primasPantalla.getImporteAmoCupon());

				//primasPantalla.setTipoCupon(tramoCupon.getId().getTipoOperacion().getCodigo());
				//primasPantalla.setFechaAmoCupon(tramoCupon.getId().getFechaInicioTramo());

				HistoricoFechaFormula fechaForm = primasBo.obtenerFechaFormula(tramoCupon);
				if (!GenericUtils.isNullOrBlank(fechaForm)){
					fechaForm.setRateLiquidacion(primasPantalla.getPorcentajePrimaCupon());
					primasBo.persistir(fechaForm);
				}

				primasBo.persistirTramo(tramoCupon);

				if	(!GenericUtils.isNullOrBlank(tramoCupon.getCodigoLiquidacion())){
					tramosLiquidados.add(tramoCupon);
				}




//				HistoricoFechaFormula fechaForm = primasBo.obtenerFechaFormula(tramoCupon);
//				fechaForm.setRateLiquidacion(primasPantalla.getPorcentajePrimaCupon());

			}

			//UPFRONT
			if (!GenericUtils.isNullOrZero(primasPantalla.getImporteAmoPrimaUpfront()) &&
					!primasPantalla.getPrimaUpFrontDisabled()){

				HistoricoTramos tramoUpfront = primasBo.obtenerTramoUpfront(historicoOperacion);

				tramoUpfront.setDivisaTramo(primasPantalla.getDivisaPrimaPrimaUpfront());
				tramoUpfront.setImporteOperacion(primasPantalla.getImporteAmoPrimaUpfront());
				//primasPantalla.setTipoPrimaImplicitaAMPO(tramoImplicita.getId().getTipoOperacion().getCodigo());
				//primasPantalla.setFechaAmoImplicita(tramoImplicita.getId().getFechaInicioTramo());

				primasBo.persistirTramo(tramoUpfront);

				if	(!GenericUtils.isNullOrBlank(tramoUpfront.getCodigoLiquidacion())){
					tramosLiquidados.add(tramoUpfront);
				}
			}


			List<LiquidacionId> neteoLiq =  new ArrayList<LiquidacionId>();
			List<TramosTable> tramosTableList = crearTablaAjustesLiq(tramosLiquidados,neteoLiq );

			if (!ajustarLiquidaciones(tramosTableList)){

				comitarAceptar(false);
				Conversation conv = Conversation.instance();

				if(conv != null && conv.isNested()){
					conv.redirectToParent();
				}

				return;
			}



			//CANCELACION
			if (
//					!GenericUtils.isNullOrZero(primasPantalla.getImporteAmoPrimaCancel()) &&
					!primasPantalla.getPrimaCancelDisabled()){

				if (!cancelacionParcial()){
					comitarAceptar(false);
					Conversation conv = Conversation.instance();
					if(conv != null && conv.isNested()){
						conv.redirectToParent();
					}
					return;
				}

			}


			primasBo.persistir(historicoOperacion);



//			//generarTramo("AMO","AMO");
//			StringBuffer errorCode = new StringBuffer();
//
//			//17/01/2014. Quitar la llamada al package de modificar calendario para productos dédalo
//			if (!historicoOperacion.getProducto().getIndDerivado().equals("D") && !primasBo.callModificarCalendario(historicoOperacion,primasPantalla.getClase(), primasPantalla.getTipoPrimaImplicita(),
//					primasPantalla.getImportePrimaImplicita(), primasPantalla.getDivisaPrimaImplicita(),
//					primasPantalla.getFechaValorPrimaImplicita(),Identity.instance().getCredentials().getUsername(), errorCode)){
//				if (!GenericUtils.isNullOrBlank(errorCode)){
//					statusMessages.addFromResourceBundle(Severity.ERROR, "mantOper.messages.modificar.calendarioPrimas", errorCode.toString());
//				}else{
//					statusMessages.add(Severity.ERROR, "#{messages['mantOper.messages.modificar.calendarioPrimas']}");
//				}
////				comitarAceptar(false);
//			}else{
				comitarAceptar(true);

				Conversation conv = Conversation.instance();
				if(conv != null && conv.isNested()){
					conv.redirectToParent();
				}

			//}

		}else if ("AMP".equals(primasPantalla.getClase())){
//			calcular();
			grabarRegistroLog();

			if (!GenericUtils.isNullOrBlank(primasPantalla.getSpreadFinal()) && !primasPantalla.getSpreadFinal().equals(primasPantalla.getSpread())
					&& !primasPantalla.getSpreadFinalRead()){

				primasBo.actualizarSpread(historicoOperacion,primasPantalla.getFechaValorAMPO(),primasPantalla.getNominalA(),primasPantalla.getNominalB(),
						primasPantalla.getSpreadFinal(), primasPantalla.getPataSpread()	);

			}
			List<HistoricoTramos> tramosLiquidados = new ArrayList<HistoricoTramos>();
			List<HistoricoTramos> tramosLiqtmp = primasBo.actualizarNominales(historicoOperacion,primasPantalla.getFechaValorAMPO(),primasPantalla.getNominalA(),primasPantalla.getNominalFinalA(),
					primasPantalla.getNominalB(),primasPantalla.getNominalFinalB());

			if (!GenericUtils.isNullOrBlank(tramosLiqtmp) && tramosLiqtmp.size() > 0){
				tramosLiquidados.addAll(tramosLiqtmp);
			}

			//generarTramo("AMP","AMP");
//			StringBuffer errorCode = new StringBuffer();
//			//17/01/2014. Quitar la llamada al package de modificar calendario para productos dédalo
//			if (!historicoOperacion.getProducto().getIndDerivado().equals("D") && !primasBo.callModificarCalendario(historicoOperacion,primasPantalla.getClase(), primasPantalla.getTipoPrimaImplicita(),
//					primasPantalla.getImportePrimaImplicita(), primasPantalla.getDivisaPrimaImplicita(),
//					primasPantalla.getFechaValorPrimaImplicita(),Identity.instance().getCredentials().getUsername(), errorCode)){
//
//				if (!GenericUtils.isNullOrBlank(errorCode)){
//					statusMessages.addFromResourceBundle(Severity.ERROR, "mantOper.messages.modificar.calendarioPrimas", errorCode.toString());
//				}else{
//					statusMessages.add(Severity.ERROR, "#{messages['mantOper.messages.modificar.calendarioPrimas']}");
//				}
////				comitarAceptar(false);
//			}else{

			pantallaAOperacion();

			if (!GenericUtils.isNullOrZero(primasPantalla.getImporteAmoImplicita())&&
					!primasPantalla.getPrimaImplicitaDisabled()){

				HistoricoTramos tramoImplicita = primasBo.obtenerTramoImplicita(historicoOperacion);

				tramoImplicita.setDivisaTramo(primasPantalla.getDivisaPrimaImplicitaAMPO());
				tramoImplicita.setImporteOperacion(primasPantalla.getImporteAmoImplicita());
				//primasPantalla.setTipoPrimaImplicitaAMPO(tramoImplicita.getId().getTipoOperacion().getCodigo());
				//primasPantalla.setFechaAmoImplicita(tramoImplicita.getId().getFechaInicioTramo());

				primasBo.persistirTramo(tramoImplicita);

				if	(!GenericUtils.isNullOrBlank(tramoImplicita.getCodigoLiquidacion())){
					tramosLiquidados.add(tramoImplicita);
				}
			}

			//Cupon
			if (!GenericUtils.isNullOrZero(primasPantalla.getImporteAmoCupon()) &&
					!primasPantalla.getPrimaCuponDisabled()){

				HistoricoTramos tramoCupon= primasBo.obtenerTramoCupon(historicoOperacion);

				tramoCupon.setDivisaTramo(primasPantalla.getDivisaPrimaCupon());
				tramoCupon.setImporteOperacion(primasPantalla.getImporteAmoCupon());

				//primasPantalla.setTipoCupon(tramoCupon.getId().getTipoOperacion().getCodigo());
				//primasPantalla.setFechaAmoCupon(tramoCupon.getId().getFechaInicioTramo());

				HistoricoFechaFormula fechaForm = primasBo.obtenerFechaFormula(tramoCupon);
				if (!GenericUtils.isNullOrBlank(fechaForm)){
					fechaForm.setRateLiquidacion(primasPantalla.getPorcentajePrimaCupon());
					primasBo.persistir(fechaForm);
				}

				primasBo.persistirTramo(tramoCupon);

				if	(!GenericUtils.isNullOrBlank(tramoCupon.getCodigoLiquidacion())){
					tramosLiquidados.add(tramoCupon);
				}

//				HistoricoFechaFormula fechaForm = primasBo.obtenerFechaFormula(tramoCupon);
//				fechaForm.setRateLiquidacion(primasPantalla.getPorcentajePrimaCupon());

			}

			//UPFRONT
			if (!GenericUtils.isNullOrZero(primasPantalla.getImporteAmoPrimaUpfront()) &&
					!primasPantalla.getPrimaUpFrontDisabled()){

				HistoricoTramos tramoUpfront = primasBo.obtenerTramoUpfront(historicoOperacion);

				tramoUpfront.setDivisaTramo(primasPantalla.getDivisaPrimaPrimaUpfront());
				tramoUpfront.setImporteOperacion(primasPantalla.getImporteAmoPrimaUpfront());
				//primasPantalla.setTipoPrimaImplicitaAMPO(tramoImplicita.getId().getTipoOperacion().getCodigo());
				//primasPantalla.setFechaAmoImplicita(tramoImplicita.getId().getFechaInicioTramo());

				primasBo.persistirTramo(tramoUpfront);

				if	(!GenericUtils.isNullOrBlank(tramoUpfront.getCodigoLiquidacion())){
					tramosLiquidados.add(tramoUpfront);
				}

			}


			List<LiquidacionId> neteoLiq =  new ArrayList<LiquidacionId>();
			List<TramosTable> tramosTableList = crearTablaAjustesLiq(tramosLiquidados, neteoLiq);

			if (!ajustarLiquidaciones(tramosTableList)){
				comitarAceptar(false);
				Conversation conv = Conversation.instance();
				if(conv != null && conv.isNested()){
					conv.redirectToParent();
				}
				return;
			}


//			//CANCELACION
//			if (!GenericUtils.isNullOrZero(primasPantalla.getImporteAmoPrimaCancel()) &&
//					!primasPantalla.getPrimaCancelDisabled()){
//
//
//			}

				primasBo.persistir(historicoOperacion);




				comitarAceptar(true);

				Conversation conv = Conversation.instance();
				if(conv != null && conv.isNested()){
					conv.redirectToParent();
				}

//			}

		}

	}

	private List<TramosTable> crearTablaAjustesLiq(
			List<HistoricoTramos> tramosLiquidados, List<LiquidacionId> neteoLiq) {

		List<TramosTable> tramosTableList = new ArrayList<TramosTable>();

		for (HistoricoTramos historicoTramos : tramosLiquidados) {
			//Como el package ajusta automaticamente las liquidaciones neteadas, solo hay que enviar una de ellas

			Liquidacion liquiNet = cancelacionBo.obtenerLiquidacionNeteo(historicoTramos);
			if (!GenericUtils.isNullOrBlank(liquiNet)){
				LiquidacionId liquiNetId = liquiNet.getId();
				if (neteoLiq.contains(liquiNetId)){

				}else{
					neteoLiq.add(liquiNetId);
					tramosTableList.add(montarRegistro(historicoTramos));
				}

			}else{
				LiquidacionId liquiNetId = new LiquidacionId(Constantes.NOMBRE_PROYECTO_DERI,historicoTramos.getComplementoCodLiqui(),historicoTramos.getCodigoLiquidacion());
				if (neteoLiq.contains(liquiNetId)){

				}else{
					neteoLiq.add(liquiNetId);
					tramosTableList.add(montarRegistro(historicoTramos));
				}

			}


		}
		return tramosTableList;
	}

	private void grabarRegistroLog() {

		LogPrimasEQSId idLog = new LogPrimasEQSId(historicoOperacion, new Date());
		AuditData auditData = new AuditData();
		auditData.setFechaUltimaModi(historicoOperacion.getId().getFechaModificacion());
		auditData.setUsuarioUltimaModi(credentials.getUsername());

		String chckImplicita, chkCupon, chkUpfront,chkCancel;

		if (primasPantalla.isImplicitaChk()) {
			chckImplicita = "S";
		}else{
			chckImplicita = "N";
		}

		if (primasPantalla.isCuponChk()) {
			chkCupon = "S";
		}else{
			chkCupon = "N";
		}

		if (primasPantalla.isPrimaUpfrontChk()) {
			chkUpfront = "S";
		}else{
			chkUpfront = "N";
		}

		if (primasPantalla.isPrimaCancelChk()) {
			chkCancel = "S";
		}else{
			chkCancel = "N";
		}

		LogPrimasEQS logPrima = new LogPrimasEQS(idLog, credentials.getUsername(),
			primasPantalla.getClase(), primasPantalla.getTipoPrimaImplicita(),
			primasPantalla.getPorcentajePrimaImplicita(),primasPantalla.getImportePrimaImplicita(),
			primasPantalla.getDivisaPrimaImplicita(),primasPantalla.getFechaValorPrimaImplicita(),
			primasPantalla.getTipoConfirmacion(), primasPantalla.getImportePrimaImplicitaAMPO(),
			primasPantalla.getFechaValorAMPO(), primasPantalla.getNominalA(), primasPantalla.getNominalFinalA(),
			primasPantalla.getNominalB(), primasPantalla.getNominalFinalB(),chckImplicita,
			primasPantalla.getTipoPrimaImplicitaAMPO(), primasPantalla.getPorcentajePrimaImplicitaAMO(),
			primasPantalla.getImporteAmoImplicita(),
			primasPantalla.getDivisaPrimaImplicitaAMPO(),
			primasPantalla.getFechaAmoImplicita(), chkCupon,
			primasPantalla.getTipoCupon(),primasPantalla.getPorcentajePrimaCupon(), primasPantalla.getImporteAmoCupon(),
			primasPantalla.getDivisaPrimaCupon(),primasPantalla.getFechaAmoCupon(),
			chkUpfront,primasPantalla.getTipoPrimaUpfront(),primasPantalla.getImporteAmoPrimaUpfront(),
			primasPantalla.getDivisaPrimaPrimaUpfront(), primasPantalla.getFechaAmoPrimaUpfront(),
			chkCancel, primasPantalla.getTipoPrimaCancel(),primasPantalla.getImporteAmoPrimaCancel(),
			primasPantalla.getDivisaPrimaPrimaCancel(), primasPantalla.getFechaAmoPrimaCancel(), primasPantalla.getSpread(),
			primasPantalla.getSpreadFinal(),
			auditData);

		primasBo.persistir(logPrima);
	}

	public void calcular(){
		primasPantalla.setCalculado(false);
		if ("AMO".equalsIgnoreCase(primasPantalla.getClase())) {
			primasPantalla.setSpreadFinalRead(false);
			// Signo -

			if (!GenericUtils.isNullOrBlank(primasPantalla.getNominalA())){
				if (GenericUtils.isNullOrBlank(fechaFinTramoNominalA) ||
						!primasPantalla.getFechaValorAMPO().after(fechaFinTramoNominalA)){

					//DEPOSITO SIMPLE o DEPOSITO DOBLE CON NOMINAL A MODIFICABLE
					primasPantalla.setNominalFinalA(primasPantalla.getNominalA().subtract(primasPantalla.getImportePrimaImplicitaAMPO()));
					primasPantalla.setNominalFinalARead(false);
				}else{
					//DESPOSITO DOBLE CON NOMINAL A NO AMORTIZABLE
					primasPantalla.setNominalFinalA(primasPantalla.getNominalA());
					primasPantalla.setNominalFinalARead(true);
				}
			}
			if (!GenericUtils.isNullOrBlank(primasPantalla.getNominalB())){

				if (GenericUtils.isNullOrBlank(fechaFinTramoNominalA) ||
						!primasPantalla.getFechaValorAMPO().after(fechaFinTramoNominalA)){

					//DEPOSITO SIMPLE o DEPOSITO DOBLE CON NOMINAL A MODIFICABLE
					BigDecimal valorTemp = 	primasPantalla.getNominalB().divide(primasPantalla.getNominalA(),10, RoundingMode.HALF_UP).multiply(primasPantalla.getImportePrimaImplicitaAMPO());
					primasPantalla.setNominalFinalB(primasPantalla.getNominalB().subtract(valorTemp));
					primasPantalla.setNominalFinalBRead(false);
				}else{
					//DESPOSITO DOBLE CON NOMINAL A NO AMORTIZABLE
					//NOMINAL B SE CALCULA DIRECTO
					primasPantalla.setNominalFinalB(primasPantalla.getNominalB().subtract(primasPantalla.getImportePrimaImplicitaAMPO()));
					primasPantalla.setNominalFinalBRead(false);
				}

			}

//			//Cupon
//			if (!GenericUtils.isNullOrBlank(primasPantalla.getImporteAmoCupon())
//					&& GenericUtils.isNullOrBlank(primasPantalla.getPorcentajePrimaCupon())){
//				onImporteAmoCuponChange();
//			}


		}else if ("AMP".equalsIgnoreCase(primasPantalla.getClase())) {
			primasPantalla.setSpreadFinalRead(false);
			// Signo +
			if (!GenericUtils.isNullOrBlank(primasPantalla.getNominalA())){
				if (GenericUtils.isNullOrBlank(fechaFinTramoNominalA) ||
						!primasPantalla.getFechaValorAMPO().after(fechaFinTramoNominalA)){
					//DEPOSITO SIMPLE o DEPOSITO DOBLE CON NOMINAL A MODIFICABLE
					primasPantalla.setNominalFinalA(primasPantalla.getNominalA().add(primasPantalla.getImportePrimaImplicitaAMPO()));
					primasPantalla.setNominalFinalARead(false);
				}else{
					//DESPOSITO DOBLE CON NOMINAL A NO AMORTIZABLE
					primasPantalla.setNominalFinalA(primasPantalla.getNominalA());
					primasPantalla.setNominalFinalARead(true);
				}
			}
			if (!GenericUtils.isNullOrBlank(primasPantalla.getNominalB())){

				if (GenericUtils.isNullOrBlank(fechaFinTramoNominalA) ||
						!primasPantalla.getFechaValorAMPO().after(fechaFinTramoNominalA)){

					//DEPOSITO SIMPLE o DEPOSITO DOBLE CON NOMINAL A MODIFICABLE
					BigDecimal valorTemp = 	primasPantalla.getNominalB().divide(primasPantalla.getNominalA(),10, RoundingMode.HALF_UP).multiply(primasPantalla.getImportePrimaImplicitaAMPO());
					primasPantalla.setNominalFinalB(primasPantalla.getNominalB().add(valorTemp));
					primasPantalla.setNominalFinalBRead(false);
				}else{
					//DESPOSITO DOBLE CON NOMINAL A NO AMORTIZABLE
					//NOMINAL B SE CALCULA DIRECTO
					primasPantalla.setNominalFinalB(primasPantalla.getNominalB().add(primasPantalla.getImportePrimaImplicitaAMPO()));
					primasPantalla.setNominalFinalBRead(false);
				}



			}
		}

		//Implicitas
		if (!GenericUtils.isNullOrBlank(primasPantalla.getImporteAmoImplicita())
				&& !GenericUtils.isNullOrBlank(primasPantalla.getPorcentajePrimaImplicitaAMO())
				&& !GenericUtils.isNullOrBlank(primasPantalla.getFechaAmoImplicita())
		){

			if (!primasPantalla.getFechaAmoImplicita().before(primasPantalla.getFechaValorAMPO())) {

				onPorcentajePrimaImplicitaAMOCalcular(primasPantalla.getImportePrimaImplicitaAMPO(),primasPantalla.getClase(),
						primasPantalla.getNominalA(),primasPantalla.getNominalFinalA());

			}

		}

		if (!GenericUtils.isNullOrBlank(primasPantalla.getImporteAmoCupon())
				&& !GenericUtils.isNullOrBlank(primasPantalla.getPorcentajePrimaCupon())
				&& !GenericUtils.isNullOrBlank(primasPantalla.getFechaAmoCupon())
		){

			if (!primasPantalla.getFechaAmoCupon().before(primasPantalla.getFechaValorAMPO())) {

				onPorcentajePrimaCuponCalcular(primasPantalla.getImportePrimaImplicitaAMPO(),primasPantalla.getClase(),
						primasPantalla.getNominalA(),primasPantalla.getNominalFinalA());

			}
		}



	}

	private void generarTramo(String concepto, String tipoConcepto) {
		HistoricoTramos oldTramo = primasBo.caragrPrimaExistente(historicoOperacion);

		DescripcionTipoOperacionHistderi tipoOpera = primasBo.getTipoOperacion(primasPantalla.getTipoPrimaImplicita());
		Date fechaFinTramo=null;
		if ("IMP".equalsIgnoreCase(tipoConcepto)){
			fechaFinTramo =historicoOperacion.getFechaVencimiento();
		}else{
			fechaFinTramo =primasPantalla.getFechaValorPrimaImplicita();
		}
		HistoricoTramosId id = new HistoricoTramosId(historicoOperacion, tipoOpera,
				primasPantalla.getFechaValorPrimaImplicita(),fechaFinTramo, concepto, tipoConcepto);
		HistoricoTramos tramo = new HistoricoTramos(id);


		if ("IMP".equalsIgnoreCase(tipoConcepto)){
			tramo.setFechaLiquidacion(null);
			tramo.setDivisaLiquidacion(null);
		}else{
			tramo.setFechaLiquidacion(primasPantalla.getFechaValorPrimaImplicita());
			tramo.setDivisaLiquidacion(primasPantalla.getDivisaPrimaImplicita().getId());
		}




		tramo.setImporteOperacion(primasPantalla.getImportePrimaImplicita());
		tramo.setDivisaTramo(primasPantalla.getDivisaPrimaImplicita());

		if ("P".equals(tramo.getId().getTipoOperacion().getCodigo())){
			if (historicoOperacion.getTipoCurvaPago()!= null && historicoOperacion.getTipoCurvaPago().getTipocurv()!=null){
				tramo.setTipoCurvaTramo(historicoOperacion.getTipoCurvaPago().getTipocurv());
			}else{
				tramo.setTipoCurvaTramo("000");
			}

		}else{
			if (historicoOperacion.getTipoCurvaRecibo()!= null && historicoOperacion.getTipoCurvaRecibo().getTipocurv()!=null){
				tramo.setTipoCurvaTramo(historicoOperacion.getTipoCurvaRecibo().getTipocurv());
			}else{
				tramo.setTipoCurvaTramo("000");
			}
		}

		tramo.setIndicNulo(null);
		tramo.setIndicadorTramoIrregular("N");
		tramo.setUltimaOperacionRealizada(historicoOperacion.getUltimaAccion().getCodigo());
		tramo.setProducto(historicoOperacion.getProducto().getId());
		tramo.setTransaccionOper(historicoOperacion.getTransaccion().getCodigo());
		tramo.setCodigoLiquidacion(null);
		tramo.setComplementoCodLiqui(null);
		tramo.setNominalParaCalculo(null);
		tramo.setNominalAmortizado(null);
		tramo.setIndicadorLiquiAmortizacion(null);
		tramo.setDiferenciaDias((short) 0);
		tramo.setBaseDeCalculoDias(null);

		//p_tramo.FECCALIQ := pkg_calendar_utiles.f_AJUSTAR_FECHA_INF (p_tramo.FECINITR, 3, p_tramo.DIVISATR);
		tramo.setFechaCalculoLiquidacion(primasBo.ajustarFechaInf(tramo.getId().getFechaInicioTramo(),3,tramo.getDivisaTramo()));

		tramo.setFechaValorDelTipo(null);
		tramo.setFechaInformarImporte(null);
		tramo.setStrikeCFC(BigDecimal.ZERO);
		tramo.setPorcentajeTipoInteres(BigDecimal.ZERO);
		tramo.setSpreadOperacion(BigDecimal.ZERO);
		tramo.setCodigoFormula(null);
		tramo.setUsuario(credentials.getUsername());
		tramo.setNivelBarrera(BigDecimal.ZERO);
		tramo.setIndicadorTipindiv(primasBo.cargarDescIndifiva("F"));
		tramo.setEstadoTramo("VA");

		primasBo.persistirTramo(tramo);
		if(oldTramo != null){
			if(!tramo.getId().equals(oldTramo.getId()))
			primasBo.borrarTramo(oldTramo);
		}
	}

	public void pantallaAOperacion(){

		if ("IMP".equals(primasPantalla.getClase())){
//				|| "RTO".equals(primasPantalla.getClase())	){
		historicoOperacion.setFechaValorPrimaImplicita(primasPantalla.getFechaValorPrimaImplicita());
		historicoOperacion.setDivisaPrimaImplicita(primasPantalla.getDivisaPrimaImplicita());
		historicoOperacion.setImportePrimaImplicita(primasPantalla.getImportePrimaImplicita());
		historicoOperacion.setTipoPrimaImplicita(primasPantalla.getTipoPrimaImplicita());

		if ("IMP".equals(primasPantalla.getClase())){
			 historicoOperacion.setPorcentajePrimaImplicita(primasPantalla.getPorcentajePrimaImplicita());
		}

		}
		if ("AMO".equals(primasPantalla.getClase())	|| "AMP".equals(primasPantalla.getClase())	){

			//Prima Implicita
			if (!GenericUtils.isNullOrZero(primasPantalla.getImporteAmoImplicita()) &&
					!primasPantalla.getPrimaImplicitaDisabled()){
				historicoOperacion.setFechaValorPrimaImplicita(primasPantalla.getFechaAmoImplicita());
				historicoOperacion.setDivisaPrimaImplicita(primasPantalla.getDivisaPrimaImplicitaAMPO());
				historicoOperacion.setImportePrimaImplicita(primasPantalla.getImporteAmoImplicita());
				historicoOperacion.setTipoPrimaImplicita(primasPantalla.getTipoPrimaImplicitaAMPO());
				historicoOperacion.setPorcentajePrimaImplicita(primasPantalla.getPorcentajePrimaImplicitaAMO());

			}

		   if (historicoOperacion.getFechaValor().before(primasPantalla.getFechaValorAMPO())){

			   if ("AMO".equals(primasPantalla.getClase())){
				   //PVP
				   DescripcionSituacion ultimaAccion = primasBo.getSituacion("P");
				   historicoOperacion.setUltimaAccion(ultimaAccion);
				   if (!GenericUtils.isNullOrBlank(primasPantalla.getTipoConfirmacion())&&
						   "NON".equalsIgnoreCase(primasPantalla.getTipoConfirmacion())){

					   desmarcarIndConfiCancel(historicoOperacion);

				   }else if (!GenericUtils.isNullOrBlank(primasPantalla.getTipoConfirmacion())&&
						   "CAN".equalsIgnoreCase(primasPantalla.getTipoConfirmacion())){

					   marcarIndConfiCancel(historicoOperacion);
				   }

			   }else{
				   //PVM
				   DescripcionSituacion ultimaAccion = primasBo.getSituacion("M");
				   historicoOperacion.setUltimaAccion(ultimaAccion);

				   if (!GenericUtils.isNullOrBlank(primasPantalla.getTipoConfirmacion())&&
						   "NON".equalsIgnoreCase(primasPantalla.getTipoConfirmacion())){

					   desmarcarIndConfiModif(historicoOperacion);

				   }else if (!GenericUtils.isNullOrBlank(primasPantalla.getTipoConfirmacion())&&
						   "MOD".equalsIgnoreCase(primasPantalla.getTipoConfirmacion())){

					   marcarIndConfiModif(historicoOperacion);
				   }
			   }


		   }else{

			   historicoOperacion.setNominalPago(primasPantalla.getNominalFinalA());
			   historicoOperacion.setNominalRecibo(primasPantalla.getNominalFinalA());

			   //PVM
			   DescripcionSituacion ultimaAccion = primasBo.getSituacion("M");
			   historicoOperacion.setUltimaAccion(ultimaAccion);

			   if (!GenericUtils.isNullOrBlank(primasPantalla.getTipoConfirmacion())&&
					   "NON".equalsIgnoreCase(primasPantalla.getTipoConfirmacion())){

				   desmarcarIndConfiModif(historicoOperacion);

			   }else if (!GenericUtils.isNullOrBlank(primasPantalla.getTipoConfirmacion())&&
					   "MOD".equalsIgnoreCase(primasPantalla.getTipoConfirmacion())){

				   marcarIndConfiModif(historicoOperacion);
			   }

		   }

		}


	}

	private OperacionId getOperacionId(HistoricoOperacion operacio) {
		OperacionId id = null;
			id = new OperacionId(operacio.getId().getFechaContratacion(), operacio.getId().getNumeroOperacion());
		return id;
	}

	private void marcarIndConfiModif(HistoricoOperacion oper) {
		try{
			IndicadorConfirmacion confirmacion = primasBo.getIndiConf(getOperacionId(oper));
			if(confirmacion!=null){

				List<Idioma> idiomasModif = primasBo.getIdiomasConfirmacion(oper,"M");
				List<CanalConfirmacion> listaCanalConfirmacionM;
				String tipoContrapartida = getTipoContr(oper);

				if(oper.getIndicadorBSAgente()) {
					confirmacion.setIndicadorConfirmacionModificacion(true);
					confirmacion.setIndicadorRecepcionConfirmacionModificacion(false);
					confirmacion.setCanelRecepcionConfirmacionModificacion(null);

					if (primasBo.checkPlantillaConfirmacion("M", historicoOperacion.getProductoCatalogo())) {
						listaCanalConfirmacionM = primasBo.getListaCanalConfirmacion("E", tipoContrapartida, "M");
					}else{
						listaCanalConfirmacionM = primasBo.getCanalConfirmacionMM();
					}

					String canalActual = confirmacion.getCanelEmisionConfirmacionModificacion();
					if (listaCanalConfirmacionM.size() == 1 &&
							( GenericUtils.isNullOrBlank(canalActual)|| listaCanalConfirmacionM.get(0).equals(canalActual)   )  ) {

						confirmacion.setCanelEmisionConfirmacionModificacion(listaCanalConfirmacionM.get(0).getId().getCodcanal());

					}


				}else{
					confirmacion.setIndicadorConfirmacionModificacion(false);
					confirmacion.setCanelEmisionConfirmacionModificacion(null);
					confirmacion.setIdiomaConfirmacionModificacion(null);
					confirmacion.setIndicadorRecepcionConfirmacionModificacion(true);

					listaCanalConfirmacionM = primasBo.getListaCanalConfirmacion("R", tipoContrapartida, "M");
					String canalActual = confirmacion.getCanelRecepcionConfirmacionCancelacionParcial();
					if (listaCanalConfirmacionM.size() == 1 &&
							( GenericUtils.isNullOrBlank(canalActual)|| listaCanalConfirmacionM.get(0).equals(canalActual)   )  ) {

						confirmacion.setCanelRecepcionConfirmacionModificacion(listaCanalConfirmacionM.get(0).getId().getCodcanal());

					}


				}

				setCamposConfirmacion(confirmacion,oper, confirmacion.getIndicadorConfirmacionModificacion(),
						confirmacion.getIndicadorRecepcionConfirmacionModificacion(),
						obtenerContrapa(oper),idiomasModif,listaCanalConfirmacionM,listaCanalConfirmacionM,"M");

				//TODO MIRAR QUE confirmacion vuelva modificado, y que se grabe

			}
		}catch(EntityNotFoundException ex){

		}


	}

	private void marcarIndConfiCancel(HistoricoOperacion oper) {
		try{
			IndicadorConfirmacion confirmacion = primasBo.getIndiConf(getOperacionId(oper));
			if(confirmacion!=null){

				List<Idioma> idiomasCancel = primasBo.getIdiomasConfirmacion(oper,"P");
				List<CanalConfirmacion> listaCanalConfirmacionP;
				String tipoContrapartida = getTipoContr(oper);

				if(oper.getIndicadorBSAgente()) {
					confirmacion.setIndicadorConfirmacionCancelacionParcial(true);
					confirmacion.setIndicadorRecepcionConfirmacionCancelacionParcial(false);
					confirmacion.setCanelRecepcionConfirmacionCancelacionParcial(null);

					if (primasBo.checkPlantillaConfirmacion("P", oper.getProductoCatalogo())) {
						listaCanalConfirmacionP = primasBo.getListaCanalConfirmacion("E", tipoContrapartida, "P");
					}else{
						listaCanalConfirmacionP = primasBo.getCanalConfirmacionMM();
					}
					String canalActual = confirmacion.getCanelEmisionConfirmacionCancelacionParcial();
					if (listaCanalConfirmacionP.size() == 1 &&
							( GenericUtils.isNullOrBlank(canalActual)|| listaCanalConfirmacionP.get(0).equals(canalActual)   )  ) {

						confirmacion.setCanelEmisionConfirmacionCancelacionParcial(listaCanalConfirmacionP.get(0).getId().getCodcanal());

					}

				}else{
					confirmacion.setIndicadorConfirmacionCancelacionParcial(false);
					confirmacion.setCanelEmisionConfirmacionCancelacionParcial(null);
					confirmacion.setIdiomaConfirmacionCancelacionParcial(null);
					confirmacion.setIndicadorRecepcionConfirmacionCancelacionParcial(true);

					listaCanalConfirmacionP = primasBo.getListaCanalConfirmacion("R", tipoContrapartida, "P");
					String canalActual = confirmacion.getCanelRecepcionConfirmacionCancelacionParcial();
					if (listaCanalConfirmacionP.size() == 1 &&
							( GenericUtils.isNullOrBlank(canalActual)|| listaCanalConfirmacionP.get(0).equals(canalActual)   )  ) {

						confirmacion.setCanelRecepcionConfirmacionCancelacionParcial(listaCanalConfirmacionP.get(0).getId().getCodcanal());

					}
				}

				setCamposConfirmacion(confirmacion,oper, confirmacion.getIndicadorConfirmacionCancelacionParcial(),
						confirmacion.getIndicadorRecepcionConfirmacionCancelacionParcial(),
						obtenerContrapa(oper),idiomasCancel,listaCanalConfirmacionP,listaCanalConfirmacionP,"P");

				//TODO MIRAR QUE confirmacion vuelva modificado, y que se grabe

			}
		}catch(EntityNotFoundException ex){

		}

	}

	private void desmarcarIndConfiModif(HistoricoOperacion oper) {
		try{
			IndicadorConfirmacion confirmacion = primasBo.getIndiConf(getOperacionId(oper));
			if(confirmacion!=null){

				confirmacion.setCanelEmisionConfirmacionModificacion(null);
				confirmacion.setCanelRecepcionConfirmacionModificacion(null);
				confirmacion.setIdiomaConfirmacionModificacion(null);
				confirmacion.setIndicadorConfirmacionModificacion(false);
				confirmacion.setIndicadorRecepcionConfirmacionModificacion(false);
				confirmacion.setModeloConfirmacionModificacion(null);
			}
		}catch(EntityNotFoundException ex){

		}
	}

	private void desmarcarIndConfiCancel(HistoricoOperacion oper) {
		try{
			IndicadorConfirmacion confirmacion = primasBo.getIndiConf(getOperacionId(oper));
			if(confirmacion!=null){

				confirmacion.setCanelEmisionConfirmacionCancelacionParcial(null);
				confirmacion.setCanelRecepcionConfirmacionCancelacionParcial(null);
				confirmacion.setIdiomaConfirmacionCancelacionParcial(null);
				confirmacion.setIndicadorConfirmacionCancelacionParcial(false);
				confirmacion.setIndicadorRecepcionConfirmacionCancelacionParcial(false);
				confirmacion.setModeloConfirmacionCancelacionParcial(null);
			}
		}catch(EntityNotFoundException ex){

		}


	}


	private Contrapartida obtenerContrapa(HistoricoOperacion oper){
		if (!GenericUtils.isNullOrBlank(oper.getContrapartida())){
			String contrapaId = oper.getContrapartida().getId();
			Contrapartida contrapa = primasBo.obtenerContrapartida(contrapaId);
			return contrapa;
		}
		return null;
	}

	private String getTipoContr(HistoricoOperacion oper) {

		try {
			if (!GenericUtils.isNullOrBlank(oper.getContrapartida())){
				String contrapaId = oper.getContrapartida().getId();
				Contrapartida contrapa = primasBo.obtenerContrapartida(contrapaId);

				if (!GenericUtils.isNullOrBlank(contrapa.getGrupoBancario()) &&
					"CLIENTES".equalsIgnoreCase(contrapa.getGrupoBancario().getId())){

					return "C";
				}
			}
		} catch (Exception e) {
			return "B";
		}

		return "B";

	}

	private void setCamposConfirmacion(IndicadorConfirmacion confirmacion,
			HistoricoOperacion oper,
			Boolean indicadorE, Boolean indicadorR, Contrapartida contrapa, List<Idioma> listaIdioma,
			List<CanalConfirmacion> listaCanalEmision, List<CanalConfirmacion> listaCanalRecepcion, String modo) {

		// Buscamos el idioma de la contrapa en la lista de idiomas
		String contrapaIdioma = contrapa.getIdioma();

		Idioma idiomaCMOF = boletasBo.recuperarIdiomaCMOF(contrapa, oper.getEntidad());
		Idioma idiomaContrapa = null;

		boolean idiomaFound = false;
		Idioma castellano = null;
		if(listaIdioma != null) {
			for (Iterator<Idioma> iterator = listaIdioma.iterator(); iterator.hasNext();) {
				Idioma idioma = (Idioma) iterator.next();
				String codigoIdioma = idioma.getCodigo();
				if("08".equalsIgnoreCase(codigoIdioma)) {
					// Guardamos el idioma castellano por ser el valor
					// por defecto en el caso de no encontrar el idioma
					castellano = idioma;
				}

				//SMM 31/03/2017 Idioma CMOF
				if(!GenericUtils.isNullOrBlank(idiomaCMOF) && codigoIdioma.equalsIgnoreCase(idiomaCMOF.getCodigo())) {
					if("M".equalsIgnoreCase(modo) && confirmacion.getIdiomaConfirmacionModificacion()==null) {
						confirmacion.setIdiomaConfirmacionModificacion(idioma);
					} else if("P".equalsIgnoreCase(modo) && confirmacion.getIdiomaConfirmacionCancelacionParcial()==null) {
						confirmacion.setIdiomaConfirmacionCancelacionParcial(idioma);
					}
					idiomaFound = true;
					break;
				}

				if(codigoIdioma.equalsIgnoreCase(contrapaIdioma)) {
					idiomaContrapa = idioma;
//					if("M".equalsIgnoreCase(modo) && confirmacion.getIdiomaConfirmacionModificacion()==null) {
//						confirmacion.setIdiomaConfirmacionModificacion(idioma);
//					} else if("P".equalsIgnoreCase(modo) && confirmacion.getIdiomaConfirmacionCancelacionParcial()==null) {
//						confirmacion.setIdiomaConfirmacionCancelacionParcial(idioma);
//					}
//
//					idiomaFound = true;
//					break;
				}
			}
		}

		if(!idiomaFound && indicadorE!=null && indicadorE) {
			if("M".equalsIgnoreCase(modo) && confirmacion.getIdiomaConfirmacionModificacion()==null) {
				if (GenericUtils.isNullOrBlank(idiomaContrapa)){
					confirmacion.setIdiomaConfirmacionModificacion(castellano);
				}else{
					confirmacion.setIdiomaConfirmacionModificacion(idiomaContrapa);
				}
//				confirmacion.setIdiomaConfirmacionModificacion(castellano);
			} else if("P".equalsIgnoreCase(modo) && confirmacion.getIdiomaConfirmacionCancelacionParcial()==null) {
				if (GenericUtils.isNullOrBlank(idiomaContrapa)){
					confirmacion.setIdiomaConfirmacionCancelacionParcial(castellano);
				}else{
					confirmacion.setIdiomaConfirmacionCancelacionParcial(idiomaContrapa);
				}

			}
		}

		String sentido;
		if(indicadorE!=null && indicadorE) {
			sentido = "E";
		}else{
			sentido = "R";
		}

		CanalConfDefecto canalConfDefecto ;
		String codigoCanal;


			if(indicadorE!=null && indicadorE) {

				sentido = "E";

				canalConfDefecto = cargarCanalConfDefecto(contrapa.getId(),
						oper.getProductoCatalogo().getProducat().toString(), modo,sentido,getTipoContr(oper));

				if(canalConfDefecto != null) {

					codigoCanal= canalConfDefecto.getCodcanal();

					// Si hemos encontrado idioma, tenemos que setear un canal
					// en caso contrario ya lo hemos seteado a "MM"
					CanalConfirmacion canal = buscaCanal(listaCanalEmision, codigoCanal);
					if(canal==null){
						canal = buscaCanal(listaCanalEmision, "MM");
					}
					String canalId = null;
					if (!GenericUtils.isNullOrBlank(canal) && !GenericUtils.isNullOrBlank(canal.getId())
							&& !GenericUtils.isNullOrBlank(canal.getId().getCodcanal())){
						canalId = canal.getId().getCodcanal();
					}
					if("M".equalsIgnoreCase(modo) && confirmacion.getCanelEmisionConfirmacionModificacion()==null) {
						confirmacion.setCanelEmisionConfirmacionModificacion(canalId);
					} else if("P".equalsIgnoreCase(modo)&& confirmacion.getCanelEmisionConfirmacionCancelacionParcial()==null) {
						confirmacion.setCanelEmisionConfirmacionCancelacionParcial(canalId);
					}

				}else{
				//No hemos encontrado canal por defecto
					CanalConfirmacion canal = buscaCanal(listaCanalEmision, "MM");
					String canalId = null;
					if (!GenericUtils.isNullOrBlank(canal) && !GenericUtils.isNullOrBlank(canal.getId())
							&& !GenericUtils.isNullOrBlank(canal.getId().getCodcanal())){
						canalId = canal.getId().getCodcanal();
					}
					if("M".equalsIgnoreCase(modo) && confirmacion.getCanelEmisionConfirmacionModificacion()==null) {
						confirmacion.setCanelEmisionConfirmacionModificacion(canalId);
					} else if("P".equalsIgnoreCase(modo)&& confirmacion.getCanelEmisionConfirmacionCancelacionParcial()==null) {
						confirmacion.setCanelEmisionConfirmacionCancelacionParcial(canalId);
					}
					if("M".equalsIgnoreCase(modo) && confirmacion.getIdiomaConfirmacionModificacion()==null) {
						confirmacion.setIdiomaConfirmacionModificacion(null);
					} else if("P".equalsIgnoreCase(modo) && confirmacion.getIdiomaConfirmacionCancelacionParcial()==null) {
						confirmacion.setIdiomaConfirmacionCancelacionParcial(null);
					}
				}

			}
			if(indicadorR!=null && indicadorR){
				sentido = "R";

				canalConfDefecto = cargarCanalConfDefecto(contrapa.getId(),
						historicoOperacion.getProductoCatalogo().getProducat().toString(), modo,sentido,getTipoContr(oper));

				if(canalConfDefecto != null) {

				codigoCanal= canalConfDefecto.getCodcanal();

				CanalConfirmacion canal = buscaCanal(listaCanalRecepcion, codigoCanal);
				if(canal==null){
					canal = buscaCanal(listaCanalRecepcion, "MM");
				}
				String canalId = null;
				if (!GenericUtils.isNullOrBlank(canal) && !GenericUtils.isNullOrBlank(canal.getId())
						&& !GenericUtils.isNullOrBlank(canal.getId().getCodcanal())){
					canalId = canal.getId().getCodcanal();
				}

				if("M".equalsIgnoreCase(modo)&& confirmacion.getCanelRecepcionConfirmacionModificacion()==null) {
					confirmacion.setCanelRecepcionConfirmacionModificacion(canalId);
				} else if("P".equalsIgnoreCase(modo)&& confirmacion.getCanelRecepcionConfirmacionCancelacionParcial()==null) {
					confirmacion.setCanelRecepcionConfirmacionCancelacionParcial(canalId);
				}

				}else{
					//No hemos encontrado canal por defecto
					CanalConfirmacion canal = buscaCanal(listaCanalRecepcion, "MM");

					String canalId = null;
					if (!GenericUtils.isNullOrBlank(canal) && !GenericUtils.isNullOrBlank(canal.getId())
							&& !GenericUtils.isNullOrBlank(canal.getId().getCodcanal())){
						canalId = canal.getId().getCodcanal();
					}

					if("M".equalsIgnoreCase(modo)&& confirmacion.getCanelRecepcionConfirmacionModificacion()==null) {
						confirmacion.setCanelRecepcionConfirmacionModificacion(canalId);
					} else if("P".equalsIgnoreCase(modo)&& confirmacion.getCanelRecepcionConfirmacionCancelacionParcial()==null) {
						confirmacion.setCanelRecepcionConfirmacionCancelacionParcial(canalId);
					}

				}

			}
	}

	private CanalConfDefecto cargarCanalConfDefecto(String contrapartida, String producat, String evento, String sentido, String tipcontr){

		CanalConfDefecto canalConfDefecto = null;
		CanalConfDefectoId canalPorDefectoId = new CanalConfDefectoId();
		canalPorDefectoId.setContrapartida(contrapartida);
		canalPorDefectoId.setProducat(producat);
		canalPorDefectoId.setEventoConfirmacion(evento);
		canalPorDefectoId.setSentido(sentido);
		canalPorDefectoId.setTipcontr(tipcontr);

		canalConfDefecto = primasBo.cargarCanalConfDefecto(canalPorDefectoId);

		if (GenericUtils.isNullOrBlank(canalConfDefecto)){
			canalPorDefectoId.setContrapartida("ZZZ");
			canalConfDefecto = primasBo.cargarCanalConfDefecto(canalPorDefectoId);
		}
		return canalConfDefecto;
	}

	private CanalConfirmacion buscaCanal(List<CanalConfirmacion> listaCanalConfirmacionEA2, String id) {
		if (id == null || listaCanalConfirmacionEA2 == null) {
			return null;
		}
		for (CanalConfirmacion canalConfirmacion : listaCanalConfirmacionEA2) {
			if (canalConfirmacion.getId().getCodcanal().equalsIgnoreCase(id)) {
				return canalConfirmacion;
			}
		}
		return null;
	}

	public void onConceptoChange(){
		if ("IMP".equals(primasPantalla.getClase())){
			if (historicoOperacion.getFechaValorPrimaImplicita()==null){
				primasPantalla.setFechaValorPrimaImplicita(historicoOperacion.getFechaValor());
			}else{
				primasPantalla.setFechaValorPrimaImplicita(historicoOperacion.getFechaValorPrimaImplicita());
			}
		}
		isPrimaCancelacionDisabled();
	}

	public void operacionAPantalla(){

//	Solo para el caso de Primas Implicitas, se informará este valor cuando seleccione el tipo de Concepto
//	primasPantalla.setFechaValorPrimaImplicita(historicoOperacion.getFechaValorPrimaImplicita());


	primasPantalla.setCalculado(true);
	primasPantalla.setDivisaPrimaImplicita(historicoOperacion.getDivisaPrimaImplicita());
	primasPantalla.setImportePrimaImplicita(historicoOperacion.getImportePrimaImplicita());
	primasPantalla.setTipoPrimaImplicita(historicoOperacion.getTipoPrimaImplicita());
	primasPantalla.setNominalFinalARead(true);
	primasPantalla.setNominalFinalBRead(true);

	primasPantalla.setPorcentajePrimaImplicita(historicoOperacion.getPorcentajePrimaImplicita());


	//AMO AMP
	if (fechamis.before(historicoOperacion.getFechaValor())){
		primasPantalla.setFechaValorAMPO(historicoOperacion.getId().getFechaContratacion());
	}else{
		primasPantalla.setFechaValorAMPO(fechamis);
	}

	calcularNominales();
	obtenerImplicita();
	obtenerCupon();

	//PrimaUpFront
	primasPantalla.setPrimaUpfrontChk(historicoOperacion.getIndicadorPrimaUpFront());
	primasPantalla.setTipoPrimaUpfront(historicoOperacion.getTipoPrimaUpFront());

	primasPantalla.setImporteAmoPrimaUpfront(historicoOperacion.getImportePrimaUpFront());
	primasPantalla.setDivisaPrimaPrimaUpfront(historicoOperacion.getDivisaLiquidacionUpFront());
	primasPantalla.setFechaAmoPrimaUpfront(historicoOperacion.getFechaLiquidacionUpFront());

	if (!GenericUtils.isNullOrBlank(historicoOperacion.getFechaLiquidacionUpFront()) &&
			historicoOperacion.getFechaLiquidacionUpFront().after(fechamis)){
		//Se Puede editar
		primasPantalla.setPrimaUpFrontDisabled(false);
	}else{
		primasPantalla.setPrimaUpFrontDisabled(true);
	}

	isPrimaCancelacionDisabled();

	habilitarPrimaImplicita();

	habilitarCupon();

	comprobarPorcentajes();
	}

	private void habilitarPrimaImplicita() {
		//PrimaImplicita
		if (!GenericUtils.isNullOrBlank(primasPantalla.getFechaAmoImplicita())
				&& !primasPantalla.getFechaAmoImplicita().before(primasPantalla.getFechaValorAMPO())) {
			//Se Puede editar
			primasPantalla.setPrimaImplicitaDisabled(false);
		}else{
			primasPantalla.setPrimaImplicitaDisabled(true);
		}
	}

	private void habilitarCupon() {
		//PrimaCupon
		if (!GenericUtils.isNullOrBlank(primasPantalla.getFechaAmoCupon()) &&
				!primasPantalla.getFechaAmoCupon().before(primasPantalla.getFechaValorAMPO())) {
			//Se Puede editar
			primasPantalla.setPrimaCuponDisabled(false);
		}else{
			primasPantalla.setPrimaCuponDisabled(true);
		}
	}

	private void isPrimaCancelacionDisabled() {
		//PrimaCancelacion
		if (!GenericUtils.isNullOrBlank(primasPantalla.getFechaValorAMPO()) &&
			primasPantalla.getFechaValorAMPO().after(historicoOperacion.getFechaValor())
				&& !GenericUtils.isNullOrBlank(primasPantalla.getClase())
				&& "AMO".equals(primasPantalla.getClase())){
			//Se Puede editar
			primasPantalla.setPrimaCancelDisabled(false);
		}else{
			primasPantalla.setPrimaCancelDisabled(true);
		}
	}


	public void comprobarPorcentajes(){
		if (!GenericUtils.isNullOrBlank(primasPantalla.getImporteAmoImplicita())
				&& GenericUtils.isNullOrBlank(primasPantalla.getPorcentajePrimaImplicitaAMO())){
			onPrimaAmoImplicitaChange();
		}


		if (!GenericUtils.isNullOrBlank(primasPantalla.getImporteAmoCupon())
				&& GenericUtils.isNullOrBlank(primasPantalla.getPorcentajePrimaCupon())){
			onImporteAmoCuponChange();
		}

	}

	public void onPrimasImplicitaImporteAMPOChange(){
		primasPantalla.setCalculado(true);
	}

	public Date obtenerMaxFechaAMPO(){
		return primasBo.obtenerMaxFechaAMPO(historicoOperacion);
	}
	public void onFechaValorAMPOChange(){
		if (!GenericUtils.isNullOrBlank(primasPantalla.getFechaValorAMPO())
			&& primasPantalla.getFechaValorAMPO().after(historicoOperacion.getFechaVencimiento()))
		{
			statusMessages.add(Severity.ERROR, "#{messages['boletas.pestanas.primas.errorFecha']}");
		}else if (!GenericUtils.isNullOrBlank(primasPantalla.getFechaValorAMPO()) &&
				!GenericUtils.isNullOrBlank(fechaMaxAMPO) &&
				primasPantalla.getFechaValorAMPO().before(fechaMaxAMPO)){
			statusMessages.addFromResourceBundle(Severity.ERROR, "boletas.pestanas.primas.errorFechaDos", fechaMaxAMPO);
//			statusMessages.add(Severity.ERROR, "#{messages['boletas.pestanas.primas.errorFechaDos']}");
		}else{
			isPrimaCancelacionDisabled();
			habilitarCupon();
			calcularNominales();
			primasPantalla.setCalculado(true);
		}
	}

	/*
	 * Nominal A, se informará automáticamente con el primer nominal
	 * que se encuentre en el calendario a partir de fecha desde
	 *
	 * Nominal B, se informará automáticamente con el segundo nominal
	 * distinto que se encuentre en el calendario a partir del tramo con el primer nominal
	 *
	 */
	public void calcularNominales(){
		if (!GenericUtils.isNullOrBlank(primasPantalla.getFechaValorAMPO())){

			primasPantalla.setNominalA(null);
			primasPantalla.setNominalB(null);
			primasPantalla.setNominalFinalA(null);
			primasPantalla.setNominalFinalB(null);


			List<HistoricoTramos>  nominals = primasBo.obtenerNominalTramoVigente(historicoOperacion,primasPantalla.getFechaValorAMPO(),fechaFinTramoNominalA);
//			List<HistoricoTramos>  nominals = primasBo.obtenerNominales(historicoOperacion,primasPantalla.getFechaValorAMPO());
//
			if (!GenericUtils.isNullOrBlank(nominals) && nominals.size() > 0){

		//SMM 14/11/2016 INI
				//CALCULAR SPREAD
				if (!GenericUtils.isNullOrBlank(historicoOperacion.getHistoricoOpcion()) &&
						!historicoOperacion.getHistoricoOpcion().getTipoOperacion().equalsIgnoreCase(
								nominals.get(0).getId().getTipoOperacion().getCodigo())
				){

					primasPantalla.setSpread(nominals.get(0).getSpreadOperacion());
					primasPantalla.setSpreadFinal(nominals.get(0).getSpreadOperacion());
					primasPantalla.setSpreadFinalRead(true);
					primasPantalla.setPataSpread(nominals.get(0).getId().getTipoOperacion().getCodigo());


				}else {
					List<HistoricoTramos>  spreads = new ArrayList<HistoricoTramos>();

					if (!GenericUtils.isNullOrBlank(historicoOperacion.getHistoricoOpcion())){
						spreads = primasBo.obtenerSpreadTramoVigente(historicoOperacion,primasPantalla.getFechaValorAMPO(),fechaFinTramoNominalA,historicoOperacion.getHistoricoOpcion().getTipoOperacion());
					}else{
						spreads = null;
					}


					if ((!GenericUtils.isNullOrBlank(spreads) && spreads.size() > 0) &&
							!GenericUtils.isNullOrBlank(historicoOperacion.getHistoricoOpcion()) &&
							!historicoOperacion.getHistoricoOpcion().getTipoOperacion().equalsIgnoreCase(
									spreads.get(0).getId().getTipoOperacion().getCodigo())
					){

						primasPantalla.setSpread(spreads.get(0).getSpreadOperacion());
						primasPantalla.setSpreadFinal(spreads.get(0).getSpreadOperacion());
						primasPantalla.setSpreadFinalRead(true);
						primasPantalla.setPataSpread(spreads.get(0).getId().getTipoOperacion().getCodigo());


					}else {

						primasPantalla.setSpread(null);
						primasPantalla.setSpreadFinal(null);
						primasPantalla.setSpreadFinalRead(true);
						primasPantalla.setPataSpread(null);

					}

				}
		//SMM 14/11/2016 FI CALCULO SPREAD

				if (GenericUtils.isNullOrBlank(fechaFinTramoNominalA)){

					//DEPOSITO SIMPLE

					primasPantalla.setNominalA(nominals.get(0).getNominalParaCalculo());



				}else if (nominals.size() > 1){

					if (primasPantalla.getFechaValorAMPO().after(fechaFinTramoNominalA)){

						//DEPOSITO DOBLE SOLO NOMINAL B
						//SE INFORMA NOMINAL A CON VALOR ULTIMO TRAMO
						primasPantalla.setNominalA(nominals.get(0).getNominalParaCalculo());
						primasPantalla.setNominalB(nominals.get(1).getNominalParaCalculo());

					}else{
						//DEPOSITO AMBOS NOMINALES
						primasPantalla.setNominalA(nominals.get(0).getNominalParaCalculo());
						primasPantalla.setNominalB(nominals.get(1).getNominalParaCalculo());
					}
				}else{
					salir();
					statusMessages.add(StatusMessage.Severity.ERROR, "#{messages['boletas.pestanas.primas.errornominales']}");
				}
			}

//				primasPantalla.setNominalA(nominals.get(0).getNominalParaCalculo());
//				if (nominals.size() > 1){
//					primasPantalla.setNominalB(nominals.get(1).getNominalParaCalculo());
//				}
//


		}

	}

	/**
	 * Datos de Prima implícita: se buscará el tramo correspondiente:
	 * (concepto= PRI y tipconce = IMP, y se recogerán todos los datos a excepción del %.
	 *
	 * El porcentaje de prima implícita se recogerá del entrado originalmente en
	 * la pantalla de primas implícitas (PORPRIIMP)
	 */
	public void obtenerImplicita(){
		HistoricoTramos tramoImplicita = primasBo.obtenerTramoImplicita(historicoOperacion);

		if (!GenericUtils.isNullOrBlank(tramoImplicita)){

			primasPantalla.setDivisaPrimaImplicitaAMPO(tramoImplicita.getDivisaTramo());
			primasPantalla.setImporteAmoImplicita(tramoImplicita.getImporteOperacion());
			primasPantalla.setTipoPrimaImplicitaAMPO(tramoImplicita.getId().getTipoOperacion().getCodigo());

			primasPantalla.setPorcentajePrimaImplicitaAMO(historicoOperacion.getPorcentajePrimaImplicita());

//			primasPantalla.setFechaAmoImplicita(tramoImplicita.getId().getFechaInicioTramo());
			if (historicoOperacion.getFechaValorPrimaImplicita()==null){
				primasPantalla.setFechaAmoImplicita(historicoOperacion.getFechaValor());
			}else{
				primasPantalla.setFechaAmoImplicita(historicoOperacion.getFechaValorPrimaImplicita());
			}


		}


	}


	/**
	 * Datos Cupón: se buscará el tramo correspondiente (INDIFIVA = C).
	 *
	 * El porcentaje de cupón se recogerá del entrado en la
	 * pantalla de liquidaciones (Rate introducido para clase cupón en la pantalla de
	 * liquidaciones) corresponde con RATELIQI de deri.situparm, con tipofech = ‘LI’ del tramo correspondiente
	 */
	public void obtenerCupon(){

		HistoricoTramos tramoCupon= primasBo.obtenerTramoCupon(historicoOperacion);

		if (!GenericUtils.isNullOrBlank(tramoCupon)){

			primasPantalla.setDivisaPrimaCupon(tramoCupon.getDivisaTramo());
			primasPantalla.setImporteAmoCupon(tramoCupon.getImporteOperacion());
			primasPantalla.setTipoCupon(tramoCupon.getId().getTipoOperacion().getCodigo());

			primasPantalla.setFechaAmoCupon(tramoCupon.getFechaLiquidacion());
//			if (historicoOperacion.getFechaValorPrimaImplicita()==null){
//				primasPantalla.setFechaAmoCupon(historicoOperacion.getFechaValor());
//			}else{
//				primasPantalla.setFechaAmoCupon(historicoOperacion.getFechaValorPrimaImplicita());
//			}


			HistoricoFechaFormula fechaForm = primasBo.obtenerFechaFormula(tramoCupon);
			if (!GenericUtils.isNullOrBlank(fechaForm)){
				primasPantalla.setPorcentajePrimaCupon(fechaForm.getRateLiquidacion());
			}

		}

	}

	/**
	 * 	2.	El tramo vigente será el tramo de interés (concepto ‘INT’) que cumpla
	 *
	 * 		FECHA de DIA >= FECINTR and FECHA del DIA < FECFINTR
	 *
	 * (Ojo en la pata de pago/recibo pueden estar las dos pero deberían tener el mismo nominal)
	 * con las excepciones siguientes:
	 *
	 *	a.	Si Fecha del DIA =max(FECFINTR) se toma el último tramo.
	 *	b.	Si fecha del DIA < min(FECINITR) se toma el primer tramo.
	 */
	public HistoricoTramos obtenerTramoVigente(){

		return primasBo.obtenerTramoVigente(historicoOperacion,null);
	}
	/**
	 * Importe PI = % PI x Nominal Vivo del tramo vigente para la fecha de proceso.
	 *
	 * El  nominal utilizado será siempre el nominal vivo del primer tramo vigente (ver nota 2) con respecto a la fecha de proceso.
	 *
	 * Notas:
	 * 1.	Si se introduce el porcentaje y luego se modifica el importe de la prima mandará siempre el importe (es decir siempre se utilizará el importe de la prima para construir el calendario) y, en este caso, se recalculará el porcentaje.
	 *
	 */
	public void onPorcentajePrimaImplicitaChange(){

		HistoricoTramos tramo = obtenerTramoVigente();
		if (!GenericUtils.isNullOrBlank(tramo)){
			if (!GenericUtils.isNullOrBlank(primasPantalla.getPorcentajePrimaImplicita())){

				BigDecimal nuevoImporte = tramo.getNominalParaCalculo().multiply(
						( primasPantalla.getPorcentajePrimaImplicita().divide(BigDecimal.valueOf(100L))));
				primasPantalla.setImportePrimaImplicita(nuevoImporte);

			}
		}else{
			statusMessages.add(StatusMessage.Severity.ERROR, "#{messages['boletas.pestanas.primas.errorVigente']}");
		}
	}

	public void onPrimaImplicitaChange(){
		HistoricoTramos tramo = obtenerTramoVigente();
		if (!GenericUtils.isNullOrBlank(tramo)){

			BigDecimal nuevoPorcentaje = primasPantalla.getImportePrimaImplicita().multiply(BigDecimal.valueOf(100L)).divide(
				tramo.getNominalParaCalculo(),4,RoundingMode.HALF_UP);
			primasPantalla.setPorcentajePrimaImplicita(nuevoPorcentaje);

		}else{
			statusMessages.add(StatusMessage.Severity.ERROR, "#{messages['boletas.pestanas.primas.errorVigente']}");
		}
	}


	public void onPorcentajePrimaImplicitaAMOChange(){
		//importeAmoImplicita
		//porcentajePrimaImplicitaAMO

		HistoricoTramos tramo = obtenerTramoVigente();
		if (!GenericUtils.isNullOrBlank(tramo)){
			if (!GenericUtils.isNullOrBlank(primasPantalla.getPorcentajePrimaImplicitaAMO())){

				BigDecimal nuevoImporte = tramo.getNominalParaCalculo().multiply(
						( primasPantalla.getPorcentajePrimaImplicitaAMO().divide(BigDecimal.valueOf(100L))));
				primasPantalla.setImporteAmoImplicita(nuevoImporte);

			}
		}else{
			statusMessages.add(StatusMessage.Severity.ERROR, "#{messages['boletas.pestanas.primas.errorVigente']}");
		}

	}

	public void onPorcentajePrimaImplicitaAMOCalcular(BigDecimal cambio,String clase, BigDecimal nominalB, BigDecimal nominalBFinal ){
//		HistoricoTramos tramo = obtenerTramoVigente();
//		if (!GenericUtils.isNullOrBlank(tramo)){
//
//				BigDecimal nominalCalculado =  tramo.getNominalParaCalculo();
//
//
//				//En caso de ser como el nominal B no se aplica la Amortización/Ampliacion directa
//				//sino la parte proporcional, es decir como en el caso del NominalFinalB
//				if (!GenericUtils.isNullOrZero(nominalB) && nominalB.equals(nominalCalculado) ){
			BigDecimal	nominalCalculado = nominalBFinal;
//				}else{
//
//					if ("AMO".equalsIgnoreCase(clase)) {
//						nominalCalculado = nominalCalculado.subtract(cambio);
//					}else{
//						nominalCalculado = nominalCalculado.add(cambio);
//					}
//				}
//

				BigDecimal nuevoImporte = nominalCalculado.multiply(
						( primasPantalla.getPorcentajePrimaImplicitaAMO().divide(BigDecimal.valueOf(100L))));
				primasPantalla.setImporteAmoImplicita(nuevoImporte);

//		}else{
//			statusMessages.add(StatusMessage.Severity.ERROR, "#{messages['boletas.pestanas.primas.errorVigente']}");
//		}

	}


	public void onPrimaAmoImplicitaChange(){
		HistoricoTramos tramo = obtenerTramoVigente();
		if (!GenericUtils.isNullOrBlank(tramo)){

			BigDecimal nuevoPorcentaje = primasPantalla.getImporteAmoImplicita().multiply(BigDecimal.valueOf(100L)).divide(
				tramo.getNominalParaCalculo(),4,RoundingMode.HALF_UP);
			primasPantalla.setPorcentajePrimaImplicitaAMO(nuevoPorcentaje);

		}else{
			statusMessages.add(StatusMessage.Severity.ERROR, "#{messages['boletas.pestanas.primas.errorVigente']}");
		}
	}



	public void onPorcentajePrimaCuponCalcular(BigDecimal cambio,String clase, BigDecimal nominalB, BigDecimal nominalBFinal){
//		HistoricoTramos tramo = obtenerTramoVigente();
//		if (!GenericUtils.isNullOrBlank(tramo)){
//
//				BigDecimal nominalCalculado =  tramo.getNominalParaCalculo();
//
//
//				//En caso de ser como el nominal B no se aplica la Amortización/Ampliacion directa
//				//sino la parte proporcional, es decir como en el caso del NominalFinalB
//				if (!GenericUtils.isNullOrZero(nominalB) && nominalB.equals(nominalCalculado) ){
					BigDecimal nominalCalculado = nominalBFinal;
//				}else{
//
//					if ("AMO".equalsIgnoreCase(clase)) {
//						nominalCalculado = nominalCalculado.subtract(cambio);
//					}else{
//						nominalCalculado = nominalCalculado.add(cambio);
//					}
//				}
//


				BigDecimal nuevoImporte = nominalCalculado.multiply(
						( primasPantalla.getPorcentajePrimaCupon().divide(BigDecimal.valueOf(100L))));
				primasPantalla.setImporteAmoCupon(nuevoImporte);

//		}else{
//			statusMessages.add(StatusMessage.Severity.ERROR, "#{messages['boletas.pestanas.primas.errorVigente']}");
//		}

	}

	public void  onPorcentajePrimaCuponChange(){
		//porcentajePrimaCupon
		//importeAmoCupon
		HistoricoTramos tramo = obtenerTramoVigente();
		if (!GenericUtils.isNullOrBlank(tramo)){
			if (!GenericUtils.isNullOrBlank(primasPantalla.getPorcentajePrimaCupon())){

				BigDecimal nuevoImporte = tramo.getNominalParaCalculo().multiply(
						( primasPantalla.getPorcentajePrimaCupon().divide(BigDecimal.valueOf(100L))));
				primasPantalla.setImporteAmoCupon(nuevoImporte);

			}
		}else{
			statusMessages.add(StatusMessage.Severity.ERROR, "#{messages['boletas.pestanas.primas.errorVigente']}");
		}


	}

	public void onImporteAmoCuponChange(){
		HistoricoTramos tramo = obtenerTramoVigente();
		if (!GenericUtils.isNullOrBlank(tramo)){

			BigDecimal nuevoPorcentaje = primasPantalla.getImporteAmoCupon().multiply(BigDecimal.valueOf(100L)).divide(
				tramo.getNominalParaCalculo(),4,RoundingMode.HALF_UP);
			primasPantalla.setPorcentajePrimaCupon(nuevoPorcentaje);

		}else{
			statusMessages.add(StatusMessage.Severity.ERROR, "#{messages['boletas.pestanas.primas.errorVigente']}");
		}
	}


	@Factory(value = "listaDivisasPrimasEQS")
	public void initListaDivisas() {
		this.divisasList = new ArrayList<Divisa>();

		if (historicoOperacion.getDivisaPago()!=null){
			divisasList.add(historicoOperacion.getDivisaPago());
			if (historicoOperacion.getDivisaRecibo()!=null &&
				!historicoOperacion.getDivisaRecibo().getId().equalsIgnoreCase(historicoOperacion.getDivisaPago().getId())){
				divisasList.add(historicoOperacion.getDivisaRecibo());
			}
		}else if (historicoOperacion.getDivisaRecibo()!=null){
			divisasList.add(historicoOperacion.getDivisaRecibo());
		}

	}
	private Boolean cancelacionParcial(){

		DescripcionTipoCancelacion tipocCancelacionParcial = cancelacionBo.obtenerTipoCancelacion("P");

//		String format="dd/MM/yyyy";
//		SimpleDateFormat sdf = new SimpleDateFormat(format);

//		mantOperBo.cargarUltimaCancelacion(historicoOperacion.getId().getNumeroOperacion(),historicoOperacion.getId().getFechaContratacion());
		cancelacionExitosa = false;
		CancelarOperacionReturn cancelarOperacionReturn = cancelacionBo.cancelarEQS(
				historicoOperacion.getId().getFechaModificacion(),
				historicoOperacion.getId().getFechaModificacion(),"P",
				"A",
				primasPantalla.getFechaValorAMPO(),
				primasPantalla.getFechaValorAMPO(),
				primasPantalla.getFechaAmoPrimaCancel(),
				primasPantalla.getTipoPrimaCancel(),
				primasPantalla.getImporteAmoPrimaCancel()==null?BigDecimal.ZERO:primasPantalla.getImporteAmoPrimaCancel(),
				primasPantalla.getDivisaPrimaPrimaCancel()==null?null:primasPantalla.getDivisaPrimaPrimaCancel().getId(),
				BigDecimal.ZERO,"",
				primasPantalla.getImportePrimaImplicitaAMPO(),primasPantalla.getImportePrimaImplicitaAMPO(),
				primasPantalla.getNominalFinalA(),primasPantalla.getNominalFinalA(),
				primasPantalla.getNominalFinalA(),primasPantalla.getNominalFinalA(),
				BigDecimal.ZERO, null,
				null,
				"",credentials.getUsername(),historicoOperacion);

			if(cancelarOperacionReturn != null) {
			//			if("P".equalsIgnoreCase(cancelarOperacionReturn.getCodError())) {
						if(cancelarOperacionReturn.getRet() == 0) {
							System.out.println("Cancelacion con exito");
							cancelacionExitosa = true;
							return true;
						}else{
							if (!GenericUtils.isNullOrBlank(cancelarOperacionReturn.getMensajeError())){
								System.out.println("Cancelacion sin exito:"+cancelarOperacionReturn.getMensajeError());
								statusMessages.add(StatusMessage.Severity.INFO, cancelarOperacionReturn.getMensajeError());
							}else if (!GenericUtils.isNullOrBlank(cancelarOperacionReturn.getCodError())){
								System.out.println("Cancelacion sin exito:"+cancelarOperacionReturn.getCodError());
								statusMessages.add(StatusMessage.Severity.INFO, cancelarOperacionReturn.getCodError());
							}

						}
			}else{
				statusMessages.add(StatusMessage.Severity.INFO, "SIN RETORNO");
				System.out.println("SIN RETORNO");
			}
			System.out.println("Cancelacion sin exito2");
	return false;
	}

	public Date getFechaMaxAMPO() {
		return fechaMaxAMPO;
	}

	public void setFechaMaxAMPO(Date fechaMaxAMPO) {
		this.fechaMaxAMPO = fechaMaxAMPO;
	}

	public boolean ajustarLiquidaciones(List<TramosTable> tramosTableList){
		if (GenericUtils.isNullOrBlank(tramosTableList) || tramosTableList.size() == 0 ){
			return true;
		}
		try {
			boletasBo.ajustarLiquidaciones(historicoOperacion, tramosTableList);
		} catch (BoletasBusinessException e) {
			e.printStackTrace();
			System.out.println(e.getMessage());
			statusMessages.add(Severity.ERROR, "#{messages['boletas.edicion.error.ajustar.liquidaciones']");
			return false;
		}
		return true;

	}

	public TramosTable	montarRegistro(HistoricoTramos tramo)
	{
		TramosTable	registro = new TramosTable();
		registro.setAccion("B");
		registro.setFechaInicioTramo(tramo.getId().getFechaInicioTramo());
		registro.setFechaFinTramo(tramo.getId().getFechaFinTramo());
		registro.setTipoOperacion(tramo.getId().getTipoOperacion());
		registro.setConcepto(tramo.getId().getConcepto());
		registro.setTipoConcepto(tramo.getId().getTipoConcepto());
		registro.setCodigoLiquidacion(tramo.getCodigoLiquidacion());
		registro.setComplementoCodLiqui(tramo.getComplementoCodLiqui());

		return registro;

	}

}