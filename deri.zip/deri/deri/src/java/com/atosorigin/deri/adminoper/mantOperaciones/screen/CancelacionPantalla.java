package com.atosorigin.deri.adminoper.mantOperaciones.screen;

import java.math.BigDecimal;
import java.util.Date;

import org.jboss.seam.ScopeType;
import org.jboss.seam.annotations.In;
import org.jboss.seam.annotations.Name;
import org.jboss.seam.annotations.Scope;
import org.jboss.seam.core.ResourceBundle;

import com.atosorigin.deri.model.adminoper.DescripcionMotivoCancelacion;
import com.atosorigin.deri.model.adminoper.DescripcionTradeOnTv;
import com.atosorigin.deri.util.FormatUtil;

@Name("cancelacionPantalla")
@Scope(ScopeType.CONVERSATION)
public class CancelacionPantalla {

	public static final String LABEL_AMORTIZADO = ResourceBundle.instance().getString("mantOper.cancelacion.amortizado");//"#{messages['mantOper.cancelacion.amortizado']}";
	public static final String LABEL_NOMINAL = ResourceBundle.instance().getString("mantOper.cancelacion.nominal");//"#{messages['mantOper.cancelacion.nominal']}";
	public static final String LABEL_AMORTIZADO_COBRO = ResourceBundle.instance().getString("mantOper.cancelacion.amortizadoc");//"#{messages['mantOper.cancelacion.amortizadoc']}";
	public static final String LABEL_NOMINAL_COBRO = ResourceBundle.instance().getString("mantOper.cancelacion.nominalc");//"#{messages['mantOper.cancelacion.nominalc']}";
	
	@In
	FormatUtil formatUtil;
	
	private String tipocanc;
	private String sentamor;
	private String fechacan;
	private String fecvalcan;
	private String fechaliq;
	private String tiprican;
	private BigDecimal imprican;
	private String diprican;
	private Boolean indefcds;
	private String obsercds;
	private BigDecimal impcanof;
	private String divicoof;
	private BigDecimal amortiza;
	private BigDecimal amortizap;
	private BigDecimal nominalt;
	private BigDecimal nominaltp;
	private String observac;
	
	private BigDecimal importePrimaSub;
	private DescripcionMotivoCancelacion motivoCancel;
	private Long claveMurexRelacionada;   
	
	
	
	private String indiPostNegociacionOTC1;
	private String indiPostNegociacionOTC2;
	private String indiPostNegociacionOTC3;
	private String indiPostNegociacionOTC4;
	private String indiPostNegociacionOTC5;
	

	private String usuarioDecisor;
	private String usuarioEjecutor;
	
	private String fechaEjec;
	
	private DescripcionTradeOnTv tradeTv;
	private String complexTradeId;
	private String isinInstrumento;
	 
	
	private BigDecimal valorActual;
	private BigDecimal valorAnual;
	private Boolean indicadorNormaIV;

	
	// Ocultos
	private BigDecimal nomitotap;
	private BigDecimal nomitota;
	
	// Activar o desactivar campos
	private Boolean activarSentoamor = false;
	private Boolean activarAmortiza = true;
	
	// Mostrar u ocultar campos
	private Boolean mostrarAmortizap = false;
	private Boolean mostrarNominaltp = false;
	
	// Labels
	private String labelAmortiza = LABEL_AMORTIZADO;
	private String labelNominalt = LABEL_NOMINAL;
	
	public void reset() {
		this.tipocanc = null;
		this.sentamor = null;
		this.fechacan = null;
		this.fecvalcan = null;
		this.fechaliq = null;
		this.tiprican = null;
		this.imprican = null;
		this.diprican = null;
		this.indefcds = null;
		this.obsercds = null;
		this.impcanof = null;
		this.divicoof = null;
		this.amortiza = null;
		this.amortizap = null;
		this.nominalt = null;
		this.nominaltp = null;
		this.observac = null;
		
		this.importePrimaSub = null;
		this.claveMurexRelacionada =null;
		this.motivoCancel=null;
		
		
		this.indiPostNegociacionOTC1 = null;
		this.indiPostNegociacionOTC2 = null;
		this.indiPostNegociacionOTC3 = null;
		this.indiPostNegociacionOTC4 = null;
		this.indiPostNegociacionOTC5 = null;
		

		this.usuarioDecisor = null;
		this.usuarioEjecutor = null;
		
		this.fechaEjec = null;
		
		this.tradeTv = null;
		this.complexTradeId = null;
		this.isinInstrumento = null;

		
		this.valorActual = null;
		this.valorAnual = null;
		this.indicadorNormaIV = null;

		
		
		// Ocultos
		this.nomitotap = null;
		this.nomitota = null;
		
		// Activar o desactivar campos
		this.activarSentoamor = false;
		this.activarAmortiza = true;
		
		// Mostrar u ocultar campos
		this.mostrarAmortizap = false;
		this.mostrarNominaltp = false;
		
		// Labels
		this.labelAmortiza = LABEL_AMORTIZADO;
		this.labelNominalt = LABEL_NOMINAL;
	}
	
	public String getTipocanc() {
		return tipocanc;
	}
	public void setTipocanc(String tipocanc) {
		this.tipocanc = tipocanc;
	}
	public String getSentamor() {
		return sentamor;
	}
	public void setSentamor(String sentamor) {
		this.sentamor = sentamor;
	}
	public String getFechacan() {
		return fechacan;
	}
	public void setFechacan(String fechacan) {
		this.fechacan = fechacan;
	}
	public void setFechacan(Date fechacan) {
		this.fechacan = formatUtil.getFormattedDate(fechacan);
	}
	public String getFecvalcan() {
		return fecvalcan;
	}
	public void setFecvalcan(String fecvalcan) {
		this.fecvalcan = fecvalcan;
	}
	public void setFecvalcan(Date fecvalcan) {
		this.fecvalcan = formatUtil.getFormattedDate(fecvalcan);
	}
	public String getFechaliq() {
		return fechaliq;
	}
	public void setFechaliq(String fechaliq) {
		this.fechaliq = fechaliq;
	}
	public void setFechaliq(Date fechaliq) {
		this.fechaliq = formatUtil.getFormattedDate(fechaliq);
	}
	public String getTiprican() {
		return tiprican;
	}
	public void setTiprican(String tiprican) {
		this.tiprican = tiprican;
	}
	public BigDecimal getImprican() {
		return imprican;
	}
	public void setImprican(BigDecimal imprican) {
		this.imprican = imprican;
	}
	public String getDiprican() {
		return diprican;
	}
	public void setDiprican(String diprican) {
		this.diprican = diprican;
	}
	public Boolean getIndefcds() {
		return indefcds;
	}
	public void setIndefcds(Boolean indefcds) {
		this.indefcds = indefcds;
	}
	public String getObsercds() {
		return obsercds;
	}
	public void setObsercds(String obsercds) {
		this.obsercds = obsercds;
	}
	public BigDecimal getImpcanof() {
		return impcanof;
	}
	public void setImpcanof(BigDecimal impcanof) {
		this.impcanof = impcanof;
	}
	public String getDivicoof() {
		return divicoof;
	}
	public void setDivicoof(String divicoof) {
		this.divicoof = divicoof;
	}
	public String getObservac() {
		return observac;
	}
	public void setObservac(String observac) {
		this.observac = observac;
	}
	public Boolean getActivarSentoamor() {
		return activarSentoamor;
	}
	public void setActivarSentoamor(Boolean activarSentoamor) {
		this.activarSentoamor = activarSentoamor;
	}
	public Boolean getActivarAmortiza() {
		return activarAmortiza;
	}
	public void setActivarAmortiza(Boolean activarAmortiza) {
		this.activarAmortiza = activarAmortiza;
	}
	public Boolean getMostrarAmortizap() {
		return mostrarAmortizap;
	}
	public void setMostrarAmortizap(Boolean mostrarAmortizap) {
		this.mostrarAmortizap = mostrarAmortizap;
	}
	public Boolean getMostrarNominaltp() {
		return mostrarNominaltp;
	}
	public void setMostrarNominaltp(Boolean mostrarNominaltp) {
		this.mostrarNominaltp = mostrarNominaltp;
	}
	public String getLabelAmortiza() {
		return labelAmortiza;
	}
	public void setLabelAmortiza(String labelAmortiza) {
		this.labelAmortiza = labelAmortiza;
	}
	public String getLabelNominalt() {
		return labelNominalt;
	}
	public void setLabelNominalt(String labelNominalt) {
		this.labelNominalt = labelNominalt;
	}
	public BigDecimal getAmortiza() {
		return amortiza;
	}
	public void setAmortiza(BigDecimal amortiza) {
		this.amortiza = amortiza;
	}
	public BigDecimal getAmortizap() {
		return amortizap;
	}
	public void setAmortizap(BigDecimal amortizap) {
		this.amortizap = amortizap;
	}
	public BigDecimal getNominalt() {
		return nominalt;
	}
	public void setNominalt(BigDecimal nominalt) {
		this.nominalt = nominalt;
	}
	public BigDecimal getNominaltp() {
		return nominaltp;
	}
	public void setNominaltp(BigDecimal nominaltp) {
		this.nominaltp = nominaltp;
	}
	public BigDecimal getNomitotap() {
		return nomitotap;
	}
	public void setNomitotap(BigDecimal nomitotap) {
		this.nomitotap = nomitotap;
	}
	public BigDecimal getNomitota() {
		return nomitota;
	}
	public void setNomitota(BigDecimal nomitota) {
		this.nomitota = nomitota;
	}

	public BigDecimal getImportePrimaSub() {
		return importePrimaSub;
	}

	public void setImportePrimaSub(BigDecimal importePrimaSub) {
		this.importePrimaSub = importePrimaSub;
	}

	public DescripcionMotivoCancelacion getMotivoCancel() {
		return motivoCancel;
	}

	public void setMotivoCancel(DescripcionMotivoCancelacion motivoCancel) {
		this.motivoCancel = motivoCancel;
	}

	public Long getClaveMurexRelacionada() {
		return claveMurexRelacionada;
	}

	public void setClaveMurexRelacionada(Long claveMurexRelacionada) {
		this.claveMurexRelacionada = claveMurexRelacionada;
	}

	public String getIndiPostNegociacionOTC1() {
		return indiPostNegociacionOTC1;
	}

	public void setIndiPostNegociacionOTC1(String indiPostNegociacionOTC1) {
		this.indiPostNegociacionOTC1 = indiPostNegociacionOTC1;
	}

	public String getIndiPostNegociacionOTC2() {
		return indiPostNegociacionOTC2;
	}

	public void setIndiPostNegociacionOTC2(String indiPostNegociacionOTC2) {
		this.indiPostNegociacionOTC2 = indiPostNegociacionOTC2;
	}

	public String getIndiPostNegociacionOTC3() {
		return indiPostNegociacionOTC3;
	}

	public void setIndiPostNegociacionOTC3(String indiPostNegociacionOTC3) {
		this.indiPostNegociacionOTC3 = indiPostNegociacionOTC3;
	}

	public String getIndiPostNegociacionOTC4() {
		return indiPostNegociacionOTC4;
	}

	public void setIndiPostNegociacionOTC4(String indiPostNegociacionOTC4) {
		this.indiPostNegociacionOTC4 = indiPostNegociacionOTC4;
	}

	public String getIndiPostNegociacionOTC5() {
		return indiPostNegociacionOTC5;
	}

	public void setIndiPostNegociacionOTC5(String indiPostNegociacionOTC5) {
		this.indiPostNegociacionOTC5 = indiPostNegociacionOTC5;
	}

	public String getUsuarioDecisor() {
		return usuarioDecisor;
	}

	public void setUsuarioDecisor(String usuarioDecisor) {
		this.usuarioDecisor = usuarioDecisor;
	}

	public String getUsuarioEjecutor() {
		return usuarioEjecutor;
	}

	public void setUsuarioEjecutor(String usuarioEjecutor) {
		this.usuarioEjecutor = usuarioEjecutor;
	}

	public String getFechaEjec() {
		return fechaEjec;
	}

	public void setFechaEjec(String fechaEjec) {
		this.fechaEjec = fechaEjec;
	}

	public DescripcionTradeOnTv getTradeTv() {
		return tradeTv;
	}

	public void setTradeTv(DescripcionTradeOnTv tradeTv) {
		this.tradeTv = tradeTv;
	}

	public String getComplexTradeId() {
		return complexTradeId;
	}

	public void setComplexTradeId(String complexTradeId) {
		this.complexTradeId = complexTradeId;
	}

	public String getIsinInstrumento() {
		return isinInstrumento;
	}

	public void setIsinInstrumento(String isinInstrumento) {
		this.isinInstrumento = isinInstrumento;
	}

	public BigDecimal getValorActual() {
		return valorActual;
	}

	public void setValorActual(BigDecimal valorActual) {
		this.valorActual = valorActual;
	}

	public BigDecimal getValorAnual() {
		return valorAnual;
	}

	public void setValorAnual(BigDecimal valorAnual) {
		this.valorAnual = valorAnual;
	}

	public Boolean getIndicadorNormaIV() {
		return indicadorNormaIV;
	}

	public void setIndicadorNormaIV(Boolean indicadorNormaIV) {
		this.indicadorNormaIV = indicadorNormaIV;
	}
}
