package com.atosorigin.deri.adminoper.mantOperaciones.screen;

import java.math.BigDecimal;
import java.util.Date;

import org.jboss.seam.ScopeType;
import org.jboss.seam.annotations.In;
import org.jboss.seam.annotations.Name;
import org.jboss.seam.annotations.Scope;
import org.jboss.seam.core.ResourceBundle;

import com.atosorigin.deri.model.adminoper.DescripcionMotivoCancelacion;
import com.atosorigin.deri.model.parametrizacion.Divisa;
import com.atosorigin.deri.util.FormatUtil;

@Name("primasEQSPantalla")
@Scope(ScopeType.CONVERSATION)
public class PrimasEQSPantalla {



	private String clase;
	private String tipoPrimaImplicita;
	private BigDecimal importePrimaImplicita;
	private Divisa divisaPrimaImplicita;
	private Date fechaValorPrimaImplicita;
	
	private BigDecimal porcentajePrimaImplicita;
	private boolean implicitaChk;

	
	private BigDecimal nominalA;
	private BigDecimal nominalFinalA;
	private BigDecimal nominalB;
	private BigDecimal nominalFinalB;
	
	private BigDecimal spread;
	private BigDecimal spreadFinal;
	private String pataSpread;
	
	private BigDecimal importeAmoImplicita;
	private BigDecimal importeAmoCupon;
	private Date fechaAmoImplicita;
	private Date fechaAmoCupon;
	
	private BigDecimal porcentajePrimaCupon;
	private Divisa divisaPrimaCupon;
	
	
	private BigDecimal importePrimaImplicitaAMPO;
	private boolean cuponChk;
	private String tipoCupon;
	private BigDecimal porcentajePrimaImplicitaAMO;
	private Date fechaValorAMPO;
	private Divisa divisaPrimaImplicitaAMPO;
	private String tipoPrimaImplicitaAMPO;
	
	private String tipoConfirmacion;
	
	private boolean primaUpfrontChk;
	private String tipoPrimaUpfront;
	private BigDecimal importeAmoPrimaUpfront;
	private Divisa divisaPrimaPrimaUpfront;
	private Date fechaAmoPrimaUpfront;
	private Boolean primaUpFrontDisabled;
	
	private boolean primaCancelChk;
	private String tipoPrimaCancel;
	private BigDecimal importeAmoPrimaCancel;
	private Divisa divisaPrimaPrimaCancel;
	private Date fechaAmoPrimaCancel;
	private Boolean primaCancelDisabled;
	
	private Boolean primaImplicitaDisabled;
	private Boolean primaCuponDisabled;
	private Boolean nominalFinalARead;
	private Boolean nominalFinalBRead;
	private Boolean spreadFinalRead;
	
	private Boolean calculado;
	
	
	public String getClase() {
		return clase;
	}

	public void setClase(String clase) {
		this.clase = clase;
	}

	public String getTipoPrimaImplicita() {
		return tipoPrimaImplicita;
	}

	public void setTipoPrimaImplicita(String tipoPrimaImplicita) {
		this.tipoPrimaImplicita = tipoPrimaImplicita;
	}

	public BigDecimal getImportePrimaImplicita() {
		return importePrimaImplicita;
	}

	public void setImportePrimaImplicita(BigDecimal importePrimaImplicita) {
		this.importePrimaImplicita = importePrimaImplicita;
	}

	public Divisa getDivisaPrimaImplicita() {
		return divisaPrimaImplicita;
	}

	public void setDivisaPrimaImplicita(Divisa divisaPrimaImplicita) {
		this.divisaPrimaImplicita = divisaPrimaImplicita;
	}

	public Date getFechaValorPrimaImplicita() {
		return fechaValorPrimaImplicita;
	}

	public void setFechaValorPrimaImplicita(Date fechaValorPrimaImplicita) {
		this.fechaValorPrimaImplicita = fechaValorPrimaImplicita;
	}

	public BigDecimal getPorcentajePrimaImplicita() {
		return porcentajePrimaImplicita;
	}

	public void setPorcentajePrimaImplicita(BigDecimal porcentajePrimaImplicita) {
		this.porcentajePrimaImplicita = porcentajePrimaImplicita;
	}

	public boolean isImplicitaChk() {
		return implicitaChk;
	}

	public void setImplicitaChk(boolean implicitaChk) {
		this.implicitaChk = implicitaChk;
	}

	public BigDecimal getNominalA() {
		return nominalA;
	}

	public void setNominalA(BigDecimal nominalA) {
		this.nominalA = nominalA;
	}

	public BigDecimal getNominalFinalA() {
		return nominalFinalA;
	}

	public void setNominalFinalA(BigDecimal nominalFinalA) {
		this.nominalFinalA = nominalFinalA;
	}

	public BigDecimal getNominalB() {
		return nominalB;
	}

	public void setNominalB(BigDecimal nominalB) {
		this.nominalB = nominalB;
	}

	public BigDecimal getNominalFinalB() {
		return nominalFinalB;
	}

	public void setNominalFinalB(BigDecimal nominalFinalB) {
		this.nominalFinalB = nominalFinalB;
	}

	public Date getFechaAmoImplicita() {
		return fechaAmoImplicita;
	}

	public void setFechaAmoImplicita(Date fechaAmoImplicita) {
		this.fechaAmoImplicita = fechaAmoImplicita;
	}

	public Date getFechaAmoCupon() {
		return fechaAmoCupon;
	}

	public void setFechaAmoCupon(Date fechaAmoCupon) {
		this.fechaAmoCupon = fechaAmoCupon;
	}

	public BigDecimal getImporteAmoImplicita() {
		return importeAmoImplicita;
	}

	public void setImporteAmoImplicita(BigDecimal importeAmoImplicita) {
		this.importeAmoImplicita = importeAmoImplicita;
	}

	public BigDecimal getImporteAmoCupon() {
		return importeAmoCupon;
	}

	public void setImporteAmoCupon(BigDecimal importeAmoCupon) {
		this.importeAmoCupon = importeAmoCupon;
	}

	public BigDecimal getPorcentajePrimaCupon() {
		return porcentajePrimaCupon;
	}

	public void setPorcentajePrimaCupon(BigDecimal porcentajePrimaCupon) {
		this.porcentajePrimaCupon = porcentajePrimaCupon;
	}

	public Divisa getDivisaPrimaCupon() {
		return divisaPrimaCupon;
	}

	public void setDivisaPrimaCupon(Divisa divisaPrimaCupon) {
		this.divisaPrimaCupon = divisaPrimaCupon;
	}

	public BigDecimal getImportePrimaImplicitaAMPO() {
		return importePrimaImplicitaAMPO;
	}

	public void setImportePrimaImplicitaAMPO(BigDecimal importePrimaImplicitaAMPO) {
		this.importePrimaImplicitaAMPO = importePrimaImplicitaAMPO;
	}

	public boolean isCuponChk() {
		return cuponChk;
	}

	public void setCuponChk(boolean cuponChk) {
		this.cuponChk = cuponChk;
	}

	public String getTipoCupon() {
		return tipoCupon;
	}

	public void setTipoCupon(String tipoCupon) {
		this.tipoCupon = tipoCupon;
	}

	public BigDecimal getPorcentajePrimaImplicitaAMO() {
		return porcentajePrimaImplicitaAMO;
	}

	public void setPorcentajePrimaImplicitaAMO(
			BigDecimal porcentajePrimaImplicitaAMO) {
		this.porcentajePrimaImplicitaAMO = porcentajePrimaImplicitaAMO;
	}

	public Date getFechaValorAMPO() {
		return fechaValorAMPO;
	}

	public void setFechaValorAMPO(Date fechaValorAMPO) {
		this.fechaValorAMPO = fechaValorAMPO;
	}

	public Divisa getDivisaPrimaImplicitaAMPO() {
		return divisaPrimaImplicitaAMPO;
	}

	public void setDivisaPrimaImplicitaAMPO(Divisa divisaPrimaImplicitaAMPO) {
		this.divisaPrimaImplicitaAMPO = divisaPrimaImplicitaAMPO;
	}

	public String getTipoPrimaImplicitaAMPO() {
		return tipoPrimaImplicitaAMPO;
	}

	public void setTipoPrimaImplicitaAMPO(String tipoPrimaImplicitaAMPO) {
		this.tipoPrimaImplicitaAMPO = tipoPrimaImplicitaAMPO;
	}

	public Boolean getCalculado() {
		return calculado;
	}

	public void setCalculado(Boolean calculado) {
		this.calculado = calculado;
	}

	public boolean isPrimaUpfrontChk() {
		return primaUpfrontChk;
	}

	public void setPrimaUpfrontChk(boolean primaUpfrontChk) {
		this.primaUpfrontChk = primaUpfrontChk;
	}

	public String getTipoPrimaUpfront() {
		return tipoPrimaUpfront;
	}

	public void setTipoPrimaUpfront(String tipoPrimaUpfront) {
		this.tipoPrimaUpfront = tipoPrimaUpfront;
	}

	public BigDecimal getImporteAmoPrimaUpfront() {
		return importeAmoPrimaUpfront;
	}

	public void setImporteAmoPrimaUpfront(BigDecimal importeAmoPrimaUpfront) {
		this.importeAmoPrimaUpfront = importeAmoPrimaUpfront;
	}

	public Divisa getDivisaPrimaPrimaUpfront() {
		return divisaPrimaPrimaUpfront;
	}

	public void setDivisaPrimaPrimaUpfront(Divisa divisaPrimaPrimaUpfront) {
		this.divisaPrimaPrimaUpfront = divisaPrimaPrimaUpfront;
	}

	public Date getFechaAmoPrimaUpfront() {
		return fechaAmoPrimaUpfront;
	}

	public void setFechaAmoPrimaUpfront(Date fechaAmoPrimaUpfront) {
		this.fechaAmoPrimaUpfront = fechaAmoPrimaUpfront;
	}

	public boolean isPrimaCancelChk() {
		return primaCancelChk;
	}

	public void setPrimaCancelChk(boolean primaCancelChk) {
		this.primaCancelChk = primaCancelChk;
	}

	public String getTipoPrimaCancel() {
		return tipoPrimaCancel;
	}

	public void setTipoPrimaCancel(String tipoPrimaCancel) {
		this.tipoPrimaCancel = tipoPrimaCancel;
	}

	public BigDecimal getImporteAmoPrimaCancel() {
		return importeAmoPrimaCancel;
	}

	public void setImporteAmoPrimaCancel(BigDecimal importeAmoPrimaCancel) {
		this.importeAmoPrimaCancel = importeAmoPrimaCancel;
	}

	public Divisa getDivisaPrimaPrimaCancel() {
		return divisaPrimaPrimaCancel;
	}

	public void setDivisaPrimaPrimaCancel(Divisa divisaPrimaPrimaCancel) {
		this.divisaPrimaPrimaCancel = divisaPrimaPrimaCancel;
	}

	public Date getFechaAmoPrimaCancel() {
		return fechaAmoPrimaCancel;
	}

	public void setFechaAmoPrimaCancel(Date fechaAmoPrimaCancel) {
		this.fechaAmoPrimaCancel = fechaAmoPrimaCancel;
	}

	public String getTipoConfirmacion() {
		return tipoConfirmacion;
	}

	public void setTipoConfirmacion(String tipoConfirmacion) {
		this.tipoConfirmacion = tipoConfirmacion;
	}

	public Boolean getPrimaUpFrontDisabled() {
		return primaUpFrontDisabled;
	}

	public void setPrimaUpFrontDisabled(Boolean primaUpFrontDisabled) {
		this.primaUpFrontDisabled = primaUpFrontDisabled;
	}

	public Boolean getPrimaCancelDisabled() {
		return primaCancelDisabled;
	}

	public void setPrimaCancelDisabled(Boolean primaCancelDisabled) {
		this.primaCancelDisabled = primaCancelDisabled;
	}

	public Boolean getPrimaImplicitaDisabled() {
		return primaImplicitaDisabled;
	}

	public void setPrimaImplicitaDisabled(Boolean primaImplicitaDisabled) {
		this.primaImplicitaDisabled = primaImplicitaDisabled;
	}

	public Boolean getPrimaCuponDisabled() {
		return primaCuponDisabled;
	}

	public void setPrimaCuponDisabled(Boolean primaCuponDisabled) {
		this.primaCuponDisabled = primaCuponDisabled;
	}

	public Boolean getNominalFinalARead() {
		return nominalFinalARead;
	}

	public void setNominalFinalARead(Boolean nominalFinalARead) {
		this.nominalFinalARead = nominalFinalARead;
	}

	public Boolean getNominalFinalBRead() {
		return nominalFinalBRead;
	}

	public void setNominalFinalBRead(Boolean nominalFinalBRead) {
		this.nominalFinalBRead = nominalFinalBRead;
	}

	public BigDecimal getSpread() {
		return spread;
	}

	public void setSpread(BigDecimal spread) {
		this.spread = spread;
	}

	public BigDecimal getSpreadFinal() {
		return spreadFinal;
	}

	public void setSpreadFinal(BigDecimal spreadFinal) {
		this.spreadFinal = spreadFinal;
	}

	public Boolean getSpreadFinalRead() {
		return spreadFinalRead;
	}

	public void setSpreadFinalRead(Boolean spreadFinalRead) {
		this.spreadFinalRead = spreadFinalRead;
	}

	public String getPataSpread() {
		return pataSpread;
	}

	public void setPataSpread(String pataSpread) {
		this.pataSpread = pataSpread;
	}
}
