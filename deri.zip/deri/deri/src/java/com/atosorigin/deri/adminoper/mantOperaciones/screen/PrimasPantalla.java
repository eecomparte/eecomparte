package com.atosorigin.deri.adminoper.mantOperaciones.screen;

import java.math.BigDecimal;
import java.util.Date;

import org.jboss.seam.ScopeType;
import org.jboss.seam.annotations.In;
import org.jboss.seam.annotations.Name;
import org.jboss.seam.annotations.Scope;
import org.jboss.seam.core.ResourceBundle;

import com.atosorigin.deri.model.adminoper.DescripcionMotivoCancelacion;
import com.atosorigin.deri.model.parametrizacion.Divisa;
import com.atosorigin.deri.util.FormatUtil;

@Name("primasPantalla")
@Scope(ScopeType.CONVERSATION)
public class PrimasPantalla {



	private String clase;
	private String tipoPrimaImplicita;
	private BigDecimal importePrimaImplicita;
	private Divisa divisaPrimaImplicita;
	private Date fechaValorPrimaImplicita;


	public String getClase() {
		return clase;
	}

	public void setClase(String clase) {
		this.clase = clase;
	}

	public String getTipoPrimaImplicita() {
		return tipoPrimaImplicita;
	}

	public void setTipoPrimaImplicita(String tipoPrimaImplicita) {
		this.tipoPrimaImplicita = tipoPrimaImplicita;
	}

	public BigDecimal getImportePrimaImplicita() {
		return importePrimaImplicita;
	}

	public void setImportePrimaImplicita(BigDecimal importePrimaImplicita) {
		this.importePrimaImplicita = importePrimaImplicita;
	}

	public Divisa getDivisaPrimaImplicita() {
		return divisaPrimaImplicita;
	}

	public void setDivisaPrimaImplicita(Divisa divisaPrimaImplicita) {
		this.divisaPrimaImplicita = divisaPrimaImplicita;
	}

	public Date getFechaValorPrimaImplicita() {
		return fechaValorPrimaImplicita;
	}

	public void setFechaValorPrimaImplicita(Date fechaValorPrimaImplicita) {
		this.fechaValorPrimaImplicita = fechaValorPrimaImplicita;
	}
}
