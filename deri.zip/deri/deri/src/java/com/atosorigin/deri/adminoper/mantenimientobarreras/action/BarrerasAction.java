package com.atosorigin.deri.adminoper.mantenimientobarreras.action;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Set;

import javax.persistence.EntityManager;

import org.jboss.seam.ScopeType;
import org.jboss.seam.annotations.Factory;
import org.jboss.seam.annotations.In;
import org.jboss.seam.annotations.Name;
import org.jboss.seam.annotations.Out;
import org.jboss.seam.annotations.Scope;
import org.jboss.seam.annotations.datamodel.DataModel;
import org.jboss.seam.annotations.datamodel.DataModelSelection;
import org.jboss.seam.core.Conversation;
import org.jboss.seam.international.StatusMessage.Severity;
import org.jboss.seam.security.Credentials;
import org.jboss.seam.security.Identity;

import com.atosorigin.common.action.ModoPantalla;
import com.atosorigin.common.action.PaginatedListAction;
import com.atosorigin.common.constantes.Constantes;
import com.atosorigin.common.formvalidator.FormValidator;
import com.atosorigin.common.utils.GenericUtils;
import com.atosorigin.deri.adminoper.boletas.action.BoletasAction.BoletasStates;
import com.atosorigin.deri.adminoper.boletas.business.BoletasBo;
import com.atosorigin.deri.adminoper.mantbarreras.business.MantenimientoBarrerasBo;
import com.atosorigin.deri.adminoper.mantenimientobarreras.screen.BarrerasPantalla;
import com.atosorigin.deri.common.dbLock.DbLockService;
import com.atosorigin.deri.model.adminoper.HistoricoBarrera;
import com.atosorigin.deri.model.adminoper.HistoricoBarreraId;
import com.atosorigin.deri.model.adminoper.HistoricoSubyacente;
import com.atosorigin.deri.model.gestionoperaciones.HistoricoOperacion;
import com.atosorigin.deri.model.gestionoperaciones.HistoricoOperacionId;
import com.atosorigin.deri.util.EntityUtil;
import com.atosorigin.deri.util.ErrorMessageBoxAction;
import com.atosorigin.deri.util.MessageBoxAction;


@Name("barrerasAction")
@Scope(ScopeType.CONVERSATION)
@FormValidator
public class BarrerasAction extends PaginatedListAction {

	@Out(required = false, value = "barrerasMessageBoxAction")
	private MessageBoxAction messageBoxAction;
	
	
	@In(create=true)
	@Out(value="barrerasPantalla")
	protected BarrerasPantalla barrerasPantalla;
	
	//FLM: Antes de llamara a subyacentes debemos poner aqui el tipo barrera
	@Out(value = "origenPantalla" ,required=false )
	protected String pantallaOrigen="BAR"; // Bar es por defecto, pero no es correcto, antes de llamar se le debe pasar el tipo de subyacente
	
	
	@In(value = "#{mantenimientoBarrerasBo}")
	protected MantenimientoBarrerasBo mantenimientoBarrerasBo;

	@In
	private HistoricoOperacion historicoOperacion;
	
	@In
	private BoletasStates boletaState;

	@In
	EntityManager entityManager; 

	@In
	private ErrorMessageBoxAction errorMessageBoxAction;
	
    @In Credentials credentials;

    
	@In(value = "dbLockService", create = true)
	private DbLockService dbLockService;

	@In(required=false)
	private String forcedReturnView;
	

	@In(required=false)
	HistoricoOperacionId historicoOperacionBloqueadoId;

	
	@In("#{boletasBo}")
	protected BoletasBo boletasBo;
   
    
	@DataModel(value="listaDtBarreras")
	protected List<HistoricoBarrera> listadoHistoricoBarrera;
	
	@DataModelSelection(value="listaDtBarreras")
	protected HistoricoBarrera historicoBarreraSelect;

	
	private Boolean modificar = false;
	
	public void init() {
		if (errorMessageBoxAction!=null) {
			errorMessageBoxAction.setReRender(null);
			errorMessageBoxAction.setOnComplete(null);
		}

		//barrerasPantalla.setNumBarreras(mantenimientoBarrerasBo.obtenerNumeroBarreras(historicoOperacion));
		if (!GenericUtils.isNullOrBlank(historicoOperacion.getHistoricoBarreras())){
			barrerasPantalla.setNumBarreras(historicoOperacion.getHistoricoBarreras().size());
		} else {
			barrerasPantalla.setNumBarreras(0);
		}
		//FLM: puede ser null
		String codigoBarrera="";
		
		if ( historicoOperacion.getHistoricoOpcion() != null && historicoOperacion.getHistoricoOpcion().getModobarr() != null)
			codigoBarrera=historicoOperacion.getHistoricoOpcion().getModobarr().getCodigo();		
		if(barrerasPantalla.getNumBarreras() == 0){
			barrerasPantalla.setBotonAltaActivo(true);
		}else if (barrerasPantalla.getNumBarreras() == 1) {		
			if ("SI".equals(codigoBarrera)){
				barrerasPantalla.setBotonAltaActivo(false);
			}else{
				barrerasPantalla.setBotonAltaActivo(true);
			}
		}else if (barrerasPantalla.getNumBarreras() == 2) {
			if ("DO".equals(codigoBarrera) || "DT".equals(codigoBarrera)){
				barrerasPantalla.setBotonAltaActivo(false);
			}else{
				barrerasPantalla.setBotonAltaActivo(true);
				
			}
		}
		}

	//FLM: hemos puesto esto en un init que se ejecuta siempre.
	// al volver tambien se tendria que hacer una carga inicial
	public void cargaInicial(){
	}

	@Override
	public void refrescarListaExcel() {
		// TODO Auto-generated method stub
		
	}

	//Métodos necesarios para pantallas con grids.
	//Es necesario implementar estos métodos abstractos de PaginatedListAction
	@Override
	public List<HistoricoBarrera> getDataTableList() {
		return listadoHistoricoBarrera;
	}

	@Override
	@SuppressWarnings("unchecked")
	public void setDataTableList(List<?> dataTableList) {
		listadoHistoricoBarrera =(List<HistoricoBarrera>) dataTableList;
	}

	@Override
	protected void refreshListInternal(){
		listadoHistoricoBarrera=null;
	}
	@Factory("listaDtBarreras")
	public void initLista() {
		setExportExcel(false);
		if (GenericUtils.isNullOrBlank(paginationData.getOrderKey())){
			paginationData.setOrderKey("ordenbar");
		}
		
		listadoHistoricoBarrera =  new ArrayList<HistoricoBarrera>(historicoOperacion.getHistoricoBarreras());
		Collections.sort(listadoHistoricoBarrera, new Comparator<HistoricoBarrera>() {

			public int compare(HistoricoBarrera o1, HistoricoBarrera o2) {
				if(o1.getOrdenbar()==null||o1.getOrdenbar()==null){
					return 0;
				}
				return o1.getOrdenbar().compareTo(o2.getOrdenbar());
			}
		});
		
//		List<HistoricoBarrera> ql = (List<HistoricoBarrera>);//mantenimientoBarrerasBo.obtenerDatosBarrera(historicoOperacion,paginationData,"C");		
		//barrerasPantalla.setListadoHistoricoBarrera(ql);		
	}
	
	public void cambioTipoBarrera(){
		
		if(Constantes.BARRERAS_TIPOBARRERA_NULL.equals(barrerasPantalla.getHistoricoBarrera().getId().getTipbarp1())){
			barrerasPantalla.setBotonSubyacenteActivo(true);
		}else{
			barrerasPantalla.setBotonSubyacenteActivo(false);
			if (barrerasPantalla.getHistoricoBarrera().getId().getTipbarp1().length()>1) {
				String tipBarrp1=barrerasPantalla.getHistoricoBarrera().getId().getTipbarp1();
				if ( Constantes.BARRERAS_TIPOBARRERA_IN.equals(tipBarrp1.substring(1,2)) &&
						barrerasPantalla.isIndrebate()){
					barrerasPantalla.setIndrebate(false);
				}
			}
		} 
		
	}
	
	public void cambioFechaInicio(){
		if(!Constantes.BARRERAS_TIPOBARRERA_NULL.equals(barrerasPantalla.getHistoricoBarrera().getTipobarr()) &&
			Constantes.BARRERAS_TIPOREVISION_EUROPEA.equals(barrerasPantalla.getHistoricoBarrera().getTipobarr())
			&& barrerasPantalla.getHistoricoBarrera().getFecfinba()!=null	
		){
			barrerasPantalla.getHistoricoBarrera().setFeciniba(barrerasPantalla.getHistoricoBarrera().getFecfinba());
		}
		
	}
		
	public void cambioTipoRevision(){
		//FLM: puede ser null
		String codigoBarrera="";
		if ( historicoOperacion.getHistoricoOpcion() != null && historicoOperacion.getHistoricoOpcion().getModobarr() != null)
			codigoBarrera=historicoOperacion.getHistoricoOpcion().getModobarr().getCodigo();
	
		//FLM: Ojo tipobar = tipo revision mientras que  <> tipobarp1 = tipobarrera, aqui los eventos estaban al reves
		if (!Constantes.BARRERAS_TIPOBARRERA_NULL.equals(barrerasPantalla.getHistoricoBarrera().getTipobarr())){
			if(Constantes.BARRERAS_TIPOREVISION_AMERICANA.equals(barrerasPantalla.getHistoricoBarrera().getTipobarr() )){
				barrerasPantalla.setFfinActivo(true);
				barrerasPantalla.setFinicioActivo(true);
				if(Constantes.BARRERAS_MODOBARR_IN.equals( codigoBarrera )){
					barrerasPantalla.setIndrebate(false);
				} else {
					/**
					 * RFA: incidencia 1053 : 
						La validación de tipo revisión es incorrecta. Se debe eliminar la validación que provoca este error,
 						se puede elegir tipo revisión américana para todos los tipos
					statusMessages.addToControl("tipoRevision", 
							Severity.ERROR,
							"#{messages['barrera.error.TipoRevisionErroneo']}");
					barrerasPantalla.getHistoricoBarrera().setTipobarr(null);
					*/
				}
			}
			
			if(Constantes.BARRERAS_TIPOREVISION_EUROPEA.equals(barrerasPantalla.getHistoricoBarrera().getTipobarr())){
//				barrerasPantalla.getHistoricoBarrera().setFecfinba(null);
				barrerasPantalla.getHistoricoBarrera().setFeciniba(barrerasPantalla.getHistoricoBarrera().getFecfinba());
				barrerasPantalla.setFfinActivo(true);
				barrerasPantalla.setFinicioActivo(false);
			}
		}
		
	}
	
	public void cambioOrdenToque(){		
		if(barrerasPantalla.isIndtoord()){
			if (mantenimientoBarrerasBo.contarCheckBarreras(historicoOperacion,
					barrerasPantalla.getHistoricoBarrera().getOrdenbar())==1){
				statusMessages.add(Severity.ERROR,"#{messages['barrera.error.CheckOrdenErroneo']}");
			}
		}
	}
	public void cambioIndRebate(){
		if (barrerasPantalla.isIndrebate()){
			if (Constantes.BARRERAS_TIPOBARRERA_NULL.equals(barrerasPantalla.getHistoricoBarrera().getId().getTipbarp1()) 
					|| GenericUtils.isNullOrBlank(barrerasPantalla.getHistoricoBarrera().getId().getTipbarp1()) ){
				barrerasPantalla.setIndrebate(false);
				statusMessages.add(Severity.ERROR,"#{messages['barrera.error.informarbarrera']}");
			}
			if(!GenericUtils.isNullOrBlank(barrerasPantalla.getHistoricoBarrera().getId().getTipbarp1())){
				//FLM: Puede petar, tenemos con dos y con uno
				if (barrerasPantalla.getHistoricoBarrera().getId().getTipbarp1().length()>1) {
					if(Constantes.BARRERAS_TIPOBARRERA_OUT.equals(barrerasPantalla.getHistoricoBarrera().getId().getTipbarp1().substring(1,2))){
						barrerasPantalla.setTiprebatActivo(true);
						barrerasPantalla.setDivisaRebateActivo(true);
					}
					if(Constantes.BARRERAS_TIPOBARRERA_IN.equals(barrerasPantalla.getHistoricoBarrera().getId().getTipbarp1().substring(1,2))){
						barrerasPantalla.setIndrebate(false);
						statusMessages.add(Severity.ERROR,"#{messages['barrera.error.TipobarreraErroneo']}");	
					}
				}
			}
		}else{
			barrerasPantalla.setTiprebatActivo(false);
			barrerasPantalla.getHistoricoBarrera().setTiprebat(null);
			barrerasPantalla.setPorcentajeRebateActivo(false);
			barrerasPantalla.getHistoricoBarrera().setPorrebat(null);
			barrerasPantalla.setDivisaRebateActivo(false);
			barrerasPantalla.getHistoricoBarrera().setDivireba(null);
			barrerasPantalla.setImporteRebateActivo(false);
			barrerasPantalla.getHistoricoBarrera().setImprebat(null);
		}
	}
	
	public void cambioTipoRebat(){
		if(!GenericUtils.isNullOrBlank(barrerasPantalla.getHistoricoBarrera().getTiprebat())){
			if(Constantes.BARRERAS_TIPOREBATE_IMPORTE.equals(barrerasPantalla.getHistoricoBarrera().getTiprebat())){
				barrerasPantalla.getHistoricoBarrera().setPorrebat(null);
				barrerasPantalla.setPorcentajeRebateActivo(false);
				barrerasPantalla.setImporteRebateActivo(true);
			}
			if(Constantes.BARRERAS_TIPOREBATE_PORCENTAJE.equals(barrerasPantalla.getHistoricoBarrera().getTiprebat())){
				barrerasPantalla.getHistoricoBarrera().setImprebat(null);
				barrerasPantalla.setImporteRebateActivo(false);
				barrerasPantalla.setPorcentajeRebateActivo(true);
			}
		}
	}
	
	public void cambioPorcentajeRebat(){
		if("P".equals(historicoOperacion.getHistoricoOpcion().getTipoOperacion())){
			
			//Si viene a null le ponemos 0
			if (GenericUtils.isNullOrBlank(barrerasPantalla.getHistoricoBarrera().getPorrebat())){
				barrerasPantalla.getHistoricoBarrera().setImprebat(new BigDecimal(0));
			} else {
				barrerasPantalla.getHistoricoBarrera().setImprebat(barrerasPantalla.getHistoricoBarrera().getPorrebat().multiply(historicoOperacion.getNominalPago()).divide(BigDecimal.valueOf(100L)));
			}
		}
		if("R".equals(historicoOperacion.getHistoricoOpcion().getTipoOperacion())){
			
			//Si viene a null le ponemos 0
			if (GenericUtils.isNullOrBlank(barrerasPantalla.getHistoricoBarrera().getPorrebat())){
				barrerasPantalla.getHistoricoBarrera().setImprebat(new BigDecimal(0));
			} else {
				barrerasPantalla.getHistoricoBarrera().setImprebat(barrerasPantalla.getHistoricoBarrera().getPorrebat().multiply(historicoOperacion.getNominalRecibo()).divide(BigDecimal.valueOf(100L)));
			}
		}
	}
	
	public void cargarAlta(){
		this.setModoPantalla(ModoPantalla.CREACION);
		barrerasPantalla.setHistoricoBarrera(new HistoricoBarrera());
		HistoricoBarreraId historicoBarreraId = new HistoricoBarreraId();
		barrerasPantalla.getHistoricoBarrera().setId(historicoBarreraId);
		barrerasPantalla.setFfinActivo(false);
		barrerasPantalla.setFinicioActivo(false);

		if("P".equals(historicoOperacion.getHistoricoOpcion().getTipoOperacion()) && historicoOperacion.getDivisaPago()!=null){
			barrerasPantalla.getHistoricoBarrera().setDivireba(historicoOperacion.getDivisaPago().getId());
		}
		if("R".equals(historicoOperacion.getHistoricoOpcion().getTipoOperacion())&& historicoOperacion.getDivisaRecibo()!=null){
			barrerasPantalla.getHistoricoBarrera().setDivireba(historicoOperacion.getDivisaRecibo().getId());
		}
		//FLM: puede ser null
		String codigoBarrera="";
		if ( historicoOperacion.getHistoricoOpcion() != null && historicoOperacion.getHistoricoOpcion().getModobarr() != null)
			codigoBarrera = historicoOperacion.getHistoricoOpcion().getModobarr().getCodigo();
		
		if("DT".equals(codigoBarrera)){
			barrerasPantalla.setIndtoordActivo(true);
		}else{
			barrerasPantalla.setIndtoordActivo(false);
		}
		if(Constantes.BARRERAS_MODOBARR_IN.equals(codigoBarrera)){
			barrerasPantalla.getHistoricoBarrera().setTipobarr(Constantes.BARRERAS_TIPOREVISION_AMERICANA);
			barrerasPantalla.setFfinActivo(true);
			barrerasPantalla.setFinicioActivo(true);
			barrerasPantalla.setIndrebate(false);
		}
	}
	
	public void cargarDetalle(){
		this.setModoPantalla(ModoPantalla.INSPECCION);
		HistoricoBarrera barrera = historicoBarreraSelect;
		barrerasPantalla.setHistoricoBarrera(barrera);
		if("S".equals( barrera.getIndtoord())){
			barrerasPantalla.setIndtoord(true);
		}else{
			barrerasPantalla.setIndtoord(false);
		}
		if("S".equals( barrera.getIndrebat())){
			barrerasPantalla.setIndrebate(true);
		}else{
			barrerasPantalla.setIndrebate(false);
		}
	}
	
	public void cargarModificacion(){
		
		this.setModoPantalla(ModoPantalla.EDICION);
		HistoricoBarrera barrera = historicoBarreraSelect;
		barrerasPantalla.setHistoricoBarrera(barrera);
		if("S".equals( barrera.getIndtoord())){
			barrerasPantalla.setIndtoord(true);
		}else{
			barrerasPantalla.setIndtoord(false);
		}
		if("S".equals( barrera.getIndrebat())){
			barrerasPantalla.setIndrebate(true);
		}else{
			barrerasPantalla.setIndrebate(false);
		}
		cambioTipoBarrera();
		cambioTipoRevision();
		cambioOrdenToque();
		cambioIndRebate();
		cambioTipoRebat();
		cambioPorcentajeRebat();
	}
	
	public String alta(){
		HistoricoBarrera historicoBarrera = barrerasPantalla.getHistoricoBarrera();
		historicoBarrera.getId().setHistoricoOperacion(historicoOperacion);
		
		if ((historicoOperacion.getFormulaPago()!=null &&  GenericUtils.in(historicoOperacion.getFormulaPago().getCodigoFormula(),1029,1030)) || 
		    (historicoOperacion.getFormulaRecibo()!=null 
		    	&& GenericUtils.in(historicoOperacion.getFormulaRecibo().getCodigoFormula(),1029,1030))	){
			historicoBarrera.setIndsitua("I");
		}else{
			historicoBarrera.setIndsitua("A");	
		}
		
		
		historicoBarrera.getId().setTipopera(historicoOperacion.getHistoricoOpcion().getTipoOperacion());
		historicoBarrera.setUsultact(credentials.getUsername());
		
		Set<HistoricoBarrera> historicoBarreras = historicoOperacion.getHistoricoBarreras();
		for (HistoricoBarrera historicoBarrera2 : historicoBarreras) {
			if(historicoBarrera2.getId().equals(historicoBarrera.getId())){
				statusMessages.add(Severity.ERROR,"#{messages['boletas.barreras.barrera.duplicada']}");
				return Constantes.FAIL;
			}
		}
		historicoBarreras.add(historicoBarrera);
		Integer i = barrerasPantalla.getNumBarreras() + 1;
		historicoBarrera.setOrdenbar(i.shortValue());
		entityManager.flush();
//08/05/2015
//		mantenimientoBarrerasBo.modificarEstadoOpcion(
//				historicoOperacion.getHistoricoOpcion());
		historicoOperacion.getHistoricoOpcion().setEstado("A");
		refrescarLista();
		initLista();
		return Constantes.SUCCESS;
	}
	
	private boolean existenSubyacentes() {
		if ( historicoOperacion.getHistoricoSubyacentes() == null || historicoOperacion.getHistoricoSubyacentes().size()==0 )
			return false;
		if ( barrerasPantalla.getHistoricoBarrera() == null ||  barrerasPantalla.getHistoricoBarrera().getId().getTipbarp1()==null)
			return false;
		for ( HistoricoSubyacente historicoSubyacente: historicoOperacion.getHistoricoSubyacentes() ) {
			if ( barrerasPantalla.getHistoricoBarrera().getId().getTipbarp1().equalsIgnoreCase(  historicoSubyacente.getId().getTiposuby() ) )
				return true;
		}
		return false;
	}
	
	public String aceptar(){
		cambioFechaInicio();
		if (!existenSubyacentes())		{
			statusMessages.add(Severity.ERROR, "Debe crear primero los subyacentes asociados") ;			
			return Constantes.FAIL;
		}
		
		if(barrerasPantalla.isIndtoord()){
			barrerasPantalla.getHistoricoBarrera().setIndtoord("S");
		}else{
			barrerasPantalla.getHistoricoBarrera().setIndtoord("N");
		}
		if(barrerasPantalla.isIndrebate()){
			barrerasPantalla.getHistoricoBarrera().setIndrebat("S");
		}else{
			barrerasPantalla.getHistoricoBarrera().setIndrebat("N");
		}
		if (modoPantalla.equals(ModoPantalla.CREACION) ){
			return alta();
		}
		if (modoPantalla.equals(ModoPantalla.EDICION) ){
			return modificar();
		}
		
		// El flush se hace en edicion y crear  entityManager.flush();
		
		return Constantes.CONSTANTE_SUCCESS;
	}
	
	public Boolean aceptarValidator(){
		boolean retorno = true;
		
//		if(Constantes.BARRERAS_TIPOBARRERA_NULL.equals(barrerasPantalla.getHistoricoBarrera().getTipobarr())){
//			statusMessages.addToControl("cmbTipoRev",Severity.ERROR,"#{messages['barrera.error.TipoRevNoInformado']}");
//			retorno = false;
//		}
		
		if(Constantes.BARRERAS_TIPOBARRERA_IN.equals(barrerasPantalla.getHistoricoBarrera().getTipobarr())){
			if(GenericUtils.isNullOrBlank(barrerasPantalla.getHistoricoBarrera().getFeciniba())){
				statusMessages.addToControl("finicio",Severity.ERROR,"#{messages['barrera.error.FechaInicioNoInformada']}");
				retorno = false;
			}
			if(GenericUtils.isNullOrBlank(barrerasPantalla.getHistoricoBarrera().getFecfinba())){
				statusMessages.addToControl("ffin",Severity.ERROR,"#{messages['barrera.error.FechaFinNoInformada']}");
				retorno = false;
			}
			//FLM:TODO esto da un null pointer exception !!
			if (retorno!=false) 
			if(barrerasPantalla.getHistoricoBarrera().getFeciniba().getTime() > barrerasPantalla.getHistoricoBarrera().getFecfinba().getTime()){
				statusMessages.addToControl("finicio",Severity.ERROR,"#{messages['barrera.error.FechaErronea']}");
				retorno = false;
			}
		}
		if(barrerasPantalla.isIndrebate()){
			//|| Constantes.BARRERAS_TIPOBARRERA_NULL.equals(barrerasPantalla.getHistoricoBarrera().getTiprebat())
			if(GenericUtils.isNullOrBlank(barrerasPantalla.getHistoricoBarrera().getTiprebat())){
				statusMessages.addToControl("tipoRebate",Severity.ERROR,"#{messages['barrera.error.TipoRebateNoInformado']}");
				retorno = false;
			}else{
				if(Constantes.BARRERAS_TIPOREBATE_IMPORTE.equals(barrerasPantalla.getHistoricoBarrera().getTiprebat()) 
						&& GenericUtils.isNullOrBlank(barrerasPantalla.getHistoricoBarrera().getImprebat())){
					statusMessages.addToControl("imporebat",Severity.ERROR,"#{messages['barrera.error.ImporteRebate	NoInformado']}");
					retorno = false;
				}
				if(Constantes.BARRERAS_TIPOREBATE_PORCENTAJE.equals(barrerasPantalla.getHistoricoBarrera().getTiprebat()) 
						&& GenericUtils.isNullOrBlank(barrerasPantalla.getHistoricoBarrera().getPorrebat())){
					statusMessages.addToControl("porcenreb",Severity.ERROR,"#{messages['barrera.error.PorcentajeRebateNoInformado']}");
					retorno = false;
				}
			}
			if( GenericUtils.isNullOrBlank(barrerasPantalla.getHistoricoBarrera().getDivireba())){
				statusMessages.addToControl("divisaRebate",Severity.ERROR,"#{messages['barrera.error.DivisaRebateNoInformada']}");
				retorno = false;
			}	
		}

		if (( (historicoOperacion.getFormulaPago()!=null &&  GenericUtils.in(historicoOperacion.getFormulaPago().getCodigoFormula(),1029,1030)) || 
			  (historicoOperacion.getFormulaRecibo()!=null &&  GenericUtils.in(historicoOperacion.getFormulaRecibo().getCodigoFormula(),1029,1030)) ) 
			&& ( !"DO".equalsIgnoreCase(barrerasPantalla.getHistoricoBarrera().getId().getTipbarp1()) &&
				 !"UO".equalsIgnoreCase(barrerasPantalla.getHistoricoBarrera().getId().getTipbarp1()) )){
			
			statusMessages.add(Severity.ERROR,"#{messages['barrera.error.tipobarNovale']}");
			retorno = false;
		}


		//Se coge de memoria
		if(historicoOperacion.getHistoricoSubyacentes() == null 
				|| historicoOperacion.getHistoricoSubyacentes().isEmpty()){
			statusMessages.add(Severity.ERROR,"#{messages['barrera.error.SubyacenteObligatorio']}");
			retorno = false;
		}
		
		//Validamos que si es tipo Doble touch no se pueda marcar orden toque en las dos barreras
		//que se dan de alta
		if("DT".equals(historicoOperacion.getHistoricoOpcion().getModobarr().getCodigo()) 
				&& barrerasPantalla.isIndtoord()){
			if (mantenimientoBarrerasBo.contarCheckBarreras(historicoOperacion,
					barrerasPantalla.getHistoricoBarrera().getOrdenbar())==1){
				statusMessages.add(Severity.ERROR,"#{messages['barrera.error.CheckOrdenErroneo']}");
				retorno = false;
			}
		}
		
		return retorno;
	}
	public String modificar(){
		
		if ((historicoOperacion.getFormulaPago()!=null &&  GenericUtils.in(historicoOperacion.getFormulaPago().getCodigoFormula(),1029,1030)) || 
			(historicoOperacion.getFormulaRecibo()!=null &&  GenericUtils.in(historicoOperacion.getFormulaRecibo().getCodigoFormula(),1029,1030)) ){
			barrerasPantalla.getHistoricoBarrera().setIndsitua("I");
			}
			
		mantenimientoBarrerasBo.aceptarModificacionBarrera(barrerasPantalla.getHistoricoBarrera());
		entityManager.flush();		
		refrescarLista();
		initLista();
		return Constantes.SUCCESS;
	}
	
	public void borrar(){
		mantenimientoBarrerasBo.eliminarBarrera(historicoBarreraSelect , historicoOperacion);
		barrerasPantalla.setNumBarreras(barrerasPantalla.getNumBarreras() - 1 );
		entityManager.flush();
//08/05/2015		mantenimientoBarrerasBo.modificarEstadoOpcion(historicoOperacion.getHistoricoOpcion());
		historicoOperacion.getHistoricoOpcion().setEstado("A");
		initLista();
	}
	
	public void subyacente(){
		if(BoletasStates.ALTA_BOLETA.equals(boletaState)){
			mantenimientoBarrerasBo.copiaSubyacenteOperacion(historicoOperacion,barrerasPantalla.getHistoricoBarrera().getId().getTipbarp1());
		}
	}
	
	public String salirBarreras(){
		return Constantes.CONSTANTE_SUCCESS;
	}
	
	
	public void salirDetalleBarreraConfirmando(){
		if (messageBoxAction==null){
			messageBoxAction=new MessageBoxAction();
		}
		messageBoxAction.init("model.confirmacion.salir", "barrerasAction.salirDetalleBarrera()", "barrerasAction.onMessageBoxKo()");
	}
	
	public void onMessageBoxKo(){
		;
	}
	public String salirDetalleBarrera(){
		//FLM: Avisar antes de salir
		Conversation conversacion=Conversation.instance();
		conversacion.redirectToParent();
		return Constantes.CONSTANTE_SUCCESS;
	}
	
	public String obtenerDescripcionTipoBarrera(String codigo){
		return mantenimientoBarrerasBo.obtenerDescripcionTipoBarrera(codigo);
	}

	public BarrerasPantalla getBarrerasPantalla() {
		return barrerasPantalla;
	}

	public void setBarrerasPantalla(BarrerasPantalla barrerasPantalla) {
		this.barrerasPantalla = barrerasPantalla;
	}

	public MantenimientoBarrerasBo getMantenimientoBarrerasBo() {
		return mantenimientoBarrerasBo;
	}

	public void setMantenimientoBarrerasBo(
			MantenimientoBarrerasBo mantenimientoBarrerasBo) {
		this.mantenimientoBarrerasBo = mantenimientoBarrerasBo;
	}

	public HistoricoOperacion getHistoricoOperacion() {
		return historicoOperacion;
	}

	public void setHistoricoOperacion(HistoricoOperacion historicoOperacion) {
		this.historicoOperacion = historicoOperacion;
	}

	public String irMantenimientoSubyacentes(){
		//FLM: TODO poner aqui los parametros de subyacentes !!!
		//this.pantallaOrigen;
		// Para llamar a subyacente en origen se debe poner el tipo de barrera
		//Ojo, NO ES BAR, es el tipo de la barrera
/*		
        <Trigger Name="WHEN-BUTTON-PRESSED" TriggerText="IF :GLOBAL.OPCION &lt;> 'C' THEN
       	 P_COPIAR_SUBYACENTE_OPERACION;
       END IF;
       	P_TRATAMIENTO_SUBYAC;
       	IF :GLOBAL.SUBYACOK = 'S' THEN
       		SET_ITEM_PROPERTY('BOTON_ACEPTAR',ENABLED,PROPERTY_TRUE);
       		GO_ITEM('BOTON_CANCELAR');
       	ELSE
       		SET_ITEM_PROPERTY('BOTON_ACEPTAR',ENABLED,PROPERTY_FALSE);
       		GO_ITEM('BOTON_SUBYAC');
       	END IF;

       " DirtyInfo="true"/>
*/		
		
		cambioFechaInicio();
		pantallaOrigen= barrerasPantalla.getHistoricoBarrera().getId().getTipbarp1();
		//Copiamos los subyacentes , dentro debemos mirar que no los tenga ya copiados antes
		if(!BoletasStates.CONSULTA_BOLETA.equals(boletaState)){
			mantenimientoBarrerasBo.copiaSubyacenteOperacion(historicoOperacion,pantallaOrigen);
			entityManager.flush();
		}

		return Constantes.CONSTANTE_SUCCESS;
	}

	public HistoricoBarrera getHistoricoBarreraSelect() {
		return historicoBarreraSelect;
	}

	public void setHistoricoBarreraSelect(HistoricoBarrera historicoBarreraSelect) {
		this.historicoBarreraSelect = historicoBarreraSelect;
	}

	
	public String salirDirectoDetalle(){
		setModificar(true);
		return salirDirecto();
	}
	public String salirDirecto(){

		if ( !BoletasStates.CONSULTA_BOLETA.equals( this.boletaState) ) {
			try {
				String result = boletasBo.salirOperacion("R", historicoOperacion, Identity.instance().getCredentials().getUsername());
				if (result != null) {
					String codigoValidacionErroneo = result;
					statusMessages.add(Severity.ERROR, "#{messages['boletas.edicion.error.salir.operacion']");
				}
				//FLM: boletas es un caso especial, si estamos en alta tenemos que saltar 2 parents quizas?
				return doCommonRedirect();
				//return doSalirRedirect();
			} finally {
				if (boletaState == BoletasStates.MODI_BOLETA) {
					dbLockService.desbloqueo(HistoricoOperacion.class, historicoOperacionBloqueadoId);
				}
			}

		} else { 
			return doCommonRedirect();
		}
		    

		
	}
	
private String doCommonRedirect() {
	
	
	if(forcedReturnView!=null){
		return doSalirRedirect();
	}
	if(boletaState==BoletasStates.ALTA_BOLETA){
		Conversation.instance().pop();
    	if (getModificar()){
    		Conversation.instance().pop();	
    	}
		return "salir";
	}
	
	Conversation conversacion=Conversation.instance();
	Conversation.instance().pop();
	if (getModificar()){
		Conversation.instance().pop();	
	}

	//	Conversation conversacion = Conversation.instance();
	//Volvemos al anterior
	conversacion.redirectToParent();
	return "";
}	

private String doSalirRedirect() {

	if ( BoletasStates.ALTA_BOLETA.equals( this.boletaState) ) {
		
    	Conversation nested =Conversation.instance();
    	Conversation.instance().pop();
    	Conversation.instance().pop();
    	if (getModificar()){
    		Conversation.instance().pop();	
    	}
    	
    	boolean dosSaltos= ( "/pages/adminoper/boletas/alta/altaOper.xhtml".equalsIgnoreCase( Conversation.instance().getViewId() ) );
    	
    
    	if(forcedReturnView!=null){
    		if(dosSaltos){
    			Conversation.instance().redirectToParent();
    			return "";
    		}else{
    			Conversation.instance().redirect();
    			return "";

    		}
		}
    	
    	nested.end(true);
    	if(EntityUtil.checkEntityExists(entityManager, historicoOperacion.getProductoCompuesto())){
    		return "/pages/gestionoperaciones/productocompuesto/mantProdCompuesto.xhtml";
    	}
		return "salir";
	} else {
		Conversation conversacion=Conversation.instance();
		Conversation.instance().pop();
    	if (getModificar()){
    		Conversation.instance().pop();	
    	}
		conversacion.redirectToParent();
		return "";
	}
}


public Boolean getModificar() {
	return modificar;
}

public void setModificar(Boolean modificar) {
	this.modificar = modificar;
}


}

