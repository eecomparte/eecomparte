package com.atosorigin.deri.adminoper.mantenimientobarreras.screen;

import org.jboss.seam.ScopeType;
import org.jboss.seam.annotations.Name;
import org.jboss.seam.annotations.Out;
import org.jboss.seam.annotations.Scope;

import com.atosorigin.deri.model.adminoper.HistoricoBarrera;


@Name("barrerasPantalla")
@Scope(ScopeType.CONVERSATION)
public class BarrerasPantalla {

	
	
	@Out (value="numBarreras")
	protected int numBarreras;
	
	protected HistoricoBarrera historicoBarrera;
	
	protected boolean botonAltaActivo;
	
	protected boolean indrebate;
	
	protected boolean indtoord;
	
	protected Boolean botonSubyacenteActivo;
	
	protected boolean indtoordActivo;
	
	protected Boolean finicioActivo = false;
	
	protected Boolean ffinActivo = false;
	
	protected Boolean tiprebatActivo = true;
	
	protected Boolean divisaRebateActivo = true;
	
	protected Boolean porcentajeRebateActivo = true;
	
	protected Boolean importeRebateActivo = true;	



	public HistoricoBarrera getHistoricoBarrera() {
		return historicoBarrera;
	}

	public void setHistoricoBarrera(HistoricoBarrera historicoBarrera) {
		this.historicoBarrera = historicoBarrera;
	}

	public int getNumBarreras() {
		return numBarreras;
	}

	public void setNumBarreras(int numBarreras) {
		this.numBarreras = numBarreras;
	}

	public boolean isBotonAltaActivo() {
		return botonAltaActivo;
	}

	public void setBotonAltaActivo(boolean botonAltaActivo) {
		this.botonAltaActivo = botonAltaActivo;
	}

	public boolean isIndrebate() {
		return indrebate;
	}

	public void setIndrebate(boolean indrebate) {
		this.indrebate = indrebate;
	}

	public boolean isIndtoord() {
		return indtoord;
	}

	public void setIndtoord(boolean indtoord) {
		this.indtoord = indtoord;
	}

	public Boolean getBotonSubyacenteActivo() {
		return botonSubyacenteActivo;
	}

	public void setBotonSubyacenteActivo(Boolean botonSubyacenteActivo) {
		this.botonSubyacenteActivo = botonSubyacenteActivo;
	}

	public boolean isIndtoordActivo() {
		return indtoordActivo;
	}

	public void setIndtoordActivo(boolean indtoordActivo) {
		this.indtoordActivo = indtoordActivo;
	}

	public Boolean getFinicioActivo() {
		return finicioActivo;
	}

	public void setFinicioActivo(Boolean finicioActivo) {
		this.finicioActivo = finicioActivo;
	}

	public Boolean getFfinActivo() {
		return ffinActivo;
	}

	public void setFfinActivo(Boolean ffinActivo) {
		this.ffinActivo = ffinActivo;
	}

	public Boolean getTiprebatActivo() {
		return tiprebatActivo;
	}

	public void setTiprebatActivo(Boolean tiprebatActivo) {
		this.tiprebatActivo = tiprebatActivo;
	}

	public Boolean getDivisaRebateActivo() {
		return divisaRebateActivo;
	}

	public void setDivisaRebateActivo(Boolean divisaRebateActivo) {
		this.divisaRebateActivo = divisaRebateActivo;
	}

	public Boolean getPorcentajeRebateActivo() {
		return porcentajeRebateActivo;
	}

	public void setPorcentajeRebateActivo(Boolean porcentajeRebateActivo) {
		this.porcentajeRebateActivo = porcentajeRebateActivo;
	}

	public Boolean getImporteRebateActivo() {
		return importeRebateActivo;
	}

	public void setImporteRebateActivo(Boolean importeRebateActivo) {
		this.importeRebateActivo = importeRebateActivo;
	}

	
}
