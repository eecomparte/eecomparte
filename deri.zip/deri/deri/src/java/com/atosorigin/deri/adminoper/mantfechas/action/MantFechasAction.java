package com.atosorigin.deri.adminoper.mantfechas.action;

import java.lang.reflect.InvocationTargetException;
import java.math.BigDecimal;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import javax.persistence.EntityManager;

import org.jboss.seam.ScopeType;
import org.jboss.seam.annotations.In;
import org.jboss.seam.annotations.Name;
import org.jboss.seam.annotations.Out;
import org.jboss.seam.annotations.Scope;
import org.jboss.seam.annotations.datamodel.DataModel;
import org.jboss.seam.annotations.datamodel.DataModelSelection;
import org.jboss.seam.core.ResourceBundle;
import org.jboss.seam.international.StatusMessage.Severity;
import org.jboss.seam.security.Credentials;

import com.atosorigin.common.action.GenericAction;
import com.atosorigin.common.action.ModoPantalla;
import com.atosorigin.common.constantes.Constantes;
import com.atosorigin.common.formvalidator.FormValidator;
import com.atosorigin.common.utils.GenericUtils;
import com.atosorigin.deri.adminoper.boletas.action.BoletasAction.BoletasStates;
import com.atosorigin.deri.adminoper.boletas.action.BoletasAction.PagoCobroType;
import com.atosorigin.deri.adminoper.boletas.screen.BoletasPantalla;
import com.atosorigin.deri.adminoper.mantfechas.business.HistoricoFechaFormulaBo;
import com.atosorigin.deri.adminoper.mantfechas.screen.MantFechasPantalla;
import com.atosorigin.deri.common.parametrosPantalla.ParametrosMantdata;
import com.atosorigin.deri.model.gestionoperaciones.DetalleAcumulado;
import com.atosorigin.deri.model.gestionoperaciones.HistoricoFechaFormula;
import com.atosorigin.deri.model.gestionoperaciones.HistoricoFechaFormulaId;
import com.atosorigin.deri.model.gestionoperaciones.HistoricoOperacion;
import com.atosorigin.deri.model.parametrizacion.Divisa;
import com.atosorigin.deri.util.EntityUtil;


@Name("mantFechasAction")
@Scope(ScopeType.CONVERSATION)
@FormValidator
public class MantFechasAction extends GenericAction {

	@In("EntityUtil")
	EntityUtil entityUtil;
	
	@In Credentials credentials;
	
	@In(create=true)
	protected MantFechasPantalla mantFechasPantalla;
	
	@In
	private HistoricoOperacion historicoOperacion;
	@In(required=false,value="parametrosMantData")
	private ParametrosMantdata parametrosMantdata;

	@In
	private EntityManager entityManager;

	@DataModel(value="listaDtFechas")
	protected List<HistoricoFechaFormula> listadoHistoricoFechaFormula;
	
	@DataModelSelection(value="listaDtFechas")
	protected HistoricoFechaFormula historicoFechaFormulaSelect;
	
	//FLM Falta un out
	@Out(required=false) 
	@In(required=false)
	protected HistoricoFechaFormula historicoFechaFormula;

	@In(required = true)
	private BoletasStates boletaState;
	
	@In(required = false)
	private PagoCobroType pagoCobroType;


	/**
	 * Inyeccion del screen bean que contiene los datos de pantalla del caso de
	 * uso datos de mercado
	 */
	@In(create = true)
	protected BoletasPantalla boletasPantalla;
	
	@In(value="#{historicoFechaFormulaBo}")
	protected HistoricoFechaFormulaBo historicoFechaFormulaBo;
	
	protected Boolean rateObl = false;
	protected Boolean op1Obl = false;
	protected Boolean op2Obl = false;
	
	protected Boolean rateDesactivado = false;
	protected Boolean factLiqDesactivado = false;
	protected Boolean op1Desactivado  = false;
	protected Boolean op2Desactivado  = false;
	
	protected String modo;
	
	public enum CancelableType {
		ES_LI_CANCELABLE("LC"), ES_LI_NO_CANCELABLE("LN"), NO_ES_LI("N"), INDEFINIDO("I");
		private String codigo;

		private CancelableType(String codigo) {
			this.codigo = codigo;
		}

		public String getCodigo() {
			return codigo;
		}
	}
	
	private CancelableType cancelableType;
	
	public CancelableType getCancelableType() {
		return cancelableType;
	}


	public void setCancelableType(CancelableType cancelableType) {
		this.cancelableType = cancelableType;
	}


	public void obligatoriosLiquidacion(){
		if(!GenericUtils.isNullOrBlank(this.getHistoricoFechaFormula().getTipoInformacionPrecio())){
			
			esLiCancelable();
			
			if("F".equals(this.getHistoricoFechaFormula().getTipoInformacionPrecio()) || "P".equals(this.getHistoricoFechaFormula().getTipoInformacionPrecio()) ){
				rateObl=true;
				op1Obl=false;
				op2Obl=false;
		
				op1Desactivado  = true;
				op2Desactivado  = true;
				rateDesactivado = false;
				
				historicoFechaFormula.setPrimerOperador(null);
				historicoFechaFormula.setSegundoOperador(null);

				if (cancelableType==CancelableType.ES_LI_CANCELABLE){
					factLiqDesactivado = false;
				}else{
					factLiqDesactivado = true;
					historicoFechaFormula.setFactorLiquidacion(null);
				}
				
			} else if("V".equals(this.getHistoricoFechaFormula().getTipoInformacionPrecio()) ){
				rateObl=true;
				op1Obl=true;
				op2Obl=true;
				
				if ("LI".equals(this.modo)){
					factLiqDesactivado = true;
					historicoFechaFormula.setFactorLiquidacion(null);
				}else{
					factLiqDesactivado = false;
				}

				op1Desactivado  = false;
				op2Desactivado  = false;
				rateDesactivado = false;			
				
			} else if("N".equals(this.getHistoricoFechaFormula().getTipoInformacionPrecio()) ){
				rateObl=false;
				op1Obl=false;
				op2Obl=false;
				historicoFechaFormula.setRateLiquidacion(null);
				historicoFechaFormula.setFactorLiquidacion(null);			
				historicoFechaFormula.setPrimerOperador(null);
				historicoFechaFormula.setSegundoOperador(null);
				
				factLiqDesactivado = true;
				op1Desactivado  = true;
				op2Desactivado  = true;
				rateDesactivado = true;
				
			} else{
				rateObl = false;
				op1Obl  = false;
				op2Obl  = false;
				
				if ("LI".equals(this.modo)){
					factLiqDesactivado = true;
					historicoFechaFormula.setFactorLiquidacion(null);
				}else{
					factLiqDesactivado = false;
				}
					
				op1Desactivado  = false;
				op2Desactivado  = false;
				rateDesactivado = false;
			}
		}else {
			rateObl = false;
			op1Obl  = false;
			op2Obl  = false;
			
			if ("LI".equals(this.modo)){
				factLiqDesactivado = true;
				historicoFechaFormula.setFactorLiquidacion(null);
			}else{
				factLiqDesactivado = false;
			}
//			factLiqDesactivado = false;
			op1Desactivado  = false;
			op2Desactivado  = false;
			rateDesactivado = false;			
		}
	}


	public void esLiCancelable() {
		if("LI".equals(this.modo)) {
			
			
		
				if("F".equals(this.getHistoricoFechaFormula().getTipoInformacionPrecio()) && 
					!GenericUtils.isNullOrBlank(parametrosMantdata) &&	
					!GenericUtils.isNullOrBlank(parametrosMantdata.getDescFormula()) &&	
					(parametrosMantdata.getDescFormula().getCodigoFormula().equals(1024) ||
					parametrosMantdata.getDescFormula().getCodigoFormula().equals(1027))
					){
					
					cancelableType = CancelableType.ES_LI_CANCELABLE;
					
				}else{
					cancelableType = CancelableType.ES_LI_NO_CANCELABLE;	
				}
		
		}else{
			cancelableType = CancelableType.NO_ES_LI;
		}
	}
	
	
	public void borrar(){
		this.getListadoHistoricoFechaFormula().remove(this.getHistoricoFechaFormulaSelect());
		//SMM 18/08/2016
		if (mostrarAcumulados()) calcularAcumulados(this.getListadoHistoricoFechaFormula());
	}
	
	public void editar(){
		setModoPantalla(ModoPantalla.EDICION);
		
		this.setHistoricoFechaFormula(this.getHistoricoFechaFormulaSelect());
		mantFechasPantalla.setFechaFin(new Date(this.getHistoricoFechaFormula().getId().getFechaFin().getTime()));
		mantFechasPantalla.setFechaIni(new Date(this.getHistoricoFechaFormula().getId().getFechaInicio().getTime()));
		mantFechasPantalla.setDias(calcularDias(this.getHistoricoFechaFormula().getId().getFechaInicio(), this.getHistoricoFechaFormulaSelect().getId().getFechaFin()).toString());
		if(Constantes.MODO_RANGO.equals(modo)){
			mantFechasPantalla.setRangoLower(this.getHistoricoFechaFormula().getRangoMinimo());
			mantFechasPantalla.setRangoUpper(this.getHistoricoFechaFormula().getRangoMaximo());
		}
		obligatoriosLiquidacion();
	}
	
	public void ver(){
		setModoPantalla(ModoPantalla.INSPECCION);
		
		this.setHistoricoFechaFormula(this.getHistoricoFechaFormulaSelect());
		mantFechasPantalla.setFechaFin(new Date(this.getHistoricoFechaFormula().getId().getFechaFin().getTime()));
		mantFechasPantalla.setFechaIni(new Date(this.getHistoricoFechaFormula().getId().getFechaInicio().getTime()));
		mantFechasPantalla.setDias(calcularDias(this.getHistoricoFechaFormula().getId().getFechaInicio(), this.getHistoricoFechaFormulaSelect().getId().getFechaFin()).toString());
		mantFechasPantalla.setRangoLower(getHistoricoFechaFormula().getRangoMinimo());
		mantFechasPantalla.setRangoUpper(getHistoricoFechaFormula().getRangoMaximo());
		mantFechasPantalla.setObservaciones(getHistoricoFechaFormula().getObservaciones());
		
	}
	
	
	public List<HistoricoFechaFormula> construirListaByModo(String modo){
		if(GenericUtils.isNullOrBlank(this.getListadoHistoricoFechaFormula())){
			this.setListadoHistoricoFechaFormula(new ArrayList<HistoricoFechaFormula>());
		}
		List<HistoricoFechaFormula> listaRetorno = new ArrayList<HistoricoFechaFormula>();
		//Salva: NullPointerExeption
		if (historicoOperacion.getHistoricoFechasFormulas()!=null){
			try {
				for (HistoricoFechaFormula hist : historicoOperacion
						.getHistoricoFechasFormulas()) {
					if (modo.equals(hist.getId().getTipoFecha())) {

						listaRetorno
								.add(hist);
					}

				}
				ordenarLista(this.getListadoHistoricoFechaFormula());
			} catch (Exception e) {
				// TODO: handle exception
				System.out.println(e);
			}
		}
		return listaRetorno;
	}
	
	private void ordenarLista(List<HistoricoFechaFormula> lista) {
		Collections.sort(lista, new Comparator<HistoricoFechaFormula>() {
		    public int compare(HistoricoFechaFormula o1, HistoricoFechaFormula o2) {
		    	int comp = 0;
		    	try {
		    		comp = o1.getId().getFechaInicio().compareTo(o2.getId().getFechaInicio());
		    		if (comp == 0){
		    			comp = o1.getId().getFechaFin().compareTo(o2.getId().getFechaFin());
		    		}
				} catch (Exception e) {
					comp = 0;
				}
		    	return comp;
		    }});
	}
	
	public void preCargar(){
		// SCM: Integración con la pantalla BOLETAS
		String tipoFecha = parametrosMantdata.getTipoFecha();
		this.modo = tipoFecha;
		if("LI".equals(this.modo)){
			factLiqDesactivado = true;
		}
		if(primerAcceso){
			
			construirListaByModo(tipoFecha);
//			if(GenericUtils.isNullOrBlank(this.getListadoHistoricoFechaFormula()) || this.getListadoHistoricoFechaFormula().isEmpty()){
				
				List<HistoricoFechaFormula>  list = this.getListadoHistoricoFechaFormula();
				if(list==null){
					list = new ArrayList<HistoricoFechaFormula>();
					this.setListadoHistoricoFechaFormula(list);
				}
				list.clear();
				list.addAll(historicoFechaFormulaBo.obtenerFechasSeleccion(historicoOperacion, tipoFecha));
//				this.setListadoHistoricoFechaFormula(historicoFechaFormulaBo.obtenerFechasSeleccion(historicoOperacion, tipoFecha));	
				
//				ArrayList<HistoricoFechaFormula> lista = new ArrayList<HistoricoFechaFormula>();
//				lista.addAll(construirListaByModo(tipoFecha));
//				
//				listadoHistoricoFechaFormula = lista;
//			} 
			if (Constantes.MODO_SELECCION.equalsIgnoreCase(tipoFecha)){
				//SMM 18/08/2016
				if (!GenericUtils.isNullOrBlank(historicoOperacion.getProductoCatalogo()) &&
						historicoOperacion.getProductoCatalogo().getProducat().equals(30L)){
					
					calcularAcumulados(list);
				}
				
		 		this.setHistoricoFechaFormula(new HistoricoFechaFormula(new HistoricoFechaFormulaId()));		 		
		 	}
		}
		primerAcceso = false;
	}

	public Boolean mostrarAcumulados(){
		if (Constantes.MODO_SELECCION.equalsIgnoreCase( parametrosMantdata.getTipoFecha())
				&& !GenericUtils.isNullOrBlank(historicoOperacion.getProductoCatalogo()) &&
					historicoOperacion.getProductoCatalogo().getProducat().equals(30L)){
			return true;
		}
		return false;		
	}
	/**
	 * 	SMM 18/08/2016 Recuperamos Acumulados de la tabla DERI.DETACUMU
	 * @param list
	 */
	private void calcularAcumulados(List<HistoricoFechaFormula> list) {
		
		//List<DetalleAcumulado> detalleAcumList = historicoFechaFormulaBo.obtenerAcumulados(historicoOperacion);
		
		int index = 0;
		BigDecimal acumAnterior = BigDecimal.ZERO;
		// Recuperar Fechamis y fecha corte, Registros anteriors a fecha Corte 0
		// fecha corte nomtabla ACUMULA
		// Posteriores a fechamis en blanco <=
		Date fechaSistema = historicoFechaFormulaBo.obtenerFechaSistema();
		Date fechaCorte =  historicoFechaFormulaBo.obtenerFechaCorteAcum();
		
		for (HistoricoFechaFormula fechaSeleccion : list) {
			
			if (fechaSeleccion.getId().getFechaInicio().before(fechaCorte)){
				
				fechaSeleccion.setNominalAcumEn(BigDecimal.ZERO);
				fechaSeleccion.setNominalAcumHasta("0,00");
				acumAnterior = BigDecimal.ZERO;
				
			}else if (fechaSistema.before(fechaSeleccion.getId().getFechaInicio())){
				
				fechaSeleccion.setNominalAcumEn(BigDecimal.ZERO);
				fechaSeleccion.setNominalAcumHasta(GenericUtils.aplicarMascaraNumerica(acumAnterior.toString(), Constantes.MASCARA_SEPARADOR_MILES));
//				acumAnterior = BigDecimal.ZERO;
			}else{
			
				DetalleAcumulado detalleAcum = historicoFechaFormulaBo.obtenerAcumuladoFecha(historicoOperacion,fechaSeleccion);
				
				if (!GenericUtils.isNullOrBlank(detalleAcum)){
					
					fechaSeleccion.setNominalAcumEn(detalleAcum.getNominalAcumulado().subtract(acumAnterior));
					
//					fechaSeleccion.setNominalAcumHasta(detalleAcum.getNominalAcumulado().toString());
					fechaSeleccion.setNominalAcumHasta(GenericUtils.aplicarMascaraNumerica(detalleAcum.getNominalAcumulado().toString(), Constantes.MASCARA_SEPARADOR_MILES));	
					acumAnterior = detalleAcum.getNominalAcumulado();
				}else{
					if (index==0){
						//Lo Permitimos en la primera Fecha de Seleccion
						fechaSeleccion.setNominalAcumEn(BigDecimal.ZERO);
						fechaSeleccion.setNominalAcumHasta("0,00");
						acumAnterior = BigDecimal.ZERO;
					}else{
						//ERROR
						fechaSeleccion.setNominalAcumHasta(ResourceBundle.instance().getString("mantfechas.error.acumulados"));
						
					}
					
				}
			
			}
			
			index++;
		}
	
	
	}


	public void calcularDias(){
		if (!GenericUtils.isNullOrBlank(mantFechasPantalla.getFechaFin()) && !GenericUtils.isNullOrBlank(mantFechasPantalla.getFechaIni())){
			SimpleDateFormat sdf = new SimpleDateFormat(Constantes.DDMMYYYY);
			
			double dias;
			//try {
				dias = (double)(mantFechasPantalla.getFechaFin().getTime() - mantFechasPantalla.getFechaIni().getTime());
				dias = Math.ceil((((dias/1000)/60)/60)/24);
				dias = dias + 1;
				if (dias<0){
					statusMessages.addFromResourceBundle(Severity.ERROR, "mantfechas.fijacionStrike.errorFechas");
					mantFechasPantalla.setDias("0");
				}else{
					mantFechasPantalla.setDias(Double.toString(dias));
				}
				if(mantFechasPantalla.getFechaFin().getTime() > historicoOperacion.getFechaVencimiento().getTime()){
					statusMessages.addFromResourceBundle(Severity.ERROR, "mantfechas.error.fechaVencimiento");
				}
			/*} catch (ParseException e) {
				
				e.printStackTrace();
			}*/
		}
	}
	
	public Long calcularDias(Date fechaInicio, Date fechaFin){
		Long dias = 0l;
		if (!GenericUtils.isNullOrBlank(fechaInicio) && !GenericUtils.isNullOrBlank(fechaFin)){
				dias = fechaFin.getTime() - fechaInicio.getTime();
				dias = (((dias/1000)/60)/60)/24;
				dias = dias + 1;
		}
		return dias;
	}
	
	public String fechaDetalle(){
		setModoPantalla(ModoPantalla.CREACION);
		//FLM: Donde hacemos un out de esto?
		this.setHistoricoFechaFormula(new HistoricoFechaFormula());
		HistoricoFechaFormulaId historicoFechaFormulaId = new HistoricoFechaFormulaId();
		this.getHistoricoFechaFormula().setId(historicoFechaFormulaId);
		mantFechasPantalla.setDias(Constantes.CADENA_VACIA);
		mantFechasPantalla.setFechaFin(null);
		mantFechasPantalla.setFechaIni(null);
		mantFechasPantalla.setPeso(null);
		mantFechasPantalla.setRangoLower(null);
		mantFechasPantalla.setRangoUpper(null);
		return Constantes.CONSTANTE_SUCCESS;
	}
	
	public boolean idIguales(HistoricoFechaFormulaId iduno, HistoricoFechaFormulaId iddos){
		if(!GenericUtils.isNullOrBlank(iduno) && !GenericUtils.isNullOrBlank(iddos)){
			if(iduno.getFechaFin().compareTo(iddos.getFechaFin()) == 0 
					&& iduno.getFechaInicio().compareTo(iddos.getFechaInicio()) == 0
					&& iduno.getTipoFecha().equals(iddos.getTipoFecha())){
				return true;
			}
			
			return false;
		}else if(GenericUtils.isNullOrBlank(iduno) && GenericUtils.isNullOrBlank(iddos)){
			return true;
		}else{
			return false;
		}
		
	}
	
	public void asignarValores(HistoricoFechaFormula histFechauno, HistoricoFechaFormula histFechados){
		histFechauno.setIndicadorNulo(histFechados.getIndicadorNulo());
		histFechauno.setPorcentajePayOff(histFechados.getPorcentajePayOff());
		histFechauno.setImportePayOff(histFechados.getImportePayOff());
		histFechauno.setRangoMinimo(histFechados.getRangoMinimo());
		histFechauno.setRangoMaximo(histFechados.getRangoMaximo());
		histFechauno.setFechaLiquidacion(histFechados.getFechaLiquidacion());
		histFechauno.setFechaFixing(histFechados.getFechaFixing());
		histFechauno.setTipoInformacionPrecio(histFechados.getTipoInformacionPrecio());
		histFechauno.setRateLiquidacion(histFechados.getRateLiquidacion());
		histFechauno.setFactorLiquidacion(histFechados.getFactorLiquidacion());
		histFechauno.setPrimerOperador(histFechados.getPrimerOperador());
		histFechauno.setSegundoOperador(histFechados.getSegundoOperador());
		histFechauno.setObservaciones(histFechados.getObservaciones());
		histFechauno.setUsuario(histFechados.getUsuario());
		histFechauno.setPesobsfe(histFechados.getPesobsfe());
		histFechauno.setId(histFechados.getId());
	}
	
	public void guardar(){
		Set<HistoricoFechaFormula> formulasAnteriores = historicoOperacion.getHistoricoFechasFormulas();
		Set<HistoricoFechaFormula> formulasBorrar = new HashSet<HistoricoFechaFormula>();
		boolean encontrado = false;
		List<HistoricoFechaFormula> formulasActuales = getListadoHistoricoFechaFormula();
	
		
		//Bloque for para modificar y añadir nuevos historicosFechaFormula
		for(HistoricoFechaFormula histFecha : formulasActuales){
			encontrado = false;
			for(HistoricoFechaFormula histFechaFor : formulasAnteriores){
				if(histFechaFor.getId().getTipoFecha().equals(modo)){
					if(idIguales(histFecha.getId(), histFechaFor.getId())){
						asignarValores(histFechaFor, histFecha);
						encontrado = true;
					}
				}
			}
			if(!encontrado){
				formulasAnteriores.add(histFecha);
			}
		}
		//Bloque de for para borrar historicosFechaFormula
		for(HistoricoFechaFormula histFechaFor : formulasAnteriores){
			if(histFechaFor.getId().getTipoFecha().equals(modo)){
				encontrado = false;
				for(HistoricoFechaFormula histFecha : formulasActuales){
					if(idIguales(histFecha.getId(), histFechaFor.getId())){
						encontrado = true;
					}
					
				}
				if(!encontrado){
					formulasBorrar.add(histFechaFor);
				}
			}
			
		}
		
		formulasAnteriores.removeAll(formulasBorrar);
		
		entityManager.flush();
	}	

	public boolean validaFechas(){
		boolean retorno = true;
		
		if(!GenericUtils.isNullOrBlank(this.getHistoricoFechaFormula()) && Constantes.MODO_RANGO.equals(modo)){
			if(mantFechasPantalla.getFechaFin().getTime() < mantFechasPantalla.getFechaIni().getTime()){
				statusMessages.addFromResourceBundle(Severity.ERROR, "mantfechas.fijacionStrike.errorFechas");
				retorno = false;
			}
			if( !GenericUtils.isNullOrBlank(mantFechasPantalla.getRangoLower()) && !GenericUtils.isNullOrBlank(mantFechasPantalla.getRangoUpper()) &&    mantFechasPantalla.getRangoLower().longValue() > mantFechasPantalla.getRangoUpper().longValue()){
				statusMessages.addFromResourceBundle(Severity.ERROR, "mantfechas.fechasRango.errorRangos");
				retorno = false;
			}else if(!GenericUtils.isNullOrBlank(mantFechasPantalla.getRangoUpper()) && mantFechasPantalla.getRangoUpper().intValue() <= 0){
				statusMessages.addFromResourceBundle(Severity.ERROR, "mantfechas.fechasRango.errorRangoUpper");
				retorno = false;
			}else{
				this.getHistoricoFechaFormula().setRangoMinimo(mantFechasPantalla.getRangoLower());
				this.getHistoricoFechaFormula().setRangoMaximo(mantFechasPantalla.getRangoUpper());
			}
			
			
			
		}else if(Constantes.MODO_SELECCION.equals(modo)){
			
				if(mantFechasPantalla.getFechaFin().getTime() != mantFechasPantalla.getFechaIni().getTime()){
					statusMessages.addFromResourceBundle(Severity.ERROR, "mantfechas.fijacionStrike.Fechasnoiguales");
					retorno = false;
				}
			
		}
		
		
		return retorno;
	}

	
	public String editarFecha(){
		if(!validaFechas()){
			return Constantes.CONSTANTE_NO;
		}
		HistoricoFechaFormula hist=null;
		int pos=0;
		 
		//Separamos los dos tipos de pantallas que hay
		//FLM: Si editamos modificando pk, tenemos que quitar y poner, cuidado con los flush

//SMM 21/02/2013
//		if(Constantes.MODO_SELECCION.equals(modo) ||
//				Constantes.MODO_EJERCICIO.equals(modo) || Constantes.MODO_PAY_OFF.equals(modo)){
		if(	Constantes.MODO_EJERCICIO.equals(modo) || Constantes.MODO_PAY_OFF.equals(modo)){
			
			if(GenericUtils.isNullOrBlank(mantFechasPantalla.getFechaIni())){
				statusMessages.addFromResourceBundle(Severity.ERROR, "mantfechas.fechainicio.noinformada");
				return Constantes.CONSTANTE_NO;
			}
			if (this.getHistoricoFechaFormulaSelect()==null) {
				statusMessages.addFromResourceBundle(Severity.ERROR, "mantfechas.error.fechaInicioNoModificada");
				return Constantes.CONSTANTE_NO;
			}
			if (!(this.getHistoricoFechaFormulaSelect().getId().getFechaFin().equals(mantFechasPantalla.getFechaFin()) 
					&& this.getHistoricoFechaFormulaSelect().getId().getFechaInicio().equals(mantFechasPantalla.getFechaIni())) && this.getHistoricoFechaFormulaSelect().getId().getFechaFin().equals(mantFechasPantalla.getFechaIni()) &&
					this.getHistoricoFechaFormulaSelect().getId().getFechaInicio().equals(mantFechasPantalla.getFechaIni()) ) {
				statusMessages.addFromResourceBundle(Severity.ERROR, "mantfechas.error.fechaInicioNoModificada");
				return Constantes.CONSTANTE_NO;				
				}
			
			//Clonamos y editamos ojo aqui tomamos el seleccionado, esto debe ser para los que se editan en la misma pantalla que en el listado
			hist=copiaEditarFecha(this.getHistoricoFechaFormulaSelect());
			
			
			hist.getId().setFechaFin(mantFechasPantalla.getFechaIni());
			hist.getId().setFechaInicio(mantFechasPantalla.getFechaIni());			

			//SMM 21/02/2013
//			if(Constantes.MODO_SELECCION.equals(modo)){
//				hist.setObservaciones(mantFechasPantalla.getObservaciones());
//			}
			
			if(hist.getId().getFechaFin().getTime() > historicoOperacion.getFechaVencimiento().getTime()){
				statusMessages.addFromResourceBundle(Severity.ERROR, "mantfechas.error.fechaVencimiento");
				 return Constantes.CONSTANTE_NO;
			}
			if(Constantes.MODO_PAY_OFF.equals(modo)){
				hist.setImportePayOff(getHistoricoFechaFormula().getImportePayOff());
				hist.setObservaciones(getHistoricoFechaFormula().getObservaciones());
				hist.setPorcentajePayOff(getHistoricoFechaFormula().getPorcentajePayOff());
			}
			
			
			//Antes de añadirlo debemos validar que no exista el mismo en la coleccion
			if (!(this.getHistoricoFechaFormulaSelect().getId().getFechaFin().compareTo(mantFechasPantalla.getFechaFin()) ==0 
					&& this.getHistoricoFechaFormulaSelect().getId().getFechaInicio().compareTo(mantFechasPantalla.getFechaIni())==0) && EntityUtil.containsEntity(this.getListadoHistoricoFechaFormula(), hist ) ) {
				  //Debemos quitar el objeto del contexto de persistencia
				  entityUtil.detach(hist);
				  statusMessages.addFromResourceBundle(Severity.ERROR, "mantfechas.error.fechaInicioRepetida");
				  return Constantes.CONSTANTE_NO;
			}
			pos=this.getListadoHistoricoFechaFormula().indexOf(this.getHistoricoFechaFormulaSelect());
			if (this.getListadoHistoricoFechaFormula()!=null )
				this.getListadoHistoricoFechaFormula().remove( this.getHistoricoFechaFormulaSelect());
			if (historicoOperacion.getHistoricoFechasFormulas()!=null )
				historicoOperacion.getHistoricoFechasFormulas().remove( this.getHistoricoFechaFormulaSelect());
			
		}else{

			//Clonamos y editamos ojo aqui tomamos el fechaformula, esto debe ser que se hace en los que tienen formulario de edicion 
			hist=copiaEditarFecha(this.getHistoricoFechaFormula());
			hist.getId().setFechaFin(mantFechasPantalla.getFechaFin());
			hist.getId().setFechaInicio(mantFechasPantalla.getFechaIni());
			if(mantFechasPantalla.getFechaFin().getTime() > historicoOperacion.getFechaVencimiento().getTime()){
				statusMessages.addFromResourceBundle(Severity.ERROR, "mantfechas.error.fechaVencimiento");
				 return Constantes.CONSTANTE_NO;
			}
			//Antes de añadirlo debemos validar que no exista el mismo en la coleccion
			if (!(this.getHistoricoFechaFormulaSelect().getId().getFechaFin().getTime() == mantFechasPantalla.getFechaFin().getTime() 
					&& this.getHistoricoFechaFormulaSelect().getId().getFechaInicio().getTime() == mantFechasPantalla.getFechaIni().getTime()) 
					&& EntityUtil.containsEntity(this.getListadoHistoricoFechaFormula(), hist )) {
				  //Debemos quitar el objeto del contexto de persistencia
				  entityUtil.detach(hist);
				  statusMessages.addFromResourceBundle(Severity.ERROR, "mantfechas.error.fechaRepetida");
				  return Constantes.CONSTANTE_NO;
			}

			//SMM 21/02/2013
//			if(Constantes.MODO_SELECCION.equals(modo)){
//				hist.setObservaciones(mantFechasPantalla.getObservaciones());
//			}
			
			pos=this.getListadoHistoricoFechaFormula().indexOf(this.getHistoricoFechaFormula());
			
			if (this.getListadoHistoricoFechaFormula()!=null )
				this.getListadoHistoricoFechaFormula().remove( this.getHistoricoFechaFormula());
//			if (historicoOperacion.getHistoricoFechasFormulas()!=null )
//				historicoOperacion.getHistoricoFechasFormulas().remove( this.getHistoricoFechaFormula() );
			
		}
		//Y guardamos para que no se pierdan los cambios
		if (this.getListadoHistoricoFechaFormula()!=null )
			this.getListadoHistoricoFechaFormula().add(pos,hist);
//		if (historicoOperacion.getHistoricoFechasFormulas()!=null )
//			historicoOperacion.getHistoricoFechasFormulas().add( hist);
		
		Collections.sort(getListadoHistoricoFechaFormula(), new HistoricoFechaFormula());
		
		//SMM 18/08/2016
		if (mostrarAcumulados()) calcularAcumulados(this.getListadoHistoricoFechaFormula());

		
		return Constantes.CONSTANTE_SUCCESS;
	}

	//FLM: Para clonar un historico fecha formula 
	private HistoricoFechaFormula copiaEditarFecha(HistoricoFechaFormula histO) {
		HistoricoFechaFormula histw=null;
		histw=entityUtil.unwrapProxy(histO,HistoricoFechaFormula.class );		
		HistoricoFechaFormula hist= null;
		HistoricoFechaFormulaId histid= null;
		
		try {
			hist= (HistoricoFechaFormula) org.apache.commons.beanutils.BeanUtils.cloneBean( histw);
			histid=(HistoricoFechaFormulaId) org.apache.commons.beanutils.BeanUtils.cloneBean( histw.getId() );
			hist.setId(histid);
		} catch (IllegalAccessException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (InstantiationException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (InvocationTargetException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (NoSuchMethodException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		return hist;
	}
	

	public void generarFechas() {
		
	}
	
	public void generacionFechas() {
		//Llamar package
		Divisa divisa = null;
		if (pagoCobroType==PagoCobroType.ES_COBRO ){
			divisa = historicoOperacion.getDivisaRecibo();
		}else{
			divisa = historicoOperacion.getDivisaPago();
		}
		
		StringBuffer errorCode = new StringBuffer();
		Boolean error = historicoFechaFormulaBo.generarFechas(historicoOperacion, credentials.getUsername(), 
				mantFechasPantalla.getFechaIni(), mantFechasPantalla.getFechaFin(), mantFechasPantalla.getFrecuencia(),
				mantFechasPantalla.getPeso(), mantFechasPantalla.getObservaciones(),modo,divisa,errorCode);
		
		if (error)		{
			if (!GenericUtils.isNullOrBlank(errorCode)){
				statusMessages.add(Severity.ERROR, errorCode.toString());
			}else{
				statusMessages.addFromResourceBundle(Severity.ERROR, "mantfechas.error.unknown");
			}
		}
		else {
			if (!GenericUtils.isNullOrBlank(errorCode)){
				statusMessages.add(Severity.WARN, errorCode.toString());
			}
			historicoFechaFormulaBo.evictFechas(this.getListadoHistoricoFechaFormula());
			primerAcceso = true;
		}
	}
	
	public void generacionFechasLiq() {
		//Llamar package
		Divisa divisa = null;
		if (pagoCobroType==PagoCobroType.ES_COBRO ){
			divisa = historicoOperacion.getDivisaRecibo();
		}else{
			divisa = historicoOperacion.getDivisaPago();
		}
		
		StringBuffer errorCode = new StringBuffer();
		Boolean error = historicoFechaFormulaBo.generarFechasLiq(historicoOperacion, credentials.getUsername(), 
				mantFechasPantalla.getFechaIni(), mantFechasPantalla.getFechaFin(), mantFechasPantalla.getFrecuencia(),
				mantFechasPantalla.getFactorLiquidacion(), mantFechasPantalla.getTipoInformacionPrecio(),mantFechasPantalla.getRateLiquidacion(),modo,divisa,errorCode);
		
		if (error)		{
			if (!GenericUtils.isNullOrBlank(errorCode)){
				statusMessages.add(Severity.ERROR, errorCode.toString());
			}else{
				statusMessages.addFromResourceBundle(Severity.ERROR, "mantfechas.error.unknown");
			}
		}
		else {
			if (!GenericUtils.isNullOrBlank(errorCode)){
				statusMessages.add(Severity.WARN, errorCode.toString());
			}
			historicoFechaFormulaBo.evictFechas(this.getListadoHistoricoFechaFormula());
			primerAcceso = true;
		}
	}
	
	
	public String anadirFecha(){
			
		if(!GenericUtils.isNullOrBlank(mantFechasPantalla.getFechaIni())){
			if(!validaFechas()){
				return Constantes.CONSTANTE_NO;
			}
		
			if(GenericUtils.isNullOrBlank(this.getHistoricoFechaFormula()) || Constantes.MODO_EJERCICIO.equals(modo) || Constantes.MODO_SELECCION.equals(modo)  || Constantes.MODO_PAY_OFF.equals(modo)){
				if(!Constantes.MODO_PAY_OFF.equals(modo)){
					this.setHistoricoFechaFormula(new HistoricoFechaFormula(new HistoricoFechaFormulaId()));
				}
				mantFechasPantalla.setFechaFin((mantFechasPantalla.getFechaIni()));
				if(Constantes.MODO_SELECCION.equals(modo)){
					this.getHistoricoFechaFormula().setObservaciones(mantFechasPantalla.getObservaciones());
				}
			}
			
			if(mantFechasPantalla.getFechaFin().getTime() > historicoOperacion.getFechaVencimiento().getTime()){
				statusMessages.addFromResourceBundle(Severity.ERROR, "mantfechas.error.fechaVencimiento");
				return Constantes.CONSTANTE_NO;
			}
			
			
			if (mantFechasPantalla.getFechaFin().getTime() < mantFechasPantalla.getFechaIni().getTime()){
				statusMessages.addFromResourceBundle(Severity.ERROR, "mantfechas.fijacionStrike.errorFechas");
				return Constantes.CONSTANTE_NO;
			}
			
			
			this.getHistoricoFechaFormula().getId().setTipoFecha(this.modo);
			this.getHistoricoFechaFormula().getId().setFechaFin(mantFechasPantalla.getFechaFin());
			this.getHistoricoFechaFormula().getId().setFechaInicio(mantFechasPantalla.getFechaIni());
			this.getHistoricoFechaFormula().getId().setHistoricoOperacion(historicoOperacion);
			this.getHistoricoFechaFormula().setUsuario(credentials.getUsername());
			
			//No se pueden añadir duplicados nunca
			if(!GenericUtils.isNullOrBlank(getHistoricoFechaFormulaSelect())){
				if (EntityUtil.containsEntity(this.getListadoHistoricoFechaFormula(), this.getHistoricoFechaFormula()) ) {
					statusMessages.addFromResourceBundle(Severity.ERROR, "mantfechas.error.fechaRepetida");
					return Constantes.CONSTANTE_NO;
				}
			}
			
			this.getListadoHistoricoFechaFormula().add(this.getHistoricoFechaFormula());
			
		}
		//primerAcceso=true;
		//Y guardamos para que no se pierdan los cambios
		//entityManager.persist(this.getHistoricoFechaFormula());
		//entityManager.flush();
		Collections.sort(getListadoHistoricoFechaFormula(), new HistoricoFechaFormula());

		//SMM 18/08/2016
		if (mostrarAcumulados()) calcularAcumulados(this.getListadoHistoricoFechaFormula());
		
		return Constantes.CONSTANTE_SUCCESS;
		
	}
	
	
	
	public void borrarFecha(){
		this.getListadoHistoricoFechaFormula().remove(this.getHistoricoFechaFormula());
		//Y guardamos para que no se pierdan los cambios		
	}
	
	public void cargaObservaciones(){
		HistoricoFechaFormula hist = new HistoricoFechaFormula( new HistoricoFechaFormulaId()); 
		this.setHistoricoFechaFormula(hist);
		this.getHistoricoFechaFormula().getId().setTipoFecha(this.getHistoricoFechaFormulaSelect().getId().getTipoFecha());
		mantFechasPantalla.setFechaIni(new Date(this.getHistoricoFechaFormulaSelect().getId().getFechaInicio().getTime()));
		if(!GenericUtils.isNullOrBlank(this.getHistoricoFechaFormulaSelect().getObservaciones())){
			mantFechasPantalla.setObservaciones(new String(this.getHistoricoFechaFormulaSelect().getObservaciones().toString()));
		}else{
			mantFechasPantalla.setObservaciones(new String());
		}
	}
	
	public MantFechasPantalla getMantFechasPantalla() {
		return mantFechasPantalla;
	}

	public void setMantFechasPantalla(MantFechasPantalla mantFechasPantalla) {
		this.mantFechasPantalla = mantFechasPantalla;
	}


	public BoletasPantalla getBoletasPantalla() {
		return boletasPantalla;
	}


	public void setBoletasPantalla(BoletasPantalla boletasPantalla) {
		this.boletasPantalla = boletasPantalla;
	}


	public HistoricoFechaFormulaBo getHistoricoFechaFormulaBo() {
		return historicoFechaFormulaBo;
	}


	public void setHistoricoFechaFormulaBo(
			HistoricoFechaFormulaBo historicoFechaFormulaBo) {
		this.historicoFechaFormulaBo = historicoFechaFormulaBo;
	}


	public HistoricoOperacion getHistoricoOperacion() {
		return historicoOperacion;
	}


	public void setHistoricoOperacion(HistoricoOperacion historicoOperacion) {
		this.historicoOperacion = historicoOperacion;
	}

	
	public Boolean getRateObl() {
		return rateObl;
	}


	public void setRateObl(Boolean rateObl) {
		this.rateObl = rateObl;
	}


	public Boolean getOp1Obl() {
		return op1Obl;
	}


	public void setOp1Obl(Boolean op1Obl) {
		this.op1Obl = op1Obl;
	}


	public Boolean getOp2Obl() {
		return op2Obl;
	}


	public void setOp2Obl(Boolean op2Obl) {
		this.op2Obl = op2Obl;
	}


	public String getModo() {
		return modo;
	}


	public void setModo(String modo) {
		this.modo = modo;
	}


	public List<HistoricoFechaFormula> getListadoHistoricoFechaFormula() {
		return listadoHistoricoFechaFormula;
	}


	public void setListadoHistoricoFechaFormula(
			List<HistoricoFechaFormula> listadoHistoricoFechaFormula) {
		this.listadoHistoricoFechaFormula = listadoHistoricoFechaFormula;
	}


	public HistoricoFechaFormula getHistoricoFechaFormulaSelect() {
		return historicoFechaFormulaSelect;
	}


	public void setHistoricoFechaFormulaSelect(
			HistoricoFechaFormula historicoFechaFormulaSelect) {
		this.historicoFechaFormulaSelect = historicoFechaFormulaSelect;
	}


	public HistoricoFechaFormula getHistoricoFechaFormula() {
		return historicoFechaFormula;
	}


	public void setHistoricoFechaFormula(HistoricoFechaFormula historicoFechaFormula) {
		this.historicoFechaFormula = historicoFechaFormula;
	}


	public Boolean getRateDesactivado() {
		return rateDesactivado;
	}


	public void setRateDesactivado(Boolean rateDesactivado) {
		this.rateDesactivado = rateDesactivado;
	}





	public Boolean getOp1Desactivado() {
		return op1Desactivado;
	}


	public void setOp1Desactivado(Boolean op1Desactivado) {
		this.op1Desactivado = op1Desactivado;
	}


	public Boolean getFactLiqDesactivado() {
		return factLiqDesactivado;
	}


	public void setFactLiqDesactivado(Boolean factLiqDesactivado) {
		this.factLiqDesactivado = factLiqDesactivado;
	}


	public Boolean getOp2Desactivado() {
		return op2Desactivado;
	}


	public void setOp2Desactivado(Boolean op2Desactivado) {
		this.op2Desactivado = op2Desactivado;
	}

}
