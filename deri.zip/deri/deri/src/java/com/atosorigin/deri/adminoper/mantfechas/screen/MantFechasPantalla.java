package com.atosorigin.deri.adminoper.mantfechas.screen;

import java.math.BigDecimal;
import java.util.Date;

import org.jboss.seam.ScopeType;
import org.jboss.seam.annotations.Name;
import org.jboss.seam.annotations.Scope;

import com.atosorigin.deri.model.mercado.Plazo;


@Name("mantFechasPantalla")
@Scope(ScopeType.CONVERSATION)
public class MantFechasPantalla {

	protected Date fechaIni;
	
	protected Date fechaFin;
	
	protected String observaciones;
	
	protected String peso;

	protected String dias;
	
	protected BigDecimal rangoUpper;
	
	protected BigDecimal rangoLower;
	
	protected Plazo frecuencia;
	
	protected String tipoInformacionPrecio;
	protected String factorLiquidacion;
	protected BigDecimal rateLiquidacion;
	
	
	public String getDias() {
		return dias;
	}

	public void setDias(String dias) {
		this.dias = dias;
	}

	public Date getFechaIni() {
		return fechaIni;
	}

	public void setFechaIni(Date fechaIni) {
		this.fechaIni = fechaIni;
	}

	public Date getFechaFin() {
		return fechaFin;
	}

	public void setFechaFin(Date fechaFin) {
		this.fechaFin = fechaFin;
	}

	public String getObservaciones() {
		return observaciones;
	}

	public void setObservaciones(String observaciones) {
		this.observaciones = observaciones;
	}

	public String getPeso() {
		return peso;
	}

	public void setPeso(String peso) {
		this.peso = peso;
	}

	public BigDecimal getRangoUpper() {
		return rangoUpper;
	}

	public void setRangoUpper(BigDecimal rangoUpper) {
		this.rangoUpper = rangoUpper;
	}

	public BigDecimal getRangoLower() {
		return rangoLower;
	}

	public void setRangoLower(BigDecimal rangoLower) {
		this.rangoLower = rangoLower;
	}

	public Plazo getFrecuencia() {
		return frecuencia;
	}

	public void setFrecuencia(Plazo frecuencia) {
		this.frecuencia = frecuencia;
	}

	public String getTipoInformacionPrecio() {
		return tipoInformacionPrecio;
	}

	public void setTipoInformacionPrecio(String tipoInformacionPrecio) {
		this.tipoInformacionPrecio = tipoInformacionPrecio;
	}

	public String getFactorLiquidacion() {
		return factorLiquidacion;
	}

	public void setFactorLiquidacion(String factorLiquidacion) {
		this.factorLiquidacion = factorLiquidacion;
	}

	public BigDecimal getRateLiquidacion() {
		return rateLiquidacion;
	}

	public void setRateLiquidacion(BigDecimal rateLiquidacion) {
		this.rateLiquidacion = rateLiquidacion;
	}

	
}
