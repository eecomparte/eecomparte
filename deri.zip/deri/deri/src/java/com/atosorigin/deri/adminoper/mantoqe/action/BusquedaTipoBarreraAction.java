package com.atosorigin.deri.adminoper.mantoqe.action;

import java.util.List;

import org.jboss.seam.ScopeType;
import org.jboss.seam.annotations.In;
import org.jboss.seam.annotations.Name;
import org.jboss.seam.annotations.Scope;

import com.atosorigin.common.action.PaginatedListAction;
import com.atosorigin.deri.adminoper.mantoqe.business.MantoqeBarreraBo;
import com.atosorigin.deri.adminoper.mantoqe.screen.BusquedaTipoBarreraPantalla;
import com.atosorigin.deri.model.gestionoperaciones.HistoricoBarreraReturn;
import com.atosorigin.deri.model.gestionoperaciones.HistoricoOperacion;


/**
 * 
 */
@Name("busquedaTipoBarreraAction")
@Scope(ScopeType.CONVERSATION)
public class BusquedaTipoBarreraAction extends PaginatedListAction {
	
	@In("#{mantoqeBarreraBo}")
	protected MantoqeBarreraBo mantoqeBarreraBo;
	
	@In(value="historicoOperacion")
	protected HistoricoOperacion historicoOperacion;
	
	@In(create=true)
	protected BusquedaTipoBarreraPantalla busquedaTipoBarreraPantalla; 
	
	
	public void buscar(){
		refrescarLista();		
	}
	
	public void cargar(){		
		mantoqeBarreraBo.obtenerBarrera(historicoOperacion);
	}

	public MantoqeBarreraBo getMantoqeBarreraBo() {
		return mantoqeBarreraBo;
	}

	public void setMantoqeBarreraBo(MantoqeBarreraBo mantoqeBarreraBo) {
		this.mantoqeBarreraBo = mantoqeBarreraBo;
	}

	@Override
	public List<?> getDataTableList() {
		return busquedaTipoBarreraPantalla.getListHistoricoBarreraReturn();
	}

	@Override
	protected void refreshListInternal() {
		busquedaTipoBarreraPantalla.setListHistoricoBarreraReturn(mantoqeBarreraBo.obtenerBarrera(historicoOperacion));
		
	}

	@Override
	public void refrescarListaExcel() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void setDataTableList(List<?> dataTableList) {
		busquedaTipoBarreraPantalla.setListHistoricoBarreraReturn((List<HistoricoBarreraReturn>)dataTableList);
		
	}

	public BusquedaTipoBarreraPantalla getBusquedaTipoBarreraPantalla() {
		return busquedaTipoBarreraPantalla;
	}

	public void setBusquedaTipoBarreraPantalla(
			BusquedaTipoBarreraPantalla busquedaTipoBarreraPantalla) {
		this.busquedaTipoBarreraPantalla = busquedaTipoBarreraPantalla;
	}
	
}
