package com.atosorigin.deri.adminoper.mantoqe.action;

import java.math.BigDecimal;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.jboss.seam.ScopeType;
import org.jboss.seam.annotations.In;
import org.jboss.seam.annotations.Name;
import org.jboss.seam.annotations.Out;
import org.jboss.seam.annotations.Scope;
import org.jboss.seam.core.Conversation;
import org.jboss.seam.international.StatusMessage.Severity;
import org.jboss.seam.security.Credentials;

import com.atosorigin.common.action.GenericAction;
import com.atosorigin.common.constantes.Constantes;
import com.atosorigin.common.utils.GenericUtils;
import com.atosorigin.deri.adminoper.mantbarreras.business.MantenimientoBarrerasBo;
import com.atosorigin.deri.adminoper.mantoqe.business.MantoqeBarreraBo;
import com.atosorigin.deri.adminoper.mantoqe.screen.MantoqePantalla;
import com.atosorigin.deri.common.dbLock.DbLockService;
import com.atosorigin.deri.common.parametrosPantalla.ParametrosMantoper;
import com.atosorigin.deri.model.adminoper.HistoricoBarrera;
import com.atosorigin.deri.model.adminoper.HistoricoBarreraId;
import com.atosorigin.deri.model.gestionoperaciones.HistoricoBarreraReturn;
import com.atosorigin.deri.model.gestionoperaciones.HistoricoOperacion;
import com.atosorigin.deri.model.gestionoperaciones.HistoricoOperacionId;
import com.atosorigin.deri.model.gestionoperaciones.MantoqeGlobal;
import com.atosorigin.deri.model.gestionoperaciones.PosiblesToques;
import com.atosorigin.deri.model.mercado.HistoricoTramos;
import com.atosorigin.deri.util.MsgBoxAction;

@Name("manToqeAction")
@Scope(ScopeType.CONVERSATION)
public class ManToqeAction extends GenericAction {

	@In(value = "origen")
	protected String origen;

	@In(value = "posiblesToques", required = false)
	protected PosiblesToques posiblesToques;

	@In(value = "codevent", required = false)
	protected Integer codevent;

	@In(required = false, value = "parametrosMantOper")
	private ParametrosMantoper parametrosMantOper;
	
	@In(value = "historicoOperacion")
	private HistoricoOperacion historicoOperacion;

	@In(create = true)
	protected MantoqePantalla mantoqePantalla;

	@In("#{mantenimientoBarrerasBo}")
	private MantenimientoBarrerasBo mantenimientoBarrerasBo;
	
	@In("#{mantoqeBarreraBo}")
	private MantoqeBarreraBo mantoqeBarreraBo;
	
	@In(create = true)
	private MsgBoxAction msgBoxAction;	

	@In Credentials credentials;	

	/** Declaracion de variables */
	protected String produc;

	MantoqeGlobal mantoqeGlobal = new MantoqeGlobal();
	
	boolean muestraPanel = false;
	
	boolean muestraPanel2 = false;
	
	/** Inyección del servicio que gestiona los bloqueos de registros en base de datos */
	@In(create = true)
	protected DbLockService dbLockService;
	
	/** Inyección del objeto para la union con MANTPROD */
	@In(required=false)
	@Out(required=false)
	String varModif;
	
	//Validaciones
	public boolean realizarValidaciones(){
		
		boolean festivo = false;
		boolean toqueMenorFechaInicialBarrera = false;
		boolean toqueMayorFechaFinalBarrera = false;
		Date fechaToque = mantoqePantalla.getVistaMantoqe().getFechatoque();
		Date fechaInicialBarrera = mantoqePantalla.getVistaMantoqe().getHistoricoBarreraReturn().getFeciniba();
		Date fechaFinalBarrera = mantoqePantalla.getVistaMantoqe().getHistoricoBarreraReturn().getFecfinba();
		
		if(fechaToque.compareTo(fechaInicialBarrera)<0){
			toqueMenorFechaInicialBarrera = true;
		}
		if(fechaToque.compareTo(fechaFinalBarrera)>0){
			toqueMayorFechaFinalBarrera = true;
		}
		
		
		if(mantoqePantalla.getVistaMantoqe().getFechaLiquidacion()!=null){
			festivo = mantoqeBarreraBo.esFestivo(mantoqePantalla.getVistaMantoqe().getFechaLiquidacion(),mantoqePantalla.getVistaMantoqe().getHistoricoBarreraReturn().getDivireba());
		}
		if(mantoqePantalla.getVistaMantoqe().getFechatoque()==null){
			statusMessages.add(Severity.ERROR, "#{messages['toqueBarrera.fechaToque.error']}");
			return false;
		}else if(mantoqeGlobal.getTipoBarrera().equals(Constantes.MANTOQE_I) && (!toqueMayorFechaFinalBarrera || !toqueMenorFechaInicialBarrera)){
			statusMessages.add(Severity.ERROR, "#{messages['toqueBarrera.fechaToque.intervalos']}");
			return false;
		}else if(mantoqePantalla.getVistaMantoqe().getHistoricoBarreraReturn().getPata()!=null && (GenericUtils.isNullOrBlank(mantoqePantalla.getVistaMantoqe().getHistoricoBarreraReturn().getImprebat()))){
			statusMessages.add(Severity.ERROR, "#{messages['toqueBarrera.importeRebate.error']}");
			return false;
		}else if(fechaToque.compareTo(mantoqeGlobal.getFechamisARL())>0){
			statusMessages.add(Severity.ERROR, "#{messages['toqueBarrera.fechaToque.superior']}");
			return false;
		}else if(mantoqePantalla.getVistaMantoqe().getHistoricoBarreraReturn().getFechaRebat() == null && mantoqePantalla.getVistaMantoqe().getHistoricoBarreraReturn().getImprebat().compareTo(new BigDecimal(0))>0){
			statusMessages.add(Severity.ERROR, "#{messages['toqueBarrera.fechaLiquidacion.fechaRebate']}");
			return false;			
		}else if(mantoqePantalla.getVistaMantoqe().getHistoricoBarrera().getTipobarr().equals(Constantes.MANTOQE_D) && mantoqePantalla.getVistaMantoqe().getPrecio().compareTo(mantoqePantalla.getVistaMantoqe().getHistoricoBarreraReturn().getNivebarr())>0){
			statusMessages.add(Severity.ERROR, "#{messages['toqueBarrera.precio.error.mayor']}");
			return false;
		}else if(mantoqePantalla.getVistaMantoqe().getHistoricoBarrera().getTipobarr().equals(Constantes.MANTOQE_U) && mantoqePantalla.getVistaMantoqe().getPrecio().compareTo(mantoqePantalla.getVistaMantoqe().getHistoricoBarreraReturn().getNivebarr())<0){
			statusMessages.add(Severity.ERROR, "#{messages['toqueBarrera.precio.error.menor']}");
			return false;
		}else if(mantoqePantalla.getVistaMantoqe().getHistoricoBarreraReturn().getFechaRebat() != null && festivo){
			statusMessages.add(Severity.ERROR, "#{messages['toqueBarrera.fechaLiquidacion.error.festivo']}");
			return false;
		}else{
			return true;
		}		
	}
	
	// montar string 1007
	public void montarString1007(String tipoOperacion, Date fecinitr, Date fechaInicioTramo, Date fecfintr, Date fechaFinTramo, Date fechatoque,
			String tipBarP1, String producto, int ordenBarr) {
		StringBuilder sb = new StringBuilder();
		sb.append(tipoOperacion+" ");
		if (fecinitr == null && fechaInicioTramo==null){
			//8 Blancos + 1
			sb.append("        "+" ");
		}else{
			sb.append(GenericUtils.to_char(GenericUtils.nvl(fecinitr, fechaInicioTramo),Constantes.YYYYMMDD)+" ");	
		}
		if (fecfintr == null && fechaFinTramo==null){
			//8 Blancos + 1
			sb.append("        "+" ");
		}else{
			sb.append(GenericUtils.to_char(GenericUtils.nvl(fecfintr, fechaFinTramo),Constantes.YYYYMMDD)+" ");	
		}
		
		sb.append(Constantes.MANTOQE_INT+" "+Constantes.MANTOQE_OPC+" ");
		if (fechatoque==null){
			//8 Blancos + 1
			sb.append("        "+" ");
		}else{
			sb.append(GenericUtils.to_char(fechatoque, Constantes.YYYYMMDD) + " ");	
		}

		sb.append(tipBarP1 + " ");
		sb.append(producto + " ");
		sb.append(GenericUtils.lpad(Integer.toString(ordenBarr),3,"0"));
		
		
		mantoqePantalla.getVistaMantoqe().setStringPantalla(sb.toString());

	}
	
	public void dummy(){
		muestraPanel = false;
		muestraPanel2 = false;
	}
	// toque barrera
	public void toqueBarrera(){
		mantoqeGlobal.setInditoqe(Constantes.MANTOQE_S);
		
		if(!comprobarToque(historicoOperacion) && verificaPositoqe(mantoqePantalla.getVistaMantoqe().getFechatoque())){
			if(verificaFechatoq(mantoqePantalla.getVistaMantoqe().getFechatoque())){
				muestraPanel = true;
				msgBoxAction.setOnCompleteNo(null);
				msgBoxAction.setOnCompleteSi(null);
				msgBoxAction.mostrarMsg(
						"#{manToqeAction.confirmaToqueBarrera}",
						"#{manToqeAction.dummy}",
						"Se va a realizar el Toque de Barrera ¿Desea grabar los cambios?");

				//confirmaToqueBarrera();
			}
		}else{
			statusMessages.add(Severity.ERROR, "#{messages['toqueBarrera.toque.noPermitido']}");
		}
		varModif = Constantes.CONSTANTE_SI;		
	}

	public boolean comprobarToque(HistoricoOperacion histoper){
		String tipBarP1Pantalla = mantoqePantalla.getVistaMantoqe().getHistoricoBarreraReturn().getTipBarP1();
		
		if (histoper.getHistoricoBarreras()!=null ){
			for (HistoricoBarrera barrera : histoper.getHistoricoBarreras()) {
	
				String tipbarp1 = barrera.getId().getTipbarp1();
//				tipbarp1.endsWith("I") &&
				if( tipBarP1Pantalla.equalsIgnoreCase(tipbarp1) && barrera.getFevaltoq() != null) {
					return true;
				} 
			}
		}
		
		return false;
	}
	
	public void confirmaToqueBarrera() {//1006
			montarStringEvento();
			String retorno = null;
			try{
			//mantoqeBarreraBo.insertarAgendoTC(mantoqePantalla.getVistaMantoqe().getFechamisARL(), (int)1006,mantoqeGlobal.getCodigoEvento(), mantoqePantalla.getVistaMantoqe().getMantoqeReturn().getProducto(), historicoOperacion, mantoqePantalla.getVistaMantoqe().getStringPantalla(), mantoqePantalla.getVistaMantoqe().getMantoqeReturn().getUsultact());
				retorno = mantoqeBarreraBo.insertarAgendoTCconRet(mantoqeGlobal.getFechamisARL(), (int)1006,mantoqePantalla.getVistaMantoqe().getMantoqeReturn().getProducto(), historicoOperacion, mantoqePantalla.getVistaMantoqe().getStringPantalla(), mantoqePantalla.getVistaMantoqe().getMantoqeReturn().getUsultact());
			}catch (Exception e){
				String s=e.getMessage();
			}
		// COMMIT
			if (retorno!= null){
				statusMessages.add(Severity.ERROR,retorno);
			}else{
				insertarPositoqe();
				mantoqeBarreraBo.flush();
				mantoqeGlobal.setCambios(Constantes.MANTOQE_S);
				salir();
			}
	}
	
	private boolean confirmaToqueBarreraValidator(){
		return realizarValidaciones();
	}

	// no toque barrera
	public void noToqueBarrera(){
		mantoqeGlobal.setInditoqe(Constantes.MANTOQE_N);
		if(!comprobarToque(historicoOperacion) && verificaPositoqe(mantoqePantalla.getVistaMantoqe().getFechatoque())){
			if(verificaFechatoq(mantoqePantalla.getVistaMantoqe().getFechatoque())){
				muestraPanel2 = true;
					//si confirman 
				msgBoxAction.setOnCompleteNo(null);
				msgBoxAction.setOnCompleteSi(null);
				msgBoxAction.mostrarMsg(
						"#{manToqeAction.confirmaNoToqueBarrera}",
						"#{manToqeAction.dummy}",
						"Se va a NO Tocar la Barrera ¿Desea grabar los cambios?");

					//confirmaNoToqueBarrera();
			}
		}else{
			//mostrar mensaje toquebarrera.notoque.nopermitido
			statusMessages.add(Severity.ERROR, "#{messages['toqueBarrera.noToque.noPermitido']}");
		}
		varModif = Constantes.CONSTANTE_SI;
		
	}

	private boolean confirmaNoToqueBarreraValidator(){
		return realizarValidaciones();		
	}	
	
	public void confirmaNoToqueBarrera() {//1007	
		
		if (mantoqeGlobal.getCodigoEvento()!=null && mantoqeGlobal.getCodigoEvento()!=  0L){
			mantoqeBarreraBo.matarEvento2003(historicoOperacion,mantoqePantalla.getVistaMantoqe().getMantoqeReturn().getUsultact(), mantoqeGlobal.getCodigoEvento());			
		}else{
			mantoqeBarreraBo.matarEvento2003(historicoOperacion,mantoqePantalla.getVistaMantoqe().getMantoqeReturn().getUsultact(), 2003);	
		}
		montarString1007(mantoqeGlobal.getTipoOperacion()!=null?mantoqeGlobal.getTipoOperacion():mantoqeGlobal.getTipoPera(),mantoqeGlobal.getFecinitr(), mantoqeGlobal.getFechaInicioTramo(),mantoqeGlobal.getFecfintr(),mantoqeGlobal.getFechaFinTramo(),mantoqeGlobal.getFechatoque(),mantoqePantalla.getVistaMantoqe().getHistoricoBarreraReturn().getTipBarP1(),mantoqePantalla.getVistaMantoqe().getMantoqeReturn().getProducto(),mantoqePantalla.getVistaMantoqe().getHistoricoBarreraReturn().getOrdenBarr());
		String retorno = mantoqeBarreraBo.insertarAgendoTCconRet(mantoqePantalla.getVistaMantoqe().getFechamisARL(), 1007, mantoqePantalla.getVistaMantoqe().getMantoqeReturn().getProducto(), historicoOperacion, mantoqePantalla.getVistaMantoqe().getStringPantalla(), mantoqePantalla.getVistaMantoqe().getMantoqeReturn().getUsultact());
		// COMMIT
		if (retorno!= null){
			statusMessages.add(Severity.ERROR,retorno);
		}else{
			insertarPositoqe();
			mantoqeBarreraBo.flush();
			mantoqeGlobal.setCambios(Constantes.MANTOQE_S);
			salir();
		}
	}

	// obtener numero evento agendoTC
/*	public int obtenerNumeroEventoAgendoTC() {
		int contador = Integer.parseInt(mantoqeBarreraBo.selectNumeroEventoContador(mantoqeGlobal.getFechamisARL()).toString());
		contador = contador + 1;
		if (contador == 10000000) {
			try {
				mantoqeBarreraBo.insertNumeroEventoContador(mantoqeGlobal.getFechamisARL(), contador);
			} catch (Exception e) {
				mantoqeGlobal.setErroresCanc(Constantes.MANTOQE_S);
			}
		} else {
			try {
				mantoqeBarreraBo.updateNumeroEventoContador(mantoqeGlobal.getFechamisARL(), contador);
			} catch (Exception e) {
				mantoqeGlobal.setErroresCanc(Constantes.MANTOQE_S);
			}
		}
		return contador;
	}*/

	// montar String Evento para TOQUE de barrera
	public void montarStringEvento() {
		String signo;
		if (mantoqePantalla.getVistaMantoqe().getHistoricoBarreraReturn().getPata()==null){
			signo = Constantes.MANTOQE_SIGNO_MAS;
		}else if (mantoqePantalla.getVistaMantoqe().getHistoricoBarreraReturn().getPata().equals(Constantes.MANTOQE_PATA_P)) {
			signo = Constantes.MANTOQE_SIGNO_MENOS;
		} else {
			signo = Constantes.MANTOQE_SIGNO_MAS;
		}

		SimpleDateFormat sdf1 = new SimpleDateFormat(Constantes.YYYYMMDD);
	
		Date d1 = null;
		Date d2 = null;

		if (mantoqeGlobal.getFecinitr() == null) {
			d1 = mantoqeGlobal.getFechaInicioTramo();
		} else {
			d1 = mantoqeGlobal.getFecinitr();
		}
		if (mantoqeGlobal.getFecfintr() == null) {
			d2 = mantoqeGlobal.getFechaFinTramo();
		} else {
			d2 = mantoqeGlobal.getFecfintr();
		}

		String s1 = sdf1.format(d1);
		String s2 = sdf1.format(d2);
		StringBuilder sb = new StringBuilder();

		sb.append(mantoqeGlobal.getTipoOperacion()!=null?mantoqeGlobal.getTipoOperacion():mantoqeGlobal.getTipoPera());
		sb.append(" ");
		sb.append(s1);
		sb.append(" ");
		sb.append(s2);
		sb.append(" ");
		sb.append(Constantes.MANTOQE_INT+" ");
		sb.append(Constantes.MANTOQE_OPC+" ");
		sb.append(GenericUtils.to_char(mantoqePantalla.getVistaMantoqe().getFechatoque(),Constantes.YYYYMMDD));
		sb.append(" ");
		sb.append(GenericUtils.lpad(mantoqeGlobal.getCodigoFormulario(), 5, "0"));
		sb.append(" ");
		sb.append(mantoqePantalla.getVistaMantoqe().getHistoricoBarreraReturn().getTipBarP1()); // tipo barrera
		sb.append(" ");
		
		BigDecimal formatoDecimal =new BigDecimal("1000000000000");//12 decimales
				
		BigDecimal nivelBarrera = mantoqePantalla.getVistaMantoqe().getHistoricoBarreraReturn().getNivebarr();
		BigDecimal nvlNivelBarrera = (BigDecimal) GenericUtils.nvl(nivelBarrera, new BigDecimal("0"));
		Number numberNvlNivelBarrera = nvlNivelBarrera.multiply(formatoDecimal);
		String toCharNumberNvlNivelBarrera = GenericUtils.to_char(numberNvlNivelBarrera);
		String replacedToCharNumberNvlNivelBarrera = GenericUtils.lpad(GenericUtils.replace(toCharNumberNvlNivelBarrera, ".", ""),17,"0");
		sb.append(replacedToCharNumberNvlNivelBarrera);
		sb.append(" ");
		
		sb.append(historicoOperacion.getProducto().getId()); // producto
		sb.append(" ");

		
		BigDecimal pantallaPrecio = mantoqePantalla.getVistaMantoqe().getPrecio();
		Number nvlPantallaPrecio = (Number)(GenericUtils.nvl(pantallaPrecio, new BigDecimal(0))).multiply(formatoDecimal);
		String toCharNumberNvlPantallaPrecio = GenericUtils.to_char(nvlPantallaPrecio);
		String replacedToCharNumberNvlPantallaPrecio = GenericUtils.lpad(GenericUtils.replace(toCharNumberNvlPantallaPrecio, ".", ""),17,"0");
		sb.append(replacedToCharNumberNvlPantallaPrecio);
		sb.append(" ");
		BigDecimal importeRebate = mantoqePantalla.getVistaMantoqe().getHistoricoBarrera().getImprebat();
		Number nvlImporteRebate = (Number) ((BigDecimal)GenericUtils.nvl(importeRebate, new BigDecimal(0))).multiply(new BigDecimal(10000));//forzamos 4 decimales
		String toCharNumberNvlImporteRebate = GenericUtils.to_char(nvlImporteRebate);
		String replacedToCharNumberNvlImporteRebate = GenericUtils.lpad(GenericUtils.replace(toCharNumberNvlImporteRebate, ".", ""),17,"0");
		sb.append(replacedToCharNumberNvlImporteRebate);
		sb.append(" ");
		sb.append(signo + " ");
		String pantallaDivisa = mantoqePantalla.getVistaMantoqe().getMantoqeReturn().getDivisano();
		String nvlPantallaDivisa = (String) GenericUtils.nvl(pantallaDivisa, "");
		String rpadNvlPantallaDivisa = GenericUtils.rpad(nvlPantallaDivisa, 3, " ");
		sb.append(rpadNvlPantallaDivisa);
		sb.append(" ");
		Date pantallaFechaRebate = mantoqePantalla.getVistaMantoqe().getHistoricoBarreraReturn().getFechaRebat();
		String toCharPantallaFechaRebate = null;
		if (pantallaFechaRebate !=null){
			toCharPantallaFechaRebate = GenericUtils.to_char(pantallaFechaRebate);
		}
		String nvlToCharPantallaFechaRebate = (String) GenericUtils.nvl(toCharPantallaFechaRebate, "00000000");
		sb.append(nvlToCharPantallaFechaRebate + " ");
		String pantallaObservaciones = mantoqePantalla.getVistaMantoqe().getHistoricoBarreraReturn().getObservac();
		String nvlPantallaObservaciones = (String) GenericUtils.nvl(pantallaObservaciones, "");
		String rpadNvlPantallaObservaciones = GenericUtils.rpad(nvlPantallaObservaciones, 200, " ");
		sb.append(rpadNvlPantallaObservaciones + " ");
		if (mantoqePantalla.getVistaMantoqe().getHistoricoBarreraReturn().getOrdenBarr() == 0){
			sb.append("001");
		}else {
			sb.append(GenericUtils.lpad(Integer.toString(mantoqePantalla.getVistaMantoqe().getHistoricoBarreraReturn().getOrdenBarr()),3,"0"));	
		}
		sb.append(GenericUtils.rpad("", 57, " "));
		mantoqePantalla.getVistaMantoqe().setStringPantalla(sb.toString());

	}
	
	
	
	// insertar Positoqe
	public void insertarPositoqe() {
		// insertar
//		Date vFechaIniTr = mantoqePantalla.getVistaMantoqe().getHistoricoBarreraReturn().getFeciniba();
//		Date vFechaFinTr = mantoqePantalla.getVistaMantoqe().getHistoricoBarreraReturn().getFecfinba();
		Date vFechaIniTr = mantoqeGlobal.getFechaInicioTramo();
		Date vFechaFinTr = mantoqeGlobal.getFechaFinTramo();
		
		String tipBarP1 = mantoqePantalla.getVistaMantoqe().getHistoricoBarreraReturn().getTipBarP1();
		Date fechatoque = mantoqePantalla.getVistaMantoqe().getFechatoque();
		BigDecimal precioeje = mantoqePantalla.getVistaMantoqe().getPrecio();
		//1924 Actualizar usuario
//		String usultact = mantoqePantalla.getVistaMantoqe().getMantoqeReturn().getUsultact();
		String usultact = credentials.getUsername();		
		
		String tipoOperacion = mantoqeGlobal.getTipoOperacion()!=null?mantoqeGlobal.getTipoOperacion():mantoqeGlobal.getTipoPera();
		String inditoqe = mantoqeGlobal.getInditoqe();
		Short ordenBarr;
		if (mantoqePantalla.getVistaMantoqe().getHistoricoBarreraReturn().getOrdenBarr() == 0){
			ordenBarr = Short.valueOf("1");
		}else{
			ordenBarr = Short.valueOf(Integer.toString(mantoqePantalla.getVistaMantoqe().getHistoricoBarreraReturn().getOrdenBarr()));	
		}
			

				
		mantoqeBarreraBo.insertarPositoqe(historicoOperacion, vFechaIniTr, vFechaFinTr, tipBarP1, fechatoque, precioeje, usultact, tipoOperacion,
				inditoqe, ordenBarr);
	}

	// verificafechatoq
	public boolean verificaFechatoq(Date fechatoque) {
		boolean salir = true;
//		if (Constantes.MANTOQE_TIPO_E.equalsIgnoreCase(mantoqeGlobal.getTipoBarrera())) {
//			int cuantos = mantoqeBarreraBo.cuantosSituparm(historicoOperacion, fechatoque);
//			if (cuantos == 0) {
//				statusMessages.add(Severity.ERROR, "#{messages['toqueBarrera.fechaToque.noTocable']}");
//				salir = false;
//			}
//		} else {
			if (mantoqePantalla.getVistaMantoqe().getFechatoque().compareTo(
					mantoqePantalla.getVistaMantoqe().getHistoricoBarreraReturn().getFeciniba()) > -1
					&& mantoqePantalla.getVistaMantoqe().getFechatoque().compareTo(
							mantoqePantalla.getVistaMantoqe().getHistoricoBarreraReturn().getFecfinba()) < 1) {
				// null
			} else {
				if (mantoqePantalla.getVistaMantoqe().getFechatoque().compareTo(
						mantoqePantalla.getVistaMantoqe().getHistoricoBarreraReturn().getFeciniba()) > 1) {
					mantoqePantalla.getVistaMantoqe().setFechatoque(mantoqePantalla.getVistaMantoqe().getHistoricoBarreraReturn().getFeciniba());
				} else {
					statusMessages.add(Severity.ERROR, "#{messages['toqueBarrera.fechaToque.intervalos']}");
					
					mantoqePantalla.getVistaMantoqe().setFechatoque(mantoqeGlobal.getFechamisARL());
					return false;
				}
			}
//		}
		return salir;
	}

	// verificapositoqe
	public boolean verificaPositoqe(Date fechatoque) {
		String tipBarP1 = mantoqePantalla.getVistaMantoqe().getHistoricoBarreraReturn().getTipBarP1();
		int count = mantoqeBarreraBo.cuantosPositoqe(historicoOperacion, mantoqeGlobal.getTipoOperacion()!=null?mantoqeGlobal.getTipoOperacion():mantoqeGlobal.getTipoPera(), mantoqeGlobal.getFechaInicioTramo(),
				mantoqeGlobal.getFechaFinTramo(), tipBarP1, fechatoque);

		if (count > 0) {
			return false;
		} else {
			return true;
		}
	}



	// Cargar datos barrera pantalla agenda
	public void cargarDatosBarreraPantallaAgenda() {
		
		mantoqePantalla.getVistaMantoqe().setHistoricoBarreraReturn(
				mantoqeBarreraBo.obtenerDatosBarreraAgenda(historicoOperacion,
						mantoqeGlobal.getTipoPera(),
						mantoqeGlobal.getTipBarP1()));

		// CONVERTIR A MANTOQGLOBAL HISTORICOBARRERA
		convertirAMantoqeGlobal(mantoqeBarreraBo.obtenerDatosGlobalesBarreraAgenda(
									historicoOperacion,
									mantoqeGlobal.getTipoPera(),
									mantoqeGlobal.getTipBarP1()));

		mantoqePantalla.getVistaMantoqe().setFechatoque(mantoqeGlobal.getFechamisARL());
		mantoqePantalla.getVistaMantoqe().setFechaLiquidacion(
				mantoqePantalla.getVistaMantoqe().getHistoricoBarreraReturn().getFecfinba());

		obtenerTipoOperacion();

		if (mantoqeGlobal.getTipBarP1() == null) {
			leerTramoPositoqe(historicoOperacion);
		} else {
			leerTramoPositoqeAgenda();
		}

	}

	private void obtenerTipoOperacion() {
		if (Constantes.MANTOQE_TIPO_P.equalsIgnoreCase(mantoqeGlobal.getTipoOperacion()!=null?mantoqeGlobal.getTipoOperacion():mantoqeGlobal.getTipoPera())) {
			mantoqePantalla.getVistaMantoqe().setPagoCobro(Constantes.MANTOQE_PAGO);
		} else {
			mantoqePantalla.getVistaMantoqe().setPagoCobro(Constantes.MANTOQE_COBRO);
		}
	}

	// Leer tramo positoqe
	public void leerTramoPositoqe(HistoricoOperacion historicoOperacion) {
		
		HistoricoTramos historicoTramos = 
			mantoqeBarreraBo.obtenerDatosGlobalesTramo(
					historicoOperacion,
					mantoqeGlobal.getTipoOperacion()!=null?mantoqeGlobal.getTipoOperacion():mantoqeGlobal.getTipoPera(),
					mantoqePantalla.getVistaMantoqe().getFechatoque());

		// Convertir a mantoqeglobal historicotramos
		convertirAMantoqeGlobal(historicoTramos);

		mantoqePantalla.getVistaMantoqe().setPrecio(
				mantoqeBarreraBo.obtenerPrecio(historicoOperacion, mantoqeGlobal.getTipoOperacion()!=null?mantoqeGlobal.getTipoOperacion():mantoqeGlobal.getTipoPera(),
						mantoqeGlobal.getFechaInicioTramo(),
						mantoqeGlobal.getFechaFinTramo(),
						mantoqeGlobal.getBarreraIO(),
						mantoqePantalla.getVistaMantoqe().getFechatoque()));
	}

	// Leer tramo positoqe agenda
	public void leerTramoPositoqeAgenda() {

		Integer codigoFormulario = mantoqeBarreraBo.obtenerCodigoFormulario(
										historicoOperacion,
										mantoqeGlobal.getTipoPera(),
										mantoqeGlobal.getConcepto(),
										mantoqeGlobal.getTipconce(),
										mantoqeGlobal.getFecinitr(),
										mantoqeGlobal.getFecfintr());
		
		if (GenericUtils.isNullOrBlank(codigoFormulario)) {
			mantoqeGlobal.setCodigoFormulario(null);
		} else {
			mantoqeGlobal.setCodigoFormulario(codigoFormulario.toString());
		}

		posiblesToques = mantoqeBarreraBo.obtenerDatosPantallaPositoqe(
							historicoOperacion,
							mantoqeGlobal.getTipoPera(),
							mantoqeGlobal.getConcepto(),
							mantoqeGlobal.getTipconce(),
							mantoqeGlobal.getFecinitr(),
							mantoqeGlobal.getFecfintr(),
							mantoqeGlobal.getTipBarP1(),
							mantoqeGlobal.getFechatoque());

		// Convertir a pantalla posiblestoques
		mantoqePantalla.getVistaMantoqe().setPosiblesToques(posiblesToques);
	}

	// Convertir a mantoqueglobal historicoBarrera
	public void convertirAMantoqeGlobal(HistoricoBarrera historicoBarrera) {
		if(historicoBarrera != null) {
			//mantoqeGlobal.setTipoBarr(historicoBarrera.getTipobarr());
			mantoqeGlobal.setTipoBarrera(historicoBarrera.getTipobarr());
			mantoqeGlobal.setTipoPera(historicoBarrera.getId().getTipopera());
			//mantoqeGlobal.setTipBarP1(historicoBarrera.getId().getTipbarp1());
			mantoqeGlobal.setTipoBarreraP1(historicoBarrera.getId().getTipbarp1());
		}
	}

	// Convertir a mantoqueglobal historicoTramos
	public void convertirAMantoqeGlobal(HistoricoTramos historicoTramos) {
		if(historicoTramos != null) {
			mantoqeGlobal.setFechaInicioTramo(historicoTramos.getId().getFechaInicioTramo());
			mantoqeGlobal.setFechaFinTramo(historicoTramos.getId().getFechaFinTramo());
			mantoqeGlobal.setCodigoFormulario(historicoTramos.getCodigoFormula().getCodigoFormula().toString());
		}
	}

	// Cargar Datos Barrera Pantalla
	public void cargarDatosBarreraPantalla(HistoricoOperacion historicoOperacion) {

		// Varios registros posibles Objeto vacio si hay varios o ninguno.
		mantoqePantalla.getVistaMantoqe().setHistoricoBarreraReturn(
				mantoqeBarreraBo.obtenerDatosBarrera(historicoOperacion,mantoqeGlobal.getBarreraIO()));

		HistoricoBarrera hb = mantoqeBarreraBo.obtenerDatosGlobalesBarrera(
				historicoOperacion, mantoqeGlobal.getBarreraIO());
		cargarDatosBarreraPantallaDos(historicoOperacion, hb);

	}

	private void cargarDatosBarreraPantallaDos(
			HistoricoOperacion historicoOperacion, HistoricoBarrera historicoBarrera ) {
		// Pantalla.producto
		mantoqePantalla.getVistaMantoqe().getMantoqeReturn().setDescriProducto(
				mantoqeBarreraBo.obtenerDescripcionProducto(historicoOperacion.getProductoCatalogo().getProducat()));

		// Convertir a mantoqeGlobal HistoricoBarrera
		// Varios registros posibles Null si hay más de uno o ninguno.
		convertirAMantoqeGlobal(historicoBarrera);

		// Pantalla.fechatoque
		mantoqePantalla.getVistaMantoqe().setFechatoque(mantoqeGlobal.getFechamisARL());

//		if (Constantes.MANTOQE_TIPO_E.equalsIgnoreCase(mantoqeGlobal.getTipoBarrera())) {
//			
//			int cuantos = mantoqeBarreraBo.cuantosSituparm(
//					historicoOperacion, mantoqePantalla.getVistaMantoqe().getFechatoque());
//			
//			if (cuantos == 0) {
//				mantoqePantalla.getVistaMantoqe().setFechatoque(
//						mantoqeBarreraBo.obtenerFechatoque(historicoOperacion.getId().getFechaContratacion(),
//								historicoOperacion.getId().getNumeroOperacion(),
//								mantoqePantalla.getVistaMantoqe().getFechatoque()));
//				if (GenericUtils.isNullOrBlank(mantoqePantalla.getVistaMantoqe().getFechatoque())) {
//					statusMessages.add(Severity.ERROR, "#{messages['toqueBarrera.fechaToque.noTocable']}");
//					mantoqePantalla.getVistaMantoqe().setFechatoque(mantoqeGlobal.getFechamisARL());
//				}
//			}
//		} else {
			if (fechatoqueEntreFechasBarrera()) {
				// null
			} else if (mantoqePantalla.getVistaMantoqe().getFechatoque().compareTo(
						mantoqePantalla.getVistaMantoqe().getHistoricoBarreraReturn().getFeciniba()) > -1) {
					mantoqePantalla.getVistaMantoqe().setFechatoque(mantoqePantalla.getVistaMantoqe().getHistoricoBarreraReturn().getFeciniba());
			} else {
					statusMessages.add(Severity.ERROR, "#{messages['toqueBarrera.fechaToque.intervalos']}");
					mantoqePantalla.getVistaMantoqe().setFechatoque(mantoqeGlobal.getFechamisARL());
			}
			
//		}

		mantoqeGlobal.setFechatoque(mantoqePantalla.getVistaMantoqe().getFechatoque());
		mantoqePantalla.getVistaMantoqe().setFechaLiquidacion(
				mantoqePantalla.getVistaMantoqe().getHistoricoBarreraReturn().getFecfinba());
		obtenerTipoOperacion();

		if (mantoqeGlobal.getTipBarP1() == null) {
			leerTramoPositoqe(historicoOperacion);
		} else {
			leerTramoPositoqeAgenda();
		}
	}

	// Métod Cargar Datos Pantalla
	public void cargarDatosPantalla(String origen, HistoricoOperacion historicoOperacion) {

		// Join Histderi con Histopci Unico Registro
		mantoqePantalla.getVistaMantoqe().setMantoqeReturn(
				mantoqeBarreraBo.obtenerDatosPantalla(historicoOperacion));
		// A152891, Se asigna la instancia de mantoqeGlobal para que aparezcan los datos en pantalla
		mantoqePantalla.getVistaMantoqe().setMantoqeGlobal(mantoqeGlobal);

		// Join Histderi con Histopci Unico Registro		
		MantoqeGlobal mantoq = mantoqeBarreraBo.obtenerDatosGlobales(historicoOperacion);
		
		if(!GenericUtils.isNullOrBlank(mantoq)){
			mantoqeGlobal.setBarreraIO(mantoq.getBarreraIO());
			mantoqeGlobal.setTipoPera(mantoq.getTipoPera());
			mantoqeGlobal.setTipoBarrera(mantoq.getTipoBarrera());
			mantoqeGlobal.setProducto(mantoq.getProducto());
			mantoqeGlobal.setEstiloop(mantoq.getEstiloop());
		}

		if (Constantes.ORIGEN_OPE.equalsIgnoreCase(origen)
				|| Constantes.ORIGEN_PRODCOM.equalsIgnoreCase(origen)) {
			cargarDatosBarreraPantalla(historicoOperacion);
		} else {
			mantoqeGlobal.setTipoOperacion(mantoqeGlobal.getTipoPera());
			mantoqeGlobal.setFechaInicioTramo(mantoqeGlobal.getFecinitr());
			mantoqeGlobal.setFechaFinTramo(mantoqeGlobal.getFecfintr());
			cargarDatosBarreraPantallaAgenda();
		}
		cargarDatosPantallaDos();

	}

	private void cargarDatosPantallaDos() {
		if (!GenericUtils.isNullOrBlank(mantoqeGlobal.getTipoBarreraP1())){
			mantoqeGlobal.setDescTipoBarrera(mantenimientoBarrerasBo.obtenerDescripcionTipoBarrera(mantoqeGlobal.getTipoBarreraP1()));
		}
		String tipoBarreraP1 = mantoqeGlobal.getTipoBarreraP1(); //RBS ¿¿No será tipBarP1?? tipobarrera no llega informado
		if (tipoBarreraP1 !=null && !Constantes.MANTOQE_O.equalsIgnoreCase(tipoBarreraP1.substring(1, 2))) {
			if (GenericUtils.isNullOrBlank(mantoqePantalla.getVistaMantoqe().getHistoricoBarreraReturn())) {
				mantoqePantalla.getVistaMantoqe().setHistoricoBarreraReturn(new HistoricoBarreraReturn());
			}
			mantoqePantalla.getVistaMantoqe().getHistoricoBarreraReturn().setPata(null);
			mantoqePantalla.getVistaMantoqe().getHistoricoBarreraReturn().setImprebat(null);
			mantoqePantalla.getVistaMantoqe().getHistoricoBarreraReturn().setDivireba(null);
			mantoqePantalla.getVistaMantoqe().getHistoricoBarreraReturn().setFechaRebat(null);
			mantoqePantalla.getVistaMantoqe().getHistoricoBarreraReturn().setDisabledImporteRebate("true");
		}
	}

	// public cargaInigical
	public void cargaInicial() {
		setPrimerAcceso(false);
/*		mantoqeGlobal.setBarreraIO(null);
		mantoqeGlobal.setTipoOperacion(null);
		mantoqeGlobal.setInditoqe(null);
		mantoqeGlobal.setTipoBarrera(null);
		mantoqeGlobal.setProducto(null);
		mantoqeGlobal.setErroresCanc(null);
		mantoqeGlobal.setTipoBarreraP1(null);
		mantoqeGlobal.setEstiloop(null);
		mantoqeGlobal.setFechatoque(null);
		mantoqeGlobal.setTipoPera(null);
		mantoqeGlobal.setTipoBarr(null);
		mantoqeGlobal.setFecinitr(null);
		mantoqeGlobal.setFecfintr(null);
		mantoqeGlobal.setTipBarP1(null); */
		mantoqeGlobal.setErroresCanc(Constantes.CONSTANTE_NO);
		mantoqeGlobal.setOrigen(origen);
		
		if ((codevent==null || codevent==  0) 
			&& (parametrosMantOper!=null && 
				"AGE".equalsIgnoreCase(parametrosMantOper.getModo()) 
				&& parametrosMantOper.getCodevent()!= null
				&& parametrosMantOper.getCodevent()!= 0L
			)  
			){
			mantoqeGlobal.setCodigoEvento(parametrosMantOper.getCodevent().intValue());
		}else{
			mantoqeGlobal.setCodigoEvento(codevent);
		}
		
		mantoqeGlobal.setFechamisARL(mantoqeBarreraBo.obtenerFechamis());

		if (Constantes.ORIGEN_OPE.equalsIgnoreCase(origen)
				|| Constantes.ORIGEN_PRODCOM.equalsIgnoreCase(origen)) {
			mantoqeGlobal.setFechatoque(mantoqeGlobal.getFechamisARL());
			mantoqeGlobal.setConcepto(null);
			mantoqeGlobal.setTipconce(null);
		}

		cargarDatosPantalla(origen, historicoOperacion);
		// a152891, se informa la descripcion del producto
		mantoqeGlobal.setProducto(historicoOperacion.getProductoCatalogo().getDescprod());

	}
	
	/**
	 * Funcion que desbloquea el HistoricoOperacion y retorna la pantalla que MANTOPER o PRODCOM
	 */
	public void retornar(){
		HistoricoOperacionId historicoOperacionId = historicoOperacion.getId();		
		dbLockService.desbloqueo(HistoricoOperacion.class, historicoOperacionId);
		Conversation conversacion=Conversation.instance();
		conversacion.end();
		conversacion.redirectToParent();
	}
	/**
	 * Desbloquea el HistoricoOperacion y retorna a la pantalla anterior
     */
	public void salir(){
		varModif = Constantes.CONSTANTE_NO;
		retornar();
	}
	
	public boolean fechatoqueEntreFechasBarrera(){
	if (mantoqePantalla.getVistaMantoqe().getHistoricoBarreraReturn().getFeciniba()==null || mantoqePantalla.getVistaMantoqe().getHistoricoBarreraReturn().getFecfinba()==null){
		return true;
	}
		return (mantoqePantalla.getVistaMantoqe().getFechatoque().compareTo(
					mantoqePantalla.getVistaMantoqe().getHistoricoBarreraReturn().getFeciniba()) > -1
				&& mantoqePantalla.getVistaMantoqe().getFechatoque().compareTo(
					mantoqePantalla.getVistaMantoqe().getHistoricoBarreraReturn().getFecfinba()) < 1);
	}
	
	public MantoqeBarreraBo getMantoqeBarreraBo() {
		return mantoqeBarreraBo;
	}

	public void setMantoqeBarreraBo(MantoqeBarreraBo mantoqeBarreraBo) {
		this.mantoqeBarreraBo = mantoqeBarreraBo;
	}

	public MantoqePantalla getMantoqePantalla() {
		return mantoqePantalla;
	}

	public void setMantoqePantalla(MantoqePantalla mantoqePantalla) {
		this.mantoqePantalla = mantoqePantalla;
	}

	public String getProduc() {

		return mantoqeBarreraBo.obtenerDescripcionProducto(0l);
	}

	public void setProduc(String produc) {
		this.produc = produc;
	}

	public boolean isMuestraPanel() {
		return muestraPanel;
	}

	public void setMuestraPanel(boolean muestraPanel) {
		this.muestraPanel = muestraPanel;
	}

	public boolean isMuestraPanel2() {
		return muestraPanel2;
	}

	public void setMuestraPanel2(boolean muestraPanel2) {
		this.muestraPanel2 = muestraPanel2;
	}

	public void cargarBarreraSeleccionada(HistoricoBarreraReturn hbr){
		if (hbr !=null) mantoqePantalla.getVistaMantoqe().setHistoricoBarreraReturn(hbr);
//		cargarDatosPantalla(origen, historicoOperacion);		


		HistoricoBarreraId hbId = new HistoricoBarreraId(historicoOperacion, hbr.getTipopera(),hbr.getTipBarP1());
		
		cargarDatosBarreraPantallaDos(historicoOperacion, mantenimientoBarrerasBo.cargarHistoricoBarrera(hbId));
		
		cargarDatosPantallaDos();
				
	}



}
