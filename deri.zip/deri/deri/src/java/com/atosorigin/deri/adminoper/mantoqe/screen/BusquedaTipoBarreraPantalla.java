package com.atosorigin.deri.adminoper.mantoqe.screen;

import java.util.List;

import org.jboss.seam.ScopeType;
import org.jboss.seam.annotations.Name;
import org.jboss.seam.annotations.Out;
import org.jboss.seam.annotations.Scope;
import org.jboss.seam.annotations.datamodel.DataModel;
import org.jboss.seam.annotations.datamodel.DataModelSelection;

import com.atosorigin.deri.model.gestionoperaciones.HistoricoBarreraReturn;

@Name("busquedaTipoBarreraPantalla")
@Scope(ScopeType.CONVERSATION)
public class BusquedaTipoBarreraPantalla {
	
	protected String descripcion;
	protected int numFilas;
	protected String tipoCliente;
	
	/** Lista de datos para el grid. */
	@DataModel(value ="listaBuscadorTipoBarrera")
	protected List<HistoricoBarreraReturn> listHistoricoBarreraReturn;
	
	/** Tipo de contrapartida seleccionado en el grid */
	@DataModelSelection(value ="listaBuscadorTipoBarrera")
    @Out(required=false)
    protected HistoricoBarreraReturn historicoBarreraReturn;

	public String getDescripcion() {
		return descripcion;
	}

	public void setDescripcion(String descripcion) {
		this.descripcion = descripcion;
	}

	public int getNumFilas() {
		return numFilas;
	}

	public void setNumFilas(int numFilas) {
		this.numFilas = numFilas;
	}

	public String getTipoCliente() {
		return tipoCliente;
	}

	public void setTipoCliente(String tipoCliente) {
		this.tipoCliente = tipoCliente;
	}

	public List<HistoricoBarreraReturn> getListHistoricoBarreraReturn() {
		return listHistoricoBarreraReturn;
	}

	public void setListHistoricoBarreraReturn(
			List<HistoricoBarreraReturn> listHistoricoBarreraReturn) {
		this.listHistoricoBarreraReturn = listHistoricoBarreraReturn;
	}

	public HistoricoBarreraReturn getHistoricoBarreraReturn() {
		return historicoBarreraReturn;
	}

	public void setHistoricoBarreraReturn(
			HistoricoBarreraReturn historicoBarreraReturn) {
		this.historicoBarreraReturn = historicoBarreraReturn;
	}
}
