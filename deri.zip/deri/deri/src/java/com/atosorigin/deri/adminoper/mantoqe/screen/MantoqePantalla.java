package com.atosorigin.deri.adminoper.mantoqe.screen;

import org.jboss.seam.ScopeType;
import org.jboss.seam.annotations.Name;
import org.jboss.seam.annotations.Scope;

import com.atosorigin.deri.model.gestionoperaciones.VistaMantoqe;


@Name("mantoqePantalla")
@Scope(ScopeType.CONVERSATION)
public class MantoqePantalla {
	
	VistaMantoqe vistaMantoqe = new VistaMantoqe();

	public VistaMantoqe getVistaMantoqe() {
		return vistaMantoqe;
	}

	public void setVistaMantoqe(VistaMantoqe vistaMantoqe) {
		this.vistaMantoqe = vistaMantoqe;
	}

}
