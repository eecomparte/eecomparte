package com.atosorigin.deri.adminoper.manttiposmercado.action;

import java.util.List;

import org.jboss.seam.ScopeType;
import org.jboss.seam.annotations.In;
import org.jboss.seam.annotations.Name;
import org.jboss.seam.annotations.Scope;

import com.atosorigin.common.action.PaginatedListAction;
import com.atosorigin.deri.adminoper.manttiposmercado.business.TiposPorIndiceBo;
import com.atosorigin.deri.adminoper.manttiposmercado.screen.ConsultaOperAsociadasPantalla;
import com.atosorigin.deri.model.mercado.TiposPorIndice;
import com.atosorigin.deri.model.mercado.Tramos;

/**
 * Clase action listener para el caso de uso de consulta operaciones asociadas en datos de mercado.
 */
@Name("consultaOperAsociadasAction")
@Scope(ScopeType.CONVERSATION)
public class ConsultaOperAsociadasAction extends PaginatedListAction {

	/**
	 * Inyección del bean de Spring "TiposPorIndiceBo"
	 */
	@In("#{tiposPorIndiceBo}")
	protected TiposPorIndiceBo TiposPorIndiceBo;

	/**
	 * Inyección del screen bean que contiene los datos de pantalla del caso de
	 * uso datos de mercado
	 */
	@In(create = true)
	protected ConsultaOperAsociadasPantalla consultaOperAsociadasPantalla;
	
	/** Tipo por índice seleccionado en la pantalla de mantenimiento de datos de mercado */
	@In(required=false)
    protected TiposPorIndice tipoIndiceSelec;
	
	/**
	 * Carga el grid de operaciones asociadas
	 */
	public void preCargarPantalla(TiposPorIndice tipoSeleccionado){
		(this.consultaOperAsociadasPantalla.getTiposPorIndiceBusq()).setId(tipoSeleccionado.getId());
		this.paginationData.reset(); /** Limpiamos la información de paginación */
		setPrimerAcceso(false);
		refrescarLista();
	}
	
	@Override
	public List<?> getDataTableList() {
		return this.consultaOperAsociadasPantalla.getTramosList();
	}

	@Override
	protected void refreshListInternal() {
		this.setExportExcel(false);
		List<Tramos> listaTramos = (List<Tramos>)TiposPorIndiceBo.buscarOperacionesAsociadas(this.consultaOperAsociadasPantalla.getTiposPorIndiceBusq(), this.paginationData);
		consultaOperAsociadasPantalla.setTramosList(listaTramos);
	}

	@Override
	public void refrescarListaExcel() {
		this.setExportExcel(true);
		List<Tramos> listaTramos = (List<Tramos>)TiposPorIndiceBo.buscarOperacionesAsociadas(this.consultaOperAsociadasPantalla.getTiposPorIndiceBusq(), this.paginationData.getPaginationDataForExcel());
		consultaOperAsociadasPantalla.setTramosList(listaTramos);
	}

	@SuppressWarnings("unchecked")
	@Override
	public void setDataTableList(List<?> dataTableList) {
		this.consultaOperAsociadasPantalla.setTramosList((List<Tramos>)dataTableList);
	}

}
