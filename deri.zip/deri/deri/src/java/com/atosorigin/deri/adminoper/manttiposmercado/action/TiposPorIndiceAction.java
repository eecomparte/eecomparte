package com.atosorigin.deri.adminoper.manttiposmercado.action;

import java.io.Serializable;
import java.math.BigDecimal;
import java.text.SimpleDateFormat;
import java.util.Collections;
import java.util.Date;
import java.util.HashSet;
import java.util.List;

import org.jboss.seam.ScopeType;
import org.jboss.seam.annotations.In;
import org.jboss.seam.annotations.Name;
import org.jboss.seam.annotations.Out;
import org.jboss.seam.annotations.Scope;
import org.jboss.seam.annotations.datamodel.DataModel;
import org.jboss.seam.annotations.datamodel.DataModelSelection;
import org.jboss.seam.core.Conversation;
import org.jboss.seam.core.ResourceBundle;
import org.jboss.seam.international.StatusMessage.Severity;

import com.atosorigin.common.action.ModoPantalla;
import com.atosorigin.common.action.PaginatedListAction;
import com.atosorigin.common.constantes.Constantes;
import com.atosorigin.common.formvalidator.FormValidator;
import com.atosorigin.common.utils.GenericUtils;
import com.atosorigin.deri.adminoper.manttiposmercado.business.TiposPorIndiceBo;
import com.atosorigin.deri.adminoper.manttiposmercado.screen.TiposPorIndicePantalla;
import com.atosorigin.deri.common.parametrosPantalla.ParametrosOutAgenda;
import com.atosorigin.deri.model.catalogo.Producto;
import com.atosorigin.deri.model.mercado.TiposPorIndice;
import com.atosorigin.deri.model.mercado.TiposPorIndiceId;
import com.atosorigin.deri.model.murex.ModeloProducto;
import com.atosorigin.deri.util.MessageBoxAction;
import com.atosorigin.deri.util.MsgBoxAction;

/**
 * Clase action listener para el caso de uso de datos de mercado.
 */
@Name("tiposPorIndiceAction")
@Scope(ScopeType.CONVERSATION)
@FormValidator
public class TiposPorIndiceAction extends PaginatedListAction implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = -3865627281961569977L;

	/**
	 * Inyección del bean de Spring "TiposPorIndiceBo" que contiene los métodos de
	 * negocio para el caso de uso datos de mercado.
	 */
	@In("#{tiposPorIndiceBo}")
	protected TiposPorIndiceBo tiposPorIndiceBo;
	 
	/**
	 * Inyección del screen bean que contiene los datos de pantalla del caso de
	 * uso datos de mercado
	 */
	@In(create = true)
	protected TiposPorIndicePantalla tiposPorIndicePantalla;
	
	/** Variable necesaria para la validación de variación máxima */
	protected boolean variacionInvalida;	
	
	/**
	 * Inyección datos provenientes de Agenda
	 */
	@In(required = false, value="parametrosOutAgenda")
	private ParametrosOutAgenda parametrosOutAgenda;
	
	/** Lista de datos para el grid. */
	@DataModel(value = "listaDtTiposIndice")
	protected List<TiposPorIndice> tiposIndiceList = null;

	/** Tipos por Indice seleccionado en el grid */
	@DataModelSelection(value = "listaDtTiposIndice")
	protected TiposPorIndice tipoIndiceDM;

	@Out(value = "tipoIndiceSelec", required = false)
	protected TiposPorIndice tipoIndiceSelec;
	
	@In(create = true)
	private MsgBoxAction msgBoxAction;	
	
	private MessageBoxAction messageBoxAction = new MessageBoxAction();

	
	/**
	 * Selección checkbox Liquidaciones
	 */
//	protected Map<LiquidacionId, Boolean> selectedLiquiIds = new HashMap<LiquidacionId, Boolean>();
	protected HashSet<TiposPorIndice> selectedTipoDataList = new HashSet<TiposPorIndice>();
	protected boolean selecTodos;

	
	public HashSet<TiposPorIndice> getSelectedTipoDataList() {
		return selectedTipoDataList;
	}

	public boolean getSelecTodos() {
		return selecTodos;
	}

	public void setSelectedTipoDataList(
			HashSet<TiposPorIndice> selectedTipoDataList) {
		this.selectedTipoDataList = selectedTipoDataList;
	}

	public void setSelecTodos(boolean selecTodos) {
		this.selecTodos = selecTodos;
	}

	/** Actualiza la lista del grid de datos de mercado */
	public void buscar() {
		paginationData.reset();
		this.tiposPorIndicePantalla.setVieneAgenda(false);
		/** Limpiamos la información de paginación */
		selectedTipoDataList.clear();
		refrescarLista();
		setPrimerAcceso(false);
	}
	
	/**
	 * Se ejecuta cuando se carga la pantalla desde Agenda
	 */
	public void initListaResultados(){
		setExportExcel(false);
		
		//Precargar la lista con los Parametros si es la primera vez q entra
		//Si parametrosOutAgenda es nulo es que entramos desde el menú
		if (isPrimerAcceso()){
			if (!GenericUtils.isNullOrBlank(parametrosOutAgenda) &&
					!GenericUtils.isNullOrBlank(parametrosOutAgenda.getModo())
					&& Constantes.MODO_AGE.equals(parametrosOutAgenda.getModo())){
				this.tiposPorIndicePantalla.setVieneAgenda(true);
				refrescarListaAgenda(parametrosOutAgenda.getCodevent(), parametrosOutAgenda.getModeloPr(), parametrosOutAgenda.getProducto(), 
						parametrosOutAgenda.getNcorrelaIni(),parametrosOutAgenda.getNcorrelaFin(), parametrosOutAgenda.getFechatraIni(), parametrosOutAgenda.getFechatraFin(),
						parametrosOutAgenda.getEstadoEv(), parametrosOutAgenda.getEstindic());
				
			}
		}
	
	}
	
	@Override
	protected void refreshListInternal() {
		Long codSubyacente = null;
		if(this.tiposPorIndicePantalla.isVieneAgenda()){
			// Habría que crear un objeto agenda en la pantalla para guardar los valores de los filtros
			refrescarListaAgenda(parametrosOutAgenda.getCodevent(), parametrosOutAgenda.getModeloPr(), parametrosOutAgenda.getProducto(), 
					parametrosOutAgenda.getNcorrelaIni(),parametrosOutAgenda.getNcorrelaFin(), parametrosOutAgenda.getFechatraIni(), parametrosOutAgenda.getFechatraFin(),
					parametrosOutAgenda.getEstadoEv(), parametrosOutAgenda.getEstindic());			
		} else {
			this.setExportExcel(false);
			String noInformado = Constantes.CONSTANTE_NO;
			String pendienteValidar = Constantes.CONSTANTE_NO;

			if (!GenericUtils.isNullOrBlank(tiposPorIndicePantalla.getSubyacenteBusq()))
				codSubyacente = tiposPorIndicePantalla.getSubyacenteBusq().getCodigo();
			
			if (!GenericUtils.isNullOrBlank(this.tiposPorIndicePantalla.getNoInformado()) 
					&& this.tiposPorIndicePantalla.getNoInformado() ) {
				noInformado = Constantes.CONSTANTE_SI;
			}

			if (!GenericUtils.isNullOrBlank(this.tiposPorIndicePantalla.getPdteValidar()) 
					&& this.tiposPorIndicePantalla.getPdteValidar()) {
				pendienteValidar = Constantes.CONSTANTE_SI;
			}
			
			List<TiposPorIndice> listaTiposIndice = (List<TiposPorIndice>) tiposPorIndiceBo.buscarTiposPorIndice(tiposPorIndicePantalla.getFechaValorDesde(), tiposPorIndicePantalla.getFechaValorHasta(), codSubyacente , pendienteValidar, noInformado, paginationData);
			
			if (!GenericUtils.isNullOrBlank(this.tiposIndiceList) && this.tiposIndiceList !=  Collections.EMPTY_LIST ){
				this.tiposIndiceList.clear();
				if(!GenericUtils.isNullOrBlank(listaTiposIndice) && listaTiposIndice.size() > 0){
					this.tiposIndiceList.addAll(listaTiposIndice);
				}else{
					this.tiposIndiceList = null;
				}
				
			} else {
				this.setTiposIndiceList(listaTiposIndice);
			}
		}
	}

	@Override
	public void refrescarListaExcel() {

		this.setExportExcel(true);
		if(this.tiposPorIndicePantalla.isVieneAgenda()){
			
			refrescarListaAgendaExcel(parametrosOutAgenda.getCodevent(), parametrosOutAgenda.getModeloPr(), parametrosOutAgenda.getProducto(), 
					parametrosOutAgenda.getNcorrelaIni(),parametrosOutAgenda.getNcorrelaFin(), parametrosOutAgenda.getFechatraIni(), parametrosOutAgenda.getFechatraFin(),
					parametrosOutAgenda.getEstadoEv(), parametrosOutAgenda.getEstindic());
		} else {
			
			String noInformado = Constantes.CONSTANTE_NO;
			String pendienteValidar = Constantes.CONSTANTE_NO;
			Long codSubyacente = null;
			if (!GenericUtils.isNullOrBlank(tiposPorIndicePantalla.getSubyacenteBusq()))
				codSubyacente = tiposPorIndicePantalla.getSubyacenteBusq().getCodigo();

			if (!GenericUtils.isNullOrBlank(this.tiposPorIndicePantalla.getNoInformado()) 
					&& this.tiposPorIndicePantalla.getNoInformado() ) {
				noInformado = Constantes.CONSTANTE_SI;
			}

			if (!GenericUtils.isNullOrBlank(this.tiposPorIndicePantalla.getPdteValidar()) 
					&& this.tiposPorIndicePantalla.getPdteValidar()) {
				pendienteValidar = Constantes.CONSTANTE_SI;
			}
			
			List<TiposPorIndice> listaTiposIndice = (List<TiposPorIndice>) tiposPorIndiceBo.buscarTiposPorIndice(tiposPorIndicePantalla.getFechaValorDesde(), tiposPorIndicePantalla.getFechaValorHasta(),codSubyacente , pendienteValidar, noInformado, paginationData.getPaginationDataForExcel());
			
			if (!GenericUtils.isNullOrBlank(this.tiposIndiceList) && this.tiposIndiceList !=  Collections.EMPTY_LIST ){
				this.tiposIndiceList.clear();
				if(!GenericUtils.isNullOrBlank(listaTiposIndice) && listaTiposIndice.size() > 0){
					this.tiposIndiceList.addAll(listaTiposIndice);
				}else{
					this.tiposIndiceList = null;
				}
				
			} else {
				this.setTiposIndiceList(listaTiposIndice);
			}
		}
	}

	/**
	 * A partir del código de estado del tipo de indice retorna su descripción para mostrarla
	 * en el grid de búsqueda de tipos por índice, en la columna estado
	 * @param codEstado: código del estado
	 * @return descripción del estado
	 */
	public String getDescEstado(String codEstado){
		return tiposPorIndiceBo.obtenerDescripEstado(codEstado);
	}
	
	/** Prepara para entrar en el modo inspección de un tipo por indice. */
	public void ver() {
		this.tipoIndiceSelec = this.tipoIndiceDM;
		this.setModoPantalla(ModoPantalla.INSPECCION);
		beanToForm();
	}
	
	/** Valida un tipo de interés */
	public void validar(){
//		this.tipoIndiceSelec = this.tipoIndiceDM;
		(this.getTipoIndiceSelec()).setEstadoindice(Constantes.TIPOINDICE_ESTADO_VA.toUpperCase());
		tiposPorIndiceBo.modifica(this.tipoIndiceSelec,false);
		refrescarLista();
	}
	
	/** Prepara para entrar en el modo edición de un tipo por índice. */
	public void editar() {
		this.tipoIndiceSelec = this.tipoIndiceDM;
		setModoPantalla(ModoPantalla.EDICION);
		beanToForm();
	}
	
	/** Prepara para entrar en el modo creación de un tipo por índice */
	public void nuevo() {
		this.setTipoIndiceSelec(new TiposPorIndice(new TiposPorIndiceId()));
		this.setModoPantalla(ModoPantalla.CREACION);
		beanToForm();
	}

	private void refrescarListaAgenda(Long codevent, ModeloProducto modelo,	Producto producto, Long nCorrelaIni, Long nCorrelaFin,
			Date fechatraIni, Date fechatraFin, String estadoEvent, String estindic) {
		this.setExportExcel(false);
		List<TiposPorIndice> listaTiposIndice =
		(List<TiposPorIndice>)tiposPorIndiceBo.buscarTiposPorIndiceDesdeAgenda(codevent, modelo, producto,
				nCorrelaIni, nCorrelaFin, fechatraIni, fechatraFin, estadoEvent, estindic, paginationData);
		
		if (!GenericUtils.isNullOrBlank(this.tiposIndiceList)){
			tiposIndiceList.clear();
			tiposIndiceList.addAll(listaTiposIndice);
		} else {
			this.setTiposIndiceList(listaTiposIndice);
		}
	}
	
	private void refrescarListaAgendaExcel(Long codevent, ModeloProducto modelo, Producto producto, Long nCorrelaIni, Long nCorrelaFin,
			Date fechatraIni, Date fechatraFin, String estadoEvent, String estindic) {
		this.setExportExcel(true);
		List<TiposPorIndice> listaTiposIndice =
		(List<TiposPorIndice>)tiposPorIndiceBo.buscarTiposPorIndiceDesdeAgenda(codevent, modelo, producto,
				nCorrelaIni, nCorrelaFin, fechatraIni, fechatraFin, estadoEvent, estindic, paginationData.getPaginationDataForExcel());
		
		if (!GenericUtils.isNullOrBlank(this.tiposIndiceList)){
			tiposIndiceList.clear();
			tiposIndiceList.addAll(listaTiposIndice);
		} else {
			this.setTiposIndiceList(listaTiposIndice);
		}
	}
	
	/**
	 * Realiza las validaciones para el alta y la edición de tipos por índice
	 * @return true si las validaciones se superan, false en caso contrario
	 */
	public boolean guardarValidator(){
		
		boolean esCorrecto = true;
		TiposPorIndice tipoExistente = null;
		
		if(ModoPantalla.CREACION.equals(this.getModoPantalla())){
			
			TiposPorIndiceId idBusqueda = new TiposPorIndiceId(tiposPorIndicePantalla.getSubyacentePantalla(),
					tiposPorIndicePantalla.getFechaValorPantalla());
			
			//Comprobamos que no exista un registro en bbdd con la misma pk
			tipoExistente = tiposPorIndiceBo.cargar(idBusqueda);
			
			if (!GenericUtils.isNullOrBlank(tipoExistente)){
				statusMessages.add(Severity.ERROR, "#{messages['tiposporindice.error.yaexiste']}");
				esCorrecto = false;
			}
		
			//Comprobamos que la fecha de aplicación no sea superior a la del sistema
			Date fechaSistema = tiposPorIndiceBo.obtenerFechaProceso();
			long diffFechaAplPro = (this.tiposPorIndicePantalla.getFechaValorPantalla().getTime() - fechaSistema.getTime())/86400000L;
			
			if(diffFechaAplPro > 0l){
				
				SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
				statusMessages.addToControlFromResourceBundle("fechaValorTxt",Severity.ERROR, "tiposporindice.error.fechasuperior", sdf.format(fechaSistema));
				esCorrecto = false;
			}
		}
		
		//Comprobamos que el valor del subyacente no supere los valores máximo y mínimo
		if(!GenericUtils.isNullOrBlank(this.tiposPorIndicePantalla.getValorMaximoPantalla())){
			
			int difValMax = this.tiposPorIndicePantalla.getTipoValorIndicePantalla().compareTo(this.tiposPorIndicePantalla.getValorMaximoPantalla())	;
			
			if(difValMax > 0){
				statusMessages.addToControl("valorCierreTxt",Severity.ERROR, "#{messages['tiposporindice.error.valorsuperior']}");
				esCorrecto = false;
			}
		}
		
		if(!GenericUtils.isNullOrBlank(this.tiposPorIndicePantalla.getValorMinimoPantalla())){
			
			int difValMin = this.tiposPorIndicePantalla.getTipoValorIndicePantalla().compareTo(this.tiposPorIndicePantalla.getValorMinimoPantalla())	;
			
			if(difValMin < 0){
				statusMessages.addToControl("valorCierreTxt",Severity.ERROR, "#{messages['tiposporindice.error.valorinferior']}");
				esCorrecto = false;
			}
		}
		
		// Validamos en formato valor índice, valorMax y valorMin (17 cifras, 12 decimales)
		if(!GenericUtils.isNullOrBlank(this.tiposPorIndicePantalla.getValorMaximoPantalla())){
			if(!GenericUtils.validaFormatoDecimal(this.tiposPorIndicePantalla.getValorMaximoPantalla(), 5, 12)){
				statusMessages.addToControl("valorMaxTxt",Severity.ERROR, "#{messages['tiposporindice.error.valor']}");
				esCorrecto = false;
			}
		}
		
		if(!GenericUtils.isNullOrBlank(this.tiposPorIndicePantalla.getValorMinimoPantalla())){
			if(!GenericUtils.validaFormatoDecimal(this.tiposPorIndicePantalla.getValorMinimoPantalla(), 5, 12)){
				statusMessages.addToControl("valorMinTxt",Severity.ERROR, "#{messages['tiposporindice.error.valor']}");
				esCorrecto = false;
			}
		}
		
		if(!GenericUtils.validaFormatoDecimal(this.tiposPorIndicePantalla.getTipoValorIndicePantalla(), 5, 12)){
			statusMessages.addToControl("valorCierreTxt",Severity.ERROR, "#{messages['tiposporindice.error.valor']}");
			esCorrecto = false;
		}
		
		//Validamos variación máxima solo si se han pasado antes las demás validaciones
		if(esCorrecto){
			if(!variacionInvalida && !esCorrectoVariacionIndice()){
				setVariacionInvalida(true);
				esCorrecto = false;
			}
		}
		
		return esCorrecto;
	}
	
	/** Graba el tipo por índice */
	public String guardar() {
		formToBean();
		if(ModoPantalla.CREACION.equals(this.getModoPantalla())){
			tiposPorIndiceBo.alta(this.getTipoIndiceSelec(),this.tiposPorIndicePantalla.getCheckValorCero());
		} else if(ModoPantalla.EDICION.equals(this.getModoPantalla())){
			tiposPorIndiceBo.modifica(this.getTipoIndiceSelec(),this.tiposPorIndicePantalla.getCheckValorCero());
		}
		refrescarLista();
		this.setVariacionInvalida(false);
		return Constantes.CONSTANTE_SUCCESS;
	}
	
	/**
	 * Actualiza la lista del grid de datos de mercado y vuelve a la pantalla de búsqueda
	 */
	public void salirDetalle() {
		paginationData.reset();
		/** Limpiamos la información de paginación */
		if (this.modoPantalla.equals(ModoPantalla.EDICION)) {
			refrescarLista();
		}
	}
	
	/**
	 * Validación de indice de variación máxima
	 * @return true si es correcta, false en caso contrario
	 */
	private boolean esCorrectoVariacionIndice(){
		
		/* Validamos el % Variación máxima */
		boolean correcto;
		BigDecimal minimo = new BigDecimal(0);
		BigDecimal maximo = new BigDecimal(99999999);
		BigDecimal valor = this.tiposPorIndicePantalla.getTipoValorIndicePantalla();
		
		TiposPorIndice tipoBusqueda = new TiposPorIndice(new TiposPorIndiceId(tiposPorIndicePantalla.getSubyacentePantalla(), tiposPorIndicePantalla.getFechaValorPantalla()));
		BigDecimal tipoIndc = tiposPorIndiceBo.calcularVariacionIndice(tipoBusqueda);
		
		if(!GenericUtils.isNullOrBlank(tipoIndc)){
			
			BigDecimal vamaxPor = new BigDecimal(0);
			
			if(!GenericUtils.isNullOrBlank(this.tiposPorIndicePantalla.getSubyacentePantalla().getVariacionMaxima())){
				vamaxPor = this.tiposPorIndicePantalla.getSubyacentePantalla().getVariacionMaxima();//this.getTipoIndiceSelec().getValorMaximo();
			}
			
			if (tipoIndc != null){
				minimo = tipoIndc.subtract(tipoIndc.multiply(vamaxPor).divide(new BigDecimal(100)));
				maximo = tipoIndc.add(tipoIndc.multiply(vamaxPor).divide(new BigDecimal(100)));
			}
		}
		
		if(valor.compareTo(maximo) == 1 || valor.compareTo(minimo) == -1){
			correcto = false;
		} else {
			correcto = true;
		}

		return correcto;
	}
	
	public void onMessageBoxValidarOk(){
		prepareValidarDos();
	}
	
	public void prepareValidar(){
		msgBoxAction.mostrarMsg("#{tiposPorIndiceAction.onMessageBoxValidarOk()}", "#{tiposPorIndiceAction.voidFunction()}", null, null,
				"resultadosConsulta,confirmarPanel,messagesPanel,tablaResultados", "confirmarPanel", "Está seguro que desea validar los tipos seleccionados?");
//		msgBoxAction.init("mantOper.messages.validar.pregunta", "mantOperacionesAction.onMessageBoxValidarOk()",
//		"mantOperacionesAction.voidFunction()","helperPanel");
	}

	public void voidFunction(){
		msgBoxAction.voidFunction();
	}
	
	
	public void prepareValidarDos(){
		int operValidadas = 0;
		if(selectedTipoDataList.size() > 0){
				for (TiposPorIndice ti : selectedTipoDataList) {
					try{
						if (ti.getEstadoindice().equals("PV") || (ti.getEstadoindice().equals("PI") && ti.getId().getSubyacente().getCodigo()== 118))
						{
						ti.setEstadoindice(Constantes.TIPOINDICE_ESTADO_VA.toUpperCase());
						tiposPorIndiceBo.modifica(ti,false);
						operValidadas++;
						}						
					}catch (NullPointerException e) {
						e.printStackTrace();
						//addError(ti,ResourceBundle.instance().getString("mantOper.messages.generic.noInfo"));
					}catch (Exception e) {
						e.printStackTrace();
						//addError(ti,ResourceBundle.instance().getString("mantOper.messages.generic.noInfo"));
					}
				}
				selectedTipoDataList.clear();
				refrescarLista();	
				String msgValidadas = String.valueOf(operValidadas) + ResourceBundle.instance().getString("tiposporindice.messages.validadas");
				statusMessages.add(Severity.INFO,msgValidadas);
		}
	}


	
	/**
	 * Retorna el mensaje de confirmación cuando se supera el índice de variación máxima
	 */
	public String getMensajeConfirmacion(){
		StringBuilder stb = new StringBuilder();
		stb.append(ResourceBundle.instance().getString("tiposporindice.confirmacion1"));
		stb.append(" " + this.tiposPorIndicePantalla.getSubyacentePantalla().getVariacionMaxima() + " ");
		stb.append(ResourceBundle.instance().getString("tiposporindice.confirmacion2"));
		return stb.toString();
	}
	
	public void valorACero(){
		
		if (this.tiposPorIndicePantalla.getCheckValorCero()){
			this.tiposPorIndicePantalla.setTipoValorIndicePantalla(BigDecimal.ZERO);
			asignarMaximoYMinimo();
		}

	}
	
	public void asignarMaximoYMinimo(){
		this.tiposPorIndicePantalla.setValorMaximoPantalla(this.tiposPorIndicePantalla.getTipoValorIndicePantalla());
		this.tiposPorIndicePantalla.setValorMinimoPantalla(this.tiposPorIndicePantalla.getTipoValorIndicePantalla());
	}
	
	private void beanToForm(){
		this.tiposPorIndicePantalla.setSubyacentePantalla(this.tipoIndiceSelec.getId().getSubyacente());
		this.tiposPorIndicePantalla.setFechaValorPantalla(this.tipoIndiceSelec.getId().getFaplicacion());
		this.tiposPorIndicePantalla.setTipoValorIndicePantalla(this.tipoIndiceSelec.getTipoValorIndice());
		this.tiposPorIndicePantalla.setValorMaximoPantalla(this.tipoIndiceSelec.getValorMaximo());
		this.tiposPorIndicePantalla.setValorMinimoPantalla(this.tipoIndiceSelec.getValorMinimo());
	}
	
	private void formToBean(){
		this.tipoIndiceSelec.getId().setSubyacente(this.tiposPorIndicePantalla.getSubyacentePantalla());
		this.tipoIndiceSelec.getId().setFaplicacion(this.tiposPorIndicePantalla.getFechaValorPantalla());
		this.tipoIndiceSelec.setTipoValorIndice(this.tiposPorIndicePantalla.getTipoValorIndicePantalla());
		
		//Modificación incidencia 1230: si el tipo valor ha sido informado (<> 0) y no se han informado 
		//el valor máximo o el mínimo, se graban en base de datos con el mismo valor que el tipo valor.
		if(GenericUtils.isNullOrBlank(this.tiposPorIndicePantalla.getValorMaximoPantalla()) 
				&& this.tiposPorIndicePantalla.getTipoValorIndicePantalla().compareTo(BigDecimal.ZERO) != 0){
			this.tipoIndiceSelec.setValorMaximo(this.tiposPorIndicePantalla.getTipoValorIndicePantalla());
		} else {
			this.tipoIndiceSelec.setValorMaximo(this.tiposPorIndicePantalla.getValorMaximoPantalla());
		}
		
		if(GenericUtils.isNullOrBlank(this.tiposPorIndicePantalla.getValorMinimoPantalla()) && 
				this.tiposPorIndicePantalla.getTipoValorIndicePantalla().compareTo(BigDecimal.ZERO) != 0){
			this.tipoIndiceSelec.setValorMinimo(this.tiposPorIndicePantalla.getTipoValorIndicePantalla());
		} else {
			this.tipoIndiceSelec.setValorMinimo(this.tiposPorIndicePantalla.getValorMinimoPantalla());
		}
	}
	
	public void salir(){
		Conversation conversacion = Conversation.instance();
		//Volvemos a la anterior conversación
		if(conversacion.isNested()){
			conversacion.redirectToParent();
		} else {
			redirectToURL("/home.seam");
			conversacion.endAndRedirect();
		}
	}
	
	@Override
	public List<?> getDataTableList() {
		return this.tiposIndiceList;
	}
	
	@SuppressWarnings("unchecked")
	@Override
	public void setDataTableList(List<?> dataTableList) {
		this.tiposIndiceList = (List<TiposPorIndice>)dataTableList;
	}

	public boolean isVariacionInvalida() {
		return variacionInvalida;
	}

	public void setVariacionInvalida(boolean variacionInvalida) {
		this.variacionInvalida = variacionInvalida;
	}
	
	public List<TiposPorIndice> getTiposIndiceList() {
		return tiposIndiceList;
	}

	public void setTiposIndiceList(List<TiposPorIndice> tiposIndiceList) {
		this.tiposIndiceList = tiposIndiceList;
	}

	public TiposPorIndice getTipoIndiceDM() {
		return tipoIndiceDM;
	}

	public void setTipoIndiceDM(TiposPorIndice tipoIndiceDM) {
		this.tipoIndiceDM = tipoIndiceDM;
	}

	public TiposPorIndice getTipoIndiceSelec() {
		return tipoIndiceSelec;
	}

	public void setTipoIndiceSelec(TiposPorIndice tipoIndiceSelec) {
		this.tipoIndiceSelec = tipoIndiceSelec;
	}

	public Boolean getSelectedRow(){
		return getSelectedTipoDataList().contains(this.getTipoIndiceDM());
	}

	public void setSelectedRow(Boolean selected){
		if(selected){
			getSelectedTipoDataList().add(this.getTipoIndiceDM());
		}
		else{
			getSelectedTipoDataList().remove(this.getTipoIndiceDM());
			setSelecTodos(false);
		}
	}
	public void seleccionarTodos(){
		
		if(getSelecTodos()){

			if(!GenericUtils.isNullOrBlank(getSelectedTipoDataList())){
				getSelectedTipoDataList().clear();
			}
			
			
			setSelecTodos(false);
						
		} else { //Caso seleccionar
			
			Integer minResul = paginationData.getFirstResult();
			Integer maxResul = paginationData.getMaxResults(); 
			
			paginationData.setFirstResult(0);
			paginationData.setMaxResults(Constantes.MAX_RESULTS_SELECCION_TOTAL);

			refreshListInternal();
			List<TiposPorIndice> listaTemp = getTiposIndiceList();

			paginationData.setMaxResults(maxResul);
			paginationData.setFirstResult(minResul);
			
			if(!GenericUtils.isNullOrBlank(listaTemp)){
				getSelectedTipoDataList().addAll(listaTemp);
			}
			setSelecTodos(true);
		}
		
	}	
	
	
}
