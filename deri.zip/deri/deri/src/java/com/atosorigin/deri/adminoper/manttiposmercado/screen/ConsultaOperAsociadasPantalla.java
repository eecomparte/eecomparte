package com.atosorigin.deri.adminoper.manttiposmercado.screen;

import java.util.List;

import org.jboss.seam.ScopeType;
import org.jboss.seam.annotations.Name;
import org.jboss.seam.annotations.Scope;
import org.jboss.seam.annotations.datamodel.DataModel;

import com.atosorigin.deri.model.mercado.TiposPorIndice;
import com.atosorigin.deri.model.mercado.Tramos;

/**
 * Contiene los datos de pantalla necesarios para el caso de uso "consulta operaciones asociadas" 
 * del mantenimiento de datos de mercado.
 */
@Name("consultaOperAsociadasPantalla")
@Scope(ScopeType.CONVERSATION)
public class ConsultaOperAsociadasPantalla {

	/** Lista de datos para el grid. */
	@DataModel(value = "listaDtOperAsociadas")
	protected List<Tramos> tramosList;

	protected TiposPorIndice tiposPorIndiceBusq;
	
	public ConsultaOperAsociadasPantalla(){
		this.tiposPorIndiceBusq = new TiposPorIndice();
	}
	
	public List<Tramos> getTramosList() {
		return tramosList;
	}

	public void setTramosList(List<Tramos> tramosList) {
		this.tramosList = tramosList;
	}

	public TiposPorIndice getTiposPorIndiceBusq() {
		return tiposPorIndiceBusq;
	}

	public void setTiposPorIndiceBusq(TiposPorIndice tiposPorIndiceBusq) {
		this.tiposPorIndiceBusq = tiposPorIndiceBusq;
	}
}
