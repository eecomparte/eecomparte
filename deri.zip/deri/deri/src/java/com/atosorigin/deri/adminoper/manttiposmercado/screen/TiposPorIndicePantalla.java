package com.atosorigin.deri.adminoper.manttiposmercado.screen;

import java.math.BigDecimal;
import java.util.Date;

import org.jboss.seam.ScopeType;
import org.jboss.seam.annotations.Name;
import org.jboss.seam.annotations.Scope;

import com.atosorigin.deri.model.mercado.Subyacente;

/**
 * Contiene los datos de pantalla necesarios para el caso de uso datos de mercado.
 */
@Name("tiposPorIndicePantalla")
@Scope(ScopeType.CONVERSATION)
public class TiposPorIndicePantalla {

	/** Criterios de búsqueda */
	protected Date fechaValorDesde;
	protected Date fechaValorHasta;
	protected Subyacente subyacenteBusq;
	protected Boolean pdteValidar;
	protected Boolean noInformado;
	
	/** Variable boolean para saber si venimos de la Agenda */
	protected boolean vieneAgenda;
	
	/** Campos de la pantalla de detalle **/
	protected BigDecimal valorMaximoPantalla;
	protected BigDecimal valorMinimoPantalla;
	protected BigDecimal tipoValorIndicePantalla;
	protected Subyacente subyacentePantalla;
	protected Date fechaValorPantalla;
	
	
	protected Boolean checkValorCero;
	
	public Subyacente getSubyacenteBusq() {
		return subyacenteBusq;
	}
	public Boolean getPdteValidar() {
		return pdteValidar;
	}
	public Boolean getNoInformado() {
		return noInformado;
	}

	public void setSubyacenteBusq(Subyacente subyacenteBusq) {
		this.subyacenteBusq = subyacenteBusq;
	}
	public void setPdteValidar(Boolean pdteValidar) {
		this.pdteValidar = pdteValidar;
	}
	public void setNoInformado(Boolean noInformado) {
		this.noInformado = noInformado;
	}
	public boolean isVieneAgenda() {
		return vieneAgenda;
	}
	public void setVieneAgenda(boolean vieneAgenda) {
		this.vieneAgenda = vieneAgenda;
	}
	public BigDecimal getValorMaximoPantalla() {
		return valorMaximoPantalla;
	}
	public void setValorMaximoPantalla(BigDecimal valorMaximoPantalla) {
		this.valorMaximoPantalla = valorMaximoPantalla;
	}
	public BigDecimal getValorMinimoPantalla() {
		return valorMinimoPantalla;
	}
	public void setValorMinimoPantalla(BigDecimal valorMinimoPantalla) {
		this.valorMinimoPantalla = valorMinimoPantalla;
	}
	public BigDecimal getTipoValorIndicePantalla() {
		return tipoValorIndicePantalla;
	}
	public void setTipoValorIndicePantalla(BigDecimal tipoValorIndicePantalla) {
		this.tipoValorIndicePantalla = tipoValorIndicePantalla;
	}
	public Subyacente getSubyacentePantalla() {
		return subyacentePantalla;
	}
	public void setSubyacentePantalla(Subyacente subyacentePantalla) {
		this.subyacentePantalla = subyacentePantalla;
	}
	public Date getFechaValorPantalla() {
		return fechaValorPantalla;
	}
	public void setFechaValorPantalla(Date fechaValorPantalla) {
		this.fechaValorPantalla = fechaValorPantalla;
	}

	public Date getFechaValorDesde() {
		return fechaValorDesde;
	}
	public void setFechaValorDesde(Date fechaValorDesde) {
		this.fechaValorDesde = fechaValorDesde;
	}
	public Date getFechaValorHasta() {
		return fechaValorHasta;
	}
	public void setFechaValorHasta(Date fechaValorHasta) {
		this.fechaValorHasta = fechaValorHasta;
	}
	public Boolean getCheckValorCero() {
		return checkValorCero;
	}
	public void setCheckValorCero(Boolean checkValorCero) {
		this.checkValorCero = checkValorCero;
	}

}
