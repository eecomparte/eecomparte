package com.atosorigin.deri.adminoper.migracion.action;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;

import javax.persistence.EntityManager;

import org.hibernate.SQLQuery;
import org.hibernate.annotations.Type;
import org.jboss.seam.ScopeType;
import org.jboss.seam.annotations.Factory;
import org.jboss.seam.annotations.In;
import org.jboss.seam.annotations.Name;
import org.jboss.seam.annotations.Out;
import org.jboss.seam.annotations.Scope;
import org.jboss.seam.annotations.datamodel.DataModel;
import org.jboss.seam.core.Conversation;
import org.jboss.seam.core.ResourceBundle;
import org.jboss.seam.international.StatusMessage.Severity;

import com.atosorigin.common.action.PaginatedListAction;
import com.atosorigin.common.constantes.Constantes;
import com.atosorigin.common.formvalidator.FormValidator;
import com.atosorigin.common.utils.GenericUtils;
import com.atosorigin.deri.adminoper.boletas.action.BoletasAction.BoletasStates;
import com.atosorigin.deri.adminoper.boletas.business.BoletasBo;
import com.atosorigin.deri.adminoper.mantoper.business.MantOperBo;
import com.atosorigin.deri.adminoper.migracion.business.MigracionBMNBo;
import com.atosorigin.deri.adminoper.migracion.screen.MigracionBMNPantalla;
import com.atosorigin.deri.common.dbLock.DbLockService;
import com.atosorigin.deri.dao.adminoper.boletas.AltaCorrelaResult;
import com.atosorigin.deri.dao.mercado.DescripcionFormula;
import com.atosorigin.deri.model.adminoper.BusquedaOperacion;
import com.atosorigin.deri.model.adminoper.GenericRange;
import com.atosorigin.deri.model.adminoper.NivelOperacion;
import com.atosorigin.deri.model.catalogo.Producto;
import com.atosorigin.deri.model.contrapartida.TipoContrapartida;
import com.atosorigin.deri.model.gestionoperaciones.DescripcionTransaccionOperacion;
import com.atosorigin.deri.model.gestionoperaciones.HistoricoOperacion;
import com.atosorigin.deri.model.gestionoperaciones.HistoricoOperacionId;
import com.atosorigin.deri.model.gestionoperaciones.MigracionBMN;
import com.atosorigin.deri.model.gestionoperaciones.VistaMigracionBMN;
import com.atosorigin.deri.model.gestionoperaciones.VistaOperacion;
import com.atosorigin.deri.model.murex.ModeloProducto;
import com.atosorigin.deri.model.murex.ProcedenciaProducto;
import com.atosorigin.deri.model.murex.ProductoCatalogo;
import com.atosorigin.deri.model.parametrizacion.Divisa;
import com.atosorigin.deri.util.ErrorMessage;
import com.atosorigin.deri.util.InterceptExceptions;
import com.atosorigin.deri.util.ErrorMessage.TypeError;

@Name("migracionBMNAction")
@Scope(ScopeType.CONVERSATION)
@InterceptExceptions
@FormValidator
public class MigracionBMNAction extends PaginatedListAction implements java.io.Serializable {

	private static final long serialVersionUID = 4371127399433844329L;
	
	/* IN's y OUT's */
	
	@In
	private EntityManager entityManager;
	
	@In("#{mantOperBo}")
	private MantOperBo mantOperBo;
	
	@In("#{migracionBMNBo}")
	private MigracionBMNBo migracionBMNBo; 
	
	/**
	 * Inyección del screen bean que contiene los datos de pantalla del caso de uso
	 * Lista de Suscripciones.
	 */
	@In(create=true)
	protected MigracionBMNPantalla migracionBMNPantalla ;
	
	
	@In("#{boletasBo}")
	private BoletasBo boletasBo;
	
	
	
	@In(create = true) /* Inyección del servicio que gestiona los bloqueos de registros en base de datos */
	private DbLockService dbLockService;
	@In(required=false)/* Para la union con producto compuestos */
	protected VistaOperacion vistaOperacionProdComp;
	@Out(required = false)
	private HistoricoOperacion historicoOperacion;
	@Out(required = false)
	private HistoricoOperacionId historicoOperacionBloqueadoId;
	@Out(required = false)
	@In(required = false )//Se pasa el valor desde productos compuestos
	private BoletasStates boletaState;

	@Out(required = false, value = "modo")
	private String modoConfirmacion;
	
	@Out
	private String modifCanc = "N";
	

	@In("org.jboss.seam.core.locale")	
	private Locale locale;
	
	@Out(required = false, value = "dealtypes")
	List<String> dealTypeList = null;
	
	/*
    * variables de contexto Integra con MANTANEX
    */
	@Out(required=false)
	private String modoTratamiento;
	
	@Out(required=false)
	private String tipoAnexo;	
	
	@Out(value = "origenPantalla")
	private String origenPantalla = "MO";

	/* CAMPOS DE PRESENTACION */
	private ProcedenciaProducto procedencia;
	private ModeloProducto modelo;
	private ProductoCatalogo productoCatalogo;
	private Producto productoOperacion;
	private DescripcionTransaccionOperacion transaccionOperacion;
	private NivelOperacion nivelOperacion;
	private String contrapartida;
	private TipoContrapartida tipoContrapa;
	private Divisa divisaPago;
	private Divisa divisaCobro;
	private BusquedaOperacion situacion;
	private DescripcionFormula formula;
	private String suReferencia;

	private Boolean cobertura =false;
	private Boolean pendienteConf = false;
	private Boolean estructura =false;
	private Boolean campana =false;

	private int maxSelected;

	private Integer ultimRegistre;
	
	private GenericRange<Long> numOper = new GenericRange<Long>("numoper", Long.class);
	private GenericRange<Date> fechaVal = new GenericRange<Date>("fechaval", Date.class);
	private GenericRange<Date> fechaVen = new GenericRange<Date>("fechaven", Date.class);
	private GenericRange<Date> fechaOpe = new GenericRange<Date>("fechaope", Date.class);
	private GenericRange<Long> numEstructu = new GenericRange<Long>("estructu", Long.class);
	private GenericRange<Long> clExterna = new GenericRange<Long>("clexterna", Long.class);
	private GenericRange<String> clBduGid = new GenericRange<String>("clbdugid", String.class);

	@DataModel(value = "mantOperaciones.listaErrores")
	private List<ErrorMessage> listaErrores = new ArrayList<ErrorMessage>();


	public String consultar() {
		 
		VistaMigracionBMN escogido = migracionBMNPantalla.getMigracionSelected();
		historicoOperacion = migracionBMNBo.recuperarHistoricoOperacion(escogido.getMigracion());
		escogido.setHistderi(historicoOperacion);
		
		if ( historicoOperacion==null){
			statusMessages.add(Severity.ERROR , "#{messages['migracionBMN.messages.error.oper']}");
			return Constantes.FAIL;
		}
		//boletasBo.prepareConsultaCorrela(historicoOperacion);
		boletaState = BoletasStates.CONSULTA_BOLETA;
		return Constantes.SUCCESS;
	}

	


	public void buscar() {
		if (migracionBMNPantalla.getMigracionList()!=null){
			migracionBMNPantalla.getMigracionList().clear();	
		}else{
			migracionBMNPantalla.setMigracionList(new ArrayList<VistaMigracionBMN>());
		}
		
		paginationData.reset(); // Como regeneramos la lista, tambien reiniciamos el paginationData
		setPrimerAcceso(false);
		refrescarLista();
	}
	
	public boolean buscarValidator() {
		boolean ret = true;
		
		if(numOper != null && numOper.getLow() != null && numOper.getHigh() != null) {
			if(numOper.getLow() > numOper.getHigh()) {
				statusMessages.add(Severity.ERROR, "#{messages['mantOper.messages.error.numOper']}");
				ret = false;
			}
		}
		if(clExterna != null && clExterna.getLow() != null && clExterna.getHigh() != null) {
			if(clExterna.getLow() > clExterna.getHigh()) {
				statusMessages.add(Severity.ERROR, "#{messages['mantOper.messages.error.clExterna']}");
				ret = false;
			}
		}
		
		return ret;
	}
	
	public void salir(){
		Conversation conversacion = Conversation.instance();
		//Volvemos a la anterior conversación
		if(conversacion.isNested()){
			conversacion.redirectToParent();
		} else {
			redirectToURL("/home.seam");
			conversacion.endAndRedirect();
		}
	}

	
	
	public String prepareModificar(){
		String ret = Constantes.FAIL;
		VistaMigracionBMN escogido = migracionBMNPantalla.getMigracionSelected();
		historicoOperacion = migracionBMNBo.recuperarHistoricoOperacion(escogido.getMigracion());
		
		
		if ( historicoOperacion==null){
			statusMessages.add(Severity.ERROR , "#{messages['migracionBMN.messages.error.oper']}");
			return ret;
		}

		
		historicoOperacionBloqueadoId = null;
		VistaOperacion vo = new VistaOperacion();
		
		
		listaErrores.clear();
		//Es modificable esta operacion?
		if(mantOperBo.calculoNumOrdenesDeOperacion(historicoOperacion.getId().getNumeroOperacion())!=0){
			statusMessages.add(Severity.ERROR , "#{messages['mantOper.messages.modificar.noModificable']}");
			return ret;
		}
		else if (mantOperBo.validatePendAgendaModifCancelAnul(historicoOperacion)) {
//			addError(vo.getHistOper(), ResourceBundle.instance().getString("mantOper.messages.modificar.agenda"));
			statusMessages.add(Severity.ERROR , "#{messages['mantOper.messages.modificar.agenda']}");
			return ret;
		} else if (mantOperBo.validatePendientesAgendaEvento(historicoOperacion,"2202") && 
				"VA".equalsIgnoreCase(historicoOperacion.getEstado().getCodigo()) &&
				"M".equalsIgnoreCase(historicoOperacion.getUltimaAccion().getCodigo())) {
//			addError(vo.getHistOper(), ResourceBundle.instance().getString("mantOper.messages.modificar.agenda"));
			statusMessages.add(Severity.ERROR , "#{messages['mantOper.messages.modificar.agenda']}");
			return ret;
		} else {
			if (!mantOperBo.validateLastFechaModificacion(historicoOperacion)) {
//				addError(vo.getHistOper(), ResourceBundle.instance().getString("mantOper.messages.modificar.noLastUpdate"));
				statusMessages.add(Severity.ERROR , "#{messages['mantOper.messages.modificar.noLastUpdate']}");
				return ret;

			} else {
				if (!dbLockService.bloqueo(HistoricoOperacion.class, historicoOperacion.getId())) {
//					addError(vo.getHistOper(), ResourceBundle.instance().getString("mantOper.messages.modificar.blocked"));
					statusMessages.add(Severity.ERROR , "#{messages['mantOper.messages.modificar.blocked']}");
					return ret;

				} else {
					HistoricoOperacion histOper = historicoOperacion;
					historicoOperacionBloqueadoId= historicoOperacion.getId();
					entityManager.refresh(histOper);
					//Invoca al package 
					AltaCorrelaResult result = boletasBo.prepareModificacionCorrela(histOper);
					
					
					if(result==null){
//						addError(historicoOperacion, ResourceBundle.instance().getString("mantOper.messages.modifica.error"));
						statusMessages.add(Severity.ERROR , "#{messages['mantOper.messages.modifica.error']}");
						return ret;
						
					}
					historicoOperacion=result.getHistoricoOperacion();
					boletaState = BoletasStates.MODI_BOLETA;
					
				}
			}
		}
		ret = Constantes.SUCCESS;
		return ret;
	}

	
	

	@Override
	public List<?> getDataTableList() {
		return migracionBMNPantalla.getMigracionList();
	}

	@Override
	protected void refreshListInternal() {
		setExportExcel(false);
		List<VistaMigracionBMN> listaMigra = new ArrayList<VistaMigracionBMN>();
		listaMigra = migracionBMNBo.obtenerMigraciones(migracionBMNPantalla.getContrapartida(),migracionBMNPantalla.getDealType(),
				migracionBMNPantalla.getNumOper(),migracionBMNPantalla.getClaveMurex(),migracionBMNPantalla.getClExterna(),
				migracionBMNPantalla.getIdBMN(),paginationData,false);
		
//		List<VistaMigracionBMN> listaVista = convertirVista(listaMigra);
		migracionBMNPantalla.setMigracionList(listaMigra);
		
	}

	private List<VistaMigracionBMN> convertirVista(List<MigracionBMN> listaMigra) {
		List<VistaMigracionBMN> listaVista = new ArrayList<VistaMigracionBMN>();
		for (MigracionBMN migracionBMN : listaMigra) {
			HistoricoOperacion oper = null;
			if (isExportExcel()){
				oper =  migracionBMNBo.recuperarHistoricoOperacion(migracionBMN);
			}
			VistaMigracionBMN vista = new VistaMigracionBMN(migracionBMN, oper);
			listaVista.add(vista);
		}
		return listaVista;
	}




	@Override
	public void refrescarListaExcel() {
		setExportExcel(true);
		List<VistaMigracionBMN> listaMigra = new ArrayList<VistaMigracionBMN>();
		listaMigra = migracionBMNBo.obtenerMigraciones(migracionBMNPantalla.getContrapartida(),migracionBMNPantalla.getDealType(),
				migracionBMNPantalla.getNumOper(),migracionBMNPantalla.getClaveMurex(),migracionBMNPantalla.getClExterna(),
				migracionBMNPantalla.getIdBMN(),paginationData.getPaginationDataForExcel(),false);
		
//		List<VistaMigracionBMN> listaVista = convertirVista(listaMigra);
		migracionBMNPantalla.setMigracionList(listaMigra);
			
	}

	
	
	public void excelBatch() {

		Long peticionBatch =  migracionBMNBo.guardarPeticionBatch();
		refrescarLista();
		String mensaje = ResourceBundle.instance().getString("liquidaciones.registros.validadosBatch") + " " + peticionBatch;
		statusMessages.add(Severity.INFO, mensaje);
	}

	
	@SuppressWarnings("unchecked")
	@Override
	public void setDataTableList(List<?> dataTableList) {
		migracionBMNPantalla.setMigracionList((List<VistaMigracionBMN>) dataTableList);
	}

	
	/*************************************************************************************************/
	/*********************************** MANEGADOR D'ERRORS ********************************************/
	/*************************************************************************************************/

	@SuppressWarnings("unused")
	private boolean addWarning(VistaOperacion vo) {
		return addWarning(vo.getHistOper(), "");
	}

	private boolean addWarning(VistaOperacion vo, String message) {
		return addWarning(vo.getHistOper(), message);
	}

	@SuppressWarnings("unused")
	private boolean addWarning(HistoricoOperacion ho) {
		return addWarning(ho, "");
	}

	private boolean addWarning(HistoricoOperacion ho, String message) {
		SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
		return listaErrores.add(new ErrorMessage(TypeError.WARNING, ho.getId().getNumeroOperacion().toString(), sdf.format(ho.getId()
				.getFechaContratacion()), message, ho));
	}
	
	@SuppressWarnings("unused")
	private boolean addError(VistaOperacion vo) {
		return addError(vo.getHistOper(), "");
	}

	private boolean addError(VistaOperacion vo, String message) {
		return addError(vo.getHistOper(), message);
	}

	@SuppressWarnings("unused")
	private boolean addError(HistoricoOperacion ho) {
		return addError(ho, "");
	}

	private boolean addError(HistoricoOperacion ho, String message) {
		if(isWarning(ho)){
			removeMessage(ho);
		}
		SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
		if (ho.getId()==null){
			return listaErrores.add(new ErrorMessage(TypeError.ERROR, message, sdf.format(new Date()), message, ho));
			
		}		
		return listaErrores.add(new ErrorMessage(TypeError.ERROR, ho.getId().getNumeroOperacion().toString(), sdf.format(ho.getId()
				.getFechaContratacion()), message, ho));
	}

	
	@SuppressWarnings("unused")
	private boolean isWarning(VistaOperacion vo){
		return isWarning(vo.getHistOper());
	}
	private boolean isWarning(HistoricoOperacion ho){
		for (ErrorMessage em : listaErrores) {
			if(em.getTypeError().equals(TypeError.WARNING)){
				if (em.getHo().equals(ho)) {
					return true;
				}
			}
		}
		return false;
	}
	
	@SuppressWarnings("unused")
	private boolean removeMessage(VistaOperacion vo){
		return removeMessage(vo.getHistOper());
	}
	private boolean removeMessage(HistoricoOperacion ho){
		for (ErrorMessage em : listaErrores) {
			if(em.getHo().equals(ho)){
				return listaErrores.remove(em);
			}
		}
		return false;
	}
	
	private boolean tieneErrores(VistaOperacion vo){
		return tieneErrores(vo.getHistOper());
	}
	private boolean tieneErrores(HistoricoOperacion ho){
		for (ErrorMessage em : listaErrores) {
			if(em.getTypeError().equals(TypeError.ERROR)){
				if (em.getHo().equals(ho)) {
					return true;
				}
			}
		}
		return false;
	}
	
		
	private void println(String message){
		System.out.println(message);
	}
	
	
	/*************************************************************************************************/
	/***************************************** FACTORY's ***********************************************/
	/*************************************************************************************************/

	@Factory(value = "dealtypes")
	public void initDealTypeList() {
		dealTypeList = migracionBMNBo.getDealTypeList();
	}

	/*************************************************************************************************/
	/************************************ GETTERS Y SETTERS ********************************************/
	/*************************************************************************************************/
	public MantOperBo getMantOperBo() {
		return mantOperBo;
	}

	public void setMantOperBo(MantOperBo mantOperBo) {
		this.mantOperBo = mantOperBo;
	}

	public BoletasBo getBoletasBo() {
		return boletasBo;
	}

	public void setBoletasBo(BoletasBo boletasBo) {
		this.boletasBo = boletasBo;
	}

	public HistoricoOperacion getHistoricoOperacion() {
		return historicoOperacion;
	}

	public void setHistoricoOperacion(HistoricoOperacion historicoOperacion) {
		this.historicoOperacion = historicoOperacion;
	}

	public BoletasStates getBoletaState() {
		return boletaState;
	}

	public void setBoletaState(BoletasStates boletaState) {
		this.boletaState = boletaState;
	}

	public String getModifCanc() {
		return modifCanc;
	}

	public void setModifCanc(String modifCanc) {
		this.modifCanc = modifCanc;
	}

	public ProcedenciaProducto getProcedencia() {
		return procedencia;
	}

	public void setProcedencia(ProcedenciaProducto procedencia) {
		this.procedencia = procedencia;
	}

	public ModeloProducto getModelo() {
		return modelo;
	}

	public void setModelo(ModeloProducto modelo) {
		this.modelo = modelo;
	}

	public ProductoCatalogo getProductoCatalogo() {
		return productoCatalogo;
	}

	public void setProductoCatalogo(ProductoCatalogo productoCatalogo) {
		this.productoCatalogo = productoCatalogo;
	}

	public Producto getProductoOperacion() {
		return productoOperacion;
	}

	public void setProductoOperacion(Producto productoOperacion) {
		this.productoOperacion = productoOperacion;
	}

	public DescripcionTransaccionOperacion getTransaccionOperacion() {
		return transaccionOperacion;
	}

	public void setTransaccionOperacion(DescripcionTransaccionOperacion transaccionOperacion) {
		this.transaccionOperacion = transaccionOperacion;
	}

	public Divisa getDivisaPago() {
		return divisaPago;
	}

	public void setDivisaPago(Divisa divisaPago) {
		this.divisaPago = divisaPago;
	}

	public Divisa getDivisaCobro() {
		return divisaCobro;
	}

	public void setDivisaCobro(Divisa divisaCobro) {
		this.divisaCobro = divisaCobro;
	}


	public NivelOperacion getNivelOperacion() {
		return nivelOperacion;
	}

	public void setNivelOperacion(NivelOperacion nivelOperacion) {
		this.nivelOperacion = nivelOperacion;
	}

	public String getContrapartida() {
		return contrapartida;
	}

	public void setContrapartida(String contrapartida) {
		this.contrapartida = contrapartida;
	}

	public TipoContrapartida getTipoContrapa() {
		return tipoContrapa;
	}

	public void setTipoContrapa(TipoContrapartida tipoContrapa) {
		this.tipoContrapa = tipoContrapa;
	}

	public String getSuReferencia() {
		return suReferencia;
	}

	public void setSuReferencia(String suReferencia) {
		this.suReferencia = suReferencia;
	}

	public BusquedaOperacion getSituacion() {
		return situacion;
	}

	public void setSituacion(BusquedaOperacion situacion) {
		this.situacion = situacion;
	}

	public DescripcionFormula getFormula() {
		return formula;
	}

	public void setFormula(DescripcionFormula formula) {
		this.formula = formula;
	}

	public String getModoConfirmacion() {
		return modoConfirmacion;
	}

	public void setModoConfirmacion(String modoConfirmacion) {
		this.modoConfirmacion = modoConfirmacion;
	}

	@Type(type = "SNNull")
	public Boolean getCobertura() {
		return cobertura;
	}

	public void setCobertura(Boolean cobertura) {
		this.cobertura = cobertura;
	}

	@Type(type = "SNNull")
	public Boolean getPendienteConf() {
		return pendienteConf;
	}

	public void setPendienteConf(Boolean pendienteConf) {
		this.pendienteConf = pendienteConf;
	}

	@Type(type = "SNNull")
	public Boolean getEstructura() {
		return estructura;
	}

	public void setEstructura(Boolean estructura) {
		this.estructura = estructura;
	}

	@Type(type = "SNNull")
	public Boolean getCampana() {
		return campana;
	}

	public void setCampana(Boolean campana) {
		this.campana = campana;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}

	public GenericRange<Long> getNumOper() {
		return numOper;
	}

	public void setNumOper(GenericRange<Long> numOper) {
		this.numOper = numOper;
	}

	public GenericRange<Date> getFechaVal() {
		return fechaVal;
	}

	public void setFechaVal(GenericRange<Date> fechaVal) {
		this.fechaVal = fechaVal;
	}

	public GenericRange<Date> getFechaVen() {
		return fechaVen;
	}

	public void setFechaVen(GenericRange<Date> fechaVen) {
		this.fechaVen = fechaVen;
	}

	public GenericRange<Date> getFechaOpe() {
		return fechaOpe;
	}

	public void setFechaOpe(GenericRange<Date> fechaOpe) {
		this.fechaOpe = fechaOpe;
	}

	public GenericRange<Long> getNumEstructu() {
		return numEstructu;
	}

	public void setNumEstructu(GenericRange<Long> numEstructu) {
		this.numEstructu = numEstructu;
	}

	public GenericRange<Long> getClExterna() {
		return clExterna;
	}

	public void setClExterna(GenericRange<Long> clExterna) {
		this.clExterna = clExterna;
	}

	public GenericRange<String> getClBduGid() {
		return clBduGid;
	}

	public void setClBduGid(GenericRange<String> clBduGid) {
		this.clBduGid = clBduGid;
	}

	public DbLockService getDbLockService() {
		return dbLockService;
	}

	public void setDbLockService(DbLockService dbLockService) {
		this.dbLockService = dbLockService;
	}
	public List<String> getDealTypeList() {
		return dealTypeList;
	}

	public void setDealTypeList(List<String> dealTypeList) {
		this.dealTypeList = dealTypeList;
	}

	public int getMaxSelected() {
		return maxSelected;
	}

	public void setMaxSelected(int maxSelected) {
		this.maxSelected = maxSelected;
	}

	public MigracionBMNPantalla getMigracionBMNPantalla() {
		return migracionBMNPantalla;
	}

	public void setMigracionBMNPantalla(MigracionBMNPantalla migracionBMNPantalla) {
		this.migracionBMNPantalla = migracionBMNPantalla;
	}

	


	
}
	