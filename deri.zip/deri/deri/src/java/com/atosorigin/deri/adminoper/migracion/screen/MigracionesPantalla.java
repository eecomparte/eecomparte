package com.atosorigin.deri.adminoper.migracion.screen;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import org.jboss.seam.ScopeType;
import org.jboss.seam.annotations.Name;
import org.jboss.seam.annotations.Out;
import org.jboss.seam.annotations.Scope;
import org.jboss.seam.annotations.datamodel.DataModel;
import org.jboss.seam.annotations.datamodel.DataModelSelection;

import com.atosorigin.deri.liquidaciones.business.MensajesValidacion;
import com.atosorigin.deri.liquidaciones.business.MensajesValidacionId;
import com.atosorigin.deri.model.adminoper.GenericRange;
import com.atosorigin.deri.model.gestionoperaciones.VistaMigraciones;
import com.atosorigin.deri.model.liquidaciones.VistaLiquidacion;

@Name("migracionesPantalla")
@Scope(ScopeType.CONVERSATION)
public class MigracionesPantalla {
	
	/**
	 * CRITERIOS DE SELECCION - INI
	 */
	
	private String contrapartida;
	private String dealType;
	private String entidadMigracion;
	
	private GenericRange<Long> numOper = new GenericRange<Long>("numoper", Long.class);
	private GenericRange<Long> claveMurex = new GenericRange<Long>("claveMurex", Long.class);
	private GenericRange<Long> clExterna = new GenericRange<Long>("clexterna", Long.class);
	private GenericRange<String> idEntidad = new GenericRange<String>("idEntidad", String.class);


	@DataModel(value = "listaMigracionesEnt")
	private List<VistaMigraciones> migracionList = null;

	@DataModelSelection(value = "listaMigracionesEnt")
	private VistaMigraciones migracionSelected;


	protected String estadoConf;
		
	
	//Cabecera
	protected String cabecera;
	
	private String onComplete;
	
	
	@DataModel(value="listaDtVistaLiqui")
	protected List<VistaLiquidacion> listaVistaLiqui;
	
	// Seguramente sera necesario sacar este objeto en otra pantalla
	HashMap<MensajesValidacionId, MensajesValidacion> liquidacionesMsg;
	
	/** Variable boolean para saber si venimos de la Agenda */
	protected boolean vieneAgenda;	
	
	/** Variable boolean para saber si venimos de Lista Operaciones */
	protected boolean vieneOperaciones;
	
	protected int registrosValidados = 0;
	protected ArrayList<String> errores = new ArrayList<String>();
	
	public boolean isVieneAgenda() {
		return vieneAgenda;
	}

	public void setVieneAgenda(boolean vieneAgenda) {
		this.vieneAgenda = vieneAgenda;
	}

	public HashMap<MensajesValidacionId, MensajesValidacion> getLiquidacionesMsg() {
		return liquidacionesMsg;
	}

	public void setLiquidacionesMsg(
			HashMap<MensajesValidacionId, MensajesValidacion> liquidacionesMsg) {
		this.liquidacionesMsg = liquidacionesMsg;
	}

	@Out(required=false, value="vistaLiqui")
	protected VistaLiquidacion vistaLiqui;
	


	@DataModelSelection(value="listaDtVistaLiqui")
	protected VistaLiquidacion vistaLiquiSelect;
	

	
	/** Checkbox forzar de Calificar Cobro */
	protected boolean forzar;
	
		
	public List<VistaLiquidacion> getListaVistaLiqui() {
		return listaVistaLiqui;
	}

	public void setListaVistaLiqui(List<VistaLiquidacion> listaVistaLiqui) {
		this.listaVistaLiqui = listaVistaLiqui;
	}


	public VistaLiquidacion getVistaLiquiSelect() {
		return vistaLiquiSelect;
	}

	public void setVistaLiquiSelect(VistaLiquidacion vistaLiquiSelect) {
		this.vistaLiquiSelect = vistaLiquiSelect;
	}

	public VistaLiquidacion getVistaLiqui() {
		return vistaLiqui;
	}

	public void setVistaLiqui(VistaLiquidacion vistaLiqui) {
		this.vistaLiqui = vistaLiqui;
	}

	public void copiarSeleccionado(){
		vistaLiqui = vistaLiquiSelect;

	}

	public String getCabecera() {
		return cabecera;
	}

	public void setCabecera(String cabecera) {
		this.cabecera = cabecera;
	}

	public boolean isForzar() {
		return forzar;
	}

	public void setForzar(boolean forzar) {
		this.forzar = forzar;
	}

	public boolean isVieneOperaciones() {
		return vieneOperaciones;
	}

	public void setVieneOperaciones(boolean vieneOperaciones) {
		this.vieneOperaciones = vieneOperaciones;
	}

	public int getRegistrosValidados() {
		return registrosValidados;
	}

	public void setRegistrosValidados(int registrosValidados) {
		this.registrosValidados = registrosValidados;
	}

	public ArrayList<String> getErrores() {
		return errores;
	}

	public void setErrores(ArrayList<String> errores) {
		this.errores = errores;
	}


	public String getOnComplete() {
		return onComplete;
	}

	public void setOnComplete(String onComplete) {
		this.onComplete = onComplete;
	}

	public String getEstadoConf() {
		return estadoConf;
	}

	public void setEstadoConf(String estadoConf) {
		this.estadoConf = estadoConf;
	}



	public String getContrapartida() {
		return contrapartida;
	}

	public void setContrapartida(String contrapartida) {
		this.contrapartida = contrapartida;
	}

	public String getDealType() {
		return dealType;
	}

	public void setDealType(String dealType) {
		this.dealType = dealType;
	}

	public GenericRange<Long> getNumOper() {
		return numOper;
	}

	public void setNumOper(GenericRange<Long> numOper) {
		this.numOper = numOper;
	}

	public GenericRange<Long> getClaveMurex() {
		return claveMurex;
	}

	public void setClaveMurex(GenericRange<Long> claveMurex) {
		this.claveMurex = claveMurex;
	}

	public GenericRange<Long> getClExterna() {
		return clExterna;
	}

	public void setClExterna(GenericRange<Long> clExterna) {
		this.clExterna = clExterna;
	}

	public GenericRange<String> getIdEntidad() {
		return idEntidad;
	}

	public void setIdEntidad(GenericRange<String> idEntidad) {
		this.idEntidad = idEntidad;
	}

	public List<VistaMigraciones> getMigracionList() {
		return migracionList;
	}

	public void setMigracionList(List<VistaMigraciones> migracionList) {
		this.migracionList = migracionList;
	}

	public VistaMigraciones getMigracionSelected() {
		return migracionSelected;
	}

	public void setMigracionSelected(VistaMigraciones migracionSelected) {
		this.migracionSelected = migracionSelected;
	}

	public String getEntidadMigracion() {
		return entidadMigracion;
	}

	public void setEntidadMigracion(String entidadMigracion) {
		this.entidadMigracion = entidadMigracion;
	}

	
}
