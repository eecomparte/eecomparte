package com.atosorigin.deri.adminoper.preconfirmaciones.action;

import java.sql.Timestamp;
import java.util.Date;
import java.util.List;

import javax.persistence.EntityManager;

import org.jboss.seam.ScopeType;
import org.jboss.seam.annotations.In;
import org.jboss.seam.annotations.Name;
import org.jboss.seam.annotations.Out;
import org.jboss.seam.annotations.Scope;
import org.jboss.seam.core.Conversation;
import org.jboss.seam.international.StatusMessage.Severity;
import org.jboss.seam.security.Credentials;

import com.atosorigin.common.action.ModoPantalla;
import com.atosorigin.common.action.PaginatedListAction;
import com.atosorigin.common.auditdata.AuditData;
import com.atosorigin.common.constantes.Constantes;
import com.atosorigin.common.formvalidator.FormValidator;
import com.atosorigin.common.utils.GenericUtils;
import com.atosorigin.deri.adminoper.boletas.action.BoletasAction.BoletasStates;
import com.atosorigin.deri.adminoper.preconfirmaciones.business.PreconfirmacionesBo;
import com.atosorigin.deri.adminoper.preconfirmaciones.screen.PreconfirmacionesPantalla;
import com.atosorigin.deri.contrapartida.business.ContrapartidaBo;
import com.atosorigin.deri.model.adminoper.DescripcionTipoConfirmacion;
import com.atosorigin.deri.model.contrapartida.Contrapartida;
import com.atosorigin.deri.model.gestionoperaciones.ConfOperacion;
import com.atosorigin.deri.model.gestionoperaciones.DescripcionAutorizaIndiforza;
import com.atosorigin.deri.model.gestionoperaciones.DescripcionEstadoConfirmacion;
import com.atosorigin.deri.model.gestionoperaciones.HistoricoConfOperacion;
import com.atosorigin.deri.model.gestionoperaciones.HistoricoConfOperacionId;
import com.atosorigin.deri.model.gestionoperaciones.HistoricoOperacion;
import com.atosorigin.deri.model.liquidaciones.VistaLiquidacion;
import com.atosorigin.deri.model.preconfirmaciones.Preconfirmaciones;
import com.atosorigin.deri.util.MessageBoxAction;
import com.atosorigin.deri.util.MsgBoxAction;
/**
 * Clase action listener para el caso de uso de preconfirmaciones
 */
@Name("preconfirmacionesAction")
@Scope(ScopeType.CONVERSATION)
@FormValidator
public class PreconfirmacionAction extends PaginatedListAction {

	/**
	 * Inyección del bean de Spring "preconfirmacionesBo" que contiene los métodos de
	 * negocio para el caso de uso preconfirmaciones.
	 */
	@In("#{preconfirmacionesBo}")
	protected PreconfirmacionesBo preconfirmacionesBo;

	/**
	 * Inyección del bean de Spring "contrapartidaBo" que contiene los métodos de
	 * negocio para el caso de uso de contrapartidas.
	 */
	@In("#{contrapartidaBo}")
	protected ContrapartidaBo contrapartidaBo;
	
	/**
	 * Inyección del screen bean que contiene los datos de pantalla del caso de
	 * uso preconfirmaciones
	 */
	@In(create = true)
	protected PreconfirmacionesPantalla preconfirmacionesPantalla;
	
	@In(required=false)
	private String modo; 
	
	//Para la union con datos generales alta BOLETAS
	@Out(required=false)
	private BoletasStates boletaState;
	
	@In Credentials credentials;
	
	@In
	private EntityManager entityManager;
	
	//Para la union con datos generales alta BOLETAS
	@Out(required=false)
	HistoricoOperacion historicoOperacion;
	
	/*
	 * variables de contexto Integra con MANTANEX
	 */
	@Out(required=false)
	private String modoTratamiento;
		
	@Out(required=false)
	private String tipoAnexo;	
	@Out(required=false)
	private String observaciones;

	@In(create = true)
	MsgBoxAction msgBoxAction;
	
	@Out(required = false, value = "preconfirmacionesMessageBoxAction")
	private MessageBoxAction messageBoxPreconfirmacionesAction;
	/**
	 * Indica si la navegación proviene de Boletas
     */
	private boolean desdeBoletas;
	
	public void init() {		
		if (Constantes.MODO_AGE.equals(modo) && primerAcceso) {
			preCargarDesdeAgenda();
			setPrimerAcceso(false);
		}
		
		if(null==messageBoxPreconfirmacionesAction){
			messageBoxPreconfirmacionesAction = new MessageBoxAction();
		}
		
	}
	/** Actualiza la lista del grid de preconfirmaciones */
	public void buscar() {
		paginationData.reset();
		this.preconfirmacionesPantalla.setModo(Constantes.CADENA_VACIA);
		/** Limpiamos la información de paginación */
		refrescarLista();
		setPrimerAcceso(false);
	}
	
	/** Valida si existe la contrapartida y si los valores introducidos en los campos de fecha
	 * y número de operación son correctos (num oper desde <= num oper hasta y fecha desde <= fecha hasta)
	 */
	public boolean buscarValidator(){
		
		boolean esCorrecto = true;
		
		if (!GenericUtils.isNullOrBlank(this.preconfirmacionesPantalla.getPreconfBusq().getContrapartida())) {
			/** Se valida la contrapartida introducida por el usuario */
			if (!validaContrapaExiste(this.preconfirmacionesPantalla
					.getPreconfBusq().getContrapartida())) {
				esCorrecto = false;
				statusMessages.addToControl("idContrapa", Severity.ERROR,
						"#{messages['preconfirmaciones.error.contrapartida']}");
			}
		}
		
		if(!GenericUtils.isNullOrBlank(this.preconfirmacionesPantalla.getNumOperDesde()) && !GenericUtils.isNullOrBlank(this.preconfirmacionesPantalla.getNumOperHasta()) ){
			
			if(this.preconfirmacionesPantalla.getNumOperHasta().compareTo(this.preconfirmacionesPantalla.getNumOperDesde()) < 0){
				esCorrecto = false;
				statusMessages.add(Severity.ERROR, "#{messages['preconfirmaciones.error.operhasta']}");
			}
		}
		
		if(!GenericUtils.isNullOrBlank(this.preconfirmacionesPantalla.getFechaDesde()) && !GenericUtils.isNullOrBlank(this.preconfirmacionesPantalla.getFechaHasta()) ){
			
			long diffFechaFinIni = (this.preconfirmacionesPantalla.getFechaHasta().getTime() - this.preconfirmacionesPantalla.getFechaDesde().getTime())/86400000L;
			
			if(diffFechaFinIni < 0){
				esCorrecto = false;
				statusMessages.add(Severity.ERROR, "#{messages['preconfirmaciones.error.fechahasta']}");
			}
		}
		
		if(!esCorrecto){
			preconfirmacionesPantalla.setPreconfirmacionesList(null);
		}
		
		return esCorrecto;
	}
	
	/** 
	 * Método que se ejecuta al regresar de Boletas.
	 * Tiene el mismo comportamiento que la edición de una preconfirmación
	 */
	public void irDetalleDesdeBoletas() {
		if (desdeBoletas){
			editar();
			desdeBoletas = false;
		}
	}
	
	/** Prepara para entrar en el modo edición de una preconfirmación */
	public void editar() {
		
		preconfirmacionesPantalla.setPreconfirmacion(this.preconfirmacionesPantalla.getPreconfirmacionSelec());
		
		/** Marcamos el check de preconfirmar si estadoco=S*/
		if(Constantes.CONSTANTE_SI.equalsIgnoreCase(this.preconfirmacionesPantalla.getPreconfirmacionSelec().getEstado())){
			this.preconfirmacionesPantalla.setPreconfirmado(true);
		} else {
			this.preconfirmacionesPantalla.setPreconfirmado(false);
		}
		
		this.setModoPantalla(ModoPantalla.EDICION);
	}
	
	/** Actualiza la preconfirmacion */
	public String tratar() {
		
		/** Recogemos el valor del checkbox preconfirmar y asignamos S ó N según
		 * esté o no marcado */
		if(this.preconfirmacionesPantalla.isPreconfirmado()){
			(preconfirmacionesPantalla.getPreconfirmacion()).setEstado(Constantes.CONSTANTE_SI);
		} else {
			(preconfirmacionesPantalla.getPreconfirmacion()).setEstado(Constantes.CONSTANTE_NO);
		}

		//  SMM 18/06/2013 Grabar ConfiopeHIST
		HistoricoConfOperacion historicoConf = generarHistorico(preconfirmacionesPantalla.getPreconfirmacion());
		preconfirmacionesBo.tratar(preconfirmacionesPantalla.getPreconfirmacion());
		preconfirmacionesBo.tratarHistoricoConfOperacion(historicoConf); 
	//	preconfirmacionesBo.recargar(preconfirmacionesPantalla.getPreconfirmacion());
		refrescarLista();
		return Constantes.CONSTANTE_SUCCESS;
	}
	
	private HistoricoConfOperacion generarHistorico(
			Preconfirmaciones preconfirmacion) {
/**
		CODCONFI: WS-CODCONFI-OUT
		FECHAOPE: TO_DATE(:WS-FECHAOPE-IN,:WC-FORMFECH)
		NCORRELA: WS-NCORRELA-IN 
		ESTRUCTU: null
		SENTIDOC: 'R'
		FECHALTA: WS-FECHALTA-OPE
		FECHCONF: null
		ESTADOCO: ‘AS’
		INDCONRE: null
		MODELCON: null
		TIPOEVEN: ‘C’
		EVENCONF: ‘A’
		FECHALIQ: null
		TIPOPERA: null
		FECINITR: null
		FECFINTR: null
		CONCEPTO: null
		TIPCONCE: null
		CODSWIFT:null
		OBSERVAC: null
		USULTACT: ‘RUTD2107’
		FEULTACT: sysdate
		INDICONF: null
		RUTACONF: null
		PRODUCAT: WS-PRODUCAT-OPE
		CODPLANT: null
		IDIOMACO: null
		CODCANAL: null
		CLAVEDMS: null
		INDSINFIR: null
		INDICOSP: null
		IDEDOCUM: null
		FEULTHIS: sysdate
*/

		ConfOperacion confirmacionVieja = preconfirmacionesBo.buscarConfirmacion(preconfirmacion);
		Date sysdate = new Date();
		HistoricoConfOperacionId id = new HistoricoConfOperacionId(sysdate, confirmacionVieja.getNumConfirmacion());
		HistoricoConfOperacion nuevo = new HistoricoConfOperacion(id);

		AuditData audit = new AuditData();
		audit.setFechaUltimaModi(sysdate);
		audit.setUsuarioUltimaModi(credentials.getUsername());
		nuevo.setAuditData(audit);
		
		nuevo.setOperacionID(preconfirmacion.getId().getOperacion());
		nuevo.setFechaContratacion(preconfirmacion.getId().getFechaContratacion());
		nuevo.setEstadoco("AS");
		DescripcionEstadoConfirmacion estadoco = (DescripcionEstadoConfirmacion) entityManager.createQuery("from DescripcionEstadoConfirmacion where codigo='AS'").getSingleResult();
		nuevo.setDescripcionEstadoConfirmacion(estadoco);
		
		nuevo.setSentidoConfirmacion("R");
		nuevo.setTipoConfirmacion("C");

		nuevo.setFechaAlta(confirmacionVieja.getFechaAlta());	
//		FECHALTA: WS-FECHALTA-OPE
		nuevo.setProducat(confirmacionVieja.getOperacion().getProductoCatalogo().toString());
//		PRODUCAT: WS-PRODUCAT-OPE
		nuevo.setEvenConf("A");	
		DescripcionTipoConfirmacion evenconf = (DescripcionTipoConfirmacion) entityManager.createQuery("from DescripcionTipoConfirmacion where codigo='A'").getSingleResult();
		nuevo.setEventoConfirmacion(evenconf);
		
		
		return nuevo;
	}
	/**
	 * Actualiza la lista del grid de parámetros informe y vuelve a la pantalla
	 * de búsqueda
	 */
	public void salirDetalle() {				
		if (this.modoPantalla.equals(ModoPantalla.EDICION)) {
			refrescarLista();
		}
	}
	
	@Override
	protected void refreshListInternal() {
		this.setExportExcel(false);
		List<Preconfirmaciones> listaPreconfirmaciones;
		
		if (Constantes.MODO_AGE.equalsIgnoreCase(this.preconfirmacionesPantalla.getModo())){
			listaPreconfirmaciones = (List<Preconfirmaciones>) preconfirmacionesBo.buscarPreconfirmacionesAgenda(paginationData);
		} else{
			listaPreconfirmaciones = (List<Preconfirmaciones>) preconfirmacionesBo.buscarPreconfirmaciones(this.preconfirmacionesPantalla.getPreconfBusq(), this.preconfirmacionesPantalla.getNumOperDesde(), this.preconfirmacionesPantalla.getNumOperHasta(), this.preconfirmacionesPantalla.getFechaDesde(), this.preconfirmacionesPantalla.getFechaHasta(), paginationData);
		}
		
		preconfirmacionesPantalla.setPreconfirmacionesList(listaPreconfirmaciones);
	}

	/** Método que comprueba si existe la contrapartida que introduce el usuario */
	private boolean validaContrapaExiste(String idContrapa) {
		
		boolean existeContrapa = true;
		
		if(GenericUtils.isNullOrBlank(this.contrapartidaBo.cargar(idContrapa))){
			existeContrapa = false;
		}
		
		return existeContrapa;
	}
	
	@Override
	public void refrescarListaExcel() {
		this.setExportExcel(true);
		List<Preconfirmaciones> listaPreconfirmaciones;
		if (Constantes.MODO_AGE.equalsIgnoreCase(this.preconfirmacionesPantalla.getModo())){
			listaPreconfirmaciones = (List<Preconfirmaciones>) preconfirmacionesBo.buscarPreconfirmacionesAgenda(paginationData.getPaginationDataForExcel());
		} else{
			listaPreconfirmaciones = (List<Preconfirmaciones>) preconfirmacionesBo.buscarPreconfirmaciones(this.preconfirmacionesPantalla.getPreconfBusq(), this.preconfirmacionesPantalla.getNumOperDesde(), this.preconfirmacionesPantalla.getNumOperHasta(), this.preconfirmacionesPantalla.getFechaDesde(), this.preconfirmacionesPantalla.getFechaHasta(), paginationData.getPaginationDataForExcel());
		}
		preconfirmacionesPantalla.setPreconfirmacionesList(listaPreconfirmaciones);
	}

	/**
	 * Función para llamar Boletas
	 */
	public String irOperaciones(){
		historicoOperacion = preconfirmacionesBo.obtenerHistoricoOperacion(preconfirmacionesPantalla.getPreconfirmacionSelec().getId());
		if (historicoOperacion==null){
			statusMessages.add(Severity.ERROR, "#{messages['preconfirmaciones.operInexistente']}");
			return null;
		}
		desdeBoletas = true;
		boletaState = BoletasStates.CONSULTA_BOLETA;
		return Constantes.SUCCESS;
	}
	
	/** Función a la que se llama desde la pantalla de agenda, para precargar el 
	 * listado de preconfirmaciones */
	public void preCargarDesdeAgenda(){
		this.preconfirmacionesPantalla.setModo(Constantes.MODO_AGE);
		this.refrescarLista();
	}
	
	public void salir(){
		Conversation conversacion = Conversation.instance();
		//Volvemos a la anterior conversación
		if(conversacion.isNested()){
			conversacion.redirectToParent();
		} else {
			redirectToURL("/home.seam");
			conversacion.endAndRedirect();
		}
	}
	
	public boolean isDesdeBoletas() {
		return desdeBoletas;
	}
	
	public void setDesdeBoletas(boolean desdeBoletas) {
		this.desdeBoletas = desdeBoletas;
	}
	
	@SuppressWarnings("unchecked")
	@Override
	public void setDataTableList(List<?> dataTableList) {
		this.preconfirmacionesPantalla.setPreconfirmacionesList((List<Preconfirmaciones>)dataTableList);
	}

	@Override
	public List<?> getDataTableList() {
		return this.preconfirmacionesPantalla.getPreconfirmacionesList();
	}
	
	public String anexos(){
		String ret = Constantes.SUCCESS;
//		VistaOperacion vo = vistaOperacionSelected;
//		historicoOperacion = vo.getHistOper();
		modoTratamiento = Constantes.TIPOANEXO_MODO_E;
		tipoAnexo = Constantes.TIPOANEXO_PRECONFIRMACION;
		observaciones = this.preconfirmacionesPantalla.getPreconfirmacion().getObservaciones();
		return ret;
	}
	
	public void voidFunction(){
		msgBoxAction.voidFunction();
	}

	/**
	 * Mostrar PopUp cuando una contrapartida está bloqueada (no bloqueante)
	 */
	public void onVerificarContrapartidaBloqueada() {
		if(preconfirmacionesPantalla.getPreconfBusq()!=null && !GenericUtils.isNullOrBlank(preconfirmacionesPantalla.getPreconfBusq().getContrapartida())){
			String contrapartida = preconfirmacionesPantalla.getPreconfBusq().getContrapartida();
			Contrapartida contrapObtenida2;
			contrapObtenida2 = preconfirmacionesBo.cargarContrapartida(contrapartida.toUpperCase());	
			if (null!=contrapObtenida2 && !GenericUtils.isNullOrBlank(contrapObtenida2.getIndBloqueo()) && "S".equalsIgnoreCase(contrapObtenida2.getIndBloqueo())){
				messageBoxPreconfirmacionesAction.init("confirmaciones.messages.contrapartida.bloqueada.texto", "preconfirmacionesAction.voidFunction()", null,"messageBoxPanelContrapa");
			}
		}
    }
	
	public String getRowClasses(){
		StringBuilder builder = new StringBuilder();
		int i=0;
		for (Preconfirmaciones pre : preconfirmacionesPantalla.getPreconfirmacionesList()) {
			Contrapartida contrapartida;
			String idContrapartida = pre.getContrapartida();
			contrapartida = preconfirmacionesBo.cargarContrapartida(idContrapartida.toUpperCase());	
			
			if(i>0){
				builder.append(",");
			}
			
			if(i%2==0){
				if(null!=contrapartida && !GenericUtils.isNullOrBlank(contrapartida.getIndBloqueo()) && "S".equalsIgnoreCase(contrapartida.getIndBloqueo())){
					builder.append("oddRowRed");
				}
				else{
					builder.append("oddRow");
				}
			}
			else{
				if(null!=contrapartida && !GenericUtils.isNullOrBlank(contrapartida.getIndBloqueo()) && "S".equalsIgnoreCase(contrapartida.getIndBloqueo())){
					builder.append("evenRowRed");
				}
				else{
					builder.append("evenRow");
				}
			}
			i++;
			contrapartida = null;
		}
		return builder.toString();
	}
}
