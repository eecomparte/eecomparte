package com.atosorigin.deri.adminoper.preconfirmaciones.screen;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.jboss.seam.ScopeType;
import org.jboss.seam.annotations.Name;
import org.jboss.seam.annotations.Out;
import org.jboss.seam.annotations.Scope;
import org.jboss.seam.annotations.datamodel.DataModel;
import org.jboss.seam.annotations.datamodel.DataModelSelection;
import org.jboss.seam.core.ResourceBundle;

import com.atosorigin.deri.model.preconfirmaciones.Preconfirmaciones;
import com.atosorigin.deri.model.preconfirmaciones.PreconfirmacionesId;

/**
 * Contiene los datos de pantalla necesarios para el caso de uso preconfirmaciones.
 */
@Name("preconfirmacionesPantalla")
@Scope(ScopeType.CONVERSATION)
public class PreconfirmacionesPantalla {

	/** Lista de datos para el grid. */
	@DataModel(value = "listaDtPreconfirmaciones")
	protected List<Preconfirmaciones> preconfirmacionesList;

	/** Parametro seleccionado en el grid */
	@DataModelSelection(value = "listaDtPreconfirmaciones")
	@Out(value = "preconfirmacionSelec", required = false)
	protected Preconfirmaciones preconfirmacionSelec;

	@Out(value = "preconfirmacion", required = false)
	protected Preconfirmaciones preconfirmacion;
	
	/** Criterios Seleccion */
	protected Preconfirmaciones preconfBusq;
	protected Long numOperDesde;
	protected Long numOperHasta;
	protected Date fechaDesde;
	protected Date fechaHasta;
	protected List<String> valoresComboSitu;
	
	/** Checkbox preconfirmado */
	protected boolean preconfirmado;

	/** Modo para saber si venimos de la agenda */
	protected String modo;
	
	public PreconfirmacionesPantalla() {
		this.valoresComboSitu = new ArrayList<String>();
		this.preconfBusq = new Preconfirmaciones(new PreconfirmacionesId());
		valoresComboSitu.add(ResourceBundle.instance().getString("preconfirmaciones.pdtepreconfirmacion"));
		valoresComboSitu.add(ResourceBundle.instance().getString("preconfirmaciones.preconfirmada"));
	}

	public List<Preconfirmaciones> getPreconfirmacionesList() {
		return preconfirmacionesList;
	}

	public Preconfirmaciones getPreconfirmacionSelec() {
		return preconfirmacionSelec;
	}

	public Preconfirmaciones getPreconfirmacion() {
		return preconfirmacion;
	}

	public Preconfirmaciones getPreconfBusq() {
		return preconfBusq;
	}

	public Long getNumOperDesde() {
		return numOperDesde;
	}

	public Long getNumOperHasta() {
		return numOperHasta;
	}

	public Date getFechaDesde() {
		return fechaDesde;
	}

	public Date getFechaHasta() {
		return fechaHasta;
	}

	public List<String> getValoresComboSitu() {
		return valoresComboSitu;
	}

	public void setPreconfirmacionesList(
			List<Preconfirmaciones> preconfirmacionesList) {
		this.preconfirmacionesList = preconfirmacionesList;
	}

	public void setPreconfirmacionSelec(Preconfirmaciones preconfirmacionSelec) {
		this.preconfirmacionSelec = preconfirmacionSelec;
	}

	public void setPreconfirmacion(Preconfirmaciones preconfirmacion) {
		this.preconfirmacion = preconfirmacion;
	}

	public void setPreconfBusq(Preconfirmaciones preconfBusq) {
		this.preconfBusq = preconfBusq;
	}

	public void setNumOperDesde(Long numOperDesde) {
		this.numOperDesde = numOperDesde;
	}

	public void setNumOperHasta(Long numOperHasta) {
		this.numOperHasta = numOperHasta;
	}

	public void setFechaDesde(Date fechaDesde) {
		this.fechaDesde = fechaDesde;
	}

	public void setFechaHasta(Date fechaHasta) {
		this.fechaHasta = fechaHasta;
	}

	public void setValoresComboSitu(List<String> valoresComboSitu) {
		this.valoresComboSitu = valoresComboSitu;
	}

	public boolean isPreconfirmado() {
		return preconfirmado;
	}

	public void setPreconfirmado(boolean preconfirmado) {
		this.preconfirmado = preconfirmado;
	}

	public String getModo() {
		return modo;
	}

	public void setModo(String modo) {
		this.modo = modo;
	}

	
}
