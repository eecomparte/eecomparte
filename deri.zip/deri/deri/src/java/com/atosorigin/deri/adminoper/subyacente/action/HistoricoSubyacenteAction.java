package com.atosorigin.deri.adminoper.subyacente.action;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Set;

import javax.persistence.EntityManager;

import org.jboss.seam.ScopeType;
import org.jboss.seam.annotations.In;
import org.jboss.seam.annotations.Name;
import org.jboss.seam.annotations.Out;
import org.jboss.seam.annotations.Scope;
import org.jboss.seam.annotations.TransactionPropagationType;
import org.jboss.seam.annotations.Transactional;
import org.jboss.seam.annotations.datamodel.DataModel;
import org.jboss.seam.annotations.datamodel.DataModelSelection;
import org.jboss.seam.core.Conversation;
import org.jboss.seam.international.StatusMessage.Severity;
import org.jboss.seam.security.Identity;

import com.atosorigin.common.action.GenericAction;
import com.atosorigin.common.action.ModoPantalla;
import com.atosorigin.common.auditdata.AuditData;
import com.atosorigin.common.constantes.Constantes;
import com.atosorigin.common.formvalidator.FormValidator;
import com.atosorigin.common.utils.GenericUtils;
import com.atosorigin.deri.adminoper.boletas.action.BoletasAction.BoletasStates;
import com.atosorigin.deri.adminoper.boletas.business.BoletasBo;
import com.atosorigin.deri.adminoper.mantbarreras.business.MantenimientoBarrerasBo;
import com.atosorigin.deri.adminoper.subyacente.screen.HistoricoSubyacentePantalla;
import com.atosorigin.deri.adminoper.subyacentes.business.HistoricoSubyacenteBo;
import com.atosorigin.deri.common.dbLock.DbLockService;
import com.atosorigin.deri.model.adminoper.HistoricoSubyacente;
import com.atosorigin.deri.model.adminoper.HistoricoSubyacenteId;
import com.atosorigin.deri.model.gestionoperaciones.HistoricoOperacion;
import com.atosorigin.deri.model.gestionoperaciones.HistoricoOperacionId;
import com.atosorigin.deri.util.EntityUtil;
import com.atosorigin.deri.util.MessageBoxAction;

/**
 * Clase action listener para el caso de uso de mantenimiento de subyacentes
 * 
 * Ojo, OrigenPantalla es OP si venimos de operacion
 *                     si venimos de barreras, es el tipo de barrera
 */
@Name("historicoSubyacenteAction")
@Scope(ScopeType.CONVERSATION)
@FormValidator
public class HistoricoSubyacenteAction extends GenericAction {

	@Out(required = false, value = "histoSubyacenteMessageBoxAction")
	private MessageBoxAction messageBoxAction;

	/**
	 * Inyección del bean de Spring "historicoSubyacenteBo" que contiene los métodos de
	 * negocio para el caso de uso de mantenimiento de subyacentes.
	 */
	@In("#{historicoSubyacenteBo}")
	protected HistoricoSubyacenteBo historicoSubyacenteBo;
	
	@In
	private EntityManager entityManager;

	
	@In(required=false)
	HistoricoOperacionId historicoOperacionBloqueadoId;

	
	@In("#{mantenimientoBarrerasBo}")
	protected MantenimientoBarrerasBo mantenimientoBarrerasBo;  

	@In(value="origenPantalla", required=true)
	protected String pantallaOrigen;
	
	/**
	 * Inyección del screen bean que contiene los datos de pantalla del caso de
	 * uso de mantenimiento de subyacentes
	 */
	@In(create = true)
	protected HistoricoSubyacentePantalla historicoSubyacentePantalla;

	/** Lista de datos original */
	protected Set<HistoricoSubyacente> listaOriginal;
	
	/** Lista de datos para el grid. */
	@DataModel(value = "listaDtHistSubyacente")
	protected List<HistoricoSubyacente> historicoSubyacentesList;

	/** HistoricoSubyacente seleccionado en el grid */
	@DataModelSelection(value = "listaDtHistSubyacente")
	protected HistoricoSubyacente historicoSubyacenteSelec;
	
	/** Inyección del objeto padre de Boletas, en este caso HistoricoOperacion */
	@In(required=false)
	protected HistoricoOperacion historicoOperacion;
	@In(required=true)
	private BoletasStates boletaState;


	@In(value = "dbLockService", create = true)
	private DbLockService dbLockService;

	@In(required=false)
	private String forcedReturnView;
	
	@In("#{boletasBo}")
	protected BoletasBo boletasBo;

	private boolean salirDirecto;
	private Boolean modificar = false;
	
	/**
	 * Función a la que se debe llamar desde boletas para acceder a la pantalla de 
	 * mantenimiento de subyacentes.
	 * @return
	 */
	public String init(){
		
		
		//Cargamos en pantalla la lista de historicosubyacentes del historicoOperacion que viene de boletas
		cargarGrid();
		
		//Calculamos el peso total de la cesta y lo guardamos en memoria. Además nos guardamos el 
		//valor original, que no vamos a modificar, para tenerlo como referencia
		BigDecimal pesoTotalCesta = historicoSubyacenteBo.calcularPeso(historicoOperacion.getId(),
				pantallaOrigen);

		this.historicoSubyacentePantalla.setPesoCestaOriginal(pesoTotalCesta);
		this.historicoSubyacentePantalla.setPesoTotalCesta(pesoTotalCesta);
		
		return Constantes.CONSTANTE_SUCCESS;
	}
	
	/**
	 * Obtiene la descripción del HistoricoSubyacente
	 * @return
	 */
	public String obtenerDescripcionSubyacente(Long codIndic){
		return historicoSubyacenteBo.obtenerDescripcionSubyacente(codIndic);
	}
	
	/**
	 * Obtiene la divisa del HistoricoSubyacente
	 * @return
	 */
	public String obtenerDivisa(Long codIndic){
		return historicoSubyacenteBo.obtenerDivisa(codIndic);
	}
	
	/**
	 * Obtiene la descripción del tipoStrike
	 * @param codigo
	 * @return
	 */
	public String obtenerDescripcionTipoStri(String codigo){
		return historicoSubyacenteBo.obtenerDescripcionTiposTri(codigo);
	}
	
	/**
	 * Obtiene la descripción del tipo subyacente
	 * @return
	 */
	public String obtenerDescripcionTipoSubyacente (String codigo){
		return historicoSubyacenteBo.obtenerDescripcionTipoSubyacente(codigo);
	}
	
	/**
	 * Carga el grid de historicosubyacentes
	 */
	public void cargarGrid() {
		
		
		listaOriginal = historicoOperacion.getHistoricoSubyacentes();

		if ( this.primerAcceso )
			this.historicoSubyacentesList = new ArrayList<HistoricoSubyacente>();
		
		//Tenemos que filtrar la lista que nos llega, que contiene todos los HistoricoSuby
		// del HistoricoOperacion. Solo queremos mostrar en la tabla los que tiposuby = origen
		
		this.getHistoricoSubyacentesList().clear();
		for (HistoricoSubyacente histo : listaOriginal) {
			
			if(histo.getId().getTiposuby().equals(pantallaOrigen)){
				this.getHistoricoSubyacentesList().add(histo);
			}
		}
		this.setPrimerAcceso(false);
		
	}

	/**
	 * Función para habilitar/deshabilitar el botón de alta
	 * @return
	 */
	public boolean mostrarAlta(){
		
		boolean esVisible = true;
		int numeroRegistros = -1;
		
		if(!GenericUtils.isNullOrBlank(this.getHistoricoSubyacentesList())){
			numeroRegistros = this.getHistoricoSubyacentesList().size();
		}

		
		if(BoletasStates.CONSULTA_BOLETA.equals(boletaState)){
			esVisible = false;
			
		} else if(!GenericUtils.isNullOrBlank(historicoOperacion.getHistoricoOpcion()) &&  !historicoOperacion.getHistoricoOpcion().getIndicadorCesta() 
				&& numeroRegistros == 1) {
			esVisible = false;
		}
		
		return esVisible;
	}
	
	/** Prepara para entrar en el modo inspección de un historicoSubyacente. */
	public void ver() {
		historicoSubyacentePantalla.setHistoricoSubyacente(this.getHistoricoSubyacenteSelec());
		this.setModoPantalla(ModoPantalla.INSPECCION);
		calcularPesoRelativoCesta();
		activarDesactivar();
	}
	
	/** Prepara para entrar en el modo edición de un historicoSubyacente. */
	public void editar() {
		historicoSubyacentePantalla.setHistoricoSubyacente(this.getHistoricoSubyacenteSelec());
		setModoPantalla(ModoPantalla.EDICION);
		historicoSubyacentePantalla.setPesoSubyaEditOriginal(this.getHistoricoSubyacenteSelec().getPesoSubyacente());
		historicoSubyacentePantalla.setPesoTotalCesta(historicoSubyacentePantalla.getPesoCestaOriginal());
		calcularPesoRelativoCesta();
		activarDesactivar();
	}
	
	/** Prepara para entrar en el modo creación de un historicoSubyacente */
	public String nuevo() {
		
		if(historicoOperacion.getHistoricoOpcion()==null || historicoOperacion.getHistoricoOpcion().getTipoSubyacente()==null){
			//log.error("", "historicosubyacente.error.tiposubyacente.obligatorio");
			statusMessages.addFromResourceBundle(Severity.ERROR, "historicosubyacente.error.tiposubyacente.obligatorio" );
			return Constantes.CONSTANTE_FAIL;			
		}

		if(historicoOperacion.getHistoricoOpcion()==null || historicoOperacion.getHistoricoOpcion().getTipoStrike() ==null){
			//log.error("", "historicosubyacente.error.tipostrike.obligatorio");
			statusMessages.addFromResourceBundle(Severity.ERROR, "historicosubyacente.error.tipostrike.obligatorio" );
			return Constantes.CONSTANTE_FAIL;			
		}
		
		
		//HistoricoSubyacenteId idNuevo = new HistoricoSubyacenteId(historicoOperacion,0,historicoOperacion.getHistoricoOpcion().getTipoSubyacente().getCodigo());
		//FLM: El tipo debe ser el origen, OP
		//this.pantallaOrigen  -> Debe ser OP si es de boletas, o si es de barreras el que le pasen
		HistoricoSubyacenteId idNuevo = new HistoricoSubyacenteId(historicoOperacion,0,  this.pantallaOrigen    );
		
		HistoricoSubyacente nuevoHistSuby = new HistoricoSubyacente(idNuevo, null, BigDecimal.ONE, null, null, null, null);
		historicoSubyacentePantalla.setHistoricoSubyacente(nuevoHistSuby);
		this.setModoPantalla(ModoPantalla.CREACION);
		historicoSubyacentePantalla.setPesoTotalCesta(historicoSubyacentePantalla.getPesoCestaOriginal().add(BigDecimal.ONE));
		calcularPesoRelativoCesta();
		activarDesactivar();
		return Constantes.CONSTANTE_SUCCESS;
	}
	
	/**
	 * Validaciones previas al alta y edición
	 * @return true si se pasan todas las validaciones correctamente
	 */
	public boolean guardarValidator(){
		
		boolean esCorrecto = true;
		
		//Si TIPOSTRI == V
		if ( historicoOperacion.getHistoricoOpcion() == null || historicoOperacion.getHistoricoOpcion().getTipoStrike() == null ){
			statusMessages.add(Severity.ERROR,"Tipo strike es obligatorio"); // TODO
		}
		if (esStrikeV_o_I()){
			
			//F.Precio Inicial obligatorio si Strike es vacío
			if(GenericUtils.isNullOrBlank(historicoSubyacentePantalla.getHistoricoSubyacente().getStrikeSubyacente())
					&& GenericUtils.isNullOrBlank(historicoSubyacentePantalla.getHistoricoSubyacente().getFechaPrecioInicial())){
				esCorrecto = false;
				statusMessages.addToControl("fechaPreinic",Severity.ERROR,"#{messages['historicosubyacente.error.feprein.obligatorio']}");
			}
			
			//El porcentaje debe ser > 0
			BigDecimal porc = historicoSubyacentePantalla.getHistoricoSubyacente().getPorcentajeInicial();
			if(!GenericUtils.isNullOrBlank(porc) && porc.compareTo(BigDecimal.ZERO) < 0){
				esCorrecto = false;
				statusMessages.addToControl("fechaPreinic",Severity.ERROR,"#{messages['historicosubyacente.error.porcentaje.mayorcero']}");
			}
		}
		
		if (ModoPantalla.CREACION.equals(this.modoPantalla)) {
			//Si el registro existe en el sistema no dejamos dar de alta
			HistoricoSubyacente his = historicoSubyacenteBo.cargar(historicoSubyacentePantalla.getHistoricoSubyacente());
			if (!GenericUtils.isNullOrBlank(his)) {
				esCorrecto = false;
				statusMessages.add(Severity.ERROR,"#{messages['historicosubyacente.error.yaexiste']}");
			}
		}
		
		if(!esCorrecto){
			reCalcularPesoCesta(); //Si falla alguna validación recalculamos el peso
		}
		
		return esCorrecto;
	}

	private boolean esStrikeV_o_I() {
		return Constantes.TIPOSTRI_V.equalsIgnoreCase(historicoOperacion.getHistoricoOpcion().getTipoStrike().getCodigo())
				|| Constantes.TIPOSTRI_I.equalsIgnoreCase(historicoOperacion.getHistoricoOpcion().getTipoStrike().getCodigo());
	}
	
	/**
	 * Guarda el historicosubyacente en base de datos
	 * @return
	 */
	public String guardar(){
		
		HistoricoSubyacente histGuardar = historicoSubyacentePantalla.getHistoricoSubyacente();
		AuditData audit = new AuditData();
		audit.setUsuarioUltimaModi(Identity.instance().getCredentials().getUsername());
		audit.setFechaUltimaModi(new Date());
		histGuardar.setAuditData(audit); // fijamos usuario y fecha actualización

//		SMM 1907
		if (GenericUtils.isNullOrBlank(histGuardar.getPorcentajeInicial()) || BigDecimal.ZERO.equals(histGuardar.getPorcentajeInicial())){
			histGuardar.setPorcentajeInicial(BigDecimal.ONE);
		}
		
		/* Para tipostrike == V, si precio inicial y porcentaje <> null se calcula Strike como
		 *  precio inicial * porcentaje */
		if (esStrikeV_o_I()) {
			if (!GenericUtils.isNullOrBlank(histGuardar.getPrecioInicialSubyacente())
					&& !GenericUtils.isNullOrBlank(histGuardar.getPorcentajeInicial())) {

				BigDecimal precio = histGuardar.getPrecioInicialSubyacente();
				BigDecimal porcentaje = histGuardar.getPorcentajeInicial();
				BigDecimal producto = precio.multiply(porcentaje);
				histGuardar.setStrikeSubyacente(producto);
			}
		}
		
		// Si es un alta, añadimos el nuevo registro a la lista y sumamos su peso al total de la cesta
		if(ModoPantalla.CREACION.equals(this.modoPantalla)){
			this.getHistoricoSubyacentesList().add(histGuardar);
			// Es parte de la operacion, lo tenemos que poner en la lista de subyacentes de operacion
			this.historicoOperacion.getHistoricoSubyacentes().add(histGuardar);
			
			//Si origen es boletas, buscamos las barreras y por cada una de ellas se añade un registro
			if ("OP".equalsIgnoreCase(pantallaOrigen)){
				
				List<String> listaBarreras = historicoSubyacenteBo.obtenerTipoBarrera(historicoOperacion);
				
				if (!GenericUtils.isNullOrBlank(listaBarreras)) {
					HistoricoSubyacente histSubyBarr;
					HistoricoSubyacenteId histSubyBarrId;
					Long codIndic = histGuardar.getId().getCodindic();
					for (String tipobarr : listaBarreras) {

						//SMM 20/06/2016 Subyacentes Barrera Si Existe subyacente barrera no hacer nada
						boolean existeSubi =false;
						for (HistoricoSubyacente subi : this.historicoOperacion.getHistoricoSubyacentes()) {
							
							if (tipobarr.equalsIgnoreCase(subi.getId().getTiposuby())){
								existeSubi = true;
								break;
							}
						}
						
						if (existeSubi) continue;
						
						histSubyBarrId = new HistoricoSubyacenteId(
								historicoOperacion,
								codIndic, tipobarr);
						histSubyBarr = new HistoricoSubyacente(histSubyBarrId,
								null, histGuardar.getPesoSubyacente(),
								histGuardar.getPrecioInicialSubyacente(), null,
								histGuardar.getPorcentajeInicial(), null);

						histSubyBarr.setAuditData(audit); //fijamos usuario y fecha actualizacion

						//Añadimos el historico subyacente a la lista
//						if (!GenericUtils.isNullOrBlank(historicoSubyacenteBo.cargar(histSubyBarr))) {
						if (!GenericUtils.isNullOrBlank(histSubyBarr)) {							
							this.getHistoricoSubyacentesList().add(histSubyBarr);
							this.historicoOperacion.getHistoricoSubyacentes().add(histSubyBarr);
						} //Si ya hay un subyacente asociado a la barrera, no hacer nada
					}
				}
			}
		} //else, si es una edición hay que actualizar usuario y fecha de ultima actualizacion
		
		// Actualizamos el peso de la cesta
		if ("OP".equalsIgnoreCase(pantallaOrigen) && historicoOperacion.getHistoricoSubyacentes().size()>0){
			historicoOperacion.getHistoricoOpcion().setStrikeOpcion(histGuardar.getStrikeSubyacente());
		}
			
		historicoSubyacentePantalla.setPesoCestaOriginal(historicoSubyacentePantalla.getPesoTotalCesta());
		entityManager.flush();

		return Constantes.SUCCESS;
	}

	
	//FLM: Ojo al retornar debemos ejecutar un proceso retornoBoletas
	public String salirSubyacente(){
		//Conversation conv= Conversation.instance(); 
		//conv.redirectToParent();
		//Ojo, pantallaOrigen en 
		if  ("OP".equals(pantallaOrigen)) {
			//Ojo, en el retorno a boletas recalculamos los campos de strike
			//TODO: retornoBoletas();		
			//entityManager.flush();			
			return "OP"; 
		} else {
			// Se hace la copia automatica
			entityManager.flush();
			return "BAR";
		}
		
	}
	
	
	/**
	 * Vuelve a la pantalla de búsqueda desde la de detalle
	 */
	public void salirDetalle() {
		Conversation conv= Conversation.instance();
		conv.redirectToParent();				
		
//		if (messageBoxAction==null)
//			messageBoxAction=new MessageBoxAction();
//		messageBoxAction.init("historicosubyacente.salir", "HistoricoSubyacenteAction.salirDetalleOk()", "HistoricoSubyacenteAction.salirDetalleKo()");;
	}

	public void salirDetalleOk() {
		Conversation conv= Conversation.instance();
		conv.redirectToParent();				
	}
	public void salirDetalleKo() {
	}
	
	

	/**
	 * Elimina un subyacente de la lista. Si se viene de boletas se borran todos los subyacentes,
	 * si viene de barrera solamente borra los de esa barrera
	 */
	@Transactional(TransactionPropagationType.REQUIRED )
	public void borrar(){
		HistoricoSubyacente histBorrar = historicoSubyacentePantalla.getHistoricoSubyacente();
		HistoricoSubyacenteId idHistBorrar = histBorrar.getId();
		this.getHistoricoSubyacentesList().remove(histBorrar);
		// FLM: Y de operaciones tambien !!
		this.historicoOperacion.getHistoricoSubyacentes().remove(histBorrar);

		//SMM 29/06/2016 Cambio Criterio Se desliga Subyacente operacion del Subyacente Barrera
		//Si se borra uno, no se borra el otro.
		
//		if("OP".equalsIgnoreCase(pantallaOrigen)){
//			//Si es OP hay que borrar además TODOS los registros de ese historicoOperacion y ese subyacente
//			//para cada tipo barrera, por lo que tenemos que recorrer la lista original e ir eliminando 
//			// los que correspondan(en el datamodel no es necesario porque ya está filtrado)
//			HistoricoSubyacenteId idAux;
//			List<HistoricoSubyacente> listBorrar = new ArrayList<HistoricoSubyacente>();
//			
//			for (HistoricoSubyacente histo : historicoOperacion.getHistoricoSubyacentes()) {
//				//Comparamos los campos de la id, menos el tiposuby, y vamos eliminando registros
//				//si hay coincidencia
//				idAux = histo.getId();
//				
//				if(idAux.getCodindic() == idHistBorrar.getCodindic()){
//					listBorrar.add(histo);
//				}
//			}
//			
//			//Eliminamos todos los registros con el mismo subyacente y cualquier tipobarr (tiposuby)
//			this.historicoOperacion.getHistoricoSubyacentes().removeAll(listBorrar);
//		} 		
		
		BigDecimal pesoActualizado = historicoSubyacentePantalla.getPesoCestaOriginal().subtract(histBorrar.getPesoSubyacente());
		historicoSubyacentePantalla.setPesoCestaOriginal(pesoActualizado);

		//FLM: Guardamos lo que se ha realizado
		entityManager.flush();		
	}
	
	/**
	 * Tratamiento de campos en función del tipo de strike 
	 */
	private void activarDesactivar(){
		
		String tipoStrike = getTipoStrike();
		
		if(modoPantalla.equals(ModoPantalla.INSPECCION)
				|| Constantes.TIPOSTRI_N.equalsIgnoreCase(tipoStrike)
				|| GenericUtils.isNullOrBlank(tipoStrike)){
			historicoSubyacentePantalla.setFecpreinActivo(false);
			historicoSubyacentePantalla.setPortinicActivo(false);
			historicoSubyacentePantalla.setStrikesuActivo(false);
			historicoSubyacentePantalla.setPreinisuActivo(false);
		} else if(Constantes.TIPOSTRI_F.equalsIgnoreCase(tipoStrike)){
			historicoSubyacentePantalla.setFecpreinActivo(false);
			historicoSubyacentePantalla.setPortinicActivo(false);
			historicoSubyacentePantalla.setStrikesuActivo(true);
			historicoSubyacentePantalla.setPreinisuActivo(false);
		} else if (Constantes.TIPOSTRI_V.equalsIgnoreCase(tipoStrike)|| Constantes.TIPOSTRI_I.equalsIgnoreCase(tipoStrike)){
			historicoSubyacentePantalla.setFecpreinActivo(true);
			historicoSubyacentePantalla.setPortinicActivo(true);
			historicoSubyacentePantalla.setStrikesuActivo(true);
			historicoSubyacentePantalla.setPreinisuActivo(true);
		}
	}

	private String getTipoStrike() {
		String tipoStrike = null;
		if(historicoOperacion.getHistoricoOpcion()!=null &&	historicoOperacion.getHistoricoOpcion().getTipoStrike()!=null){
			tipoStrike = historicoOperacion.getHistoricoOpcion().getTipoStrike().getCodigo();
		}
		return tipoStrike;
	}
	
	/**
	 * Fija el valor del peso relativo al cargar la pantalla de
	 * detalle.
	 */
	private void calcularPesoRelativoCesta(){
		
		try {
		BigDecimal pesoSubya = this.historicoSubyacentePantalla.getHistoricoSubyacente().getPesoSubyacente();
		BigDecimal pesoRelativo = pesoSubya.divide(historicoSubyacentePantalla.getPesoTotalCesta(),4,BigDecimal.ROUND_HALF_EVEN);
		BigDecimal cien = BigDecimal.TEN.multiply(BigDecimal.TEN);
		this.historicoSubyacentePantalla.setPesoRespectoTotal(pesoRelativo.multiply(cien));
		} catch (Exception e) {
			BigDecimal cero = BigDecimal.TEN.multiply(BigDecimal.ZERO );
			this.historicoSubyacentePantalla.setPesoRespectoTotal(cero);
		}		
	}

	/**
	 * Fija los valores de peso total cesta y de peso relativo al cambiar el valor del peso
	 * del subyacente
	 */
	public void reCalcularPesoCesta(){
		
		Boolean indiCesta = historicoOperacion.getHistoricoOpcion().getIndicadorCesta();
		BigDecimal cien = BigDecimal.TEN.multiply(BigDecimal.TEN);
		BigDecimal pesoSubya = this.historicoSubyacentePantalla.getHistoricoSubyacente().getPesoSubyacente();
		BigDecimal pesoOriginalCesta = this.historicoSubyacentePantalla.getPesoCestaOriginal();
		BigDecimal pesoOriginalSubya = this.historicoSubyacentePantalla.getPesoSubyaEditOriginal();
		
		//Si no es cesta, el peso total siempre es igual al del único subyacente que hay
		//en la cesta, y su porcentaje relativo del 100%
		if(!indiCesta){
			this.historicoSubyacentePantalla.setPesoTotalCesta(pesoSubya);
			this.historicoSubyacentePantalla.setPesoRespectoTotal(cien);
		}
		
		if (indiCesta && ModoPantalla.CREACION.equals(this.modoPantalla)){
			//Si es cesta el peso del nuevo subyacente se acumula al de la cesta
			BigDecimal pesoNuevoCesta = pesoOriginalCesta.add(pesoSubya);
			this.historicoSubyacentePantalla.setPesoTotalCesta(pesoNuevoCesta);
			calcularPesoRelativoCesta();
		} else if (indiCesta && ModoPantalla.EDICION.equals(this.modoPantalla)){
			BigDecimal pesoCestaSinSubya = pesoOriginalCesta.subtract(pesoOriginalSubya);
			BigDecimal pesoNuevoCesta = pesoCestaSinSubya.add(pesoSubya);
			this.historicoSubyacentePantalla.setPesoTotalCesta(pesoNuevoCesta);
			calcularPesoRelativoCesta();
		}
	}

	/**
	 * Si se informa precio incial y porcentaje, se calcula strike = precio * porcentaje
	 */
	public void calculaStrike(){
		
		BigDecimal precio = historicoSubyacentePantalla.getHistoricoSubyacente().getPrecioInicialSubyacente();
		BigDecimal porcentaje = historicoSubyacentePantalla.getHistoricoSubyacente().getPorcentajeInicial();
		
		if(!GenericUtils.isNullOrBlank(precio) && !GenericUtils.isNullOrBlank(porcentaje)){
			BigDecimal strike = precio.multiply(porcentaje);
			historicoSubyacentePantalla.getHistoricoSubyacente().setStrikeSubyacente(strike);
		}
	}
	
	public List<HistoricoSubyacente> getHistoricoSubyacentesList() {
		return historicoSubyacentesList;
	}

	public HistoricoSubyacente getHistoricoSubyacenteSelec() {
		return historicoSubyacenteSelec;
	}

	public void setHistoricoSubyacentesList(
			List<HistoricoSubyacente> historicoSubyacentesList) {
		this.historicoSubyacentesList = historicoSubyacentesList;
	}

	public void setHistoricoSubyacenteSelec(
			HistoricoSubyacente historicoSubyacenteSelec) {
		this.historicoSubyacenteSelec = historicoSubyacenteSelec;
	}
	
	public String decidirSalir(){
		
		if (isSalirDirecto()) {
			setModificar(true);
			return salirDirecto(); 
		}
			else{ 
				salir();
				return "SalirDos";
			}
			
	}
	
	public String salirDirecto(){

		if ( !BoletasStates.CONSULTA_BOLETA.equals( this.boletaState) ) {
			try {
				String result = boletasBo.salirOperacion("R", historicoOperacion, Identity.instance().getCredentials().getUsername());
				if (result != null) {
					String codigoValidacionErroneo = result;
					statusMessages.add(Severity.ERROR, "#{messages['boletas.edicion.error.salir.operacion']");
				}
				//FLM: boletas es un caso especial, si estamos en alta tenemos que saltar 2 parents quizas?
				return doCommonRedirect();
				//return doSalirRedirect();
			} finally {
				if (boletaState == BoletasStates.MODI_BOLETA) {
					dbLockService.desbloqueo(HistoricoOperacion.class, historicoOperacionBloqueadoId);
				}
			}

		} else { 
			return doCommonRedirect();
		}
		    

		
	}
	
private String doCommonRedirect() {
	
	
	if(forcedReturnView!=null){
		return doSalirRedirect();
	}
	if(boletaState==BoletasStates.ALTA_BOLETA){
		Conversation.instance().pop();
    	if (getModificar()){
    		Conversation.instance().pop();	
    	}
    	if  (!"OP".equals(pantallaOrigen)) {
    		Conversation.instance().pop();
    		Conversation.instance().pop();
    	}
    	return "salir";
	}
	
	Conversation conversacion=Conversation.instance();
	Conversation.instance().pop();
	if (getModificar()){
		Conversation.instance().pop();	
	}
	if  (!"OP".equals(pantallaOrigen)) {
		Conversation.instance().pop();
		Conversation.instance().pop();
	}
	//	Conversation conversacion = Conversation.instance();
	//Volvemos al anterior
	conversacion.redirectToParent();
	return "";
}	

private String doSalirRedirect() {

	if ( BoletasStates.ALTA_BOLETA.equals( this.boletaState) ) {
		
    	Conversation nested =Conversation.instance();
    	Conversation.instance().pop();
    	Conversation.instance().pop();
    	if (getModificar()){
    		Conversation.instance().pop();	
    	}
    	if  (!"OP".equals(pantallaOrigen)) {
    		Conversation.instance().pop();
    		Conversation.instance().pop();
    	}
    	
    	boolean dosSaltos= ( "/pages/adminoper/boletas/alta/altaOper.xhtml".equalsIgnoreCase( Conversation.instance().getViewId() ) );
    	
    
    	if(forcedReturnView!=null){
    		if(dosSaltos){
    			Conversation.instance().redirectToParent();
    			return "";
    		}else{
    			Conversation.instance().redirect();
    			return "";

    		}
		}
    	
    	nested.end(true);
    	if(EntityUtil.checkEntityExists(entityManager, historicoOperacion.getProductoCompuesto())){
    		return "/pages/gestionoperaciones/productocompuesto/mantProdCompuesto.xhtml";
    	}
		return "salir";
	} else {
		Conversation conversacion=Conversation.instance();
		Conversation.instance().pop();
    	if (getModificar()){
    		Conversation.instance().pop();	
    	}
    	if  (!"OP".equals(pantallaOrigen)) {
    		Conversation.instance().pop();
    		Conversation.instance().pop();
    	}
		conversacion.redirectToParent();
		return "";
	}
}

public Boolean getModificar() {
	return modificar;
}

public void setModificar(Boolean modificar) {
	this.modificar = modificar;
}

public boolean isSalirDirecto() {
	return salirDirecto;
}

public void setSalirDirecto(boolean salirDirecto) {
	this.salirDirecto = salirDirecto;
}




	
}