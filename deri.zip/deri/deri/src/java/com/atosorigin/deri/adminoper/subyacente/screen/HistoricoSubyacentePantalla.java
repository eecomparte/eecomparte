package com.atosorigin.deri.adminoper.subyacente.screen;

import java.math.BigDecimal;

import org.jboss.seam.ScopeType;
import org.jboss.seam.annotations.Name;
import org.jboss.seam.annotations.Out;
import org.jboss.seam.annotations.Scope;

import com.atosorigin.deri.model.adminoper.HistoricoSubyacente;

/**
 * Contiene los datos de pantalla necesarios para el caso de uso mantenimiento de subyacentes.
 */
@Name("historicoSubyacentePantalla")
@Scope(ScopeType.CONVERSATION)
public class HistoricoSubyacentePantalla {

	@Out(required=false)
	protected HistoricoSubyacente historicoSubyacente;
	
	/** Parametros calculados */
	protected BigDecimal pesoTotalCesta;
	protected BigDecimal pesoRespectoTotal;
	protected BigDecimal pesoCestaOriginal;
	protected BigDecimal pesoSubyaEditOriginal;
	
	/** Variables booleanas para el tratamiento de campos en funcion de tipostri */
	protected boolean preinisuActivo;
	protected boolean portinicActivo;
	protected boolean fecpreinActivo;
	protected boolean strikesuActivo;
	
	public HistoricoSubyacente getHistoricoSubyacente() {
		return historicoSubyacente;
	}

	public void setHistoricoSubyacente(HistoricoSubyacente historicoSubyacente) {
		this.historicoSubyacente = historicoSubyacente;
	}

	public BigDecimal getPesoTotalCesta() {
		return pesoTotalCesta;
	}

	public BigDecimal getPesoRespectoTotal() {
		return pesoRespectoTotal;
	}

	public void setPesoTotalCesta(BigDecimal pesoTotalCesta) {
		this.pesoTotalCesta = pesoTotalCesta;
	}

	public void setPesoRespectoTotal(BigDecimal pesoRespectoTotal) {
		this.pesoRespectoTotal = pesoRespectoTotal;
	}

	public boolean isPreinisuActivo() {
		return preinisuActivo;
	}

	public boolean isPortinicActivo() {
		return portinicActivo;
	}

	public boolean isFecpreinActivo() {
		return fecpreinActivo;
	}

	public boolean isStrikesuActivo() {
		return strikesuActivo;
	}

	public void setPreinisuActivo(boolean preinisuActivo) {
		this.preinisuActivo = preinisuActivo;
	}

	public void setPortinicActivo(boolean portinicActivo) {
		this.portinicActivo = portinicActivo;
	}

	public void setFecpreinActivo(boolean fecpreinActivo) {
		this.fecpreinActivo = fecpreinActivo;
	}

	public void setStrikesuActivo(boolean strikesuActivo) {
		this.strikesuActivo = strikesuActivo;
	}

//	public HistoricoOperacion getHistOperMadre() {
//		return histOperMadre;
//	}

//	public void setHistOperMadre(HistoricoOperacion histOperMadre) {
//		this.histOperMadre = histOperMadre;
//	}

	public BigDecimal getPesoCestaOriginal() {
		return pesoCestaOriginal;
	}

	public void setPesoCestaOriginal(BigDecimal pesoCestaOriginal) {
		this.pesoCestaOriginal = pesoCestaOriginal;
	}

	public BigDecimal getPesoSubyaEditOriginal() {
		return pesoSubyaEditOriginal;
	}

	public void setPesoSubyaEditOriginal(BigDecimal pesoSubyaEditOriginal) {
		this.pesoSubyaEditOriginal = pesoSubyaEditOriginal;
	}
}
