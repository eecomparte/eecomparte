package com.atosorigin.deri.adminoper.swaption.action;

import javax.persistence.EntityManager;

import org.jboss.seam.ScopeType;
import org.jboss.seam.annotations.In;
import org.jboss.seam.annotations.Name;
import org.jboss.seam.annotations.Out;
import org.jboss.seam.annotations.Scope;
import org.jboss.seam.international.StatusMessage.Severity;
import org.jboss.seam.security.Credentials;

import com.atosorigin.common.action.GenericAction;
import com.atosorigin.common.constantes.Constantes;
import com.atosorigin.common.formvalidator.FormValidator;
import com.atosorigin.deri.adminoper.boletas.action.BoletasAction.BoletasStates;
import com.atosorigin.deri.adminoper.boletas.business.BoletasBo;
import com.atosorigin.deri.adminoper.swaption.screen.SwaptionPantalla;
import com.atosorigin.deri.model.gestionoperaciones.HistoricoOperacion;
import com.atosorigin.deri.model.gestionoperaciones.Operacion;
import com.atosorigin.deri.util.ErrorMessageBoxAction;



@Name("swaptionAction")
@Scope(ScopeType.CONVERSATION)
@FormValidator
public class SwaptionAction extends GenericAction {


	@In(create=true)
	@Out(value="swaptionPantalla")
	protected SwaptionPantalla swaptionPantalla;
	
	@In(value = "#{boletasBo}")
	protected BoletasBo boletasBo;

	@In
	private HistoricoOperacion historicoOperacion;
	
	@In
	private BoletasStates boletaState;

	@In
	private ErrorMessageBoxAction errorMessageBoxAction;

	@In
	EntityManager entityManager; 

    @In Credentials credentials;
	
    
    public void init(){
    	
    	swaptionPantalla.setFechaContratacionAsociada(historicoOperacion.getHistoricoOpcion().getFechaContratacionAsociada());
    	swaptionPantalla.setNumeroOperacionAsociada(historicoOperacion.getHistoricoOpcion().getNumeroOperacionAsociada());
    	swaptionPantalla.setTipoSwaption(historicoOperacion.getHistoricoOpcion().getTipoSwaption());
		errorMessageBoxAction.setReRender("Swaption");
		errorMessageBoxAction.setOnComplete("");

	}
    
    public Boolean guardarSwapValidator(){
//Se debe validar que exista en Situderi, que el estadoco =’VA’ y que el producat sea 
//del modelo ‘SWAP’
    	Operacion oper = boletasBo.getOperacionByNCorrelaAndFechaOper(swaptionPantalla.getNumeroOperacionAsociada(), swaptionPantalla.getFechaContratacionAsociada());
    	if (oper==null){
			statusMessages.add(Severity.ERROR, "#{messages['swaption.error.noexiste']}");

//    		statusMessages.addFromResourceBundle(Severity.ERROR, "swaption.error.noexiste");
    		return false;	
    	}else if (!oper.getEstado().equalsIgnoreCase("VA")){
    		statusMessages.addFromResourceBundle(Severity.ERROR, "swaption.error.novalidada");
    		return false;
    	}else if (!boletasBo.obtenerModeloProducto(Long.valueOf(oper.getProductoCatalogo().toString())).equalsIgnoreCase("SWP")){
    		statusMessages.addFromResourceBundle(Severity.ERROR, "swaption.error.noSwap");
    		return false;
    	}
    	return true;
    }
    
    public String guardarSwap(){
    	historicoOperacion.getHistoricoOpcion().setFechaContratacionAsociada(swaptionPantalla.getFechaContratacionAsociada());
    	historicoOperacion.getHistoricoOpcion().setNumeroOperacionAsociada(swaptionPantalla.getNumeroOperacionAsociada());
    	historicoOperacion.getHistoricoOpcion().setTipoSwaption(swaptionPantalla.getTipoSwaption());
    	return Constantes.CONSTANTE_SUCCESS;
	}
	
	public String salirSwap(){
		return Constantes.CONSTANTE_SUCCESS;
	}
	
	

	public HistoricoOperacion getHistoricoOperacion() {
		return historicoOperacion;
	}

	public void setHistoricoOperacion(HistoricoOperacion historicoOperacion) {
		this.historicoOperacion = historicoOperacion;
	}

	public SwaptionPantalla getSwaptionPantalla() {
		return swaptionPantalla;
	}

	public void setSwaptionPantalla(SwaptionPantalla swaptionPantalla) {
		this.swaptionPantalla = swaptionPantalla;
	}

	public BoletasBo getBoletasBo() {
		return boletasBo;
	}

	public void setBoletasBo(BoletasBo boletasBo) {
		this.boletasBo = boletasBo;
	}

	
}

