package com.atosorigin.deri.adminoper.swaption.screen;

import java.util.Date;

import org.jboss.seam.ScopeType;
import org.jboss.seam.annotations.Name;
import org.jboss.seam.annotations.Scope;

import com.atosorigin.deri.model.adminoper.DescripcionTipoSwaption;


@Name("swaptionPantalla")
@Scope(ScopeType.CONVERSATION)
public class SwaptionPantalla {

	
	protected Long numeroOperacionAsociada;
	protected Date fechaContratacionAsociada;
	protected DescripcionTipoSwaption tipoSwaption;
	


	public Long getNumeroOperacionAsociada() {
		return numeroOperacionAsociada;
	}

	public void setNumeroOperacionAsociada(Long numeroOperacionAsociada) {
		this.numeroOperacionAsociada = numeroOperacionAsociada;
	}

	public Date getFechaContratacionAsociada() {
		return fechaContratacionAsociada;
	}

	public void setFechaContratacionAsociada(Date fechaContratacionAsociada) {
		this.fechaContratacionAsociada = fechaContratacionAsociada;
	}

	public DescripcionTipoSwaption getTipoSwaption() {
		return tipoSwaption;
	}

	public void setTipoSwaption(DescripcionTipoSwaption tipoSwaption) {
		this.tipoSwaption = tipoSwaption;
	}

	
}
