package com.atosorigin.deri.adminoper.tramosrango.action;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;

import org.jboss.seam.ScopeType;
import org.jboss.seam.annotations.In;
import org.jboss.seam.annotations.Name;
import org.jboss.seam.annotations.Out;
import org.jboss.seam.annotations.Scope;
import org.jboss.seam.annotations.datamodel.DataModel;
import org.jboss.seam.annotations.datamodel.DataModelSelection;
import org.jboss.seam.core.Conversation;
import org.jboss.seam.international.StatusMessage.Severity;
import org.jboss.seam.security.Identity;

import com.atosorigin.common.action.ModoPantalla;
import com.atosorigin.common.action.PaginatedListAction;
import com.atosorigin.common.constantes.Constantes;
import com.atosorigin.common.formvalidator.FormValidator;
import com.atosorigin.common.utils.GenericUtils;
import com.atosorigin.deri.adminoper.boletas.action.BoletasAction.BoletasStates;
import com.atosorigin.deri.adminoper.tramosrango.business.TramosRangoBo;
import com.atosorigin.deri.adminoper.tramosrango.screen.TramosrangoPantalla;
import com.atosorigin.deri.model.adminoper.HistoricoTramosRango;
import com.atosorigin.deri.model.adminoper.HistoricoTramosRangoId;
import com.atosorigin.deri.model.gestionoperaciones.HistoricoOperacion;
import com.atosorigin.deri.model.gestionoperaciones.HistoricoOperacionId;

@Name("tramosrangoAction")
@Scope(ScopeType.CONVERSATION)
@FormValidator
public class TramosrangoAction extends PaginatedListAction {

	// oO[Variables]Oo
	@In("#{tramosRangoBo}")
	protected TramosRangoBo tramosrangoBo;

	// Se pasan estos parámetros, ojo boletas, en un caso puede en consulta y diferente a boletas state
	@In
	private HistoricoOperacion historicoOperacion;
	
	@In
	private BoletasStates boletaStateWedd;
	
	@In
	private EntityManager entityManager;
	
	private boolean esAlta;
	private boolean esModif;
	private boolean desactivado;
	
	private boolean muestraPanel = false;
	
	@In(create=true)
	protected TramosrangoPantalla tramosrangoPantalla;
	
	@DataModel(value ="listaDtTramosrango")
	protected List<HistoricoTramosRango> historicoTramosrangoList;
	
	@DataModelSelection(value ="listaDtTramosrango")
	protected HistoricoTramosRango historicoTramos;
	
	@Out(value="histtramrang", required=false)
	protected HistoricoTramosRango historicoTramosRango;
	
	// oO[Métodos]Oo
	@Override
	public List<HistoricoTramosRango> getDataTableList() {
		return this.historicoTramosrangoList;
	}

	@Override
	protected void refreshListInternal() {
		setExportExcel(false);
		if(GenericUtils.isNullOrBlank(historicoTramosrangoList)){
			historicoTramosrangoList = new ArrayList<HistoricoTramosRango>();
		}
		historicoTramosrangoList.clear();
	    historicoTramosrangoList.addAll(tramosrangoBo.obtenerHistoricoTramosRangos(this.getHistoricoOperacion(), paginationData));
	}

	@Override
	public void refrescarListaExcel() {
		setExportExcel(true);
		// TODO Auto-generated method stub
	}
	
	@SuppressWarnings("unchecked")
	@Override
	public void setDataTableList(List<?> dataTableList) {
		historicoTramosrangoList = (List<HistoricoTramosRango>)dataTableList;
	}
	
	/**
	 * Método que se ejecuta la primera vez que se entra en la página
	 * @param historicoOperacion
	 */
	public void mostrarPantallaListado(){
		if(GenericUtils.isNullOrBlank(this.getHistoricoOperacion())){
			if (this.boletaStateWedd==BoletasStates.ALTA_BOLETA )
				this.setModoPantalla(ModoPantalla.CREACION );
			else if (this.boletaStateWedd==BoletasStates.MODI_BOLETA )
				this.setModoPantalla(ModoPantalla.EDICION );
			else
				this.setModoPantalla(ModoPantalla.INSPECCION );
			//Las fechas inicio y fin se forman dependiendo si se viene de modif/detalle o alta
			try{
				SimpleDateFormat formatoDelTexto = new SimpleDateFormat("dd/MM/yyyy");
				SimpleDateFormat formatoDelTextoHora = new SimpleDateFormat("dd/MM/yyyy H:mm:ss");
				setHistoricoOperacion(new HistoricoOperacion());
				getHistoricoOperacion().setId(new HistoricoOperacionId());
				getHistoricoOperacion().getId().setNumeroOperacion(2012602L);
				getHistoricoOperacion().getId().setFechaTratamiento(formatoDelTexto.parse("20/12/2006"));
				getHistoricoOperacion().getId().setFechaContratacion(formatoDelTexto.parse("20/12/2006"));
				getHistoricoOperacion().getId().setFechaModificacion(formatoDelTextoHora.parse("20/12/2006 12:41:06"));
			}catch (ParseException e) {				
				e.printStackTrace();
			}
		}
		this.refrescarLista();
	}
	
	/**
	 * Muestra la pantalla para dar de alta un nuevo tramo
	 */
	public void nuevo(){
		this.setEsAlta(true);
		this.setEsModif(false);
		this.setDesactivado(false);
		if(GenericUtils.isNullOrBlank(historicoTramosrangoList)){
			this.setDataTableList(new ArrayList<HistoricoTramosRango>());
		}
		this.setHistoricoTramosRango(new HistoricoTramosRango(new HistoricoTramosRangoId()));
		this.getHistoricoTramosRango().getId().setHistoricoOperacion(getHistoricoOperacion());
		this.getHistoricoTramosRango().setUsuario(Identity.instance().getCredentials().getUsername());
		//Ponemos los valores por defecto del tramo en función de la boleta. 
		this.getHistoricoTramosRango().getId().setFechaInicial(getHistoricoOperacion().getFechaValor());
		this.getHistoricoTramosRango().getId().setFechaFinal(getHistoricoOperacion().getFechaVencimiento());
		
		//asignamos el valor del rango
		Integer rango = tramosrangoBo.obtenerRangowedSiguiente(historicoOperacion);
		this.getHistoricoTramosRango().getId().setRango(rango.byteValue());
		
		setModoPantalla(ModoPantalla.CREACION);
	}
	
	/**
	 * Muestra la pantalla para editar el tramo
	 */
	public String editar(){
		this.setEsAlta(false);
		this.setEsModif(true);
		this.setDesactivado(false);
		this.setHistoricoTramosRango(this.getHistoricoTramos());
		setModoPantalla(ModoPantalla.EDICION);
		return Constantes.CONSTANTE_SUCCESS;
	}
	
	/**
	 * Muestra la pantalla para visualizar el detalle del tramo
	 */
	public String ver(){
		this.setDesactivado(true);
		this.setHistoricoTramosRango(this.getHistoricoTramos());
		setModoPantalla(ModoPantalla.INSPECCION);
		return Constantes.CONSTANTE_SUCCESS;
	}
	
	public void borrar(){
		tramosrangoBo.borraTramoRango(historicoTramos);
		//fijar
		entityManager.flush();
		refrescarLista();
	}
	
	/**
	 * Guarda en BBDD los nuevos registros o actualiza los modificacos
	 * @return
	 */
	public String guardar(){
		//FLM: Por algun extraño motivo, parece que este BO no hace el flush ok, seguramente tema transaccional 
		//FLM: Salvamos el valor		
		//Esto lo hace el guardar

/*
//por ver		 
		Set<HistoricoTramosRango > tramosAnteriores = historicoOperacion.getHistoricoTramosRangos();
		for(HistoricoTramosRango histFechaFor : tramosAnteriores){
			if(histFechaFor.getId().getTipoFecha().equals(modo)){
				formulasAnteriores.remove(histFechaFor);
			}
		}
		formulasAnteriores.addAll(mantFechasPantalla.getListadoHistoricoFechaFormula());
*/
		//Perisistir
		if(getModoPantalla().equals(ModoPantalla.CREACION)){
			tramosrangoBo.nuevoTramoRango(this.getHistoricoTramosRango());
		}else if(getModoPantalla().equals(ModoPantalla.EDICION)){
			tramosrangoBo.editaTramoRango(this.getHistoricoTramosRango());
		}
		//fijar
		entityManager.flush();
		return Constantes.CONSTANTE_SUCCESS;
	}
	
	/**
	 * Valida los campos antes de guardar en BBDD
	 * @return
	 */
	public boolean guardarValidator(){
		boolean resultado = true;
		
		if(GenericUtils.isNullOrBlank(this.getHistoricoTramosRango().getRangoUpper())){
			statusMessages.addToControl("rangoUpperTxt",Severity.ERROR,"#{messages['tramosrango.obligatorio.upper']}");
			resultado = false;
		}
		if(GenericUtils.isNullOrBlank(this.getHistoricoTramosRango().getRangoLower())){
			statusMessages.addToControl("rangoLowerTxt",Severity.ERROR,"#{messages['tramosrango.obligatorio.lower']}");
			resultado = false;
		}
		if(GenericUtils.isNullOrBlank(this.getHistoricoTramosRango().getRangoRate())){
			statusMessages.addToControl("rangoRateTxt",Severity.ERROR,"#{messages['tramosrango.obligatorio.rate']}");
			resultado = false;
		}
		if((!GenericUtils.isNullOrBlank(this.getHistoricoTramosRango().getRangoUpper())) && (!GenericUtils.isNullOrBlank(this.getHistoricoTramosRango().getRangoLower()))){
			if((this.getHistoricoTramosRango().getRangoUpper().longValue()) <= (this.getHistoricoTramosRango().getRangoLower().longValue())){
				statusMessages.add(Severity.ERROR,"#{messages['tramosrango.erroneo.upper']}");
				resultado = false;
			}
		}
		
		/* Incidencia 1213. Hay que validar los rangos en formato 5 enteros, 12 decimales */
		if(!GenericUtils.validaFormatoDecimal(this.getHistoricoTramosRango().getRangoUpper(),
				5, 12)){
			statusMessages.addToControl("rangoUpperTxt",Severity.ERROR,"#{messages['tramosrango.formato']}");
			resultado = false;
		}
		
		if(!GenericUtils.validaFormatoDecimal(this.getHistoricoTramosRango().getRangoLower(),
				5, 12)){
			statusMessages.addToControl("rangoLowerTxt",Severity.ERROR,"#{messages['tramosrango.formato']}");
			resultado = false;
		}
		
		if(!GenericUtils.validaFormatoDecimal(this.getHistoricoTramosRango().getRangoRate(),
				5, 12)){
			statusMessages.addToControl("rangoRateTxt",Severity.ERROR,"#{messages['tramosrango.formato']}");
			resultado = false;
		}
		/* fin incidencia */
		
		if(this.getHistoricoTramosRango().getId().getFechaInicial().after(this.getHistoricoTramosRango().getId().getFechaFinal())){
			statusMessages.add(Severity.ERROR,"#{messages['tramosrango.fechaserrroneas']}");
			resultado = false;
		}
		return resultado;
	}
	
	public void salir(){
		Conversation conversacion=Conversation.instance();
		//Volvemos al anterior
		conversacion.redirectToParent();
	}

	// oO[Getters y Setters]Oo
	public boolean isEsAlta() {
		return esAlta;
	}

	public void setEsAlta(boolean esAlta) {
		this.esAlta = esAlta;
	}

	public void setDesactivado(boolean desactivado) {
		this.desactivado = desactivado;
	}

	public boolean isDesactivado() {
		return desactivado;
	}

	public void setEsModif(boolean esModif) {
		this.esModif = esModif;
	}

	public boolean isEsModif() {
		return esModif;
	}

	public void setHistoricoOperacion(HistoricoOperacion historicoOperacion) {
		this.historicoOperacion = historicoOperacion;
	}

	public HistoricoOperacion getHistoricoOperacion() {
		return historicoOperacion;
	}

	public boolean isMuestraPanel() {
		return muestraPanel;
	}

	public void setMuestraPanel(boolean muestraPanel) {
		this.muestraPanel = muestraPanel;
	}

	public HistoricoTramosRango getHistoricoTramos() {
		return historicoTramos;
	}

	public void setHistoricoTramos(HistoricoTramosRango historicoTramos) {
		this.historicoTramos = historicoTramos;
	}

	public HistoricoTramosRango getHistoricoTramosRango() {
		return historicoTramosRango;
	}

	public void setHistoricoTramosRango(HistoricoTramosRango historicoTramosRango) {
		this.historicoTramosRango = historicoTramosRango;
	}

	public List<HistoricoTramosRango> getHistoricoTramosrangoList() {
		return historicoTramosrangoList;
	}

	public void setHistoricoTramosrangoList(
			List<HistoricoTramosRango> historicoTramosrangoList) {
		this.historicoTramosrangoList = historicoTramosrangoList;
	}

}
