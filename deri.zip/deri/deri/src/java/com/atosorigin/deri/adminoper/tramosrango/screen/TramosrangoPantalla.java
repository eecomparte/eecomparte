package com.atosorigin.deri.adminoper.tramosrango.screen;

import org.jboss.seam.ScopeType;
import org.jboss.seam.annotations.Name;
import org.jboss.seam.annotations.Scope;

@Name("tramosrangoPantalla")
@Scope(ScopeType.CONVERSATION)
public class TramosrangoPantalla {

	// oO[Variables]Oo
	protected Long numFilas = 0L;

	// oO[Getters y Setters]Oo
	public Long getNumFilas() {
		return numFilas;
	}

	public void setNumFilas(Long numFilas) {
		this.numFilas = numFilas;
	}
	
}
