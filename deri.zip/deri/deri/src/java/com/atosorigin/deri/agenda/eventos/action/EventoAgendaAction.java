package com.atosorigin.deri.agenda.eventos.action;

import java.math.BigDecimal;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import org.jboss.seam.ScopeType;
import org.jboss.seam.annotations.In;
import org.jboss.seam.annotations.Name;
import org.jboss.seam.annotations.Out;
import org.jboss.seam.annotations.Scope;
import org.jboss.seam.international.StatusMessage.Severity;
import org.jboss.seam.security.Identity;

import com.atosorigin.common.action.PaginatedListAction;
import com.atosorigin.common.constantes.Constantes;
import com.atosorigin.common.formvalidator.FormValidator;
import com.atosorigin.common.utils.GenericUtils;
import com.atosorigin.deri.agenda.aviso.business.EventosAgendaBo;
import com.atosorigin.deri.agenda.eventos.screen.EventoAgendaPantalla;
import com.atosorigin.deri.common.dbLock.DbLockService;
import com.atosorigin.deri.common.parametrosPantalla.ParametrosAvisoAgenda;
import com.atosorigin.deri.common.parametrosPantalla.ParametrosMantoper;
import com.atosorigin.deri.common.parametrosPantalla.ParametrosOutAgenda;
import com.atosorigin.deri.model.agenda.EventoAgenda;
import com.atosorigin.deri.model.kondor.ControlDeri;
import com.atosorigin.deri.model.liquidaciones.VistaLiquidacion;

/**
 * Clase que actúa de action listener para el caso de uso de agenda de eventos .
 */
@Name("eventoAgendaAction")
@Scope(ScopeType.CONVERSATION)
@FormValidator
public class EventoAgendaAction extends PaginatedListAction{

		
	/**
	 * Inyección del bean de Spring "avisoBo" que contiene los métodos de negocio
	 * para el caso de uso mantenimiento de avisos.
	 */
	@In("#{eventosAgendaBo}")
	protected EventosAgendaBo eventosAgendaBo;

	/**
	 * Inyección del screen bean que contiene los datos de pantalla del caso de uso
	 * mantenimiento de agenda eventos.
	 */
	@In(create=true)
	protected EventoAgendaPantalla eventoAgendaPantalla;
	
	/** Inyección del servicio que gestiona los bloqueos de registros en base de datos */
	@In(create = true)
	protected DbLockService dbLockService;	
	
	private Date fechaMisAgenda;
	
	private Date fechaTraAgenda;
	
	private boolean pendiente;
	
	private boolean eventoIsAccion;
	
	private boolean yaAdelantado = false;
	
	@Out(required = false, value="parametrosMantOper") //Parametros para MantOper
	private ParametrosMantoper parametrosMantOper;
	
	@Out(required = false, value="parametrosOutAgenda") //Parametros para llamar al resto de las pantallas
	private ParametrosOutAgenda parametrosOutAgenda;
	
	@Out(required = false, value="eventoSeleccionat") //Parametros para llamar a listaAvisos
	private ParametrosAvisoAgenda parametrosAvisoAgenda;
		
	@Out(required=false, value="idContrapartidaAnonimizar")
	private String idContrapartida; 
	
	public void precargar(){
		paginationData.reset();		
		setPrimerAcceso(false);
		
		
		eventoAgendaPantalla.setPendientes(true);
		obtenerFechaSistema();	
		if (eventoAgendaPantalla.getTiempore()==Constantes.EVENTO_TIEMPORE_2030)
			setYaAdelantado(false);
		else
			setYaAdelantado(true);
		tratamientoBuscar();
	}

	public void obtenerFechaSistema(){
		int tiempore = 0;
		String fechaParada = null;
		SimpleDateFormat sdf = new SimpleDateFormat(Constantes.DDMMYYYY);
		Date fechaMis = eventosAgendaBo.getFechamis();
		setFechaMisAgenda(fechaMis);
		setFechaTraAgenda(fechaMis);	
		eventoAgendaPantalla.setFechaEvento(fechaMis);
		tiempore = eventosAgendaBo.getTiempore();
		eventoAgendaPantalla.setTiempore(tiempore);
		fechaParada = sdf.format(fechaMis)+" "+tiempore/100+":"+tiempore % 100+":00"; 
		eventoAgendaPantalla.setFechaParada(fechaParada);
	}

	
	public void tratamientoBuscar() {
		actualizarPaseAgenda();
		buscar();		
	}
	
	public void actualizarPaseAgenda(){
		float diferencia = 0;
		int limiteInferior = eventosAgendaBo.getLimiteInferior();
		Date fechaModificacion = eventosAgendaBo.getFechaModificacion();
		SimpleDateFormat sdf = new SimpleDateFormat(Constantes.DDMMYYYYHHMMSS);
		eventoAgendaPantalla.setUltimoPase(sdf.format(fechaModificacion));
		
		/**
		 * SMM 11/06/2014 Comprobar TiempoRE
		 * 
		 */
		SimpleDateFormat sdf2 = new SimpleDateFormat(Constantes.DDMMYYYY);	
		Integer horaFinal= eventosAgendaBo.getTiempore();
		String tiempoFinal = sdf2.format(new Date()).toString();
		String horaFeliz = GenericUtils.lpad(horaFinal.toString(), 4,"0");
		tiempoFinal = tiempoFinal.concat(" ").concat(horaFeliz.substring(0, 2)).concat(":").concat(horaFeliz.substring(2, 4)).concat(":00");
		
		if (!eventosAgendaBo.horaParada(tiempoFinal)) {
			eventoAgendaPantalla.setFaltaMMSS(Constantes.STOP);
			return;
		}
		/**
		 * SMM 11/06/2014 FIN Comprobar TiempoRE
		 * 
		 */
		
		
		
		if (!GenericUtils.isNullOrBlank(fechaModificacion)){
			
			diferencia = Math.abs(eventosAgendaBo.calculaDiferencia(limiteInferior, fechaModificacion));
			if (diferencia >(limiteInferior*60*5)){
				eventoAgendaPantalla.setFaltaMMSS(Constantes.STOP);
			}else if (diferencia<5){
				eventoAgendaPantalla.setFaltaMMSS("----");
			}else{
				float numero = Math.round(diferencia)/60;
				int numeroInt = (new Float(numero)).intValue();
				String faltaMMSS = null;
				if (numeroInt == 0){
					faltaMMSS = "00:"+GenericUtils.lpad(diferencia+"", 2, '0');					
				}else{
					float resta = diferencia - (numeroInt*60);
					faltaMMSS = GenericUtils.lpad(numeroInt+"", 2, '0')+":"+GenericUtils.lpad(resta+"", 2, '0');
				}
				eventoAgendaPantalla.setFaltaMMSS(faltaMMSS);
			}
		}
	}
	/**
	 * Actualiza la lista del grid de eventos
	 * 
	 */
	public void buscar() {
		paginationData.reset();	
		setPrimerAcceso(false);
		refrescarLista();		
	}
	
	/**
	 * Actualiza la lista del grid de eventos
	 * 
	 */
	public boolean buscarValidator() {
		String operDesde = eventoAgendaPantalla.getNumOperDesde();
		String operHasta = eventoAgendaPantalla.getNumOperHasta();
		
		if(!GenericUtils.isNullOrBlank(operDesde) && !GenericUtils.isNullOrBlank(operHasta)) {
			try {
				BigDecimal numOperDesde = new BigDecimal(operDesde);
				BigDecimal numOperHasta = new BigDecimal(operHasta);
				if(numOperDesde.intValue() > numOperHasta.intValue()) {
					// Mostrar error
					statusMessages.add(Severity.ERROR, "#{messages['evento.numOperacionDesde.error']}");
					return false;
				}
			} catch(NumberFormatException e) {
				// Mostrar error
				statusMessages.add(Severity.ERROR, "#{messages['evento.numOperacion.error']}");
				return false;
			}
		}
		return true;
	}
	
	//Métodos necesarios para pantallas con grids.
	//Es necesario implementar estos métodos abstractos de PaginatedListAction
	@Override
	public List<EventoAgenda> getDataTableList() {
		return eventoAgendaPantalla.getEventoList();
	}

	@Override
	@SuppressWarnings("unchecked")
	public void setDataTableList(List<?> dataTableList) {
		eventoAgendaPantalla.setEventoList((List<EventoAgenda>)dataTableList);
	}

	@Override
	protected void refreshListInternal() {
		setExportExcel(false);		
		paginationData.setMaxResults(Constantes.MAX_ROWSAGENDA);
		String prod = eventoAgendaPantalla.getProductoSelected()!=null?eventoAgendaPantalla.getProductoSelected().getId():null;
		String accAvi = eventoAgendaPantalla.getDescrAccAviSelected()!=null?eventoAgendaPantalla.getDescrAccAviSelected().getCodigo():null;
		String numOperDesde = GenericUtils.isNullOrBlank(eventoAgendaPantalla.getNumOperDesde())?null:eventoAgendaPantalla.getNumOperDesde();
		String numOperHasta = GenericUtils.isNullOrBlank(eventoAgendaPantalla.getNumOperHasta())?null:eventoAgendaPantalla.getNumOperHasta();

		List<EventoAgenda> eventoAgendaList = eventosAgendaBo.busqueda(getFechaTraAgenda(), getFechaMisAgenda(), 
				prod, accAvi, numOperDesde, numOperHasta,
				eventoAgendaPantalla.getFechaEvento(), eventoAgendaPantalla.isPendientes()?"P":"N", paginationData);

		log.info("getFechaTraAgenda()::" + getFechaTraAgenda()
				+ " getFechaMisAgenda()::" + getFechaMisAgenda() + " prod::"
				+ prod + " accAvi::" + accAvi + " numOperDesde::"
				+ numOperDesde + " numOperHasta::" + numOperHasta
				+ " eventoAgendaPantalla.getFechaEvento()::"
				+ eventoAgendaPantalla.getFechaEvento()
				+ " eventoAgendaPantalla.isPendientes()::"
				+ eventoAgendaPantalla.isPendientes());

		eventoAgendaPantalla.setEventoList(eventoAgendaList);
		if ( parametrosAvisoAgenda!=null && "RECARGAR".equals(parametrosAvisoAgenda.getModo())){
			parametrosAvisoAgenda.setModo(Constantes.MODO_AGE);
		}
	}

	/**
	 * Devuelve "Sí" o "No" en función de si el evento tiene registros pendientes
	 * @param eventoAgenda
	 * @return
	 */
	public String obtenerPendiente(EventoAgenda eventoAgenda){
		//Si true, contiene 'P'
		if (eventoAgendaPantalla.isPendientes()){
			setPendiente(true);
			return Constantes.EVENTO_PDTE_Si;			
		}else{
			int numReg = eventosAgendaBo.obtenerNumeroRegistros(eventoAgenda);
			if (numReg == eventoAgenda.getNumeroRegistros()){
				setPendiente(false);
				return Constantes.EVENTO_PDTE_No;
			}else{
				setPendiente(true);
				return Constantes.EVENTO_PDTE_Si;
			}
		}		
	}
	
	/**
	 * Devuelve la descripción del Evento
	 * @param eventoAgenda
	 * @return
	 */
	public String obtenerDescrEvento(EventoAgenda eventoAgenda){		
		if (!GenericUtils.isNullOrBlank(eventoAgenda.getCodigoAviso())){
			return eventosAgendaBo.getDescripcionAviso(eventoAgenda.getCodigoAviso());
		}else if (!GenericUtils.isNullOrBlank(eventoAgenda.getCodigoEvento())){
			if (eventoAgenda.getCodigoEvento().equals(Constantes.EVENTO_3610) 
					||eventoAgenda.getCodigoEvento().equals(Constantes.EVENTO_3611)
					||eventoAgenda.getCodigoEvento().equals(Constantes.EVENTO_3612)					
					||eventoAgenda.getCodigoEvento().equals(Constantes.EVENTO_3772)
					||eventoAgenda.getCodigoEvento().equals(Constantes.EVENTO_3774)
					||eventoAgenda.getCodigoEvento().equals(Constantes.EVENTO_3776)){
				return eventoAgenda.getDatos();
			}else if (eventoAgenda.getCodigoEvento().equals(Constantes.EVENTO_4013) ){
				return eventosAgendaBo.getDescripcionAccion(eventoAgenda.getCodigoEvento()).concat(" ").concat(eventoAgenda.getDatos().substring(0,19));
			}else if (eventoAgenda.getCodigoEvento().equals(Constantes.EVENTO_2004) ){
				return eventosAgendaBo.getDescripcionAccion(eventoAgenda.getCodigoEvento()).concat(" ").concat(eventoAgenda.getDatos());
			}else{
				return eventosAgendaBo.getDescripcionAccion(eventoAgenda.getCodigoEvento());
			}
		}else{
			return eventoAgenda.getAgrupacion().getDescripcion();
		}
	}	
	
	public void desplegar(){
		int indiceActual = getDataTableList().indexOf(eventoAgendaPantalla.getEventoSelected());
		getDataTableList().addAll(indiceActual+1, eventoAgendaPantalla.getEventoSelected().getEventosAsociados());
		eventoAgendaPantalla.getEventoSelected().setDisplayed(false);
	}
	
	public void replegar(){
		getDataTableList().removeAll(eventoAgendaPantalla.getEventoSelected().getEventosAsociados());
		eventoAgendaPantalla.getEventoSelected().setDisplayed(true);
	}
	
	/**
	 * Devuelve "Aviso" o "Acción" en función del tipo de Evento 
	 * @param eventoAgenda
	 * @return
	 */
	public String obtenerTipoEvento(EventoAgenda eventoAgenda){	
		
		if(eventoAgenda.getHeader()) return Constantes.EVENTO_TIPO_AGRUPADO;
		
		if (eventoAgenda.getCodigoEvento().toString().startsWith(Constantes.EVENTO_37) 
			|| eventoAgenda.getCodigoEvento().toString().startsWith(Constantes.EVENTO_71)
			|| eventoAgenda.getCodigoEvento().toString().startsWith(Constantes.EVENTO_72)){
			setEventoIsAccion(false);
			return Constantes.EVENTO_TIPO_AVISO;
		}else{
			setEventoIsAccion(true);
			return Constantes.EVENTO_TIPO_ACCION;
		}		
	}	
	
//	@javax.annotation.PostConstruct
	public boolean mostrarRevisar(EventoAgenda eventoAgenda){
	//Pendiente y no es ACCION
		return (Constantes.EVENTO_PDTE_Si.equalsIgnoreCase(obtenerPendiente(eventoAgenda)) 
				&& (eventoAgenda.getCodigoEvento().toString().startsWith(Constantes.EVENTO_37)
					|| eventoAgenda.getCodigoEvento().toString().startsWith(Constantes.EVENTO_71)
					|| eventoAgenda.getCodigoEvento().toString().startsWith(Constantes.EVENTO_72)));
	}
	
	/**
	 * Prepara para entrar en el modo inspección de un evento.
	 * 
	 */
	public void seleccionar() {
		String codPantalla = null;
		if (!GenericUtils.isNullOrBlank(eventoAgendaPantalla.getEventoSelected().getCodigoEvento()))
			codPantalla = eventosAgendaBo.getCodigoPantalla(eventoAgendaPantalla.getEventoSelected().getCodigoEvento().toString());
		if (GenericUtils.isNullOrBlank(codPantalla)){
			statusMessages.add(Severity.ERROR, "#{messages['evento.pantalla.error']}");
			return;
		}
		
		
		if (Short.valueOf("3501").equals(eventoAgendaPantalla.getEventoSelected().getCodigoEvento()) ||
			Short.valueOf("3504").equals(eventoAgendaPantalla.getEventoSelected().getCodigoEvento()) ||
			Short.valueOf("2015").equals(eventoAgendaPantalla.getEventoSelected().getCodigoEvento()) ||
			Short.valueOf("2915").equals(eventoAgendaPantalla.getEventoSelected().getCodigoEvento())){
				eventoAgendaPantalla.setEstindic("PI");
		}else 
//			  if (Short.valueOf("3505").equals(eventoAgendaPantalla.getEventoSelected().getCodigoEvento()) ||
//				  Short.valueOf("2501").equals(eventoAgendaPantalla.getEventoSelected().getCodigoEvento()) ||
//				  Short.valueOf("2016").equals(eventoAgendaPantalla.getEventoSelected().getCodigoEvento()) ||
//				  Short.valueOf("2916").equals(eventoAgendaPantalla.getEventoSelected().getCodigoEvento()))
			  {
						eventoAgendaPantalla.setEstindic("PV");
				}
		
		if(eventoAgendaPantalla.getEventoSelected().getDatos()!= null &&
				Short.valueOf("4013").equals(eventoAgendaPantalla.getEventoSelected().getCodigoEvento())){
			this.idContrapartida = eventoAgendaPantalla.getEventoSelected().getDatos().substring(0,19).trim();
		}
		
		if (eventoAgendaPantalla.getEventoSelected().getDatos()!= null &&
				!Short.valueOf("2004").equals(eventoAgendaPantalla.getEventoSelected().getCodigoEvento()) && !Short.valueOf("4013").equals(eventoAgendaPantalla.getEventoSelected().getCodigoEvento())) {
		eventoAgendaPantalla.setFechaPro(eventoAgendaPantalla.getEventoSelected().getDatos().substring(51, 61));
		eventoAgendaPantalla.setFecInsfo(eventoAgendaPantalla.getEventoSelected().getDatos().substring(21, 31));
		}
		eventoAgendaPantalla.setEstructuraId(eventosAgendaBo.recuperarEstructura(eventoAgendaPantalla.getEventoSelected().getCodigoEvento(), 
				eventoAgendaPantalla.getEventoSelected().getCodigoAviso()));
		
		// Ha quedado en desuso, FECHATRA_IN y FECHATRA_FIN
		//eventoAgendaPantalla.setFechaTraIni(eventoAgendaPantalla.getFechaEvento());
		eventoAgendaPantalla.setFechaTraIni(getFechaTraAgenda());
		eventoAgendaPantalla.setProducto(eventoAgendaPantalla.getProductoSelected());
		eventoAgendaPantalla.setNumOperIni(eventoAgendaPantalla.getNumOperDesde());
		eventoAgendaPantalla.setNumOperFin(eventoAgendaPantalla.getNumOperHasta());
		eventoAgendaPantalla.setEstadoAgenda(eventoAgendaPantalla.isPendientes()); 
		eventoAgendaPantalla.setEventoSelectAgenda(eventoAgendaPantalla.getEventoSelected());  
		if(codPantalla.equals(Constantes.PANT_MANTOPER)){
			parametrosMantOper =  new ParametrosMantoper();
			parametrosMantOper.setCodevent(eventoAgendaPantalla.getEventoSelected().getCodigoEvento().longValue());
			parametrosMantOper.setProducto(eventoAgendaPantalla.getProducto());
			try{
				if(eventoAgendaPantalla.getNumOperIni() != null){
					parametrosMantOper.setNcorrelaIni(Long.parseLong(eventoAgendaPantalla.getNumOperIni()));
				}					
			} catch (NumberFormatException e) { }
			try{
				if(eventoAgendaPantalla.getNumOperDesde() != null){
					parametrosMantOper.setNcorrelaFin(Long.parseLong(eventoAgendaPantalla.getNumOperDesde()));
				}					
			} catch (NumberFormatException e) { }
			parametrosMantOper.setEstadoev(GenericUtils.PNBoolean(eventoAgendaPantalla.isPendientes()));
			parametrosMantOper.setFechatra(getFechaTraAgenda());
			
			if (Short.valueOf("2004").equals(eventoAgendaPantalla.getEventoSelected().getCodigoEvento())) {
				parametrosMantOper.setTipoBarrera(eventoAgendaPantalla.getEventoSelected().getDatos());	
			}
			
			parametrosMantOper.setModo(Constantes.MODO_AGE);
		}else if (codPantalla.equals(Constantes.PANT_OPEPROLI) 
				|| codPantalla.equals(Constantes.PANT_MANTIPIN)				
				|| codPantalla.equals(Constantes.PANT_MANCONTR)){
			parametrosOutAgenda = new ParametrosOutAgenda();			
			parametrosOutAgenda.setCodevent(eventoAgendaPantalla.getEventoSelected().getCodigoEvento().longValue());
			/* SMM: acordado con Alfonso. Los parámetros modeloPr y FechaTraFin ya no se usan, 
			 * pero puesto que las select ya están codificadas, se procede a enviar modeloPr nulo, y fechaTraFin
			 * igual a fechaTraIni 
			 */ 
			parametrosOutAgenda.setModeloPr(null);
			parametrosOutAgenda.setProducto(eventoAgendaPantalla.getProducto());
			parametrosOutAgenda.setEstindic(eventoAgendaPantalla.getEstindic());
			try{
				if(eventoAgendaPantalla.getNumOperIni() != null){
					parametrosOutAgenda.setNcorrelaIni(Long.parseLong(eventoAgendaPantalla.getNumOperIni()));
				}					
			} catch (NumberFormatException e) { }
			try{
				if(eventoAgendaPantalla.getNumOperDesde() != null){
					parametrosOutAgenda.setNcorrelaFin(Long.parseLong(eventoAgendaPantalla.getNumOperDesde()));
				}					
			} catch (NumberFormatException e) { }

			parametrosOutAgenda.setFechatraIni(getFechaTraAgenda());
			parametrosOutAgenda.setFechatraFin(getFechaTraAgenda());		
			parametrosOutAgenda.setEstadoEv(GenericUtils.PNBoolean(eventoAgendaPantalla.isPendientes()));
			parametrosOutAgenda.setModo(Constantes.MODO_AGE);
		} else if(codPantalla.equals(Constantes.PANT_MANTESTR) || codPantalla.equals(Constantes.PANT_ERRINTMX)){
			/* Inc. 1484 --> Agenda hacía Mant. Prod. Compuestos */
			parametrosOutAgenda = new ParametrosOutAgenda();			
			parametrosOutAgenda.setCodevent(eventoAgendaPantalla.getEventoSelected().getCodigoEvento().longValue());
			parametrosOutAgenda.setEstadoEv(GenericUtils.PNBoolean(eventoAgendaPantalla.isPendientes()));
			parametrosOutAgenda.setModo(Constantes.MODO_AGE);
			parametrosOutAgenda.setFechatraIni(getFechaTraAgenda());
			parametrosOutAgenda.setFechatraFin(getFechaTraAgenda());
		}
		redirect(codPantalla);
	}
	
	public void seleccionAviso() {				
		parametrosAvisoAgenda = new ParametrosAvisoAgenda();
		if (!GenericUtils.isNullOrBlank(eventoAgendaPantalla.getEventoSelected())){
			parametrosAvisoAgenda.setEventoAgenda(eventoAgendaPantalla.getEventoSelected());
			parametrosAvisoAgenda.setCodevent(eventoAgendaPantalla.getEventoSelected().getCodigoEvento().longValue());
		}
		
		parametrosAvisoAgenda.setEstadoEv(GenericUtils.PNBoolean(eventoAgendaPantalla.isPendientes()));
		parametrosAvisoAgenda.setModo(Constantes.MODO_AGE);
		parametrosAvisoAgenda.setFechatraIni(getFechaTraAgenda());
		parametrosAvisoAgenda.setFechatraFin(getFechaTraAgenda());

		try{
			if(eventoAgendaPantalla.getNumOperIni() != null){
				parametrosAvisoAgenda.setNcorrelaIni(Long.parseLong(eventoAgendaPantalla.getNumOperIni()));
			}					
		} catch (NumberFormatException e) { }
		try{
			if(eventoAgendaPantalla.getNumOperDesde() != null){
				parametrosAvisoAgenda.setNcorrelaFin(Long.parseLong(eventoAgendaPantalla.getNumOperDesde()));
			}					
		} catch (NumberFormatException e) { }

		parametrosAvisoAgenda.setProducto(eventoAgendaPantalla.getProducto());
		parametrosAvisoAgenda.setEstindic(eventoAgendaPantalla.getEstindic());
		
	}
	
	public void revisar() {				
		if (GenericUtils.in(eventoAgendaPantalla.getEventoSelected().getCodigoEvento(),Constantes.EVENTO_3772,Constantes.EVENTO_3774,Constantes.EVENTO_3776)) {
			eventosAgendaBo.updateAgenda(eventoAgendaPantalla.getEventoSelected().getCodigoEvento(), eventoAgendaPantalla.getEventoSelected().getDatos(), Identity.instance().getCredentials().getUsername());	
		}else{
			eventosAgendaBo.updateAgenda(eventoAgendaPantalla.getEventoSelected().getCodigoEvento(),  Identity.instance().getCredentials().getUsername());
		}
		refrescarLista();
	}
	
	public void modificarFechaParada(){
				
		SimpleDateFormat sdf = new SimpleDateFormat(Constantes.DDMMYYYYHHMMSS);
		Date hoy = new Date();

		if(dbLockService.bloqueo(ControlDeri.class, Constantes.NOMBRE_PROYECTO_DERI)){			
				
			String tiemporeCalculado = eventosAgendaBo.calculaTiempore();
			String fechaParadaCalculada = eventosAgendaBo.calculaFechaParada();
			String minParada = eventosAgendaBo.calculaMinParada();
			
			if (eventoAgendaPantalla.getTiempore()==Constantes.EVENTO_TIEMPORE_2030){
				
				Date minParadaDate =null;
				try {
					minParadaDate = sdf.parse(minParada);
				} catch (ParseException e) {
					e.printStackTrace();
				}
				if (hoy.before(minParadaDate)){					
					tiemporeCalculado = Constantes.EVENTO_1800;
					fechaParadaCalculada = minParada;
				}
				updateAuditorControla(tiemporeCalculado,fechaParadaCalculada);	
				setYaAdelantado(true);			
			}else{
				Date fechaParadaDate = null;
				try {
					fechaParadaDate = sdf.parse(eventoAgendaPantalla.getFechaParada());
				} catch (ParseException e) {					
					e.printStackTrace();
				}
				if (GenericUtils.isNullOrBlank(fechaParadaDate) 
						&& (hoy.after(fechaParadaDate) || hoy.equals(fechaParadaDate))){
					statusMessages.add(Severity.ERROR, "#{messages['evento.parada.error']}");					
				}else{
					tiemporeCalculado = Integer.toString(Constantes.EVENTO_TIEMPORE_2030);
					sdf.applyLocalizedPattern(Constantes.DDMMYYYY);					
					fechaParadaCalculada = sdf.format(hoy)+" " + "20:30:00";
					updateAuditorControla(tiemporeCalculado,fechaParadaCalculada);
					setYaAdelantado(false);
				}				
			}
			dbLockService.desbloqueo(ControlDeri.class, Constantes.NOMBRE_PROYECTO_DERI);
		}
	}
	
	public void updateAuditorControla(String tiempore, String fechaParada){
		eventosAgendaBo.updateAuditor(tiempore);
		eventoAgendaPantalla.setFechaParada(fechaParada);
		eventoAgendaPantalla.setTiempore(Integer.parseInt(tiempore));
	}
	
	@Override
	public void refrescarListaExcel() { 
		setExportExcel(true);	
		String prod = eventoAgendaPantalla.getProductoSelected()!=null?eventoAgendaPantalla.getProductoSelected().getId():null;
		String accAvi = eventoAgendaPantalla.getDescrAccAviSelected()!=null?eventoAgendaPantalla.getDescrAccAviSelected().getCodigo():null;
		String numOperDesde = GenericUtils.isNullOrBlank(eventoAgendaPantalla.getNumOperDesde())?null:eventoAgendaPantalla.getNumOperDesde();
		String numOperHasta = GenericUtils.isNullOrBlank(eventoAgendaPantalla.getNumOperHasta())?null:eventoAgendaPantalla.getNumOperHasta();
		
		List<EventoAgenda> eventoAgendaList = eventosAgendaBo.busqueda(getFechaTraAgenda(), getFechaMisAgenda(), 
				prod, accAvi, numOperDesde, numOperHasta,
				eventoAgendaPantalla.getFechaEvento(), eventoAgendaPantalla.isPendientes()?"P":"N", paginationData.getPaginationDataForExcel());

		eventoAgendaPantalla.setEventoList(eventoAgendaList);	
		
	}

	public Date getFechaMisAgenda() {
		return fechaMisAgenda;
	}

	public Date getFechaTraAgenda() {
		return fechaTraAgenda;
	}

	public void setFechaMisAgenda(Date fechaMisAgenda) {
		this.fechaMisAgenda = fechaMisAgenda;
	}

	public void setFechaTraAgenda(Date fechaTraAgenda) {
		this.fechaTraAgenda = fechaTraAgenda;
	}

	public boolean isPendiente() {
		return pendiente;
	}

	public boolean isEventoIsAccion() {
		return eventoIsAccion;
	}

	public void setPendiente(boolean pendiente) {
		this.pendiente = pendiente;
	}

	public void setEventoIsAccion(boolean eventoIsAccion) {
		this.eventoIsAccion = eventoIsAccion;
	}

	public boolean isYaAdelantado() {
		return yaAdelantado;
	}

	public void setYaAdelantado(boolean yaAdelantado) {
		this.yaAdelantado = yaAdelantado;
	}
	
	public boolean isAviso(EventoAgenda eventoAgenda){
		return (eventoAgenda.getCodigoEvento().toString().startsWith(Constantes.EVENTO_37)
				|| eventoAgenda.getCodigoEvento().toString().startsWith(Constantes.EVENTO_71)
				|| eventoAgenda.getCodigoEvento().toString().startsWith(Constantes.EVENTO_72));
	}

	public ParametrosAvisoAgenda getParametrosAvisoAgenda() {
		return parametrosAvisoAgenda;
	}

	public void setParametrosAvisoAgenda(ParametrosAvisoAgenda parametrosAvisoAgenda) {
		this.parametrosAvisoAgenda = parametrosAvisoAgenda;
	}


	public String getRowClasses(){
		StringBuilder builder = new StringBuilder();
		int i=0;
		for (EventoAgenda evento : eventoAgendaPantalla.getEventoList()) {
			if(i>0){
				builder.append(",");
			}
			
			if (evento.getHeader()){
				builder.append("resaltarRow");	
			}else {
				if(i%2==0){
					builder.append("oddRow");
				}
				else{
					builder.append("evenRow");
				}
			}
			i++;
		}
		return builder.toString();
	}
	


}
