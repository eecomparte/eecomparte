package com.atosorigin.deri.agenda.eventos.action;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashSet;
import java.util.List;

import org.jboss.seam.ScopeType;
import org.jboss.seam.annotations.In;
import org.jboss.seam.annotations.Name;
import org.jboss.seam.annotations.Out;
import org.jboss.seam.annotations.Scope;
import org.jboss.seam.international.StatusMessage.Severity;
import org.jboss.seam.security.Identity;

import com.atosorigin.common.action.PaginatedListAction;
import com.atosorigin.common.constantes.Constantes;
import com.atosorigin.common.formvalidator.FormValidator;
import com.atosorigin.common.utils.GenericUtils;
import com.atosorigin.deri.agenda.aviso.business.EventosAgendaBo;
import com.atosorigin.deri.agenda.eventos.screen.ListaAvisosPantalla;
import com.atosorigin.deri.common.dbLock.DbLockService;
import com.atosorigin.deri.common.parametrosPantalla.ParametrosAvisoAgenda;
import com.atosorigin.deri.common.parametrosPantalla.ParametrosMantoper;
import com.atosorigin.deri.common.parametrosPantalla.ParametrosOutAgenda;
import com.atosorigin.deri.model.agenda.EventoAgenda;
import com.atosorigin.deri.model.agenda.ListaAviso;

/**
 * Clase que actúa de action listener para el caso de uso de agenda de eventos .
 */
@Name("listaAvisosAction")
@Scope(ScopeType.CONVERSATION)
@FormValidator
public class ListaAvisosAction extends PaginatedListAction{

		
	/**
	 * Inyección del bean de Spring "avisoBo" que contiene los métodos de negocio
	 * para el caso de uso mantenimiento de avisos.
	 */
	@In("#{eventosAgendaBo}")
	protected EventosAgendaBo eventosAgendaBo;

	/**
	 * Inyección del screen bean que contiene los datos de pantalla del caso de uso
	 * mantenimiento de agenda eventos.
	 */
	@In(create=true)
	protected ListaAvisosPantalla listaAvisosPantalla;
	
	/** Inyección del servicio que gestiona los bloqueos de registros en base de datos */
	@In(create = true)
	protected DbLockService dbLockService;	
	
	private Date fechaMisAgenda;
	
	private Date fechaTraAgenda;
	
	private boolean pendiente;
	
	private boolean eventoIsAccion;
	
	private boolean yaAdelantado = false;

	private HashSet<ListaAviso> listasSeleccionadas = new HashSet<ListaAviso>();
	private int maxSelected;
	
	@Out(required = false, value="parametrosMantOper") //Parametros para MantOper
	private ParametrosMantoper parametrosMantOper;
	
	@Out(required = false, value="parametrosOutAgenda") //Parametros para llamar al resto de las pantallas
	private ParametrosOutAgenda parametrosOutAgenda;
	
	@In(required = false, value = "eventoSeleccionat")
	@Out
	private ParametrosAvisoAgenda parametrosAvisoAgenda;
	
	
		
	public void precargar(){
		paginationData.reset();		
		setPrimerAcceso(false);
		refrescarLista();
	}

	public void obtenerFechaSistema(){
		int tiempore = 0;
		String fechaParada = null;
		SimpleDateFormat sdf = new SimpleDateFormat(Constantes.DDMMYYYY);
		Date fechaMis = eventosAgendaBo.getFechamis();
		setFechaMisAgenda(fechaMis);
		setFechaTraAgenda(fechaMis);	
		tiempore = eventosAgendaBo.getTiempore();
		fechaParada = sdf.format(fechaMis)+" "+tiempore/100+":"+tiempore % 100+":00"; 
	}

	
	public void tratamientoBuscar() {
		actualizarPaseAgenda();
		buscar();		
	}
	
	public void actualizarPaseAgenda(){
		float diferencia = 0;
		int limiteInferior = eventosAgendaBo.getLimiteInferior();
		Date fechaModificacion = eventosAgendaBo.getFechaModificacion();
		SimpleDateFormat sdf = new SimpleDateFormat(Constantes.DDMMYYYYHHMMSS);
		
		if (!GenericUtils.isNullOrBlank(fechaModificacion)){
			
			diferencia = Math.abs(eventosAgendaBo.calculaDiferencia(limiteInferior, fechaModificacion));
			if (diferencia >(limiteInferior*60*5)){
			}else if (diferencia<5){
			}else{
				float numero = Math.round(diferencia)/60;
				int numeroInt = (new Float(numero)).intValue();
				String faltaMMSS = null;
				if (numeroInt == 0){
					faltaMMSS = "00:"+GenericUtils.lpad(diferencia+"", 2, '0');					
				}else{
					float resta = diferencia - (numeroInt*60);
					faltaMMSS = GenericUtils.lpad(numeroInt+"", 2, '0')+":"+GenericUtils.lpad(resta+"", 2, '0');
				}
			}
		}
	}
	/**
	 * Actualiza la lista del grid de eventos
	 * 
	 */
	public void buscar() {
		paginationData.reset();	
		setPrimerAcceso(false);
		refrescarLista();		
	}
	
	/**
	 * Actualiza la lista del grid de eventos
	 * 
	 */
	public boolean buscarValidator() {

		return true;
	}
	
	//Métodos necesarios para pantallas con grids.
	//Es necesario implementar estos métodos abstractos de PaginatedListAction
	@Override
	public List<ListaAviso> getDataTableList() {
		return listaAvisosPantalla.getAvisosList();
	}

	@Override
	@SuppressWarnings("unchecked")
	public void setDataTableList(List<?> dataTableList) {
		listaAvisosPantalla.setAvisosList((List<ListaAviso>)dataTableList);
	}

	@Override
	protected void refreshListInternal() {
		listasSeleccionadas.clear();
		if (GenericUtils.isNullOrBlank(parametrosAvisoAgenda)){
			return;
		}

		setExportExcel(false);		
		paginationData.setMaxResults(Constantes.MAX_ROWS);
		List<ListaAviso> listaAvisosList = new ArrayList<ListaAviso>();
//		eventoSeleccionat.getCodigoAviso(), eventoSeleccionat.
		/*
		 * 	private String modo;
	private String codcampa;
	private Long codevent;
	private Producto producto;
	private Long ncorrelaIni;
	private Long ncorrelaFin;
	private Date fechatra;
	private String estadoev;
	private Long numorden;
	private String tipoBarrera;
		 */
		
		
		Date fechaMis = eventosAgendaBo.getFechamis();
		String ncorrelaInicial = null;
		String ncorrelaFinal = null;
		if (parametrosAvisoAgenda.getNcorrelaIni()!=null){
			ncorrelaInicial = parametrosAvisoAgenda.getNcorrelaIni().toString();	
		}
		
		if (parametrosAvisoAgenda.getNcorrelaFin()!=null){
			ncorrelaFinal = parametrosAvisoAgenda.getNcorrelaFin().toString();	
		}
		
		
		listaAvisosList		= eventosAgendaBo.busquedaAviso(parametrosAvisoAgenda.getEventoAgenda(),
				fechaMis, fechaMis,parametrosAvisoAgenda.getProducto(), ncorrelaInicial, ncorrelaFinal, 
				parametrosAvisoAgenda.getEstadoEv(), paginationData);

				
				
		
		
		listaAvisosPantalla.setAvisosList(listaAvisosList);
	}

	
	
	
	protected List<ListaAviso>  prepareList() {
		if (GenericUtils.isNullOrBlank(parametrosAvisoAgenda)){
			return null;
		}

		List<ListaAviso> listaAvisosList = new ArrayList<ListaAviso>();
		Date fechaMis = eventosAgendaBo.getFechamis();
		String ncorrelaInicial = null;
		String ncorrelaFinal = null;
		if (parametrosAvisoAgenda.getNcorrelaIni()!=null){
			ncorrelaInicial = parametrosAvisoAgenda.getNcorrelaIni().toString();	
		}
		
		if (parametrosAvisoAgenda.getNcorrelaFin()!=null){
			ncorrelaFinal = parametrosAvisoAgenda.getNcorrelaFin().toString();	
		}
		
		
		listaAvisosList		= eventosAgendaBo.busquedaAviso(parametrosAvisoAgenda.getEventoAgenda(),
				fechaMis, fechaMis,parametrosAvisoAgenda.getProducto(), ncorrelaInicial, ncorrelaFinal, 
				parametrosAvisoAgenda.getEstadoEv(), paginationData);

					
		return listaAvisosList;
	}
	
	/**
	 * Devuelve "Sí" o "No" en función de si el evento tiene registros pendientes
	 * @param eventoAgenda
	 * @return
	 */
	public String obtenerPendiente(EventoAgenda eventoAgenda){
		//Si true, contiene 'P'
				return Constantes.EVENTO_PDTE_Si;
		}		
	
	/**
	 * Devuelve la descripción del Evento
	 * @param eventoAgenda
	 * @return
	 */
	public String obtenerDescrEvento(EventoAgenda eventoAgenda){		
		if (!GenericUtils.isNullOrBlank(eventoAgenda.getCodigoAviso())){
			return eventosAgendaBo.getDescripcionAviso(eventoAgenda.getCodigoAviso());
		}else{
			if (eventoAgenda.getCodigoEvento().equals(Constantes.EVENTO_3610) 
					||eventoAgenda.getCodigoEvento().equals(Constantes.EVENTO_3611)
					||eventoAgenda.getCodigoEvento().equals(Constantes.EVENTO_3612)					
					||eventoAgenda.getCodigoEvento().equals(Constantes.EVENTO_3772)
					||eventoAgenda.getCodigoEvento().equals(Constantes.EVENTO_3774)
					||eventoAgenda.getCodigoEvento().equals(Constantes.EVENTO_3776)){
				return eventoAgenda.getDatos();
			}else if (eventoAgenda.getCodigoEvento().equals(Constantes.EVENTO_2004) ){
				return eventosAgendaBo.getDescripcionAccion(eventoAgenda.getCodigoEvento()).concat(" ").concat(eventoAgenda.getDatos());
			}else{
				return eventosAgendaBo.getDescripcionAccion(eventoAgenda.getCodigoEvento());
			}
		}		
	}	
	
	/**
	 * Devuelve "Aviso" o "Acción" en función del tipo de Evento 
	 * @param eventoAgenda
	 * @return
	 */
	public String obtenerTipoEvento(EventoAgenda eventoAgenda){	
		
		if (eventoAgenda.getCodigoEvento().toString().startsWith(Constantes.EVENTO_37)
			|| eventoAgenda.getCodigoEvento().toString().startsWith(Constantes.EVENTO_71)
			|| eventoAgenda.getCodigoEvento().toString().startsWith(Constantes.EVENTO_72)){
			setEventoIsAccion(false);
			return Constantes.EVENTO_TIPO_AVISO;
		}else{
			setEventoIsAccion(true);
			return Constantes.EVENTO_TIPO_ACCION;
		}		
	}	
	
	public boolean mostrarRevisar(EventoAgenda eventoAgenda){
	//Pendiente y no es ACCION
		return (Constantes.EVENTO_PDTE_Si.equalsIgnoreCase(obtenerPendiente(eventoAgenda)) 
				&& (eventoAgenda.getCodigoEvento().toString().startsWith(Constantes.EVENTO_37)
					|| eventoAgenda.getCodigoEvento().toString().startsWith(Constantes.EVENTO_71)
					|| eventoAgenda.getCodigoEvento().toString().startsWith(Constantes.EVENTO_72)));
	}
	
	/**
	 * Prepara para entrar en el modo inspección de un evento.
	 * 
	 */
	public void seleccionar() {
		Date fechaMis = eventosAgendaBo.getFechamis();
		String codPantalla =  eventosAgendaBo.getCodigoPantalla(listaAvisosPantalla.getListaAvisoSelected().getCodigoEvento().toString());
		if (GenericUtils.isNullOrBlank(codPantalla)){
			statusMessages.add(Severity.ERROR, "#{messages['evento.pantalla.error']}");
			return;
		}

		if ("X".equalsIgnoreCase(listaAvisosPantalla.getListaAvisoSelected().getFlagDatos()) && listaAvisosPantalla.getListaAvisoSelected().getDatos()!= null) {
			listaAvisosPantalla.setFechaPro(listaAvisosPantalla.getListaAvisoSelected().getDatos().substring(51, 61));
			listaAvisosPantalla.setFecInsfo(listaAvisosPantalla.getListaAvisoSelected().getDatos().substring(21, 31));
		}
		listaAvisosPantalla.setEstructuraId(eventosAgendaBo.recuperarEstructura(listaAvisosPantalla.getListaAvisoSelected().getCodigoEvento(), 
				listaAvisosPantalla.getListaAvisoSelected().getCodigoAviso()));
		

		listaAvisosPantalla.setFechaTraIni(fechaMis);
		listaAvisosPantalla.setProducto(listaAvisosPantalla.getProductoSelected());
		listaAvisosPantalla.setNumOperIni(listaAvisosPantalla.getNumOperDesde());
		listaAvisosPantalla.setNumOperFin(listaAvisosPantalla.getNumOperHasta());
		listaAvisosPantalla.setEstadoAgenda(listaAvisosPantalla.isPendientes()); 
//SMM	Se mantiene comentado, pues muestra más informacion de la necesaria
//		en caso necesario ya se habilitara
		EventoAgenda eventoSelectAgenda = new EventoAgenda(listaAvisosPantalla.getListaAvisoSelected().getCodigoEvento(), 
				listaAvisosPantalla.getListaAvisoSelected().getCodigoAviso(), 1, listaAvisosPantalla.getListaAvisoSelected().getDatos(),null,null,null); 
		listaAvisosPantalla.setEventoSelectAgenda(eventoSelectAgenda);
		
		if(codPantalla.equals(Constantes.PANT_MANTOPER)){
			parametrosMantOper =  new ParametrosMantoper();
			parametrosMantOper.setCodevent(listaAvisosPantalla.getListaAvisoSelected().getCodigoEvento().longValue());
			parametrosMantOper.setProducto(listaAvisosPantalla.getProducto());
			
			if (listaAvisosPantalla.getListaAvisoSelected().getNumeroOperacion()!=null){
				parametrosMantOper.setNcorrelaIni(listaAvisosPantalla.getListaAvisoSelected().getNumeroOperacion());
				parametrosMantOper.setNcorrelaFin(listaAvisosPantalla.getListaAvisoSelected().getNumeroOperacion());
			}else{
			
					try{
						if(listaAvisosPantalla.getNumOperIni() != null){
							parametrosMantOper.setNcorrelaIni(Long.parseLong(listaAvisosPantalla.getNumOperIni()));
						}					
					} catch (NumberFormatException e) { }
					try{
						if(listaAvisosPantalla.getNumOperDesde() != null){
							parametrosMantOper.setNcorrelaFin(Long.parseLong(listaAvisosPantalla.getNumOperDesde()));
						}					
					} catch (NumberFormatException e) { }
					
			}
			parametrosMantOper.setEstadoev(parametrosAvisoAgenda.getEstadoEv());
			parametrosMantOper.setFechatra(fechaMis);
			
				
			parametrosMantOper.setModo(Constantes.MODO_AGE);
		}else if (codPantalla.equals(Constantes.PANT_OPEPROLI) 
				|| codPantalla.equals(Constantes.PANT_MANTIPIN)				
				|| codPantalla.equals(Constantes.PANT_MANCONTR)){
			parametrosOutAgenda = new ParametrosOutAgenda();			
			parametrosOutAgenda.setCodevent(listaAvisosPantalla.getListaAvisoSelected().getCodigoEvento().longValue());
			/* SMM: acordado con Alfonso. Los parámetros modeloPr y FechaTraFin ya no se usan, 
			 * pero puesto que las select ya están codificadas, se procede a enviar modeloPr nulo, y fechaTraFin
			 * igual a fechaTraIni 
			 */ 
			parametrosOutAgenda.setModeloPr(null);
			parametrosOutAgenda.setProducto(listaAvisosPantalla.getProducto());
			parametrosOutAgenda.setEstindic(listaAvisosPantalla.getEstindic());
			if (listaAvisosPantalla.getListaAvisoSelected().getNumeroOperacion()!=null){
				parametrosOutAgenda.setNcorrelaIni(listaAvisosPantalla.getListaAvisoSelected().getNumeroOperacion());
				parametrosOutAgenda.setNcorrelaFin(listaAvisosPantalla.getListaAvisoSelected().getNumeroOperacion());
			}else{
					try{
						if(listaAvisosPantalla.getNumOperIni() != null){
							parametrosOutAgenda.setNcorrelaIni(Long.parseLong(listaAvisosPantalla.getNumOperIni()));
						}					
					} catch (NumberFormatException e) { }
					try{
						if(listaAvisosPantalla.getNumOperDesde() != null){
							parametrosOutAgenda.setNcorrelaFin(Long.parseLong(listaAvisosPantalla.getNumOperDesde()));
						}					
					} catch (NumberFormatException e) { }
			}
			
			parametrosOutAgenda.setFechatraIni(fechaMis);
			parametrosOutAgenda.setFechatraFin(fechaMis);		
			parametrosOutAgenda.setEstadoEv(parametrosAvisoAgenda.getEstadoEv());
			parametrosOutAgenda.setModo(Constantes.MODO_AGE);
		} else if(codPantalla.equals(Constantes.PANT_MANTESTR) || codPantalla.equals(Constantes.PANT_ERRINTMX)){
			/* Inc. 1484 --> Agenda hacía Mant. Prod. Compuestos */
			parametrosOutAgenda = new ParametrosOutAgenda();			
			parametrosOutAgenda.setCodevent(listaAvisosPantalla.getListaAvisoSelected().getCodigoEvento().longValue());
			parametrosOutAgenda.setEstadoEv(parametrosAvisoAgenda.getEstadoEv());
			parametrosOutAgenda.setModo(Constantes.MODO_AGE);
			parametrosOutAgenda.setFechatraIni(fechaMis);
			parametrosOutAgenda.setFechatraFin(fechaMis);
		}
		redirect(codPantalla);
	}
	
	
	public void revisar() {				
		
		for (ListaAviso aviso : listasSeleccionadas) {
			String indtrata = "N";
			if (aviso.getCodigoEvento()==3507){
				indtrata = "S";
			}
			eventosAgendaBo.updateAgenda(aviso.getTratamiento(),aviso.getNumeradorEvento(), Identity.instance().getCredentials().getUsername(),indtrata);
		}		
		eventosAgendaBo.flush();
		refrescarLista();
	}
	
	@Override
	public void refrescarListaExcel() { 
		setExportExcel(true);	

		List<ListaAviso> listaAvisosList = new ArrayList<ListaAviso>();
		
		if (GenericUtils.isNullOrBlank(parametrosAvisoAgenda)){
			return;
		}

		paginationData.setMaxResults(Constantes.MAX_RESULTS_EXCEL);
		Date fechaMis = eventosAgendaBo.getFechamis();
		String ncorrelaInicial = null;
		String ncorrelaFinal = null;
		if (parametrosAvisoAgenda.getNcorrelaIni()!=null){
			ncorrelaInicial = parametrosAvisoAgenda.getNcorrelaIni().toString();	
		}
		
		if (parametrosAvisoAgenda.getNcorrelaFin()!=null){
			ncorrelaFinal = parametrosAvisoAgenda.getNcorrelaFin().toString();	
		}
		
		listaAvisosList		= eventosAgendaBo.busquedaAviso(parametrosAvisoAgenda.getEventoAgenda(),
				fechaMis, fechaMis,parametrosAvisoAgenda.getProducto(), ncorrelaInicial, ncorrelaFinal, 
				parametrosAvisoAgenda.getEstadoEv(), paginationData);

				
		
		listaAvisosPantalla.setAvisosList(listaAvisosList);
	}

	public Date getFechaMisAgenda() {
		return fechaMisAgenda;
	}

	public Date getFechaTraAgenda() {
		return fechaTraAgenda;
	}

	public void setFechaMisAgenda(Date fechaMisAgenda) {
		this.fechaMisAgenda = fechaMisAgenda;
	}

	public void setFechaTraAgenda(Date fechaTraAgenda) {
		this.fechaTraAgenda = fechaTraAgenda;
	}

	public boolean isPendiente() {
		return pendiente;
	}

	public boolean isEventoIsAccion() {
		return eventoIsAccion;
	}

	public void setPendiente(boolean pendiente) {
		this.pendiente = pendiente;
	}

	public void setEventoIsAccion(boolean eventoIsAccion) {
		this.eventoIsAccion = eventoIsAccion;
	}

	public void salir(){
		paginationData.reset();	
		setPrimerAcceso(true);
		parametrosAvisoAgenda.setModo("RECARGAR");
	}

	
	public Boolean getSelectedRow() {
		return listasSeleccionadas.contains(listaAvisosPantalla.getListaAvisoSelected());
//		ListaAviso avisSelected = listaAvisosPantalla.getListaAvisoSelected();
//		if (avisSelected  != null && listasSeleccionadas != null) {
//			return contains(avisSelected );
//		} else {
//			return false;
//		}
	}

	public void setSelectedRow(Boolean selected) {
		ListaAviso avisSelected = listaAvisosPantalla.getListaAvisoSelected();
		if (selected) {
			listasSeleccionadas.add((ListaAviso) avisSelected);
		} else {
			listasSeleccionadas.remove((ListaAviso) avisSelected);
		}
	}
	
	public boolean contains(ListaAviso voSelected){
		boolean ret = false;
		for (ListaAviso vo : listasSeleccionadas) {
			if(vo.equals(voSelected)){
				ret = true;
				break;
			}
		} 
		return ret; 
	}
	public void seleccionarLista(){ }

	public void selectAll() {

		int tmpMaxResults = paginationData.getMaxResults();
		int tmpFirstResult = paginationData.getFirstResult();
		paginationData.setMaxResults(501);
		paginationData.setFirstResult(0);
		List<ListaAviso> prepareList = prepareList();
		int iteraciones = prepareList.size();
		if(prepareList.size() > 500){
			statusMessages.add(Severity.INFO, "#{messages['mantoper.seleccionados.primeros.cincuenta']}");
			iteraciones = 500;
			tmpFirstResult=0;
			maxSelected = 499;
		} else {
			maxSelected = prepareList.size()-1;
		}
		listasSeleccionadas.clear(); 
		for(int i = 0; i<iteraciones; i++){
			listasSeleccionadas.add(prepareList.get(i));
		}
		paginationData.setMaxResults(tmpMaxResults);
		paginationData.setFirstResult(tmpFirstResult);
		
	}

	public HashSet<ListaAviso> getListasSeleccionadas() {
		return listasSeleccionadas;
	}

	public void setListasSeleccionadas(HashSet<ListaAviso> listasSeleccionadas) {
		this.listasSeleccionadas = listasSeleccionadas;
	}

	public int getMaxSelected() {
		return maxSelected;
	}

	public void setMaxSelected(int maxSelected) {
		this.maxSelected = maxSelected;
	}

	public void deSelectAll() {
		//Este metodo borra Todos y punto
		listasSeleccionadas.clear();  //.removeAll(listaOperacionesList);
		maxSelected = 0;
	}

////	public String ver(ListaAviso aviso){
////			
////			historicoOperacion = vistaOperacionSelected.getHistOper();
////			mantOperBo.refreshHistDeri(historicoOperacion);
////			if ( ! mantOperBo.validateLastFechaModificacion(historicoOperacion)){
////				statusMessages.add(Severity.ERROR , "Se ha modificado este historico, vuelva a realizar la busqueda para continuar");
////				return Constantes.FAIL;
////			}
////			//boletasBo.prepareConsultaCorrela(historicoOperacion);
////			boletaState = BoletasStates.CONSULTA_BOLETA;
//			return Constantes.SUCCESS;
//
//	}
	
}
