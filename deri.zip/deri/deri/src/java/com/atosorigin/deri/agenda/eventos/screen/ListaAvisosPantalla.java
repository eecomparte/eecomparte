package com.atosorigin.deri.agenda.eventos.screen;

import java.util.Date;
import java.util.List;

import org.jboss.seam.ScopeType;
import org.jboss.seam.annotations.Name;
import org.jboss.seam.annotations.Out;
import org.jboss.seam.annotations.Scope;
import org.jboss.seam.annotations.datamodel.DataModel;
import org.jboss.seam.annotations.datamodel.DataModelSelection;

import com.atosorigin.common.constantes.Constantes;
import com.atosorigin.deri.model.agenda.DescripcionAccionesAvisos;
import com.atosorigin.deri.model.agenda.EventoAgenda;
import com.atosorigin.deri.model.agenda.ListaAviso;
import com.atosorigin.deri.model.catalogo.Producto;


/**
 *  Contiene los datos de pantalla necesarios para el caso de uso de eventos agenda.
 */
@Name("listaAvisosPantalla")
@Scope(ScopeType.CONVERSATION)
public class ListaAvisosPantalla {

	/** Combo de Acciones/Avisos. Criterio de búsqueda de eventos */	
	protected DescripcionAccionesAvisos descrAccAviSelected;

	/** Combo de producto. Criterio de búsqueda de eventos */	
	protected Producto productoSelected;
	
	/** Numero de operación desde. Criterio de búsqueda de eventos.  */
	protected String numOperDesde;
	
	/** Numero de operación hasta. Criterio de búsqueda de eventos.  */
	protected String numOperHasta;

	/** Fecha Evento. Criterio de búsqueda de eventos.  */
	protected Date fechaEvento;
	
	/** Ver solo pendientes. Criterio de búsqueda de eventos.  */
	protected boolean pendientes;

	protected String ultimoPase;
	
	protected String fechaParada;
	
	protected String faltaMMSS;
	
	protected int tiempore;

	/** Lista de datos para el grid. */
	@DataModel(value ="listaDeAvisos")
	protected List<ListaAviso> avisosList;	
	
	@DataModelSelection(value ="listaDeAvisos")    
	protected ListaAviso listaAvisoSelected;
	
		
	@Out(required=false)
	private Boolean estadoAgenda; 
	
	@Out(required=false)
	private EventoAgenda eventoSelectAgenda; 
	
	@Out(required=false)
	private String modo = Constantes.MODO_AGE; 
	
	@Out(required=false)
	private Producto producto; 
	
	@Out(required=false)
	private  String numOperIni;
	
	@Out(required=false)
	private  String numOperFin;
	
	@Out(required=false)
	private  Date fechaTraIni;
	
	@Out(required=false)
	private String estindic;
	
	@Out(required=false)
	private String fechaPro; 
	
	@Out(required=false)
	private String fecInsfo;

	@Out(required=false)
	private Long estructuraId;
	
	private Boolean pollEnabled = false;
	
	public Producto getProductoSelected() {
		return productoSelected;
	}

	public void setProductoSelected(Producto productoSelected) {
		this.productoSelected = productoSelected;
	}

	public DescripcionAccionesAvisos getDescrAccAviSelected() {
		return descrAccAviSelected;
	}

	public void setDescrAccAviSelected(DescripcionAccionesAvisos descrAccAviSelected) {
		this.descrAccAviSelected = descrAccAviSelected;
	}

	public String getNumOperDesde() {
		return numOperDesde;
	}

	public String getNumOperHasta() {
		return numOperHasta;
	}

	public boolean isPendientes() {
		return pendientes;
	}



	public void setNumOperDesde(String numOperDesde) {
		this.numOperDesde = numOperDesde;
	}

	public void setNumOperHasta(String numOperHasta) {
		this.numOperHasta = numOperHasta;
	}

	public void setPendientes(boolean pendientes) {
		this.pendientes = pendientes;
	}


	public List<ListaAviso> getAvisosList() {
		return avisosList;
	}

	public void setAvisosList(List<ListaAviso> avisosList) {
		this.avisosList = avisosList;
	}

	public ListaAviso getListaAvisoSelected() {
		return listaAvisoSelected;
	}

	public void setListaAvisoSelected(ListaAviso listaAvisoSelected) {
		this.listaAvisoSelected = listaAvisoSelected;
	}

	public Date getFechaEvento() {
		return fechaEvento;
	}

	public void setFechaEvento(Date fechaEvento) {
		this.fechaEvento = fechaEvento;
	}

	public Boolean getPollEnabled() {
		return pollEnabled;
	}

	public void setPollEnabled(Boolean pollEnabled) {
		this.pollEnabled = pollEnabled;
	}

	public int getTiempore() {
		return tiempore;
	}

	public void setTiempore(int tiempore) {
		this.tiempore = tiempore;
	}

	public String getFechaParada() {
		return fechaParada;
	}

	public String getUltimoPase() {
		return ultimoPase;
	}

	public String getFaltaMMSS() {
		return faltaMMSS;
	}

	public void setFechaParada(String fechaParada) {
		this.fechaParada = fechaParada;
	}

	public void setUltimoPase(String ultimoPase) {
		this.ultimoPase = ultimoPase;
	}

	public void setFaltaMMSS(String faltaMMSS) {
		this.faltaMMSS = faltaMMSS;
	}

	public Boolean getEstadoAgenda() {
		return estadoAgenda;
	}

	public void setEstadoAgenda(Boolean estadoAgenda) {
		this.estadoAgenda = estadoAgenda;
	}

	public EventoAgenda getEventoSelectAgenda() {
		return eventoSelectAgenda;
	}

	public void setEventoSelectAgenda(EventoAgenda eventoSelectAgenda) {
		this.eventoSelectAgenda = eventoSelectAgenda;
	}

	public String getModo() {
		return modo;
	}

	public void setModo(String modo) {
		this.modo = modo;
	}

	public Producto getProducto() {
		return producto;
	}

	public void setProducto(Producto producto) {
		this.producto = producto;
	}

	public String getNumOperIni() {
		return numOperIni;
	}

	public void setNumOperIni(String numOperIni) {
		this.numOperIni = numOperIni;
	}

	public String getNumOperFin() {
		return numOperFin;
	}

	public void setNumOperFin(String numOperFin) {
		this.numOperFin = numOperFin;
	}

	public Date getFechaTraIni() {
		return fechaTraIni;
	}

	public void setFechaTraIni(Date fechaTraIni) {
		this.fechaTraIni = fechaTraIni;
	}

	public String getEstindic() {
		return estindic;
	}

	public void setEstindic(String estindic) {
		this.estindic = estindic;
	}

	public String getFechaPro() {
		return fechaPro;
	}

	public void setFechaPro(String fechaPro) {
		this.fechaPro = fechaPro;
	}

	public String getFecInsfo() {
		return fecInsfo;
	}

	public void setFecInsfo(String fecInsfo) {
		this.fecInsfo = fecInsfo;
	}

	public Long getEstructuraId() {
		return estructuraId;
	}

	public void setEstructuraId(Long estructuraId) {
		this.estructuraId = estructuraId;
	}


}
