package com.atosorigin.deri.agenda.mantaviso.action;

import org.jboss.seam.ScopeType;
import org.jboss.seam.annotations.Name;
import org.jboss.seam.annotations.Scope;

import com.atosorigin.common.action.GenericAction;
import com.atosorigin.common.formvalidator.FormValidator;

/**
 * Clase que actúa de action listener para el caso de uso de mantenimiento de avisos.
 */
@Name("avisoAction")
@Scope(ScopeType.CONVERSATION)
@FormValidator
public class AvisoAction extends GenericAction{

//		
//	/**
//	 * Inyección del bean de Spring "avisoBo" que contiene los métodos de negocio
//	 * para el caso de uso mantenimiento de avisos.
//	 */
//	@In("#{avisoBo}")
//	protected AvisoBo avisoBo;
//
//	/**
//	 * Inyección del screen bean que contiene los datos de pantalla del caso de uso
//	 * mantenimiento de avisos.
//	 */
//	@In(create=true)
//	protected AvisoPantalla avisoPantalla;
//	
//	@In Credentials credentials;
//	
//	protected boolean fechaIniInvalida;
//	
//	public boolean isFechaIniInvalida() {
//		return fechaIniInvalida;
//	}
//
//	public void setFechaIniInvalida(boolean fechaIniInvalida) {
//		this.fechaIniInvalida = fechaIniInvalida;
//	}
//
//	public boolean guardarValidator(){
//		Aviso aviso = this.avisoPantalla.getAviso();
//		
//		if (modoPantalla.equals(ModoPantalla.CREACION)){
//			Aviso avisoExitente = avisoBo.cargar(aviso.getCodigo());			
//			if (avisoExitente !=null){
//				statusMessages.addToControl("codigo", Severity.ERROR, "aviso.error.avisoExistente", Constantes.DEFAULT_MESSAGE_TEMPLATE);
//				return false;
//			}			
//		}
//		
//		long diffFechaValida = (aviso.getFechaInicio().getTime() - new Date().getTime())/86400000L;
//		
//		if (!fechaIniInvalida && diffFechaValida<0){				
//			setFechaIniInvalida(true);
//			return false;
//		}			
//		setFechaIniInvalida(false);
//
//		if (GenericUtils.isNullOrBlank(aviso.getFechaFin())){
//			aviso.setFechaFin(recuperarFechaFin());
//		}
//		long diffFechaFinIni = (aviso.getFechaFin().getTime() - aviso.getFechaInicio().getTime())/86400000L;
//		long diffFechaIniFin = (aviso.getFechaInicio().getTime() - aviso.getFechaFin().getTime())/86400000L;
//		
//		if (diffFechaIniFin>0){
//			statusMessages.addToControl("fechaInicio", Severity.ERROR, "aviso.error.fechaValidezErronea", Constantes.DEFAULT_MESSAGE_TEMPLATE);
//			return false;
//		}
//		
//		aviso.setDiasPeriodo((short)avisoBo.calcularDiasPeriodo(aviso.getPeriodicidad().getCodigo()));
//		long diff = diffFechaFinIni +1; 
//		if (aviso.getPeriodicidad().getCodigo().equals(Constantes.COD_PERIODICIDAD_UNICO) 
//				&& diff>1){
//			statusMessages.addToControl("fechaInicio", Severity.ERROR, "aviso.error.fechasIncoherentes", Constantes.DEFAULT_MESSAGE_TEMPLATE);
//			return false;
//		}
//		if (!aviso.getPeriodicidad().getCodigo().equals(Constantes.COD_PERIODICIDAD_UNICO) 
//				&& ! aviso.getPeriodicidad().getCodigo().equals(Constantes.COD_PERIODICIDAD_DIARIA)
//				&& diff<(int)aviso.getDiasPeriodo()){
//			statusMessages.addToControl("fechaInicio", Severity.ERROR, "aviso.error.fechasIncoherentes", Constantes.DEFAULT_MESSAGE_TEMPLATE);
//			return false;
//			
//		}
//		return true;
//	}
//	
//	public String guardar() {
//		Aviso aviso = avisoPantalla.getAviso();		
//
//		if (modoPantalla.equals(ModoPantalla.CREACION)){			
//			aviso.setNivelUrgencia(Constantes.NIVEL_URGENCIA_B);
//			aviso.setFechaOperacion(null);
//			aviso.setMarcaBaja(false);
//			if (GenericUtils.isNullOrBlank(aviso.getFechaFin())){
//					aviso.setFechaFin(recuperarFechaFin());
//			}
//		}
//		
//		aviso.setDiasPeriodo((short)avisoBo.calcularDiasPeriodo(aviso.getPeriodicidad().getCodigo()));
//		aviso.setFechaProximoAviso(avisoBo.obtenerFechaProximoAviso(aviso.getFechaInicio()));
//		
//		avisoBo.guardar(aviso);
//		if (avisoPantalla.getAviso()!=null && !GenericUtils.isNullOrBlank(avisoPantalla.getAviso().getCodigo())){
//			avisoBo.recargar(avisoPantalla.getAviso());
//		}
//		refrescarLista();
//		return "success";
//	}
//
//	/**
//	 * Actualiza la lista del grid de avisos no Vencidos
//	 * 
//	 */
//	public void buscarNoVencidos() {
//		paginationData.reset();
//		avisoPantalla.setNovencidos(true);
//		setPrimerAcceso(false);
//		refrescarLista();		
//	}
//	
//	/**
//	 * Actualiza la lista del grid de avisos
//	 * 
//	 */
//	public void buscar() {
//		paginationData.reset();	
//		setPrimerAcceso(false);
//		refrescarLista();		
//	}
//
//	
//		
//	//Métodos necesarios para pantallas con grids.
//	//Es necesario implementar estos métodos abstractos de PaginatedListAction
//	@Override
//	public List<Aviso> getDataTableList() {
//		return avisoPantalla.getAvisoList();
//	}
//
//	@Override
//	@SuppressWarnings("unchecked")
//	public void setDataTableList(List<?> dataTableList) {
//		avisoPantalla.setAvisoList((List<Aviso>)dataTableList);
//	}
//
//	@Override
//	protected void refreshListInternal() {
//		setExportExcel(false);
//		if (GenericUtils.isNullOrBlank(paginationData.getOrderKey())){
//			paginationData.setOrderKey("aviso.codigo");
//		}
//		List ql = (List)avisoBo.buscarAvisos(avisoPantalla.getCodigo(), avisoPantalla.getDescripcion(), avisoPantalla.getNovencidos(), paginationData);		
//		avisoPantalla.setAvisoList(ql);		
//	}
//
//
//	/**
//	 * Prepara para entrar en el modo inspección de un aviso.
//	 * 
//	 */
//	public void ver() {
//		setModoPantalla(ModoPantalla.INSPECCION);		
//		avisoPantalla.setAviso(avisoBo.cargar(avisoPantalla.getAvisoSelect().getCodigo()));
//		
//	}
//	
//	/**
//	 * Prepara para entrar en el modo edición de un aviso.
//	 * 
//	 */
//	public void editar() {
//		setFechaIniInvalida(false);
//		setModoPantalla(ModoPantalla.EDICION);
//		avisoPantalla.setAviso(avisoBo.cargar(avisoPantalla.getAvisoSelect().getCodigo()));		
//	}
//
//	/**
//	 * Prepara para entrar en el modo creación de un aviso.
//	 * 
//	 */
//	public void nuevo() {
//		String name = credentials.getUsername();
//		Aviso aviso = new Aviso();
//		
//		setModoPantalla(ModoPantalla.CREACION);		
//		aviso.setFechaInicio(new Date());
//				
//		AuditData auditData = new AuditData();
//		auditData.setUsuarioUltimaModi(name);	
//		aviso.setAuditData(auditData);
//		
//		avisoPantalla.setAviso(aviso);	
//		
//		setFechaIniInvalida(false);
//	}
//	
//
//	/**
//	 * Borra un aviso.
//	 * 
//	 */
//	public void borrar() {
//		avisoBo.borrar(avisoPantalla.getAviso());		
//		refrescarLista();
//		
//	}
//	
//	@Override
//	public void refrescarListaExcel() { 
//		//SMM revisión fase0
//		setExportExcel(true);
//		avisoPantalla.setAvisoList(avisoBo.buscarAvisos(avisoPantalla.getCodigo(), avisoPantalla.getDescripcion(), avisoPantalla.getNovencidos(), paginationData.getPaginationDataForExcel()));	
//	}
//
//	public void actualizarFechaIni(){		
//		Aviso aviso = this.avisoPantalla.getAviso();
//		aviso.setFechaFin(recuperarFechaFin());
//		avisoPantalla.setAviso(aviso);
//	}
//	
//	public Date recuperarFechaFin(){
//		Date fechaFin = null;
//		Aviso aviso = this.avisoPantalla.getAviso();
//		SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
//		
//		if (!aviso.getPeriodicidad().getCodigo().equals(Constantes.COD_PERIODICIDAD_UNICO)){
//			if (GenericUtils.isNullOrBlank(aviso.getFechaFin())){
//				try {
//					fechaFin = sdf.parse("31/12/2099");
//				} catch (ParseException e) { 
//					log.error(e.getLocalizedMessage());
//				}
//			}else{
//				fechaFin = aviso.getFechaFin();
//			}
//		}else{
//			if (GenericUtils.isNullOrBlank(aviso.getFechaFin())){
//				fechaFin = aviso.getFechaInicio();
//			}else{
//				fechaFin = aviso.getFechaFin();
//			}
//		}				
//			
//		return fechaFin;
//	}
//	
//	public void salirDetalle() {
//		super.salir();
//		if (avisoPantalla.getAviso()!=null && !GenericUtils.isNullOrBlank(avisoPantalla.getAviso().getCodigo())){
//			avisoBo.recargar(avisoPantalla.getAviso());
//		}
//		refrescarLista();
//	}
}
