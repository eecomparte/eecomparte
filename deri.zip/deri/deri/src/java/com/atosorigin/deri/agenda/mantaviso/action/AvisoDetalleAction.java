package com.atosorigin.deri.agenda.mantaviso.action;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.jboss.seam.ScopeType;
import org.jboss.seam.annotations.In;
import org.jboss.seam.annotations.Name;
import org.jboss.seam.annotations.Scope;
import org.jboss.seam.international.StatusMessage.Severity;

import com.atosorigin.common.action.GenericAction;
import com.atosorigin.common.action.ModoPantalla;
import com.atosorigin.common.constantes.Constantes;
import com.atosorigin.common.formvalidator.FormValidator;
import com.atosorigin.common.utils.GenericUtils;
import com.atosorigin.deri.agenda.aviso.business.AvisoBo;
import com.atosorigin.deri.agenda.mantaviso.screen.AvisoPantalla;
import com.atosorigin.deri.model.agenda.Aviso;

@Name("avisoDetalleAction")
@Scope(ScopeType.CONVERSATION)
@FormValidator
public class AvisoDetalleAction extends GenericAction {

	@In("#{avisoBo}")
	protected AvisoBo avisoBo;

	@In(value="avisoEdit")
	protected Aviso aviso;

	@In(required = false)
	protected AvisoListadoAction avisoListadoAction;

	@In("modoPantalla")
	protected ModoPantalla modoPantallaIn;

	@In(value="avisoPantalla", required=true)
	protected AvisoPantalla avisoPantalla;
	
	protected boolean fechaIniInvalida;
	
	public boolean isFechaIniInvalida() {
		return fechaIniInvalida;
	}

	public void setFechaIniInvalida(boolean fechaIniInvalida) {
		this.fechaIniInvalida = fechaIniInvalida;
	}
	
	public boolean guardarValidator() {

		if (modoPantalla.equals(ModoPantalla.CREACION)) {
			Aviso avisoExitente = avisoBo.cargar(avisoPantalla.getCodigo());
			if (avisoExitente != null) {
				statusMessages.addToControl("codigo", Severity.ERROR,
						"aviso.error.avisoExistente",
						Constantes.DEFAULT_MESSAGE_TEMPLATE);
				return false;
			}
		}

		long diffFechaValida = (avisoPantalla.getFechaInicio().getTime() - new Date()
				.getTime()) / 86400000L;

		if (!fechaIniInvalida && diffFechaValida<0){				
			setFechaIniInvalida(true);
			return false;
		}			
		setFechaIniInvalida(false);

		if (GenericUtils.isNullOrBlank(avisoPantalla.getFechaFin())){
			avisoPantalla.setFechaFin(recuperarFechaFin());
		}
		long diffFechaFinIni = (avisoPantalla.getFechaFin().getTime() - avisoPantalla.getFechaInicio().getTime()) / 86400000L;
		long diffFechaIniFin = (avisoPantalla.getFechaInicio().getTime() - avisoPantalla.getFechaFin().getTime()) / 86400000L;

		if (diffFechaIniFin > 0) {
			statusMessages.addToControl("fechaInicio", Severity.ERROR,
					"aviso.error.fechaValidezErronea",
					Constantes.DEFAULT_MESSAGE_TEMPLATE);
			return false;
		}

		Short diasPeriodo = (short) avisoBo.calcularDiasPeriodo(avisoPantalla.getPeriodicidad().getCodigo());
		
//		aviso.setDiasPeriodo((short) avisoBo.calcularDiasPeriodo(avisoPantalla.getPeriodicidad().getCodigo()));
		long diff = diffFechaFinIni + 1;
		if (avisoPantalla.getPeriodicidad().getCodigo().equals(
				Constantes.COD_PERIODICIDAD_UNICO)
				&& diff > 1) {
			statusMessages.addToControl("fechaInicio", Severity.ERROR,
					"aviso.error.fechasIncoherentes",
					Constantes.DEFAULT_MESSAGE_TEMPLATE);
			return false;
		}
		if (!avisoPantalla.getPeriodicidad().getCodigo().equals(
				Constantes.COD_PERIODICIDAD_UNICO)
				&& !avisoPantalla.getPeriodicidad().getCodigo().equals(
						Constantes.COD_PERIODICIDAD_DIARIA)
				&& diff < (int) diasPeriodo) {
			statusMessages.addToControl("fechaInicio", Severity.ERROR,
					"aviso.error.fechasIncoherentes",
					Constantes.DEFAULT_MESSAGE_TEMPLATE);
			return false;

		}
		return true;
	}

	public String guardar() {

		this.formToBean();
		
		if (modoPantalla.equals(ModoPantalla.CREACION)) {
			aviso.setNivelUrgencia(Constantes.NIVEL_URGENCIA_B);
			aviso.setFechaOperacion(null);
			aviso.setMarcaBaja(false);
		}

		aviso.setDiasPeriodo((short) avisoBo.calcularDiasPeriodo(aviso
				.getPeriodicidad().getCodigo()));
		aviso.setFechaProximoAviso(avisoBo.obtenerFechaProximoAviso(aviso
				.getFechaInicio()));

		avisoBo.guardar(aviso);

		if (avisoListadoAction != null)
			avisoListadoAction.refrescarLista();

		return Constantes.SUCCESS;
	}

//	public void salirDetalle() {
//		
//		super.salir();
//	}
	
	@Override
	public void salir(){
		if (avisoListadoAction != null)
			avisoListadoAction.refrescarLista();		
		super.salir();
	}

	public void actualizarFechaIni() {
		avisoPantalla.setFechaFin(recuperarFechaFin());
	}

	public Date recuperarFechaFin() {
		Date fechaFin = null;
		SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");

		if (!avisoPantalla.getPeriodicidad().getCodigo().equals(Constantes.COD_PERIODICIDAD_UNICO)) {
			if (GenericUtils.isNullOrBlank(avisoPantalla.getFechaFin())) {
				try {
					fechaFin = sdf.parse("31/12/2099");
				} catch (ParseException e) {
					log.error(e.getLocalizedMessage());
				}
			} else {
				fechaFin = avisoPantalla.getFechaFin();
			}
		} else {
			// SMM: inc 705 - cambio. Si periodicidad única fecha Fin siempre tendrá valor fecha Inicio
			//if (GenericUtils.isNullOrBlank(aviso.getFechaFin())) {
			fechaFin = avisoPantalla.getFechaInicio();
//			} else {
//				fechaFin = aviso.getFechaFin();
//			}
		}

		return fechaFin;
	}

//	/**
//	 * Getter del modoPantalla comprobando si en la conversación está definido
//	 * el modo.
//	 */
//	public ModoPantalla getModoPantalla() {
//		return (modoPantallaIn == null) ? (modoPantallaIn = super
//				.getModoPantalla()) : (modoPantalla = modoPantallaIn);
//	}

	public void init() {

		// init. modo pantalla
		if (modoPantallaIn != null)
			modoPantalla = modoPantallaIn;

	}

	private void formToBean(){
		this.aviso.setCodigo(avisoPantalla.getCodigo());
		this.aviso.setDescripcion(avisoPantalla.getDescripcion());
		this.aviso.setEstructuraRelacionada(avisoPantalla.getEstructuraRelacionada());
		this.aviso.setFechaFin(avisoPantalla.getFechaFin());
		this.aviso.setFechaInicio(avisoPantalla.getFechaInicio());
		this.aviso.setOperacionRelacionada(avisoPantalla.getOperacionRelacionada());
		this.aviso.setPeriodicidad(avisoPantalla.getPeriodicidad());
		this.aviso.getAuditData().setUsuarioUltimaModi(avisoPantalla.getUsuario());
	}
	
	public void setAviso(Aviso aviso) {
		this.aviso = aviso;
	}
	public Aviso getAviso() {
		return aviso;
	}

}
