package com.atosorigin.deri.agenda.mantaviso.action;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.jboss.seam.ScopeType;
import org.jboss.seam.annotations.In;
import org.jboss.seam.annotations.Name;
import org.jboss.seam.annotations.Out;
import org.jboss.seam.annotations.Scope;
import org.jboss.seam.annotations.datamodel.DataModel;
import org.jboss.seam.annotations.datamodel.DataModelSelection;
import org.jboss.seam.core.Init;
import org.jboss.seam.security.Credentials;

import com.atosorigin.common.action.ModoPantalla;
import com.atosorigin.common.action.PaginatedListAction;
import com.atosorigin.common.auditdata.AuditData;
import com.atosorigin.common.constantes.Constantes;
import com.atosorigin.common.formvalidator.FormValidator;
import com.atosorigin.common.utils.GenericUtils;
import com.atosorigin.deri.agenda.aviso.business.AvisoBo;
import com.atosorigin.deri.agenda.mantaviso.screen.AvisoPantalla;
import com.atosorigin.deri.model.agenda.Aviso;

/**
 * Clase que actúa de action listener para el caso de uso de mantenimiento de
 * avisos.
 */
@Name("avisoListadoAction")
@Scope(ScopeType.CONVERSATION)
@FormValidator
public class AvisoListadoAction extends PaginatedListAction {

	@In
	protected Credentials credentials;

	@In
	protected Init init;

	@In(value="avisoPantalla", create=true)
	@Out
	protected AvisoPantalla avisoPantalla;
	
	//
	// Campos del panel de búsqueda
	//

	protected boolean noVencidos;

	protected String codigo;

	protected String descripcion;

	//
	// Business Objects
	//

	@In("#{avisoBo}")
	protected AvisoBo avisoBo;

	@DataModel(value="avisoList")
	protected List<Aviso> avisoList;
	
	@DataModelSelection(value="avisoList")
	protected Aviso avisoListSelect;
	
	@Out(value="avisoEdit", required = false)
	protected Aviso aviso;
	
	// Modo para la pantalla de detalle
	@Out(value = "modoPantalla", required = false)
	protected ModoPantalla modoPantallaDetalle;


	/**
	 * Actualiza la lista del grid de avisos no Vencidos
	 * 
	 */
	public void buscarNoVencidos() {
		paginationData.reset();
		setNoVencidos(true);
		setPrimerAcceso(false);
		refrescarLista();		
	}
	
	/**
	 * Actualiza la lista del grid de avisos
	 * 
	 */
	public void buscar() {
		paginationData.reset();
		setPrimerAcceso(false);
		aviso = null;

		refrescarLista();
	}

	// Métodos necesarios para pantallas con grids.
	// Es necesario implementar estos métodos abstractos de PaginatedListAction
	@Override
	public List<Aviso> getDataTableList() {
		return avisoList;
	}

	@Override
	@SuppressWarnings("unchecked")
	public void setDataTableList(List<?> dataTableList) {
		avisoList = (List<Aviso>) dataTableList;
	}

	@Override	
	protected void refreshListInternal() {

		setExportExcel(false);
	
		if (GenericUtils.isNullOrBlank(paginationData.getOrderKey()))
			paginationData.setOrderKey("aviso.codigo");

		String codigo = GenericUtils.isNullOrBlank(this.codigo) ? null
				: this.codigo;
		String descripcion = GenericUtils.isNullOrBlank(this.descripcion) ? null
				: this.descripcion;
		if (avisoList!=null) avisoList.clear();
		else avisoList = new ArrayList<Aviso>();
		avisoList.addAll(avisoBo.buscarAvisos(codigo, descripcion, noVencidos, paginationData));
		//avisoList= avisoBo.buscarAvisos(codigo, descripcion, noVencidos, paginationData);
		
	}

	/**
	 * Prepara para entrar en el modo inspección de un aviso.
	 * 
	 */
	public void ver() {
		copiaSeleccionado();
		beanToForm();
//		setAviso(avisoBo.cargar(avisoListSelect.getCodigo()));
		modoPantallaDetalle = ModoPantalla.INSPECCION;		
	}

	/**
	 * Prepara para entrar en el modo edición de un aviso.
	 * 
	 */
	public void editar() {
		copiaSeleccionado();
		beanToForm();
	//	setAviso(avisoBo.cargar(avisoListSelect.getCodigo()));
		modoPantallaDetalle = ModoPantalla.EDICION;
	}

	/**
	 * Prepara para entrar en el modo creación de un aviso.
	 * 
	 */
	public void nuevo() {
		aviso = new Aviso();
		aviso.setFechaInicio(new Date());

		final AuditData auditData = new AuditData();
		auditData.setUsuarioUltimaModi(credentials.getUsername());
		aviso.setAuditData(auditData);
		beanToForm();
		modoPantallaDetalle = ModoPantalla.CREACION;
		// Component.forName(
		// AvisoDetalleAction.class.getAnnotation(Name.class).value())
		// .inject(avisoDetalleAction, true);
	}

	private void beanToForm(){
		avisoPantalla.setCodigo(this.aviso.getCodigo());
		avisoPantalla.setDescripcion(this.aviso.getDescripcion());
		avisoPantalla.setEstructuraRelacionada(this.aviso.getEstructuraRelacionada());
		avisoPantalla.setFechaFin(this.aviso.getFechaFin());
		avisoPantalla.setFechaInicio(this.aviso.getFechaInicio());
		avisoPantalla.setOperacionRelacionada(this.aviso.getOperacionRelacionada());
		avisoPantalla.setPeriodicidad(this.aviso.getPeriodicidad());
		avisoPantalla.setUsuario(this.aviso.getAuditData().getUsuarioUltimaModi());
	}
	
	/**
	 * Borra un aviso.
	 * 
	 */
	public void borrar() {
		copiaSeleccionado();
		avisoBo.borrar(aviso);
		refrescarLista();
	}

	@Override
	public void refrescarListaExcel() {

		// SMM revisión fase0
		setExportExcel(true);
		
		String codigo = GenericUtils.isNullOrBlank(this.codigo) ? null
				: this.codigo;
		String descripcion = GenericUtils.isNullOrBlank(this.descripcion) ? null
				: this.descripcion;
		
		if (avisoList!=null) avisoList.clear();
		else avisoList = new ArrayList<Aviso>();
		avisoList.addAll(avisoBo.buscarAvisos(codigo, descripcion, noVencidos,
				paginationData.getPaginationDataForExcel()));
	}

	public void actualizarFechaIni() {
		aviso.setFechaFin(recuperarFechaFin());
	}

	public Date recuperarFechaFin() {
		Date fechaFin = null;
		SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");

		if (!aviso.getPeriodicidad().getCodigo().equals(
				Constantes.COD_PERIODICIDAD_UNICO)) {
			if (GenericUtils.isNullOrBlank(aviso.getFechaFin())) {
				try {
					fechaFin = sdf.parse("31/12/2099");
				} catch (ParseException e) {
					log.error(e.getLocalizedMessage());
				}
			} else {
				fechaFin = aviso.getFechaFin();
			}
		} else {
			if (GenericUtils.isNullOrBlank(aviso.getFechaFin())) {
				fechaFin = aviso.getFechaInicio();
			} else {
				fechaFin = aviso.getFechaFin();
			}
		}

		return fechaFin;
	}

	public void init() {
//		init.setDebug(true);
	}
	
	public void copiaSeleccionado(){
		this.aviso = this.avisoListSelect;
	}
	
	public boolean isNoVencidos() {
		return noVencidos;
	}

	public void setNoVencidos(boolean noVencidos) {
		this.noVencidos = noVencidos;
	}

	public String getCodigo() {
		return codigo;
	}

	public void setCodigo(String codigo) {
		this.codigo = codigo;
	}

	public String getDescripcion() {
		return descripcion;
	}

	public void setDescripcion(String descripcion) {
		this.descripcion = descripcion;
	}

	public Aviso getAviso() {
		return aviso;
	}
	public void setAviso(Aviso aviso) {
		this.aviso = aviso;
	}
}
