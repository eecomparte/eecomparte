package com.atosorigin.deri.agenda.mantaviso.screen;

import java.util.Date;

import org.jboss.seam.ScopeType;
import org.jboss.seam.annotations.Name;
import org.jboss.seam.annotations.Scope;

import com.atosorigin.deri.model.agenda.DescripcionAviso;


/**
 *  Contiene los datos de pantalla necesarios para el caso de uso mantenimiento de avisos.
 */
@Name("avisoPantalla")
@Scope(ScopeType.CONVERSATION)
public class AvisoPantalla {

	private String codigo;
	private String descripcion;
	private Long operacionRelacionada;
	private Long estructuraRelacionada;
	private DescripcionAviso periodicidad;
	private Date fechaInicio;
	private Date fechaFin;
	private String usuario;
	
	public String getCodigo() {
		return codigo;
	}
	public void setCodigo(String codigo) {
		this.codigo = codigo;
	}
	public String getDescripcion() {
		return descripcion;
	}
	public void setDescripcion(String descripcion) {
		this.descripcion = descripcion;
	}
	public Long getOperacionRelacionada() {
		return operacionRelacionada;
	}
	public void setOperacionRelacionada(Long operacionRelacionada) {
		this.operacionRelacionada = operacionRelacionada;
	}
	public Long getEstructuraRelacionada() {
		return estructuraRelacionada;
	}
	public void setEstructuraRelacionada(Long estructuraRelacionada) {
		this.estructuraRelacionada = estructuraRelacionada;
	}
	public DescripcionAviso getPeriodicidad() {
		return periodicidad;
	}
	public void setPeriodicidad(DescripcionAviso periodicidad) {
		this.periodicidad = periodicidad;
	}
	public Date getFechaInicio() {
		return fechaInicio;
	}
	public void setFechaInicio(Date fechaInicio) {
		this.fechaInicio = fechaInicio;
	}
	public Date getFechaFin() {
		return fechaFin;
	}
	public void setFechaFin(Date fechaFin) {
		this.fechaFin = fechaFin;
	}
	public String getUsuario() {
		return usuario;
	}
	public void setUsuario(String usuario) {
		this.usuario = usuario;
	}
	
}
