
package com.atosorigin.deri.agenda.peticiones.action;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import javax.faces.context.ExternalContext;
import javax.faces.context.FacesContext;
import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServletResponse;

import org.jboss.seam.ScopeType;
import org.jboss.seam.annotations.In;
import org.jboss.seam.annotations.Name;
import org.jboss.seam.annotations.Scope;
import org.jboss.seam.core.Conversation;
import org.jboss.seam.international.StatusMessages;

import com.atosorigin.common.action.PaginatedListAction;
import com.atosorigin.common.action.PaginationData;
import com.atosorigin.common.constantes.Constantes;
import com.atosorigin.common.formvalidator.FormValidator;
import com.atosorigin.common.utils.GenericUtils;
import com.atosorigin.deri.agenda.peticiones.business.PeticionesBo;
import com.atosorigin.deri.agenda.peticiones.screen.PeticionesPantalla;
import com.atosorigin.deri.liquidaciones.business.MensajesValidacion;
import com.atosorigin.deri.liquidaciones.business.MensajesValidacionId;
import com.atosorigin.deri.model.peticiones.DescripcionEstadoPeticion;
import com.atosorigin.deri.model.peticiones.DescripcionTipoPeticion;
import com.atosorigin.deri.model.peticiones.PeticionDatos;
import com.atosorigin.deri.model.peticiones.PeticionExcelTmp;
import com.atosorigin.deri.model.peticiones.PeticionProceso;
import com.atosorigin.deri.util.MsgBoxAction;

@Name("peticionesAction")
@Scope(ScopeType.CONVERSATION)
@FormValidator
public class PeticionesAction extends PaginatedListAction {
	
	public static final String SITUALIQ_PDR = "PDR";
	public static final String SITUALIQ_VEN = "VEN";
	private final String PETICION_TRATADA = "TR";

	private PaginationData paginationCopy = new PaginationData();

	@In(value="#{facesContext.externalContext}")
	private ExternalContext extCtx;

	@In("#{peticionesBo}")
	protected PeticionesBo peticionesBo;

	@In(create=true)
	protected PeticionesPantalla peticionesPantalla;
	
	@In(required=false)
	protected List<DescripcionTipoPeticion> tipoPeticionesList;
	
	@In(required=false)
	protected List<DescripcionEstadoPeticion> estadoPeticionesList;

	/** Inyección de los mensajes de estado de SEAM */
	@In
	protected StatusMessages statusMessages;

	HashMap<MensajesValidacionId, MensajesValidacion> peticionesMsg;
	
	private boolean esDetalle=false;
	private boolean verErroneos=false;
	
	/** Inyeccion del componente necesario para mostrar mensajes de decisión al usuario */
	@In(create = true)
	private MsgBoxAction msgBoxAction;
	
	//private List<VistaLiquidacion> liquidacionesBloqueadas;
	
	//Selección de 500 registros para el botón seleccionar todos.
	//private List<VistaLiquidacion> listaTemp;
	
	
	// oO[Métodos]Oo
	@Override
	public List<?> getDataTableList() {
		if(!esDetalle)
			return peticionesPantalla.getListaPeticionProceso();
		else
			return peticionesPantalla.getDetallePeticionProceso();
	}
	
	@SuppressWarnings("unchecked")
	@Override
	public void setDataTableList(List<?> dataTableList) {
		if(!esDetalle)
			peticionesPantalla.setListaPeticionProceso((List<PeticionProceso>) dataTableList);
		else
			peticionesPantalla.setDetallePeticionProceso((List<PeticionDatos>) dataTableList);
	}

	@Override
	protected void refreshListInternal() {

		setExportExcel(false);
		rellenarLista(paginationData);
	}
	
	@Override
	public void refrescarListaExcel() {		
		setExportExcel(true);
		rellenarLista(paginationData.getPaginationDataForExcel());
	}

	public void buscar(){		
		paginationData.reset();
		paginationData.setMaxResults(50);
		setPrimerAcceso(false);	
		refrescarLista();	
	}

	public void salir(){
		Conversation conversacion = Conversation.instance();
		//Volvemos a la anterior conversación
		if(conversacion.isNested()){
			conversacion.redirectToParent();
		} else {
			redirectToURL("/home.seam");
			conversacion.endAndRedirect();
		}
	}

	public String getRowClasses(){
		StringBuilder builder = new StringBuilder();
		int i=0;
		for (PeticionProceso pp : peticionesPantalla.getListaPeticionProceso()) {
			if(i>0){
				builder.append(",");
			}

			if(i%2==0){
				builder.append("oddRow");
			}
			else{
				builder.append("evenRow");
			}
			i++;
		}
		return builder.toString();
	}
	
	public void rellenarLista(PaginationData paginationData){		
		primerAcceso=false;
		if(!esDetalle){
			List<PeticionProceso> lista = peticionesBo.obtenerDatosPeticiones(peticionesPantalla.getIdPeticion(),peticionesPantalla.getDescripcionTipoPeticion(), peticionesPantalla.getDescripcionEstadoPeticion(),
					peticionesPantalla.getFechaPetiDesde(), peticionesPantalla.getFechaPetiHasta(),
					exportExcel , paginationData);			
	
				peticionesPantalla.setListaPeticionProceso(lista);
		}else{
			List<PeticionDatos> detallePeticionProceso = null;
			if(!verErroneos)
				detallePeticionProceso = peticionesBo.obtenerDetallePeticion(peticionesPantalla.getPeticionProcesoSelected(),
					exportExcel , paginationData);
			else
				detallePeticionProceso = peticionesBo.obtenerErroneosPeticion(peticionesPantalla.getPeticionProcesoSelected(),
						exportExcel , paginationData);

				peticionesPantalla.setDetallePeticionProceso(detallePeticionProceso);
		}
			
			
	}
	
	//verTodos
	public void verTodos(){
		//hacemos copia del paginationData en paginationCopy para tener su valor al regresar a la página inicial
		paginationCopy.setFirstResult(paginationData.getFirstResult());
		paginationData.reset();
		setPrimerAcceso(false);	
		esDetalle=true;
		verErroneos=false;
		refrescarLista();
	}

	public void salirDeDetalle(){
		Conversation conversacion = Conversation.instance();
		esDetalle=false;
		verErroneos=false;
		//Volvemos a la anterior conversación
		if(conversacion.isNested()){
			conversacion.redirectToParent();
			//restauramos el pagination data con los valores guardados en paginationCopy
			paginationData.setFirstResult(paginationCopy.getFirstResult());
			paginationCopy.reset();
			rellenarLista(paginationData);
		} else {
			redirectToURL("/home.seam");
			conversacion.endAndRedirect();
		}
	}


	//verErroneos
	public void verErroneos(){
		//hacemos copia del paginationData en paginationCopy para tener su valor al regresar a la página inicial
		paginationCopy.setFirstResult(paginationData.getFirstResult());
		paginationData.reset();
		setPrimerAcceso(false);	
		esDetalle=true;
		verErroneos=true;
		refrescarLista();
	}
	
	/**
	 * Petición con estado ya marcada
	 */
	public boolean peticionMarcada(){
		return peticionesPantalla.getPeticionProcesoSelected().getEstado().getCodigo()!=PETICION_TRATADA;
	}
	/**
	 * marcar
	 */
	public void marcarTratada(){
		peticionesBo.marcarTratada(peticionesPantalla.getPeticionProcesoSelected());
		statusMessages.clear();
		statusMessages.add("#{messages['peticion.marcada']}");

	}
	
	public String getRowDetalleClasses(){
		StringBuilder builder = new StringBuilder();
		int i=0;
		for (PeticionDatos pd : peticionesPantalla.getDetallePeticionProceso()) {
			if(i>0){
				builder.append(",");
			}

			if(i%2==0){
				builder.append("oddRow");
			}
			else{
				builder.append("evenRow");
			}
			i++;
		}
		return builder.toString();
	}

	/**
	 * Indica si la petición listada es de tipo Listado Reclamacion
	 * Tienen un tratamiento distinto. 
	 * @return
	 */
	public boolean esListadoReclamacion(){
		return 
		(Constantes.PETICION_LISTADO_RECLAMACION.equalsIgnoreCase(peticionesPantalla.getPeticionProcesoSelected().getPeticion().getCodigo()));
	}
	
	public void generarFicheroReclamacion(){
		PeticionProceso peticion = peticionesPantalla.getPeticionProcesoSelected();
		//obtenemos la lista de registros de la petición
		List<PeticionExcelTmp> datosPeticion = peticionesBo.getDatosExcelPeticion(peticion,paginationData.getPaginationDataForExcel());
		
		
		
		String retorno = new String("\r\n");
		
		FacesContext context = FacesContext.getCurrentInstance();
		HttpServletResponse response = (HttpServletResponse)extCtx.getResponse();
		response.setContentType("text/plain");
		
		if (GenericUtils.isNullOrBlank(peticion.getObservacion())){
			response.addHeader("Content-disposition", "attachment; filename=\"PeticionExcel.csv");	
		}else{
			response.addHeader("Content-disposition", "attachment; filename=\"" + peticion.getObservacion());	
		}
		
		try {
			ServletOutputStream os = response.getOutputStream();
			
			//for(String linea: lineas){
			for(PeticionExcelTmp peticionExcel: datosPeticion){
				String campoDatos = "";
				if (GenericUtils.isNullOrBlank(peticionExcel.getDatos2())){
					campoDatos = peticionExcel.getDatos();
				}else{
					campoDatos = peticionExcel.getDatos().concat(peticionExcel.getDatos2());	
				}
				
				os.write(campoDatos.getBytes());		
				os.write(retorno.getBytes());
			}			
			os.flush();
			os.close();
			context.responseComplete();
		} catch(Exception e) {
			log.error("\nFailure : " + e.toString() + "\n");
		}
	
	
	/**
	 * 
	 * 
	 * 
	 * 
	 * 
	 */
//		List<String> nombresFichero = peticionDao.obtenerNombresFichero();
//		if(!GenericUtils.isNullOrBlank(nombresFichero) && !nombresFichero.isEmpty()){
//			try{
//				for(String nombreFichero : nombresFichero){
//					ArrayList<String> lineasFichero = peticionDao.generarFichero(nombreFichero);
//					if (GenericUtils.in(codListado, 14,15,17,18)){
//						FacesContext context = FacesContext.getCurrentInstance();
//						HttpServletResponse response = (HttpServletResponse)extCtx.getResponse();
//						response.setContentType("text/plain");
//
//						response.addHeader("Content-disposition", "attachment; filename=\"" + nombreFichero);
//						try {
//							ServletOutputStream os = response.getOutputStream();
//							
//							for(String linea: lineasFichero){				
//								os.write(linea.getBytes());		
//								os.write(carryReturn.getBytes());
//							}			
//							os.flush();
//							os.close();
//							context.responseComplete();
//						} catch(Exception e) {
//							log.error("\nFailure : " + e.toString() + "\n");
//					}
//					}else{
//						
//						log.info(" Guardando fichero " + dirListados+File.separatorChar+ nombreFichero  );
//						bw = new BufferedWriter(new FileWriter(dirListados+File.separatorChar+ nombreFichero));							
//						for(String lineaFichero : lineasFichero){
//						      bw.write(lineaFichero + "\n");
//						}
//						bw.close();
//						bw=null;
//					}
//				}
//			}catch (Exception e) {
//				log.error(e);
//				throw e;
//			} finally {
//				if (bw!=null){
//					try {
//						bw.close();
//					} catch (Exception e2) {
//
//					}
//				}
//				for(String nombreFichero : nombresFichero){
//					log.info(" borrando fichero " + dirListados+File.separatorChar+ nombreFichero  );
//					peticionDao.borrarFichero(nombreFichero);
//				}
//				
//			}
//
//		}
	
	
	/***
	 * 
	 */
	
	
	
	
	}
	
	/**
	 * Indica si la petición listada es de tipo escel o no 
	 * @return
	 */
	public boolean esPeticionExcel(){
		return peticionesPantalla.getPeticionProcesoSelected().getPeticion().getCodigo().toUpperCase().indexOf("EXCEL")!=-1;
	}
	/**
	 * Generar excel de la petición
	 * @param peticion
	 */
	public void generarFicheroPeticion(){
		PeticionProceso peticion = peticionesPantalla.getPeticionProcesoSelected();
		//obtenemos la lista de registros de la petición
		List<PeticionExcelTmp> datosPeticion = peticionesBo.getDatosExcelPeticion(peticion,paginationData.getPaginationDataForExcel());

		String retorno = new String("\r\n");
		
		FacesContext context = FacesContext.getCurrentInstance();
		HttpServletResponse response = (HttpServletResponse)extCtx.getResponse();
		response.setContentType("text/plain");

		response.addHeader("Content-disposition", "attachment; filename=\"PeticionExcel.csv");
			
		try {
			ServletOutputStream os = response.getOutputStream();
			
			//for(String linea: lineas){
			for(PeticionExcelTmp peticionExcel: datosPeticion){
				
				String campoDatos = "";
				
				if (GenericUtils.isNullOrBlank(peticionExcel.getDatos2())){
					campoDatos = peticionExcel.getDatos();
				}else{
					campoDatos = peticionExcel.getDatos().concat(peticionExcel.getDatos2());	
				}
				
				os.write(campoDatos.getBytes());		
				os.write(retorno.getBytes());
			}			
			os.flush();
			os.close();
			context.responseComplete();
		} catch(Exception e) {
			log.error("\nFailure : " + e.toString() + "\n");
		}

		

	}

	public boolean isEsDetalle() {
		return esDetalle;
	}

	public void setEsDetalle(boolean esDetalle) {
		this.esDetalle = esDetalle;
	}

	public PaginationData getPaginationCopy() {
		return paginationCopy;
	}

	public void setPaginationCopy(PaginationData paginationCopy) {
		this.paginationCopy = paginationCopy;
	}

	public boolean isVerErroneos() {
		return verErroneos;
	}

	public void setVerErroneos(boolean verErroneos) {
		this.verErroneos = verErroneos;
	}

}

