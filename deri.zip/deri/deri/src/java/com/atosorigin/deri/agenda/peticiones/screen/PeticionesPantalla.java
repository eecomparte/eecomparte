package com.atosorigin.deri.agenda.peticiones.screen;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.jboss.seam.ScopeType;
import org.jboss.seam.annotations.Name;
import org.jboss.seam.annotations.Out;
import org.jboss.seam.annotations.Scope;
import org.jboss.seam.annotations.datamodel.DataModel;
import org.jboss.seam.annotations.datamodel.DataModelSelection;

import com.atosorigin.deri.model.peticiones.DescripcionEstadoPeticion;
import com.atosorigin.deri.model.peticiones.DescripcionTipoPeticion;
import com.atosorigin.deri.model.peticiones.PeticionDatos;
import com.atosorigin.deri.model.peticiones.PeticionProceso;

@Name("peticionesPantalla")
@Scope(ScopeType.CONVERSATION)
public class PeticionesPantalla {
	
	/**
	 * Criterios de selección
	 */
	protected DescripcionTipoPeticion descripcionTipoPeticion;
	protected DescripcionEstadoPeticion descripcionEstadoPeticion;
	
	protected Date fechaPetiDesde;
	protected Date fechaPetiHasta;
	
	protected String usuario;
		
    protected Long idPeticion;
	/*
	 * Campos específicos del detalle de la petición
	 */
	protected Date fechaPeticion;
	
	@DataModel(value="detallePeticionProceso")
	protected List<PeticionDatos> detallePeticionProceso;
	


	
	@DataModel(value="listaPeticionProceso")
	protected List<PeticionProceso> listaPeticionProceso;
	
	@DataModelSelection(value="listaPeticionProceso")
	protected PeticionProceso peticionProcesoSelected;

	@Out(required=false, value="listaTipoPeticion")
	protected List<DescripcionTipoPeticion> listaTipoPeticion;

	@Out(required=false, value="listaEstadoPeticion")
	protected List<DescripcionEstadoPeticion> listaEstadoPeticion;
	
	protected ArrayList<String> errores = new ArrayList<String>();

	public DescripcionTipoPeticion getDescripcionTipoPeticion() {
		return descripcionTipoPeticion;
	}
	public void setDescripcionTipoPeticion(
			DescripcionTipoPeticion descripcionTipoPeticion) {
		this.descripcionTipoPeticion = descripcionTipoPeticion;
	}
	public DescripcionEstadoPeticion getDescripcionEstadoPeticion() {
		return descripcionEstadoPeticion;
	}
	public void setDescripcionEstadoPeticion(
			DescripcionEstadoPeticion descripcionEstadoPeticion) {
		this.descripcionEstadoPeticion = descripcionEstadoPeticion;
	}
	public Date getFechaPetiDesde() {
		return fechaPetiDesde;
	}
	public void setFechaPetiDesde(Date fechaPetiDesde) {
		this.fechaPetiDesde = fechaPetiDesde;
	}
	public Date getFechaPetiHasta() {
		return fechaPetiHasta;
	}
	public void setFechaPetiHasta(Date fechaPetiHasta) {
		this.fechaPetiHasta = fechaPetiHasta;
	}
	public String getUsuario() {
		return usuario;
	}
	public void setUsuario(String usuario) {
		this.usuario = usuario;
	}
	public List<PeticionProceso> getListaPeticionProceso() {
		return listaPeticionProceso;
	}
	public void setListaPeticionProceso(List<PeticionProceso> listaPeticionProceso) {
		this.listaPeticionProceso = listaPeticionProceso;
	}
	public PeticionProceso getPeticionProcesoSelected() {
		return peticionProcesoSelected;
	}
	public void setPeticionProcesoSelected(PeticionProceso peticionProcesoSelected) {
		this.peticionProcesoSelected = peticionProcesoSelected;
	}
	public List<DescripcionTipoPeticion> getListaTipoPeticion() {
		return listaTipoPeticion;
	}
	public void setListaTipoPeticion(List<DescripcionTipoPeticion> listaTipoPeticion) {
		this.listaTipoPeticion = listaTipoPeticion;
	}
	public List<DescripcionEstadoPeticion> getListaEstadoPeticion() {
		return listaEstadoPeticion;
	}
	public void setListaEstadoPeticion(
			List<DescripcionEstadoPeticion> listaEstadoPeticion) {
		this.listaEstadoPeticion = listaEstadoPeticion;
	}
	public ArrayList<String> getErrores() {
		return errores;
	}
	public void setErrores(ArrayList<String> errores) {
		this.errores = errores;
	}

	/*
	 * Campos de la pantalla de detalle petición
	 */
	public Date getFechaPeticion() {
		return fechaPeticion;
	}
	public void setFechaPeticion(Date fechaPeticion) {
		this.fechaPeticion = fechaPeticion;
	}
	public List<PeticionDatos> getDetallePeticionProceso() {
		return detallePeticionProceso;
	}
	public void setDetallePeticionProceso(List<PeticionDatos> detallePeticionProceso) {
		this.detallePeticionProceso = detallePeticionProceso;
	}
	public Long getIdPeticion() {
		return idPeticion;
	}
	public void setIdPeticion(Long idPeticion) {
		this.idPeticion = idPeticion;
	}
}
