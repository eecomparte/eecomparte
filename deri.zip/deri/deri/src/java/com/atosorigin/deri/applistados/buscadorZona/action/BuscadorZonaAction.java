package com.atosorigin.deri.applistados.buscadorZona.action;

import java.util.List;

import org.jboss.seam.ScopeType;
import org.jboss.seam.annotations.In;
import org.jboss.seam.annotations.Name;
import org.jboss.seam.annotations.Scope;

import com.atosorigin.common.action.PaginatedListAction;
import com.atosorigin.common.formvalidator.FormValidator;
import com.atosorigin.deri.appListados.listados.business.PeticionBo;
import com.atosorigin.deri.applistados.buscadorZona.screen.BuscadorZonaPantalla;
import com.atosorigin.deri.model.appListados.Zona;

@Name("buscadorZonaAction")
@Scope(ScopeType.CONVERSATION)
@FormValidator
public class BuscadorZonaAction extends PaginatedListAction{

	/**
	 * Inyección del bean de Spring "PeticionBo" que contiene los métodos de negocio
	 * para el caso de uso mantenimiento de listados.
	 */
	@In("#{peticionBo}")
	protected PeticionBo peticionBo;

	/**
	 * Inyección del screen bean que contiene los datos de pantalla del caso de uso
	 * mantenimiento de listados.
	 */
	@In(create=true)
	protected  BuscadorZonaPantalla buscadorZonaPantalla;
	
	/**
	 * Actualiza la lista del grid de zonas.
	 */
	public void buscar() {
		refrescarLista();
		setPrimerAcceso(false);
	}

	//Métodos necesarios para pantallas con grids.
	//Es necesario implementar estos métodos abstractos de PaginatedListAction
	@Override
	public List<Zona> getDataTableList() {
		return buscadorZonaPantalla.getZonaList();
	}

	@Override
	@SuppressWarnings("unchecked")
	public void setDataTableList(List<?> dataTableList) {
		buscadorZonaPantalla.setZonaList((List<Zona>)dataTableList);
	}

	@SuppressWarnings("unchecked")
	@Override
	protected void refreshListInternal() {
		List ql = (List)peticionBo.buscarZonas(buscadorZonaPantalla.getNombreReducido(), paginationData); 
		buscadorZonaPantalla.setZonaList(ql);
		
	}

	@SuppressWarnings("unchecked")
	@Override
	public void refrescarListaExcel() {
		List ql = (List)peticionBo.buscarZonas(null, paginationData);
		buscadorZonaPantalla.setZonaList(ql);
		
	}
	
}
