package com.atosorigin.deri.applistados.buscadorZona.screen;

import java.util.List;

import org.jboss.seam.ScopeType;
import org.jboss.seam.annotations.Name;
import org.jboss.seam.annotations.Out;
import org.jboss.seam.annotations.Scope;
import org.jboss.seam.annotations.datamodel.DataModel;
import org.jboss.seam.annotations.datamodel.DataModelSelection;

import com.atosorigin.deri.model.appListados.Zona;

@Name("buscadorZonaPantalla")
@Scope(ScopeType.CONVERSATION)
public class BuscadorZonaPantalla {

	/** Descripcion. Criterio de búsqueda de zonas  */
	protected String nombreReducido;
	
	
	/** Lista de datos para el grid. */
	@DataModel(value ="listaBuscadorZona")
	protected List<Zona> zonaList;
	
	/** Zona seleccionada en el grid */
	@DataModelSelection(value ="listaBuscadorZona")
    @Out(required=false)
    protected Zona zonas;

	public String getNombreReducido() {
		return nombreReducido;
	}

	public void setNombreReducido(String nombreReducido) {
		this.nombreReducido = nombreReducido;
	}

	/**
	 * Obtiene la Lista de datos para el grid.
	 * 
	 * @return la lista de zonas que mostrará el grid de resultados de la búsqueda.
	 */
	public List<Zona> getZonaList() {
		return zonaList;
	}
	
	/**
	 * Establece la Lista de datos para el grid.
	 * 
	 * @param zonaList la lista de zonas del grid.
	 */
	public void setZonaList(List<Zona> zonaList) {
		this.zonaList = zonaList;
	}
	
	public Zona getZonas() {
		return zonas;
	}
	
	public void setZonas(Zona zonas) {
		this.zonas = zonas;
	}

}
