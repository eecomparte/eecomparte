package com.atosorigin.deri.applistados.buscadorconsulta.action;

import java.util.List;

import org.jboss.seam.ScopeType;
import org.jboss.seam.annotations.In;
import org.jboss.seam.annotations.Name;
import org.jboss.seam.annotations.Scope;

import com.atosorigin.common.action.PaginatedListAction;
import com.atosorigin.common.formvalidator.FormValidator;
import com.atosorigin.deri.appListados.consulta.business.ConsultaCustomizadaBo;
import com.atosorigin.deri.applistados.buscadorconsulta.screen.BuscadorConsultaCoPantalla;
import com.atosorigin.deri.model.appListados.Consulta;

@Name("buscadorConsultaCoAction")
@Scope(ScopeType.CONVERSATION)
@FormValidator
public class BuscadorConsultaCoAction extends PaginatedListAction{

	/**
	 * Inyección del bean de Spring "ConsultaCustomizadaBo" que contiene los métodos de negocio
	 * para el caso de uso de generar consultas en ficheros.
	 */
	@In("#{consultaCustomizadaBo}")
	protected ConsultaCustomizadaBo consultaCustomizadaBo;

	/**
	 * Inyección del screen bean que contiene los datos de pantalla del caso de uso
	 * mantenimiento de listados.
	 */
	@In(create=true)
	protected BuscadorConsultaCoPantalla buscadorConsultaCoPantalla;
	
	/**
	 * Actualiza la lista del grid de consultas.
	 */
	public void buscar() {
		refrescarLista();
		setPrimerAcceso(false);
	}

	//Métodos necesarios para pantallas con grids.
	@Override
	public List<Consulta> getDataTableList() {
		return buscadorConsultaCoPantalla.getConsultacoList();
	}

	@Override
	@SuppressWarnings("unchecked")
	public void setDataTableList(List<?> dataTableList) {
		buscadorConsultaCoPantalla.setConsultacoList((List<Consulta>)dataTableList);
	}

	@SuppressWarnings("unchecked")
	@Override
	protected void refreshListInternal() {
		List<Consulta> ql = (List<Consulta>)consultaCustomizadaBo.buscarConsulta(buscadorConsultaCoPantalla.getCodigo(),paginationData);
		buscadorConsultaCoPantalla.setConsultacoList(ql);
	}

	@SuppressWarnings("unchecked")
	@Override
	public void refrescarListaExcel() {
		List ql = (List)consultaCustomizadaBo.buscarConsulta(buscadorConsultaCoPantalla.getCodigo(), paginationData);
		buscadorConsultaCoPantalla.setConsultacoList(ql);
		
	}

	public BuscadorConsultaCoPantalla getBuscadorConsultaCoPantalla() {
		return buscadorConsultaCoPantalla;
	}

	public void setBuscadorConsultaCoPantalla(
			BuscadorConsultaCoPantalla buscadorConsultaCoPantalla) {
		this.buscadorConsultaCoPantalla = buscadorConsultaCoPantalla;
	}
	
}
