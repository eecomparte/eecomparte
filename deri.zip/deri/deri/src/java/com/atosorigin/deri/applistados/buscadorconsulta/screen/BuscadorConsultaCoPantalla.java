package com.atosorigin.deri.applistados.buscadorconsulta.screen;

import java.util.List;

import org.jboss.seam.ScopeType;
import org.jboss.seam.annotations.Name;
import org.jboss.seam.annotations.Out;
import org.jboss.seam.annotations.Scope;
import org.jboss.seam.annotations.datamodel.DataModel;
import org.jboss.seam.annotations.datamodel.DataModelSelection;

import com.atosorigin.deri.model.appListados.Consulta;


@Name("buscadorConsultaCoPantalla")
@Scope(ScopeType.CONVERSATION)
public class BuscadorConsultaCoPantalla {

	/** Codigo. Criterio de búsqueda de zonas  */
	protected String codigo;
	
	
	/** Lista de datos para el grid. */
	@DataModel(value ="listaBuscadorConsultaCo")
	protected List<Consulta> consultacoList;
	
	/** Consulta seleccionada en el grid */
	@DataModelSelection(value ="listaBuscadorConsultaCo")
    @Out(required=false)
    protected Consulta consultas;

	/**
	 * Establece la Lista de datos para el grid.
	 */
	public List<Consulta> getConsultacoList() {
		return consultacoList;
	}

	public void setConsultacoList(List<Consulta> consultacoList) {
		this.consultacoList = consultacoList;
	}

	public Consulta getConsultas() {
		return consultas;
	}

	public void setConsultas(Consulta consultas) {
		this.consultas = consultas;
	}

	public String getCodigo() {
		return codigo;
	}

	public void setCodigo(String codigo) {
		this.codigo = codigo;
	}

}
