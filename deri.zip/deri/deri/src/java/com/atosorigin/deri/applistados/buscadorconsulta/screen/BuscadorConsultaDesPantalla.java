package com.atosorigin.deri.applistados.buscadorconsulta.screen;

import java.util.List;

import org.jboss.seam.ScopeType;
import org.jboss.seam.annotations.Name;
import org.jboss.seam.annotations.Out;
import org.jboss.seam.annotations.Scope;
import org.jboss.seam.annotations.datamodel.DataModel;
import org.jboss.seam.annotations.datamodel.DataModelSelection;

import com.atosorigin.deri.model.appListados.Consulta;


@Name("buscadorConsultaDesPantalla")
@Scope(ScopeType.CONVERSATION)
public class BuscadorConsultaDesPantalla {

	/** Codigo. Criterio de búsqueda de consultas  */
	protected String descripcion;
	
	
	/** Lista de datos para el grid. */
	@DataModel(value ="listaBuscadorConsultaDes")
	protected List<Consulta> consultadesList;
	
	/** Consulta seleccionada en el grid */
	@DataModelSelection(value ="listaBuscadorConsultaDes")
    @Out(required=false)
    protected Consulta consultas;

	/**
	 * Establece la Lista de datos para el grid.
	 */
	public List<Consulta> getConsultadesList() {
		return consultadesList;
	}

	public void setConsultadesList(List<Consulta> consultadesList) {
		this.consultadesList = consultadesList;
	}

	public Consulta getConsultas() {
		return consultas;
	}

	public void setConsultas(Consulta consultas) {
		this.consultas = consultas;
	}

	public String getDescripcion() {
		return descripcion;
	}

	public void setDescripcion(String descripcion) {
		this.descripcion = descripcion;
	}

}
