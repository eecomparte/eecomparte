package com.atosorigin.deri.applistados.buscadoroperaciones.action;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.jboss.seam.ScopeType;
import org.jboss.seam.annotations.Create;
import org.jboss.seam.annotations.In;
import org.jboss.seam.annotations.Name;
import org.jboss.seam.annotations.Out;
import org.jboss.seam.annotations.Scope;
import org.jboss.seam.annotations.TransactionPropagationType;
import org.jboss.seam.annotations.Transactional;
import org.jboss.seam.international.Messages;
import org.jboss.seam.international.StatusMessage.Severity;
import org.jboss.seam.security.Credentials;

import com.atosorigin.common.action.PaginatedListAction;
import com.atosorigin.common.constantes.Constantes;
import com.atosorigin.common.utils.GenericUtils;
import com.atosorigin.deri.appListados.circularizacion.business.CircularizacionBo;
import com.atosorigin.deri.applistados.buscadoroperaciones.screen.BusquedaOperacionesPantalla;
import com.atosorigin.deri.common.reports.OracleReports;
import com.atosorigin.deri.common.reports.Report;
import com.atosorigin.deri.model.appListados.Circular;
import com.atosorigin.deri.model.appListados.CircularId;
import com.atosorigin.deri.model.appListados.OperacionCircular;
import com.atosorigin.deri.model.appListados.OperacionCircularColat;
import com.atosorigin.deri.model.appListados.OperacionCircularDedalo;
import com.atosorigin.deri.model.appListados.OperacionCircularDeri;
import com.atosorigin.deri.model.catalogo.Producto;
import com.atosorigin.deri.model.contrapartida.Contrapartida;
import com.atosorigin.deri.model.gestionoperaciones.Operacion;
import com.atosorigin.deri.model.gestionoperaciones.OperacionId;
import com.atosorigin.deri.model.reports.ControlReport;
import com.atosorigin.deri.seguridad.pantalla.business.PantallaBo;
import com.atosorigin.deri.util.ConfiguracionDeri;
import com.atosorigin.deri.util.MessageBoxAction;
import com.atosorigin.deri.util.MsgBoxAction;
import com.atosorigin.deri.util.VerJasperReport;


@Name("busquedaOperacionesAction")
@Scope(ScopeType.CONVERSATION)
public class BusquedaOperacionesAction extends PaginatedListAction{

	@In(create=true)
	protected BusquedaOperacionesPantalla busquedaOperacionesPantalla;
	
	@In("#{circularizacionBo}")
	protected CircularizacionBo circularizacionBo;

	@In("#{pantallaBo}")
	protected PantallaBo pantallaBo;

	@In(create = true)
	private MsgBoxAction msgBoxAction;

	protected boolean muestraAlta;
	
	protected Boolean bloquearBotonAlta = true;
	
	@Out(required=false,value="reports")
	private List<OracleReports> oracleReports;
	
	@In Credentials credentials;
	
	@In(value="configuracionDeri")
	ConfiguracionDeri configuracionDeri;
	
	@Out(required=false,value="jasperReports")
	private List<VerJasperReport> jasperReports;

	@Out(required = false, value = "busquedaOperacionesMessageBoxAction")
	private MessageBoxAction messageBoxbusquedaOperacionesAction;
	
	// Parametros por el components.properties
	private String userId;
	private String pathForms;
	private String pathEjecutable;
	private String execMode;
	private boolean mostrarInformes;
	
	private HashSet<OperacionCircular> listasSeleccionadas = new HashSet<OperacionCircular>();	

	
	@Create
	public void onCreate(){
		assert configuracionDeri!=null;
		userId = configuracionDeri.getUserId();
		pathForms = configuracionDeri.getPathForms();
		pathEjecutable = configuracionDeri.getPathEjecutable();
		execMode = configuracionDeri.getExecMode();
		
		
	}	
	
	public String generarInforme(){
		if (circularizacionBo.getContrapartidaCircular(busquedaOperacionesPantalla.getIdContrapaBusq())!=null){
			busquedaOperacionesPantalla.setContrapaReport(circularizacionBo.getContrapartidaCircular(busquedaOperacionesPantalla.getIdContrapaBusq()));
			if(busquedaOperacionesPantalla.getContrapaReport().getTipoContrapartida() == Constantes.DIVISA_TIPO_B){
				busquedaOperacionesPantalla.setIdiomaRep("I");
			}else{
				busquedaOperacionesPantalla.setIdiomaRep("C");
			}
			if (busquedaOperacionesPantalla.getContrapaReport()!=null){
				String direccion = busquedaOperacionesPantalla.getContrapaReport().getDireccion();
				if(GenericUtils.isNullOrBlank(direccion))direccion="";
				String ciudad = busquedaOperacionesPantalla.getContrapaReport().getCiudad();
				if(GenericUtils.isNullOrBlank(ciudad))ciudad="";
				String pais = busquedaOperacionesPantalla.getContrapaReport().getPais();
				if(GenericUtils.isNullOrBlank(pais))pais="";
				String adreca = direccion + '\n' + ciudad + '\n' + pais;
				busquedaOperacionesPantalla.setDireccion(adreca);
			}
			return Constantes.SUCCESS;	
		}else{
			msgBoxAction.mostrarMsg("#{msgBoxAction.voidFunction()}", "", Messages.instance().get("circular.mensaje.errorContrapa"));
			msgBoxAction.setReRenderSi("aceptarPanel");
			return Constantes.FAIL; 

		}
	}
	
	
	public void provaFuncio(){
		msgBoxAction.setMostrarMensaje(false);
	}
	
	public void grabarDatosDericont() {
//		List<OperacionCircular> listaOpers = busquedaOperacionesPantalla.getListaOperacionesCirculares();
		
		if (!GenericUtils.isNullOrBlank(getListasSeleccionadas())) {
			for (OperacionCircular oper : getListasSeleccionadas()) {
//				if (contains(oper)) {
					Circular circular = new Circular(new CircularId());
					circular.getId().setProyecto(busquedaOperacionesPantalla.getAplicacionBusq());
					Operacion op = new Operacion();
					op.setId(new OperacionId(oper.getFechaContratacion(), oper.getNumeroOperacion()));
					circular.getId().setNcorrela(op.getId().getNumeroOperacion());
					circular.getId().setFechaope(op.getId().getFechaContratacion());
					
					circular.getId().setFechareg(busquedaOperacionesPantalla.getFechaSelecBusq());
					circular.setProducto(circularizacionBo.getProducto(oper.getProducto()));
					circular.setFechaval(oper.getFechaValor());
					circular.setFechaven(oper.getFechaVencimiento());
					circular.setDivisapa(oper.getDivisa());
					circular.setNominapa(oper.getNominal());
					circular.setCampotex(credentials.getUsername());
					if (Constantes.APLICACION_DERI.equals(busquedaOperacionesPantalla.getAplicacionBusq())) {
						OperacionCircularDeri deri = getOperacionDeri(oper);
						if (!GenericUtils.isNullOrBlank(deri)) {
							circular.setDivisapa(deri.getDivisaPago());
							circular.setNominapa(deri.getNominalPago());
							circular.setInpafiva(deri.getIndicadorTipoPago());
							circular.setPortippa(deri.getPorcenTipoFijoPago());
							circular.setBasecapa(deri.getBaseCalculoPago());
							circular.setCodforpa(deri.getCodigoFormulaPago());
							circular.setDivisare(deri.getDivisaRecibo());
							circular.setNominare(deri.getNominalRecibo());
							circular.setInrefiva(deri.getReciboFijoVariable());
							circular.setPortipre(deri.getPorcentajeTipoFijoRecibo());
							circular.setCodforre(deri.getCodigoFormulaRecibo());
							circular.setNomiinip(deri.getNomiinip());
							circular.setNomiinir(deri.getNomiinir());
						}
					}
					circularizacionBo.grabarDatosDericont(circular);
//				}
			}
			
		}
	}
	
	@Transactional(TransactionPropagationType.SUPPORTS)
	public void cerrarBorrar(){
		if(!Constantes.APLICACION_MMOO.equals(busquedaOperacionesPantalla.getAplicacionBusq())){
			circularizacionBo.borrarDatosCircular(busquedaOperacionesPantalla.getAplicacionBusq(), busquedaOperacionesPantalla.getFechaSelecBusq(), credentials.getUsername());
			circularizacionBo.flush();
		}	
	}
	
	@Transactional(TransactionPropagationType.SUPPORTS)
	public String aceptar(){
		//if (busquedaOperacionesPantalla.getContrapaReport().getPersonaContacto() != null){
			oracleReports = new ArrayList<OracleReports>();
			jasperReports = new ArrayList<VerJasperReport>();
	
			final String informe = GenericUtils.equals("I",
					busquedaOperacionesPantalla.getIdiomaRep()) ? "DERIINGL"
					: "DERICAST";
			if(Constantes.APLICACION_MMOO.equals(busquedaOperacionesPantalla.getAplicacionBusq())){
				VerJasperReport report = new VerJasperReport(informe,credentials.getUsername(),null,
						busquedaOperacionesPantalla.getFechaSelecBusq(),busquedaOperacionesPantalla.getContrapaReport().getId(),busquedaOperacionesPantalla.getContrapaReport().getDescLarga(),
						busquedaOperacionesPantalla.getDireccion(),null);
				report.cargaDatosInforme(pantallaBo);
				jasperReports.add(report);

				
			}else{
//				circularizacionBo.borrarDatosCircular(busquedaOperacionesPantalla.getAplicacionBusq(), busquedaOperacionesPantalla.getFechaSelecBusq(), credentials.getUsername());
//				circularizacionBo.flush();
				
				grabarDatosDericont();
				circularizacionBo.flush();

				VerJasperReport report = new VerJasperReport(informe,credentials.getUsername(),null,
						busquedaOperacionesPantalla.getFechaSelecBusq(),busquedaOperacionesPantalla.getContrapaReport().getId(),busquedaOperacionesPantalla.getContrapaReport().getDescLarga(),
						busquedaOperacionesPantalla.getDireccion(),null);
				report.cargaDatosInforme(pantallaBo);
				jasperReports.add(report);

				final ControlReport controlReport = new ControlReport();

				Set<String> idproductos=new HashSet<String>();
//				List<OperacionCircular> listaOpers = ; 
//					busquedaOperacionesPantalla.getListaOperacionesCirculares();
				
				if (!GenericUtils.isNullOrBlank(getListasSeleccionadas())) {
					for (OperacionCircular oper : getListasSeleccionadas()) {
//						if (contains(oper)) {			
							idproductos.add(oper.getProducto());
//						}
					}
				}
				
				List<Producto> productos=new ArrayList<Producto>();		
				for (String idproducto : idproductos) {
					productos.add(circularizacionBo.getProducto(idproducto));
				}			
				
				for (Producto producto : productos) {
					if("I".equalsIgnoreCase(busquedaOperacionesPantalla.getIdiomaRep())) {
						reportsIngles(producto,controlReport);
					} else {
						reportsCastellano(producto,controlReport);
					}
				}
			}
			this.setMostrarInformes(true);
//		}else{
//			this.setMostrarInformes(false);
//		}
		return Constantes.SUCCESS;	

	}
	
	public void runReport(String reportString){
		Report report = null;
				 
		report = circularizacionBo.runReport(userId, pathForms, pathEjecutable, execMode, reportString, busquedaOperacionesPantalla.getFechaSelecBusq(),  busquedaOperacionesPantalla.getContrapaReport().getDescLarga(), busquedaOperacionesPantalla.getDireccion(), busquedaOperacionesPantalla.getContrapaReport().getPersonaContacto(),busquedaOperacionesPantalla.getContrapaReport().getId());
		OracleReports oracleReport = new OracleReports();
		oracleReport.setReport(report);
		oracleReport.setOnClickJS(report.getOnClick());
		oracleReport.setLinkValue(report.getInformeName());
		oracleReports.add(oracleReport);
		
	}
	
	public void runJasperReport(String reportCode, String username, String producto,
			Date fechaReg, String idContrapartida, String descContrapartida,
			String direccion, String personaContacto){

		VerJasperReport report = new VerJasperReport(reportCode,username,producto,fechaReg,idContrapartida,descContrapartida,direccion,personaContacto);
		report.cargaDatosInforme(pantallaBo);
		jasperReports.add(report);
	}

	
	public void reportsCastellano(Producto producto, ControlReport controlReport) {
			
		if("751201".equalsIgnoreCase(producto.getId()) || "751202".equalsIgnoreCase(producto.getId()) || " 00004".equalsIgnoreCase(producto.getId())) {
			if("N".equalsIgnoreCase(controlReport.getP_751201())) {
				//runReport("C8751201");
				runJasperReport("C8751201",credentials.getUsername(),producto.getId(),
					busquedaOperacionesPantalla.getFechaSelecBusq()/*fechaReg*/,
					busquedaOperacionesPantalla.getContrapaReport().getId(),
					busquedaOperacionesPantalla.getContrapaReport().getDescLarga(), 
					busquedaOperacionesPantalla.getDireccion(), 
					busquedaOperacionesPantalla.getContrapaReport().getPersonaContacto());
				controlReport.setP_751201("S");
			}
		}else if("751055".equalsIgnoreCase(producto.getId())|| " 00003".equalsIgnoreCase(producto.getId())){
			//runReport("C8751055");
			//verJasperReport.verPDF
			if("N".equalsIgnoreCase(controlReport.getP_751055())) {
				runJasperReport("C8751055",credentials.getUsername(),producto.getId(),
						busquedaOperacionesPantalla.getFechaSelecBusq()/*fechaReg*/,
						busquedaOperacionesPantalla.getContrapaReport().getId(), 
						busquedaOperacionesPantalla.getContrapaReport().getDescLarga(), 
						busquedaOperacionesPantalla.getDireccion(), 
						busquedaOperacionesPantalla.getContrapaReport().getPersonaContacto());
				controlReport.setP_751055("S");
			}
		}else if("751204".equalsIgnoreCase(producto.getId())){
			
			int migradas = circularizacionBo.countMigradas(busquedaOperacionesPantalla.getFechaSelecBusq());
			int nomigradas = circularizacionBo.countNoMigradas(busquedaOperacionesPantalla.getFechaSelecBusq());
		      
			if(nomigradas > 0 ){
				//runReport("C8751204");

				runJasperReport("C8750204",credentials.getUsername(),producto.getId(),
						busquedaOperacionesPantalla.getFechaSelecBusq()/*fechaReg*/,
						busquedaOperacionesPantalla.getContrapaReport().getId(), 
						busquedaOperacionesPantalla.getContrapaReport().getDescLarga(), 
						busquedaOperacionesPantalla.getDireccion(), 
						busquedaOperacionesPantalla.getContrapaReport().getPersonaContacto());
			}
			if(migradas > 0 ){

				runJasperReport("C8751204",credentials.getUsername(),producto.getId(),
						busquedaOperacionesPantalla.getFechaSelecBusq()/*fechaReg*/,
						busquedaOperacionesPantalla.getContrapaReport().getId(), 
						busquedaOperacionesPantalla.getContrapaReport().getDescLarga(), 
						busquedaOperacionesPantalla.getDireccion(), 
						busquedaOperacionesPantalla.getContrapaReport().getPersonaContacto());
			}
				
		}else if("751404".equalsIgnoreCase(producto.getId()) || "751408".equalsIgnoreCase(producto.getId()) 
				|| " 00013".equalsIgnoreCase(producto.getId()) || " 00014".equalsIgnoreCase(producto.getId())
				|| " 00015".equalsIgnoreCase(producto.getId()) ) {
			if("N".equalsIgnoreCase(controlReport.getP_751404())) {
				//runReport("C8751404");
				runJasperReport("C8751404",credentials.getUsername(),producto.getId(),
						busquedaOperacionesPantalla.getFechaSelecBusq()/*fechaReg*/,
						busquedaOperacionesPantalla.getContrapaReport().getId(), 
						busquedaOperacionesPantalla.getContrapaReport().getDescLarga(), 
						busquedaOperacionesPantalla.getDireccion(), 
						busquedaOperacionesPantalla.getContrapaReport().getPersonaContacto());
				controlReport.setP_751404("S");
			}
		}else if("751402".equalsIgnoreCase(producto.getId()) || "751409".equalsIgnoreCase(producto.getId())
				|| "751415".equalsIgnoreCase(producto.getId()) || "751418".equalsIgnoreCase(producto.getId())) {
			if("N".equalsIgnoreCase(controlReport.getP_751402())) {
				runReport("C8751402");
				runJasperReport("C8751402",credentials.getUsername(),producto.getId(),
						busquedaOperacionesPantalla.getFechaSelecBusq()/*fechaReg*/,
						busquedaOperacionesPantalla.getContrapaReport().getId(), 
						busquedaOperacionesPantalla.getContrapaReport().getDescLarga(), 
						busquedaOperacionesPantalla.getDireccion(), 
						busquedaOperacionesPantalla.getContrapaReport().getPersonaContacto());
				controlReport.setP_751402("S");
			}
		}else if("751403".equalsIgnoreCase(producto.getId()) || "751407".equalsIgnoreCase(producto.getId())
				|| "751412".equalsIgnoreCase(producto.getId()) || "751413".equalsIgnoreCase(producto.getId())
				|| "751421".equalsIgnoreCase(producto.getId()) || "751422".equalsIgnoreCase(producto.getId())
				|| " 00010".equalsIgnoreCase(producto.getId()) || " 00011".equalsIgnoreCase(producto.getId())) {
			if("N".equalsIgnoreCase(controlReport.getP_751403())) {
				//runReport("C8751403");
				runJasperReport("C8751403",credentials.getUsername(),producto.getId(),
						busquedaOperacionesPantalla.getFechaSelecBusq()/*fechaReg*/,
						busquedaOperacionesPantalla.getContrapaReport().getId(), 
						busquedaOperacionesPantalla.getContrapaReport().getDescLarga(), 
						busquedaOperacionesPantalla.getDireccion(), 
						busquedaOperacionesPantalla.getContrapaReport().getPersonaContacto());
				controlReport.setP_751403("S");
			}
		}else if("751401".equalsIgnoreCase(producto.getId()) || "751406".equalsIgnoreCase(producto.getId())) {
			if("N".equalsIgnoreCase(controlReport.getP_751401())) {
				//runReport("C8751401");
				runJasperReport("C8751401",credentials.getUsername(),producto.getId(),
						busquedaOperacionesPantalla.getFechaSelecBusq()/*fechaReg*/,
						busquedaOperacionesPantalla.getContrapaReport().getId(), 
						busquedaOperacionesPantalla.getContrapaReport().getDescLarga(), 
						busquedaOperacionesPantalla.getDireccion(), 
						busquedaOperacionesPantalla.getContrapaReport().getPersonaContacto());
				controlReport.setP_751401("S");
			}
		}else if("751410".equalsIgnoreCase(producto.getId()) || "751411".equalsIgnoreCase(producto.getId())) {
			if("N".equalsIgnoreCase(controlReport.getP_751410())) {
				//runReport("C8751410");
				runJasperReport("C8751410",credentials.getUsername(),producto.getId(),
						busquedaOperacionesPantalla.getFechaSelecBusq()/*fechaReg*/,
						busquedaOperacionesPantalla.getContrapaReport().getId(), 
						busquedaOperacionesPantalla.getContrapaReport().getDescLarga(), 
						busquedaOperacionesPantalla.getDireccion(), 
						busquedaOperacionesPantalla.getContrapaReport().getPersonaContacto());
				controlReport.setP_751410("S");
			}
		}else if("751205".equalsIgnoreCase(producto.getId()) || "751206".equalsIgnoreCase(producto.getId()) ||
				"751207".equalsIgnoreCase(producto.getId()) || "751208".equalsIgnoreCase(producto.getId()) || 
				"751209".equalsIgnoreCase(producto.getId())){
			//Agrupamos estos listados: pintan el mismo informe variando solo el producto de la consulta
			String informe = "C8"+producto.getId();
			runJasperReport(informe,credentials.getUsername(),producto.getId(),
					busquedaOperacionesPantalla.getFechaSelecBusq()/*fechaReg*/,
					busquedaOperacionesPantalla.getContrapaReport().getId(), 
					busquedaOperacionesPantalla.getContrapaReport().getDescLarga(), 
					busquedaOperacionesPantalla.getDireccion(), 
					busquedaOperacionesPantalla.getContrapaReport().getPersonaContacto());

		}else if("751214".equalsIgnoreCase(producto.getId())|| "751213".equalsIgnoreCase(producto.getId()) 
				||  " 00002".equalsIgnoreCase(producto.getId())) {
			if("N".equalsIgnoreCase(controlReport.getP_751214())) {
				//runReport("C8751214");
				runJasperReport("C8751214",credentials.getUsername(),null,
						busquedaOperacionesPantalla.getFechaSelecBusq()/*fechaReg*/,
						busquedaOperacionesPantalla.getContrapaReport().getId(), 
						busquedaOperacionesPantalla.getContrapaReport().getDescLarga(), 
						busquedaOperacionesPantalla.getDireccion(), 
						busquedaOperacionesPantalla.getContrapaReport().getPersonaContacto());
				controlReport.setP_751214("S");
			}
		}else if("751419".equalsIgnoreCase(producto.getId()) || "751416".equalsIgnoreCase(producto.getId())
				|| "751417".equalsIgnoreCase(producto.getId()) || "751420".equalsIgnoreCase(producto.getId())) {
			if("N".equalsIgnoreCase(controlReport.getP_751419())) {
				//runReport("C8751219");
				runJasperReport("C8751419",credentials.getUsername(),null,
						busquedaOperacionesPantalla.getFechaSelecBusq()/*fechaReg*/,
						busquedaOperacionesPantalla.getContrapaReport().getId(), 
						busquedaOperacionesPantalla.getContrapaReport().getDescLarga(), 
						busquedaOperacionesPantalla.getDireccion(), 
						busquedaOperacionesPantalla.getContrapaReport().getPersonaContacto());
				controlReport.setP_751419("S");
			}
		}else if(" 00007".equalsIgnoreCase(producto.getId()) || " 00008".equalsIgnoreCase(producto.getId())){
			if("N".equalsIgnoreCase(controlReport.getP_00007())) { 
				//runReport("C8000007");
				runJasperReport("C8000007",credentials.getUsername(),producto.getId(),
					busquedaOperacionesPantalla.getFechaSelecBusq()/*fechaReg*/,
					busquedaOperacionesPantalla.getContrapaReport().getId(), 
					busquedaOperacionesPantalla.getContrapaReport().getDescLarga(), 
					busquedaOperacionesPantalla.getDireccion(), 
					busquedaOperacionesPantalla.getContrapaReport().getPersonaContacto());
				controlReport.setP_00007("S");
			}
		}
	}
	
	

	private void reportsIngles(Producto producto, ControlReport controlReport) {
		
		circularizacionBo.countNoMigradas(busquedaOperacionesPantalla.getFechaSelecBusq());
		
		if("751201".equalsIgnoreCase(producto.getId()) || "751202".equalsIgnoreCase(producto.getId())|| " 00004".equalsIgnoreCase(producto.getId())) {
			if("N".equalsIgnoreCase(controlReport.getP_751201())) {
				//runReport("C2751201");
				runJasperReport("C2751201",credentials.getUsername(),producto.getId(),
						busquedaOperacionesPantalla.getFechaSelecBusq()/*fechaReg*/,
						busquedaOperacionesPantalla.getContrapaReport().getId(), 
						busquedaOperacionesPantalla.getContrapaReport().getDescLarga(), 
						busquedaOperacionesPantalla.getDireccion(), 
						busquedaOperacionesPantalla.getContrapaReport().getPersonaContacto());
				controlReport.setP_751201("S");
			}
		}else if("751055".equalsIgnoreCase(producto.getId())|| " 00003".equalsIgnoreCase(producto.getId())){
			//runReport("C2751055");
			if("N".equalsIgnoreCase(controlReport.getP_751055())) {
				runJasperReport("C2751055",credentials.getUsername(),producto.getId(),
						busquedaOperacionesPantalla.getFechaSelecBusq()/*fechaReg*/,
						busquedaOperacionesPantalla.getContrapaReport().getId(), 
						busquedaOperacionesPantalla.getContrapaReport().getDescLarga(), 
						busquedaOperacionesPantalla.getDireccion(), 
						busquedaOperacionesPantalla.getContrapaReport().getPersonaContacto());
				controlReport.setP_751055("S");
			}
		}else if("751204".equalsIgnoreCase(producto.getId())){
			
			int migradas = circularizacionBo.countMigradas(busquedaOperacionesPantalla.getFechaSelecBusq());
			int nomigradas = circularizacionBo.countNoMigradas(busquedaOperacionesPantalla.getFechaSelecBusq());

			if(nomigradas > 0){
				//runReport("C2750204");
				runJasperReport("C2750204",credentials.getUsername(),producto.getId(),
						busquedaOperacionesPantalla.getFechaSelecBusq()/*fechaReg*/,
						busquedaOperacionesPantalla.getContrapaReport().getId(), 
						busquedaOperacionesPantalla.getContrapaReport().getDescLarga(), 
						busquedaOperacionesPantalla.getDireccion(), 
						busquedaOperacionesPantalla.getContrapaReport().getPersonaContacto());
			}
			if(nomigradas > 0){
				runJasperReport("C2751204",credentials.getUsername(),producto.getId(),
						busquedaOperacionesPantalla.getFechaSelecBusq()/*fechaReg*/,
						busquedaOperacionesPantalla.getContrapaReport().getId(), 
						busquedaOperacionesPantalla.getContrapaReport().getDescLarga(), 
						busquedaOperacionesPantalla.getDireccion(), 
						busquedaOperacionesPantalla.getContrapaReport().getPersonaContacto());
			}
		}else if("751404".equalsIgnoreCase(producto.getId()) || "751408".equalsIgnoreCase(producto.getId()) 
				|| " 00013".equalsIgnoreCase(producto.getId()) || " 00014".equalsIgnoreCase(producto.getId())
				|| " 00015".equalsIgnoreCase(producto.getId()) ) {
			if("N".equalsIgnoreCase(controlReport.getP_751404())) {
				//runReport("C2751404");
				runJasperReport("C2751404",credentials.getUsername(),producto.getId(),
						busquedaOperacionesPantalla.getFechaSelecBusq()/*fechaReg*/,
						busquedaOperacionesPantalla.getContrapaReport().getId(), 
						busquedaOperacionesPantalla.getContrapaReport().getDescLarga(), 
						busquedaOperacionesPantalla.getDireccion(), 
						busquedaOperacionesPantalla.getContrapaReport().getPersonaContacto());
				controlReport.setP_751404("S");
			}
		}else if("751402".equalsIgnoreCase(producto.getId()) || "751409".equalsIgnoreCase(producto.getId())
				|| "751415".equalsIgnoreCase(producto.getId()) || "751418".equalsIgnoreCase(producto.getId())) {
			if("N".equalsIgnoreCase(controlReport.getP_751402())) {
				//runReport("C2751402");
				runJasperReport("C2751402",credentials.getUsername(),producto.getId(),
						busquedaOperacionesPantalla.getFechaSelecBusq()/*fechaReg*/,
						busquedaOperacionesPantalla.getContrapaReport().getId(), 
						busquedaOperacionesPantalla.getContrapaReport().getDescLarga(), 
						busquedaOperacionesPantalla.getDireccion(), 
						busquedaOperacionesPantalla.getContrapaReport().getPersonaContacto());
				controlReport.setP_751402("S");
			}
		}else if("751403".equalsIgnoreCase(producto.getId()) || "751407".equalsIgnoreCase(producto.getId())
				|| "751412".equalsIgnoreCase(producto.getId()) || "751413".equalsIgnoreCase(producto.getId())
				|| "751421".equalsIgnoreCase(producto.getId()) || "751422".equalsIgnoreCase(producto.getId())
				|| " 00010".equalsIgnoreCase(producto.getId()) || " 00011".equalsIgnoreCase(producto.getId())) {
			if("N".equalsIgnoreCase(controlReport.getP_751403())) {
				//runReport("C2751403");
				runJasperReport("C2751403",credentials.getUsername(),producto.getId(),
						busquedaOperacionesPantalla.getFechaSelecBusq()/*fechaReg*/,
						busquedaOperacionesPantalla.getContrapaReport().getId(), 
						busquedaOperacionesPantalla.getContrapaReport().getDescLarga(), 
						busquedaOperacionesPantalla.getDireccion(), 
						busquedaOperacionesPantalla.getContrapaReport().getPersonaContacto());
				controlReport.setP_751403("S");
			}
		}else if("751401".equalsIgnoreCase(producto.getId()) || "751406".equalsIgnoreCase(producto.getId())) {
			if("N".equalsIgnoreCase(controlReport.getP_751401())) {
				//runReport("C2751401");
				runJasperReport("C2751401",credentials.getUsername(),producto.getId(),
						busquedaOperacionesPantalla.getFechaSelecBusq()/*fechaReg*/,
						busquedaOperacionesPantalla.getContrapaReport().getId(), 
						busquedaOperacionesPantalla.getContrapaReport().getDescLarga(), 
						busquedaOperacionesPantalla.getDireccion(), 
						busquedaOperacionesPantalla.getContrapaReport().getPersonaContacto());
				controlReport.setP_751401("S");
			}
		}else if("751410".equalsIgnoreCase(producto.getId()) || "751411".equalsIgnoreCase(producto.getId())) {
			if("N".equalsIgnoreCase(controlReport.getP_751410())) {
				//runReport("C2751410");
				runJasperReport("C2751410",credentials.getUsername(),producto.getId(),
						busquedaOperacionesPantalla.getFechaSelecBusq()/*fechaReg*/,
						busquedaOperacionesPantalla.getContrapaReport().getId(), 
						busquedaOperacionesPantalla.getContrapaReport().getDescLarga(), 
						busquedaOperacionesPantalla.getDireccion(), 
						busquedaOperacionesPantalla.getContrapaReport().getPersonaContacto());
				controlReport.setP_751410("S");
			}
		}else if("751205".equalsIgnoreCase(producto.getId()) || "751206".equalsIgnoreCase(producto.getId()) ||
				"751207".equalsIgnoreCase(producto.getId()) || "751208".equalsIgnoreCase(producto.getId()) || 
				"751209".equalsIgnoreCase(producto.getId())){
			//Agrupamos estos listados: pintan el mismo informe y varía solo el producto de la consulta
			String informe = "C2"+producto.getId();
			runJasperReport(informe,credentials.getUsername(),producto.getId(),
					busquedaOperacionesPantalla.getFechaSelecBusq()/*fechaReg*/,
					busquedaOperacionesPantalla.getContrapaReport().getId(), 
					busquedaOperacionesPantalla.getContrapaReport().getDescLarga(), 
					busquedaOperacionesPantalla.getDireccion(), 
					busquedaOperacionesPantalla.getContrapaReport().getPersonaContacto());

		}else if("751214".equalsIgnoreCase(producto.getId())|| "751213".equalsIgnoreCase(producto.getId()) 
				||  " 00002".equalsIgnoreCase(producto.getId())) {
			if("N".equalsIgnoreCase(controlReport.getP_751214())) {
				//runReport("C2751214");
				runJasperReport("C2751214",credentials.getUsername(),null,
						busquedaOperacionesPantalla.getFechaSelecBusq()/*fechaReg*/,
						busquedaOperacionesPantalla.getContrapaReport().getId(), 
						busquedaOperacionesPantalla.getContrapaReport().getDescLarga(), 
						busquedaOperacionesPantalla.getDireccion(), 
						busquedaOperacionesPantalla.getContrapaReport().getPersonaContacto());
				controlReport.setP_751214("S");
			}
		}else if("751419".equalsIgnoreCase(producto.getId()) || "751416".equalsIgnoreCase(producto.getId())
				|| "751417".equalsIgnoreCase(producto.getId()) || "751420".equalsIgnoreCase(producto.getId())) {
			if("N".equalsIgnoreCase(controlReport.getP_751419())) {
				//runReport("C2751219");
				runJasperReport("C2751419",credentials.getUsername(),null,
						busquedaOperacionesPantalla.getFechaSelecBusq()/*fechaReg*/,
						busquedaOperacionesPantalla.getContrapaReport().getId(), 
						busquedaOperacionesPantalla.getContrapaReport().getDescLarga(), 
						busquedaOperacionesPantalla.getDireccion(), 
						busquedaOperacionesPantalla.getContrapaReport().getPersonaContacto());
				controlReport.setP_751419("S");
			}
		}else if(" 00007".equalsIgnoreCase(producto.getId()) || " 00008".equalsIgnoreCase(producto.getId())){
			if("N".equalsIgnoreCase(controlReport.getP_00007())) { 
				//runReport("C2000007");
				runJasperReport("C2000007",credentials.getUsername(),null,
						busquedaOperacionesPantalla.getFechaSelecBusq()/*fechaReg*/,
						busquedaOperacionesPantalla.getContrapaReport().getId(), 
						busquedaOperacionesPantalla.getContrapaReport().getDescLarga(), 
						busquedaOperacionesPantalla.getDireccion(), 
						busquedaOperacionesPantalla.getContrapaReport().getPersonaContacto());
				controlReport.setP_00007("S");
			}
		}

	}
	
	public void nuevo(){
		muestraAlta = !muestraAlta;
		if(!muestraAlta){
			busquedaOperacionesPantalla.setFechaOperAlta(null);
			busquedaOperacionesPantalla.setnCorrelaAlta(null);
		}
	}
	
	public String buscar(){
		if (Constantes.APLICACION_MMOO.equals(busquedaOperacionesPantalla.getAplicacionBusq())) {
			busquedaOperacionesPantalla.setContrapaReport(circularizacionBo.getContrapartidaCircular(busquedaOperacionesPantalla.getIdContrapaBusq()));
		}
		muestraAlta = false;
		paginationData.reset();
		setPrimerAcceso(false);
		bloquearBotonAlta = false;
		deSelectAll();
		this.busquedaOperacionesPantalla.setSelecTodos(false);	
		refrescarLista();
		return busquedaOperacionesPantalla.getAplicacionBusq();
	}
	
	public void cambioSeleccion(){
		bloquearBotonAlta = true;
	}
	
	
	private void buildListaCircular(List<?> lista){
		List<OperacionCircular> listaResult = new ArrayList<OperacionCircular>();
		OperacionCircular operActual = null;
		for(Object oper : lista){
			operActual = buildCircular(oper);
			listaResult.add(operActual);
		}
		setDataTableList(listaResult);
		
	}
	
	private OperacionCircular buildCircular(Object vo){
			OperacionCircular operActual = null;
			if(!GenericUtils.isNullOrBlank(vo)){
				if(vo instanceof OperacionCircularColat){
					OperacionCircularColat oper = (OperacionCircularColat) vo;
					operActual = new OperacionCircular();
					operActual.setNumeroOperacion(oper.getId().getContrasw());
					operActual.setFechaContratacion(oper.getId().getFechaContratacion());
					operActual.setProducto(oper.getProducto());
					operActual.setFechaValor(oper.getFechaValor());
					operActual.setNominal(oper.getNominal());
					operActual.setDivisa(oper.getDivisa());
					operActual.setFechaVencimiento(oper.getFechaVencimiento());
				}
				else if(vo instanceof OperacionCircularDedalo){
					OperacionCircularDedalo oper = (OperacionCircularDedalo) vo;
					operActual = new OperacionCircular();
					operActual.setNumeroOperacion(oper.getId().getNumeroOperacion());
					operActual.setFechaContratacion(oper.getId().getFechaContratacion());
					operActual.setProducto(oper.getProducto());
					operActual.setFechaValor(oper.getFechaValor());
					operActual.setNominal(oper.getNominal());
					operActual.setDivisa(oper.getDivisa());
					operActual.setFechaVencimiento(oper.getFechaVencimiento());
				}
				else if(vo instanceof OperacionCircularDeri){
					OperacionCircularDeri oper = (OperacionCircularDeri) vo;
					operActual = new OperacionCircular();
					operActual.setNumeroOperacion(oper.getId().getNumeroOperacion());
					operActual.setFechaContratacion(oper.getId().getFechaContratacion());
					operActual.setProducto(oper.getProducto());
					operActual.setFechaValor(oper.getFechaValor());
					operActual.setNominal(oper.getNominal());
					operActual.setDivisa(oper.getDivisa());
					operActual.setFechaVencimiento(oper.getFechaVencimiento());
				}else{
					OperacionCircular oper = (OperacionCircular) vo;
					operActual = new OperacionCircular();
					operActual.setNumeroOperacion(oper.getNumeroOperacion());
					operActual.setFechaContratacion(oper.getFechaContratacion());
					operActual.setProducto(oper.getProducto());
					operActual.setFechaValor(oper.getFechaValor());
					operActual.setNominal(oper.getNominal());
					operActual.setDivisa(oper.getDivisa());
					operActual.setFechaVencimiento(oper.getFechaVencimiento());

					
				}
			}
			return operActual;
	}
	
	/*
	 *  METODOS DEL PAGINATED LIST ACTION 
	 */
	@Override
	public List<?> getDataTableList() {
		return busquedaOperacionesPantalla.getListaOperacionesCirculares();
	}

	@Override
	protected void refreshListInternal() {
		setExportExcel(false);
		String producto = null;
		
		if(!GenericUtils.isNullOrBlank(busquedaOperacionesPantalla.getProductoBusqueda())){
			producto = busquedaOperacionesPantalla.getProductoBusqueda().getId();
		}
		String contrapartida = busquedaOperacionesPantalla.getIdContrapaBusq();
		Date fechaSeleccion = busquedaOperacionesPantalla.getFechaSelecBusq();
		
		if (Constantes.APLICACION_COLAT.equals(busquedaOperacionesPantalla.getAplicacionBusq())) {
			List<OperacionCircularColat> lista = circularizacionBo.obtenerOperacionCircularColat(producto, contrapartida, fechaSeleccion, paginationData);
			buildListaCircular(lista);
			busquedaOperacionesPantalla.setListaOperacionesCircularesColat(lista);
		}
		if (Constantes.APLICACION_DEDALO.equals(busquedaOperacionesPantalla.getAplicacionBusq())) {
			List<OperacionCircularDedalo> lista = circularizacionBo.obtenerOperacionCircularDedalo(producto, contrapartida, fechaSeleccion, paginationData);
			buildListaCircular(lista);
			busquedaOperacionesPantalla.setListaOperacionesCircularesDedalo(lista);
		}
		if (Constantes.APLICACION_DERI.equals(busquedaOperacionesPantalla.getAplicacionBusq())) {
			List<OperacionCircularDeri> lista = circularizacionBo.obtenerOperacionCircularDeri(producto, contrapartida, fechaSeleccion, paginationData);
			buildListaCircular(lista);
			busquedaOperacionesPantalla.setListaOperacionesCircularesDeri(lista);

		}
		if(GenericUtils.isNullOrBlank(busquedaOperacionesPantalla.getListaOperacionesCirculares()) || busquedaOperacionesPantalla.getListaOperacionesCirculares().isEmpty()){
			bloquearBotonAlta = true;
		}else{
			bloquearBotonAlta = false;
		}
		if (Constantes.APLICACION_MMOO.equals(busquedaOperacionesPantalla.getAplicacionBusq())) {
			bloquearBotonAlta = true;
		}
		
		
	}

	public OperacionCircularDeri getOperacionDeri(OperacionCircular operCircular){
		
//		private Date fechaTratamiento; fecselecc
//		private Date fechaContratacion;
//		private long numeroOperacion;
		
		OperacionCircularDeri oper = null;
		oper =  circularizacionBo.addOperacionCircularDeri(busquedaOperacionesPantalla.getFechaSelecBusq(), operCircular.getFechaContratacion(), operCircular.getNumeroOperacion());
		return oper;

//		List<OperacionCircularDeri> listaDeri = busquedaOperacionesPantalla.getListaOperacionesCircularesDeri();
//		
//		String divisa = operCircular.getDivisa();
//		Date fechaContr = operCircular.getFechaContratacion();
//		Date fechaval = operCircular.getFechaValor();
//		Date fechaven = operCircular.getFechaVencimiento();
//		BigDecimal nominal = operCircular.getNominal();
//		Long numnoper = operCircular.getNumeroOperacion();
//		String producto = operCircular.getProducto();
//		
//		String divisaDeri;
//		Date fechaContrDeri;
//		Date fechavalDeri;
//		Date fechavenDeri;
//		BigDecimal nominalDeri;
//		Long numnoperDeri;
//		String productoDeri;		
//		
//		for(OperacionCircularDeri deri : listaDeri){
//			
//			divisaDeri = deri.getDivisa();
//			fechaContrDeri = deri.getId().getFechaContratacion();
//			fechavalDeri = deri.getFechaValor();
//			fechavenDeri = deri.getFechaVencimiento();
//			nominalDeri = deri.getNominal();
//			numnoperDeri = deri.getId().getNumeroOperacion();
//			productoDeri = deri.getProducto();
//			if((!GenericUtils.isNullOrBlank(divisa) && divisa.equals(divisaDeri)) 
//					|| (GenericUtils.isNullOrBlank(divisa) && GenericUtils.isNullOrBlank(divisaDeri))){
//			
//				if((!GenericUtils.isNullOrBlank(fechaContr) && fechaContr.equals(fechaContrDeri)) 
//						|| (GenericUtils.isNullOrBlank(fechaContr) && GenericUtils.isNullOrBlank(fechaContrDeri))){
//					if((!GenericUtils.isNullOrBlank(fechaval) && fechaval.equals(fechavalDeri)) 
//							|| (GenericUtils.isNullOrBlank(fechaval) && GenericUtils.isNullOrBlank(fechavalDeri))){
//						if((!GenericUtils.isNullOrBlank(fechaven) && fechaven.equals(fechavenDeri)) 
//								|| (GenericUtils.isNullOrBlank(fechaven) && GenericUtils.isNullOrBlank(fechavenDeri))){
//							if((!GenericUtils.isNullOrBlank(nominal) && nominal.equals(nominalDeri)) 
//									|| (GenericUtils.isNullOrBlank(nominal) && GenericUtils.isNullOrBlank(nominalDeri))){
//								if((!GenericUtils.isNullOrBlank(numnoper) && numnoper.equals(numnoperDeri)) 
//										|| (GenericUtils.isNullOrBlank(numnoper) && GenericUtils.isNullOrBlank(numnoperDeri))){
//									if((!GenericUtils.isNullOrBlank(producto) && producto.equals(productoDeri)) 
//											|| (GenericUtils.isNullOrBlank(producto) && GenericUtils.isNullOrBlank(productoDeri))){
//										return deri;
//										
//									}
//								}
//							}
//						}
//					}
//				}
//			}
//			
//		}
//		return null;
	}	
	
	
	public void anadirOperacion(){
		
//		testPDf();
		
		Date fechaReg = busquedaOperacionesPantalla.getFechaSelecBusq();
		Date fechaContratacion = busquedaOperacionesPantalla.getFechaOperAlta();
		Long numeroOperacion = busquedaOperacionesPantalla.getnCorrelaAlta();
		OperacionCircular operacionAnadida = null;
		if (Constantes.APLICACION_COLAT.equals(busquedaOperacionesPantalla.getAplicacionBusq())) {
			OperacionCircularColat oper = circularizacionBo.addOperacionCircularColat(fechaReg, fechaContratacion, numeroOperacion);
			busquedaOperacionesPantalla.getListaOperacionesCircularesColat().add(oper);
			operacionAnadida = buildCircular (oper);
			
		}
		if (Constantes.APLICACION_DEDALO.equals(busquedaOperacionesPantalla.getAplicacionBusq())) {
			OperacionCircularDedalo oper = circularizacionBo.addOperacionCircularDedalo(fechaReg, fechaContratacion, numeroOperacion);
			busquedaOperacionesPantalla.getListaOperacionesCircularesDedalo().add(oper);
			operacionAnadida = buildCircular (oper);
		}
		if (Constantes.APLICACION_DERI.equals(busquedaOperacionesPantalla.getAplicacionBusq())) {
			OperacionCircularDeri oper = circularizacionBo.addOperacionCircularDeri(fechaReg, fechaContratacion, numeroOperacion);
			busquedaOperacionesPantalla.getListaOperacionesCircularesDeri().add(oper);
			operacionAnadida = buildCircular (oper);

		}
		if (Constantes.APLICACION_MMOO.equals(busquedaOperacionesPantalla.getAplicacionBusq())) {

		}
		if(!GenericUtils.isNullOrBlank(operacionAnadida)){
			busquedaOperacionesPantalla.getListaOperacionesCirculares().add(operacionAnadida);
		}else{
			statusMessages.add(Severity.ERROR ,"#{messages['circular.error.operacion']}");
		}
		
		muestraAlta = false;
	}

	@Override
	public void refrescarListaExcel() {
		setExportExcel(true);
		String producto = null;
		if(busquedaOperacionesPantalla.getProductoBusqueda()!=null)
			producto = busquedaOperacionesPantalla.getProductoBusqueda().getId();			
		String contrapartida = busquedaOperacionesPantalla.getIdContrapaBusq();
		Date fechaSeleccion = busquedaOperacionesPantalla.getFechaSelecBusq();
		
		if (Constantes.APLICACION_COLAT.equals(busquedaOperacionesPantalla.getAplicacionBusq())) {
			List<OperacionCircularColat> lista = circularizacionBo.obtenerOperacionCircularColat(producto, contrapartida, fechaSeleccion, paginationData.getPaginationDataForExcel());
			buildListaCircular(lista);
		}
		if (Constantes.APLICACION_DEDALO.equals(busquedaOperacionesPantalla.getAplicacionBusq())) {
			List<OperacionCircularDedalo> lista = circularizacionBo.obtenerOperacionCircularDedalo(producto, contrapartida, fechaSeleccion, paginationData.getPaginationDataForExcel());
			buildListaCircular(lista);
		}
		if (Constantes.APLICACION_DERI.equals(busquedaOperacionesPantalla.getAplicacionBusq())) {
			List<OperacionCircularDeri> lista = circularizacionBo.obtenerOperacionCircularDeri(producto, contrapartida, fechaSeleccion, paginationData.getPaginationDataForExcel());
			buildListaCircular(lista);

		}
		if (Constantes.APLICACION_MMOO.equals(busquedaOperacionesPantalla.getAplicacionBusq())) {

		}
		
	}

	@Override
	public void setDataTableList(List<?> dataTableList) {
		busquedaOperacionesPantalla.setListaOperacionesCirculares((List<OperacionCircular>) dataTableList);
	}
	
	
	
	
	/*
	 * GETTERS Y SETTERS
	 */
	public BusquedaOperacionesPantalla getBusquedaOperacionesPantalla() {
		return busquedaOperacionesPantalla;
	}
	
	public void setBusquedaOperacionesPantalla(
			BusquedaOperacionesPantalla busquedaOperacionesPantalla) {
		this.busquedaOperacionesPantalla = busquedaOperacionesPantalla;
	}


	public Boolean getMuestraAlta() {
		return muestraAlta;
	}

	public void setMuestraAlta(Boolean muestraAlta) {
		this.muestraAlta = muestraAlta;
	}

	public Boolean getBloquearBotonAlta() {
		return bloquearBotonAlta;
	}

	public void setBloquearBotonAlta(Boolean bloquearBotonAlta) {
		this.bloquearBotonAlta = bloquearBotonAlta;
	}

	public void setMuestraAlta(boolean muestraAlta) {
		this.muestraAlta = muestraAlta;
	}

	public CircularizacionBo getCircularizacionBo() {
		return circularizacionBo;
	}

	public void setCircularizacionBo(CircularizacionBo circularizacionBo) {
		this.circularizacionBo = circularizacionBo;
	}
	
	public boolean isMostrarInformes() {
		return mostrarInformes;
	}

	public void setMostrarInformes(boolean mostrarInformes) {
		this.mostrarInformes = mostrarInformes;
	}

	// ### FUNCIONES PARA GESTIONAR LOS CHECKBOX ###
	
	/** Seleccionar o deseleccionar todos los checks del datagrid */
	public void seleccionarTodos(){
		
//		OperacionCircular operacionCircular;
//
//		List<OperacionCircular> operacionesList = busquedaOperacionesPantalla.getListaOperacionesCirculares();
//		int tamanyoLista = operacionesList.size();
//		
//		if (tamanyoLista > paginationData.getMaxResults()){ //Cuando hay paginación el último registro no se debe tener en cuenta
//			tamanyoLista--;
//		}
		
		//Lo primero es saber si tenemos que seleccionar o deseleccionar todos. 
		//1- Caso deseleccionar
		if(busquedaOperacionesPantalla.getSelecTodos()){
			deSelectAll();
//			for (int k = 0; k < tamanyoLista; k++ ){
//				operacionCircular = operacionesList.get(k);
//				if(!GenericUtils.isNullOrBlank(operacionCircular) && operacionCircular.getSeleccionado()){
//					operacionCircular.setSeleccionado(false);
//				}
//			}			
			this.busquedaOperacionesPantalla.setSelecTodos(false);					
		} else { //Caso seleccionar
			selectAll();
//			for (int k = 0; k < tamanyoLista; k++ ){
//				operacionCircular = operacionesList.get(k);
//				if(!GenericUtils.isNullOrBlank(operacionCircular) && !operacionCircular.getSeleccionado()){
//					operacionCircular.setSeleccionado(true);
//				}
//			}			
			this.busquedaOperacionesPantalla.setSelecTodos(true);
		}
				
	}	
	
	public void selectAll(){
			
//		List<OperacionCircular> operacionesList = new ArrayList<OperacionCircular>();
		int tmpMaxResults = paginationData.getMaxResults();
		int tmpFirstResult = paginationData.getFirstResult();
		paginationData.setMaxResults(501);
		paginationData.setFirstResult(0);
		
		setExportExcel(false);
		String producto = null;
		
		if(!GenericUtils.isNullOrBlank(busquedaOperacionesPantalla.getProductoBusqueda())){
			producto = busquedaOperacionesPantalla.getProductoBusqueda().getId();
		}
		String contrapartida = busquedaOperacionesPantalla.getIdContrapaBusq();
		Date fechaSeleccion = busquedaOperacionesPantalla.getFechaSelecBusq();

		OperacionCircular operActual = null;
		listasSeleccionadas.clear();
	
		if (Constantes.APLICACION_COLAT.equals(busquedaOperacionesPantalla.getAplicacionBusq())) {
			List<OperacionCircularColat> lista = circularizacionBo.obtenerOperacionCircularColat(producto, contrapartida, fechaSeleccion, paginationData);
//			busquedaOperacionesPantalla.setListaOperacionesCircularesColat(lista);
			for(Object oper : lista){
				operActual = buildCircular(oper);
				listasSeleccionadas.add(operActual);
//				listasSeleccionadas.add((OperacionCircular) oper);
			}
		}
		if (Constantes.APLICACION_DEDALO.equals(busquedaOperacionesPantalla.getAplicacionBusq())) {
			List<OperacionCircularDedalo> lista = circularizacionBo.obtenerOperacionCircularDedalo(producto, contrapartida, fechaSeleccion, paginationData);
//			busquedaOperacionesPantalla.setListaOperacionesCircularesDedalo(lista);
			for(Object oper : lista){
				operActual = buildCircular(oper);
				listasSeleccionadas.add(operActual);
			}
		}
		if (Constantes.APLICACION_DERI.equals(busquedaOperacionesPantalla.getAplicacionBusq())) {
			List<OperacionCircularDeri> lista = circularizacionBo.obtenerOperacionCircularDeri(producto, contrapartida, fechaSeleccion, paginationData);
//			busquedaOperacionesPantalla.setListaOperacionesCircularesDeri(null);
//			busquedaOperacionesPantalla.setListaOperacionesCircularesDeri(lista);
			for(Object oper : lista){
				operActual = buildCircular(oper);
				listasSeleccionadas.add(operActual);
				
			}
		}

		
		paginationData.setMaxResults(tmpMaxResults);
		paginationData.setFirstResult(tmpFirstResult);

	}

		
		 
	@Out
	public Boolean getSelectedRow() {
		if (busquedaOperacionesPantalla.getOperacionCircularSeleccionada() != null && listasSeleccionadas != null) {
//			OperacionCircular oper = buildCircular(busquedaOperacionesPantalla.getOperacionCircularSeleccionada());
//			return contains(oper);
			return contains(busquedaOperacionesPantalla.getOperacionCircularSeleccionada());
		} else {
			return false;
		}
	}
	
	public void setSelectedRow(Boolean selected) {
		OperacionCircular oper = buildCircular(busquedaOperacionesPantalla.getOperacionCircularSeleccionada());
		if (selected) {
			if (!contains(oper)){
				listasSeleccionadas.add(oper);
			}
//			listasSeleccionadas.add((OperacionCircular) busquedaOperacionesPantalla.getOperacionCircularSeleccionada());
		} else {

			for (OperacionCircular vo : listasSeleccionadas) {
				if (vo.getFechaContratacion().equals(oper.getFechaContratacion()) &&
					(vo.getNumeroOperacion() == oper.getNumeroOperacion())
					){

					listasSeleccionadas.remove(vo);
					break;
				}
			} 

	
//			listasSeleccionadas.remove((OperacionCircular) busquedaOperacionesPantalla.getOperacionCircularSeleccionada());
		}
	}
	
	public boolean contains(OperacionCircular voSelected){
		boolean ret = false;
		for (OperacionCircular vo : listasSeleccionadas) {
			if (vo.getFechaContratacion().equals(voSelected.getFechaContratacion()) &&
				(vo.getNumeroOperacion() == voSelected.getNumeroOperacion())
				){
//			if(vo.equals(voSelected)){
				ret = true;
				break;
			}
		} 
		return ret; 
	}
	
	public void seleccionarLista(){ }


	public void deSelectAll() {
		//Este metodo borra Todos y punto
		listasSeleccionadas.clear();  //.removeAll(listaOperacionesList);
	}

	public HashSet<OperacionCircular> getListasSeleccionadas() {
		return listasSeleccionadas;
	}

	public void setListasSeleccionadas(
			HashSet<OperacionCircular> listasSeleccionadas) {
		this.listasSeleccionadas = listasSeleccionadas;
	}

	public PantallaBo getPantallaBo() {
		return pantallaBo;
	}

	public void setPantallaBo(PantallaBo pantallaBo) {
		this.pantallaBo = pantallaBo;
	}
	
	public void salir(){
		this.cerrarBorrar();
	}
	
	// ### FIN CHECKBOX ###
	
	public void init(){
		if(null==messageBoxbusquedaOperacionesAction){
			messageBoxbusquedaOperacionesAction = new MessageBoxAction();
		}
	}

	public void voidFunction(){
		msgBoxAction.voidFunction();
	}
	
	/**
	 * Mostrar PopUp cuando una contrapartida está bloqueada (no bloqueante)
	 */
	public void onVerificarContrapartidaBloqueada() {
		String contrapartida = busquedaOperacionesPantalla.getIdContrapaBusq();
		if (!GenericUtils.isNullOrBlank(contrapartida)){
			 Contrapartida contrapObtenida2 = circularizacionBo.cargarContrapartida(contrapartida.toUpperCase());	
			if (null!=contrapObtenida2 && !GenericUtils.isNullOrBlank(contrapObtenida2.getIndBloqueo()) && "S".equalsIgnoreCase(contrapObtenida2.getIndBloqueo())){
				messageBoxbusquedaOperacionesAction.init("circular.messages.contrapartida.bloqueada.texto", "busquedaOperacionesAction.voidFunction()", null,"messageBoxPanelContrapa");
			}
		}
		cambioSeleccion();
	}

}
