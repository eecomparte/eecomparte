package com.atosorigin.deri.applistados.buscadoroperaciones.screen;

import java.util.Date;
import java.util.List;

import org.jboss.seam.ScopeType;
import org.jboss.seam.annotations.Name;
import org.jboss.seam.annotations.Out;
import org.jboss.seam.annotations.Scope;
import org.jboss.seam.annotations.datamodel.DataModel;
import org.jboss.seam.annotations.datamodel.DataModelSelection;

import com.atosorigin.deri.model.appListados.ContrapartidaCircular;
import com.atosorigin.deri.model.appListados.OperacionCircular;
import com.atosorigin.deri.model.appListados.OperacionCircularColat;
import com.atosorigin.deri.model.appListados.OperacionCircularDedalo;
import com.atosorigin.deri.model.appListados.OperacionCircularDeri;
import com.atosorigin.deri.model.catalogo.Producto;


@Name("busquedaOperacionesPantalla")
@Scope(ScopeType.CONVERSATION)
public class BusquedaOperacionesPantalla {
	
	protected Producto productoBusqueda;
	
	protected String aplicacionBusq;
	
	protected String idContrapaBusq;
	
	protected Date fechaSelecBusq;

	protected Date fechaOperAlta;
	
	protected Long nCorrelaAlta;
	
	protected ContrapartidaCircular contrapaReport;
	
	protected String idiomaRep;
	
	protected String direccion;
	
	@DataModel(value="listaDtOperacionesCirculares")
	List<OperacionCircular> listaOperacionesCirculares;
	
	List<OperacionCircularDedalo> listaOperacionesCircularesDedalo;

	List<OperacionCircularColat> listaOperacionesCircularesColat;
	
	List<OperacionCircularDeri>  listaOperacionesCircularesDeri;
	
	@DataModelSelection(value="listaDtOperacionesCirculares")
	@Out(required=false)
	OperacionCircular operacionCircularSeleccionada;
	
	
	/**
	 * Selección checkbox OperacionCircular
	 */	
	protected boolean selecTodos;
	
	/*
	 * GETTERS & SETTERS
	 */
	
	public Producto getProductoBusqueda() {
		return productoBusqueda;
	}

	public void setProductoBusqueda(Producto productoBusqueda) {
		this.productoBusqueda = productoBusqueda;
	}

	public String getAplicacionBusq() {
		return aplicacionBusq;
	}

	public void setAplicacionBusq(String aplicacionBusq) {
		this.aplicacionBusq = aplicacionBusq;
	}

	public String getIdContrapaBusq() {
		return idContrapaBusq;
	}

	public void setIdContrapaBusq(String idContrapaBusq) {
		this.idContrapaBusq = idContrapaBusq;
	}

	public Date getFechaSelecBusq() {
		return fechaSelecBusq;
	}

	public void setFechaSelecBusq(Date fechaSelecBusq) {
		this.fechaSelecBusq = fechaSelecBusq;
	}

	public List<OperacionCircular> getListaOperacionesCirculares() {
		return listaOperacionesCirculares;
	}

	public void setListaOperacionesCirculares(List<OperacionCircular> listaOperacionesCirculares) {
		this.listaOperacionesCirculares = listaOperacionesCirculares;
	}

	public OperacionCircular getOperacionCircularSeleccionada() {
		return operacionCircularSeleccionada;
	}

	public void setOperacionCircularSeleccionada(OperacionCircular operacionCircularSeleccionada) {
		this.operacionCircularSeleccionada = operacionCircularSeleccionada;
	}

	public Date getFechaOperAlta() {
		return fechaOperAlta;
	}

	public void setFechaOperAlta(Date fechaOperAlta) {
		this.fechaOperAlta = fechaOperAlta;
	}

	public Long getnCorrelaAlta() {
		return nCorrelaAlta;
	}

	public void setnCorrelaAlta(Long nCorrelaAlta) {
		this.nCorrelaAlta = nCorrelaAlta;
	}

	public ContrapartidaCircular getContrapaReport() {
		return contrapaReport;
	}

	public void setContrapaReport(ContrapartidaCircular contrapaReport) {
		this.contrapaReport = contrapaReport;
	}

	public String getIdiomaRep() {
		return idiomaRep;
	}

	public void setIdiomaRep(String idiomaRep) {
		this.idiomaRep = idiomaRep;
	}

	public List<OperacionCircularDedalo> getListaOperacionesCircularesDedalo() {
		return listaOperacionesCircularesDedalo;
	}

	public void setListaOperacionesCircularesDedalo(
			List<OperacionCircularDedalo> listaOperacionesCircularesDedalo) {
		this.listaOperacionesCircularesDedalo = listaOperacionesCircularesDedalo;
	}

	public List<OperacionCircularColat> getListaOperacionesCircularesColat() {
		return listaOperacionesCircularesColat;
	}

	public void setListaOperacionesCircularesColat(
			List<OperacionCircularColat> listaOperacionesCircularesColat) {
		this.listaOperacionesCircularesColat = listaOperacionesCircularesColat;
	}

	public List<OperacionCircularDeri> getListaOperacionesCircularesDeri() {
		return listaOperacionesCircularesDeri;
	}

	public void setListaOperacionesCircularesDeri(
			List<OperacionCircularDeri> listaOperacionesCircularesDeri) {
		this.listaOperacionesCircularesDeri = listaOperacionesCircularesDeri;
	}
	public boolean getSelecTodos() {
		return selecTodos;
	}

	public void setSelecTodos(boolean selecTodos) {
		this.selecTodos = selecTodos;
	}

	public String getDireccion() {
		if(this.direccion==null) {
			return contrapaReport.getDireccion() + '\n' + contrapaReport.getCiudad() + '\n' + contrapaReport.getPais();
		}else{
			return this.direccion;
		}
	}

	public void setDireccion(String direccion) {
		this.direccion = direccion;
	}
}
