package com.atosorigin.deri.applistados.consultacustomizada.action;

import java.math.BigDecimal;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import javax.faces.context.ExternalContext;
import javax.faces.context.FacesContext;
import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServletResponse;

import org.jboss.seam.ScopeType;
import org.jboss.seam.annotations.In;
import org.jboss.seam.annotations.Name;
import org.jboss.seam.annotations.Out;
import org.jboss.seam.annotations.Scope;
import org.jboss.seam.international.StatusMessage;
import org.jboss.seam.international.StatusMessage.Severity;

import com.atosorigin.common.action.PaginatedListAction;
import com.atosorigin.common.constantes.Constantes;
import com.atosorigin.common.formvalidator.FormValidator;
import com.atosorigin.common.utils.GenericUtils;
import com.atosorigin.deri.appListados.consulta.business.ConsultaCustomizadaBo;
import com.atosorigin.deri.appListados.consulta.business.ConsultaParametroBo;
import com.atosorigin.deri.applistados.buscadorconsulta.screen.BuscadorConsultaCoPantalla;
import com.atosorigin.deri.applistados.buscadorconsulta.screen.BuscadorConsultaDesPantalla;
import com.atosorigin.deri.applistados.consutlascustomizadas.screen.ConsultaCustomizadaPantalla;
import com.atosorigin.deri.contrapartida.business.ContrapartidaBo;
import com.atosorigin.deri.model.appListados.ParamConsultaCustom;
import com.atosorigin.deri.model.appListados.ParametroConsulta;
import com.atosorigin.deri.model.contrapartida.Contrapartida;
import com.atosorigin.deri.util.MessageBoxAction;
import com.atosorigin.deri.util.MsgBoxAction;

/**
 * Clase que actúa de action listener para el caso de uso de mantenimiento de parametros conciliacion.
 */
@Name("consultaCustomizadaAction")
@Scope(ScopeType.CONVERSATION)
@FormValidator
public class ConsultaCustomizadaAction extends PaginatedListAction{

	@In(value="#{facesContext.externalContext}")
	private ExternalContext extCtx;

	/**
	 * Inyección del bean de Spring "plazoBo" que contiene los métodos de negocio
	 * para el caso de uso consultas customizadas.
	 */
	@In("#{consultaCustomizadaBo}")
	protected  ConsultaCustomizadaBo consultaCustomizadaBo;
	
	
	@In("#{consultaParametroBo}")
	protected  ConsultaParametroBo consultaParametroBo;

	@In("#{contrapartidaBo}")
	protected ContrapartidaBo contrapartidaBo;

	/** Inyeccion del componente necesario para mostrar mensajes de decisión al usuario */
	@In(create = true)
	private MsgBoxAction msgBoxAction;
	
	@Out(required = false, value = "consultaCustomizadaMessageBoxAction")
	private MessageBoxAction msgboxPanelConsultaCustomizadaContrapaBloq;
	
	/**
	 * Inyección del screen bean que contiene los datos de pantalla del caso de uso
	 * consultas customizadas.
	 */
	@In(create=true)
	protected ConsultaCustomizadaPantalla  consultaCustomizadaPantalla;
	
	@In(create=true)
	protected BuscadorConsultaCoPantalla  buscadorConsultaCoPantalla;
	
	@In(create=true)
	protected BuscadorConsultaDesPantalla  buscadorConsultaDesPantalla;
	
	public boolean generarFicheroValidator(){
		
		boolean esCorrecto = true;
		
		for (ParamConsultaCustom paramCustom : this.getDataTableList()) {
		
			//campo parametro.obligatorio
			if(Constantes.CONSTANTE_SI.equals(paramCustom.getParam().getObligatorio())){
				if(GenericUtils.isNullOrBlank(paramCustom.getValor())){
					statusMessages.addFromResourceBundle(Severity.ERROR, "consulta.error.parametronulo",paramCustom.getParam().getId().getOrden());
					esCorrecto = false;
				}
			}else if(GenericUtils.isNullOrBlank(paramCustom.getValor()))
				return esCorrecto;
							
			
			//campo parametro.tipo
			//caso de ser numero
			if(Constantes.NUMERICO.equals(paramCustom.getParam().getTipo())){
				
				try{
					BigDecimal numero = new BigDecimal(paramCustom.getValor());
					if((numero.precision() - numero.scale()) > paramCustom.getParam().getLongitud()){
						statusMessages.addFromResourceBundle(Severity.ERROR, "consulta.error.longituderronea",paramCustom.getParam().getId().getOrden(),paramCustom.getParam().getLongitud());
						esCorrecto = false;
					}
					
				}catch(NumberFormatException e){
					statusMessages.addFromResourceBundle(Severity.ERROR, "consulta.error.parametrononumerico",paramCustom.getParam().getId().getOrden());
					esCorrecto = false;
				}
				
			}
			
			//caso de ser fecha
			if(Constantes.FECHA.equals(paramCustom.getParam().getTipo())){
				if(paramCustom.getParam().getLongitud() < paramCustom.getValor().length()){
					statusMessages.addFromResourceBundle(Severity.ERROR, "consulta.error.longituderronea",paramCustom.getParam().getId().getOrden(),paramCustom.getParam().getLongitud());
					esCorrecto = false;
				}
				
				SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
				try{
					Date parametro = sdf.parse(paramCustom.getValor());
					Date fechaIni = sdf.parse("01/01/1900");
					
					long diffFechaParamIni = (parametro.getTime() - fechaIni.getTime())/86400000L;

					if (parametro.getTime() < fechaIni.getTime()){
						statusMessages.addFromResourceBundle(Severity.ERROR, "consulta.error.fechaerronea", paramCustom.getParam().getId().getOrden());
						esCorrecto = false;
					}
					
				}catch(ParseException e){
					statusMessages.addFromResourceBundle(Severity.ERROR, "consulta.error.fechaerronea", paramCustom.getParam().getId().getOrden());
					esCorrecto = false;

				}
			}		
			
			//caso de ser caracter
			if(Constantes.LONGITUD.equals(paramCustom.getParam().getTipo())){
				if(paramCustom.getParam().getLongitud()< paramCustom.getValor().length()){
					statusMessages.addFromResourceBundle(Severity.ERROR, "consulta.error.longituderronea",paramCustom.getParam().getId().getOrden(), paramCustom.getParam().getLongitud());
					esCorrecto = false;
				}
			}
		}
		
		return esCorrecto;
	}
	
	/**
	 * Actualiza la lista del grid de consutlas
	 * 
	 */
	public void buscar() {
		paginationData.reset();
		refrescarLista();
		setPrimerAcceso(false);		
	}
	
	//Métodos necesarios para pantallas con grids.
	public List<ParamConsultaCustom> getDataTableList() {
		return consultaCustomizadaPantalla.getConsultaList();
	}

	@SuppressWarnings("unchecked")
	public void setDataTableList(List<?> dataTableList) {
		consultaCustomizadaPantalla.setConsultaList((List<ParamConsultaCustom>)dataTableList);
	}

	@Override
	protected void refreshListInternal() {
		setExportExcel(false);
		
		if(buscadorConsultaCoPantalla.getConsultas() != null){
			List<ParamConsultaCustom> ql = (List<ParamConsultaCustom>)consultaParametroBo.buscarParametros(buscadorConsultaCoPantalla.getConsultas(), paginationData);
			consultaCustomizadaPantalla.setConsultaList(ql);
			buscadorConsultaCoPantalla.setConsultas(null);
		}
		if(buscadorConsultaDesPantalla.getConsultas() != null){
			List<ParamConsultaCustom> ql = (List<ParamConsultaCustom>)consultaParametroBo.buscarParametros(buscadorConsultaDesPantalla.getConsultas(), paginationData);
			consultaCustomizadaPantalla.setConsultaList(ql);
			//Ponemos el datamodel selection a nulo, para próximas busquedas
			buscadorConsultaDesPantalla.setConsultas(null);
		}
	}
	
	@Override
	public void refrescarListaExcel() {
		setExportExcel(true);
		if(buscadorConsultaCoPantalla.getConsultas() != null){
			List<ParamConsultaCustom> ql = (List<ParamConsultaCustom>)consultaParametroBo.buscarParametros(buscadorConsultaCoPantalla.getConsultas(), paginationData.getPaginationDataForExcel());
			consultaCustomizadaPantalla.setConsultaList(ql);
		}
		if(buscadorConsultaDesPantalla.getConsultas() != null){
			List<ParamConsultaCustom> ql = (List<ParamConsultaCustom>)consultaParametroBo.buscarParametros(buscadorConsultaDesPantalla.getConsultas(), paginationData.getPaginationDataForExcel());
			consultaCustomizadaPantalla.setConsultaList(ql);
		}
	}
	
	public void generarFichero(){
		Integer codigoConsulta = consultaCustomizadaPantalla.getCodigo();
		List<ParamConsultaCustom> parametroConsultaList = consultaCustomizadaPantalla.getConsultaList();
		
		
		
		if ("SI".equalsIgnoreCase(consultaCustomizadaPantalla.getIndicadorBatch())){
			Long peticion = consultaCustomizadaBo.generarPeticionBatch(codigoConsulta, parametroConsultaList);
			if (!GenericUtils.isNullOrBlank(peticion)){
				
				statusMessages.addFromResourceBundle(Severity.INFO,"consulta.batch.petición", peticion);
			}else{
				statusMessages.add(StatusMessage.Severity.ERROR, "#{messages['consulta.batch.error']}");
			}
			return ;
		}
		
		List<String> lineas = consultaCustomizadaBo.generaFichero(codigoConsulta, parametroConsultaList);

		
		String retorno = new String("\r\n");
		
		FacesContext context = FacesContext.getCurrentInstance();
		HttpServletResponse response = (HttpServletResponse)extCtx.getResponse();
		response.setContentType("text/plain");

		response.addHeader("Content-disposition", "attachment; filename=\"ConsultaCustomizada.csv");
		try {
			ServletOutputStream os = response.getOutputStream();
			
			for(String linea: lineas){				
				os.write(linea.getBytes());		
				os.write(retorno.getBytes());
			}			
			os.flush();
			os.close();
			context.responseComplete();
		} catch(Exception e) {
			log.error("\nFailure : " + e.toString() + "\n");
		}

	}
	
	public void init(){
		
		if (msgboxPanelConsultaCustomizadaContrapaBloq==null){
			msgboxPanelConsultaCustomizadaContrapaBloq = new MessageBoxAction();
		}
	}

	public void voidFunction(){
		msgBoxAction.voidFunction();
	}
	
	
	/**
	 * Valida que el parámetro tenga activo el FLAG de contrapartida.
	 * Si el FLASG es S, se verifica si la contrapartida está bloqueada.
	 * Si la contrapartida está bloqueada, se muestra PopUp indicándolo. 
	 * 
	 */
	public void verificarBloqueoValor(){
		ParametroConsulta pant = consultaCustomizadaPantalla.getConsulta().getParam();
		if(null!=consultaCustomizadaPantalla.getConsultaList()){
			for(ParamConsultaCustom actual : consultaCustomizadaPantalla.getConsultaList()){
				ParametroConsulta param = actual.getParam();
				if(null!=param.getIndicadorContrapartida() && "S".equals(param.getIndicadorContrapartida())&& pant.equals(param)){
					//Parámetro marcado con FLAG de contrapartida, hay que mirar si la contrapartida está bloqueada.
					if(null!=consultaCustomizadaPantalla.getConsulta() && null!=consultaCustomizadaPantalla.getConsulta().getValor() && consultaCustomizadaPantalla.getConsulta().getValor().trim().length()>0){
					String idContrapartida = consultaCustomizadaPantalla.getConsulta().getValor();
						Contrapartida contrapartida = contrapartidaBo.cargarContrapartida(idContrapartida.toUpperCase());
						if (null!=contrapartida && !GenericUtils.isNullOrBlank(contrapartida.getIndBloqueo()) && "S".equalsIgnoreCase(contrapartida.getIndBloqueo())){
							iniciarPopUpContrapartidaBloqueada();
							return;
						}
					}
				}
			}
		}
	}
	
	/**
	 * Muestra el PopUp de contrapartida bloqueada.
	 */
	private void iniciarPopUpContrapartidaBloqueada(){
		msgboxPanelConsultaCustomizadaContrapaBloq.init("consulta.messages.contrapartida.bloqueada.texto", "consultaCustomizadaAction.voidFunction()", null, "messageBoxPanelContrapa");
	}
}

