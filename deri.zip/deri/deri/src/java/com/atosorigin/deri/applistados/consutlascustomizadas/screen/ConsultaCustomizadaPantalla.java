package com.atosorigin.deri.applistados.consutlascustomizadas.screen;

import java.util.List;

import org.jboss.seam.ScopeType;
import org.jboss.seam.annotations.Name;
import org.jboss.seam.annotations.Out;
import org.jboss.seam.annotations.Scope;
import org.jboss.seam.annotations.datamodel.DataModel;
import org.jboss.seam.annotations.datamodel.DataModelSelection;

import com.atosorigin.deri.model.appListados.ParamConsultaCustom;

/**
 *  Contiene los datos de pantalla necesarios para el caso de uso mantenimiento de plazos.
 */
@Name("consultaCustomizadaPantalla")
@Scope(ScopeType.CONVERSATION)
public class ConsultaCustomizadaPantalla {

	/** Codigo. Criterio de búsqueda de consultas. */
	protected Integer codigo;
	
	/** Indicador de Parametro. Criterio de búsqueda de consultas.*/	
	protected String indicadorParametros;

	
	/** Indicador de Parametro. Criterio de búsqueda de consultas.*/	
	protected String indicadorBatch;
	
	/** Descripcion. Criterio de búsqueda de consultas. */
	protected String descripcion;
	
	/** Ubicacion. Criterio de búsqueda de consultas. */
	protected String ubicacion;
	
	
	/** Lista de datos para el grid. */
	@DataModel(value ="listaDtConsultasCu")
	protected List<ParamConsultaCustom> consultaList;
	
	@DataModelSelection(value ="listaDtConsultasCu")
    @Out(value="consulta", required=false)
	protected ParamConsultaCustom consulta;
	
	public List<ParamConsultaCustom> getConsultaList() {
		return consultaList;
	}

	public void setConsultaList(List<ParamConsultaCustom> consultaList) {
		this.consultaList = consultaList;
	}

	public ParamConsultaCustom getConsulta() {
		return consulta;
	}

	public void setConsulta(ParamConsultaCustom consulta) {
		this.consulta = consulta;
	}
	
	/*metodos get y set de las variables de pantalla de búsqueda*/
	public String getIndicadorParametros() {
		return indicadorParametros;
	}

	public void setIndicadorParametros(String indicadorParametros) {
		this.indicadorParametros = indicadorParametros;
	}

	public String getDescripcion() {
		return descripcion;
	}

	public void setDescripcion(String descripcion) {
		this.descripcion = descripcion;
	}

	public String getUbicacion() {
		return ubicacion;
	}

	public void setUbicacion(String ubicacion) {
		this.ubicacion = ubicacion;
	}

	public Integer getCodigo() {
		return codigo;
	}

	public void setCodigo(Integer codigo) {
		this.codigo = codigo;
	}

	public String getIndicadorBatch() {
		return indicadorBatch;
	}

	public void setIndicadorBatch(String indicadorBatch) {
		this.indicadorBatch = indicadorBatch;
	}

	
}
