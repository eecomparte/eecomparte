package com.atosorigin.deri.applistados.extractovisibilidad.action;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.jboss.seam.ScopeType;
import org.jboss.seam.annotations.In;
import org.jboss.seam.annotations.Name;
import org.jboss.seam.annotations.Scope;
import org.jboss.seam.core.ResourceBundle;
import org.jboss.seam.international.Messages;
import org.jboss.seam.international.StatusMessage.Severity;
import org.jboss.seam.security.Credentials;
import org.richfaces.event.UploadEvent;
import org.richfaces.model.UploadItem;

import com.atosorigin.common.action.PaginatedListAction;
import com.atosorigin.common.constantes.Constantes;
import com.atosorigin.common.formvalidator.FormValidator;
import com.atosorigin.common.utils.ExcelImporter;
import com.atosorigin.common.utils.GenericUtils;
import com.atosorigin.deri.appListados.visibilidad.business.ExtractoVisibilidadBo;
import com.atosorigin.deri.applistados.extractovisibilidad.screen.ExtractoVisibilidadPantalla;
import com.atosorigin.deri.model.appListados.ExtractoVisibilidad;
import com.atosorigin.deri.util.ConfiguracionDeri;

/**
 * Clase action listener para el caso de uso de titulares de la Ordén
 */
@Name("extractoVisibilidadAction")
@Scope(ScopeType.CONVERSATION)
@FormValidator
public class ExtractoVisibilidadAction extends PaginatedListAction{
	
	@In Credentials credentials;
    
	@In(create =true)
	protected ExtractoVisibilidadPantalla extractoVisibilidadPantalla;
	
	@In(value="#{extractoVisibilidadBo}")
	protected ExtractoVisibilidadBo extractoVisibilidadBo;
	
	@In(value="configuracionDeri")
	ConfiguracionDeri configuracionDeri;
	

	
	protected List<ExtractoVisibilidad> extractosTotal;
	protected List<ExtractoVisibilidad> extractosError;
	protected boolean pasaValidacion = false;
	
	protected StringBuilder mensajeConfirmacion = new StringBuilder();
	
	//booleana para mostrar o no el panel de listado de informes
	protected boolean mostrarInformesPanel;
	
	protected Boolean error = false;
	
	public boolean isMostrarInformesPanel() {
		return mostrarInformesPanel;
	}
	
	public void setMostrarInformesPanel(boolean mostrarInformesPanel) {
		this.mostrarInformesPanel = mostrarInformesPanel;
	}

	
	public void limpiarAdjuntos(){
		extractoVisibilidadPantalla.setFichero(null);
		extractosTotal = null;
		extractosError = null;
		setDataTableList(null);
		paginationData.reset();
	}
	/**
	 * Función para gestionar el upload de ficheros adjuntos
	 */
	public void uploadFile(UploadEvent event) throws IOException{
		
		UploadItem item = event.getUploadItem();
               
        if (item.isTempFile()) {
        	extractoVisibilidadPantalla.setFichero(item.getFile().getPath());	
//        	extractoVisibilidadPantalla.setFichero(item.getFileName());
//        	//SMM si no contiene : podemos suponer que version de navegador sin path.
//        	if (!extractoVisibilidadPantalla.getFichero().contains(":")){
//        		extractoVisibilidadPantalla.setFichero(item.getFile().getAbsolutePath());	
//        	}
        } else {
        	statusMessages.add(Severity.ERROR,"#{messages['extractovisibilidad.error.noarchivo']}");
        }
	}
	
	
	public void fichero(){
		String fichero = extractoVisibilidadPantalla.getFichero(); 
		String contenido;
		List<ExtractoVisibilidad> extractos = new ArrayList<ExtractoVisibilidad>();
		extractoVisibilidadPantalla.setExtractoList(null);
		paginationData.reset();
		error = false;
		if (!GenericUtils.isNullOrBlank(fichero)) {

			try {
				
				contenido = ExcelImporter.excelExtractor(fichero);
				System.out.println(contenido);
				if (!GenericUtils.isNullOrBlank(contenido)){
					extractos  = parser(contenido);	
					extractosTotal = extractos;
					setPrimerAcceso(false);
					refrescarLista();
				}
//				System.out.println(contenido);
//				ExcelImporter.read(fichero, "Workbook");
			} catch (FileNotFoundException e) {
				e.printStackTrace();
				error = true;
				statusMessages.add(Severity.ERROR,"#{messages['extractovisibilidad.error.abrir']}");
			}catch (Exception ex){
				ex.printStackTrace();
				error = true;
				if (ex!=null && !GenericUtils.isNullOrBlank(ex.getMessage())){
					statusMessages.add(Severity.ERROR,ex.getMessage());
				}else{
					statusMessages.add(Severity.ERROR,"#{messages['extractovisibilidad.error.lectura']}");	
				}
			}
		}else{
			error = true;
			statusMessages.add(Severity.ERROR,"#{messages['extractovisibilidad.error.archivo']}");
		}
	}
	
	public List<ExtractoVisibilidad> parser(String excel) throws Exception{
		SimpleDateFormat sdf = new SimpleDateFormat(Constantes.DDMMYYYY );
		List<ExtractoVisibilidad> extractos = new ArrayList<ExtractoVisibilidad>();
		List<ExtractoVisibilidad>  extractosError= new ArrayList<ExtractoVisibilidad>();
		String[] lineas = excel.split("\n");
		for (int i = 0; i < lineas.length; i++) {
			String string = lineas[i];
			String[] campos;
			// Primera línea Nombre Columna
			if (i!=0){
				campos = string.split("\t");

				String tipo = null;
				Date fechaCarga=null;
				Double oper = null;
				Long ncorrela = null;
				Date fechaope = null;
				Double valorapa = null;
				Double  valorare = null;
				Date fechavalvm = null;
				String observaciones = "";
				String divisaPago = null;
				String divisaRecibo = null;
				
				//Verificamos que tena el número de columnas acordado.
				
				if (campos.length == 0){
					continue;	
				}
				
				if (campos.length == 9){
					for (int j = 0; j < campos.length; j++) {
					 
						switch (j) {
							case 0:
								tipo = campos[j];
								break;
							case 1:
								try {
									sdf.setLenient(false);
									//Nueva columna fecha carga. Puede venir informada o no
									if (!GenericUtils.isNullOrBlank(campos[j])){
										fechaCarga = sdf.parse(campos[j]);	
									}else{
										observaciones = observaciones.concat(ResourceBundle.instance().getString("extractovisibilidad.error.formatocampo"));
										observaciones = observaciones.concat(" Fecha Carga");
										error = true;
									}
									
									break;
								} catch (ParseException e) {
									e.printStackTrace();
									observaciones = observaciones.concat(ResourceBundle.instance().getString("extractovisibilidad.error.formatocampo"));
									observaciones = observaciones.concat(" Fecha Carga");
									error = true;
									break;
								} finally {
								}
							case 2:
								try {
									oper = Double.valueOf(campos[j]);
									ncorrela = oper.longValue();
									break;
								} catch (NumberFormatException e) {
									e.printStackTrace();
									observaciones = observaciones.concat(ResourceBundle.instance().getString("extractovisibilidad.error.formatocampo"));
									observaciones = observaciones.concat(" Num.Operación");
									error = true;
									break;
								} finally {
								}
							case 3:
								// try {
								try {
									sdf.setLenient(false);
									fechaope = sdf.parse(campos[j]);
									break;
								} catch (ParseException e) {
									e.printStackTrace();
									// int a = j +1 ;
									// int b = i +1;
	
									observaciones = observaciones.concat(ResourceBundle.instance().getString("extractovisibilidad.error.formatocampo"));
									observaciones = observaciones.concat(" fechaOpe");
									// statusMessages.addFromResourceBundle(Severity.ERROR,
									// "extractovisibilidad.error.formato",
									// String.valueOf(a), String.valueOf(b));
									error = true;
									break;
								} finally {
								}
								// DateUtil.parseDate(campos[j]);
								// } catch (DateParseException e) {
								// e.printStackTrace();
								// }
	
							case 4:
								try {
									valorapa = Double.valueOf(campos[j]);
									break;
								} catch (NumberFormatException e) {
									e.printStackTrace();
									observaciones = observaciones.concat(ResourceBundle.instance().getString("extractovisibilidad.error.formatocampo"));
									observaciones = observaciones.concat(" Valoración Pago");
									error = true;
									break;
								} finally {
								}
							case 5:
								try {
									valorare = Double.valueOf(campos[j]);
									break;
								} catch (NumberFormatException e) {
									e.printStackTrace();
									observaciones = observaciones.concat(ResourceBundle.instance().getString("extractovisibilidad.error.formatocampo"));
									observaciones = observaciones.concat(" Valoración Recibo");
									error = true;
									break;
								} finally {
								}
							case 6:
								try {
									sdf.setLenient(false);
									fechavalvm = sdf.parse(campos[j]);
									break;
								} catch (ParseException e) {
									e.printStackTrace();
									observaciones = observaciones.concat(ResourceBundle.instance().getString("extractovisibilidad.error.formatocampo"));
									observaciones = observaciones.concat(" Fecha Valoración");
									error = true;
									break;
								} finally {
								}
							case 7:
								divisaPago = campos[j];
								break;
							case 8:
								divisaRecibo = campos[j];
								break;
						}
					}
//					ExtracoVi
					
					if (!comprobarTipo(tipo)){
						observaciones = observaciones.concat("\n" + ResourceBundle.instance().getString("extractovisibilidad.error.tipo"));
						error = true;
					}
					ExtractoVisibilidad registro = new ExtractoVisibilidad(tipo, fechaCarga, ncorrela, fechaope, valorapa, valorare, fechavalvm, observaciones);
					
					if (!comprobarExistenciaRegistro(registro)){
						registro.setObservaciones(observaciones.concat("\n" + ResourceBundle.instance().getString("extractovisibilidad.error.registro")));
						error = true;
					}
					
					if (!"EUR".equalsIgnoreCase(divisaPago) && valorapa!=null && valorapa!=0){
						valorapa = cambiarDivisa(fechavalvm,valorapa,divisaPago);
						if (valorapa==null){
							registro.setObservaciones(observaciones.concat("\n" + ResourceBundle.instance().getString("extractovisibilidad.error.DivisaPago")));
							error = true;
						}else{
							registro.setValorapa(valorapa);
						}
						
					}
					
					if (!"EUR".equalsIgnoreCase(divisaRecibo) && valorare!=null && valorare!=0 ){
						valorare = cambiarDivisa(fechavalvm,valorare,divisaRecibo);
						if (valorare==null){
							registro.setObservaciones(observaciones.concat("\n" + ResourceBundle.instance().getString("extractovisibilidad.error.DivisaRecibo")));
							error = true;
						}else{
							registro.setValorare(valorare);
						}

					}

					
					extractos.add(registro);
					if (error && !GenericUtils.isNullOrBlank(registro.getObservaciones())) {
						extractosError.add(registro);	
					}
					
					
					
				}else{
					statusMessages.add(Severity.ERROR,"#{messages['extractovisibilidad.error.columnas']}");
					error = true;
					throw new Exception();
				}
			}
		}
		if (error) {
			return extractosError;	
		}else{
			return extractos;	
		}
		
	}
	
	private Double cambiarDivisa(Date fechavalvm, Double valoracion, String divisa) {
		return extractoVisibilidadBo.cambiarDivisa(fechavalvm,valoracion, divisa);
	}

	private Boolean comprobarTipo(String tipo){
		if ("S".equalsIgnoreCase(tipo) || "D".equalsIgnoreCase(tipo)){
			return true;
		}else{
			return false;
		}
	}
	
	private boolean comprobarExistenciaRegistro(ExtractoVisibilidad registro) {
		return extractoVisibilidadBo.existeRegistro(registro);
	}
	@Override
	public List<ExtractoVisibilidad>  getDataTableList() {
		return extractoVisibilidadPantalla.getExtractoList();
	}
	@Override
	public void refrescarListaExcel() {
		// TODO Auto-generated method stub
		
	}
	@Override
	protected void refreshListInternal() {
		 
		Integer maxResults; 
		if (paginationData !=null && extractosTotal !=null 
				&& extractosTotal.size()!= 0){

			maxResults = paginationData.getMaxResults()*paginationData.getActivePage()+1;
			if (extractosTotal.size() < maxResults){
				maxResults = extractosTotal.size(); 
			}
			setDataTableList(extractosTotal.subList(paginationData.getFirstResult(),maxResults ));
		}
		
	}
	@Override
	public void setDataTableList(List<?> dataTableList) {
		extractoVisibilidadPantalla.setExtractoList((List<ExtractoVisibilidad> )dataTableList);
	}
	public List<ExtractoVisibilidad> getExtractosTotal() {
		return extractosTotal;
	}
	public void setExtractosTotal(List<ExtractoVisibilidad> extractosTotal) {
		this.extractosTotal = extractosTotal;
	}
	public boolean isPasaValidacion() {
		return pasaValidacion;
	}
	public void setPasaValidacion(boolean pasaValidacion) {
		this.pasaValidacion = pasaValidacion;
	}

	public void validaciones(){
		pasaValidacion = true;
		mensajeConfirmacion = new StringBuilder();
		String aviso = Messages.instance().get("parametrosLiquidacion.confirmacion.continuar");
		mensajeConfirmacion.append(aviso);
	}
	public StringBuilder getMensajeConfirmacion() {
		return mensajeConfirmacion;
	}
	public void setMensajeConfirmacion(StringBuilder mensajeConfirmacion) {
		this.mensajeConfirmacion = mensajeConfirmacion;
	}
		

	public void guardar(){
//		extractosTotal
		 extractoVisibilidadBo.guardar(extractosTotal);
		 limpiarAdjuntos();
		 statusMessages.add(Severity.INFO,"#{messages['extractovisibilidad.actualizado']}");
	}

	public Boolean getError() {
		return error;
	}

	public void setError(Boolean error) {
		this.error = error;
	}

	public List<ExtractoVisibilidad> getExtractosError() {
		return extractosError;
	}

	public void setExtractosError(List<ExtractoVisibilidad> extractosError) {
		this.extractosError = extractosError;
	}


}
