package com.atosorigin.deri.applistados.extractovisibilidad.screen;

import java.util.Date;
import java.util.List;

import org.ajax4jsf.component.html.HtmlAjaxCommandButton;
import org.jboss.seam.ScopeType;
import org.jboss.seam.annotations.In;
import org.jboss.seam.annotations.Name;
import org.jboss.seam.annotations.Out;
import org.jboss.seam.annotations.Scope;
import org.jboss.seam.annotations.datamodel.DataModel;

import com.atosorigin.deri.model.appListados.ExtractoVisibilidad;
import com.atosorigin.deri.model.appListados.Listados;

/**
 *  Contiene los datos de pantalla necesarios para el caso de uso de titulares de la ordén.
 */

@Name("extractoVisibilidadPantalla")
@Scope(ScopeType.CONVERSATION)
public class ExtractoVisibilidadPantalla {

	protected Listados listados;

	protected Date fechaListado;
	
	protected String contrapartida;
	
	/** Lista de datos para el grid. */
	@DataModel(value ="listaDtExtractoVisibilidad")
	protected List<ExtractoVisibilidad> extractoList;
	
	
	protected String fichero;
	
	@In(create=true, required = false)
	@Out(required = false)
	protected HtmlAjaxCommandButton reportButton;
	
	protected Boolean buttonVisibility = false;

	public String getContrapartida() {
		return contrapartida;
	}

	public void setContrapartida(String contrapartida) {
		this.contrapartida = contrapartida;
	}

	public Date getFechaListado() {
		return fechaListado;
	}

	public void setFechaListado(Date fechaListado) {
		this.fechaListado = fechaListado;
	}
	
	public Listados getListados() {
		return listados;
	}

	public void setListados(Listados listados) {
		this.listados = listados;
	}

	public HtmlAjaxCommandButton getReportButton() {
//		if(reportButton == null) {
//			Application app = FacesContext.getCurrentInstance().getApplication();
//			reportButton = (HtmlAjaxCommandButton)app.createComponent(HtmlAjaxCommandButton.COMPONENT_TYPE);
//			reportButton.setId("reportCommandButton");
//		}
		return reportButton;
	}

	public void setReportButton(HtmlAjaxCommandButton reportButton) {
		this.reportButton = reportButton;
	}

	public Boolean getButtonVisibility() {
		return buttonVisibility;
	}

	public void setButtonVisibility(Boolean buttonVisibility) {
		this.buttonVisibility = buttonVisibility;
	}

	public String getFichero() {
		return fichero;
	}

	public void setFichero(String fichero) {
		this.fichero = fichero;
	}

	public List<ExtractoVisibilidad> getExtractoList() {
		return extractoList;
	}

	public void setExtractoList(List<ExtractoVisibilidad> extractoList) {
		this.extractoList = extractoList;
	}	
}
