package com.atosorigin.deri.applistados.informes.action;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;

import org.jboss.seam.ScopeType;
import org.jboss.seam.annotations.In;
import org.jboss.seam.annotations.Name;
import org.jboss.seam.annotations.Scope;
import org.jboss.seam.core.Conversation;
import org.jboss.seam.international.StatusMessage.Severity;

import com.atosorigin.common.action.ModoPantalla;
import com.atosorigin.common.action.PaginatedListAction;
import com.atosorigin.common.action.PaginationData;
import com.atosorigin.common.constantes.Constantes;
import com.atosorigin.common.formvalidator.FormValidator;
import com.atosorigin.common.utils.GenericUtils;
import com.atosorigin.deri.appListados.informes.business.InformeBo;
import com.atosorigin.deri.appListados.informes.business.InformeParametroBo;
import com.atosorigin.deri.appListados.parametros.business.ParametroBo;
import com.atosorigin.deri.applistados.informes.screen.InformePantalla;
import com.atosorigin.deri.model.appListados.Informe;
import com.atosorigin.deri.model.appListados.InformeParametro;
import com.atosorigin.deri.model.appListados.InformeParametroId;
import com.atosorigin.deri.model.appListados.Parametro;
import com.atosorigin.deri.model.seguridad.NivelPrivilegioInforme;
import com.atosorigin.deri.model.seguridad.Pantalla;
import com.atosorigin.deri.model.seguridad.PantallaId;
import com.atosorigin.deri.model.seguridad.PrivilegiosInforme;
import com.atosorigin.deri.seguridad.pantalla.business.PantallaBo;
import com.atosorigin.deri.util.PaginacionUtil;

@Name("informeAction")
@Scope(ScopeType.CONVERSATION)
@FormValidator
public class InformeAction extends PaginatedListAction {

	@In("entityManager")
	private EntityManager em;
	@In("#{informeBo}")
	protected InformeBo informeBo;
	
	@In("#{informeParametroBo}")
	protected InformeParametroBo informeParametroBo;
	
	@In("#{parametroBo}")
	protected ParametroBo parametroBo;
	
	@In("#{pantallaBo}")
	protected PantallaBo pantallaBo;
	

	@In(create=true)
	protected InformePantalla informePantalla;
	
	//Variable de control, para saber cuando tenemos que actualizar la lista de informeParametro
	private boolean muestraInfoParam = false;
	private boolean muestraParam = false;
	
	private PaginationData paginationInfo = new PaginationData();
	private PaginationData paginationParam = new PaginationData();
	private PaginationData paginationInfoParam = new PaginationData();
	
	private Boolean creacionParametro = null;
	
	
	/**
	 * Actualiza la lista del grid de informes
	 * 
	 */
	public void buscar() {
		ajustaPaginationData(paginationInfo);
		paginationData.reset();
		refrescarLista();
	}

	/**
	 * Prepara para entrar en el modo edición de un informe.
	 */
	public void editar() {
		informePantalla.setInforme(informeBo.cargar(informePantalla.getInformeSelec().getId()));		
		ajustaPaginationData(paginationInfoParam);
		informePantalla.setInfoParam(informeParametroBo.obtenerParametrosInfome(informePantalla.getInforme(), paginationData));
		setModoPantalla(ModoPantalla.EDICION);
	}

	/**
	 * Prepara para entrar en el modo inspección de un informe.
	 * 
	 */
	public void ver() {
		informePantalla.setInforme(informeBo.cargar(informePantalla.getInformeSelec().getId()));		
		ajustaPaginationData(paginationInfoParam);
		informePantalla.setInfoParam(informeParametroBo.obtenerParametrosInfome(informePantalla.getInforme(), paginationData));
		setModoPantalla(ModoPantalla.INSPECCION);
	}

	/**
	 * Prepara para entrar en el modo creación de un informe.
	 * 
	 */
	public void nuevo() {
		Informe informe = new Informe();
		//Inicializamos la Ejecucion por shell
		informe.setEjecucionShell(false);
		//Instanciamos el infoParam, para que no aparezcan datos de otras creaciones anteriores
		informePantalla.setInfoParam(new ArrayList<InformeParametro>());
		informePantalla.setInforme(informe);
		//Inicializamos el nivel
		if(GenericUtils.isNullOrBlank(informePantalla.getInforme().getPrivilegiosInforme())){
			informePantalla.getInforme().setPrivilegiosInforme(new PrivilegiosInforme());
		}
		if(GenericUtils.isNullOrBlank(informePantalla.getInforme().getPrivilegiosInforme().getPrivilegioImpresion())){
			informePantalla.getInforme().getPrivilegiosInforme().setPrivilegioImpresion(new NivelPrivilegioInforme());
			informePantalla.getInforme().getPrivilegiosInforme().getPrivilegioImpresion().setNivel(0);
		}
		setModoPantalla(ModoPantalla.CREACION);
	}
	
	public void salirDetalle(){
		muestraInfoParam=false;
		muestraParam=false;
                ajustaPaginationData(paginationInfo);
		if (modoPantalla.equals(ModoPantalla.EDICION)){
			Informe informe = informePantalla.getInforme();
			if(informe!=null && !GenericUtils.isNullOrBlank(informe.getId())
					&& !GenericUtils.isNullOrBlank(informe.getId().getCodigo())){
				informeBo.recargar(informe);
			}
		}
	}
	
	/**
	 * Guarda un parametro para un informe dado
	 */
	public void guardarInformeParametro(){

		InformeParametroId  idInfPar= new InformeParametroId();
		//en caso de que el id sea nulo es porque es un alta, y formamos el id con el parametro seleccionado anteriormente
		Informe informe = informePantalla.getInforme();
		//en caso de que el id sea nulo es porque es un alta, y formamos el id con el parametro seleccionado anteriormente
		boolean esAlta = false;
		if(GenericUtils.isNullOrBlank(informePantalla.getInformeParam().getId())){
			Parametro para = informePantalla.getParamSelec();
			esAlta=true;
			
			idInfPar.setInforme(informe);
			idInfPar.setParametro(para);
			informePantalla.getInformeParam().setId(idInfPar);
		}

		if(!GenericUtils.isNullOrBlank(informePantalla.getListaParametros())){
			informePantalla.getListaParametros().clear();
		}
		
		//Si es alta a�adimos, si es modificacion modificamos
		if(!esAlta){
			
			
			for(InformeParametro info : informePantalla.getInfoParam()){
				if((GenericUtils.isNullOrBlank(info.getId().getInforme().getId().getCodigo()) || info.getId().getInforme().getId().getCodigo().equals(informePantalla.getInformeParam().getId().getInforme().getId().getCodigo()))
					&& info.getId().getInforme().getId().getProyecto().equals(informePantalla.getInformeParam().getId().getInforme().getId().getProyecto())
					&& info.getId().getParametro().getId().getProyecto().equals(informePantalla.getInformeParam().getId().getParametro().getId().getProyecto())
					&& info.getId().getParametro().getId().getNombre().equals(informePantalla.getInformeParam().getId().getParametro().getId().getNombre())
					&& info.getId().getParametro().getId().getCodigo().equals(informePantalla.getInformeParam().getId().getParametro().getId().getCodigo())
				){
					informePantalla.getInfoParam().remove(info);
					break;
				}
			}
			for(InformeParametro info : informe.getInformeParametros()){
				if((GenericUtils.isNullOrBlank(info.getId().getInforme().getId().getCodigo()) || info.getId().getInforme().getId().getCodigo().equals(informePantalla.getInformeParam().getId().getInforme().getId().getCodigo()))
					&& info.getId().getInforme().getId().getProyecto().equals(informePantalla.getInformeParam().getId().getInforme().getId().getProyecto())
					&& info.getId().getParametro().getId().getProyecto().equals(informePantalla.getInformeParam().getId().getParametro().getId().getProyecto())
					&& info.getId().getParametro().getId().getNombre().equals(informePantalla.getInformeParam().getId().getParametro().getId().getNombre())
					&& info.getId().getParametro().getId().getCodigo().equals(informePantalla.getInformeParam().getId().getParametro().getId().getCodigo())
				){
					informe.getInformeParametros().remove(info);
					break;
				}
			}
		}
		informePantalla.getInfoParam().add(informePantalla.getInformeParam());
		informe.getInformeParametros().add(informePantalla.getInformeParam());
		muestraInfoParam = true;
		creacionParametro = null;
		refrescarLista();
		muestraInfoParam=false;
		//SMM: MATA UNA CONVESACION, si estoy en Alta tengo q matar 
		//la conversación de Seleccion además de la de mantenimiento
		  if(Conversation.instance().isNested()){
	        	Conversation nested =Conversation.instance();
	        	Conversation.instance().pop();
	        	nested.end(true);
	        }
	}
	public boolean guardarInformeParametroValidator(){
		InformeParametroId  idInfPar= new InformeParametroId();
		//en caso de que el id sea nulo es porque es un alta, y formamos el id con el parametro seleccionado anteriormente
		if(GenericUtils.isNullOrBlank(informePantalla.getInformeParam().getId()) ){
			idInfPar.setInforme(informePantalla.getInforme());
			idInfPar.setParametro(informePantalla.getParamSelec());
			informePantalla.getInformeParam().setId(idInfPar);
		}
		if(!GenericUtils.isNullOrBlank(informeParametroBo.cargar(informePantalla.getInformeParam().getId())) && creacionParametro){
			statusMessages.addToControl("", Severity.ERROR, "#{messages['infoParametro.error.ordenYaExiste']}");
			return false;
		}
		return true;
	}
	
	
	/**
	 * Prepara para entrar en el modo edición de un informeParametro.
	 */
	public void editarInformeParam(){
		creacionParametro = false;
		informePantalla.setInformeParam(informePantalla.getInformeParamSelec());
		
	}
	
	/**
	 * Prepara para entrar en el modo creación de un informeParametro.
	 */
	public void nuevoInformeParam(){
		creacionParametro = true;
		informePantalla.setInformeParam(new InformeParametro());
		informePantalla.getInformeParam().setObligatorio("N");
	}
	
	/**
	 * Borra una informe.
	 * 
	 */
	public void borrar() {
		PantallaId pantallaId = new PantallaId(Constantes.NOMBRE_PROYECTO_DERI, "I", informePantalla.getInforme().getId().getCodigo());
		Pantalla pantalla = pantallaBo.cargar(pantallaId);
		if(GenericUtils.isNullOrBlank(pantalla)){
			pantallaBo.borrar(pantalla);
		}
		List<InformeParametro> listaInformes = informeParametroBo.obtenerParametrosInfome(informePantalla.getInforme(), new PaginationData().getPaginationDataForExcel());
		for(InformeParametro informeParam : listaInformes){
			informeParametroBo.borrar(informeParam);
		}
		
		informeBo.borrar(informePantalla.getInforme());
		refrescarLista();
	}
	
	/**
	 * Borra una informeParametro.
	 * 
	 */
	public void borrarParametro(){

		informePantalla.getInforme().getInformeParametros().remove(informePantalla.getInformeParamSelec());
		informePantalla.getInfoParam().clear();
		informePantalla.getInfoParam().addAll(informePantalla.getInforme().getInformeParametros());
		//muestraInfoParam = true;
		muestraInfoParam = false;
	}

	/**
	 * Graba la informe en la base de datos.
	 * 
	 */
	public String guardar() {
		informeBo.guardar(informePantalla.getInforme());
		Informe informe = informePantalla.getInforme();
		PrivilegiosInforme privilegiosInforme = informe.getPrivilegiosInforme();
		privilegiosInforme.setDescripcion(informe.getDescripcion());
		privilegiosInforme.setPathEjecutable(informe.getPathEjecutable());
		informeBo.recargar(informe);
		muestraInfoParam = false;
		muestraParam = false;
		informePantalla.setInfoParam(new ArrayList<InformeParametro>());
                //inicializamos las variables para control de paginaciones, listas, etc...
		ajustaPaginationData(paginationInfo);
		refrescarLista();
		
		return Constantes.CONSTANTE_SUCCESS;
	}
	public boolean guardarValidator(){
		if(!GenericUtils.isNullOrBlank(informeBo.cargar(informePantalla.getInforme().getId())) && modoPantalla.equals(ModoPantalla.CREACION)){
			statusMessages.addToControl("codigo", Severity.ERROR, "#{messages['informe.error.informeYaExiste']}");
			return false;
		}
		if(informePantalla.getInforme().isEjecucionShell()){
			if(GenericUtils.isNullOrBlank(informePantalla.getInforme().getShell())){
				statusMessages.addToControl("shell", Severity.ERROR, "#{messages['informe.error.shell']}");
				return false;
			}
		}
		return true;
	}
	
	/**
	 * Carga todos los parámetros válidos
	 */
	public void cargaParametros(){
		muestraParam = true;
		creacionParametro = true;		
		ajustaPaginationData(paginationParam);
		informePantalla.setCodigoParametro(null);
		paginationData.reset();
		refrescarLista();
	}

	@Override
	public List<Informe> getDataTableList() {
		return informePantalla.getListaInformes();
	}

	@Override
	@SuppressWarnings("unchecked")
	public void setDataTableList(List<?> dataTableList) {
		informePantalla.setListaInformes((List<Informe>)dataTableList);
		
	}
	
	/**
	 * Metodo encargado de ajustar el pagintaionData con los valores pasados por parametro
	 * @param pagination
	 */
	public void ajustaPaginationData(PaginationData pagination){
		paginationData.setFirstResult(pagination.getFirstResult());
		paginationData.setMaxResults(pagination.getMaxResults());
		paginationData.setMaxResults(pagination.getMaxResults());
		paginationData.setOrderKey(pagination.getOrderKey());
	}
	/**
	 * Marca las propiedades del paginationData obtenido con las del actual 
	 * @param pagination
	 */
	public void actualizaPaginationData(PaginationData pagination){
		pagination.setFirstResult(paginationData.getFirstResult());
		pagination.setMaxResults(paginationData.getMaxResults());
		pagination.setMaxResults(paginationData.getMaxResults());
		pagination.setOrderKey(paginationData.getOrderKey());
	}
	
	@SuppressWarnings("unchecked")
	@Override
	protected void refreshListInternal() {
		setPrimerAcceso(false);
		setExportExcel(false);
		if(muestraParam){
			informePantalla.setListaParametros((List)parametroBo.buscarParametros(informePantalla.getCodigoParametro(), null, paginationData));
			actualizaPaginationData(paginationParam);
		}
		else if(muestraInfoParam){
			//No es necesario ir a la base de datos, refrescamos la lista directamente del informe, el metodo sublist extrae la paginacion			
			List<InformeParametro> sublist = new ArrayList<InformeParametro>(informePantalla.getInforme().getInformeParametros());			
			informePantalla.setInfoParam(paginaSublist(sublist));
                        actualizaPaginationData(paginationInfoParam);
		}else{
			List ql =  informeBo.buscarInformes(paginationData);
			informePantalla.setListaInformes(ql);
			actualizaPaginationData(paginationInfo);
		}
	}

	private List<InformeParametro> paginaSublist(List<InformeParametro> list) {
		return PaginacionUtil.paginaSublist(InformeParametro.class, list, paginationInfo);
	}
	
	@Override
	public void refrescarListaExcel() {
		setExportExcel(true);
		informePantalla.setListaInformes(informeBo.buscarInformes(paginationData.getPaginationDataForExcel()));
	}
	
	public InformeBo getInformeBo() {
		return informeBo;
	}

	public void setInformeBo(InformeBo informeBo) {
		this.informeBo = informeBo;
	}

	public InformeParametroBo getInformeParametroBo() {
		return informeParametroBo;
	}

	public void setInformeParametroBo(InformeParametroBo informeParametroBo) {
		this.informeParametroBo = informeParametroBo;
	}

	public InformePantalla getInformePantalla() {
		return informePantalla;
	}

	public void setInformePantalla(InformePantalla informePantalla) {
		this.informePantalla = informePantalla;
	}

	public ParametroBo getParametroBo() {
		return parametroBo;
	}

	public void setParametroBo(ParametroBo parametroBo) {
		this.parametroBo = parametroBo;
	}

	public boolean isListaInfoParam() {
		return muestraInfoParam;
	}

	public void setListaInfoParam(boolean listaInfoParam) {
		this.muestraInfoParam = listaInfoParam;
	}

	public PaginationData getPaginationInfo() {
		return paginationInfo;
	}

	public void setPaginationInfo(PaginationData paginationInfo) {
		this.paginationInfo = paginationInfo;
	}

	public PaginationData getPaginationParam() {
		return paginationParam;
	}

	public void setPaginationParam(PaginationData paginationParam) {
		this.paginationParam = paginationParam;
	}

	public PaginationData getPaginationInfoParam() {
		return paginationInfoParam;
	}

	public void setPaginationInfoParam(PaginationData paginationInfoParam) {
		this.paginationInfoParam = paginationInfoParam;
	}

	public boolean isMuestraInfoParam() {
		return muestraInfoParam;
	}

	public void setMuestraInfoParam(boolean muestraInfoParam) {
		this.muestraInfoParam = muestraInfoParam;
	}

	public boolean isMuestraParam() {
		return muestraParam;
	}

	public void setMuestraParam(boolean muestraParam) {
		this.muestraParam = muestraParam;
	}

	public Boolean getCreacionParametro() {
		return creacionParametro;
	}

	public void setCreacionParametro(Boolean creacionParametro) {
		this.creacionParametro = creacionParametro;
	}

	public PantallaBo getPantallaBo() {
		return pantallaBo;
	}

	public void setPantallaBo(PantallaBo pantallaBo) {
		this.pantallaBo = pantallaBo;
	}

	@Override
	public void salir() {		
		super.salir();
		em.clear();
	}		

	//No hay filtro, por tanto no tiene sentido ocultar la paginación
	@Override
	public boolean isPrimerAcceso() {
		return false;
	}
}
