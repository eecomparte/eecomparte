package com.atosorigin.deri.applistados.informes.action;

import java.util.List;

import org.jboss.seam.ScopeType;
import org.jboss.seam.annotations.In;
import org.jboss.seam.annotations.Name;
import org.jboss.seam.annotations.Scope;

import com.atosorigin.common.action.PaginatedListAction;
import com.atosorigin.deri.appListados.parametros.business.ParametroBo;
import com.atosorigin.deri.applistados.informes.screen.InformePantalla;
import com.atosorigin.deri.model.appListados.Parametro;

@Name("informeParametroAction")
@Scope(ScopeType.CONVERSATION)
public class InformeParametroAction extends PaginatedListAction {

	@In
	protected InformePantalla informePantalla;
	
	@In("#{parametroBo}")
	protected ParametroBo parametroBo;

	@Override
	public List<?> getDataTableList() {
		return informePantalla.getListaParametros();
	}

	@Override
	protected void refreshListInternal() {		
		informePantalla.setListaParametros((List)parametroBo.buscarParametros(informePantalla.getCodigoParametro(), null, paginationData));
	}

	@Override
	public void refrescarListaExcel() {
		informePantalla.setListaParametros((List)parametroBo.buscarParametros(informePantalla.getCodigoParametro(), null, paginationData.getPaginationDataForExcel()));
	}

	@Override
	public void setDataTableList(List<?> dataTableList) {
		informePantalla.setListaParametros((List<Parametro>)dataTableList);
	}
	
	@Override
	public boolean isPrimerAcceso() {
		return false;
	}

}
