
package com.atosorigin.deri.applistados.informes.screen;

import java.util.ArrayList;
import java.util.List;

import org.jboss.seam.ScopeType;
import org.jboss.seam.annotations.Name;
import org.jboss.seam.annotations.Out;
import org.jboss.seam.annotations.Scope;
import org.jboss.seam.annotations.datamodel.DataModel;
import org.jboss.seam.annotations.datamodel.DataModelSelection;

import com.atosorigin.deri.model.appListados.Informe;
import com.atosorigin.deri.model.appListados.InformeParametro;
import com.atosorigin.deri.model.appListados.Parametro;

/**
* Contiene los datos de pantalla necesarios para el caso de uso mantenimiento de listados.
*/
@Name("informePantalla")
@Scope(ScopeType.CONVERSATION)
public class InformePantalla {
	
	@Out(value="informe", required=false)
	protected Informe informe;
	
	protected List<Boolean> listaOpciones;
	
	@DataModel(value="listaDtInforme")
	protected List<Informe> listaInformes;
	
	@DataModelSelection(value="listaDtInforme")
	@Out(required=false)
	protected Informe informeSelec;

	@DataModel(value="listaDtInformeParam")
	protected List<InformeParametro> infoParam;
	
	@DataModelSelection(value="listaDtInformeParam")
	@Out(required=false)
	protected InformeParametro informeParamSelec;
	
	protected List<InformeParametro> listaNuevosInformesParam;
	
	protected InformeParametro informeParam;
	
	//Lista de parametros para el alta y su filtro
	@DataModelSelection(value="listaDtParametro")
	@Out(required=false)
	protected Parametro paramSelec;
	
	@DataModel(value="listaDtParametro")
	protected List<Parametro> listaParametros;
	
	protected String codigoParametro;

	public Informe getInformeSelec() {
		return informeSelec;
	}

	public void setInformeSelec(Informe informeSelec) {
		this.informeSelec = informeSelec;
	}

	public List<Informe> getListaInformes() {
		return listaInformes;
	}

	public void setListaInformes(List<Informe> listaInformes) {
		if(this.listaInformes==null){
			this.listaInformes=new ArrayList<Informe>();
		}
		this.listaInformes = listaInformes;
	}

	public Informe getInforme() {
		return informe;
	}

	public void setInforme(Informe informe) {
		this.informe = informe;
	}

	public List<Boolean> getListaOpciones() {
		return listaOpciones;
	}

	public void setListaOpciones(List<Boolean> listaOpciones) {
		this.listaOpciones = listaOpciones;
	}
	
	public InformePantalla(){
		/** Cargamos la pantalla con los valores por defecto */
		//duda
		
		//this.listaOpciones = new ArrayList<Boolean>();
		//this.listaOpciones.add(Constantes.DIVISA_MARGEN_5);
		//this.listaOpciones.add(Constantes.DIVISA_MARGEN_10);
		//this.listaOpciones.add(Constantes.DIVISA_MARGEN_20);
	}

	public List<InformeParametro> getInfoParam() {
		return infoParam;
	}

	public void setInfoParam(List<InformeParametro> infoParam) {
		if(this.infoParam==null){
			this.infoParam = new ArrayList<InformeParametro>();
		}
	this.infoParam = infoParam;
	}

	public InformeParametro getInformeParamSelec() {
		return informeParamSelec;
	}

	public void setInformeParamSelec(InformeParametro informeParamSelec) {
		this.informeParamSelec = informeParamSelec;
	}

	public Parametro getParamSelec() {
		return paramSelec;
	}

	public void setParamSelec(Parametro paramSelec) {
		this.paramSelec = paramSelec;
	}

	public List<Parametro> getListaParametros() {
		return listaParametros;
	}

	public void setListaParametros(List<Parametro> listaParametros) {
		if(this.listaParametros==null){
			this.listaParametros = new ArrayList<Parametro>();
		}
		this.listaParametros = listaParametros;
	}

	public String getCodigoParametro() {
		return codigoParametro;
	}

	public void setCodigoParametro(String codigoParametro) {
		this.codigoParametro = codigoParametro;
	}

	public InformeParametro getInformeParam() {
		return informeParam;
	}

	public void setInformeParam(InformeParametro informeParam) {
		this.informeParam = informeParam;
	}

	public List<InformeParametro> getListaNuevosInformesParam() {
		return listaNuevosInformesParam;
	}

	public void setListaNuevosInformesParam(
			List<InformeParametro> listaNuevosInformesParam) {
		this.listaNuevosInformesParam = listaNuevosInformesParam;
	}
	
}
