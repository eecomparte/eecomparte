package com.atosorigin.deri.applistados.listados.action;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import javax.faces.context.ExternalContext;
import javax.persistence.EntityManager;

import org.jboss.seam.ScopeType;
import org.jboss.seam.annotations.In;
import org.jboss.seam.annotations.Name;
import org.jboss.seam.annotations.Out;
import org.jboss.seam.annotations.Scope;
import org.jboss.seam.core.ResourceBundle;
import org.jboss.seam.international.StatusMessage.Severity;

import com.atosorigin.common.action.ModoPantalla;
import com.atosorigin.common.action.PaginatedListAction;
import com.atosorigin.common.constantes.Constantes;
import com.atosorigin.common.formvalidator.FormValidator;
import com.atosorigin.common.utils.GenericUtils;
import com.atosorigin.deri.appListados.listados.business.PeticionBo;
import com.atosorigin.deri.applistados.listados.screen.PeticionPantalla;
import com.atosorigin.deri.contrapartida.business.ContrapartidaBo;
import com.atosorigin.deri.model.appListados.Peticion;
import com.atosorigin.deri.model.appListados.PeticionId;
import com.atosorigin.deri.model.appListados.Zona;
import com.atosorigin.deri.model.common.RetornoFuncion;
import com.atosorigin.deri.model.contrapartida.Contrapartida;
import com.atosorigin.deri.model.provisional.ListasTipo;
import com.atosorigin.deri.util.ConfiguracionDeri;
import com.atosorigin.deri.util.EntityUtil;
import com.atosorigin.deri.util.MessageBoxAction;
import com.atosorigin.deri.util.MsgBoxAction;

/**
 * Clase action listener para el caso de uso de mantenimiento de peticions.
 */
@Name("peticionAction")
@Scope(ScopeType.CONVERSATION)
@FormValidator
public class PeticionAction extends PaginatedListAction {

	/**
	 * Inyección del bean de Spring "peticionBo" que contiene los métodos de negocio
	 * para el caso de uso mantenimiento de listados.
	 */
	@In("#{peticionBo}")
	protected PeticionBo peticionBo;
	
	@In("#{contrapartidaBo}")
	protected ContrapartidaBo contrapartidaBo;
	
    @In(value="configuracionDeri")
    ConfiguracionDeri configuracionDeri;
    
	@In(value="#{facesContext.externalContext}")
	private ExternalContext extCtx;

//	@In(required=false, value="zonas")
//	@Out(required=false, value="zonas")	
//	private Zona zonaSeleccionada;
	
	/**
	 * Inyección del screen bean que contiene los datos de pantalla del caso de uso
	 * mantenimiento de listados.
	 */
	@In(create=true)
	protected PeticionPantalla peticionPantalla;
	
	@In
	private EntityManager entityManager;
	
	/**
	 * Contiene true si estamos en la pantalla de busqueda
	 */
	private boolean zonaEstaEnPantalla = true;
	
	protected boolean fInicioEnabled;
	protected boolean fFinEnabled;
	
	@In(create = true)
	MsgBoxAction msgBoxAction;
	
	@Out(required = false, value = "peticionesMessageBoxAction")
	private MessageBoxAction messageBoxPeticionAction;
	
	/**
	 * Valida que no se introduzca para la búsqueda una fechaInicio mayor que fechaFin
	 * @return true si fecha inicial <= fecha final
	 */
	public boolean buscarValidator(){
		
		boolean esCorrecto = true;
		
		if(!GenericUtils.isNullOrBlank(peticionPantalla.getFechaInicio()) && !GenericUtils.isNullOrBlank(peticionPantalla.getFechaFin())){
			long diffFechaFinIni = (peticionPantalla.getFechaFin().getTime() - peticionPantalla.getFechaInicio().getTime())/86400000L;
		
			if(diffFechaFinIni < 0){
				esCorrecto = false;
				statusMessages.addToControl("fechaInicio", Severity.ERROR,"#{messages['peticion.error.fechaErronea']}");
			}
		}
		if(!GenericUtils.isNullOrBlank(peticionPantalla.getContrapartida().getId())){
			if(GenericUtils.isNullOrBlank(contrapartidaBo.cargar(peticionPantalla.getContrapartida().getId()))){
				esCorrecto = false;
				statusMessages.addToControl("idContrapartida", Severity.ERROR,"#{messages['peticion.error.contrapa']}");
			}
		}
		
		return esCorrecto;
	}
	
	
	/** Actualiza la lista del grid de peticiones */
	public void buscar() {	
		setModoPantalla(ModoPantalla.INSPECCION);
		zonaEstaEnPantalla = true;
		paginationData.reset();		
		refrescarLista();		
		setPrimerAcceso(false);
		
	}
	
	/** Borra una petición. */
	public void borrar() {
		peticionBo.borrar(peticionPantalla.getPeticionSelec());
		zonaEstaEnPantalla = true;
		refrescarLista();
	}
	
	/** Prepara para entrar en el modo edición de una petición. */
	public void editar() {
		peticionPantalla.setZonaIdDetalle(null);
		peticionPantalla.copiaSeleccionado();
		if(!GenericUtils.isNullOrBlank(peticionPantalla.getPeticion().getContrapartida())){
			
			peticionPantalla.setContrapartidaDetalle(peticionPantalla.getPeticion().getContrapartida().getId());
		}
		if(!GenericUtils.isNullOrBlank(peticionPantalla.getPeticion().getZona()) 
				&& EntityUtil.checkEntityExists(entityManager, peticionPantalla.getPeticion().getZona())){
			peticionPantalla.setZonaIdDetalle(peticionPantalla.getPeticion().getZona().getCodigo());
			peticionPantalla.setZonaNombreReducidoDetalle(peticionPantalla.getPeticion().getZona().getNombreReducido());
		}
		
		zonaEstaEnPantalla = false;
		setModoPantalla(ModoPantalla.EDICION);
	}

	/** Prepara para entrar en el modo inspección de una petición. */
	public void ver() {

		peticionPantalla.copiaSeleccionado();
		if(!GenericUtils.isNullOrBlank(peticionPantalla.getPeticion().getZona())){
			peticionPantalla.setZonaIdDetalle(peticionPantalla.getPeticion().getZona().getCodigo());
			peticionPantalla.setZonaNombreReducidoDetalle(peticionPantalla.getPeticion().getZona().getNombreReducido());
			peticionPantalla.setContrapartidaDetalle(peticionPantalla.getPeticion().getContrapartida().getId());
		}
		
		zonaEstaEnPantalla = false;
		setModoPantalla(ModoPantalla.INSPECCION);
	}
	
	/** Graba la peticion en la base de datos. */

	public String guardar() {
		//preguntar si esta vacio
		Peticion peticion = peticionPantalla.getPeticion();
		Zona zona = null;
		
		if(!GenericUtils.isNullOrBlank(peticion)){

			
			if (!GenericUtils.isNullOrBlank(peticionPantalla.getContrapartidaDetalle())){
				
				peticion.setContrapartida(contrapartidaBo.cargar(peticionPantalla.getContrapartidaDetalle()));
			}else{
				peticion.setContrapartida(null);
			}
			if (!GenericUtils.isNullOrBlank(peticionPantalla.getZonaIdDetalle())){
				zona = peticionBo.cargarZona(peticionPantalla.getZonaIdDetalle());
			}
			peticion.setZona(zona);
			
			// Calcular FECHAINI
			if (peticion.getCodigoListado().getId() ==13 || peticion.getCodigoListado().getId()==16){
				Date fechaInicio = peticionBo.obtenerFechaInicio(peticion.getFechaInicio(), peticion.getContrapartida());
				peticion.setFechaInicio(fechaInicio);
			}
			
			//SMM 07/06/2013n Añadir un dia a fechamis.
			if (peticion.getCodigoListado().getId() ==13){
				Date fechamis = peticionBo.getFechamis();
				Calendar c = Calendar.getInstance(); 
				c.setTime(fechamis); 
				c.add(Calendar.DATE, 1);
				fechamis = c.getTime();
				peticion.getId().setFechaPeticion(fechamis);
			}
					
			if(ModoPantalla.CREACION.equals(getModoPantalla())){
				RetornoFuncion retorno;
				try {
					retorno = peticionBo.guardarPeticion(configuracionDeri.getDirListados(), peticion,extCtx);
					//En caso de que sea nulo, es porque no se ha lanzado ningún package
					if(!GenericUtils.isNullOrBlank(retorno) && retorno.getHayErrores()){
						statusMessages.add(Severity.ERROR, retorno.getDescError());
					}
					
				} catch (Exception e) {
					statusMessages.add(Severity.ERROR, e.getMessage(),  e);					
				}
			}else{
				peticionBo.guardar(peticion);
			}
			
			refrescarLista();
		
		}
		zonaEstaEnPantalla = true;
		setModoPantalla(ModoPantalla.INSPECCION);
		return Constantes.CONSTANTE_SUCCESS;
	}
	
	
	/**
	 * Prepara para entrar en el modo creación de una petición, teniendo en cuenta los parámetros por defectos señalados
	 *	Peticion.Estado = 'PE' (Si codigo de listado es 1, 7, 8, 13, 16) <br/>
	 *	Peticion.Estado = 'CO' (Para el resto de codigos)<br/>
	 * 
	 */
	public void nuevo() {
		
		Long codigoNuevo = peticionBo.obtenerNuevoCodigo();
		
		PeticionId id = new PeticionId(new Date(),codigoNuevo);
		peticionPantalla.setZonaIdDetalle(null);
		peticionPantalla.setPeticion(new Peticion(id, new Zona(), null, new Contrapartida(), null, Constantes.PE, null, null, null, null));
		zonaEstaEnPantalla = false;
		setModoPantalla(ModoPantalla.CREACION);
	}
	
	/**
	 * Función que en base a los valores informados en ciertos campos del formulario
	 * habilita o deshabilita para su modificación otros campos de dicho formulario
	 */
	public void establecerCamposModificables(){
		
		if(GenericUtils.isNullOrBlank(peticionPantalla.getPeticion().getCodigoListado())){
			peticionPantalla.getPeticion().setCodigoListado(new ListasTipo());
		}
		
		if(EntityUtil.checkEntityExists(entityManager, peticionPantalla.getPeticion().getCodigoListado()) && peticionPantalla.getPeticion().getCodigoListado().getId() > 0){
			
			short idListado = peticionPantalla.getPeticion().getCodigoListado().getId();
			
			peticionPantalla.getPeticion().setCodigoListado(peticionBo.obtenerListadoSeleccionado(idListado));
			
			if (Constantes.CONSTANTE_SI.equals(peticionPantalla.getPeticion().getCodigoListado().getIndFechasActivadas())){
				if ((Constantes.UNO.equals(idListado)) 
						|| (Constantes.SIETE.equals(idListado))){
					
					peticionPantalla.getPeticion().setFechaInicio(new Date());
					peticionPantalla.getPeticion().setFechaFin(new Date());
					fInicioEnabled = true;
					fFinEnabled = true;
				}
				if ((Constantes.NUEVE.equals(idListado))
						|| (Constantes.DIEZ.equals(idListado))
						|| (Constantes.ONCE.equals(idListado))
						|| (Constantes.DOCE.equals(idListado)) 
						|| (Constantes.CATORCE.equals(idListado))
						|| (Constantes.QUINCE.equals(idListado))
						|| (Constantes.DIECISIETE.equals(idListado))
						|| (Constantes.DIECIOCHO.equals(idListado)) ){
					
					//se establece la fecha indicada por defecto 24/09/1998
					SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
					Date d;
					try {
						d = sdf.parse("24/09/1998");
					} catch (ParseException e) {
						d = new Date();
					}
					peticionPantalla.getPeticion().setFechaInicio(d);
					peticionPantalla.getPeticion().setFechaFin(new Date());
					
					fInicioEnabled = true;
					fFinEnabled = true;
					
				}
				if ((Constantes.TRECE.equals(idListado))
						|| (Constantes.DIECISEIS.equals(idListado))){		
					peticionPantalla.getPeticion().setFechaInicio(new Date());
					peticionPantalla.getPeticion().setFechaFin(null);
					fInicioEnabled = true;
					fFinEnabled = false;
				}
				
				establecerEstadoInicial();
				
			} else if (Constantes.CONSTANTE_NO.equals(peticionPantalla.getPeticion().getCodigoListado().getIndFechasActivadas())){
					establecerEstadoInicial();
					peticionPantalla.getPeticion().setFechaInicio(null);
					peticionPantalla.getPeticion().setFechaFin(null);
					fInicioEnabled = false;
					fFinEnabled = false;
			}
		}
	}
	
	/**
	 * Establece el valor por defecto del estado al crear un nuevo registro dependiendo del valor del código de listado.
	 */
	public void establecerEstadoInicial(){

		if(getModoPantalla().equals(ModoPantalla.CREACION)){
		
			if((Constantes.UNO.equals(peticionPantalla.getPeticion().getCodigoListado().getId())) ||(Constantes.SIETE.equals(peticionPantalla.getPeticion().getCodigoListado().getId())) ||(Constantes.OCHO.equals(peticionPantalla.getPeticion().getCodigoListado().getId())) || 
				(Constantes.TRECE.equals(peticionPantalla.getPeticion().getCodigoListado().getId())) || (Constantes.DIECISEIS.equals(peticionPantalla.getPeticion().getCodigoListado().getId()))){
			
				peticionPantalla.getPeticion().setEstado(Constantes.PE);
			}else{	
				peticionPantalla.getPeticion().setEstado(Constantes.CO);
			
			}
		}
	}
	
	/**
	 * 
	 * Se realizan las validaciones solicitadas antes de guardar el registro creado dependendiento del valor del código de listado elegido.
	 */
	public boolean guardarValidator(){
		
		boolean esCorrecto = false;
		   
		short codigoList = peticionPantalla.getPeticion().getCodigoListado().getId();
		
		switch (codigoList) {
		case 13:
			esCorrecto = peticionBo.existePeticion(peticionPantalla.getPeticion().getId().getFechaPeticion(), peticionPantalla.getPeticion().getCodigoListado(), null, null);
			if(esCorrecto == false){
				statusMessages.add(Severity.ERROR, "#{messages['peticion.error.peticionYaExiste']}");
			}
			break;
		case 16:
			Contrapartida contrapaAux = new Contrapartida();
			contrapaAux.setId(peticionPantalla.getContrapartidaDetalle());
			esCorrecto = peticionBo.existePeticion(peticionPantalla.getPeticion().getId().getFechaPeticion(), peticionPantalla.getPeticion().getCodigoListado(), contrapaAux, obtenerFechaInicio());
			if(esCorrecto == false){
				statusMessages.add(Severity.ERROR, "#{messages['peticion.error.peticionYaExiste']}");
			}
			break;
		case 8:
			// En este caso no se debe realizar ninguna validación
			esCorrecto = true;
			break;
		default:
			esCorrecto = validaFechaIniFin();
			break;
		}
		
		return esCorrecto;
	}

	/**
	 * Se valida el valor de las fechas de inicio y fin introducidas.
	 * 
	 * */
	private boolean validaFechaIniFin() {
		
		boolean esCorrecto = true;
		Long diferencia = null;
		
		if(!GenericUtils.isNullOrBlank(peticionPantalla.getPeticion().getFechaInicio()) && !GenericUtils.isNullOrBlank(peticionPantalla.getPeticion().getFechaFin())){
			diferencia = (peticionPantalla.getPeticion().getFechaInicio().getTime() - peticionPantalla.getPeticion().getFechaFin().getTime())/86400000L;
		}
		
		if (!GenericUtils.isNullOrBlank(diferencia) && diferencia.compareTo(0L)>0){
			esCorrecto = false;
			statusMessages.add(Severity.ERROR, "#{messages['peticion.error.fechaErronea']}");
		}
		
		return esCorrecto;
	}
	
	
	/** 
	 * Se obtiene la fecha de inicio en modo creación cuando el código de listado es 16.
	 * 
	 * */
	
	public Date obtenerFechaInicio(){
		
		Date fecha = null;
		
		if(getModoPantalla().equals(ModoPantalla.CREACION)){
		
			if (Constantes.DIECISEIS.equals(peticionPantalla.getPeticion().getCodigoListado().getId())){
				Contrapartida contr=new Contrapartida();
				contr.setId(peticionPantalla.getContrapartidaDetalle());
				fecha = peticionBo.obtenerFechaInicio(peticionPantalla.getPeticion().getFechaInicio(), contr);
			}
		}
		
		return fecha;
	}
	
	@Override
	public List<?> getDataTableList() {
		return peticionPantalla.getPeticionList();
	}

	@Override
	protected void refreshListInternal() {
		setExportExcel(false);		
		Zona zona = null;
		if (!GenericUtils.isNullOrBlank(peticionPantalla.getZonaId())){
			zona = peticionBo.cargarZona(peticionPantalla.getZonaId());
			//if (zona!=null) peticionPantalla.setZonaNombreReducido(zona.getNombreReducido());
		}
		List<Peticion> ql = (List<Peticion>) peticionBo.buscarPeticiones(peticionPantalla.getCodigoListado(),peticionPantalla.getFechaInicio(), peticionPantalla.getFechaFin(), peticionPantalla.getCuentaBS(), peticionPantalla.getProducto(), peticionPantalla.getAgrupContrapartida(), zona, peticionPantalla.getContrapartida(),paginationData);
		peticionPantalla.setPeticionList(ql);
	}

	
	@Override
	public void refrescarListaExcel() {
		setExportExcel(true);
		Zona zona = null;
		if (!GenericUtils.isNullOrBlank(peticionPantalla.getZonaId())){
			zona = peticionBo.cargarZona(peticionPantalla.getZonaId());
			//if (zona!=null) peticionPantalla.setZonaNombreReducido(zona.getNombreReducido());
		}
		List<Peticion> ql = (List<Peticion>) peticionBo.buscarPeticiones(peticionPantalla.getCodigoListado(),peticionPantalla.getFechaInicio(), peticionPantalla.getFechaFin(), peticionPantalla.getCuentaBS(), peticionPantalla.getProducto(), peticionPantalla.getAgrupContrapartida(), zona, peticionPantalla.getContrapartida(),paginationData.getPaginationDataForExcel());
		peticionPantalla.setPeticionList(ql);
	
	}

	@Override
	@SuppressWarnings("unchecked")
	public void setDataTableList(List<?> dataTableList) {
		peticionPantalla.setPeticionList((List<Peticion>)dataTableList);		
	}
	
	
	public void onChangeZona(){
		
		Short zonaId = null;

		if (modoPantalla.equals(ModoPantalla.CREACION) || (modoPantalla.equals(ModoPantalla.EDICION) && !zonaEstaEnPantalla)){
			Peticion peticion = peticionPantalla.getPeticion();
			zonaId = peticionPantalla.getZonaIdDetalle();
			if(!GenericUtils.isNullOrBlank(zonaId)){
				
				Zona zonaCargada = peticionBo.cargarZona(zonaId);
				if(zonaCargada==null){
					statusMessages.addToControl("idZona", Severity.ERROR, "#{messages['peticion.error.codigoZonaNoExiste']}");
					peticion.setZona(new Zona());
					return;
				}else{
					peticionPantalla.setZonaNombreReducidoDetalle(zonaCargada.getNombreReducido());
				}

				peticionPantalla.getPeticion().setZona(zonaCargada);
			}else{

				peticionPantalla.getPeticion().setZona(new Zona());
			}			
		}else{
			zonaId = peticionPantalla.getZonaId();
			if(!GenericUtils.isNullOrBlank(zonaId)){
								
				Zona zonaCargada= peticionBo.cargarZona(peticionPantalla.getZonaId());
				if(zonaCargada==null){
					statusMessages.addToControl("idZona", Severity.ERROR, "#{messages['peticion.error.codigoZonaNoExiste']}");
					return;
				}else{
					peticionPantalla.setZonaNombreReducido(zonaCargada.getNombreReducido());
				}
			}		
		}
	}
	
	public void salirDetalle(){
		peticionBo.recargar(peticionPantalla.getPeticion());
		super.salir();
	}


	public boolean isfInicioEnabled() {
		return fInicioEnabled;
	}


	public void setfInicioEnabled(boolean fInicioEnabled) {
		this.fInicioEnabled = fInicioEnabled;
	}


	public boolean isfFinEnabled() {
		return fFinEnabled;
	}


	public void setfFinEnabled(boolean fFinEnabled) {
		this.fFinEnabled = fFinEnabled;
	}
	
	public Boolean isGuardarBatchRendered(){
	
		if (!modoPantalla.equals(ModoPantalla.CREACION)) {
			return false;
		}

		Peticion peticion = peticionPantalla.getPeticion();
		
		if (peticion==null || peticion.getCodigoListado()==null ){
			return false;
		}
		
//		Obtenemos el codigo del listado y filtramos
		short codListado = peticion.getCodigoListado().getId();
		
		 if (GenericUtils.in(codListado, 14,15,17,18)){
			return true;
		}else    {
			return false;
		}

	}
	
	public void guardarBatch(){
		//preguntar si esta vacio
		Peticion peticion = peticionPantalla.getPeticion();
		Zona zona = null;
		
		if(!GenericUtils.isNullOrBlank(peticion)){

			
			if (!GenericUtils.isNullOrBlank(peticionPantalla.getContrapartidaDetalle())){
				
				peticion.setContrapartida(contrapartidaBo.cargar(peticionPantalla.getContrapartidaDetalle()));
			}else{
				peticion.setContrapartida(null);
			}
			if (!GenericUtils.isNullOrBlank(peticionPantalla.getZonaIdDetalle())){
				zona = peticionBo.cargarZona(peticionPantalla.getZonaIdDetalle());
			}
			peticion.setZona(zona);
			
			// Calcular FECHAINI
//			if (peticion.getCodigoListado().getId() ==13 || peticion.getCodigoListado().getId()==16){
//				Date fechaInicio = peticionBo.obtenerFechaInicio(peticion.getFechaInicio(), peticion.getContrapartida());
//				peticion.setFechaInicio(fechaInicio);
//			}
//			if(ModoPantalla.CREACION.equals(getModoPantalla())){
				
				
			Long peticionBatch =  peticionBo.guardarPeticionBatch(configuracionDeri.getDirListados(), peticion);


			//En caso de que sea nulo, es porque no se ha lanzado ningún package
				
//			}else{
//				peticionBo.guardar(peticion);
//			}
			
			refrescarLista();
			String mensaje = ResourceBundle.instance().getString("liquidaciones.registros.validadosBatch") + " " + peticionBatch;
			statusMessages.add(Severity.INFO, mensaje);
		
		}
		zonaEstaEnPantalla = true;
		setModoPantalla(ModoPantalla.INSPECCION);
	}

	public boolean guardarBatchValidator(){
		
		boolean esCorrecto = false;
		   
		short codigoList = peticionPantalla.getPeticion().getCodigoListado().getId();
		
		switch (codigoList) {
		case 13:
			esCorrecto = peticionBo.existePeticion(peticionPantalla.getPeticion().getId().getFechaPeticion(), peticionPantalla.getPeticion().getCodigoListado(), null, null);
			if(esCorrecto == false){
				statusMessages.add(Severity.ERROR, "#{messages['peticion.error.peticionYaExiste']}");
			}
			break;
		case 16:
			Contrapartida contrapaAux = new Contrapartida();
			contrapaAux.setId(peticionPantalla.getContrapartidaDetalle());
			esCorrecto = peticionBo.existePeticion(peticionPantalla.getPeticion().getId().getFechaPeticion(), peticionPantalla.getPeticion().getCodigoListado(), contrapaAux, obtenerFechaInicio());
			if(esCorrecto == false){
				statusMessages.add(Severity.ERROR, "#{messages['peticion.error.peticionYaExiste']}");
			}
			break;
		case 8:
			// En este caso no se debe realizar ninguna validación
			esCorrecto = true;
			break;
		default:
			esCorrecto = validaFechaIniFin();
			break;
		}
		
		return esCorrecto;
	}
	
	public void init(){
		if(null==messageBoxPeticionAction){
			messageBoxPeticionAction = new MessageBoxAction();
		}
	}
	
	public void initDetalle(){
		if(null==messageBoxPeticionAction){
			messageBoxPeticionAction = new MessageBoxAction();
		}
	}

	public void voidFunction(){
		msgBoxAction.voidFunction();
	}

	/**
	 * Mostrar PopUp cuando una contrapartida está bloqueada (no bloqueante)
	 */
	public void onVerificarContrapartidaBloqueada() {
		String contrapartida = peticionPantalla.getContrapartida().getId();
		if (!GenericUtils.isNullOrBlank(contrapartida)){
			 Contrapartida contrapObtenida2 = peticionBo.cargarContrapartida(contrapartida.toUpperCase());	
			if (!GenericUtils.isNullOrBlank(contrapObtenida2) && !GenericUtils.isNullOrBlank(contrapObtenida2.getIndBloqueo()) && "S".equalsIgnoreCase(contrapObtenida2.getIndBloqueo())){
				iniciarPopUpContrapartidaBloqueada();
			}
		}
	}
	
	public void onVerificarContrapartidaBloqueadaDetalle() {
		String contrapartida = peticionPantalla.getContrapartidaDetalle();
		if (!GenericUtils.isNullOrBlank(contrapartida)){
			 Contrapartida contrapObtenida2 = peticionBo.cargarContrapartida(contrapartida.toUpperCase());	
			if (!GenericUtils.isNullOrBlank(contrapObtenida2) && !GenericUtils.isNullOrBlank(contrapObtenida2.getIndBloqueo()) && "S".equalsIgnoreCase(contrapObtenida2.getIndBloqueo())){
				iniciarPopUpContrapartidaBloqueada();
			}
		}
	}
	
	private void iniciarPopUpContrapartidaBloqueada(){
		messageBoxPeticionAction.init(ResourceBundle.instance().getString("peticion.messages.contrapartida.bloqueada.texto"), "peticionAction.voidFunction()", null,"messageBoxPanelContrapa");
	}

}
