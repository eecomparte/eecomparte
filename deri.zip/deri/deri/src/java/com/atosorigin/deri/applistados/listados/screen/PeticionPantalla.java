package com.atosorigin.deri.applistados.listados.screen;

import java.util.Date;
import java.util.List;

import org.jboss.seam.ScopeType;
import org.jboss.seam.annotations.Name;
import org.jboss.seam.annotations.Out;
import org.jboss.seam.annotations.Scope;
import org.jboss.seam.annotations.datamodel.DataModel;
import org.jboss.seam.annotations.datamodel.DataModelSelection;

import com.atosorigin.deri.model.appListados.Peticion;
import com.atosorigin.deri.model.appListados.PeticionId;
import com.atosorigin.deri.model.catalogo.Producto;
import com.atosorigin.deri.model.contrapartida.AgrupContrapartida;
import com.atosorigin.deri.model.contrapartida.Contrapartida;
import com.atosorigin.deri.model.provisional.ListasTipo;

/**
* Contiene los datos de pantalla necesarios para el caso de uso mantenimiento de listados.
*/
@Name("peticionPantalla")
@Scope(ScopeType.CONVERSATION)
public class PeticionPantalla {
	
	protected PeticionId id;
	protected Date fechaInicio;
	protected Date fechaFin;
	protected String cuentaBS;
	protected Producto producto;
	protected AgrupContrapartida agrupContrapartida;
	//protected Zona zona;

	protected Short zonaId;
	protected String zonaNombreReducido;
	
	protected Short zonaIdDetalle;
	protected String zonaNombreReducidoDetalle;
	
	private ListasTipo codigoListado;
	
	protected Contrapartida contrapartida;
	
	protected String contrapartidaDetalle;
	
	public PeticionPantalla() {
		contrapartida = new Contrapartida();
		//zona=new Zona();
		
	}
	
	@Out(value="peticion", required=false)
	protected Peticion peticion;
	
	/** Lista de datos para el grid. */
	@DataModel(value ="listaDtPeticion")
	protected List<Peticion> peticionList;
	
	/** Petición seleccionada en el grid */
	@DataModelSelection(value ="listaDtPeticion")    
	protected Peticion peticionSelec;
	
	/** Variables necesarias para habilitar y deshabilitar los
	 * campos del formulario de detalle */
	protected boolean agrupContrapaModif;
	protected boolean productoModif;
	protected boolean fechaIniModif;
	protected boolean fechaFinModif;
	protected boolean zonaModif;
	protected boolean cuentaBSModif;
	protected boolean contrapaModif;

	public PeticionId getId() {
		return id;
	}
	public void setId(PeticionId id) {
		this.id = id;
	}
	public Date getFechaInicio() {
		return fechaInicio;
	}
	public void setFechaInicio(Date fechaInicio) {
		this.fechaInicio = fechaInicio;
	}
	public Date getFechaFin() {
		return fechaFin;
	}
	public void setFechaFin(Date fechaFin) {
		this.fechaFin = fechaFin;
	}
	public String getCuentaBS() {
		return cuentaBS;
	}
	public void setCuentaBS(String cuentaBS) {
		this.cuentaBS = cuentaBS;
	}
	public Producto getProducto() {
		return producto;
	}
	public void setProducto(Producto producto) {
		this.producto = producto;
	}
	public AgrupContrapartida getAgrupContrapartida() {
		return agrupContrapartida;
	}
	public void setAgrupContrapartida(AgrupContrapartida agrupContrapartida) {
		this.agrupContrapartida = agrupContrapartida;
	}
//	public Zona getZona() {
//		return zona;
//	}
//	public void setZona(Zona zona) {
//		this.zona = zona;
//	}
	public ListasTipo getCodigoListado() {
		return codigoListado;
	}
	public void setCodigoListado(ListasTipo codigoListado) {
		this.codigoListado = codigoListado;
	}
	public Contrapartida getContrapartida() {
		return contrapartida;
	}
	public void setContrapartida(Contrapartida contrapartida) {
		this.contrapartida = contrapartida;
	}
	public Peticion getPeticion() {
		return peticion;
	}
	public void setPeticion(Peticion peticion) {
		this.peticion = peticion;
	}
	public List<Peticion> getPeticionList() {
		return peticionList;
	}
	public void setPeticionList(List<Peticion> peticionList) {
		this.peticionList = peticionList;
	}
	public Peticion getPeticionSelec() {
		return peticionSelec;
	}
	public void setPeticionSelec(Peticion peticionSelec) {
		this.peticionSelec = peticionSelec;
	}
	public boolean isAgrupContrapaModif() {
		return agrupContrapaModif;
	}
	public void setAgrupContrapaModif(boolean agrupContrapaModif) {
		this.agrupContrapaModif = agrupContrapaModif;
	}
	public boolean isProductoModif() {
		return productoModif;
	}
	public void setProductoModif(boolean productoModif) {
		this.productoModif = productoModif;
	}
	public boolean isFechaIniModif() {
		return fechaIniModif;
	}
	public void setFechaIniModif(boolean fechaIniModif) {
		this.fechaIniModif = fechaIniModif;
	}
	public boolean isFechaFinModif() {
		return fechaFinModif;
	}
	public void setFechaFinModif(boolean fechaFinModif) {
		this.fechaFinModif = fechaFinModif;
	}
	public boolean isZonaModif() {
		return zonaModif;
	}
	public void setZonaModif(boolean zonaModif) {
		this.zonaModif = zonaModif;
	}
	public boolean isCuentaBSModif() {
		return cuentaBSModif;
	}
	public void setCuentaBSModif(boolean cuentaBSModif) {
		this.cuentaBSModif = cuentaBSModif;
	}
	public boolean isContrapaModif() {
		return contrapaModif;
	}
	public void setContrapaModif(boolean contrapaModif) {
		this.contrapaModif = contrapaModif;
	}

	public Short getZonaId() {
		return zonaId;
	}
	public String getZonaNombreReducido() {
		return zonaNombreReducido;
	}
	public void setZonaId(Short zonaId) {
		this.zonaId = zonaId;
	}
	public void setZonaNombreReducido(String zonaNombreReducido) {
		this.zonaNombreReducido = zonaNombreReducido;
	}
	
	public void copiaSeleccionado(){
		peticion = peticionSelec;
	}
	public Short getZonaIdDetalle() {
		return zonaIdDetalle;
	}
	public String getZonaNombreReducidoDetalle() {
		return zonaNombreReducidoDetalle;
	}
	public void setZonaIdDetalle(Short zonaIdDetalle) {
		this.zonaIdDetalle = zonaIdDetalle;
	}
	public void setZonaNombreReducidoDetalle(String zonaNombreReducidoDetalle) {
		this.zonaNombreReducidoDetalle = zonaNombreReducidoDetalle;
	}
	public String getContrapartidaDetalle() {
		return contrapartidaDetalle;
	}
	public void setContrapartidaDetalle(String contrapartidaDetalle) {
		this.contrapartidaDetalle = contrapartidaDetalle;
	}
	
}
