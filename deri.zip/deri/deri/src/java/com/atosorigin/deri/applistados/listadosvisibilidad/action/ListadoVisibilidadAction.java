package com.atosorigin.deri.applistados.listadosvisibilidad.action;

import java.io.IOException;
import java.io.InputStream;
import java.sql.Connection;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.faces.context.FacesContext;
import javax.naming.Context;
import javax.naming.InitialContext;
import javax.servlet.ServletContext;
import javax.sql.DataSource;

import net.sf.jasperreports.engine.JasperCompileManager;
import net.sf.jasperreports.engine.JasperExportManager;
import net.sf.jasperreports.engine.JasperFillManager;
import net.sf.jasperreports.engine.JasperPrint;
import net.sf.jasperreports.engine.JasperReport;
import net.sf.jasperreports.engine.type.WhenNoDataTypeEnum;
import net.sf.jasperreports.engine.util.JRLoader;

import org.jboss.seam.Component;
import org.jboss.seam.ScopeType;
import org.jboss.seam.annotations.Create;
import org.jboss.seam.annotations.In;
import org.jboss.seam.annotations.Name;
import org.jboss.seam.annotations.Out;
import org.jboss.seam.annotations.Scope;
import org.jboss.seam.core.Manager;
import org.jboss.seam.document.ByteArrayDocumentData;
import org.jboss.seam.document.DocumentData;
import org.jboss.seam.document.DocumentStore;
import org.jboss.seam.document.DocumentData.DocumentType;
import org.jboss.seam.international.StatusMessage.Severity;
import org.jboss.seam.navigation.Pages;
import org.jboss.seam.security.Credentials;
import org.jboss.seam.security.Identity;

import com.atosorigin.common.action.GenericAction;
import com.atosorigin.common.constantes.Constantes;
import com.atosorigin.common.formvalidator.FormValidator;
import com.atosorigin.common.utils.GenericUtils;
import com.atosorigin.deri.appListados.visibilidad.business.ListadosVisibilidadBo;
import com.atosorigin.deri.applistados.listadosvisibilidad.screen.ListadoVisibilidadPantalla;
import com.atosorigin.deri.common.authentication.CustomIdentity;
import com.atosorigin.deri.common.reports.Report;
import com.atosorigin.deri.model.contrapartida.Contrapartida;
import com.atosorigin.deri.util.ConfiguracionDeri;
import com.atosorigin.deri.util.MessageBoxAction;
import com.atosorigin.deri.util.MsgBoxAction;



/**
 * Clase action listener para el caso de uso de titulares de la Ordén
 */
@Name("listadoVisibilidadAction")
@Scope(ScopeType.CONVERSATION)
@FormValidator
public class ListadoVisibilidadAction extends GenericAction{
	
	
	@Out(required=false,value="onClickJS")
	private String onClickJS;
	@Out(required=false,value="linkValue")
	private String linkValue;
	@Out(required=false,value="reports")
	private List<Report> reports = new ArrayList<Report>();

	@In Credentials credentials;

//	@In
//	private EntityManager em;
	
	@In(create =true)
	protected ListadoVisibilidadPantalla listadoVisibilidadPantalla;
	
	@In(value="#{listadosVisibilidadBo}")
	protected ListadosVisibilidadBo listadosVisibilidadBo;
	
	@In(value="configuracionDeri")
	ConfiguracionDeri configuracionDeri;
	
	// Parametros por el components.properties
	private String userId;
	private String pathForms;
	private String pathEjecutable;
	private String execMode;
	
	@In(create = true)
	MsgBoxAction msgBoxAction;
	
	@Out(required = false, value = "listadoVisibilidadMessageBoxAction")
	private MessageBoxAction messageBoxListadoVisibilidadAction;
	
	//booleana para mostrar o no el panel de listado de informes
	protected boolean mostrarInformesPanel;
	
	@Create
	public void onCreate(){
		assert configuracionDeri!=null;
		userId = configuracionDeri.getUserId();
		pathForms = configuracionDeri.getPathForms();
		pathEjecutable = configuracionDeri.getPathEjecutable();
		execMode = configuracionDeri.getExecMode();
		
//		Map<String,String> params = 
//			FacesContext.getCurrentInstance().getExternalContext().getRequestParameterMap();
		
	}
	public void preCargar(){
		listadoVisibilidadPantalla.setFechaListado(new Date());
	}
	
	/**
	 * "Nuevo evento y control en la pantalla para impedir que usuaros no BO saquen los reports de visibilidad 
	 * antes de que se hayan revisado. En el botón Aceptar se pone el siguiente control, si existe un evento 379
	 * pendiente y el perfil de usuario es mayor que 1 y la fecha del listado es mayor o igual a la fecha del 
	 * evento (datosvar)  se mostrará un mensaje 'El listado de visibilidad solicitado aún no está 
	 * disponible, inténtelo más tarde'  "
	 */
	public void aceptar(){
//		protected CustomIdentity identity = (CustomIdentity)Component.getInstance("org.jboss.seam.security.identity");;
		CustomIdentity identity = (CustomIdentity) Identity.instance();
		Boolean error = false;
		if (identity.getPerfilUsuario()>1){
			Date fechaEvento = listadosVisibilidadBo.buscarFechaAprobacion();
			if (fechaEvento!=null && listadoVisibilidadPantalla.getFechaListado()!=null 
				&& fechaEvento.compareTo(listadoVisibilidadPantalla.getFechaListado())<=0){
				error = true;
			}
		}

		if (error) statusMessages.addFromResourceBundle(Severity.ERROR, "listadovisibilidad.error.disponibilidad");
		else{
		
		String reportPath=null;
		String reportHeaderPath=null;
		String subreport2 = null;
		
		if (GenericUtils.in(listadoVisibilidadPantalla.getListados().getCodigo(), 
				   Constantes.TIPO_LISTADO_DERIVISI,Constantes.TIPO_LISTADO_DERIVIS8,Constantes.TIPO_LISTADO_DERIVISA,
				   Constantes.TIPO_LISTADO_DERIVIS5,Constantes.TIPO_LISTADO_DERIVIS7,Constantes.TIPO_LISTADO_DERIVISD,	   
				   Constantes.TIPO_LISTADO_DERIVIS4,Constantes.TIPO_LISTADO_DERIVIS6,Constantes.TIPO_LISTADO_DERIVISC,
				   Constantes.TIPO_LISTADO_DERIVIS2,Constantes.TIPO_LISTADO_DERIVIS9,Constantes.TIPO_LISTADO_DERIVISB)){
			
			Date fechatra = listadosVisibilidadBo.obtenerFechaTratamientoPdf(listadoVisibilidadPantalla.getFechaListado(), 
					listadoVisibilidadPantalla.getContrapartida(), listadoVisibilidadPantalla.getListados().getCodigo());
			
			
			if (!GenericUtils.isNullOrBlank(fechatra)){
				
				if (GenericUtils.in(listadoVisibilidadPantalla.getListados().getCodigo(), Constantes.TIPO_LISTADO_DERIVISI,Constantes.TIPO_LISTADO_DERIVIS8, 
						   Constantes.TIPO_LISTADO_DERIVISA)){
					
					reportPath="/reports/Derivisi.jasper";
					reportHeaderPath="/reports/Cabecera_Visib.jasper";
					
				}else if (GenericUtils.in(listadoVisibilidadPantalla.getListados().getCodigo(), 
						Constantes.TIPO_LISTADO_DERIVIS4,Constantes.TIPO_LISTADO_DERIVIS6,Constantes.TIPO_LISTADO_DERIVISC)){
			
					reportPath="/reports/Derivis4.jasper";
					reportHeaderPath="/reports/Cabecera_Visib4.jasper";
					
				}else if (GenericUtils.in(listadoVisibilidadPantalla.getListados().getCodigo(), 
						Constantes.TIPO_LISTADO_DERIVIS5,Constantes.TIPO_LISTADO_DERIVIS7,Constantes.TIPO_LISTADO_DERIVISD)){
					
					reportPath="/reports/Derivis5.jasper";
					reportHeaderPath="/reports/Cabecera_Visib5.jasper";
					
				}else if (GenericUtils.in(listadoVisibilidadPantalla.getListados().getCodigo(), 
					Constantes.TIPO_LISTADO_DERIVIS2,Constantes.TIPO_LISTADO_DERIVIS9,Constantes.TIPO_LISTADO_DERIVISB)){
				
					reportPath="/reports/Derivis2.jasper";
					reportHeaderPath="/reports/Cabecera_Visib.jasper";
					subreport2 ="/reports/Derivis2_b.jasper";
				
				}
				
				verPDF(fechatra, listadosVisibilidadBo.getEntidad(),listadoVisibilidadPantalla.getContrapartida(),reportPath,reportHeaderPath,subreport2);
			}else{
				statusMessages.addFromResourceBundle(Severity.ERROR, "listadovisibilidad.nodatos",listadoVisibilidadPantalla.getContrapartida());
			}
			
			mostrarInformesPanel = false;
		}else{

			
			Report report = listadosVisibilidadBo.generaInforme(userId,pathForms,pathEjecutable,execMode,listadoVisibilidadPantalla.getListados().getCodigo(),
					listadoVisibilidadPantalla.getFechaListado(),
					listadoVisibilidadPantalla.getContrapartida(),
					credentials.getUsername());
			
			if(GenericUtils.isNullOrBlank(report)){
				mostrarInformesPanel = false;
				statusMessages.addFromResourceBundle(Severity.ERROR, "listadovisibilidad.nodatos",listadoVisibilidadPantalla.getContrapartida());
			} else {
				reports = new ArrayList<Report>();
				mostrarInformesPanel = true;
				reports.add(report);
				onClickJS= report.getOnClick();
				linkValue=report.getInformeName();
			}

			
		}
		
		} // CONTROL LISTADOS APROBADOS
	}
	
	public boolean isMostrarInformesPanel() {
		return mostrarInformesPanel;
	}
	
	public void setMostrarInformesPanel(boolean mostrarInformesPanel) {
		this.mostrarInformesPanel = mostrarInformesPanel;
	}
	
	@SuppressWarnings("unused")
	private void redirectExport(byte[] data)

	{

		String viewId = Pages.getViewId(FacesContext.getCurrentInstance());

		String baseName = Pages.getCurrentBaseName();
		DocumentType documType = new DocumentType("pdf", "application/pdf");
		DocumentData documentData = new ByteArrayDocumentData(baseName,
				documType, data);

		documentData.setDisposition("attachment");
		documentData.setFilename(baseName + ".pdf");

		String id = DocumentStore.instance().newId();

		String url = DocumentStore.instance().preferredUrlForContent(baseName,
				documType.getExtension(), id);

		url = Manager.instance().encodeConversationId(url, viewId);
		
		DocumentStore.instance().saveData(id, documentData);

		try	{
				FacesContext.getCurrentInstance().getExternalContext()
					.redirect(url);
				return;
		}
		catch (IOException e)
		{	 e.printStackTrace();return;	}

	}

	public void verPDF(Date fechatra, String entidad, String contrapa, String reportPath, String reportHeaderPath, String subReport2) {
		JasperReport jasperReport;
		JasperReport jasperSubReport;
		JasperReport jasperSubReport_DOS = null;
		JasperPrint jasperPrint;
	    
	    try {
	    	

//	    	JasperCompileManager.compileReportToFile("D:\\workspace\\deri_web\\WebContent\\reports\\Cabecera_Visib.jrxml",
//			"D:\\workspace\\deri_web\\WebContent\\reports\\Cabecera_Visib.jasper" );
//	    	JasperCompileManager.compileReportToFile("D:\\workspace\\deri_web\\WebContent\\reports\\Cabecera_Visib4.jrxml",
//			"D:\\workspace\\deri_web\\WebContent\\reports\\Cabecera_Visib4.jasper" );
//	    	JasperCompileManager.compileReportToFile("D:\\workspace\\deri_web\\WebContent\\reports\\Cabecera_Visib5.jrxml",
//			"D:\\workspace\\deri_web\\WebContent\\reports\\Cabecera_Visib5.jasper" );

//	    	JasperCompileManager.compileReportToFile("D:\\workspace\\deri_web\\WebContent\\reports\\Derivis2.jrxml",
//			"D:\\workspace\\deri_web\\WebContent\\reports\\Derivis2.jasper" );
//	    	
//	    	JasperCompileManager.compileReportToFile("D:\\workspace\\deri_web\\WebContent\\reports\\Derivisi.jrxml",
//	    			"D:\\workspace\\deri_web\\WebContent\\reports\\Derivisi.jasper" );
//	    	JasperCompileManager.compileReportToFile("D:\\workspace\\deri_web\\WebContent\\reports\\Derivis4.jrxml",
//			"D:\\workspace\\deri_web\\WebContent\\reports\\Derivis4.jasper" );
//	    	JasperCompileManager.compileReportToFile("D:\\workspace\\deri_web\\WebContent\\reports\\Derivis5.jrxml",
//			"D:\\workspace\\deri_web\\WebContent\\reports\\Derivis5.jasper" );
//
//	    	
//	    	JasperCompileManager.compileReportToFile("D:\\workspace\\deri_web\\WebContent\\reports\\Derivis2_b.jrxml",
//			"D:\\workspace\\deri_web\\WebContent\\reports\\Derivis2_b.jasper" );


	    	
	    	ServletContext servletContext = (ServletContext) FacesContext.getCurrentInstance().getExternalContext().getContext();
	    	jasperReport = (JasperReport)JRLoader.loadObject (getClass().getClassLoader().getResourceAsStream(reportPath));
	    	jasperSubReport = (JasperReport)JRLoader.loadObject (getClass().getClassLoader().getResourceAsStream(reportHeaderPath));
	    	if (!GenericUtils.isNullOrBlank(subReport2)){
	    		jasperSubReport_DOS = (JasperReport)JRLoader.loadObject (getClass().getClassLoader().getResourceAsStream(subReport2));
	    		jasperSubReport_DOS.setWhenNoDataType(WhenNoDataTypeEnum.ALL_SECTIONS_NO_DETAIL);
	    	}
	    																	 
//	    	InputStream input = servletContext.getResourceAsStream("/reports/Derivisi2.jasper");
//	    	InputStream input = servletContext.getResourceAsStream("/reports/Derivisi.jrxml");
//	    	jasperReport = JasperCompileManager.compileReport(
//	    		  input);
//	    	jasperReport = (JasperReport)JRLoader.loadObject (servletContext.getResourceAsStream("/reports/Derivisi.jasper"));
	    	
//	    	String config = ProjectConfig.getProperty("ForaFirmes");
//			URL camp_url = getClass().getClassLoader().getResource("reports/")images/")LogoSabadellAtlantico.JPG");
	    	
//	    	jasperSubReport = (JasperReport)JRLoader.loadObject (servletContext.getResourceAsStream("/reports/Cabecera_Visib.jasper"));
	    	
//	    	servletContext.getContextPath()+"\\reports\\"
	    	
//	    	InputStream input = servletContext.getResourceAsStream("/reports/Cabecera_Visib.jasper");
//	    	InputStream input2 = servletContext.getResourceAsStream("/reports/Cabecera_Visib.jrxml");
//	    	jasperSubReport = JasperCompileManager.compileReport(
//	    		  input2);
//	    	jasperSubReport = (JasperReport)JRLoader.loadObject (servletContext.getResourceAsStream("/reports/Cabecera_Visib.jasper"));
	    	
	    	jasperSubReport.setWhenNoDataType(WhenNoDataTypeEnum.ALL_SECTIONS_NO_DETAIL);
	    	jasperReport.setWhenNoDataType(WhenNoDataTypeEnum.ALL_SECTIONS_NO_DETAIL);
	    	
//	    	JasperCompileManager.compileReportToFile("D:\\workspace\\deri_web\\WebContent\\reports\\Cabecera_Visib.jrxml",
//			"D:\\workspace\\deri_web\\WebContent\\reports\\Cabecera_Visib.jasper" );
//	    	
//	    	JasperCompileManager.compileReportToFile("D:\\workspace\\deri_web\\WebContent\\reports\\Derivisi.jrxml",
//	    			"D:\\workspace\\deri_web\\WebContent\\reports\\Derivisi.jasper" );
	    	
//	    	JasperCompileManager.compileReportToFile("D:\\workspace\\deri_web\\WebContent\\reports\\Derivisi2.jrxml",
//			"D:\\workspace\\deri_web\\WebContent\\reports\\Derivisi2.jasper" );

	    	Map<String, Object> params = new HashMap<String, Object>();
//	    	Map params = new HashMap();

	    	
	    	SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
	    	params.put("P_FECHATRA", sdf.format(fechatra));
	    	params.put("P_ENTIOPER", entidad);
	    	params.put("P_CONTRAPA",contrapa);
	    	params.put("P_USUARIO",credentials.getUsername());
	    	params.put("P_ROOT",getClass().getClassLoader().getResource("/reports/").toString());
	    	params.put("SUBREPORT_DIR",jasperSubReport);
	    	if (!GenericUtils.isNullOrBlank(subReport2)){
	    		params.put("SUBREPORT_DIR2",jasperSubReport_DOS);	
	    	}
	    	
	    		  Connection result = null;
	    	      Context initialContext = new InitialContext();
	    	      if ( initialContext != null){
	    	    	  DataSource datasource = (DataSource)initialContext.lookup("java:/jboss/deri_webDatasource");
//	    	    	  DataSource datasource = (DataSource)initialContext.lookup("java:/jboss/deriMex_webDatasource");
	    	      if (datasource != null) {
	    	    	  result = datasource.getConnection();
	    	      }
	    	      }
	    	      if (result==null){
	    	    	  statusMessages.addFromResourceBundle(Severity.ERROR, "listadovisibilidad.error.conexion");
	    	    	  return;
	    	      }
	    	    
	    	
	    	
//	    	DriverManager.registerDriver(new oracle.jdbc.driver.OracleDriver());
//	    	Session session = (Session)em.getDelegate();
//	    	Connection conn = session.connection();
//	    	Connection conexion = DriverManager.getConnection("jdbc:oracle:thin:@172.30.80.66:1558:TRADEDES", "ops$deptre", "proves");
	    	

	    	
	    	jasperPrint = JasperFillManager.fillReport(
	    			jasperReport, params, result);
	     
	    	if (!result.isClosed()){
	    		result.close();
	    	}
//	    	jasperPrint = JasperFillManager.fillReport(
//	    			input, params, conexion);
	    	
	
	      redirectExport(JasperExportManager.exportReportToPdf(jasperPrint));
	      return;
	    }
	    catch (Exception e)
	    {
	      e.printStackTrace();
	      return;
	    }
	}
	
	public void init(){
		if(null==messageBoxListadoVisibilidadAction){
			messageBoxListadoVisibilidadAction = new MessageBoxAction();
}
	}

	public void voidFunction(){
		msgBoxAction.voidFunction();
	}
	
	/**
	 * Mostrar PopUp cuando una contrapartida está bloqueada (no bloqueante)
	 */
	public void onVerificarContrapartidaBloqueada() {
		String contrapartida = listadoVisibilidadPantalla.getContrapartida();
		if (!GenericUtils.isNullOrBlank(contrapartida)){
			 Contrapartida contrapObtenida2 = listadosVisibilidadBo.cargarContrapartida(contrapartida.toUpperCase());	
			if (null!=contrapObtenida2 && !GenericUtils.isNullOrBlank(contrapObtenida2.getIndBloqueo()) && "S".equalsIgnoreCase(contrapObtenida2.getIndBloqueo())){
				messageBoxListadoVisibilidadAction.init("listadovisibilidad.messages.contrapartida.bloqueada.texto", "listadoVisibilidadAction.voidFunction()", null,"messageBoxPanelContrapa");
			}
		}
	}
	
}
