package com.atosorigin.deri.applistados.listadosvisibilidad.screen;

import java.util.Date;

import org.ajax4jsf.component.html.HtmlAjaxCommandButton;
import org.jboss.seam.ScopeType;
import org.jboss.seam.annotations.In;
import org.jboss.seam.annotations.Name;
import org.jboss.seam.annotations.Out;
import org.jboss.seam.annotations.Scope;

import com.atosorigin.deri.model.appListados.Listados;

/**
 *  Contiene los datos de pantalla necesarios para el caso de uso de titulares de la ordén.
 */

@Name("listadoVisibilidadPantalla")
@Scope(ScopeType.CONVERSATION)
public class ListadoVisibilidadPantalla {

	protected Listados listados;

	protected Date fechaListado;
	
	protected String contrapartida;
	
	@In(create=true, required = false)
	@Out(required = false)
	protected HtmlAjaxCommandButton reportButton;
	
	protected Boolean buttonVisibility = false;

	public String getContrapartida() {
		return contrapartida;
	}

	public void setContrapartida(String contrapartida) {
		this.contrapartida = contrapartida;
	}

	public Date getFechaListado() {
		return fechaListado;
	}

	public void setFechaListado(Date fechaListado) {
		this.fechaListado = fechaListado;
	}
	
	public Listados getListados() {
		return listados;
	}

	public void setListados(Listados listados) {
		this.listados = listados;
	}

	public HtmlAjaxCommandButton getReportButton() {
//		if(reportButton == null) {
//			Application app = FacesContext.getCurrentInstance().getApplication();
//			reportButton = (HtmlAjaxCommandButton)app.createComponent(HtmlAjaxCommandButton.COMPONENT_TYPE);
//			reportButton.setId("reportCommandButton");
//		}
		return reportButton;
	}

	public void setReportButton(HtmlAjaxCommandButton reportButton) {
		this.reportButton = reportButton;
	}

	public Boolean getButtonVisibility() {
		return buttonVisibility;
	}

	public void setButtonVisibility(Boolean buttonVisibility) {
		this.buttonVisibility = buttonVisibility;
	}	
}
