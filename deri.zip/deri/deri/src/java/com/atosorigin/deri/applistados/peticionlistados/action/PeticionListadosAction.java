package com.atosorigin.deri.applistados.peticionlistados.action;

import java.text.NumberFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.Iterator;
import java.util.List;
import java.util.Set;

import javax.persistence.EntityManager;

import org.jboss.seam.ScopeType;
import org.jboss.seam.annotations.In;
import org.jboss.seam.annotations.Name;
import org.jboss.seam.annotations.Scope;
import org.jboss.seam.international.StatusMessage.Severity;
import org.jboss.seam.security.Credentials;
import org.richfaces.component.html.HtmlExtendedDataTable;
import org.richfaces.model.selection.SimpleSelection;

import com.atosorigin.common.action.ModoPantalla;
import com.atosorigin.common.action.PaginatedListAction;
import com.atosorigin.common.constantes.Constantes;
import com.atosorigin.common.formvalidator.FormValidator;
import com.atosorigin.common.utils.DateIterator;
import com.atosorigin.common.utils.GenericUtils;
import com.atosorigin.deri.appListados.peticionlistados.business.PeticionListadosBo;
import com.atosorigin.deri.applistados.peticionlistados.screen.InformeCompleto;
import com.atosorigin.deri.applistados.peticionlistados.screen.InformeEnCurso;
import com.atosorigin.deri.applistados.peticionlistados.screen.PeticionListadosPantalla;
import com.atosorigin.deri.model.appListados.Informe;
import com.atosorigin.deri.model.appListados.InformeParametro;
import com.atosorigin.deri.model.appListados.Parametro;
import com.atosorigin.deri.model.appListados.PeticionCliente;
import com.atosorigin.deri.model.appListados.PeticionInforme;
import com.atosorigin.deri.model.seguridad.Usuario;
import com.atosorigin.deri.seguridad.mantusuario.business.UsuarioBo;

/**
 * Clase action listener para el caso de uso de mantenimiento de peticions.
 */
@Name("peticionListadosAction")
@Scope(ScopeType.CONVERSATION)
@FormValidator
public class PeticionListadosAction extends PaginatedListAction {
	
    @In Credentials credentials;
    
	@In("entityManager")
	protected EntityManager em;
	
	/**
	 * Inyección del bean de Spring "peticionListadosBo" que contiene los métodos de negocio
	 * para el caso de uso mantenimiento de listados.
	 */
	@In("#{peticionListadosBo}")
	protected PeticionListadosBo peticionListadosBo;

	/**
	 * Inyección del bean de Spring "usuarioBo" que contiene los métodos de negocio
	 * para el caso de uso mantenimiento de listados.
	 */
	@In("#{usuarioBo}")
	protected UsuarioBo usuarioBo;
	
	/**
	 * Inyección del screen bean que contiene los datos de pantalla del caso de uso
	 * mantenimiento de listados.
	 */
	@In(create=true)
	protected PeticionListadosPantalla peticionListadosPantalla;
	
	
	public void existenteSeleccionadoEvent() {
		peticionListadosPantalla.setExistenteSeleccionado(true);
	}
	
	public void configuradoSeleccionadoEvent() {
		peticionListadosPantalla.setConfiguradoSeleccionado(true);
	}
	
	public void completoSeleccionadoEvent() {
		peticionListadosPantalla.setCompletoSeleccionado(true);
	}
	
	public void borrarConfigurado() {
		peticionListadosPantalla.setBorrarConfigurado(true);
		peticionListadosPantalla.setBorrarCompleto(false);
		getInformeConfiguradoSeleccionado();
	}
	
	public void borrarCompleto() {
		peticionListadosPantalla.setBorrarConfigurado(false);
		peticionListadosPantalla.setBorrarCompleto(true);
	}
	
	/**
	 * Primero se creará un TIMER que salte cada 5 segundos (cada 5 segundos se ejecutará TimerExpirado).<br/>
	 * Luego se informarán todas las listas.
	 */
	public void preCargarListasInformes() {
		// TIMER
		peticionListadosPantalla.setPollEnabled(true);
		obtenerPerfilUsuario();
		peticionListadosPantalla.setInformesExistentes(getInformesExistentes());
		updateInformesConfigurados();
		// Valor por defecto 'U'
		peticionListadosPantalla.setTipoInforme(Constantes.TIPO_INFORME_USUARIO);
		updateInformesEnCurso();
		updateInformesCompletos();
		resetModalPanel();
		
//		redirect("MANTCAMP");
	}

	public void preCargarValores() {
		refrescarLista();
	}
	
	public void updateValorInformeParametro(String valor) {
		InformeParametro informeParametro = peticionListadosPantalla.getInformeParametroSeleccionado();
		informeParametro.setValor(valor);
	}

	private void obtenerPerfilUsuario() {
		Usuario usuario = usuarioBo.buscarUsuarioUsername(credentials.getUsername());
		if(usuario != null) {
			peticionListadosPantalla.setPerfilUsuario(usuario.getPerfil());
		}
	}
	
	public void preAltaPeticion() {
		this.setModoPantalla(ModoPantalla.CREACION);
		resetModalPanel();
		List<Object> list = extractObjectFromSelection(peticionListadosPantalla.getSelectionExistentes(),peticionListadosPantalla.getTableExistentes());
		if(list.size() == 1) {
			Informe informe = (Informe)list.get(0);
			if(informe!=null){
				peticionListadosPantalla.setCodigoInformeSistema(informe.getId().getCodigo());
				peticionListadosPantalla.setDescripcionInformeSistema(informe.getDescripcion());
				peticionListadosPantalla.setInformeParametros(peticionListadosBo.obtenerParametrosInforme(informe));
				peticionListadosPantalla.setcMando(false);
			}
		}
	}
	
	public PeticionInforme altaPeticion() {
		String codigoSistema = peticionListadosPantalla.getCodigoInformeSistema();
		String cMando = (String)getCMando(peticionListadosPantalla.getcMando());
		String parametros = agregarParametros(codigoSistema, peticionListadosPantalla.getInformeParametros());
		PeticionInforme peticionInforme = peticionListadosBo.altaPeticion(codigoSistema, peticionListadosPantalla.getCodigoInformeUsuario(), 
				peticionListadosPantalla.getDescripcionInformeUsuario(), parametros, cMando, credentials.getUsername());
		resetModalPanel();
		updateInformesConfigurados();
		
		return peticionInforme;
	}
	
	public boolean altaPeticionValidator() {
		// Si estamos en modo alta, comprobamos que no hay una petición igual
		if(ModoPantalla.CREACION.equals(this.getModoPantalla())) {
			PeticionInforme peticionInforme = peticionListadosBo.getPeticion(peticionListadosPantalla.getCodigoInformeSistema(), peticionListadosPantalla.getCodigoInformeUsuario(), credentials.getUsername());
			if (!GenericUtils.isNullOrBlank(peticionInforme)){
				statusMessages.addToControl("codigoInformeUsuario", Severity.ERROR, "peticionListados.error.yaExiste", Constantes.DEFAULT_MESSAGE_TEMPLATE);
				updateInformesConfigurados();
				return false;
			}
		}
		
		return true;
	}
	
	/**
	 * Se añade el nombre del parámetro y el valor a la lista de parámetros:<br/>
	 * parametros = parametros || InformeParametro.ParametroInforme.Nombre ||'@'||valor||'/';<br/>
	 * (si el campo valor no está informado no se añade, con lo que quedaría nombreparametro@/ )
	 * 
	 * @param codigoSistema
	 * @param informeParametros
	 * 
	 * @return String
	 */
	public String agregarParametros(String codigoSistema, List<InformeParametro> informeParametros) {
		String parametros = "";
		for (Iterator<InformeParametro> iterator = informeParametros.iterator(); iterator.hasNext();) {
			InformeParametro informeParametro = (InformeParametro) iterator.next();
			if(informeParametro != null) {
				Parametro parametro = informeParametro.getId().getParametro();
				String nombreParametro = parametro.getId().getNombre();
				String valorParametro =  informeParametro.getValor();
				if(Constantes.PARAM_TIPO_DATE_COD.equalsIgnoreCase(parametro.getId().getTipo())) {
					String valorParametroAux = valorParametro;
					// Formateamos fecha: DDMMYYYY -> YYYYMMDD
					if(valorParametroAux.contains(Constantes.SEPARADOR_FECHA)) {
						valorParametro = valorParametro.substring(valorParametroAux.lastIndexOf(Constantes.SEPARADOR_FECHA)+1, valorParametroAux.length());
						valorParametro = valorParametro.concat(valorParametroAux.substring(valorParametroAux.indexOf(Constantes.SEPARADOR_FECHA)+1, valorParametroAux.lastIndexOf(Constantes.SEPARADOR_FECHA)));
						valorParametro = valorParametro.concat(valorParametroAux.substring(0,valorParametroAux.indexOf(Constantes.SEPARADOR_FECHA)));
					} else {
						valorParametro = valorParametroAux.substring(4,8).concat(valorParametroAux.substring(2,4)).concat(valorParametroAux.substring(0,2));
					}
				}
				// nombre_param1@valor_param1/nombre_param2@valor...
				String strParametro = nombreParametro.concat(Constantes.SEPARADOR_PARAMETRO_VALOR.concat(valorParametro));
				parametros = parametros.concat(strParametro.concat(Constantes.SEPARADOR_PARAMETROS));
			}
		}
		return parametros.concat(codigoSistema);
	}
	
	public void preDetallePeticion() {
		this.setModoPantalla(ModoPantalla.INSPECCION);
		preparaPeticion(peticionListadosPantalla.getSelectionConfigurados(),peticionListadosPantalla.getTableConfigurados());
	}
	
	public void preModificacionPeticion() {
		this.setModoPantalla(ModoPantalla.EDICION);
		preparaPeticion(peticionListadosPantalla.getSelectionConfigurados(),peticionListadosPantalla.getTableConfigurados());
	}
	
	public void preDetalleCompletos() {
		this.setModoPantalla(ModoPantalla.INSPECCION);
		preparaPeticion(peticionListadosPantalla.getSelectionCompletos(),peticionListadosPantalla.getTableCompletos());
	}
	
	public void bajaPeticion() {
		if(peticionListadosPantalla.getPeticionInformeConfiguradoSeleccionado()!=null) {
			peticionListadosBo.bajaPeticion(peticionListadosPantalla.getPeticionInformeConfiguradoSeleccionado(),credentials.getUsername());
			peticionListadosPantalla.setPeticionInformeConfiguradoSeleccionado(null);
			updateInformesConfigurados();
		}
	}
	
	public void bajaCompletos() {
		List<Object> list = extractObjectFromSelection(peticionListadosPantalla.getSelectionCompletos(),peticionListadosPantalla.getTableCompletos());
		List<PeticionCliente> peticionClientes = new ArrayList<PeticionCliente>(0);
		for (Iterator<Object> iterator = list.iterator(); iterator.hasNext();) {
			PeticionCliente peticionCliente = (PeticionCliente) iterator.next();
			peticionClientes.add(peticionCliente);
		}
		peticionListadosBo.bajaPeticionCompletada(peticionClientes);
		updateInformesCompletos();
	}
	
	public void timerExpirado() {
		System.out.println(">>>>>>>>> POLL!");
		if(!peticionListadosPantalla.getCompletoSeleccionado()) {
			updateInformesCompletos();
		} else {
			updateInformesEnCurso();
		}
	}

	public void updateInformesCompletos() {
		peticionListadosPantalla.setInformesCompletos(getInformesCompletos(peticionListadosPantalla.getTipoInforme()));
	}

	public void ejecutarInforme(boolean save) {
		Date fechaInicio = peticionListadosPantalla.getFechaInicio();
		Date fechaFinal = peticionListadosPantalla.getFechaFin();
		PeticionInforme peticionInforme = null;
		if((!save) || (ModoPantalla.INSPECCION.equals(this.getModoPantalla()))) {
			peticionInforme = getInformeConfiguradoSeleccionado();
		} else {
			peticionInforme = altaPeticion();
		}
		
		DateIterator dateIterator = new DateIterator(fechaInicio, fechaFinal);
		while(dateIterator.hasNext()) {
			if(peticionInforme != null) {
				Date fecha = (Date)dateIterator.next();
				if(!esFestivo(fecha)) {
					desglosarPeticionInforme(peticionInforme, fecha);
				}
			}
		}
		// TODO EJECUTAR TIMER?
		peticionListadosPantalla.setPollEnabled(true);
		updateInformesEnCurso();
		updateInformesCompletos();
	}

	public boolean ejecutarInformeValidator() {
		Date fechaInicio = peticionListadosPantalla.getFechaInicio();
		Date fechaFinal = peticionListadosPantalla.getFechaFin();
		
		if(!GenericUtils.isNullOrBlank(fechaInicio) && !GenericUtils.isNullOrBlank(fechaFinal)){
			if(fechaInicio.after(fechaFinal)){
				statusMessages.add(Severity.ERROR, "#{messages['peticionListados.error.fechasErroneas']}");
				return false;
			}
		}
		return true;
	}

	private Boolean esFestivo(Date fecha) {
		if(fecha != null) {
			Calendar cal = new GregorianCalendar();
			cal.setTime(fecha);
			int dayOfWeek = cal.get(java.util.Calendar.DAY_OF_WEEK);
			if(dayOfWeek == 7 || dayOfWeek == 8) {
				return true;
			}
		}
		return false;
	}
	
	private void desglosarPeticionInforme(PeticionInforme peticionInforme, Date fecha) {
		int correctos = 0;
		int contador = 1;
		int status = peticionListadosBo.insertarPeticionCliente(peticionInforme, fecha, credentials.getUsername());
		correctos = status;
		if(correctos == 0) {
			statusMessages.addToControl("fechaInicio", Severity.ERROR, "peticionListados.error.todosSolicitados", Constantes.DEFAULT_MESSAGE_TEMPLATE);
		} else if(correctos != contador) {
			statusMessages.addToControl("fechaInicio", Severity.ERROR, "peticionListados.error.algunosSolicitados", Constantes.DEFAULT_MESSAGE_TEMPLATE);
		}
	}

	private void preparaPeticion(SimpleSelection selection, HtmlExtendedDataTable table) {
		resetModalPanel();
		List<Object> list = extractObjectFromSelection(selection,table);
		if(list.size() == 1) {
			PeticionInforme peticionInforme = (PeticionInforme)list.get(0);
			if(peticionInforme!=null){
				Informe informe = peticionInforme.getId().getInforme();
				peticionListadosPantalla.setCodigoInformeSistema(informe.getId().getCodigo());
				peticionListadosPantalla.setDescripcionInformeSistema(informe.getDescripcion());
				peticionListadosPantalla.setCodigoInformeUsuario(peticionInforme.getId().getCodigoInformeUsuario());
				peticionListadosPantalla.setDescripcionInformeUsuario(peticionInforme.getDescripcionInforme());
				peticionListadosPantalla.setcMando((Boolean)getCMando(peticionInforme.getIndicadorMando()));
				peticionListadosPantalla.setInformeParametros(extraerParametros(peticionInforme.getParametrosInforme(),informe.getInformeParametros()));
			}
		}
	}

	private Object getCMando(Object cMandoIn) {
		Object cMandoOut = null;
		if(cMandoIn instanceof Boolean) {
			cMandoOut = "0";
			Boolean cMando = (Boolean)cMandoIn;
			if(cMando == true) {
				cMandoOut = "1";
			}
		} else if(cMandoIn instanceof String) {
			cMandoOut = false;
			String cMando = (String)cMandoIn;
			if("1".equalsIgnoreCase(cMando)) {
				cMandoOut = true;
			}
		}
		return cMandoOut;
	}

	private void resetModalPanel() {
		peticionListadosPantalla.setCodigoInformeSistema(null);
		peticionListadosPantalla.setDescripcionInformeSistema(null);
		peticionListadosPantalla.setCodigoInformeUsuario(null);
		peticionListadosPantalla.setDescripcionInformeUsuario(null);
		List<InformeParametro> informeParametros = peticionListadosPantalla.getInformeParametros();
		if(informeParametros != null) {
			for (Iterator<InformeParametro> iterator = informeParametros.iterator(); iterator.hasNext();) {
				InformeParametro informeParametro = (InformeParametro) iterator.next();
				informeParametro.setValor(null);
				informeParametro = null;
			}
			peticionListadosPantalla.setInformeParametros(null);
		}
		peticionListadosPantalla.setcMando(false);
	}

	private void updateInformesConfigurados() {
		peticionListadosPantalla.setInformesConfigurados(peticionListadosBo.obtenerInformesConfigurados(Constantes.TIPO_INFORME_USUARIO,credentials.getUsername()));
	}
	
	private void updateInformesEnCurso() {
		peticionListadosPantalla.setInformesEnCurso(getInformesEnCurso(peticionListadosPantalla.getTipoInforme()));
	}

	private List<Object> extractObjectFromSelection(SimpleSelection selection, HtmlExtendedDataTable table) {
		List<Object> ret = new ArrayList<Object>(0);
		if(selection != null && table != null) {
			Iterator<Object> iterator = selection.getKeys();
			while (iterator.hasNext()) {
				Object key = iterator.next();
				table.setRowKey(key);
				if (table.isRowAvailable()) {
					ret.add(table.getRowData());
				}
			}
		}
		return ret;
	}

	private PeticionInforme getInformeConfiguradoSeleccionado() {
		PeticionInforme peticionInforme = null;
		List<Object> result = extractObjectFromSelection(peticionListadosPantalla.getSelectionConfigurados(), peticionListadosPantalla.getTableConfigurados());
		if(result.size() == 1){
			peticionInforme = (PeticionInforme)result.get(0);
			peticionListadosPantalla.setPeticionInformeConfiguradoSeleccionado(peticionInforme);
			peticionListadosPantalla.setSelectionConfigurados(null);
		}
		return peticionInforme;
	}
	
	private List<InformeParametro> extraerParametros(String parametros, Set<InformeParametro> informeParametros) {
		List<InformeParametro> listInformeParametros = new ArrayList<InformeParametro>(informeParametros);
		String[] parametrosValor = parametros.split(Constantes.SEPARADOR_PARAMETROS);
		// -1 pq el ultimo parametro es el codigo del informe, NO nos interesa
		for (int i = 0; i < parametrosValor.length-1; i++) {
			String[] parametroValor = parametrosValor[i].split(Constantes.SEPARADOR_PARAMETRO_VALOR);
			
			for (Iterator<InformeParametro> iterator = listInformeParametros.iterator(); iterator.hasNext();) {
				InformeParametro informeParametro = (InformeParametro) iterator.next();
				Parametro parametro = informeParametro.getId().getParametro();
				if(parametro.getId().getNombre().equalsIgnoreCase(parametroValor[0])) {
					String valor = parametroValor[1];
					if(Constantes.PARAM_TIPO_DATE_COD.equalsIgnoreCase(parametro.getId().getTipo())) {
						String valorAux = valor;
						// Formateamos fecha: YYYYMMDD -> DDMMYYYY
						valor = valorAux.substring(6, 8).concat(valorAux.substring(4, 6)).concat(valorAux.substring(0, 4));
					}
					informeParametro.setValor(valor);
					break;
				}
			}
		}
		return listInformeParametros;
	}

	private List<Informe> getInformesExistentes() {
		return peticionListadosBo.obtenerInformesExistentes(peticionListadosPantalla.getPerfilUsuario());
	}

	private List<InformeEnCurso> getInformesEnCurso(String tipoInforme) {
		List<InformeEnCurso> informesEnCurso = new ArrayList<InformeEnCurso>(0);
		List<PeticionCliente> informes = peticionListadosBo.obtenerInformesCurso(tipoInforme,credentials.getUsername());
		for (Iterator<PeticionCliente> iterator = informes.iterator(); iterator.hasNext();) {
			PeticionCliente informe = (PeticionCliente) iterator.next();
			
			InformeEnCurso informeEnCurso = new InformeEnCurso();
			informeEnCurso.setDescripcion(informe.getPeticionInforme().getDescripcionInforme());
			informeEnCurso.setFecha(informe.getFechaRegistro());
			informeEnCurso.setEstado(informe.getIndicadorEstado());
			
			int tiempore = peticionListadosBo.getTiempore();
			int procesados = informe.getRegistrosProcesados();
			int total = informe.getTotalRegistros();
			if(tiempore == 0 || total == 0 || procesados == 0) { // Si tiempore es NULL ó PeticionCliente.TotalRegistros es NULL ó 0 ó PeticionCliente. RegistrosProcesados es NULL
				// Progreso 0%
				informeEnCurso.setProgreso("0");
			} else {
				// Calculamos % progreso
				Float progreso = new Float((procesados / total)*100);
				informeEnCurso.setProgreso(progreso.toString());
				
				// v_tiempo := (total - procesados) * tiempore/100;
				int tiempo = new Float((total - procesados)*(tiempore/100)).intValue();
				informeEnCurso.settProceso(obtenerTProceso(tiempo));
				
				// v_llevado := (sysdate - fechapeticion)*24*3600;
				tiempo = ((peticionListadosBo.getRestaFechas(informe.getNumeroPeticion()).intValue())*24*3600);
				informeEnCurso.sethProceso(obtenerTProceso(tiempo));
			}
			informesEnCurso.add(informeEnCurso);
		}
		return informesEnCurso;
	}

	/**
	 * v_horas := trunc(v_tiempo/3600);
	 * v_minutos := trunc((v_tiempo - v_horas*3600)/60);
	 * v_segundos := v_tiempo - v_horas*3600 - v_minutos *60;		            	   
	 * tiempoproceso := substr(to_char(v_horas,'900'),2,3)||':'||substr(to_char(v_minutos,'00'),2,2)||':'||substr(to_char(v_segundos,'00'),2,2)
	 * 
	 * @param tiempo
	 * 
	 * @return tiempoproceso
	 */
	private String obtenerTProceso(int tiempo) {
		int horas = new Float(tiempo/3600).intValue();
		int minutos = new Float((tiempo - (horas*3600))/60).intValue();
		int segundos = tiempo - (horas*3600) - (minutos*60);
		
		NumberFormat nf = NumberFormat.getInstance();
		nf.setMinimumIntegerDigits(2);
		return nf.format(horas) + ":" + nf.format(minutos) + ":" + nf.format(segundos);
	}

	private List<InformeCompleto> getInformesCompletos(String tipoInforme) {
		List<InformeCompleto> informesCompletos = new ArrayList<InformeCompleto>(0);
		List<PeticionCliente> informes = peticionListadosBo.obtenerInformesCompletos(tipoInforme,credentials.getUsername());
		for (Iterator<PeticionCliente> iterator = informes.iterator(); iterator.hasNext();) {
			PeticionCliente informe = (PeticionCliente) iterator.next();
			InformeCompleto informeCompleto = new InformeCompleto();
			informeCompleto.setDescripcion(informe.getPeticionInforme().getDescripcionInforme());
			informeCompleto.setFecha(informe.getFechaRegistro());
			if(informe.getIndicadorEstado() == Constantes.INDICADOR_INFORME_FINALIZADO) {
				informeCompleto.setEstado(Constantes.ESTADO_INFORME_FINALIZADO);
			} else if(informe.getIndicadorEstado() == Constantes.INDICADOR_INFORME_IMPRESION) {
				informeCompleto.setEstado(Constantes.ESTADO_INFORME_IMPRESION);
			}
			informesCompletos.add(informeCompleto);
		}
		return informesCompletos;
	}

	public Credentials getCredentials() {
		return credentials;
	}

	public void setCredentials(Credentials credentials) {
		this.credentials = credentials;
	}

	@Override
	protected void refreshListInternal() {
		List<Object> list = extractObjectFromSelection(peticionListadosPantalla.getSelectionParametros(),peticionListadosPantalla.getTableParametros());
		if(list.size() == 1) {
			InformeParametro informeParametro = (InformeParametro)list.get(0);
			peticionListadosPantalla.setInformeParametroSeleccionado(informeParametro);
			String seleccion = informeParametro.getId().getParametro().getSeleccion();
			
			List<Object[]> valoresParametro = new ArrayList<Object[]>();
			List<Object> result = peticionListadosBo.executeQuery(seleccion);
			for (Iterator<Object> iterator = result.iterator(); iterator.hasNext();) {
				Object object = iterator.next();
				if(object instanceof Object[]) {
					Object[] valorParametro = (Object[])object;
					valoresParametro.add(valorParametro);
				}
			}
			peticionListadosPantalla.setValoresParametro(valoresParametro);
		}
	}

	@Override
	public void refrescarListaExcel() {
		// Nothing to do
		
	}

	@Override
	public List<?> getDataTableList() {
		return peticionListadosPantalla.getValoresParametro();
	}

	@Override
	@SuppressWarnings("unchecked")
	public void setDataTableList(List<?> dataTableList) {
		peticionListadosPantalla.setValoresParametro((List<Object[]>)dataTableList);
	}
	
}
