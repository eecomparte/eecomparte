package com.atosorigin.deri.applistados.peticionlistados.screen;

import java.util.Date;

public class InformeEnCurso {

	private String descripcion;
	private Date fecha;
	private String estado;
	private String progreso;
	private String tiempo;
	private String tProceso;
	private String hProceso;
	
	public String getDescripcion() {
		return descripcion;
	}
	public void setDescripcion(String descripcion) {
		this.descripcion = descripcion;
	}
	public Date getFecha() {
		return fecha;
	}
	public void setFecha(Date fecha) {
		this.fecha = fecha;
	}
	public String getEstado() {
		return estado;
	}
	public void setEstado(String estado) {
		this.estado = estado;
	}
	public String getProgreso() {
		return progreso;
	}
	public void setProgreso(String progreso) {
		this.progreso = progreso;
	}
	public String getTiempo() {
		return tiempo;
	}
	public void setTiempo(String tiempo) {
		this.tiempo = tiempo;
	}
	public String gettProceso() {
		return tProceso;
	}
	public void settProceso(String tProceso) {
		this.tProceso = tProceso;
	}
	public String gethProceso() {
		return hProceso;
	}
	public void sethProceso(String hProceso) {
		this.hProceso = hProceso;
	}
}
