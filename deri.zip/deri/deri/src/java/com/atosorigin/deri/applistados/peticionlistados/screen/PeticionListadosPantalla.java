package com.atosorigin.deri.applistados.peticionlistados.screen;

import java.util.Date;
import java.util.List;

import org.jboss.seam.ScopeType;
import org.jboss.seam.annotations.In;
import org.jboss.seam.annotations.Name;
import org.jboss.seam.annotations.Out;
import org.jboss.seam.annotations.Scope;
import org.jboss.seam.annotations.datamodel.DataModel;
import org.richfaces.component.html.HtmlExtendedDataTable;
import org.richfaces.model.selection.SimpleSelection;

import com.atosorigin.deri.model.appListados.Informe;
import com.atosorigin.deri.model.appListados.InformeParametro;
import com.atosorigin.deri.model.appListados.PeticionInforme;

/**
* Contiene los datos de pantalla necesarios para el caso de uso mantenimiento de listados.
*/
@Name("peticionListadosPantalla")
@Scope(ScopeType.CONVERSATION)
public class PeticionListadosPantalla {
	
	/** Criterios Seleccion */
	protected Date fechaInicio;
	protected Date fechaFin;
	protected String tipoInforme;
	
	protected Integer perfilUsuario;
	
	/** Modal Panel */
	protected String codigoInformeSistema;
	protected String descripcionInformeSistema;
	protected String codigoInformeUsuario;
	protected String descripcionInformeUsuario;
	protected Boolean cMando;
	@DataModel(value="listaInformeParametros")
    protected List<InformeParametro> informeParametros;
	
	/** informes existentes */
	@DataModel(value="listaInformesExistentes")
    protected List<Informe> informesExistentes;
	
	/** informes configurados */
	@DataModel(value="listaInformesConfigurados")
    protected List<PeticionInforme> informesConfigurados;
	
    /** informes */
	protected List<InformeEnCurso> informesEnCurso;
	protected List<InformeCompleto> informesCompletos;
	
	/** extended data table */
	@In(create=true, required = false)
	@Out(required = false)
	private HtmlExtendedDataTable tableExistentes;
	
	@In(create=true, required = false)
	@Out(required = false)
	private HtmlExtendedDataTable tableConfigurados;
	
	@In(create=true, required = false)
	@Out(required = false)
	private HtmlExtendedDataTable tableCompletos;
	
	/** informe seleccionado */
	private SimpleSelection selectionExistentes;
	private SimpleSelection selectionConfigurados;
	private SimpleSelection selectionCompletos;
	
	private Boolean existenteSeleccionado = false;
	private Boolean configuradoSeleccionado = false;
	private Boolean completoSeleccionado = false;
	
	private Boolean pollEnabled = false;
	
	private Boolean borrarConfigurado = false;
	private Boolean borrarCompleto = false;
	
	private PeticionInforme peticionInformeConfiguradoSeleccionado;
	
	/** valores de los parametros */
	@In(create=true, required = false)
	@Out(required = false)
	private HtmlExtendedDataTable tableParametros;
	private SimpleSelection selectionParametros;
	@DataModel(value="listaValoresParametro")
    @Out(required=false)
    protected List<Object[]> valoresParametro;
    private InformeParametro informeParametroSeleccionado;
	
	public PeticionListadosPantalla() {
		super();
	}

	public Date getFechaInicio() {
		return fechaInicio;
	}
	
	public void setFechaInicio(Date fechaInicio) {
		this.fechaInicio = fechaInicio;
	}
	
	public Date getFechaFin() {
		return fechaFin;
	}
	
	public void setFechaFin(Date fechaFin) {
		this.fechaFin = fechaFin;
	}
	
	public String getTipoInforme() {
		return tipoInforme;
	}
	
	public void setTipoInforme(String tipoInforme) {
		this.tipoInforme = tipoInforme;
	}
	
	public List<Informe> getInformesExistentes() {
		return informesExistentes;
	}
	
	public void setInformesExistentes(List<Informe> informesExistentes) {
		this.informesExistentes = informesExistentes;
	}
	
	
	public List<InformeEnCurso> getInformesEnCurso() {
		return informesEnCurso;
	}
	
	public void setInformesEnCurso(List<InformeEnCurso> informesEnCurso) {
		this.informesEnCurso = informesEnCurso;
	}
	
	public List<InformeCompleto> getInformesCompletos() {
		return informesCompletos;
	}
	
	public void setInformesCompletos(List<InformeCompleto> informesCompletos) {
		this.informesCompletos = informesCompletos;
	}

	public String getCodigoInformeSistema() {
		return codigoInformeSistema;
	}

	public void setCodigoInformeSistema(String codigoInformeSistema) {
		this.codigoInformeSistema = codigoInformeSistema;
	}

	public String getDescripcionInformeSistema() {
		return descripcionInformeSistema;
	}

	public void setDescripcionInformeSistema(String descripcionInformeSistema) {
		this.descripcionInformeSistema = descripcionInformeSistema;
	}

	public String getCodigoInformeUsuario() {
		return codigoInformeUsuario;
	}

	public void setCodigoInformeUsuario(String codigoInformeUsuario) {
		this.codigoInformeUsuario = codigoInformeUsuario;
	}

	public String getDescripcionInformeUsuario() {
		return descripcionInformeUsuario;
	}

	public void setDescripcionInformeUsuario(String descripcionInformeUsuario) {
		this.descripcionInformeUsuario = descripcionInformeUsuario;
	}

	public Boolean getcMando() {
		return cMando;
	}

	public void setcMando(Boolean cMando) {
		this.cMando = cMando;
	}

	public HtmlExtendedDataTable getTableExistentes() {
		return tableExistentes;
	}

	public void setTableExistentes(HtmlExtendedDataTable tableExistentes) {
		this.tableExistentes = tableExistentes;
	}

	public HtmlExtendedDataTable getTableConfigurados() {
		return tableConfigurados;
	}

	public void setTableConfigurados(HtmlExtendedDataTable tableConfigurados) {
		this.tableConfigurados = tableConfigurados;
	}

	public SimpleSelection getSelectionExistentes() {
		return selectionExistentes;
	}

	public void setSelectionExistentes(SimpleSelection selectionExistentes) {
		this.selectionExistentes = selectionExistentes;
	}

	public SimpleSelection getSelectionConfigurados() {
		return selectionConfigurados;
	}

	public void setSelectionConfigurados(SimpleSelection selectionConfigurados) {
		this.selectionConfigurados = selectionConfigurados;
	}

	public List<InformeParametro> getInformeParametros() {
		return informeParametros;
	}

	public void setInformeParametros(List<InformeParametro> informeParametros) {
		this.informeParametros = informeParametros;
	}

	public Integer getPerfilUsuario() {
		return perfilUsuario;
	}

	public void setPerfilUsuario(Integer perfilUsuario) {
		this.perfilUsuario = perfilUsuario;
	}

	public Boolean getExistenteSeleccionado() {
		return existenteSeleccionado;
	}

	public void setExistenteSeleccionado(Boolean existenteSeleccionado) {
		this.existenteSeleccionado = existenteSeleccionado;
	}

	public Boolean getConfiguradoSeleccionado() {
		return configuradoSeleccionado;
	}

	public void setConfiguradoSeleccionado(Boolean configuradoSeleccionado) {
		this.configuradoSeleccionado = configuradoSeleccionado;
	}

	public Boolean getPollEnabled() {
		return pollEnabled;
	}

	public void setPollEnabled(Boolean pollEnabled) {
		this.pollEnabled = pollEnabled;
	}

	public Boolean getCompletoSeleccionado() {
		return completoSeleccionado;
	}

	public void setCompletoSeleccionado(Boolean completoSeleccionado) {
		this.completoSeleccionado = completoSeleccionado;
	}

	public HtmlExtendedDataTable getTableCompletos() {
		return tableCompletos;
	}

	public void setTableCompletos(HtmlExtendedDataTable tableCompletos) {
		this.tableCompletos = tableCompletos;
	}

	public SimpleSelection getSelectionCompletos() {
		return selectionCompletos;
	}

	public void setSelectionCompletos(SimpleSelection selectionCompletos) {
		this.selectionCompletos = selectionCompletos;
	}

	public Boolean getBorrarConfigurado() {
		return borrarConfigurado;
	}

	public void setBorrarConfigurado(Boolean borrarConfigurado) {
		this.borrarConfigurado = borrarConfigurado;
	}

	public Boolean getBorrarCompleto() {
		return borrarCompleto;
	}

	public void setBorrarCompleto(Boolean borrarCompleto) {
		this.borrarCompleto = borrarCompleto;
	}

	public List<PeticionInforme> getInformesConfigurados() {
		return informesConfigurados;
	}

	public void setInformesConfigurados(List<PeticionInforme> informesConfigurados) {
		this.informesConfigurados = informesConfigurados;
	}

	public PeticionInforme getPeticionInformeConfiguradoSeleccionado() {
		return peticionInformeConfiguradoSeleccionado;
	}

	public void setPeticionInformeConfiguradoSeleccionado(
			PeticionInforme peticionInformeConfiguradoSeleccionado) {
		this.peticionInformeConfiguradoSeleccionado = peticionInformeConfiguradoSeleccionado;
	}

	public HtmlExtendedDataTable getTableParametros() {
		return tableParametros;
	}

	public void setTableParametros(HtmlExtendedDataTable tableParametros) {
		this.tableParametros = tableParametros;
	}

	public SimpleSelection getSelectionParametros() {
		return selectionParametros;
	}

	public void setSelectionParametros(SimpleSelection selectionParametros) {
		this.selectionParametros = selectionParametros;
	}

	public List<Object[]> getValoresParametro() {
		return valoresParametro;
	}

	public void setValoresParametro(List<Object[]> valoresParametro) {
		this.valoresParametro = valoresParametro;
	}

	public InformeParametro getInformeParametroSeleccionado() {
		return informeParametroSeleccionado;
	}

	public void setInformeParametroSeleccionado(
			InformeParametro informeParametroSeleccionado) {
		this.informeParametroSeleccionado = informeParametroSeleccionado;
	}
}
