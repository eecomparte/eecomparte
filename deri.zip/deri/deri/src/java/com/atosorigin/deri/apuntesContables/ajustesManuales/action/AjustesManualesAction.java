package com.atosorigin.deri.apuntesContables.ajustesManuales.action;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import org.hibernate.SQLQuery;
import org.jboss.seam.ScopeType;
import org.jboss.seam.annotations.Factory;
import org.jboss.seam.annotations.In;
import org.jboss.seam.annotations.Name;
import org.jboss.seam.annotations.Out;
import org.jboss.seam.annotations.Scope;
import org.jboss.seam.core.ResourceBundle;
import org.jboss.seam.international.StatusMessage.Severity;
import org.jboss.seam.security.Credentials;

import com.atosorigin.common.action.ModoPantalla;
import com.atosorigin.common.action.PaginatedListAction;
import com.atosorigin.common.auditdata.AuditData;
import com.atosorigin.common.constantes.Constantes;
import com.atosorigin.common.formvalidator.FormValidator;
import com.atosorigin.common.utils.GenericUtils;
import com.atosorigin.deri.apuntesContables.ajustesManuales.screen.AjustesManualesPantalla;
import com.atosorigin.deri.apuntescontables.ajustesmanuales.business.AjustesManualesBo;
import com.atosorigin.deri.model.apuntesContables.AjustesManuales;
import com.atosorigin.deri.model.apuntesContables.AjustesManualesId;
import com.atosorigin.deri.model.contrapartida.AbstractContrapartida;
import com.atosorigin.deri.model.contrapartida.Contrapartida;
import com.atosorigin.deri.model.gestionoperaciones.HistoricoOperacion;
import com.atosorigin.deri.model.parametrizacion.Divisa;
import com.atosorigin.deri.util.EntityUtil;
import com.atosorigin.deri.util.MessageBoxAction;
import com.atosorigin.deri.util.MsgBoxAction;

/**
 * Clase action listener para el caso de uso de ajustes manuales
 */
@Name("ajustesManualesAction")
@Scope(ScopeType.CONVERSATION)
@FormValidator
public class AjustesManualesAction extends PaginatedListAction {

	/**
	 * Inyección del bean de Spring "ajustesManualesBo" que contiene los métodos de
	 * negocio para el caso de uso ajustes manuales.
	 */
	@In("#{ajustesManualesBo}")
	AjustesManualesBo ajustesManualesBo;
	
	/**
	 * Inyección del screen bean que contiene los datos de pantalla del caso de
	 * uso Ajustes Manuales
	 */
	@In(create = true)
	protected AjustesManualesPantalla ajustesManualesPantalla;
	
	@In Credentials credentials;	
	
	@In("EntityUtil")
    private EntityUtil entityUtil;

	@In(create = true)
	MsgBoxAction msgBoxAction;
	
	@Out(required = false, value = "ajustesManualesMessageBoxAction")
	private MessageBoxAction messageBoxAjustesManualesAction;
	
	private Boolean primeraEjecucionInit=null;
	
	/** Actualiza la lista del grid de ajustes manuales */
	public void buscar() {
		paginationData.reset();
		refrescarLista();
		setPrimerAcceso(false);
	}
	
	public boolean guardarValidator(){
		AjustesManuales ajustesManuales = this.ajustesManualesPantalla.getAjusteManual();
		
		Date fechaRegistro = null;
		
		//Validación Importe a contabilizar
		if (!GenericUtils.validaFormatoDecimal(ajustesManuales.getImporteContabilizar(), 13, 4)){
			statusMessages.addToControl("importe",Severity.ERROR, "#{messages['ajustesmanuales.error.importe.valor']}");
			return false;
		}
		AjustesManualesId ajustesManualesId = ajustesManuales.getId();
		
		String modeloContable = ajustesManualesBo.obtenerModeloContable(ajustesManualesId.getCodigoOperacionRad(), ajustesManualesId.getMomentoRad());
		//Busca MODELCON en tabla Conta.Momentos		
		if (GenericUtils.isNullOrBlank(modeloContable)){
			statusMessages.addToControl("codOper", Severity.ERROR, "ajustesmanuales.error.modelcon.inexistente", Constantes.DEFAULT_MESSAGE_TEMPLATE);			
			return false;
		}		
		ajustesManualesId.setModeloContable(modeloContable);
		
		//Busca FECHAREG en tabla Auditor.Controla
		fechaRegistro = ajustesManualesBo.getFechaDeri();		
		ajustesManualesId.setFechaRegistro(fechaRegistro);						
		ajustesManuales.setId(ajustesManualesId);		
			
		AjustesManuales ajustesManualesExistente = ajustesManualesBo.cargar(ajustesManuales);
		if (ajustesManualesExistente!=null && getModoPantalla().equals(ModoPantalla.CREACION)){				
			statusMessages.add(Severity.ERROR, "#{messages['ajustesmanuales.error.yaexiste']}");						
			return false;
		}						
		
		//Validación Aplicación es campo no numérico
		if (GenericUtils.isNumeric(ajustesManuales.getTipoProductoContrato())){
			statusMessages.addToControl("aplicacion", Severity.ERROR, "ajustesmanuales.error.aplicacion.nonumerico", Constantes.DEFAULT_MESSAGE_TEMPLATE);
			return false;
		}

		if (ajustesManualesPantalla.getEnvContab()){
			ajustesManuales.setEstadoMovimiento(Constantes.EST_MOV_PEN);
		}else{
			ajustesManuales.setEstadoMovimiento(Constantes.EST_MOV_CRC);
		}
		if (ajustesManualesPantalla.getRadContable()){
			ajustesManuales.setConjuntoIndicadoresAuxiliares(Constantes.IND_AUX_CN);
		}else{
			ajustesManuales.setConjuntoIndicadoresAuxiliares(Constantes.IND_AUX_NN);
		}
		
		HistoricoOperacion historicoOperacion = ajustesManualesBo.obtenerHistorico(ajustesManuales);
		if (GenericUtils.isNullOrBlank(historicoOperacion)){
			statusMessages.addToControl("numOper", Severity.ERROR, "ajustesmanuales.error.operacion.inexistente", Constantes.DEFAULT_MESSAGE_TEMPLATE);
			return false;
		}
		
		ajustesManuales.setContrapartida(historicoOperacion.getContrapartida().getId());
		
		AuditData aud = new AuditData();
		aud.setFechaUltimaModi(new Date());
		aud.setUsuarioUltimaModi(credentials.getUsername());
		ajustesManuales.setAuditData(aud);
		
		ajustesManuales.setDivisaContabilizar(ajustesManualesPantalla.getDivisaSelect().getId());
		
		return true;
	}
	
	public String guardar() {
		if (getModoPantalla().equals(ModoPantalla.CREACION)){			
			return crear();
		}else if (getModoPantalla().equals(ModoPantalla.EDICION)){				
			return modificar();
		}
		return Constantes.CONSTANTE_SUCCESS;
	}
	
	public String crear(){		
		AjustesManuales ajustesManuales = this.ajustesManualesPantalla.getAjusteManual();
		
			
		ajustesManualesBo.nuevo(ajustesManuales);		
		refrescarLista();
		
		limpiarPantalla();
		return Constantes.CONSTANTE_SUCCESS;
	}
	
	public String modificar(){
		
		AjustesManualesPantalla ajustesManualesPantalla = this.ajustesManualesPantalla;		
		ajustesManualesBo.guardar(ajustesManualesPantalla.getAjusteManual(), ajustesManualesPantalla.getAjustesManualesIdSelec());
		ajustesManualesBo.recargar(ajustesManualesPantalla.getAjusteManual());
		refrescarLista();		
		limpiarPantalla();
		return Constantes.CONSTANTE_SUCCESS;
	}

	/** Prepara para entrar en el modo edición de un ajuste manual */
	public void editar() {
		setModoPantalla(ModoPantalla.EDICION);		
		cargarAjuste();
		AjustesManuales ajustesManuales = this.ajustesManualesPantalla.getAjusteManual();
		AjustesManualesId ajustesManualesId = new AjustesManualesId();
		ajustesManualesId.setAplicacionOrigenDatos(ajustesManuales.getId().getAplicacionOrigenDatos());
		ajustesManualesId.setFechaRegistro(ajustesManuales.getId().getFechaRegistro());
		ajustesManualesId.setEntidadFormatoBe(ajustesManuales.getId().getEntidadFormatoBe());
		ajustesManualesId.setModeloContable(ajustesManuales.getId().getModeloContable());
		ajustesManualesId.setCodigoOperacionRad(ajustesManuales.getId().getCodigoOperacionRad());
		ajustesManualesId.setMomentoRad(ajustesManuales.getId().getMomentoRad());
		ajustesManualesId.setProductoInterno(ajustesManuales.getId().getProductoInterno());	
		//SMM 25/05/2018
		ajustesManualesId.setFechaOperacion(ajustesManuales.getId().getFechaOperacion());
		this.ajustesManualesPantalla.setAjustesManualesIdSelec(ajustesManualesId);
	}
	
	/** Prepara para entrar en el modo inspección de un ajuste manual */
	public void ver() {
		setModoPantalla(ModoPantalla.INSPECCION);		
		cargarAjuste();
	}	
	
	public void cargarAjuste(){
		AjustesManuales ajustesManuales = null;
		ajustesManuales = ajustesManualesBo.cargar(this.ajustesManualesPantalla.getAjusteManual());
		Divisa d = new Divisa();
		d.setId(ajustesManuales.getDivisaContabilizar());
		this.ajustesManualesPantalla.setDivisaSelect(d);

		if (ajustesManuales.getEstadoMovimiento().equals(Constantes.EST_MOV_PEN)){
			ajustesManualesPantalla.setEnvContab(true);
		}
		if (!GenericUtils.isNullOrBlank(ajustesManuales.getConjuntoIndicadoresAuxiliares()) 
				&& ajustesManuales.getConjuntoIndicadoresAuxiliares().equals(Constantes.IND_AUX_CN)){
			ajustesManualesPantalla.setRadContable(true);
		}
		this.ajustesManualesPantalla.setAjusteManual(ajustesManuales);
	}

	public void excelBatch(){
		List<AjustesManuales> ajustesManualesList = null;
		
		this.setExportExcel(true);		
		AjustesManualesPantalla pantalla = this.ajustesManualesPantalla;		
		ajustesManualesList = ajustesManualesBo.buscar(pantalla.getfValor(), pantalla.getEntidadSelected(), pantalla.getOficinaSelected(), 
				pantalla.getProdOperSelected(), pantalla.getNumOper(), pantalla.getfContr(), pantalla.getCodOperaSelected(), 
				pantalla.getEstadoSelected(), pantalla.getFechaRegistro(),true, paginationData);		
		
		procesoExcelBatch(ajustesManualesList);
	}
	
	private void procesoExcelBatch(List<AjustesManuales> ajustesManualesList) {
		String sqlTxt = null; String sustitucion = null; String sqlHeader = null;
		
		sqlHeader ="F. Valor;Entidad;Oficina;Prod. Oper;Num.Oper;F. Contrat;Cod. opera;Estado;Descripcion Ajuste";
		

		if (ajustesManualesList!=null && ajustesManualesList.size()>0){
			
			SQLQuery sql = ajustesManualesList.get(0).getSqlQuery();
			sqlTxt = sql.getQueryString();
			for (String param : sql.getNamedParameters()) {
				sustitucion = obtenerSustitucion(param);
				param = ":".concat(param);
				
				sqlTxt =	sqlTxt.replaceAll(param , sustitucion);	
			}	
		
			Long peticion = ajustesManualesBo.generarPeticionExcel(sqlTxt,sqlHeader);

			String mensaje = ResourceBundle.instance().getString("ajustesmanuales..excelBatch") + " " + peticion ;
			statusMessages.add(Severity.INFO, mensaje);

		}
	}


	private String obtenerSustitucion(String param) {
		
		SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");

		if ("rownumMin".equalsIgnoreCase(param)){
			return paginationData.getPaginationDataForExcel().getFirstResult().toString();
		}else if ("rownumMax".equalsIgnoreCase(param)){
			return paginationData.getPaginationDataForExcel().getMaxResults().toString();
		}else if ("fechaValorContable".equalsIgnoreCase(param)){
			 return "'".concat(sdf.format(this.ajustesManualesPantalla.getfValor()).toString()).concat("'");
		}else if ("entidadFormatoBe".equalsIgnoreCase(param)){
			return "'".concat(this.ajustesManualesPantalla.getEntidadSelected().toString()).concat("'");
		}else if ("oficina".equalsIgnoreCase(param)){
			return "'".concat(this.ajustesManualesPantalla.getOficinaSelected().toString()).concat("'");
		}else if ("productoInterno".equalsIgnoreCase(param)){
			return "'".concat(this.ajustesManualesPantalla.getProdOperSelected()).concat("'");
		}else if ("numeroOperacion".equalsIgnoreCase(param)){
			return this.ajustesManualesPantalla.getNumOper().toString();
		}else if ("fechaOperacion".equalsIgnoreCase(param)){
			return "'".concat(sdf.format(this.ajustesManualesPantalla.getfContr()).toString()).concat("'");
		}else if ("codigoOperacionRad".equalsIgnoreCase(param)){
			return "'".concat(this.ajustesManualesPantalla.getCodOperaSelected()).concat("'"); 
		}else if ("estadoMovimiento".equalsIgnoreCase(param)){
			return "'".concat(this.ajustesManualesPantalla.getEstadoSelected()).concat("'");
		}else if ("fechaRegistroMin".equalsIgnoreCase(param)){
			return "'".concat(sdf.format(this.ajustesManualesPantalla.getFechaRegistro().getLow())).concat("'");
		}else if ("fechaRegistroMax".equalsIgnoreCase(param)){
			return "'".concat(sdf.format(this.ajustesManualesPantalla.getFechaRegistro().getHigh())).concat("'");
		}else{
			return "1";		
		}

	}

	
	
	
	
	
	
	@Override
	protected void refreshListInternal() {
		List<AjustesManuales> ajustesManualesList = null;
		
		this.setExportExcel(false);		
		AjustesManualesPantalla pantalla = this.ajustesManualesPantalla;		
		ajustesManualesList = ajustesManualesBo.buscar(pantalla.getfValor(), pantalla.getEntidadSelected(), pantalla.getOficinaSelected(), 
				pantalla.getProdOperSelected(), pantalla.getNumOper(), pantalla.getfContr(), pantalla.getCodOperaSelected(), 
				pantalla.getEstadoSelected(), pantalla.getFechaRegistro(),false, paginationData);		
		setDataTableList(ajustesManualesList);
	}

	
	@Override
	public void refrescarListaExcel() {
		this.setExportExcel(true);
		List<AjustesManuales> ajustesManualesList = null;
		AjustesManualesPantalla pantalla = this.ajustesManualesPantalla;		
		ajustesManualesList = ajustesManualesBo.buscar(pantalla.getfValor(), pantalla.getEntidadSelected(), pantalla.getOficinaSelected(), 
				pantalla.getProdOperSelected(), pantalla.getNumOper(), pantalla.getfContr(), pantalla.getCodOperaSelected(), 
				pantalla.getEstadoSelected(), pantalla.getFechaRegistro(), false,paginationData.getPaginationDataForExcel());		
		setDataTableList(ajustesManualesList);
	}
	
	/**
	 * Prepara para entrar en el modo creación de un ajuste manual.
	 * 
	 */
	public void nuevo() {
		setModoPantalla(ModoPantalla.CREACION);
		AjustesManualesId ajustesManualesId = new AjustesManualesId();
		AjustesManuales ajustesManuales = new AjustesManuales();
		ajustesManuales.setId(ajustesManualesId);	
		
		this.ajustesManualesPantalla.setAjusteManual(ajustesManuales);		
	}
	
	//Limpiar Combos y checks
	public void limpiarPantalla(){
		AjustesManualesPantalla ajustesManualesPantalla = this.ajustesManualesPantalla;
		ajustesManualesPantalla.setDivisaSelect(null);
		ajustesManualesPantalla.setRadContable(false);
		ajustesManualesPantalla.setEnvContab(false);
		
	}
	
	/**
	 * 
	 * 
	 */
	public void borrar() {
		AjustesManuales ajustesManuales = this.ajustesManualesPantalla.getAjusteManual();
		ajustesManualesBo.borrar(ajustesManuales);
	}	
	
	@SuppressWarnings("unchecked")
	@Override
	public void setDataTableList(List<?> dataTableList) {
		this.ajustesManualesPantalla.setAjustesManualesList((List<AjustesManuales>) dataTableList);
	}

	@Override
	public List<?> getDataTableList() {
		return this.ajustesManualesPantalla.getAjustesManualesList();
	}

	public void recuperarContrapa(){
		HistoricoOperacion historicoOperacion = null;
		AbstractContrapartida absContrapa = null;
		
		AjustesManuales ajustesManuales = ajustesManualesPantalla.getAjusteManual();
		
		if (!GenericUtils.isNullOrBlank(ajustesManuales.getId().getFechaOperacion())
				&&(!GenericUtils.isNullOrBlank(ajustesManuales.getId().getNumeroOperacion())
						&& ajustesManuales.getId().getNumeroOperacion()!=0)){
			historicoOperacion = ajustesManualesBo.obtenerHistorico(ajustesManuales);
			if (GenericUtils.isNullOrBlank(historicoOperacion)){
				statusMessages.addToControl("numOper", Severity.ERROR, "ajustesmanuales.error.operacion.inexistente", Constantes.DEFAULT_MESSAGE_TEMPLATE);
				ajustesManuales.setContrapartida(null);
				return;
			}else{
				absContrapa = entityUtil.unwrapProxy(historicoOperacion.getContrapartida(), AbstractContrapartida.class);
                if (!GenericUtils.isNullOrBlank(absContrapa)){
                	ajustesManuales.setContrapartida(((Contrapartida)absContrapa).getId());
                	Contrapartida contrapObtenida2 = (Contrapartida) absContrapa;
                	if (null!=contrapObtenida2 && !GenericUtils.isNullOrBlank(contrapObtenida2.getIndBloqueo()) && "S".equalsIgnoreCase(contrapObtenida2.getIndBloqueo())){
						messageBoxAjustesManualesAction.init(ResourceBundle.instance().getString("ajustesmanuales.messages.contrapartida.bloqueada.texto"), "ajustesManualesAction.voidFunction()", null,"messageBoxPanelContrapa");
                	}
                }
                

			}
		}
	}

	@Factory("LlistaEntidadAjustesManuales")
	public List<Short> listaDescripcionEntidad() {
		
		if (ModoPantalla.INSPECCION.equals(this.modoPantalla)){
			return ajustesManualesBo.obtenerEntidadSelect(false);
		}else{
			return ajustesManualesBo.obtenerEntidadSelect(true);
		}
		
	}


	@Factory("LlistaEntidadAjustes")
	public List<Short> listaDescripcionEntidadOperacions() {
		if (ModoPantalla.CREACION.equals(this.modoPantalla)){
			return ajustesManualesBo.obtenerEntidadSelect(true);
		}else{
			return ajustesManualesBo.obtenerEntidadSelect(false);
		}
	}
	
	public void init(){
		if(null==messageBoxAjustesManualesAction){
			messageBoxAjustesManualesAction = new MessageBoxAction();
		}
		primeraEjecucionInit = null;
	}
	
	public void initDetalle(){
		if (primeraEjecucionInit == null) {
			primeraEjecucionInit=true;
		} 
		else{
			primeraEjecucionInit = false;
		}
		
		if(null==messageBoxAjustesManualesAction){
			messageBoxAjustesManualesAction = new MessageBoxAction();
		}
		
		if(primeraEjecucionInit){
			if(null!=ajustesManualesPantalla.getAjusteManual()){
				String contrapartida = ajustesManualesPantalla.getAjusteManual().getContrapartida();
				if (!GenericUtils.isNullOrBlank(contrapartida)){
					 Contrapartida contrapObtenida2 = ajustesManualesBo.cargarContrapartida(contrapartida.toUpperCase());	
					if (!GenericUtils.isNullOrBlank(contrapObtenida2) && !GenericUtils.isNullOrBlank(contrapObtenida2.getIndBloqueo()) && "S".equalsIgnoreCase(contrapObtenida2.getIndBloqueo())){
						messageBoxAjustesManualesAction.init(ResourceBundle.instance().getString("ajustesmanuales.messages.contrapartida.bloqueada.texto"), "ajustesManualesAction.voidFunction()", null,"messageBoxPanelContrapa");
					}
				}
			}
		}
	}

	public void voidFunction(){
		msgBoxAction.voidFunction();
	}

}
