package com.atosorigin.deri.apuntesContables.ajustesManuales.screen;

import java.util.Date;
import java.util.List;

import org.jboss.seam.ScopeType;
import org.jboss.seam.annotations.Name;
import org.jboss.seam.annotations.Out;
import org.jboss.seam.annotations.Scope;
import org.jboss.seam.annotations.datamodel.DataModel;
import org.jboss.seam.annotations.datamodel.DataModelSelection;

import com.atosorigin.deri.model.adminoper.GenericRange;
import com.atosorigin.deri.model.apuntesContables.AjustesManuales;
import com.atosorigin.deri.model.apuntesContables.AjustesManualesId;
import com.atosorigin.deri.model.parametrizacion.Divisa;

/**
* Contiene los datos de pantalla necesarios para el caso de uso Ajustes Manuales.
*/
@Name("ajustesManualesPantalla")
@Scope(ScopeType.CONVERSATION)
public class AjustesManualesPantalla {
		
	/**
	 * Criterios de búsqueda
	 */ 
	protected Date fValor;
	protected Long numOper;
	protected Date fContr;
	protected Short entidadSelected;
	protected Short oficinaSelected;
	protected String prodOperSelected;
	protected String codOperaSelected;
	protected String estadoSelected;
	private GenericRange<Date> fechaRegistro = new GenericRange<Date>("fechaRegistro", Date.class);
	
	/**
	 * Campos pantalla de edicion
	 */
	protected boolean radContable;
	protected boolean envContab;		
	protected AjustesManualesId ajustesManualesIdSelec;
	@DataModelSelection(value ="listaDtAjustesManuales")	
	@Out(value="ajusteManual", required=false)
	protected AjustesManuales ajusteManual;
	
	/** Lista de datos para el grid. */
	@DataModel(value ="listaDtAjustesManuales")
	protected List<AjustesManuales> ajustesManualesList;

	protected Divisa divisaSelect;		
	
	public Date getfValor() {
		return fValor;
	}

	public Long getNumOper() {
		return numOper;
	}

	public Date getfContr() {
		return fContr;
	}

	public AjustesManuales getAjusteManual() {
		return ajusteManual;
	}

	public List<AjustesManuales> getAjustesManualesList() {
		return ajustesManualesList;
	}

	public Short getEntidadSelected() {
		return entidadSelected;
	}

	public Short getOficinaSelected() {
		return oficinaSelected;
	}

	public void setOficinaSelected(Short oficinaSelected) {
		this.oficinaSelected = oficinaSelected;
	}

	public void setfValor(Date fValor) {
		this.fValor = fValor;
	}

	public void setNumOper(Long numOper) {
		this.numOper = numOper;
	}

	public void setfContr(Date fContr) {
		this.fContr = fContr;
	}

	public void setAjusteManual(AjustesManuales ajusteManual) {
		this.ajusteManual = ajusteManual;
	}

	public void setAjustesManualesList(List<AjustesManuales> ajustesManualesList) {
		this.ajustesManualesList = ajustesManualesList;
	}

	public void setEntidadSelected(Short entidadSelected) {
		this.entidadSelected = entidadSelected;
	}

	public String getProdOperSelected() {
		return prodOperSelected;
	}

	public String getCodOperaSelected() {
		return codOperaSelected;
	}

	public void setProdOperSelected(String prodOperSelected) {
		this.prodOperSelected = prodOperSelected;
	}

	public void setCodOperaSelected(String codOperaSelected) {
		this.codOperaSelected = codOperaSelected;
	}

	public String getEstadoSelected() {
		return estadoSelected;
	}

	public void setEstadoSelected(String estadoSelected) {
		this.estadoSelected = estadoSelected;
	}

	public boolean getRadContable() {
		return radContable;
	}

	public boolean getEnvContab() {
		return envContab;
	}

	public void setRadContable(boolean radContable) {
		this.radContable = radContable;
	}

	public void setEnvContab(boolean envContab) {
		this.envContab = envContab;
	}

	public Divisa getDivisaSelect() {
		return divisaSelect;
	}

	public void setDivisaSelect(Divisa divisaSelect) {
		this.divisaSelect = divisaSelect;
	}

	public AjustesManualesId getAjustesManualesIdSelec() {
		return ajustesManualesIdSelec;
	}

	public void setAjustesManualesIdSelec(AjustesManualesId ajustesManualesIdSelect) {
		this.ajustesManualesIdSelec = ajustesManualesIdSelect;
	}
	

	public GenericRange<Date> getFechaRegistro() {
		return fechaRegistro;
	}

	public void setFechaRegistro(GenericRange<Date> fechaRegistro) {
		this.fechaRegistro = fechaRegistro;
	}

	
}
