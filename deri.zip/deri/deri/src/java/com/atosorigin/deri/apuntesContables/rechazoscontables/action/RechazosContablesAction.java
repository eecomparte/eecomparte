package com.atosorigin.deri.apuntesContables.rechazoscontables.action;

import java.util.ArrayList;
import java.util.List;

import org.jboss.seam.ScopeType;
import org.jboss.seam.annotations.In;
import org.jboss.seam.annotations.Name;
import org.jboss.seam.annotations.Out;
import org.jboss.seam.annotations.Scope;
import org.jboss.seam.international.StatusMessage.Severity;

import com.atosorigin.common.action.ModoPantalla;
import com.atosorigin.common.action.PaginatedListAction;
import com.atosorigin.common.constantes.Constantes;
import com.atosorigin.common.formvalidator.FormValidator;
import com.atosorigin.deri.apuntesContables.rechazoscontables.screen.RechazosContablesPantalla;
import com.atosorigin.deri.apuntescontables.rechazoscontables.business.RechazosContablesBo;
import com.atosorigin.deri.model.apuntesContables.RechazosContables;

/**
 * Clase action listener para el caso de uso de calendario de la Ordén
 */
@Name("rechazosContablesAction")
@Scope(ScopeType.CONVERSATION)
@FormValidator
public class RechazosContablesAction extends PaginatedListAction {

	/**
	 * Inyección del bean de Spring "RechazosContablesBo" 
	 */
	@In("#{rechazosContablesBo}")
	protected RechazosContablesBo rechazosContablesBo;

	/**
	 * Inyección del screen bean que contiene los datos de pantalla del caso de uso
	 */
	@In(create=true)
	protected RechazosContablesPantalla rechazosContablesPantalla;
	
	
    @Out(required=false)
    protected RechazosContables rechazoContableSeleccionado;	



	/**
	 * Actualiza la lista del grid de Errores de Conciliación.
	 * 
	 */
	public void buscar() {
		paginationData.reset();
		refrescarLista();	
		setPrimerAcceso(false);
	}
	
	@Override
	public List<?> getDataTableList() {
		return rechazosContablesPantalla.getRechazosContablesList();
	}

	@Override
	protected void refreshListInternal() {
		// TODO Auto-generated method stub
		setExportExcel(false);
		 List<RechazosContables> list = rechazosContablesPantalla.getRechazosContablesList();
		if(list==null){
			list = new ArrayList<RechazosContables>();
			rechazosContablesPantalla.setRechazosContablesList(list);
		}
		list.clear();
		list.addAll((List<RechazosContables>)rechazosContablesBo.Busqueda(rechazosContablesPantalla.getFechaProceso(), rechazosContablesPantalla.getEntidadOperacion(), rechazosContablesPantalla.getOficinaOperacion(), rechazosContablesPantalla.getProductoContable(),rechazosContablesPantalla.getNumeroOperacion(), rechazosContablesPantalla.getFechaOperacion(), rechazosContablesPantalla.getEstadoError(), paginationData));

	}
		
	

	@Override
	public void refrescarListaExcel() {
		// TODO Auto-generated method stub
		setExportExcel(true);
		 List<RechazosContables> list = rechazosContablesPantalla.getRechazosContablesList();
		if(list==null){
			list = new ArrayList<RechazosContables>();
			rechazosContablesPantalla.setRechazosContablesList(list);
		}
		list.clear();
		list.addAll((List<RechazosContables>)rechazosContablesBo.Busqueda(rechazosContablesPantalla.getFechaProceso(), rechazosContablesPantalla.getEntidadOperacion(), rechazosContablesPantalla.getOficinaOperacion(), rechazosContablesPantalla.getProductoContable(),rechazosContablesPantalla.getNumeroOperacion(), rechazosContablesPantalla.getFechaOperacion(), rechazosContablesPantalla.getEstadoError(), paginationData));
	
	}

	@Override
	@SuppressWarnings("unchecked")
	public void setDataTableList(List<?> dataTableList) {
		rechazosContablesPantalla.setRechazosContablesList((List<RechazosContables>)dataTableList);
		
	}

	public void editar(){
		rechazoContableSeleccionado = rechazosContablesPantalla.getRechazosContablesSel();
		setModoPantalla(ModoPantalla.EDICION);		
	}
	
	public void descartar(){
		rechazoContableSeleccionado = rechazosContablesPantalla.getRechazosContablesSel();
		rechazosContablesBo.descartar(rechazoContableSeleccionado);
	}

	/**
	 * Visualizamos un Rechazo
	 * 
	 */
	public void ver() {
		rechazoContableSeleccionado = rechazosContablesPantalla.getRechazosContablesSel();
		setModoPantalla(ModoPantalla.INSPECCION);		
	}
	

	public String guardar(){
//		if(ModoPantalla.CREACION.equals(getModoPantalla())){
//			rechazosContablesBo.alta(rechazosContablesPantalla.getRechazosContablesSel());
//			statusMessages.add(Severity.INFO, "#{messages['confirmaciones.altacorrecta']}", Constantes.DEFAULT_MESSAGE_TEMPLATE);			}
		if(ModoPantalla.EDICION.equals(getModoPantalla())){
			rechazosContablesBo.guardar(rechazosContablesPantalla.getRechazosContablesSel());
			statusMessages.add(Severity.INFO, "#{messages['rechazosContables.modificacionOK']}", Constantes.DEFAULT_MESSAGE_TEMPLATE);
		}
		return Constantes.CONSTANTE_SUCCESS;
	}
}
