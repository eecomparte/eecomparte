package com.atosorigin.deri.apuntesContables.rechazoscontables.screen;

import java.util.Date;
import java.util.List;

import org.jboss.seam.ScopeType;
import org.jboss.seam.annotations.Name;
import org.jboss.seam.annotations.Out;
import org.jboss.seam.annotations.Scope;
import org.jboss.seam.annotations.datamodel.DataModel;
import org.jboss.seam.annotations.datamodel.DataModelSelection;

import com.atosorigin.deri.model.apuntesContables.RechazosContables;

/**
 *  Contiene los datos de pantalla necesarios para el caso de uso de rechazos contables.
 */

@Name("rechazosContablesPantalla")
@Scope(ScopeType.CONVERSATION)
public class RechazosContablesPantalla {

	/** fechaProceso. Criterio de búsqueda de Rechazos Contables */
	protected Date fechaProceso;
	
	/** Entidad Operacion. Criterio de búsqueda de Rechazos Contables */
	protected Short entidadOperacion;
	
	/** oficinaOperacion. Criterio de búsqueda de Rechazos Contables */
	protected Short oficinaOperacion;
	
	/** numeroOperacion. Criterio de búsqueda de Rechazos Contables */
	protected Long numeroOperacion;
	
	
	/** productoContable. Criterio de búsqueda de Rechazos Contables */
	protected  String productoContable;
	
	/** fechaOperacion. Criterio de búsqueda de Rechazos Contables */
	protected Date fechaOperacion;
	
	/** estadoError. Criterio de búsqueda de Rechazos Contables */
	protected String estadoError;
	
	/** Número de resultados totales para los criterios de búsqueda. */
	protected Long numFilas = 0L;
	
	protected String descripcionError;
	protected String valorCampoInicial;
	protected String valorCampoFinal;
	


	/** Lista de datos para el grid. */
	@DataModel(value ="listaDtRechazoContable")
	protected List<RechazosContables> rechazosContablesList;
	


	/** Tipo de documento seleccionado en el grid */
	@DataModelSelection(value ="listaDtRechazoContable")
    @Out(required=false)
    protected RechazosContables rechazosContablesSel;



	public Date getFechaProceso() {
		return fechaProceso;
	}



	public void setFechaProceso(Date fechaProceso) {
		this.fechaProceso = fechaProceso;
	}



	public Short getEntidadOperacion() {
		return entidadOperacion;
	}



	public void setEntidadOperacion(Short entidadOperacion) {
		this.entidadOperacion = entidadOperacion;
	}



	public Short getOficinaOperacion() {
		return oficinaOperacion;
	}



	public void setOficinaOperacion(Short oficinaOperacion) {
		this.oficinaOperacion = oficinaOperacion;
	}



	public Long getNumeroOperacion() {
		return numeroOperacion;
	}



	public void setNumeroOperacion(Long numeroOperacion) {
		this.numeroOperacion = numeroOperacion;
	}



	public String getProductoContable() {
		return productoContable;
	}



	public void setProductoContable(String productoContable) {
		this.productoContable = productoContable;
	}



	public Date getFechaOperacion() {
		return fechaOperacion;
	}



	public void setFechaOperacion(Date fechaOperacion) {
		this.fechaOperacion = fechaOperacion;
	}



	public String getEstadoError() {
		return estadoError;
	}



	public void setEstadoError(String estadoError) {
		this.estadoError = estadoError;
	}



	public Long getNumFilas() {
		return numFilas;
	}



	public void setNumFilas(Long numFilas) {
		this.numFilas = numFilas;
	}

	public String getDescripcionError() {
		return descripcionError;
	}



	public void setDescripcionError(String descripcionError) {
		this.descripcionError = descripcionError;
	}



	public String getValorCampoInicial() {
		return valorCampoInicial;
	}



	public void setValorCampoInicial(String valorCampoInicial) {
		this.valorCampoInicial = valorCampoInicial;
	}



	public String getValorCampoFinal() {
		return valorCampoFinal;
	}



	public void setValorCampoFinal(String valorCampoFinal) {
		this.valorCampoFinal = valorCampoFinal;
	}




	public List<RechazosContables> getRechazosContablesList() {
		return rechazosContablesList;
	}



	public void setRechazosContablesList(
			List<RechazosContables> rechazosContablesList) {
		this.rechazosContablesList = rechazosContablesList;
	}



	public RechazosContables getRechazosContablesSel() {
		return rechazosContablesSel;
	}



	public void setRechazosContablesSel(RechazosContables rechazosContablesSel) {
		this.rechazosContablesSel = rechazosContablesSel;
	}	
	
	
//	@Out(required=false)
//	protected ErroresConciliacion errorConciliacionSel;

	
	
}
