package com.atosorigin.deri.colat.apuntesManuales.action;

import java.math.BigDecimal;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import org.jboss.seam.ScopeType;
import org.jboss.seam.annotations.In;
import org.jboss.seam.annotations.Name;
import org.jboss.seam.annotations.Scope;
import org.jboss.seam.international.Messages;
import org.jboss.seam.international.StatusMessage.Severity;

import com.atosorigin.common.action.ModoPantalla;
import com.atosorigin.common.action.PaginatedListAction;
import com.atosorigin.common.constantes.Constantes;
import com.atosorigin.common.formvalidator.FormValidator;
import com.atosorigin.common.utils.GenericUtils;
import com.atosorigin.deri.colat.apuntesManuales.business.ApuntesManualesBo;
import com.atosorigin.deri.colat.apuntesManuales.screen.ApuntesManualesPantalla;
import com.atosorigin.deri.model.catalogo.Producto;
import com.atosorigin.deri.model.colat.EsquemaContable;
import com.atosorigin.deri.model.colat.EsquemaContableColat;
import com.atosorigin.deri.model.colat.EsquemaContableDeri;
import com.atosorigin.deri.model.colat.apuntesManuales.ApunteManual;
import com.atosorigin.deri.model.colat.apuntesManuales.ApunteManualId;
import com.atosorigin.deri.model.colat.configuracionesContables.ConceptoTipconta;
import com.atosorigin.deri.model.colat.configuracionesContables.ConceptoTipcontaId;
import com.atosorigin.deri.model.gestionoperaciones.Colacont;
import com.atosorigin.deri.model.gestionoperaciones.Operacion;

/**
 * Clase action listener para el caso de uso de apuntes manuales
 */
@Name("apuntesManualesAction")
@Scope(ScopeType.CONVERSATION)
@FormValidator
public class ApuntesManualesAction extends PaginatedListAction {
	
	private final String OFICINA_BS = "0901";
	private final String PARAM = "PARAM";
	private final String DOSMIL = "01/01/2000";
	
	private final String MICROCOBERTURA = "0";
	private final String PRODUCTO_COLATERALES = "756000";

	@In(value="#{apuntesManualesBo}")
	ApuntesManualesBo apuntesManualesBo;
	
	@In(create=true)
	ApuntesManualesPantalla apuntesManualesPantalla;
	
	//concepto cabecera de cada grupo listado 
	private ConceptoTipconta conceptoActual;
	
	public void proyectoDeri(){
		apuntesManualesPantalla.setProyecto(Constantes.NOMBRE_PROYECTO_DERI);
	}

	public void proyectoColat(){
		apuntesManualesPantalla.setProyecto(Constantes.NOMBRE_PROYECTO_COLAT);
	}
	
	public void onProductoGrucontChange() {
		Producto prod = apuntesManualesPantalla.getProductoSelected();
	}

	public void onProductoGrucontChangeDetalle() {
		Producto prod = new Producto();
		prod.setId(apuntesManualesPantalla.getApunteManualSeleccionado().getId().getProducto());
		
		bloqueoCamposDebeHaber();
	}
	
	public void buscar(){
		setPrimerAcceso(false);
		paginationData.reset();
		refrescarLista();		
	}

	public String guardar(){
		if(ModoPantalla.CREACION.equals(getModoPantalla())){
			if(copiaFechaContable().equals("-1")){
				return Constantes.CONSTANTE_FAIL;
			}
			ApunteManualId id = apuntesManualesPantalla.getApunteManualSeleccionado().getId();
			//proyecto
			id.setProyecto(apuntesManualesPantalla.getProyecto());

			if(!GenericUtils.isNullOrBlank(apuntesManualesPantalla.getCuentaBsDebe()) &&
					apuntesManualesPantalla.getCuentaBsDebe().equals(PARAM)){

				statusMessages.add(Severity.ERROR, "#{messages['apuntes.manuales.cuenta.param']}", Constantes.DEFAULT_MESSAGE_TEMPLATE);
				return Constantes.CONSTANTE_FAIL;
				
			}else if(!GenericUtils.isNullOrBlank(apuntesManualesPantalla.getCuentaBsHaber()) &&
					apuntesManualesPantalla.getCuentaBsHaber().equals(PARAM)){
				statusMessages.add(Severity.ERROR, "#{messages['apuntes.manuales.cuenta.param']}", Constantes.DEFAULT_MESSAGE_TEMPLATE);
				return Constantes.CONSTANTE_FAIL;
			}
				
				
			if(GenericUtils.isNullOrBlank(apuntesManualesBo.cargar(apuntesManualesPantalla.getApunteManualSeleccionado().getId()))){
				ApunteManual nueva = apuntesManualesPantalla.getApunteManualSeleccionado();
				//proyecto
				nueva.getId().setProyecto(apuntesManualesPantalla.getProyecto());
				
				//VALIDACIONES
				//1-Si tipconta = 'D50' o 'D60' oficinas debe y haber iguales
				if(apuntesManualesPantalla.getConceptoSelected().getId().getCodconta().equals("D50")
						|| apuntesManualesPantalla.getConceptoSelected().getId().getCodconta().equals("D60")){
					
					if(apuntesManualesPantalla.getOficinaDebe().equals(apuntesManualesPantalla.getOficinaHaber())){
						statusMessages.add(Severity.ERROR, "#{messages['apuntes.manuales.oficinas.iguales']}", Constantes.DEFAULT_MESSAGE_TEMPLATE);
						return Constantes.CONSTANTE_FAIL;
					}
				}
				//2-Debe existir la operacion nCorrela - fecha ope
				Long ncorrela = apuntesManualesPantalla.getApunteManualSeleccionado().getId().getnCorrela();
				Date fechaope = apuntesManualesPantalla.getApunteManualSeleccionado().getId().getFechaOpe();
				if(apuntesManualesBo.validaNCorrelaFechaOpe(ncorrela,fechaope,apuntesManualesPantalla.getProyecto()).size()==0){
					statusMessages.add(Severity.ERROR, "#{messages['apuntes.manuales.ncorrela.fechaope']}", Constantes.DEFAULT_MESSAGE_TEMPLATE);
					return Constantes.CONSTANTE_FAIL;
				}
				
				//3-Si tipconta=100 y no está marcado el check de fecha ejecucion NO se inserta registros DEBE y HABER
				if(apuntesManualesPantalla.getConceptoSelected().getId().getCodconta().equals("100") &&
						!apuntesManualesPantalla.isCheckDiaMenos()){
					statusMessages.add(Severity.ERROR, "#{messages['apuntes.manuales.marca.d.menos.uno']}", Constantes.DEFAULT_MESSAGE_TEMPLATE);
					return Constantes.CONSTANTE_FAIL;

				}

				//Registro del debe
				nueva.getId().setProducto(apuntesManualesPantalla.getApunteManualSeleccionado().getId().getProducto());
				Date fechaReg = apuntesManualesPantalla.getApunteManualSeleccionado().getId().getFechaReg();
				if(apuntesManualesPantalla.isCheckDiaMenos()){
					Calendar calendar =Calendar.getInstance();
					calendar.setTime(fechaReg);
					calendar.add(Calendar.DATE, -1);
					nueva.getId().setFechaReg(calendar.getTime());
				}else
					nueva.getId().setFechaReg(fechaReg);
				nueva.getId().setFechaVal(apuntesManualesPantalla.getApunteManualSeleccionado().getId().getFechaVal());
				nueva.getId().setTipconta(apuntesManualesPantalla.getConceptoSelected().getId().getCodconta());
				nueva.getId().setAgrucont(apuntesManualesPantalla.getApunteManualSeleccionado().getId().getAgrucont());
				nueva.getId().setGrupocbs(apuntesManualesPantalla.getGrupoContDebe());
				nueva.getId().setOficinbs(new Short(apuntesManualesPantalla.getOficinaDebe()));
				nueva.getId().setCuentabs(apuntesManualesPantalla.getCuentaBsDebe());
				nueva.getId().setCodivisa(apuntesManualesPantalla.getApunteManualSeleccionado().getId().getCodivisa());
				nueva.getId().setFechaOpe(apuntesManualesPantalla.getApunteManualSeleccionado().getId().getFechaOpe());
				nueva.getId().setnCorrela(apuntesManualesPantalla.getApunteManualSeleccionado().getId().getnCorrela());
				nueva.getId().setFechaCon(apuntesManualesPantalla.getApunteManualSeleccionado().getId().getFechaVal());

//				SMM 07/06/2015 Correo VO Dejar importe a cero, proceso recalculará
				nueva.setContrava(BigDecimal.ZERO);
				
				//Buscar registros del debe
				int contadorDebe = apuntesManualesBo.buscarRegistroDebeHaber(nueva);
				if(contadorDebe==0){
					nueva.setSubctabs(apuntesManualesPantalla.getSubctaBsDebe());
					//contrava - seteamos el valor introducido en importes
//					SMM 07/06/2015 Correo VO Dejar importe a cero, proceso recalculará
//					nueva.setContrava(nueva.getImportes());
					//descripc - no informamos el campo
					//alta del registro del debe
					apuntesManualesBo.alta(nueva);
				}
				
				
				//Registro del haber
				ApunteManual nuevaHaber = new ApunteManual();
				ApunteManualId idHaber =new ApunteManualId();
				idHaber.setProyecto(nueva.getId().getProyecto());
				idHaber.setProducto(nueva.getId().getProducto());
				idHaber.setFechaReg(nueva.getId().getFechaReg());
				idHaber.setFechaVal(nueva.getId().getFechaVal());
				idHaber.setTipconta(nueva.getId().getTipconta());
				idHaber.setAgrucont(nueva.getId().getAgrucont());
				idHaber.setGrupocbs(apuntesManualesPantalla.getGrupoContHaber());
				idHaber.setOficinbs(Short.valueOf(apuntesManualesPantalla.getOficinaHaber()));
				idHaber.setCuentabs(apuntesManualesPantalla.getCuentaBsHaber());
				idHaber.setCodivisa(nueva.getId().getCodivisa());
				idHaber.setFechaOpe(nueva.getId().getFechaOpe());
				idHaber.setnCorrela(nueva.getId().getnCorrela());
				idHaber.setFechaCon(nueva.getId().getFechaCon());
				nuevaHaber.setId(idHaber);
				
				nuevaHaber.setSubctabs(apuntesManualesPantalla.getSubctaBsHaber());
				//cambiamos el signo al importe del debe
//				SMM 07/06/2015 Correo VO Dejar importe a cero, proceso recalculará
				nueva.setContrava(BigDecimal.ZERO);
//				nuevaHaber.setContrava(nueva.getImportes().multiply(new BigDecimal(-1)));/*seteamos el mismo valor que para importes*/
				nuevaHaber.setImportes(nueva.getImportes().multiply(new BigDecimal(-1)));
				
			
				//Buscar registros del haber
				int contadorHaber = apuntesManualesBo.buscarRegistroDebeHaber(nuevaHaber);
				if(contadorHaber==0){
					nuevaHaber.setSubctabs(apuntesManualesPantalla.getSubctaBsHaber());
					//contrava????
					//descripc????
					//alta del registro del haber
					apuntesManualesBo.alta(nuevaHaber);
				}
				statusMessages.add(Severity.INFO, "#{messages['apuntes.manuales.altacorrecta']}", Constantes.DEFAULT_MESSAGE_TEMPLATE);
			}else{
				statusMessages.add(Severity.ERROR, "#{messages['apuntes.manuales.duplicado']}", Constantes.DEFAULT_MESSAGE_TEMPLATE);
				return Constantes.CONSTANTE_FAIL;
			}
		}if(ModoPantalla.EDICION.equals(getModoPantalla())){
			apuntesManualesBo.modifica(apuntesManualesPantalla.getApunteManualSeleccionado());
			statusMessages.add(Severity.INFO, "#{messages['apuntes.manuales.modificacioncorrecta']}", Constantes.DEFAULT_MESSAGE_TEMPLATE);
		}
		refrescarLista();

		return Constantes.CONSTANTE_SUCCESS;
	}
	
	public void alta(){
		apuntesManualesPantalla.clear();
		apuntesManualesPantalla.setApunteManualSeleccionado(new ApunteManual(new ApunteManualId()));
		apuntesManualesPantalla.setEntidadNueva("81"); 
		apuntesManualesPantalla.setEsquemaNuevo(new EsquemaContable()); 
		apuntesManualesPantalla.setCamposDebeDisabled(true);
		apuntesManualesPantalla.setCamposHaberDisabled(true);
		apuntesManualesPantalla.setOficinaDebeDisabled(true);
		apuntesManualesPantalla.setOficinaHaberDisabled(true);
		
		if(apuntesManualesPantalla.getProyecto().equalsIgnoreCase(Constantes.NOMBRE_PROYECTO_DERI))
			apuntesManualesPantalla.setEsquemaSelected(new EsquemaContableDeri());
		else{
			apuntesManualesPantalla.setEsquemaSelected(new EsquemaContableColat());
			//OJO!! CÓDIGO = 0 PARA ESQUEMA. Ya que en colat solo hay un esquema y un producto
			//forzamos producto y esquema para q no se muestre la opción de noSelectionValue
			apuntesManualesPantalla.getApunteManualSeleccionado().getId().setProducto(PRODUCTO_COLATERALES);//756000 - COL·LATERALS
			EsquemaContable ec = new EsquemaContable("COLAT","CONFCONT","ESQUEMAC");//Microcobertura de COLAT
			ec.setCodigo(MICROCOBERTURA);//Sólo existe el esquema Microcobertura para colat, con codigo 0
			apuntesManualesPantalla.setEsquemaNuevo(ec);

		}
		
		apuntesManualesPantalla.getApunteManualSeleccionado().getId().setFechaReg(apuntesManualesBo.obtenerFechaEjecucion(apuntesManualesPantalla.getProyecto()));
		setModoPantalla(ModoPantalla.CREACION);
	}
	
	public void borrar(){
		ApunteManual apunteManual = apuntesManualesPantalla.getApunteManualSeleccionado();
		if(!GenericUtils.esHoy(apunteManual.getAuditData().getFechaUltimaModi())){
			statusMessages.add(Severity.ERROR, "#{messages['apuntes.manuales.borrado.error.hoy']}", Constantes.DEFAULT_MESSAGE_TEMPLATE);
		}else{
			apuntesManualesBo.baja(apuntesManualesPantalla.getApunteManualSeleccionado());
			statusMessages.add(Severity.INFO, "#{messages['apuntes.manuales.borradoCorrecto']}", Constantes.DEFAULT_MESSAGE_TEMPLATE);
		}
		refrescarLista();
	}
	
	@Override
	public List<?> getDataTableList() {
		
		return apuntesManualesPantalla.getListaApuntesManuales();
	}
	
	public void ver(){
		ApunteManual apunteManual = apuntesManualesBo.cargar(apuntesManualesPantalla.getApunteManualSeleccionado().getId()); 
		apuntesManualesPantalla.setApunteManualSeleccionado(apunteManual);
		//Producto
		apuntesManualesPantalla.setProductoSelected(cargarProducto(apunteManual.getId().getProducto()));
		//Concepto
		apuntesManualesPantalla.setConceptoSelected(obtenerConcepto(apunteManual.getId().getTipconta()));
		//apuntesManualesPantalla.setEsquemaNuevo(apunteManual.getId().getAgrucont());
		//TODO
		//apuntesManualesPantalla.setEsquemaNuevo(new EsquemaContable());
		
		//Campos del debe
		apuntesManualesPantalla.setGrupoContDebe(apunteManual.getId().getGrupocbs());
		apuntesManualesPantalla.setOficinaDebe(apunteManual.getId().getOficinbs().toString());
		apuntesManualesPantalla.setCuentaBsDebe(apunteManual.getId().getCuentabs());
		apuntesManualesPantalla.setSubctaBsDebe(apunteManual.getSubctabs());

		//Campos del haber
		ApunteManual apunteHaber = apuntesManualesBo.buscarRegistroHaberInspeccion(apunteManual);
		if(null!=apunteHaber){
			apuntesManualesPantalla.setGrupoContHaber(apunteHaber.getId().getGrupocbs());
			apuntesManualesPantalla.setOficinaHaber(apunteHaber.getId().getOficinbs().toString());
			apuntesManualesPantalla.setCuentaBsHaber(apunteHaber.getId().getCuentabs());
			apuntesManualesPantalla.setSubctaBsHaber(apunteHaber.getSubctabs());
		}
		setModoPantalla(ModoPantalla.INSPECCION);
	}

	@Override
	protected void refreshListInternal() {
		setExportExcel(false);
		
		String proyecto = apuntesManualesPantalla.getProyecto();
		String producto = null;
		String concepto = null;
		Long nCorrela = null;
		Date fechaEjec = null; 

		//Producto
		if(!GenericUtils.isNullOrBlank(apuntesManualesPantalla.getProductoBusqueda())){
			producto = apuntesManualesPantalla.getProductoBusqueda().getId();
		}
		//Concepto
		if(!GenericUtils.isNullOrBlank(apuntesManualesPantalla.getConceptoBusqueda())){
			concepto = apuntesManualesPantalla.getConceptoBusqueda().getId().getCodconta();
		}
		//nCorrela
		if(!GenericUtils.isNullOrBlank(apuntesManualesPantalla.getnCorrelaBusqueda())){
			nCorrela = apuntesManualesPantalla.getnCorrelaBusqueda();
		}
		//fecha ejecución
		if(!GenericUtils.isNullOrBlank(apuntesManualesPantalla.getFechaEjecucionBusqueda())){
			fechaEjec = apuntesManualesPantalla.getFechaEjecucionBusqueda();
		}

		List<ApunteManual> listaApuntesManuales = apuntesManualesBo
		.buscarApuntesManuales(proyecto,producto, concepto, nCorrela, fechaEjec,paginationData);
		
		apuntesManualesPantalla.setListaApuntesManuales(listaApuntesManuales);
	}

	@Override
	public void refrescarListaExcel() {
		setExportExcel(true);

		String proyecto = apuntesManualesPantalla.getProyecto();
		String producto = null;
		String concepto = null;
		Long nCorrela = null;
		Date fechaEjec = null; 
		
		//Producto
		if(!GenericUtils.isNullOrBlank(apuntesManualesPantalla.getProductoBusqueda())){
			producto = apuntesManualesPantalla.getProductoBusqueda().getId();
		}
		//Concepto
		if(!GenericUtils.isNullOrBlank(apuntesManualesPantalla.getConceptoBusqueda())){
			concepto = apuntesManualesPantalla.getConceptoBusqueda().getId().getCodconta();
		}
		//nCorrela
		if(!GenericUtils.isNullOrBlank(apuntesManualesPantalla.getnCorrelaBusqueda())){
			nCorrela = apuntesManualesPantalla.getnCorrelaBusqueda();
		}
		//fecha ejecución
		if(!GenericUtils.isNullOrBlank(apuntesManualesPantalla.getFechaEjecucionBusqueda())){
			fechaEjec = apuntesManualesPantalla.getFechaEjecucionBusqueda();
		}

		List<ApunteManual> listaApuntesManuales = apuntesManualesBo
		.buscarApuntesManuales(proyecto,producto, concepto, nCorrela, fechaEjec,paginationData.getPaginationDataForExcel());

		apuntesManualesPantalla.setListaApuntesManuales(listaApuntesManuales);
	}

	@Override
	public void setDataTableList(List<?> dataTableList) {
		apuntesManualesPantalla.setListaApuntesManuales((List<ApunteManual>)dataTableList);
		
	}

	public ApuntesManualesPantalla getapuntesManualesPantalla() {
		return apuntesManualesPantalla;
	}

	public void setApuntesManualesPantalla(
			ApuntesManualesPantalla apuntesManualesPantalla) {
		this.apuntesManualesPantalla = apuntesManualesPantalla;
	}
	
	public ConceptoTipconta getConceptoActual() {
		return conceptoActual;
	}

	public void setConceptoActual(ConceptoTipconta conceptoActual) {
		this.conceptoActual = conceptoActual;
	}
	
	public Producto cargarProducto(String productoId){
		if (productoId==null || productoId.equals(""))
			return null;

		return apuntesManualesBo.cargarProducto(productoId);
	}
	
	public ConceptoTipconta obtenerConcepto(String codConcepto){
		ConceptoTipcontaId ctcid = new ConceptoTipcontaId(apuntesManualesPantalla.getProyecto(),codConcepto);
		return apuntesManualesBo.obtenerConcepto(ctcid);
	}
	
	public String obtenerEstado(Short estadoco){
		if(null==estadoco || estadoco.shortValue()==0)
			return Messages.instance().get("apuntes.manuales.no.procesado");
		else
			return Messages.instance().get("apuntes.manuales.procesado");
	}

	public void bloqueoCamposDebeHaber(){
		String proyecto = apuntesManualesPantalla.getProyecto();
		String entidad = apuntesManualesPantalla.getEntidadNueva();
		String producto = apuntesManualesPantalla.getApunteManualSeleccionado().getId().getProducto();
		String agrucont = apuntesManualesPantalla.getApunteManualSeleccionado().getId().getAgrucont();
		ConceptoTipconta concepto = apuntesManualesPantalla.getConceptoSelected();
		EsquemaContable esquema = apuntesManualesPantalla.getEsquemaNuevo();
		
		if(GenericUtils.isNullOrBlank(entidad) || GenericUtils.isNullOrBlank(producto) || 
				GenericUtils.isNullOrBlank(agrucont) || GenericUtils.isNullOrBlank(concepto) || GenericUtils.isNullOrBlank(esquema.getCodigo())){
			apuntesManualesPantalla.setCamposDebeHabilidados(false);
			apuntesManualesPantalla.setCamposHaberHabilitados(false);
			apuntesManualesPantalla.setOficinaDebeHabilitado(false);
			apuntesManualesPantalla.setOficinaHaberHabilitado(false);
		}else{
			List result = apuntesManualesBo.llenarCamposDebeHaber(proyecto, entidad, producto, agrucont, concepto.getId().getCodconta(), esquema.getCodigo());
			if(result.size()>0){
				//GRUPOCTA CUENTACO, SUBCUENT,GRUPCONT, CTACONTR, SCTACONT
				Object[] confcont = (Object[])result.get(0);
				Short grupcta = null;
				Short grupcont = null;
				if(!GenericUtils.isNullOrBlank(confcont[0]))
					grupcta = ((BigDecimal)confcont[0]).shortValue();
				String cuentaco = (String)confcont[1];
				String subcuent = (String)confcont[2];
				if(!GenericUtils.isNullOrBlank(confcont[3]))
					grupcont = ((BigDecimal)confcont[3]).shortValue();
				String ctacontr = (String)confcont[4];
				String sctacont = (String)confcont[5];
				
				//Si no está informado el campo cuentaco es que se ha creado la configuración por copia y sin informar lso campos
				if(GenericUtils.isNullOrBlank(cuentaco)){
					statusMessages.add(Severity.INFO, "#{messages['apuntes.manuales.cuentaco.no.informada']}");
					return;
				}

				apuntesManualesPantalla.setGrupoContDebe(grupcta);
				apuntesManualesPantalla.setOficinaDebe(OFICINA_BS);
				apuntesManualesPantalla.setCuentaBsDebe(cuentaco);
				apuntesManualesPantalla.setSubctaBsDebe(subcuent);
				
				apuntesManualesPantalla.setGrupoContHaber(grupcont);
				apuntesManualesPantalla.setOficinaHaber(OFICINA_BS);
				apuntesManualesPantalla.setCuentaBsHaber(ctacontr);
				apuntesManualesPantalla.setSubctaBsHaber(sctacont);
				
				//Bloqueo / desbloqueo de campos
				//SMM 16/03/2015
				apuntesManualesPantalla.setOficinaDebeDisabled(true);
				apuntesManualesPantalla.setCamposDebeDisabled(true);
				apuntesManualesPantalla.setOficinaHaberDisabled(true);
				apuntesManualesPantalla.setCamposHaberDisabled(true);

				if(cuentaco.equals(PARAM)){
					apuntesManualesPantalla.setCamposDebeDisabled(false);
//					apuntesManualesPantalla.setOficinaHaberDisabled(false);
//					apuntesManualesPantalla.setCamposHaberDisabled(true);
					apuntesManualesPantalla.setOficinaDebeDisabled(false);
				}else if (concepto.getId().getCodconta().equals("D50") || concepto.getId().getCodconta().equals("D60") || 
						concepto.getId().getCodconta().equals("500") || concepto.getId().getCodconta().equals("510") ||
						concepto.getId().getCodconta().equals("520") || concepto.getId().getCodconta().equals("530") ||
						concepto.getId().getCodconta().equals("540") || concepto.getId().getCodconta().equals("550") ||
						concepto.getId().getCodconta().equals("560") || concepto.getId().getCodconta().equals("570") ||
						concepto.getId().getCodconta().equals("580") || concepto.getId().getCodconta().equals("590")){

					apuntesManualesPantalla.setOficinaDebeDisabled(false);
					apuntesManualesPantalla.setCamposDebeDisabled(true);
//					apuntesManualesPantalla.setOficinaHaberDisabled(true);
//					apuntesManualesPantalla.setCamposHaberDisabled(true);
				}
				//SMM 16/03/2015
				if(ctacontr.equals(PARAM)){
//					apuntesManualesPantalla.setCamposDebeDisabled(true);
					apuntesManualesPantalla.setOficinaHaberDisabled(false);
					apuntesManualesPantalla.setCamposHaberDisabled(false);
//					apuntesManualesPantalla.setOficinaDebeDisabled(false);
				}else if (concepto.getId().getCodconta().equals("D50") || concepto.getId().getCodconta().equals("D60") || 
						concepto.getId().getCodconta().equals("500") || concepto.getId().getCodconta().equals("510") ||
						concepto.getId().getCodconta().equals("520") || concepto.getId().getCodconta().equals("530") ||
						concepto.getId().getCodconta().equals("540") || concepto.getId().getCodconta().equals("550") ||
						concepto.getId().getCodconta().equals("560") || concepto.getId().getCodconta().equals("570") ||
						concepto.getId().getCodconta().equals("580") || concepto.getId().getCodconta().equals("590")){

//					apuntesManualesPantalla.setOficinaDebeDisabled(true);
//					apuntesManualesPantalla.setCamposDebeDisabled(true);
					apuntesManualesPantalla.setOficinaHaberDisabled(false);
					apuntesManualesPantalla.setCamposHaberDisabled(true);
				}
				//SMM 16/03/2015				
//				else{
//					apuntesManualesPantalla.setOficinaDebeDisabled(true);
//					apuntesManualesPantalla.setCamposDebeDisabled(true);
//					apuntesManualesPantalla.setOficinaHaberDisabled(true);
//					apuntesManualesPantalla.setCamposHaberDisabled(true);
//				}
			}else{
				apuntesManualesPantalla.setGrupoContDebe(null);
				apuntesManualesPantalla.setOficinaDebe(null);
				apuntesManualesPantalla.setCuentaBsDebe(null);
				apuntesManualesPantalla.setSubctaBsDebe(null);
				
				apuntesManualesPantalla.setGrupoContHaber(null);
				apuntesManualesPantalla.setOficinaHaber(null);
				apuntesManualesPantalla.setCuentaBsHaber(null);
				apuntesManualesPantalla.setSubctaBsHaber(null);

				apuntesManualesPantalla.setOficinaDebeDisabled(true);
				apuntesManualesPantalla.setCamposDebeDisabled(true);
				apuntesManualesPantalla.setOficinaHaberDisabled(true);
				apuntesManualesPantalla.setCamposHaberDisabled(true);
			}
		}
	}
	
	public String copiaFechaContable(){
		long fechaValor = apuntesManualesPantalla.getApunteManualSeleccionado().getId().getFechaVal().getTime();
		Date dosmil = GenericUtils.deStringToDate(DOSMIL);
		
		if(dosmil.getTime()>fechaValor || fechaValor>new Date().getTime()){
			statusMessages.add(Severity.ERROR, "#{messages['apuntes.manuales.fechaValor.incorrecta']}");
			return "-1";
		}
		
		apuntesManualesPantalla.getApunteManualSeleccionado().getId().setFechaCon(apuntesManualesPantalla.getApunteManualSeleccionado().getId().getFechaVal());
		return "0";
	}
	
	public void fechaDivisaDeNcorrela(){
		Long ncorrela = apuntesManualesPantalla.getApunteManualSeleccionado().getId().getnCorrela();
		//Deri
		if(apuntesManualesPantalla.getProyecto().equals(Constantes.NOMBRE_PROYECTO_DERI)){
			Operacion operacion = apuntesManualesBo.getOperacion(ncorrela);
			if(operacion!=null){
				apuntesManualesPantalla.getApunteManualSeleccionado().getId().setFechaOpe(operacion.getId().getFechaContratacion());
				if(!GenericUtils.isNullOrBlank(operacion.getDivisaPago())){
					apuntesManualesPantalla.getApunteManualSeleccionado().getId().setCodivisa(operacion.getDivisaPago());
				}else{
					apuntesManualesPantalla.getApunteManualSeleccionado().getId().setCodivisa(operacion.getDivisaRecibo());
				}
			}
		}
		else{//Colat
			Colacont colacont = apuntesManualesBo.getColacont(ncorrela);
			if(colacont!=null){
				apuntesManualesPantalla.getApunteManualSeleccionado().getId().setFechaOpe(colacont.getId().getFechaContratacion());
				if(!GenericUtils.isNullOrBlank(colacont.getDivisaPeriodInteresesPago())){
					apuntesManualesPantalla.getApunteManualSeleccionado().getId().setCodivisa(colacont.getDivisaPeriodInteresesPago());
				}else{
					apuntesManualesPantalla.getApunteManualSeleccionado().getId().setCodivisa(colacont.getDivisaPeriodInteresesRecibo());
				}
			}
		}
	}
	
}
