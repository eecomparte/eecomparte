package com.atosorigin.deri.colat.apuntesManuales.screen;

import java.util.Date;
import java.util.List;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.jboss.seam.ScopeType;
import org.jboss.seam.annotations.Name;
import org.jboss.seam.annotations.Out;
import org.jboss.seam.annotations.Scope;
import org.jboss.seam.annotations.datamodel.DataModel;
import org.jboss.seam.annotations.datamodel.DataModelSelection;

import com.atosorigin.deri.model.catalogo.Producto;
import com.atosorigin.deri.model.colat.EsquemaContable;
import com.atosorigin.deri.model.colat.apuntesManuales.ApunteManual;
import com.atosorigin.deri.model.colat.configuracionesContables.ConceptoTipconta;

/**
 *  Contiene los datos de pantalla necesarios para el mantenimiento de contrapartidas repo.
 */

@Name("apuntesManualesPantalla")
@Scope(ScopeType.CONVERSATION)
public class ApuntesManualesPantalla {
	
	protected static Log log = LogFactory.getLog(ApuntesManualesPantalla.class);


	private String proyecto;

	private Producto productoSelected;
	
	private ConceptoTipconta conceptoSelected;
	
	private Long nCorrelaBusqueda;
	
	private Date fechaEjecucionBusqueda;
	
	@DataModel(value="listaDtApuntesManuales")
	List<ApunteManual> listaApuntesManuales;
	
	@DataModelSelection(value="listaDtApuntesManuales")
	@Out(value = "apunteManualSeleccionado", required = false)
	protected ApunteManual apunteManualSeleccionado;

//	@Out(value = "apunteManualNuevo", required = false)
//	protected ApunteManual apunteManualNuevo;
	
	private boolean checkDiaMenos;
	
	//private DescripcionEntidadOperacion entidadSelected;
	
	private EsquemaContable esquemaSelected;
	
	private boolean camposDebeHabilidados;
	
	private boolean camposHaberHabilitados;
	
	private boolean oficinaDebeHabilitado;
	
	private boolean oficinaHaberHabilitado;
	
	private String entidadNueva;
	
	private EsquemaContable esquemaNuevo;
	
	private ConceptoTipconta conceptoBusqueda;

	private Producto productoBusqueda;

	
	//Campos del debe
	private Short grupoContDebe;
	private String oficinaDebe;
	private String cuentaBsDebe;
	private String subctaBsDebe;
	private boolean camposDebeDisabled=true;
	private boolean oficinaDebeDisabled=true;

	//Campos del haber
	private Short grupoContHaber;
	private String oficinaHaber;
	private String cuentaBsHaber;
	private String subctaBsHaber;
	private boolean camposHaberDisabled=true;
	private boolean oficinaHaberDisabled=true;

	public String getProyecto() {
		return proyecto;
	}

	public void setProyecto(String proyecto) {
		this.proyecto = proyecto;
	}

	public List<ApunteManual> getListaApuntesManuales() {
		return listaApuntesManuales;
	}

	public void setListaApuntesManuales(
			List<ApunteManual> listaApuntesManuales) {
		this.listaApuntesManuales = listaApuntesManuales;
	}

	public ApunteManual getApunteManualSeleccionado() {
		return apunteManualSeleccionado;
	}

	public void setApunteManualSeleccionado(ApunteManual apunteManualSeleccionado) {
		this.apunteManualSeleccionado = apunteManualSeleccionado;
	}

/*	public ApunteManual getApunteManualNuevo() {
		return apunteManualNuevo;
	}

	public void setApunteManualNuevo(ApunteManual apunteManualNuevo) {
		this.apunteManualNuevo = apunteManualNuevo;
	}*/

	public Long getnCorrelaBusqueda() {
		return nCorrelaBusqueda;
	}

	public void setnCorrelaBusqueda(Long nCorrelaBusqueda) {
		this.nCorrelaBusqueda = nCorrelaBusqueda;
	}

	public Date getFechaEjecucionBusqueda() {
		return fechaEjecucionBusqueda;
	}

	public void setFechaEjecucionBusqueda(Date fechaEjecucionBusqueda) {
		this.fechaEjecucionBusqueda = fechaEjecucionBusqueda;
	}

	public Producto getProductoSelected() {
		return productoSelected;
	}

	public void setProductoSelected(Producto productoSelected) {
		this.productoSelected = productoSelected;
	}

	public ConceptoTipconta getConceptoSelected() {
		return conceptoSelected;
	}

	public void setConceptoSelected(ConceptoTipconta conceptoSelected) {
		this.conceptoSelected = conceptoSelected;
	}

	public boolean isCheckDiaMenos() {
		return checkDiaMenos;
	}

	public void setCheckDiaMenos(boolean checkDiaMenos) {
		this.checkDiaMenos = checkDiaMenos;
	}

	/*public DescripcionEntidadOperacion getEntidadSelected() {
		return entidadSelected;
	}

	public void setEntidadSelected(DescripcionEntidadOperacion entidadSelected) {
		this.entidadSelected = entidadSelected;
	}*/

	public EsquemaContable getEsquemaSelected() {
		return esquemaSelected;
	}

	public void setEsquemaSelected(EsquemaContable esquemaSelected) {
		this.esquemaSelected = esquemaSelected;
	}

	public boolean isCamposDebeHabilidados() {
		return camposDebeHabilidados;
	}

	public void setCamposDebeHabilidados(boolean camposDebeHabilidados) {
		this.camposDebeHabilidados = camposDebeHabilidados;
	}

	public boolean isCamposHaberHabilitados() {
		return camposHaberHabilitados;
	}

	public void setCamposHaberHabilitados(boolean camposHaberHabitados) {
		this.camposHaberHabilitados = camposHaberHabitados;
	}

	public boolean isOficinaDebeHabilitado() {
		return oficinaDebeHabilitado;
	}

	public void setOficinaDebeHabilitado(boolean oficinaDebeHabilitado) {
		this.oficinaDebeHabilitado = oficinaDebeHabilitado;
	}

	public boolean isOficinaHaberHabilitado() {
		return oficinaHaberHabilitado;
	}

	public void setOficinaHaberHabilitado(boolean oficinaHaberHabilitado) {
		this.oficinaHaberHabilitado = oficinaHaberHabilitado;
	}

	public String getEntidadNueva() {
		return entidadNueva;
	}

	public void setEntidadNueva(String entidadNueva) {
		this.entidadNueva = entidadNueva;
	}

	public EsquemaContable getEsquemaNuevo() {
		return esquemaNuevo;
	}

	public void setEsquemaNuevo(EsquemaContable esquemaNuevo) {
		this.esquemaNuevo = esquemaNuevo;
	}

	public Short getGrupoContDebe() {
		return grupoContDebe;
	}

	public void setGrupoContDebe(Short grupoContDebe) {
		this.grupoContDebe = grupoContDebe;
	}

	public String getOficinaDebe() {
		return oficinaDebe;
	}

	public void setOficinaDebe(String oficinaDebe) {
		this.oficinaDebe = oficinaDebe;
	}

	public String getCuentaBsDebe() {
		return cuentaBsDebe;
	}

	public void setCuentaBsDebe(String cuentaBsDebe) {
		this.cuentaBsDebe = cuentaBsDebe;
	}

	public String getSubctaBsDebe() {
		return subctaBsDebe;
	}

	public void setSubctaBsDebe(String subctaBsDebe) {
		this.subctaBsDebe = subctaBsDebe;
	}

	public Short getGrupoContHaber() {
		return grupoContHaber;
	}

	public void setGrupoContHaber(Short grupoContHaber) {
		this.grupoContHaber = grupoContHaber;
	}

	public String getOficinaHaber() {
		return oficinaHaber;
	}

	public void setOficinaHaber(String oficinaHaber) {
		this.oficinaHaber = oficinaHaber;
	}

	public String getCuentaBsHaber() {
		return cuentaBsHaber;
	}

	public void setCuentaBsHaber(String cuentaBsHaber) {
		this.cuentaBsHaber = cuentaBsHaber;
	}

	public String getSubctaBsHaber() {
		return subctaBsHaber;
	}

	public void setSubctaBsHaber(String subctaBsHaber) {
		this.subctaBsHaber = subctaBsHaber;
	}

	public boolean isCamposDebeDisabled() {
		return camposDebeDisabled;
	}

	public void setCamposDebeDisabled(boolean camposDebeDisabled) {
		this.camposDebeDisabled = camposDebeDisabled;
	}

	public boolean isOficinaDebeDisabled() {
		return oficinaDebeDisabled;
	}

	public void setOficinaDebeDisabled(boolean oficinaDebeDisabled) {
		this.oficinaDebeDisabled = oficinaDebeDisabled;
	}

	public boolean isCamposHaberDisabled() {
		return camposHaberDisabled;
	}

	public void setCamposHaberDisabled(boolean camposHaberDisabled) {
		this.camposHaberDisabled = camposHaberDisabled;
	}

	public boolean isOficinaHaberDisabled() {
		return oficinaHaberDisabled;
	}

	public void setOficinaHaberDisabled(boolean oficinaHaberDisabled) {
		this.oficinaHaberDisabled = oficinaHaberDisabled;
	}

	public ConceptoTipconta getConceptoBusqueda() {
		return conceptoBusqueda;
	}

	public void setConceptoBusqueda(ConceptoTipconta conceptoBusqueda) {
		this.conceptoBusqueda = conceptoBusqueda;
	}
	
	public void clear(){
		this.productoSelected=null;
		this.conceptoSelected=null;
		this.checkDiaMenos=false;
		this.esquemaSelected=null;
		this.entidadNueva=null;
		this.esquemaNuevo=null;

		this.grupoContDebe=null;
		this.oficinaDebe=null;
		this.cuentaBsDebe=null;
		this.subctaBsDebe=null;
		this.grupoContHaber=null;
		this.oficinaHaber=null;
		this.cuentaBsHaber=null;
		this.subctaBsHaber=null;
	}

	public Producto getProductoBusqueda() {
		return productoBusqueda;
	}

	public void setProductoBusqueda(Producto productoBusqueda) {
		this.productoBusqueda = productoBusqueda;
	}



}
