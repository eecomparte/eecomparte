package com.atosorigin.deri.colat.configuracionesContables.action;

import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;

import org.jboss.seam.ScopeType;
import org.jboss.seam.annotations.In;
import org.jboss.seam.annotations.Name;
import org.jboss.seam.annotations.Scope;
import org.jboss.seam.international.StatusMessage.Severity;

import com.atosorigin.common.action.ModoPantalla;
import com.atosorigin.common.action.PaginatedListAction;
import com.atosorigin.common.constantes.Constantes;
import com.atosorigin.common.formvalidator.FormValidator;
import com.atosorigin.common.utils.GenericUtils;
import com.atosorigin.deri.colat.configuracionesContables.business.ConfiguracionesContablesBo;
import com.atosorigin.deri.colat.configuracionesContables.screen.ConfiguracionesContablesPantalla;
import com.atosorigin.deri.model.adminoper.DescripcionEntidadOperacion;
import com.atosorigin.deri.model.catalogo.Producto;
import com.atosorigin.deri.model.colat.EsquemaContable;
import com.atosorigin.deri.model.colat.configuracionesContables.ConceptoTipContaContador;
import com.atosorigin.deri.model.colat.configuracionesContables.ConceptoTipconta;
import com.atosorigin.deri.model.colat.configuracionesContables.ConceptoTipcontaId;
import com.atosorigin.deri.model.contabilidad.GrupoContable;
import com.atosorigin.deri.model.parametrizacion.ConfiguracionContable;
import com.atosorigin.deri.model.parametrizacion.ConfiguracionContableId;

/**
 * Clase action listener para el caso de uso de configuraciones contables
 */
@Name("configuracionesContablesAction")
@Scope(ScopeType.CONVERSATION)
@FormValidator
public class ConfiguracionesContablesAction extends PaginatedListAction {
	
	@In(value="#{configuracionesContablesBo}")
	ConfiguracionesContablesBo configuracionesContablesBo;
	
	@In(create=true)
	ConfiguracionesContablesPantalla configuracionesContablesPantalla;
	
	//concepto cabecera de cada grupo listado 
	private ConceptoTipconta conceptoActual;
	
	public void proyectoDeri(){
		configuracionesContablesPantalla.setProyecto(Constantes.NOMBRE_PROYECTO_DERI);
	}

	public void proyectoColat(){
		configuracionesContablesPantalla.setProyecto(Constantes.NOMBRE_PROYECTO_COLAT);
	}
	
	public void onProductoGrucontChange() {
		Producto prod = configuracionesContablesPantalla.getProductoSelected();
		configuracionesContablesPantalla.setTipContas(getListaConceptos());
	}

	public void onEsquemaChange() {
		configuracionesContablesPantalla.setTipContas(getListaConceptos());
	}
	public void onGrupoContChange() {
		configuracionesContablesPantalla.setTipContas(getListaConceptos());
	}

	public void onProductoGrucontChangeDetalle() {
		Producto prod = new Producto();
		prod.setId(configuracionesContablesPantalla.getConfiguracionContableSeleccionada().getId().getProducto());
	}

	public void onCuentaChange(){
		if(configuracionesContablesPantalla.getConfiguracionContableSeleccionada().getCuenta().length()!=10 ){
					statusMessages.add(Severity.ERROR, "#{messages['configuraciones.contables.cuentapeque']}", Constantes.DEFAULT_MESSAGE_TEMPLATE);
			}

	}
	
	public void onCuentaContrapaChange(){
		if(configuracionesContablesPantalla.getConfiguracionContableSeleccionada().getCuentaContrapartida().length()!=10){
			statusMessages.add(Severity.ERROR, "#{messages['configuraciones.contables.cuentapeque']}", Constantes.DEFAULT_MESSAGE_TEMPLATE);
		}
	}
	
	public void buscar(){
		if(GenericUtils.isNullOrBlank(configuracionesContablesPantalla.getProductoSelected())){
			statusMessages.add(Severity.ERROR, "#{messages['configuraciones.contables.producto.required']}", Constantes.DEFAULT_MESSAGE_TEMPLATE);
			return;
		}

		//obtenemos map de conceptos y filas por concepto para la paginación
		configuracionesContablesPantalla.setConceptos(getMapConceptos());
		

		setPrimerAcceso(false);
		paginationData.reset();
		configuracionesContablesPantalla.setNumeroPagina(1);
		refrescarLista();		
	}

	public Boolean guardarValidator(){
		if(configuracionesContablesPantalla.getConfiguracionContableSeleccionada().getCuentaContrapartida().length()!=10 || 
				   configuracionesContablesPantalla.getConfiguracionContableSeleccionada().getCuenta().length()!=10 ){

		statusMessages.add(Severity.ERROR, "#{messages['configuraciones.contables.cuentapeque']}", Constantes.DEFAULT_MESSAGE_TEMPLATE);
		return false;
		}
		
		if (( (!GenericUtils.isNullOrBlank(configuracionesContablesPantalla.getConfiguracionContableSeleccionada().getGrupoContable()) &&
			 configuracionesContablesPantalla.getConfiguracionContableSeleccionada().getGrupoContable()==85) ||
			 (!GenericUtils.isNullOrBlank(configuracionesContablesPantalla.getConfiguracionContableSeleccionada().getGrupoCuenta()) &&
			 configuracionesContablesPantalla.getConfiguracionContableSeleccionada().getGrupoCuenta()==85) 
			) &&
			(
			 GenericUtils.isNullOrBlank(configuracionesContablesPantalla.getConfiguracionContableSeleccionada().getCuentaPosicion()) ||
			 "0".equals(configuracionesContablesPantalla.getConfiguracionContableSeleccionada().getCuentaPosicion())
			)
		){
			statusMessages.add(Severity.ERROR, "#{messages['configuraciones.contables.cuentaposicion']}", Constantes.DEFAULT_MESSAGE_TEMPLATE);
			return false;
		}
		
		if ((GenericUtils.isNullOrBlank(configuracionesContablesPantalla.getConfiguracionContableSeleccionada().getGrupoContable()) || 
				configuracionesContablesPantalla.getConfiguracionContableSeleccionada().getGrupoContable()!=85)				&&
			(GenericUtils.isNullOrBlank(configuracionesContablesPantalla.getConfiguracionContableSeleccionada().getGrupoCuenta()) ||
				configuracionesContablesPantalla.getConfiguracionContableSeleccionada().getGrupoCuenta()!=85)   &&
  		    !GenericUtils.isNullOrBlank(configuracionesContablesPantalla.getConfiguracionContableSeleccionada().getCuentaPosicion()) &&
			!"0".equals(configuracionesContablesPantalla.getConfiguracionContableSeleccionada().getCuentaPosicion())
			){
				statusMessages.add(Severity.ERROR, "#{messages['configuraciones.contables.cuentaposicion']}", Constantes.DEFAULT_MESSAGE_TEMPLATE);
				return false;
			}
		
		return true;
	}
		
	public String guardar(){
		if(ModoPantalla.CREACION.equals(getModoPantalla())){
			ConfiguracionContableId id = configuracionesContablesPantalla.getConfiguracionContableSeleccionada().getId();
			//formateamos la entidad
			if(!GenericUtils.isNullOrBlank(id.getEntidad()))
				id.setEntidad(GenericUtils.lpad(configuracionesContablesPantalla.getEntidadSelected().getCodigo(),4,"0"));
			//proyecto
			id.setProyecto(configuracionesContablesPantalla.getProyecto());

			
			if(GenericUtils.isNullOrBlank(configuracionesContablesBo.cargar(configuracionesContablesPantalla.getConfiguracionContableSeleccionada().getId()))){
				ConfiguracionContable nueva = configuracionesContablesPantalla.getConfiguracionContableSeleccionada();
				//proyecto
				nueva.getId().setProyecto(configuracionesContablesPantalla.getProyecto());
				//formateamos la entidad
				nueva.getId().setEntidad(GenericUtils.lpad(configuracionesContablesPantalla.getEntidadSelected().getCodigo(),4,"0"));
				//esquema
				//nueva.getId().setEsquemaContable(configuracionesContablesPantalla.getEsquemaSelected().getId());

				//codasien
				String codigoAsiento = configuracionesContablesBo.obtenerCodigoAsiento(nueva.getId().getProyecto(),nueva.getId().getEntidad(),nueva.getId().getProducto());
				nueva.setCodigoAsiento(codigoAsiento);
				configuracionesContablesBo.alta(nueva);
				statusMessages.add(Severity.INFO, "#{messages['configuraciones.contables.altacorrecta']}", Constantes.DEFAULT_MESSAGE_TEMPLATE);
			}else{
				statusMessages.add(Severity.ERROR, "#{messages['configuraciones.contables.duplicado']}", Constantes.DEFAULT_MESSAGE_TEMPLATE);
				return Constantes.CONSTANTE_FAIL;
			}
		}if(ModoPantalla.EDICION.equals(getModoPantalla())){
			configuracionesContablesBo.modifica(configuracionesContablesPantalla.getConfiguracionContableSeleccionada());
			statusMessages.add(Severity.INFO, "#{messages['configuraciones.contables.modificacioncorrecta']}", Constantes.DEFAULT_MESSAGE_TEMPLATE);
		}
		//actualizamos la lista de conceptos
		configuracionesContablesPantalla.setConceptos(getMapConceptos());
		if (configuracionesContablesPantalla.getNumeroPagina()==0){ 
			configuracionesContablesPantalla.setNumeroPagina(1);
		}
		refrescarLista();

		return Constantes.CONSTANTE_SUCCESS;
	}
	
	public void alta(){
		configuracionesContablesPantalla.setConfiguracionContableSeleccionada(new ConfiguracionContable(new ConfiguracionContableId()));
		setModoPantalla(ModoPantalla.CREACION);
	}
	
	public void editar(){
		ConfiguracionContable configuracionContable = configuracionesContablesBo.cargar(configuracionesContablesPantalla.getConfiguracionContableSeleccionada().getId());
		configuracionesContablesPantalla.getConfiguracionContableSeleccionada().getId().setEntidad(configuracionContable.getId().getEntidad());
		configuracionesContablesPantalla.getConfiguracionContableSeleccionada().getId().setProducto(configuracionContable.getId().getProducto());
		configuracionesContablesPantalla.getConfiguracionContableSeleccionada().getId().setEsquemaContable(configuracionContable.getId().getEsquemaContable());
		configuracionesContablesPantalla.getConfiguracionContableSeleccionada().getId().setAgrupacionContable(configuracionContable.getId().getAgrupacionContable());
		configuracionesContablesPantalla.getConfiguracionContableSeleccionada().getId().setConcepto(configuracionContable.getId().getConcepto());
		configuracionesContablesPantalla.getConfiguracionContableSeleccionada().getId().setProyecto(configuracionContable.getId().getProyecto());
		
		setModoPantalla(ModoPantalla.EDICION);
	}
	
	public void borrar(){
		configuracionesContablesBo.baja(configuracionesContablesPantalla.getConfiguracionContableSeleccionada());
		statusMessages.add(Severity.INFO, "#{messages['configuraciones.contables.borradoCorrecto']}", Constantes.DEFAULT_MESSAGE_TEMPLATE);
		//actualizamos la lista de conceptos
		configuracionesContablesPantalla.setConceptos(getMapConceptos());
		refrescarLista();
	}
	
	public void copiar(){
		ConfiguracionContable configuracionContable = configuracionesContablesBo.cargar(configuracionesContablesPantalla.getConfiguracionContableSeleccionada().getId());
		configuracionesContablesPantalla.getConfiguracionContableSeleccionada().getId().setEntidad(configuracionContable.getId().getEntidad());
		configuracionesContablesPantalla.getConfiguracionContableSeleccionada().getId().setProducto(configuracionContable.getId().getProducto());
		configuracionesContablesPantalla.getConfiguracionContableSeleccionada().getId().setEsquemaContable(configuracionContable.getId().getEsquemaContable());
		configuracionesContablesPantalla.getConfiguracionContableSeleccionada().getId().setAgrupacionContable(configuracionContable.getId().getAgrupacionContable());
		configuracionesContablesPantalla.getConfiguracionContableSeleccionada().getId().setProyecto(configuracionContable.getId().getProyecto());
		
		configuracionesContablesPantalla.setConfiguracionContableNueva(new ConfiguracionContable(new ConfiguracionContableId()));
		configuracionesContablesPantalla.setCopiarCuenta("");

		setModoPantalla(ModoPantalla.EDICION);
	}
	
	public String guardarCopia(){
		ConfiguracionContableId idPlantilla = configuracionesContablesPantalla.getConfiguracionContableSeleccionada().getId();
		ConfiguracionContableId idNueva = configuracionesContablesPantalla.getConfiguracionContableNueva().getId();
		String copiarCuentas = configuracionesContablesPantalla.getCopiarCuenta();
		//formateamos la entidad
		if(!GenericUtils.isNullOrBlank(idPlantilla.getEntidad()))
			idPlantilla.setEntidad(GenericUtils.lpad(configuracionesContablesPantalla.getEntidadSelected().getCodigo(),4,"0"));
		//proyecto
		String proyecto = configuracionesContablesPantalla.getProyecto();
		idPlantilla.setProyecto(proyecto);
		idNueva.setProyecto(proyecto);
		
		//Comprobamos si ya existen registros para el nuevo esquema. En ese caso no permitimos la copia
		List<ConfiguracionContable> existeNueva = configuracionesContablesBo
		.buscarConfiguracionesContables(proyecto,idNueva.getEntidad(), idNueva.getProducto(), idNueva.getEsquemaContable(),idNueva.getAgrupacionContable());
		if(existeNueva.size()>0){
			statusMessages.add(Severity.ERROR, "#{messages['colat.configuraciones.contables.copiar.nuevo.yaexiste']}", Constantes.DEFAULT_MESSAGE_TEMPLATE);
			return Constantes.CONSTANTE_FAIL;
		}
		
		//obtenemos los datos del esquema plantilla
		List<ConfiguracionContable> listaConfiguracionesContables = configuracionesContablesBo
		.buscarConfiguracionesContables(proyecto,idPlantilla.getEntidad(), idPlantilla.getProducto(), idPlantilla.getEsquemaContable(),idPlantilla.getAgrupacionContable());
		
		List<ConfiguracionContable> listaNuevas = new ArrayList<ConfiguracionContable>();
		//tratar la lista, modificando la pk por los nuevos criterios
		for(ConfiguracionContable configuracionContable : listaConfiguracionesContables){
			ConfiguracionContable nueva = new ConfiguracionContable();
			ConfiguracionContableId nuevaId = new ConfiguracionContableId();
			nuevaId.setProyecto(idNueva.getProyecto());
			nuevaId.setEntidad(GenericUtils.lpad(idNueva.getEntidad(), 4,"0"));
			nuevaId.setProducto(idNueva.getProducto());
			nuevaId.setEsquemaContable(idNueva.getEsquemaContable());
			nuevaId.setAgrupacionContable(idNueva.getAgrupacionContable());
			
			nuevaId.setConcepto(configuracionContable.getId().getConcepto());
			
			nueva.setId(nuevaId);
			
			//si cuenta no, setear todos los campos a nulo
			if(copiarCuentas.equals(Constantes.CONSTANTE_SI)){
				copiaCampos(configuracionContable,nueva);
			}
			listaNuevas.add(nueva);

		}
		//grabar datos
		configuracionesContablesBo.guardarCopia(listaNuevas);
		buscar();
		
		statusMessages.add(Severity.INFO, "#{messages['colat.configuraciones.contables.copiar.nuevo.ok']}", Constantes.DEFAULT_MESSAGE_TEMPLATE);

		return Constantes.CONSTANTE_SUCCESS;	}

	@Override
	public List<?> getDataTableList() {
		
		return configuracionesContablesPantalla.getListaConfiguracionesContables();
	}
	
	@Override
	public void salir()
	{
		if (!GenericUtils.isNullOrBlank(configuracionesContablesPantalla.getConfiguracionContableSeleccionada()) 
			&& !GenericUtils.isNullOrBlank(configuracionesContablesPantalla.getConfiguracionContableSeleccionada().getId())
			&& !GenericUtils.isNullOrBlank(configuracionesContablesPantalla.getConfiguracionContableSeleccionada().getId().getProyecto()) 
			&& !GenericUtils.isNullOrBlank(configuracionesContablesPantalla.getConfiguracionContableSeleccionada().getId().getProducto())	){
			configuracionesContablesBo.clearEM(configuracionesContablesPantalla.getConfiguracionContableSeleccionada());	
		}
		
	}
	
	public void ver(){
		configuracionesContablesPantalla.setConfiguracionContableSeleccionada(configuracionesContablesPantalla.getConfiguracionContableSeleccionada());
		setModoPantalla(ModoPantalla.INSPECCION);
	}

	@Override
	protected void refreshListInternal() {
		String entidad = null;
		Producto producto = null;
		EsquemaContable esquema = null;
		GrupoContable grupocon=null;
		ConceptoTipconta concepto = null;
		String proyecto = configuracionesContablesPantalla.getProyecto();
		setExportExcel(false);
	
		if(!GenericUtils.isNullOrBlank(configuracionesContablesPantalla.getEntidadSelected())){
			DescripcionEntidadOperacion entidadNum = configuracionesContablesPantalla.getEntidadSelected();
			entidad = GenericUtils.lpad(entidadNum.getCodigo(), 4,"0");

		}
		if(!GenericUtils.isNullOrBlank(configuracionesContablesPantalla.getProductoSelected())){
			producto = configuracionesContablesPantalla.getProductoSelected();
		}
		if(!GenericUtils.isNullOrBlank(configuracionesContablesPantalla.getEsquemaSelected())){
			esquema = configuracionesContablesPantalla.getEsquemaSelected();
		}
		if(!GenericUtils.isNullOrBlank(configuracionesContablesPantalla.getGrupoContableSelected())){
			grupocon = configuracionesContablesPantalla.getGrupoContableSelected();
		}

		//obtenemos map de conceptos y filas por concepto para la paginación
		//List<ConceptoTipContaContador> conceptos = getMapConceptos();
		List<ConceptoTipContaContador> conceptos = configuracionesContablesPantalla.getConceptos();
		if(!GenericUtils.isNullOrBlank(configuracionesContablesPantalla.getConceptoSelected())){
			for(int i=0;i<conceptos.size();i++){
				ConceptoTipContaContador actual = conceptos.get(i);
				if (actual.getConcepto().equals(configuracionesContablesPantalla.getConceptoSelected())){
					configuracionesContablesPantalla.setNumeroPagina(i+1);
					break;
				}
			}
		}
			
		configuracionesContablesPantalla.setListaConfiguracionesContables(null);
		List<ConfiguracionContable> listaConfiguracionesContables = new ArrayList<ConfiguracionContable>();
		listaConfiguracionesContables = null;
		if(null!=conceptos && conceptos.size()>0){
			int pagina = configuracionesContablesPantalla.getNumeroPagina();
			//SMM 25/08/2017 Al eliminar el ultimo elemento del ultimo concepto no se posiciona correctamente, al no existir el siguiente concepto
			// que por defecto es el que muestra. 
			if ( pagina > conceptos.size() ) {
				pagina = conceptos.size();
				configuracionesContablesPantalla.setNumeroPagina(pagina);
			}
			//FIN MODIF
			ConceptoTipContaContador concont = conceptos.get(pagina-1); 
			this.conceptoActual= concont.getConcepto();
			int numFilas = concont.getContador().intValue();
			paginationData.setMaxResults(numFilas);
			paginationData.setFirstResult(concont.getFirstResult().intValue());
			configuracionesContablesPantalla.setNumConfiguracionesContables(numFilas);
	
			listaConfiguracionesContables = configuracionesContablesBo
			.buscarConfiguracionesContables(proyecto,entidad, producto, esquema, grupocon,paginationData);
			
			configuracionesContablesPantalla.setListaConfiguracionesContables(listaConfiguracionesContables);
		}else{
			configuracionesContablesPantalla.setListaConfiguracionesContables(null);
		}
	}

	@Override
	public void refrescarListaExcel() {
		String entidad = null;
		Producto producto = null;
		EsquemaContable esquema = null;
		GrupoContable grupocon=null;
		String proyecto = configuracionesContablesPantalla.getProyecto();
		setExportExcel(true);
		
		if(!GenericUtils.isNullOrBlank(configuracionesContablesPantalla.getEntidadSelected())){
			String entidadNum = configuracionesContablesPantalla.getEntidadSelected().getCodigo();
			entidad = GenericUtils.lpad(entidadNum, 4,"0");
		}
		if(!GenericUtils.isNullOrBlank(configuracionesContablesPantalla.getProductoSelected())){
			producto = configuracionesContablesPantalla.getProductoSelected();
		}
		if(!GenericUtils.isNullOrBlank(configuracionesContablesPantalla.getEsquemaSelected())){
			esquema = configuracionesContablesPantalla.getEsquemaSelected();
		}
		if(!GenericUtils.isNullOrBlank(configuracionesContablesPantalla.getGrupoContableSelected())){
			grupocon = configuracionesContablesPantalla.getGrupoContableSelected();
		}
		List<ConfiguracionContable> listaConfiguracionesContables = configuracionesContablesBo
		.buscarConfiguracionesContables(proyecto,entidad, producto, esquema, grupocon,paginationData.getPaginationDataForExcel());

		configuracionesContablesPantalla.setListaConfiguracionesContables(listaConfiguracionesContables);
	}

	@Override
	public void setDataTableList(List<?> dataTableList) {
		configuracionesContablesPantalla.setListaConfiguracionesContables((List<ConfiguracionContable>)dataTableList);
		
	}

	public ConfiguracionesContablesPantalla getConfiguracionesContablesPantalla() {
		return configuracionesContablesPantalla;
	}

	public void setConfiguracionesContablesPantalla(
			ConfiguracionesContablesPantalla configuracionesContablesPantalla) {
		this.configuracionesContablesPantalla = configuracionesContablesPantalla;
	}
	public ConfiguracionesContablesBo getConfiguracionesContablesBo() {
		return configuracionesContablesBo;
	}
	public void setConfiguracionesContablesBo(
			ConfiguracionesContablesBo configuracionesContablesBo) {
		this.configuracionesContablesBo = configuracionesContablesBo;
	}
	
	/**
	 * Para cada concepto a listar el objeto ConceptoTipContaContador 
	 * tiene el número de registros y el first result necesarios para realizar la consulta
	 * @return
	 */
	public List<ConceptoTipContaContador> getMapConceptos(){
		String entidad = null;
		String producto = null;
		String esquema = null;
		String grupocon=null;
		String proyecto = configuracionesContablesPantalla.getProyecto();
		
		if(!GenericUtils.isNullOrBlank(configuracionesContablesPantalla.getEntidadSelected())){
			entidad=configuracionesContablesPantalla.getEntidadSelected().getCodigo();
		}
		if(!GenericUtils.isNullOrBlank(configuracionesContablesPantalla.getProductoSelected())){
			producto = configuracionesContablesPantalla.getProductoSelected().getId();
		}
		if(!GenericUtils.isNullOrBlank(configuracionesContablesPantalla.getEsquemaSelected())){
			esquema = configuracionesContablesPantalla.getEsquemaSelected().getCodigo();
		}
		if(!GenericUtils.isNullOrBlank(configuracionesContablesPantalla.getGrupoContableSelected())){
			grupocon = configuracionesContablesPantalla.getGrupoContableSelected().getId().getGrupoContable();
		}
		List result = configuracionesContablesBo.getMapConceptos(proyecto, entidad, producto, esquema, grupocon);

		List<ConceptoTipContaContador> conceptos = new LinkedList<ConceptoTipContaContador>();

		long maxResults=0;
		for(int i=0;i<result.size();i++){
			ConfiguracionContableId id = new ConfiguracionContableId();
			Object[] o = (Object[])result.get(i);
			//C.PROYECTO,C.ENTIOPER,C.PRODUCTO,C.CONCEPTO,COUNT(*)
			
			ConceptoTipcontaId ctcid = new ConceptoTipcontaId(proyecto,(String)o[3]);
			try{
				ConceptoTipconta concepto = configuracionesContablesBo.obtenerConcepto(ctcid);
				if(null!=concepto){
					Long numFilas = (Long)o[4];
					if(numFilas>0){
						ConceptoTipContaContador par = new ConceptoTipContaContador(concepto,numFilas,maxResults);
						maxResults+=numFilas;
						conceptos.add(par);
					}
				}
			}
			catch (Exception e){
				log.error("Concepto "+ctcid.getCodconta()+" no existente para el proyecto "+ctcid.getProyecto());
			}
		}
		return conceptos;
	}
	
	public List<ConceptoTipconta> getListaConceptos(){
		String entidad = "0081";
		String producto = null;
		String esquema = null;
		String grupocon=null;
		String proyecto = configuracionesContablesPantalla.getProyecto();
		
		if(!GenericUtils.isNullOrBlank(configuracionesContablesPantalla.getEntidadSelected())){
			entidad=configuracionesContablesPantalla.getEntidadSelected().getCodigo();
		}
		if(!GenericUtils.isNullOrBlank(configuracionesContablesPantalla.getProductoSelected())){
			producto = configuracionesContablesPantalla.getProductoSelected().getId();
		}
		if(!GenericUtils.isNullOrBlank(configuracionesContablesPantalla.getEsquemaSelected())){
			esquema = configuracionesContablesPantalla.getEsquemaSelected().getCodigo();
		}
		if(!GenericUtils.isNullOrBlank(configuracionesContablesPantalla.getGrupoContableSelected())){
			grupocon = configuracionesContablesPantalla.getGrupoContableSelected().getId().getGrupoContable();
		}
		List result = configuracionesContablesBo.getListaConceptos(proyecto, entidad, producto, esquema, grupocon);

		return result;
	}

	public void copiaCampos(ConfiguracionContable configuracionContable, ConfiguracionContable nueva){
		nueva.setCuenta(configuracionContable.getCuenta());;
		nueva.setCuentaContrapartida(configuracionContable.getCuentaContrapartida());
		nueva.setCuentaPosicion(configuracionContable.getCuentaPosicion());
		nueva.setGrupoContable(configuracionContable.getGrupoContable());
		nueva.setGrupoCuenta(configuracionContable.getGrupoCuenta());
		nueva.setObservaciones(configuracionContable.getObservaciones());
		nueva.setSubcuenta(configuracionContable.getSubcuenta());
		nueva.setSubcuentaContrapartida(configuracionContable.getSubcuentaContrapartida());
	}

	public ConceptoTipconta getConceptoActual() {
		return conceptoActual;
	}

	public void setConceptoActual(ConceptoTipconta conceptoActual) {
		this.conceptoActual = conceptoActual;
	}
	
	public Producto cargarProducto(String productoId){
		if (productoId==null || productoId.equals(""))
			return null;

		return configuracionesContablesBo.cargarProducto(productoId);
	}
	
	public String obtenerConcepto(String codConcepto){
		ConceptoTipcontaId ctcid = new ConceptoTipcontaId(configuracionesContablesPantalla.getProyecto(),codConcepto);
		return configuracionesContablesBo.obtenerConcepto(ctcid).getDesconta();
	}
	

	/******** PAGINACIÓN ******
	 * Dado que el número de registros a mostrar en cada página es diferente no usamos
	 * los botones del PaginatedListAction y el pagination.xhtml.
	 * Creamos la página paginationConfCont y aquí implementamos los métodos para paginar
	 * */
	
	/**
	 * Comprueba que hay una página anterior a la que se está mostrando actualmente.
	 * 
	 * @return true si hay página anterior.
	 */
	public boolean isExisteAnterior() {
		return configuracionesContablesPantalla.getNumeroPagina() > 1;
	}

	/**
	 * Comprueba si hay página siguiente a la que se está mostrando actualmente.
	 * 
	 * @return true, Si hay página siguiente
	 */
	public boolean isExisteSiguiente() {
		int paginaActual = configuracionesContablesPantalla.getNumeroPagina();
		//List<ConceptoTipContaContador> conceptos = getMapConceptos();
		List<ConceptoTipContaContador> conceptos = configuracionesContablesPantalla.getConceptos();
		return conceptos!=null && conceptos.size()>0 && conceptos.size()>paginaActual;
		
	}
	
	public boolean isExisteUltimo() {
		int paginaActual = configuracionesContablesPantalla.getNumeroPagina();
		List<ConceptoTipContaContador> conceptos = configuracionesContablesPantalla.getConceptos();
		return conceptos!=null && conceptos.size()>0 && conceptos.size()>paginaActual;
	}

	/**
	 * Actualiza la lista de datos del grid con la siguiente página de base de datos,
	 */
	public void siguiente() {
		int paginaActual = configuracionesContablesPantalla.getNumeroPagina();
		configuracionesContablesPantalla.setNumeroPagina(paginaActual + 1);
		this.refrescarLista();
	}

	/**
	 * Actualiza la lista de datos del grid con la anterior página de base de datos,
	 */
	public void anterior() {
		int paginaActual = configuracionesContablesPantalla.getNumeroPagina();
		if(paginaActual>1)
			configuracionesContablesPantalla.setNumeroPagina(paginaActual - 1);
		this.refrescarLista();
	}

	/**
	 * Actualiza la lista de datos del grid con la primera página de base de datos,
	 */
	public void primero() {
		configuracionesContablesPantalla.setNumeroPagina(1); //¿ó 0?
		this.refrescarLista();
	}

	
	public int getActivePage() {
		return configuracionesContablesPantalla.getNumeroPagina();
	}
	
	public void ultimo(){
		int ultimaPagina = configuracionesContablesPantalla.getConceptos().size();
		configuracionesContablesPantalla.setNumeroPagina(ultimaPagina);
		this.refrescarLista();
	}
}
