package com.atosorigin.deri.colat.configuracionesContables.screen;

import java.util.List;

import org.jboss.seam.ScopeType;
import org.jboss.seam.annotations.Name;
import org.jboss.seam.annotations.Out;
import org.jboss.seam.annotations.Scope;
import org.jboss.seam.annotations.datamodel.DataModel;
import org.jboss.seam.annotations.datamodel.DataModelSelection;

import com.atosorigin.deri.model.adminoper.DescripcionEntidadOperacion;
import com.atosorigin.deri.model.catalogo.Producto;
import com.atosorigin.deri.model.colat.EsquemaContable;
import com.atosorigin.deri.model.colat.configuracionesContables.ConceptoTipContaContador;
import com.atosorigin.deri.model.colat.configuracionesContables.ConceptoTipconta;
import com.atosorigin.deri.model.colat.configuracionesContables.CuentaPosicion;
import com.atosorigin.deri.model.contabilidad.GrupoContable;
import com.atosorigin.deri.model.parametrizacion.ConfiguracionContable;

/**
 *  Contiene los datos de pantalla necesarios para el mantenimiento de contrapartidas repo.
 */

@Name("configuracionesContablesPantalla")
@Scope(ScopeType.CONVERSATION)
public class ConfiguracionesContablesPantalla {

	private String proyecto;

	private DescripcionEntidadOperacion entidadSelected;
	
	private Producto productoSelected;
	
	private EsquemaContable esquemaSelected;
	
	private GrupoContable grupoContableSelected;
	
	private ConceptoTipconta conceptoSelected;
	
	private CuentaPosicion cuentaPosicionSelected;
	
	private int numConfiguracionesContables;
	
	public int numeroPagina;
	
	
	@DataModel(value="listaDtConfiguracionesContables")
	List<ConfiguracionContable> listaConfiguracionesContables;
	
	@DataModelSelection(value="listaDtConfiguracionesContables")
	@Out(value = "configuracionContableSeleccionada", required = false)
	protected ConfiguracionContable configuracionContableSeleccionada;

	@Out(value = "configuracionContableNueva", required = false)
	protected ConfiguracionContable configuracionContableNueva;
	
	private String copiarCuenta;
	
	private List<ConceptoTipContaContador> conceptos;

	private List<ConceptoTipconta> tipContas;

	public String getProyecto() {
		return proyecto;
	}

	public void setProyecto(String proyecto) {
		this.proyecto = proyecto;
	}

	public DescripcionEntidadOperacion getEntidadSelected() {
		return entidadSelected;
	}

	public void setEntidadSelected(DescripcionEntidadOperacion entidadSelected) {
		this.entidadSelected = entidadSelected;
	}

	public Producto getProductoSelected() {
		return productoSelected;
	}

	public void setProductoSelected(Producto productoSelected) {
		this.productoSelected = productoSelected;
	}

	public EsquemaContable getEsquemaSelected() {
		return esquemaSelected;
	}

	public void setEsquemaSelected(EsquemaContable esquemaSelected) {
		this.esquemaSelected = esquemaSelected;
	}

	public GrupoContable getGrupoContableSelected() {
		return grupoContableSelected;
	}

	public void setGrupoContableSelected(GrupoContable grupoContableSelected) {
		this.grupoContableSelected = grupoContableSelected;
	}
	
	public List<ConfiguracionContable> getListaConfiguracionesContables() {
		return listaConfiguracionesContables;
	}

	public void setListaConfiguracionesContables(
			List<ConfiguracionContable> listaConfiguracionesContables) {
		this.listaConfiguracionesContables = listaConfiguracionesContables;
	}

	public int getNumConfiguracionesContables() {
		return numConfiguracionesContables;
	}

	public void setNumConfiguracionesContables(int numConfiguracionesContables) {
		this.numConfiguracionesContables = numConfiguracionesContables;
	}

	public ConceptoTipconta getConceptoSelected() {
		return conceptoSelected;
	}

	public void setConceptoSelected(ConceptoTipconta conceptoSelected) {
		this.conceptoSelected = conceptoSelected;
	}

	public CuentaPosicion getCuentaPosicionSelected() {
		return cuentaPosicionSelected;
	}

	public void setCuentaPosicionSelected(CuentaPosicion cuentaPosicionSelected) {
		this.cuentaPosicionSelected = cuentaPosicionSelected;
	}

	public ConfiguracionContable getConfiguracionContableSeleccionada() {
		return configuracionContableSeleccionada;
	}

	public void setConfiguracionContableSeleccionada(
			ConfiguracionContable configuracionContableSeleccionada) {
		this.configuracionContableSeleccionada = configuracionContableSeleccionada;
	}

	public ConfiguracionContable getConfiguracionContableNueva() {
		return configuracionContableNueva;
	}

	public void setConfiguracionContableNueva(
			ConfiguracionContable configuracionContableNueva) {
		this.configuracionContableNueva = configuracionContableNueva;
	}

	public String getCopiarCuenta() {
		return copiarCuenta;
	}

	public void setCopiarCuenta(String copiarCuenta) {
		this.copiarCuenta = copiarCuenta;
	}

	public List<ConceptoTipContaContador> getConceptos() {
		return conceptos;
	}

	public void setConceptos(List<ConceptoTipContaContador> conceptos) {
		this.conceptos = conceptos;
	}

	public int getNumeroPagina() {
		return numeroPagina;
	}

	public void setNumeroPagina(int numeroPagina) {
		this.numeroPagina = numeroPagina;
	}

	public void setTipContas(List<ConceptoTipconta> tipContas) {
		this.tipContas = tipContas;
	}

	public List<ConceptoTipconta> getTipContas() {
		return tipContas;
	}

}
