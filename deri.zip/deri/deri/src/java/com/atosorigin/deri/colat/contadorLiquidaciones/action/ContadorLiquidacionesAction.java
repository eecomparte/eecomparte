package com.atosorigin.deri.colat.contadorLiquidaciones.action;

import java.util.List;

import org.jboss.seam.ScopeType;
import org.jboss.seam.annotations.In;
import org.jboss.seam.annotations.Name;
import org.jboss.seam.annotations.Scope;
import org.jboss.seam.core.Conversation;

import com.atosorigin.common.action.PaginatedListAction;
import com.atosorigin.common.constantes.Constantes;
import com.atosorigin.common.formvalidator.FormValidator;
import com.atosorigin.deri.colat.contadorLiquidaciones.screen.ContadorLiquidacionesPantalla;
import com.atosorigin.deri.liquidaciones.business.LiquidacionesBo;
import com.atosorigin.deri.model.colat.ContadoresLiquidaciones;

/**
 * Clase action listener para el caso de uso de contrapartidas liquidación
 */
@Name("contadorLiquidacionesAction")
@Scope(ScopeType.CONVERSATION)
@FormValidator
public class ContadorLiquidacionesAction extends PaginatedListAction {

	@In(value="#{liquidacionesBo}")
	LiquidacionesBo liquidacionesBo;
	
	@In(create=true)
	ContadorLiquidacionesPantalla contadorLiquidacionesPantalla ;

	public void proyectoColat(){
		this.contadorLiquidacionesPantalla.setProyecto(Constantes.NOMBRE_PROYECTO_COLAT);
	}

	public void proyectoDeri(){
		this.contadorLiquidacionesPantalla.setProyecto(Constantes.NOMBRE_PROYECTO_DERI);
	}

	
	public void buscar(){
		setPrimerAcceso(false);
		paginationData.reset();
		refrescarLista();		
	}
	
	
	@Override
	public List<?> getDataTableList() {
		
		return contadorLiquidacionesPantalla.getContadorList();
	}
	

	@Override
	protected void refreshListInternal() {
		setExportExcel(false);

		List<ContadoresLiquidaciones> contadorList = liquidacionesBo.buscarContadorLiquidacion(contadorLiquidacionesPantalla.getProyecto(),paginationData);
		
		contadorLiquidacionesPantalla.setContadorList(contadorList);
	}

	@Override
	public void refrescarListaExcel() {
		
		setExportExcel(true);
		List<ContadoresLiquidaciones> contadorList = liquidacionesBo.buscarContadorLiquidacion(contadorLiquidacionesPantalla.getProyecto(),paginationData);		
		contadorLiquidacionesPantalla.setContadorList(contadorList);

	}

	@Override
	public void setDataTableList(List<?> dataTableList) {
		contadorLiquidacionesPantalla.setContadorList((List<ContadoresLiquidaciones>)dataTableList);
	}


	public ContadorLiquidacionesPantalla getContadorLiquidacionesPantalla() {
		return contadorLiquidacionesPantalla;
	}

	public void setContadorLiquidacionesPantalla(
			ContadorLiquidacionesPantalla contadorLiquidacionesPantalla) {
		this.contadorLiquidacionesPantalla = contadorLiquidacionesPantalla;
	}

	public void salir() {
			Conversation conversacion = Conversation.instance();
			//Volvemos a la anterior conversación
			if(conversacion.isNested()){
				conversacion.redirectToParent();
			} else {
				redirectToURL("/home.seam");
				conversacion.endAndRedirect();
			}
		}

	public LiquidacionesBo getLiquidacionesBo() {
		return liquidacionesBo;
	}

	public void setLiquidacionesBo(LiquidacionesBo liquidacionesBo) {
		this.liquidacionesBo = liquidacionesBo;
	}
			

}
