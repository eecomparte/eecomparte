package com.atosorigin.deri.colat.contadorLiquidaciones.screen;

import java.util.List;

import org.jboss.seam.ScopeType;
import org.jboss.seam.annotations.Name;
import org.jboss.seam.annotations.Out;
import org.jboss.seam.annotations.Scope;
import org.jboss.seam.annotations.datamodel.DataModel;
import org.jboss.seam.annotations.datamodel.DataModelSelection;

import com.atosorigin.deri.model.colat.ContadoresLiquidaciones;

/**
 *  Contiene los datos de pantalla necesarios para el mantenimiento de contrapartidas liquidacion.
 */

@Name("contadorLiquidacionesPantalla")
@Scope(ScopeType.CONVERSATION)
public class ContadorLiquidacionesPantalla {


	protected String proyecto;
	
	@DataModel(value="listaDtContadoresLiquidaciones")
	List<ContadoresLiquidaciones> contadorList;
	
	@DataModelSelection(value="listaDtContadoresLiquidaciones")
	@Out(required=false)
	protected ContadoresLiquidaciones contadorListSelect;


	public String getProyecto() {
		return proyecto;
	}

	public void setProyecto(String proyecto) {
		this.proyecto = proyecto;
	}

	public List<ContadoresLiquidaciones> getContadorList() {
		return contadorList;
	}

	public void setContadorList(List<ContadoresLiquidaciones> contadorList) {
		this.contadorList = contadorList;
	}

	public ContadoresLiquidaciones getContadorListSelect() {
		return contadorListSelect;
	}

	public void setContadorListSelect(ContadoresLiquidaciones contadorListSelect) {
		this.contadorListSelect = contadorListSelect;
	}
	

}
