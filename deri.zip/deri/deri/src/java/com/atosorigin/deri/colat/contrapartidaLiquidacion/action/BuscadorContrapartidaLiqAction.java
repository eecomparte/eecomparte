package com.atosorigin.deri.colat.contrapartidaLiquidacion.action;

import java.util.List;

import org.jboss.seam.ScopeType;
import org.jboss.seam.annotations.In;
import org.jboss.seam.annotations.Name;
import org.jboss.seam.annotations.Scope;

import com.atosorigin.common.action.PaginatedListAction;
import com.atosorigin.common.formvalidator.FormValidator;
import com.atosorigin.deri.colat.contrapartidaLiquidacion.screen.BuscadorContrapartidaLiqPantalla;
import com.atosorigin.deri.colat.contrapartidasLiquidacion.business.ContrapartidaLiquidacionBo;
import com.atosorigin.deri.model.colat.ContrapartidaCargaCto;

/**
 * Clase que actúa de action listener para el caso de uso de busqueda de contrapartidas de cargacto.
 */
@Name("buscadorContrapartidaLiqAction")
@Scope(ScopeType.CONVERSATION)
@FormValidator
public class BuscadorContrapartidaLiqAction extends PaginatedListAction{

	/**
	 * Inyección del bean de Spring "ContrapartidaLiquidacionBo" que contiene los métodos de negocio
	 * para la búsqueda de contrapartidas .
	 */
	@In(value="#{contrapartidaLiquidacionBo}")
	ContrapartidaLiquidacionBo contrapartidaLiquidacionBo;


	/**
	 * Inyección del screen bean que contiene los datos de pantalla del caso de uso
	 * mantenimiento de tipos de contrapartidas.
	 */
	@In(create=true)
	protected BuscadorContrapartidaLiqPantalla buscadorContrapartidaLiqPantalla;

	public void buscaContrapa(){
		setPrimerAcceso(true);
		paginationData.reset();
		buscadorContrapartidaLiqPantalla.setContrapartidaList(null);
	}
	/**
	 * Actualiza la lista del grid de tipos de contrapartidas.
	 * 
	 */
	public void buscar() {
		paginationData.reset();
		refrescarLista();
		setPrimerAcceso(false);
	}

	//Métodos necesarios para pantallas con grids.
	//Es necesario implementar estos métodos abstractos de PaginatedListAction
	@Override
	public List<ContrapartidaCargaCto> getDataTableList() {
		return buscadorContrapartidaLiqPantalla.getContrapartidaList();
	}

	@Override
	@SuppressWarnings("unchecked")
	public void setDataTableList(List<?> dataTableList) {
		buscadorContrapartidaLiqPantalla.setContrapartidaList((List<ContrapartidaCargaCto>)dataTableList);
	}

	@SuppressWarnings("unchecked")
	@Override
	protected void refreshListInternal() {
		List ql = (List)contrapartidaLiquidacionBo.buscarContrapartidasCargaCto(buscadorContrapartidaLiqPantalla.getCodigo(), buscadorContrapartidaLiqPantalla.getDescripcion(), paginationData);
		buscadorContrapartidaLiqPantalla.setContrapartidaList(ql);
	}

	@SuppressWarnings("unchecked")
	@Override
	public void refrescarListaExcel() {
		List ql = (List)contrapartidaLiquidacionBo.buscarContrapartidasCargaCto(buscadorContrapartidaLiqPantalla.getCodigo(), buscadorContrapartidaLiqPantalla.getDescripcion(), paginationData.getPaginationDataForExcel());	

		buscadorContrapartidaLiqPantalla.setContrapartidaList(ql);
	}	
	
	public String quitaComillas(String textConComillas){
		return textConComillas.replaceAll("'", "\\\\'");
	}
	
}
