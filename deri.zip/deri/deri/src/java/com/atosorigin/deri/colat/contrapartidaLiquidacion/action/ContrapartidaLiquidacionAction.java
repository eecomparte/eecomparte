package com.atosorigin.deri.colat.contrapartidaLiquidacion.action;

import java.util.Date;
import java.util.List;

import org.jboss.seam.ScopeType;
import org.jboss.seam.annotations.In;
import org.jboss.seam.annotations.Name;
import org.jboss.seam.annotations.Out;
import org.jboss.seam.annotations.Scope;
import org.jboss.seam.international.StatusMessage.Severity;

import com.atosorigin.common.action.ModoPantalla;
import com.atosorigin.common.action.PaginatedListAction;
import com.atosorigin.common.constantes.Constantes;
import com.atosorigin.common.formvalidator.FormValidator;
import com.atosorigin.common.utils.GenericUtils;
import com.atosorigin.deri.colat.contrapartidaLiquidacion.screen.ContrapartidaLiquidacionPantalla;
import com.atosorigin.deri.colat.contrapartidasLiquidacion.business.ContrapartidaLiquidacionBo;
import com.atosorigin.deri.model.colat.ContrapartidaLiquidacion;
import com.atosorigin.deri.model.colat.ContrapartidaLiquidacionId;
import com.atosorigin.deri.model.contrapartida.Contrapartida;
import com.atosorigin.deri.model.parametrizacion.ParamCobroPago;
import com.atosorigin.deri.util.MessageBoxAction;
import com.atosorigin.deri.util.MsgBoxAction;

/**
 * Clase action listener para el caso de uso de contrapartidas liquidación
 */
@Name("contrapartidaLiquidacionAction")
@Scope(ScopeType.CONVERSATION)
@FormValidator
public class ContrapartidaLiquidacionAction extends PaginatedListAction {

	private static final long serialVersionUID = -4996253373443421408L;

	@In(value="#{contrapartidaLiquidacionBo}")
	ContrapartidaLiquidacionBo contrapartidaLiquidacionBo;
	
	@In(create=true)
	ContrapartidaLiquidacionPantalla contrapartidaLiquidacionPantalla;

	@In(create = true)
	MsgBoxAction msgBoxAction;
	
	@Out(required = false, value = "contrapartidaLiquidacionMessageBoxAction")
	private MessageBoxAction messageBoxContrapartidaLiquidacionAction;
	
	public static final String PRODUCTO_COLAT= "756000";

	private Boolean primeraEjecucionInit=null;
	
	public void buscar(){
		setPrimerAcceso(false);
		paginationData.reset();
		refrescarLista();		
	}
	
	public String guardar(){
		if(ModoPantalla.CREACION.equals(getModoPantalla())){
			if(GenericUtils.isNullOrBlank(contrapartidaLiquidacionBo.cargar(contrapartidaLiquidacionPantalla.getContrapartidaLiquidacionSeleccionada().getId()))){
				contrapartidaLiquidacionBo.alta(contrapartidaLiquidacionPantalla.getContrapartidaLiquidacionSeleccionada());
				statusMessages.add(Severity.INFO, "#{messages['contrapartidas.liquidacion.altacorrecta']}", Constantes.DEFAULT_MESSAGE_TEMPLATE);
			}else{
				statusMessages.add(Severity.ERROR, "#{messages['contrapartidas.liquidacion.alta.existente']}", Constantes.DEFAULT_MESSAGE_TEMPLATE);
				return Constantes.CONSTANTE_FAIL;
			}
		}if(ModoPantalla.EDICION.equals(getModoPantalla())){
			contrapartidaLiquidacionBo.modifica(contrapartidaLiquidacionPantalla.getContrapartidaLiquidacionSeleccionada());
			statusMessages.add(Severity.INFO, "#{messages['contrapartidas.liquidacion.modificacioncorrecta']}", Constantes.DEFAULT_MESSAGE_TEMPLATE);
		}
		refreshListInternal();
		return Constantes.CONSTANTE_SUCCESS;
	}
	
	public void nuevo(){
		ContrapartidaLiquidacion contrapartidaLiquidacion = new ContrapartidaLiquidacion(new ContrapartidaLiquidacionId());
		//Sólo para producto COLAT
		contrapartidaLiquidacion.getId().setProducto(PRODUCTO_COLAT);
		contrapartidaLiquidacionPantalla.setContrapartidaLiquidacionSeleccionada(contrapartidaLiquidacion);
		setModoPantalla(ModoPantalla.CREACION);
	}
	
	public void borrar(){
		contrapartidaLiquidacionBo.baja(contrapartidaLiquidacionPantalla.getContrapartidaLiquidacionSeleccionada());
		statusMessages.add(Severity.INFO, "#{messages['contrapartidas.liquidacion.borradoCorrecto']}", Constantes.DEFAULT_MESSAGE_TEMPLATE);	
		refrescarLista();
	}
	
	@Override
	public List<?> getDataTableList() {
		
		return contrapartidaLiquidacionPantalla.getListaContrapartidasLiquidacion();
	}
	
	public void ver(){
		contrapartidaLiquidacionPantalla.setContrapartidaLiquidacionSeleccionada(contrapartidaLiquidacionPantalla.getContrapartidaLiquidacionSeleccionada());
		setModoPantalla(ModoPantalla.INSPECCION);
	}

	@Override
	protected void refreshListInternal() {
		setExportExcel(false);
		Date fechaLiquidacion = null;
		String contrapartida = null;
		Date fechaProceso = null;
	
		if(!GenericUtils.isNullOrBlank(contrapartidaLiquidacionPantalla.getFechaLiquidacionSel())){
			fechaLiquidacion = contrapartidaLiquidacionPantalla.getFechaLiquidacionSel();
		}
		if(!GenericUtils.isNullOrBlank(contrapartidaLiquidacionPantalla.getContrapartidaSel())){
			contrapartida = contrapartidaLiquidacionPantalla.getContrapartidaSel();
		}
		if(!GenericUtils.isNullOrBlank(contrapartidaLiquidacionPantalla.getFechaProcesoSel())){
			fechaProceso = contrapartidaLiquidacionPantalla.getFechaProcesoSel();
		}
		List<ContrapartidaLiquidacion> listaContrapartidaLiquidacion = contrapartidaLiquidacionBo
				.buscarContrapartidasLiquidacion(fechaLiquidacion, contrapartida, fechaProceso, paginationData);
		
		contrapartidaLiquidacionPantalla.setListaContrapartidasLiquidacion(listaContrapartidaLiquidacion);
	}

	@Override
	public void refrescarListaExcel() {
		
		setExportExcel(true);
		Date fechaLiquidacion = null;
		String contrapartida = null;
		Date fechaProceso = null;
	
		if(!GenericUtils.isNullOrBlank(contrapartidaLiquidacionPantalla.getFechaLiquidacionSel())){
			fechaLiquidacion = contrapartidaLiquidacionPantalla.getFechaLiquidacionSel();
		}
		if(!GenericUtils.isNullOrBlank(contrapartidaLiquidacionPantalla.getContrapartidaSel())){
			contrapartida = contrapartidaLiquidacionPantalla.getContrapartidaSel();
		}
		if(!GenericUtils.isNullOrBlank(contrapartidaLiquidacionPantalla.getFechaProcesoSel())){
			fechaProceso = contrapartidaLiquidacionPantalla.getFechaProcesoSel();
		}
		List<ContrapartidaLiquidacion> listaContrapartidaLiquidacion = contrapartidaLiquidacionBo
				.buscarContrapartidasLiquidacion(fechaLiquidacion, contrapartida, fechaProceso, paginationData.getPaginationDataForExcel());
		
		contrapartidaLiquidacionPantalla.setListaContrapartidasLiquidacion(listaContrapartidaLiquidacion);

	}

	@Override
	public void setDataTableList(List<?> dataTableList) {
		contrapartidaLiquidacionPantalla.setListaContrapartidasLiquidacion((List<ContrapartidaLiquidacion>)dataTableList);
	}

	
	public ContrapartidaLiquidacionBo getContrapartidaLiquidacionBo() {
		return contrapartidaLiquidacionBo;
	}

	public void setContrapartidaLiquidacionBo(
			ContrapartidaLiquidacionBo contrapartidaLiquidacionBo) {
		this.contrapartidaLiquidacionBo = contrapartidaLiquidacionBo;
	}

	public ContrapartidaLiquidacionPantalla getContrapartidaLiquidacionPantalla() {
		return contrapartidaLiquidacionPantalla;
	}

	public void setContrapartidaLiquidacionPantalla(
			ContrapartidaLiquidacionPantalla contrapartidaLiquidacionPantalla) {
		this.contrapartidaLiquidacionPantalla = contrapartidaLiquidacionPantalla;
	}

	public void init(){
		primeraEjecucionInit = null;
		if(null==messageBoxContrapartidaLiquidacionAction){
			messageBoxContrapartidaLiquidacionAction = new MessageBoxAction();
		}
	}
	
	public void initDetalle(){
		if (primeraEjecucionInit == null) {
			primeraEjecucionInit=true;
		} 
		else{
			primeraEjecucionInit = false;
		}
		
		if(primeraEjecucionInit){
		if(null!=contrapartidaLiquidacionPantalla.getContrapartidaLiquidacionSeleccionada() && null!=contrapartidaLiquidacionPantalla.getContrapartidaLiquidacionSeleccionada().getId()){
			String idContrapartida = contrapartidaLiquidacionPantalla.getContrapartidaLiquidacionSeleccionada().getId().getContrapa();
			if (!GenericUtils.isNullOrBlank(idContrapartida)){
				 Contrapartida contrapObtenida2 = contrapartidaLiquidacionBo.cargarContrapartida(idContrapartida.toUpperCase());	
				if (null!=contrapObtenida2 && !GenericUtils.isNullOrBlank(contrapObtenida2.getIndBloqueo()) && "S".equalsIgnoreCase(contrapObtenida2.getIndBloqueo())){
					messageBoxContrapartidaLiquidacionAction.init("contrapartidas.messages.contrapartida.bloqueada.texto", "contrapartidaLiquidacionAction.voidFunction()", null,"messageBoxPanelContrapa");
				}
			}
		}
		}
	}

	public void voidFunction(){
		msgBoxAction.voidFunction();
	}
	
	/**
	 * Mostrar PopUp cuando una contrapartida está bloqueada (no bloqueante)
	 */
	public void onVerificarContrapartidaBloqueada() {
		String contrapartida = contrapartidaLiquidacionPantalla.getContrapartidaSel();
		if (!GenericUtils.isNullOrBlank(contrapartida)){
			 Contrapartida contrapObtenida2 = contrapartidaLiquidacionBo.cargarContrapartida(contrapartida.toUpperCase());	
			if (null!=contrapObtenida2 && !GenericUtils.isNullOrBlank(contrapObtenida2.getIndBloqueo()) && "S".equalsIgnoreCase(contrapObtenida2.getIndBloqueo())){
				messageBoxContrapartidaLiquidacionAction.init("contrapartidas.messages.contrapartida.bloqueada.texto", "contrapartidaLiquidacionAction.voidFunction()", null,"messageBoxPanelContrapa");
			}
		}
	}
	
	public void onVerificarContrapartidaBloqueadaNueva() {
		if(null!=contrapartidaLiquidacionPantalla.getContrapartidaLiquidacionSeleccionada() && null!=contrapartidaLiquidacionPantalla.getContrapartidaLiquidacionSeleccionada().getId()){
			String contrapartida = contrapartidaLiquidacionPantalla.getContrapartidaLiquidacionSeleccionada().getId().getContrapa();
			if (!GenericUtils.isNullOrBlank(contrapartida)){
				 Contrapartida contrapObtenida2 = contrapartidaLiquidacionBo.cargarContrapartida(contrapartida.toUpperCase());	
				if (null!=contrapObtenida2 && !GenericUtils.isNullOrBlank(contrapObtenida2.getIndBloqueo()) && "S".equalsIgnoreCase(contrapObtenida2.getIndBloqueo())){
					messageBoxContrapartidaLiquidacionAction.init("contrapartidas.messages.contrapartida.bloqueada.texto", "contrapartidaLiquidacionAction.voidFunction()", null,"messageBoxPanelContrapa");
				}
			}
		}
	}
	
	public String getRowClasses(){
		StringBuilder builder = new StringBuilder();
		int i=0;
		for (ContrapartidaLiquidacion contraLiq : contrapartidaLiquidacionPantalla.getListaContrapartidasLiquidacion()) {
			Contrapartida contrapartida = null;
			String idContrapartida = contraLiq.getId().getContrapa();
			contrapartida = contrapartidaLiquidacionBo.cargarContrapartida(idContrapartida.toUpperCase());	

			if(i>0){
				builder.append(",");
			}
			
			if(i%2==0){
				if(null!=contrapartida && !GenericUtils.isNullOrBlank(contrapartida.getIndBloqueo()) && "S".equalsIgnoreCase(contrapartida.getIndBloqueo())){
					builder.append("oddRowRed");
				}
				else{
					builder.append("oddRow");
				}
			}
			else{
				if(null!=contrapartida && !GenericUtils.isNullOrBlank(contrapartida.getIndBloqueo()) && "S".equalsIgnoreCase(contrapartida.getIndBloqueo())){
					builder.append("evenRowRed");
				}
				else{
					builder.append("evenRow");
				}
			}
			i++;
			contrapartida = null;
		}
		return builder.toString();
	}

}
