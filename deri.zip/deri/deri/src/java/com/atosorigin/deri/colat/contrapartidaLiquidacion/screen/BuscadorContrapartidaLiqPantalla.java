package com.atosorigin.deri.colat.contrapartidaLiquidacion.screen;

import java.util.List;

import org.jboss.seam.ScopeType;
import org.jboss.seam.annotations.Name;
import org.jboss.seam.annotations.Out;
import org.jboss.seam.annotations.Scope;
import org.jboss.seam.annotations.datamodel.DataModel;
import org.jboss.seam.annotations.datamodel.DataModelSelection;

import com.atosorigin.deri.model.colat.ContrapartidaCargaCto;


/**
 *  Contiene los datos de pantalla necesarios para el caso de uso mantenimiento de tipos de contrapartidas.
 */
@Name("buscadorContrapartidaLiqPantalla")
@Scope(ScopeType.CONVERSATION)
public class BuscadorContrapartidaLiqPantalla {

	/** Descripcion. Criterio de búsqueda de tipos de contrapartidas  */
	protected String descripcion;
	
	protected String codigo;
	
	/** Lista de datos para el grid. */
	@DataModel(value ="listaBuscadorContrapartidasLiq")
	protected List<ContrapartidaCargaCto> contrapartidaList;
	
	/** Tipo de contrapartida seleccionado en el grid */
	@DataModelSelection(value ="listaBuscadorContrapartidasLiq")
    @Out(required=false)
    protected ContrapartidaCargaCto contrapartida;

	/** Número de resultados totales para los criterios de búsqueda. */
	protected Long numFilas = 0L;
	
	public String getDescripcion() {
		return descripcion;
	}

	public void setDescripcion(String descripcion) {
		this.descripcion = descripcion;
	}

	/**
	 * Obtiene la Lista de datos para el grid.
	 * 
	 * @return la lista de tipos de contrapartidas que mostrará el grid de resultados de la búsqueda.
	 */
	public List<ContrapartidaCargaCto> getContrapartidaList() {
		return contrapartidaList;
	}
	
	/**
	 * Establece la Lista de datos para el grid.
	 * 
	 * @param tipoContrapartidaList la lista de tipos de contrapartidas del grid.
	 */
	public void setContrapartidaList(List<ContrapartidaCargaCto> contrapartidaList) {
		this.contrapartidaList = contrapartidaList;
	}

	public ContrapartidaCargaCto getContrapartida() {
		return contrapartida;
	}

	public void setContrapartida(ContrapartidaCargaCto contrapartida) {
		this.contrapartida = contrapartida;
	}

	public Long getNumFilas() {
		return numFilas;
	}

	public void setNumFilas(Long numFilas) {
		this.numFilas = numFilas;
	}

	public String getCodigo() {
		return codigo;
	}

	public void setCodigo(String codigo) {
		this.codigo = codigo;
	}

}
