package com.atosorigin.deri.colat.contrapartidaLiquidacion.screen;

import java.util.Date;
import java.util.List;

import org.jboss.seam.ScopeType;
import org.jboss.seam.annotations.Name;
import org.jboss.seam.annotations.Out;
import org.jboss.seam.annotations.Scope;
import org.jboss.seam.annotations.datamodel.DataModel;
import org.jboss.seam.annotations.datamodel.DataModelSelection;

import com.atosorigin.deri.model.colat.ContrapartidaLiquidacion;

/**
 *  Contiene los datos de pantalla necesarios para el mantenimiento de contrapartidas liquidacion.
 */

@Name("contrapartidaLiquidacionPantalla")
@Scope(ScopeType.CONVERSATION)
public class ContrapartidaLiquidacionPantalla {

	protected Date fechaLiquidacionSel;
	
	protected String contrapartidaSel;
	
	protected Date fechaProcesoSel;
	
	protected String idContrapartida;
	
	@DataModel(value="listaDtContrapartidaLiquidacion")
	List<ContrapartidaLiquidacion> listaContrapartidasLiquidacion;
	
	@DataModelSelection(value="listaDtContrapartidaLiquidacion")
	@Out(required=false)
	protected ContrapartidaLiquidacion contrapartidaLiquidacionSeleccionada;

	public Date getFechaLiquidacionSel() {
		return fechaLiquidacionSel;
	}

	public void setFechaLiquidacionSel(Date fechaLiquidacionSel) {
		this.fechaLiquidacionSel = fechaLiquidacionSel;
	}

	public String getContrapartidaSel() {
		return contrapartidaSel;
	}

	public void setContrapartidaSel(String contrapartidaSel) {
		this.contrapartidaSel = contrapartidaSel;
	}

	public Date getFechaProcesoSel() {
		return fechaProcesoSel;
	}

	public void setFechaProcesoSel(Date fechaProcesoSel) {
		this.fechaProcesoSel = fechaProcesoSel;
	}

	public List<ContrapartidaLiquidacion> getListaContrapartidasLiquidacion() {
		return listaContrapartidasLiquidacion;
	}

	public void setListaContrapartidasLiquidacion(
			List<ContrapartidaLiquidacion> listaContrapartidasLiquidacion) {
		this.listaContrapartidasLiquidacion = listaContrapartidasLiquidacion;
	}

	public ContrapartidaLiquidacion getContrapartidaLiquidacionSeleccionada() {
		return contrapartidaLiquidacionSeleccionada;
	}

	public void setContrapartidaLiquidacionSeleccionada(
			ContrapartidaLiquidacion contrapartidaLiquidacionSeleccionada) {
		this.contrapartidaLiquidacionSeleccionada = contrapartidaLiquidacionSeleccionada;
	}

	public String getIdContrapartida() {
		return idContrapartida;
	}

	public void setIdContrapartida(String idContrapartida) {
		this.idContrapartida = idContrapartida;
	}
	

}
