package com.atosorigin.deri.colat.contrapartidaRepo.action;

import java.util.ArrayList;
import java.util.List;

import org.jboss.seam.ScopeType;
import org.jboss.seam.annotations.In;
import org.jboss.seam.annotations.Name;
import org.jboss.seam.annotations.Out;
import org.jboss.seam.annotations.Scope;
import org.jboss.seam.international.StatusMessage.Severity;

import com.atosorigin.common.action.ModoPantalla;
import com.atosorigin.common.action.PaginatedListAction;
import com.atosorigin.common.constantes.Constantes;
import com.atosorigin.common.formvalidator.FormValidator;
import com.atosorigin.common.utils.GenericUtils;
import com.atosorigin.deri.colat.contrapartidaRepo.screen.ContrapartidaRepoPantalla;
import com.atosorigin.deri.colat.contrapartidasRepo.business.ContrapartidasRepoBo;
import com.atosorigin.deri.model.colat.ContrapartidaRepo;
import com.atosorigin.deri.model.contrapartida.Contrapartida;
import com.atosorigin.deri.model.gestionoperaciones.ListaSuscripciones;
import com.atosorigin.deri.util.MessageBoxAction;
import com.atosorigin.deri.util.MsgBoxAction;

/**
 * Clase action listener para el caso de uso de contrapartidas repo
 */
@Name("contrapartidasRepoAction")
@Scope(ScopeType.CONVERSATION)
@FormValidator
public class ContrapartidasRepoAction extends PaginatedListAction {

	@In(value="#{contrapartidasRepoBo}")
	ContrapartidasRepoBo contrapartidasRepoBo;
	
	@In(create=true)
	ContrapartidaRepoPantalla contrapartidaRepoPantalla;
	
	public void buscar(){
		//String pr = contrapartidaRepoPantalla.getProyecto();
		setPrimerAcceso(false);
		paginationData.reset();
		refrescarLista();		
	}
	
	@In(create = true)
	MsgBoxAction msgBoxAction;
	
	@Out(required = false, value = "contrapartidasRepoMessageBoxAction")
	private MessageBoxAction messageBoxContrapartidasRepoAction;
	
	private Boolean primeraEjecucionInit=null;

	public String obtenerDescProducto(String idProd){
		return contrapartidasRepoBo.obtenerDescProducto(idProd);
	}
	
	public String guardar(){
		if(ModoPantalla.CREACION.equals(getModoPantalla())){
			ContrapartidaRepo contrapa = contrapartidaRepoPantalla.getContrapartidaRepo();
			if(contrapartidasRepoBo.searchByUniqueIndex(contrapa.getProducto(),contrapa.getContrapaOriginal(),contrapa.getContrapaAInformar()).size()>0){
				statusMessages.add(Severity.ERROR, "#{messages['contrapartidas.repo.erroraltamodif']}", Constantes.DEFAULT_MESSAGE_TEMPLATE);
				return Constantes.CONSTANTE_FAIL;
			}else{
				contrapartidasRepoBo.alta(contrapartidaRepoPantalla.getContrapartidaRepo());
				statusMessages.add(Severity.INFO, "#{messages['contrapartidas.repo.altacorrecta']}", Constantes.DEFAULT_MESSAGE_TEMPLATE);
			}
		}if(ModoPantalla.EDICION.equals(getModoPantalla())){
			ContrapartidaRepo contrapa = contrapartidaRepoPantalla.getContrapartidaRepo();
			List<ContrapartidaRepo> lista = contrapartidasRepoBo.searchByUniqueIndex(contrapa.getProducto(),contrapa.getContrapaOriginal(),contrapa.getContrapaAInformar());
			if(lista.size()>1 || (lista.size()==1 &&((ContrapartidaRepo)lista.get(0)).getSecuenci().longValue()!=contrapa.getSecuenci().longValue())){
				statusMessages.add(Severity.ERROR, "#{messages['contrapartidas.repo.erroraltamodif']}", Constantes.DEFAULT_MESSAGE_TEMPLATE);
				contrapartidasRepoBo.cargar(contrapa.getSecuenci());
				return Constantes.CONSTANTE_FAIL;
			}else{
				contrapartidasRepoBo.modifica(contrapartidaRepoPantalla.getContrapartidaRepo());
				statusMessages.add(Severity.INFO, "#{messages['contrapartidas.repo.modificacioncorrecta']}", Constantes.DEFAULT_MESSAGE_TEMPLATE);
			}
		}
		refrescarLista();
		return Constantes.CONSTANTE_SUCCESS;
	}
	
	public void nuevo(){
		contrapartidaRepoPantalla.setContrapartidaRepo(new ContrapartidaRepo());
		setModoPantalla(ModoPantalla.CREACION);
	}
	
	public void editar(){
		ContrapartidaRepo contrapartidaRepo = contrapartidasRepoBo.cargar(contrapartidaRepoPantalla.getContrapartidaRepoSeleccionada().getSecuenci());
//		contrapartidaRepoPantalla.getContrapartidaRepo().setContrapaAInformar(null);
		contrapartidaRepoPantalla.setContrapartidaRepo(contrapartidaRepo);

		setModoPantalla(ModoPantalla.EDICION);
	}
	

	public void borrar(){
		contrapartidasRepoBo.baja(contrapartidaRepoPantalla.getContrapartidaRepo());
		statusMessages.add(Severity.INFO, "#{messages['contrapartidas.repo.borradoCorrecto']}", Constantes.DEFAULT_MESSAGE_TEMPLATE);	
		refrescarLista();
	}
	
	@Override
	public List<?> getDataTableList() {
		
		return contrapartidaRepoPantalla.getListaContrapartidasRepo();
	}
	
	public void ver(){
		ContrapartidaRepo contrapartidaRepo = contrapartidasRepoBo.cargar(contrapartidaRepoPantalla.getContrapartidaRepoSeleccionada().getSecuenci());
//		contrapartidaRepoPantalla.getContrapartidaRepo().setContrapaAInformar(null);
		contrapartidaRepoPantalla.setContrapartidaRepo(contrapartidaRepo);
		setModoPantalla(ModoPantalla.INSPECCION);
	}

	@Override
	protected void refreshListInternal() {
		String prod = null;
		setExportExcel(false);
		String contrapartida = null;
		
		if(!GenericUtils.isNullOrBlank(contrapartidaRepoPantalla.getProductoBusqueda())){
			prod = contrapartidaRepoPantalla.getProductoBusqueda().getCodigo();
		}
		if(!GenericUtils.isNullOrBlank(contrapartidaRepoPantalla.getIdContrapartida())){
			contrapartida = contrapartidaRepoPantalla.getIdContrapartida();
		}
		List<ContrapartidaRepo> listaContrapartidaRepo = new ArrayList<ContrapartidaRepo>(); 
		listaContrapartidaRepo =  contrapartidasRepoBo.buscarContrapartidasRepo(prod, 
						contrapartida,
						paginationData);
		
		if (contrapartidaRepoPantalla.getListaContrapartidasRepo()!=null) {
			contrapartidaRepoPantalla.getListaContrapartidasRepo().clear();
			contrapartidaRepoPantalla.getListaContrapartidasRepo().addAll(listaContrapartidaRepo);
		}else{
			contrapartidaRepoPantalla.setListaContrapartidasRepo(new ArrayList<ContrapartidaRepo>(listaContrapartidaRepo));	
		}
		contrapartidaRepoPantalla.setContrapartidaRepoSeleccionada(null);
		contrapartidaRepoPantalla.setContrapartidaRepo(null);
		
	}

	@Override
	public void refrescarListaExcel() {
		
		setExportExcel(true);
		String prod = null;
		String contrapartida = null;
		if(!GenericUtils.isNullOrBlank(contrapartidaRepoPantalla.getProductoBusqueda())){
			prod = contrapartidaRepoPantalla.getProductoBusqueda().getCodigo();
		}
		if(!GenericUtils.isNullOrBlank(contrapartidaRepoPantalla.getIdContrapartida())){
			contrapartida = contrapartidaRepoPantalla.getIdContrapartida();
		}
		List<ContrapartidaRepo> listaContRepo = contrapartidasRepoBo
				.buscarContrapartidasRepo(prod, 
						contrapartida,
						paginationData.getPaginationDataForExcel());
		
		
		
		if (contrapartidaRepoPantalla.getListaContrapartidasRepo()!=null) {
			contrapartidaRepoPantalla.getListaContrapartidasRepo().clear();
			contrapartidaRepoPantalla.getListaContrapartidasRepo().addAll(listaContRepo);
		}else{
			contrapartidaRepoPantalla.setListaContrapartidasRepo(new ArrayList<ContrapartidaRepo>(listaContRepo));	
		}
		contrapartidaRepoPantalla.setContrapartidaRepoSeleccionada(null);
		contrapartidaRepoPantalla.setContrapartidaRepo(null);
		
	}

	@Override
	public void setDataTableList(List<?> dataTableList) {
		contrapartidaRepoPantalla.setListaContrapartidasRepo((List<ContrapartidaRepo>)dataTableList);
		
	}

	public ContrapartidasRepoBo getContrapartidasRepoBo() {
		return contrapartidasRepoBo;
	}

	public void setContrapartidasRepoBo(ContrapartidasRepoBo contrapartidasRepoBo) {
		this.contrapartidasRepoBo = contrapartidasRepoBo;
	}

	public ContrapartidaRepoPantalla getContrapartidaRepoPantalla() {
		return contrapartidaRepoPantalla;
	}

	public void setContrapartidaRepoPantalla(
			ContrapartidaRepoPantalla contrapartidaRepoPantalla) {
		this.contrapartidaRepoPantalla = contrapartidaRepoPantalla;
	}
	
	public void abrirPopUP(String queContrapartida){
		if ("1".equals(queContrapartida)){
			contrapartidaRepoPantalla.setQueContrapartida("contrapartidaRepoDetalleForm:contrapartidaOId:idContrapaOriginal");
		}
		else{
			contrapartidaRepoPantalla.setQueContrapartida("contrapartidaRepoDetalleForm:contrapartidaIId:idContrapaAInformar");
		} 
	}

	public void salir() {
		refrescarLista();
		super.salir();
	}

	public void init(){
		primeraEjecucionInit = null;
		
		if(null==messageBoxContrapartidasRepoAction){
			messageBoxContrapartidasRepoAction = new MessageBoxAction();
		}
	}
	
	public void initRepoDetalle(){
		if (primeraEjecucionInit == null) {
			primeraEjecucionInit=true;
		} 
		else{
			primeraEjecucionInit = false;
		}
		
		if(null==messageBoxContrapartidasRepoAction){
			messageBoxContrapartidasRepoAction = new MessageBoxAction();
		}
		
		if(primeraEjecucionInit){
			if(null!=contrapartidaRepoPantalla.getContrapartidaRepo() && null!=contrapartidaRepoPantalla.getContrapartidaRepo().getContrapaOriginal()){
				String idContrapartida = contrapartidaRepoPantalla.getContrapartidaRepo().getContrapaOriginal();
				if(null!=idContrapartida && idContrapartida.trim().length()>0){
					Contrapartida contrapartida = contrapartidasRepoBo.cargarContrapartida(idContrapartida.toUpperCase());	
					if (null!=contrapartida && !GenericUtils.isNullOrBlank(contrapartida.getIndBloqueo()) && "S".equalsIgnoreCase(contrapartida.getIndBloqueo())){
						lanzarPopUpContrapartidaBloqueada();
					}
				}
			}
		}
	}

	public void voidFunction(){
		msgBoxAction.voidFunction();
	}
	
	/**
	 * Mostrar PopUp cuando una contrapartida está bloqueada (no bloqueante)
	 */
	public void onVerificarContrapartidaBloqueada() {
		String contrapartida = contrapartidaRepoPantalla.getIdContrapartida();
		if (!GenericUtils.isNullOrBlank(contrapartida)){
			 Contrapartida contrapObtenida2 = contrapartidasRepoBo.cargarContrapartida(contrapartida.toUpperCase());	
			if (null!=contrapObtenida2 && !GenericUtils.isNullOrBlank(contrapObtenida2.getIndBloqueo()) && "S".equalsIgnoreCase(contrapObtenida2.getIndBloqueo())){
				lanzarPopUpContrapartidaBloqueada();
			}
		}
	}
	
	public void onVerificarContrapartidaBloqueadaNuevaOriginal() {
		String contrapartida = contrapartidaRepoPantalla.getContrapartidaRepo().getContrapaOriginal();
		if (!GenericUtils.isNullOrBlank(contrapartida)){
			 Contrapartida contrapObtenida2 = contrapartidasRepoBo.cargarContrapartida(contrapartida.toUpperCase());	
			if (null!=contrapObtenida2 && !GenericUtils.isNullOrBlank(contrapObtenida2.getIndBloqueo()) && "S".equalsIgnoreCase(contrapObtenida2.getIndBloqueo())){
				lanzarPopUpContrapartidaBloqueada();
			}
		}
	}
	
	public void onVerificarContrapartidaBloqueadaNuevaDestino() {
		String contrapartida = contrapartidaRepoPantalla.getContrapartidaRepo().getContrapaAInformar();
		if (!GenericUtils.isNullOrBlank(contrapartida)){
			 Contrapartida contrapObtenida2 = contrapartidasRepoBo.cargarContrapartida(contrapartida.toUpperCase());	
			if (null!=contrapObtenida2 && !GenericUtils.isNullOrBlank(contrapObtenida2.getIndBloqueo()) && "S".equalsIgnoreCase(contrapObtenida2.getIndBloqueo())){
				lanzarPopUpContrapartidaBloqueada();
			}
		}
	}
	
	private void lanzarPopUpContrapartidaBloqueada(){
		messageBoxContrapartidasRepoAction.init("contrapartidas.messages.contrapartida.bloqueada.texto", "contrapartidasRepoAction.voidFunction()", null,"messageBoxPanelContrapa");
	}
	
	public String getRowClasses(){
		StringBuilder builder = new StringBuilder();
		int i=0;
		for (ContrapartidaRepo contraRepo : contrapartidaRepoPantalla.getListaContrapartidasRepo()) {
			Contrapartida contrapartida = null;
			Boolean bloqueada = false;
			String idContrapartida = contraRepo.getContrapaOriginal();
			
			if(i>0){
				builder.append(",");
			}
			
			contrapartida = (Contrapartida) contrapartidasRepoBo.cargarContrapartida(idContrapartida.toUpperCase());
			if(null!=contrapartida && !GenericUtils.isNullOrBlank(contrapartida.getIndBloqueo()) && "S".equalsIgnoreCase(contrapartida.getIndBloqueo())){
				bloqueada = true;
			}
			else{
				idContrapartida = contraRepo.getContrapaAInformar();
				contrapartida = (Contrapartida) contrapartidasRepoBo.cargarContrapartida(idContrapartida.toUpperCase());
				if(null!=contrapartida && !GenericUtils.isNullOrBlank(contrapartida.getIndBloqueo()) && "S".equalsIgnoreCase(contrapartida.getIndBloqueo())){
					bloqueada = true;
				}
			}
			
			if(i%2==0){
				if(bloqueada){
					builder.append("oddRowRed");
				}
				else{
					builder.append("oddRow");
				}
			}
			else{
				if(bloqueada){
					builder.append("evenRowRed");
				}
				else{
					builder.append("evenRow");
				}
			}
			bloqueada = false;
			i++;
			contrapartida = null;
		}
		return builder.toString();
	}
	
}
