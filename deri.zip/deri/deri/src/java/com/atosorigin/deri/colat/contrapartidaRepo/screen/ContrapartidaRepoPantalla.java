package com.atosorigin.deri.colat.contrapartidaRepo.screen;

import java.util.List;

import org.jboss.seam.ScopeType;
import org.jboss.seam.annotations.Name;
import org.jboss.seam.annotations.Out;
import org.jboss.seam.annotations.Scope;
import org.jboss.seam.annotations.datamodel.DataModel;
import org.jboss.seam.annotations.datamodel.DataModelSelection;

import com.atosorigin.deri.model.colat.ContrapartidaRepo;
import com.atosorigin.deri.model.colat.ProductoContraRepo;

/**
 *  Contiene los datos de pantalla necesarios para el mantenimiento de contrapartidas repo.
 */

@Name("contrapartidaRepoPantalla")
@Scope(ScopeType.CONVERSATION)
public class ContrapartidaRepoPantalla {

	private String proyecto;
	
	protected ProductoContraRepo productoBusqueda;
	
	protected ProductoContraRepo productoSeleccionado;
	
	protected String productoSel;
	
	protected String contrapaOriginalSel;
	
	protected String contrapaAInformarSel;
	
	protected String idContrapartida;
	
	@DataModel(value="listaDtContrapartidasRepo")
	List<ContrapartidaRepo> listaContrapartidasRepo;
	
	@DataModelSelection(value="listaDtContrapartidasRepo")
	protected ContrapartidaRepo contrapartidaRepoSeleccionada;

	//@Out(value="contrapartidaRepo",required=false)
	protected ContrapartidaRepo contrapartidaRepo;
	
	protected String queContrapartida;
	
	public ProductoContraRepo getProductoBusqueda() {
		return productoBusqueda;
	}

	public void setProductoBusqueda(ProductoContraRepo productoBusqueda) {
		this.productoBusqueda = productoBusqueda;
	}

	public String getIdContrapartida() {
		return idContrapartida;
	}

	public void setIdContrapartida(String idContrapartida) {
		this.idContrapartida = idContrapartida;
	}

	public List<ContrapartidaRepo> getListaContrapartidasRepo() {
		return listaContrapartidasRepo;
	}

	public void setListaContrapartidasRepo(
			List<ContrapartidaRepo> listaContrapartidasRepo) {
		this.listaContrapartidasRepo = listaContrapartidasRepo;
	}

	public ContrapartidaRepo getContrapartidaRepoSeleccionada() {
		return contrapartidaRepoSeleccionada;
	}

	public void setContrapartidaRepoSeleccionada(
			ContrapartidaRepo contrapartidaRepoSeleccionada) {
		this.contrapartidaRepoSeleccionada = contrapartidaRepoSeleccionada;
	}

	public String getContrapaOriginalSel() {
		return contrapaOriginalSel;
	}

	public void setContrapaOriginalSel(String contrapaOriginalSel) {
		this.contrapaOriginalSel = contrapaOriginalSel;
	}

	public String getContrapaAInformarSel() {
		return contrapaAInformarSel;
	}

	public void setContrapaAInformarSel(String contrapaAInformarSel) {
		this.contrapaAInformarSel = contrapaAInformarSel;
	}

	public ProductoContraRepo getProductoSeleccionado() {
		return productoSeleccionado;
	}

	public void setProductoSeleccionado(ProductoContraRepo productoSeleccionado) {
		this.productoSeleccionado = productoSeleccionado;
	}

	public String getProductoSel() {
		return productoSel;
	}

	public void setProductoSel(String productoSel) {
		this.productoSel = productoSel;
	}

	public String getQueContrapartida() {
		return queContrapartida;
	}

	public void setQueContrapartida(String queContrapartida) {
		this.queContrapartida = queContrapartida;
	}

	public String getProyecto() {
		return proyecto;
	}

	public void setProyecto(String proyecto) {
		this.proyecto = proyecto;
	}

	public ContrapartidaRepo getContrapartidaRepo() {
		return contrapartidaRepo;
	}

	public void setContrapartidaRepo(ContrapartidaRepo contrapartidaRepo) {
		this.contrapartidaRepo = contrapartidaRepo;
	}

}
