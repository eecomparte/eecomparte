package com.atosorigin.deri.colat.grupoContable.action;

import java.util.List;

import org.jboss.seam.ScopeType;
import org.jboss.seam.annotations.In;
import org.jboss.seam.annotations.Name;
import org.jboss.seam.annotations.Out;
import org.jboss.seam.annotations.Scope;
import org.jboss.seam.international.StatusMessage.Severity;

import com.atosorigin.common.action.ModoPantalla;
import com.atosorigin.common.action.PaginatedListAction;
import com.atosorigin.common.constantes.Constantes;
import com.atosorigin.common.formvalidator.FormValidator;
import com.atosorigin.common.utils.GenericUtils;
import com.atosorigin.deri.colat.grupoContable.business.GrupoconColatBo;
import com.atosorigin.deri.colat.grupoContable.screen.GrupoconColatPantalla;
import com.atosorigin.deri.contrapartida.buscadorContrapartida.action.BuscadorContrapartidaAction;
import com.atosorigin.deri.model.catalogo.Producto;
import com.atosorigin.deri.model.colat.ContrapartidaLiquidacion;
import com.atosorigin.deri.model.colat.GrupoconColat;
import com.atosorigin.deri.model.contabilidad.GrupoContable;
import com.atosorigin.deri.model.contabilidad.GrupoContableId;
import com.atosorigin.deri.model.contrapartida.Contrapartida;
import com.atosorigin.deri.util.MessageBoxAction;
import com.atosorigin.deri.util.MsgBoxAction;

/**
 * Clase action listener para el caso de uso de contrapartidas liquidación
 */
@Name("grupoconColatAction")
@Scope(ScopeType.CONVERSATION)
@FormValidator
public class GrupoconColatAction extends PaginatedListAction {

	private static final long serialVersionUID = -4996253373443421408L;

	@In(value="#{grupoconColatBo}")
	GrupoconColatBo grupoconColatBo;
	
	@In(create=true)
	GrupoconColatPantalla grupoconColatPantalla;

	@In(create = true)
	private BuscadorContrapartidaAction buscadorContrapartidaAction;

	public static final String PRODUCTO_COLAT= "756000";

	@In(create = true)
	MsgBoxAction msgBoxAction;
	
	@Out(required = false, value = "grupoconColatMessageBoxAction")
	private MessageBoxAction messageBoxGrupoconColatAction;
	
	private Boolean primeraEjecucionInit=null;

	public void buscar(){
		setPrimerAcceso(false);
		paginationData.reset();
		refrescarLista();		
	}
	
	public void productoColat(){
		//Inicialización de filtros
		grupoconColatPantalla.setProductoSel(grupoconColatBo.getProductoColat(PRODUCTO_COLAT));
		GrupoContableId id = new GrupoContableId();
		id.setGrupoContable("");
		grupoconColatPantalla.setGrupoconSel(new GrupoContable(id));
		
	}

	public String guardar(){
		if(ModoPantalla.CREACION.equals(getModoPantalla())){
			if(GenericUtils.isNullOrBlank(grupoconColatBo.cargar(grupoconColatPantalla.getGrupoconSeleccionado().getContrapa()))){
				//Validar que la contrapartida existe
				if(!grupoconColatBo.existeContrapa(grupoconColatPantalla.getGrupoconSeleccionado().getContrapa())){
					statusMessages.add(Severity.ERROR, "#{messages['grupo.contable.contrapartida.no.existe']}", Constantes.DEFAULT_MESSAGE_TEMPLATE);
					return Constantes.CONSTANTE_FAIL;
				}
				grupoconColatBo.alta(grupoconColatPantalla.getGrupoconSeleccionado());
				statusMessages.add(Severity.INFO, "#{messages['grupo.contable.altacorrecta']}", Constantes.DEFAULT_MESSAGE_TEMPLATE);
			}else{
				statusMessages.add(Severity.ERROR, "#{messages['grupo.contable.alta.existente']}", Constantes.DEFAULT_MESSAGE_TEMPLATE);
				return Constantes.CONSTANTE_FAIL;
			}
		}if(ModoPantalla.EDICION.equals(getModoPantalla())){
			grupoconColatBo.modifica(grupoconColatPantalla.getGrupoconSeleccionado());
			statusMessages.add(Severity.INFO, "#{messages['contrapartidas.liquidacion.modificacioncorrecta']}", Constantes.DEFAULT_MESSAGE_TEMPLATE);
		}
		refreshListInternal();
		return Constantes.CONSTANTE_SUCCESS;
	}
	
	public void nuevo(){
		grupoconColatPantalla.setGrupoconSeleccionado(new GrupoconColat());
		setModoPantalla(ModoPantalla.CREACION);
	}
	
	public void borrar(){
		grupoconColatBo.baja(grupoconColatPantalla.getGrupoconSeleccionado());
		statusMessages.add(Severity.INFO, "#{messages['grupo.contable.borradoCorrecto']}", Constantes.DEFAULT_MESSAGE_TEMPLATE);	
		refrescarLista();
	}
	
	@Override
	public List<?> getDataTableList() {
		
		return grupoconColatPantalla.getListaGrupoconColat();
	}
	
	public void ver(){
		grupoconColatPantalla.setGrupoconSeleccionado(grupoconColatPantalla.getGrupoconSeleccionado());
		setModoPantalla(ModoPantalla.INSPECCION);
	}

	@Override
	protected void refreshListInternal() {
		setExportExcel(false);
		String producto = null;
		String contrapartida = null;
		String grupocon = null;
	
		if(!GenericUtils.isNullOrBlank(grupoconColatPantalla.getProductoSel())){
			producto = grupoconColatPantalla.getProductoSel().getId();
		}
		if(!GenericUtils.isNullOrBlank(grupoconColatPantalla.getContrapartidaSel())){
			contrapartida = grupoconColatPantalla.getContrapartidaSel();
		}
		if(!GenericUtils.isNullOrBlank(grupoconColatPantalla.getGrupoconSel())){
			grupocon = grupoconColatPantalla.getGrupoconSel().getId().getGrupoContable();
		}
		List<GrupoconColat> listaGrupoconColat = grupoconColatBo
				.buscarGrupoconColat(producto, contrapartida, grupocon, paginationData);
		
		grupoconColatPantalla.setListaGrupoconColat(listaGrupoconColat);
	}

	@Override
	public void refrescarListaExcel() {
		
		setExportExcel(true);
		String producto = null;
		String contrapartida = null;
		String grupocon = null;
	
		if(!GenericUtils.isNullOrBlank(grupoconColatPantalla.getProductoSel())){
			producto = grupoconColatPantalla.getProductoSel().getId();
		}
		if(!GenericUtils.isNullOrBlank(grupoconColatPantalla.getContrapartidaSel())){
			contrapartida = grupoconColatPantalla.getContrapartidaSel();
		}
		if(!GenericUtils.isNullOrBlank(grupoconColatPantalla.getGrupoconSel())){
			grupocon = grupoconColatPantalla.getGrupoconSel().getId().getGrupoContable();
		}
		List<GrupoconColat> listaGrupoconColat = grupoconColatBo
				.buscarGrupoconColat(producto, contrapartida, grupocon, paginationData.getPaginationDataForExcel());
		
		grupoconColatPantalla.setListaGrupoconColat(listaGrupoconColat);

	}

	public void editar(){
		grupoconColatPantalla.setGrupoconSeleccionado(grupoconColatPantalla.getGrupoconSeleccionado());
		
		setModoPantalla(ModoPantalla.EDICION);
	}

	public void cargarContrapartidas() {
		buscadorContrapartidaAction.buscar();
	}
	
	@Override
	public void setDataTableList(List<?> dataTableList) {
		grupoconColatPantalla.setListaGrupoconColat((List<GrupoconColat>)dataTableList);
	}

	public GrupoconColatBo getGrupoconColatBo() {
		return grupoconColatBo;
	}

	public void setGrupoconColatBo(GrupoconColatBo grupoconColatBo) {
		this.grupoconColatBo = grupoconColatBo;
	}

	public GrupoconColatPantalla getGrupoconColatPantalla() {
		return grupoconColatPantalla;
	}

	public void setGrupoconColatPantalla(GrupoconColatPantalla grupoconColatPantalla) {
		this.grupoconColatPantalla = grupoconColatPantalla;
	}

	public void onProductoChange() {
		Producto prod = grupoconColatPantalla.getProductoSel();
		grupoconColatPantalla.setProductoSel(prod);
	}
	
	public void init(){
		primeraEjecucionInit = null;
		
		if(null==messageBoxGrupoconColatAction){
			messageBoxGrupoconColatAction = new MessageBoxAction();
		}
	}
	
	public void initDetalle(){
		if (primeraEjecucionInit == null) {
			primeraEjecucionInit=true;
		}
		else{
			primeraEjecucionInit = false;
		}
		
		if(null==messageBoxGrupoconColatAction){
			messageBoxGrupoconColatAction = new MessageBoxAction();
		}
		
		if(primeraEjecucionInit){
			String idContrapartida = grupoconColatPantalla.getGrupoconSeleccionado().getContrapa();
			if (!GenericUtils.isNullOrBlank(idContrapartida)){
				 Contrapartida contrapartida = grupoconColatBo.cargarContrapartida(idContrapartida.toUpperCase());	
				if (null!=contrapartida && !GenericUtils.isNullOrBlank(contrapartida.getIndBloqueo()) && "S".equalsIgnoreCase(contrapartida.getIndBloqueo())){
					abrirPopUpContrapartidaBloqueada();
				}
			}
		}
	}

	public void voidFunction(){
		msgBoxAction.voidFunction();
	}
	
	/**
	 * Mostrar PopUp cuando una contrapartida está bloqueada (no bloqueante)
	 */
	public void onVerificarContrapartidaBloqueada() {
		String contrapartida = grupoconColatPantalla.getContrapartidaSel();
		if (!GenericUtils.isNullOrBlank(contrapartida)){
			 Contrapartida contrapObtenida2 = grupoconColatBo.cargarContrapartida(contrapartida.toUpperCase());	
			if (null!=contrapObtenida2 && !GenericUtils.isNullOrBlank(contrapObtenida2.getIndBloqueo()) && "S".equalsIgnoreCase(contrapObtenida2.getIndBloqueo())){
				abrirPopUpContrapartidaBloqueada();
			}
		}
	}
	
	public void onVerificarContrapartidaBloqueadaNueva() {
		String contrapartida = grupoconColatPantalla.getGrupoconSeleccionado().getContrapa();
		if (!GenericUtils.isNullOrBlank(contrapartida)){
			Contrapartida contrapObtenida2 = grupoconColatBo.cargarContrapartida(contrapartida.toUpperCase());	
			if (null!=contrapObtenida2 && !GenericUtils.isNullOrBlank(contrapObtenida2.getIndBloqueo()) && "S".equalsIgnoreCase(contrapObtenida2.getIndBloqueo())){
				abrirPopUpContrapartidaBloqueada();
			}
		}
	}
	
	private void abrirPopUpContrapartidaBloqueada(){
		messageBoxGrupoconColatAction.init("contrapartidas.messages.contrapartida.bloqueada.texto", "grupoconColatAction.voidFunction()", null,"confirmarPanel");
	}
	
	public String getRowClasses(){
		StringBuilder builder = new StringBuilder();
		int i=0;
		for (GrupoconColat grColat : grupoconColatPantalla.getListaGrupoconColat()) {
			Contrapartida contrapartida = null;
			String idContrapartida = grColat.getContrapa();
			contrapartida = grupoconColatBo.cargarContrapartida(idContrapartida.toUpperCase());	

			if(i>0){
				builder.append(",");
			}
			
			if(i%2==0){
				if(null!=contrapartida && !GenericUtils.isNullOrBlank(contrapartida.getIndBloqueo()) && "S".equalsIgnoreCase(contrapartida.getIndBloqueo())){
					builder.append("oddRowRed");
				}
				else{
					builder.append("oddRow");
				}
			}
			else{
				if(null!=contrapartida && !GenericUtils.isNullOrBlank(contrapartida.getIndBloqueo()) && "S".equalsIgnoreCase(contrapartida.getIndBloqueo())){
					builder.append("evenRowRed");
				}
				else{
					builder.append("evenRow");
				}
			}
			i++;
			contrapartida = null;
		}
		return builder.toString();
	}

}
