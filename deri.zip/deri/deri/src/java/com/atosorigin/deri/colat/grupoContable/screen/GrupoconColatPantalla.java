package com.atosorigin.deri.colat.grupoContable.screen;

import java.util.List;

import org.jboss.seam.ScopeType;
import org.jboss.seam.annotations.Name;
import org.jboss.seam.annotations.Out;
import org.jboss.seam.annotations.Scope;
import org.jboss.seam.annotations.datamodel.DataModel;
import org.jboss.seam.annotations.datamodel.DataModelSelection;

import com.atosorigin.deri.model.catalogo.Producto;
import com.atosorigin.deri.model.colat.GrupoconColat;
import com.atosorigin.deri.model.contabilidad.GrupoContable;

/**
 *  Contiene los datos de pantalla necesarios para el mantenimiento de grupo contable colat.
 */

@Name("grupoconColatPantalla")
@Scope(ScopeType.CONVERSATION)
public class GrupoconColatPantalla {

	protected Producto productoSel;
	
	protected String contrapartidaSel;
	
	protected GrupoContable grupoconSel;
	
	protected String idContrapartida;
	
	@DataModel(value="listaDtGrupoconColat")
	List<GrupoconColat> listaGrupoconColat;
	
	@DataModelSelection(value="listaDtGrupoconColat")
	@Out(required=false)
	protected GrupoconColat grupoconSeleccionado;

	public Producto getProductoSel() {
		return productoSel;
	}

	public void setProductoSel(Producto productoSel) {
		this.productoSel = productoSel;
	}

	public String getContrapartidaSel() {
		return contrapartidaSel;
	}

	public void setContrapartidaSel(String contrapartidaSel) {
		this.contrapartidaSel = contrapartidaSel;
	}

	public GrupoContable getGrupoconSel() {
		return grupoconSel;
	}

	public void setGrupoconSel(GrupoContable grupoconSel) {
		this.grupoconSel = grupoconSel;
	}

	public List<GrupoconColat> getListaGrupoconColat() {
		return listaGrupoconColat;
	}

	public void setListaGrupoconColat(List<GrupoconColat> listaGrupoconColat) {
		this.listaGrupoconColat = listaGrupoconColat;
	}

	public GrupoconColat getGrupoconSeleccionado() {
		return grupoconSeleccionado;
	}

	public void setGrupoconSeleccionado(GrupoconColat grupoconSeleccionado) {
		this.grupoconSeleccionado = grupoconSeleccionado;
	}

	public String getIdContrapartida() {
		return idContrapartida;
	}

	public void setIdContrapartida(String idContrapartida) {
		this.idContrapartida = idContrapartida;
	}

}
