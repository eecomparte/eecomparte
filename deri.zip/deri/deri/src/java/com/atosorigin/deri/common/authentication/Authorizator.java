package com.atosorigin.deri.common.authentication;

import org.jboss.seam.Component;
import org.jboss.seam.ScopeType;
import org.jboss.seam.annotations.Name;
import org.jboss.seam.annotations.Scope;
import org.jboss.seam.annotations.intercept.BypassInterceptors;

import com.atosorigin.deri.common.authentication.PantallasNivelesCache.TipoAccionNivel;

@Name("authorizator")
@Scope(ScopeType.CONVERSATION)
@BypassInterceptors
public class Authorizator
{
	
	protected CustomIdentity identity = (CustomIdentity)Component.getInstance("org.jboss.seam.security.identity");;
	protected PantallasNivelesCache pantallasNivelesCache = (PantallasNivelesCache)Component.getInstance("pantallasNivelesCache");
	protected String codigoPantalla = null;
	protected boolean calculadosPermisos = false;
	protected boolean permisoAlta = false;
	protected boolean permisoBaja = false;
	protected boolean permisoModificacion = false;
	protected boolean permisoConsulta = false;
	protected boolean permisoImpresion = false;
	
	public boolean isAccesoPermitido(String codigoPantalla) {
		if (identity.getPantallasProhibidas() == null || identity.getPantallasProhibidas().contains(codigoPantalla)) {
			return false;
		}
		if (!calculadosPermisos) {
			this.codigoPantalla = codigoPantalla;
			permisoAlta = isPermisoGeneral(codigoPantalla, TipoAccionNivel.ALTA);
			permisoBaja = isPermisoGeneral(codigoPantalla, TipoAccionNivel.BAJA);
			permisoModificacion = isPermisoGeneral(codigoPantalla, TipoAccionNivel.MODIFICACION);
			permisoConsulta = isPermisoGeneral(codigoPantalla, TipoAccionNivel.CONSULTA);
			permisoImpresion = isPermisoGeneral(codigoPantalla, TipoAccionNivel.IMPRESION);
			calculadosPermisos = true;
		}
		
		return true;
	}
	
	private boolean isPermisoGeneral(String pantalla, TipoAccionNivel tipoAccionNivel) {
		Integer nivelUsuario = identity.getNivelUsuario();
		Integer nivel = pantallasNivelesCache.getNivel(pantalla, tipoAccionNivel);

//		try {
//			return (nivelUsuario >= nivel);
//		} catch (Exception e) {
//			try {
//				MapUtils.verbosePrint(System.out, "identity",  BeanUtils.describe(identity));
//			} catch (Exception e1) {
//				e1.printStackTrace();
//			}
//
//			try {
//				MapUtils.verbosePrint(System.out, "pantallasNivelesCache",  BeanUtils.describe(pantallasNivelesCache));
//			} catch (Exception e1) {
//				e1.printStackTrace();
//			}
//		}

		if (nivelUsuario == null)
			return false;

		if (nivel == null)
			nivel = 99;

		return (nivelUsuario >= nivel);
	}

	public boolean isPermisoAlta() {
		return permisoAlta;
	}

	public void setPermisoAlta(boolean permisoAlta) {
		this.permisoAlta = permisoAlta;
	}

	public boolean isPermisoBaja() {
		return permisoBaja;
	}

	public void setPermisoBaja(boolean permisoBaja) {
		this.permisoBaja = permisoBaja;
	}

	public boolean isPermisoModificacion() {
		return permisoModificacion;
	}

	public void setPermisoModificacion(boolean permisoModificacion) {
		this.permisoModificacion = permisoModificacion;
	}

	public boolean isPermisoConsulta() {
		return permisoConsulta;
	}

	public void setPermisoConsulta(boolean permisoConsulta) {
		this.permisoConsulta = permisoConsulta;
	}

	public boolean isPermisoImpresion() {
		return permisoImpresion;
	}

	public void setPermisoImpresion(boolean permisoImpresion) {
		this.permisoImpresion = permisoImpresion;
	}

	
	public boolean isPermisoAlta(String pantalla) {
		if (pantalla.equals(this.codigoPantalla)) {
			return permisoAlta; 
		}
		return isPermisoGeneral(pantalla, TipoAccionNivel.ALTA);
	}
	
	public boolean isPermisoBaja(String pantalla) {
		if (pantalla.equals(this.codigoPantalla)) {
			return permisoBaja; 
		}
		return isPermisoGeneral(pantalla, TipoAccionNivel.BAJA);
	}
	
	public boolean isPermisoConsulta(String pantalla) {
		if (pantalla.equals(this.codigoPantalla)) {
			return permisoConsulta; 
		}
		return isPermisoGeneral(pantalla, TipoAccionNivel.CONSULTA);
	}
	
	public boolean isPermisoImpresion(String pantalla) {
		if (pantalla.equals(this.codigoPantalla)) {
			return permisoImpresion; 
		}
		return isPermisoGeneral(pantalla, TipoAccionNivel.IMPRESION);
	}
	
	public boolean isPermisoModificacion(String pantalla) {
		if (pantalla.equals(this.codigoPantalla)) {
			return permisoModificacion; 
		}
		return isPermisoGeneral(pantalla, TipoAccionNivel.MODIFICACION);
	}

	
	
}
