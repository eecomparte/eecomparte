package com.atosorigin.deri.common.authentication;

import java.util.List;

import org.jboss.seam.ScopeType;
import org.jboss.seam.annotations.Install;
import org.jboss.seam.annotations.Name;
import org.jboss.seam.annotations.Scope;
import org.jboss.seam.annotations.Startup;
import org.jboss.seam.annotations.intercept.BypassInterceptors;
import org.jboss.seam.security.Identity;

@Name("org.jboss.seam.security.identity")
@Scope(ScopeType.SESSION)
@Install(precedence = Install.APPLICATION)
@BypassInterceptors
@Startup
public class CustomIdentity extends Identity {
	private static final long serialVersionUID = -9154737979944336061L;

	private List<String> pantallasProhibidas = null;
	
	private boolean loggedIn = false;
	
	private Integer nivelUsuario = null;
	
	private Integer perfilUsuario = null;

	@Override
	public boolean isLoggedIn() {
		return loggedIn;
	}

	public void setLoggedIn(boolean loggedIn) {
		this.loggedIn = loggedIn;
	}

	public List<String> getPantallasProhibidas() {
		return pantallasProhibidas;
	}

	public void setPantallasProhibidas(List<String> pantallasProhibidas) {
		this.pantallasProhibidas = pantallasProhibidas;
	}

	public Integer getNivelUsuario() {
		return nivelUsuario;
	}

	public void setNivelUsuario(Integer nivelUsuario) {
		this.nivelUsuario = nivelUsuario;
	}


	public Integer getPerfilUsuario() {
		return perfilUsuario;
	}

	public void setPerfilUsuario(Integer perfil) {
		this.perfilUsuario = perfil;
	} 


}
