package com.atosorigin.deri.common.authentication;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.jboss.seam.ScopeType;
import org.jboss.seam.annotations.In;
import org.jboss.seam.annotations.Name;
import org.jboss.seam.annotations.Scope;

import com.atosorigin.deri.model.seguridad.Pantalla;
import com.atosorigin.deri.seguridad.pantalla.business.PantallaBo;

@Name("pantallasNivelesCache")
@Scope(ScopeType.APPLICATION)
public class PantallasNivelesCache {
	
	@In("#{pantallaBo}")
	private PantallaBo pantallaBo;
	
	private static final Integer MIN_NIVEL_PANTALLA = -1;
	public enum TipoAccionNivel {ALTA, BAJA, CONSULTA, IMPRESION, MODIFICACION};
	
	private Map<String, Map<TipoAccionNivel, Integer>> pantallas = new HashMap<String, Map<TipoAccionNivel, Integer>>();

	public void inicializar() {
			List<Pantalla> pantallasDERI = pantallaBo.buscarPantallas();
			for (Pantalla pantalla : pantallasDERI) {
				pantalla.checkPrivilegios();
				Map<TipoAccionNivel, Integer> nivelesPantalla = new HashMap<TipoAccionNivel, Integer>();
				nivelesPantalla.put(TipoAccionNivel.ALTA, 	      pantalla.getPrivilegioAlta().getNivel());
				nivelesPantalla.put(TipoAccionNivel.BAJA, 	      pantalla.getPrivilegioBaja().getNivel());
				nivelesPantalla.put(TipoAccionNivel.CONSULTA, 	  pantalla.getPrivilegioConsulta().getNivel());
				nivelesPantalla.put(TipoAccionNivel.IMPRESION,    pantalla.getPrivilegioImpresion().getNivel());
				nivelesPantalla.put(TipoAccionNivel.MODIFICACION, pantalla.getPrivilegioModificacion().getNivel());
				pantallas.put(pantalla.getId().getCodigo(), nivelesPantalla);
			}
	}

	public void actualizarPantalla(Pantalla pantallaActualizada) {
		if (pantallas.containsKey(pantallaActualizada.getId())) {
			pantallas.remove(pantallaActualizada.getId().getCodigo());
		}
		Map<TipoAccionNivel, Integer> nivelesPantalla = new HashMap<TipoAccionNivel, Integer>();
		//Rehacemos los permisos, parece que no se actualizan correctamente
		pantallaActualizada.checkPrivilegios();
		
		nivelesPantalla.put(TipoAccionNivel.ALTA, 	      pantallaActualizada.getPrivilegioAlta().getNivel());
		nivelesPantalla.put(TipoAccionNivel.BAJA, 	      pantallaActualizada.getPrivilegioBaja().getNivel());
		nivelesPantalla.put(TipoAccionNivel.CONSULTA, 	  pantallaActualizada.getPrivilegioConsulta().getNivel());
		nivelesPantalla.put(TipoAccionNivel.IMPRESION,    pantallaActualizada.getPrivilegioImpresion().getNivel());
		nivelesPantalla.put(TipoAccionNivel.MODIFICACION, pantallaActualizada.getPrivilegioModificacion().getNivel());
		pantallas.put(pantallaActualizada.getId().getCodigo(), nivelesPantalla);
		
	}

	
	public void actualizarPantallaBorrar(Pantalla pantallaActualizada) {
		if (pantallas.containsKey(pantallaActualizada.getId())) {
			pantallas.remove(pantallaActualizada.getId().getCodigo());
		}
	}
	
	public Integer getNivel(String pantalla, TipoAccionNivel modalidad) {
		Map<TipoAccionNivel, Integer> nivelesPantalla = pantallas.get(pantalla);
		if (nivelesPantalla == null) {
			return MIN_NIVEL_PANTALLA;
		}
		Integer nivel = nivelesPantalla.get(modalidad);
		if (nivel == null) {
			return MIN_NIVEL_PANTALLA;
		}
		return nivel;
	}
}
