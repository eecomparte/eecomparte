package com.atosorigin.deri.common.authentication;

import java.security.Principal;
import java.util.List;

import javax.faces.context.ExternalContext;
import javax.faces.context.FacesContext;

import org.jasig.cas.client.util.AssertionHolder;
import org.jasig.cas.client.validation.Assertion;
import org.jboss.seam.ScopeType;
import org.jboss.seam.annotations.In;
import org.jboss.seam.annotations.Logger;
import org.jboss.seam.annotations.Name;
import org.jboss.seam.annotations.Scope;
import org.jboss.seam.core.Events;
import org.jboss.seam.international.StatusMessages;
import org.jboss.seam.log.Log;
import org.jboss.seam.security.Credentials;
import org.jboss.seam.security.Identity;
import org.jboss.seam.web.Session;

import com.atosorigin.deri.model.seguridad.Usuario;
import com.atosorigin.deri.seguridad.mantusuario.business.UsuarioBo;

@Name("ssoAuthenticator")
@Scope(ScopeType.SESSION)
public class SSOAuthenticator implements java.io.Serializable {

	private static final String CAS_FILTER = "_const_cas_assertion_"; 

	@Logger
	private Log log;

	@In
	CustomIdentity identity;
	@In
	Credentials credentials;

	@In("usuarioBo")
	UsuarioBo usuarioBo;

	/** Inyección de los mansajes de estado de SEAM */
	@In
	protected StatusMessages statusMessages;


	
	public void checkLogin() {
		// user may already be logged in - check
		final boolean isLoggedIn = Identity.instance().isLoggedIn();
		
		if (isLoggedIn) {
			return;
		}
		authenticate();
	}

	public boolean authenticate() {
		try {
	        log.info("Autenticando a {0}", credentials.getUsername());
	        
			try {
				
				String username = credentials.getUsername();
				if (username == null) {
					//username = (String)FacesContext.getCurrentInstance().getExternalContext().getSessionMap().get("edu.yale.its.tp.cas.client.filter.user");
					//username = (String)FacesContext.getCurrentInstance().getExternalContext().getUserPrincipal().getName();
					Assertion assertion = AssertionHolder.getAssertion();
					Principal principal = assertion.getPrincipal();
					username = principal.getName();

					credentials.setUsername(username);
				}
				Usuario usuarioLogin = usuarioBo.buscarUsuarioUsername(username);
				if (usuarioLogin == null) {
					statusMessages.add("#{messages['error.login']}");
					return false;
				}

				if (usuarioLogin.getEstadoBloqueo()){
					statusMessages.add("#{messages['Usuario.Bloqueado']}");
					return false;
				}
					
				List<String> pantallasProhibidas = usuarioBo.obtenerPantallasProhibidasUsuario(usuarioLogin);

				identity.setPantallasProhibidas(pantallasProhibidas);

				identity.setNivelUsuario(usuarioLogin.getNivel());
				
				identity.setPerfilUsuario(usuarioLogin.getPerfil());
				
				identity.setLoggedIn(true);
				
				identity.authenticate();


				log.info("Login status....." + identity.isLoggedIn());
				Events.instance().raiseEvent(Identity.EVENT_LOGIN_SUCCESSFUL);

				
				return true;
			} catch (Exception e) {
				this.log.error("authenticating Error {0}", e.getMessage());
				System.err.println("authenticate exception: " + e);
				return false;
			}

		} catch (Exception e) {
			System.err.println("authenticate exception: " + e);
			return false;
		}
	}

	public void logout() {
		
		identity.setLoggedIn(false);
		identity.logout();
		identity.unAuthenticate();
		Session.instance().invalidate();
		Events.instance().raiseEvent(Identity.EVENT_LOGGED_OUT);

		FacesContext facesContext = FacesContext.getCurrentInstance();
		ExternalContext ctx = facesContext.getExternalContext();
		try {
			String url = "home.seam";
			ctx.redirect(ctx.encodeResourceURL(url));
		} catch (Exception e) {
			System.err.println("logout exception: " + e);
		}
		FacesContext.getCurrentInstance().responseComplete();

	}
}