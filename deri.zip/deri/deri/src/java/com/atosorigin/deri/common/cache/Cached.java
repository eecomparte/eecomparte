package com.atosorigin.deri.common.cache;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

import org.jboss.seam.annotations.intercept.Interceptors;

/**
 * Anotación para indicar a SEAM que la clase ha de ser procesada.
 * 
 * @author alejandro.torras@atosorigin.com
 */
@Target(ElementType.TYPE)
@Retention(RetentionPolicy.RUNTIME)
@Interceptors(CachedMethodInterceptor.class)
public @interface Cached {
}
