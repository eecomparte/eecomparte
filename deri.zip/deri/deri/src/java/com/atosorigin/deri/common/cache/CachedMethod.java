package com.atosorigin.deri.common.cache;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

@Target(ElementType.METHOD)
@Retention(RetentionPolicy.RUNTIME)
public @interface CachedMethod {

	public static enum Region {

		UN_DIA("UN_DIA");

		private String regionName;

		private Region(String regionName) {
			this.regionName = regionName;
		}

		public String getRegionName() {
			return regionName;
		}
	}

	String name() default "";

	Region region() default Region.UN_DIA;

}
