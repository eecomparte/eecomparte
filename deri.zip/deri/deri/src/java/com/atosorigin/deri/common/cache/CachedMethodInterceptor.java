package com.atosorigin.deri.common.cache;

import java.io.Serializable;
import java.lang.reflect.Method;

import javax.management.MalformedObjectNameException;

import net.sf.ehcache.Cache;
import net.sf.ehcache.CacheManager;
import net.sf.ehcache.Element;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.jboss.cache.TreeCache;
import org.jboss.seam.annotations.Name;
import org.jboss.seam.annotations.intercept.AroundInvoke;
import org.jboss.seam.annotations.intercept.Interceptor;
import org.jboss.seam.annotations.intercept.InterceptorType;
import org.jboss.seam.core.MethodContextInterceptor;
import org.jboss.seam.core.SynchronizationInterceptor;
import org.jboss.seam.intercept.InvocationContext;
import org.jboss.seam.intercept.JavaBeanInterceptor;
import org.jboss.seam.transaction.TransactionInterceptor;

import com.atosorigin.deri.common.cache.CachedMethod.Region;

/**
 * Interceptor de Seam para almacenar en caché (a.k.a <i>cachear</i>) el
 * resultado devuelto por el método invocado.<br />
 * 
 * Internamente se usa la caché de JBoss {@link TreeCache}.<br />
 * 
 * Su uso es sencillo:
 * <ol>
 * <li>Añadir la anotación {@link Cached} la clase.</li>
 * <li>Añadir la anotación {@link CachedMethod} a los métodos que quieran
 * cachearse.</li>
 * </ol>
 * 
 * @see #remove(Region, String)
 * @see <a
 *      href="http://solutionsfit.com/blog/2007/11/09/thoughts-on-webbeans-and-stereotypes/">http://solutionsfit.com/blog/2007/11/09/thoughts-on-webbeans-and-stereotypes/</a>
 */
@Interceptor(stateless = true, type = InterceptorType.CLIENT, around = {
		MethodContextInterceptor.class, TransactionInterceptor.class,
		JavaBeanInterceptor.class, SynchronizationInterceptor.class })
@Name("cachedMethodInterceptor")
public class CachedMethodInterceptor implements Serializable {
	
	private static Log log = LogFactory.getLog(CachedMethodInterceptor.class);

	private static final long serialVersionUID = 1L;

	private static final String PREFIX = "DERI";
	

	public CachedMethodInterceptor() throws MalformedObjectNameException {
		initMBean();
	}

	@AroundInvoke
	public Object aroundInvoke(final InvocationContext invocation)
			throws Exception {

		final Method invokedMethod = invocation.getMethod();
		final CachedMethod cmAnnotation = invokedMethod.getAnnotation(CachedMethod.class);

		if (cmAnnotation == null)
			return invocation.proceed();

		
		String region = cmAnnotation.region().getRegionName();
		String entryName = cmAnnotation.name();

		try {
			return handleCache(invocation, region, entryName);
		} catch (Exception e) {

			log.warn(e);
			throw new RuntimeException("ERROR ACCEDIENDO A LA CACHE", e);
		}

		
	}

	private Object handleCache(final InvocationContext invocation, String region, String entryName) throws Exception{

		
		CacheManager manager = CacheManager.getInstance();
		Cache cache = manager.getCache(region);
		Element cacheValue = cache.get(entryName);
		

		if (cacheValue != null)
			return cacheValue.getObjectValue();

		// No existe el valor

		final Object invocationValue = invocation.proceed();
		cacheValue= new Element(entryName, invocationValue);
		cache.put(cacheValue);

		return invocationValue;
	}

	protected void initMBean() throws MalformedObjectNameException {
		

	}


}
