package com.atosorigin.deri.common.comboboxes;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.jboss.seam.ScopeType;
import org.jboss.seam.annotations.Factory;
import org.jboss.seam.annotations.Name;
import org.jboss.seam.core.Expressions;

import com.atosorigin.common.constantes.Constantes;
import com.atosorigin.common.utils.GenericUtils;
import com.atosorigin.deri.adminoper.admconfirmaciones.business.ConfirmacionOperacionesBo;
import com.atosorigin.deri.adminoper.boletas.business.BoletasBo;
import com.atosorigin.deri.adminoper.boletas.business.IndPagoCobroBo;
import com.atosorigin.deri.adminoper.boletas.tramos.business.AltaTramosBo;
import com.atosorigin.deri.adminoper.boletas.tramos.business.DatosPrimerTramoIrregularBo;
import com.atosorigin.deri.adminoper.boletas.tramos.business.DetallePrimasBo;
import com.atosorigin.deri.adminoper.cancelacionparcial.business.CancelacionParcialBo;
import com.atosorigin.deri.adminoper.condFijacion.business.CondFijacionBo;
import com.atosorigin.deri.adminoper.ejercicio.business.EjercicioBo;
import com.atosorigin.deri.adminoper.gestionemir.business.EmirBo;
//import com.atosorigin.deri.adminoper.gestionemir.business.EmirBo;
import com.atosorigin.deri.adminoper.mantbarreras.business.MantenimientoBarrerasBo;
import com.atosorigin.deri.adminoper.mantfechas.business.HistoricoFechaFormulaBo;
import com.atosorigin.deri.adminoper.mantoper.business.CancelacionBo;
import com.atosorigin.deri.adminoper.mantoper.business.MantOperBo;
import com.atosorigin.deri.adminoper.mantoqe.business.MantoqeBarreraBo;
import com.atosorigin.deri.adminoper.subyacentes.business.HistoricoSubyacenteBo;
import com.atosorigin.deri.agenda.aviso.business.AvisoBo;
import com.atosorigin.deri.agenda.aviso.business.EventosAgendaBo;
import com.atosorigin.deri.agenda.peticiones.business.PeticionesBo;
import com.atosorigin.deri.appListados.listados.business.PeticionBo;
import com.atosorigin.deri.appListados.parametros.business.ParametroBo;
import com.atosorigin.deri.appListados.visibilidad.business.ListadosVisibilidadBo;
import com.atosorigin.deri.apuntescontables.ajustesmanuales.business.AjustesManualesBo;
import com.atosorigin.deri.colat.configuracionesContables.business.ConfiguracionesContablesBo;
import com.atosorigin.deri.colat.contrapartidasRepo.business.ContrapartidasRepoBo;
import com.atosorigin.deri.common.cache.Cached;
import com.atosorigin.deri.common.cache.CachedMethod;
import com.atosorigin.deri.common.cache.CachedMethod.Region;
import com.atosorigin.deri.contabilidad.grupocontable.business.GrupoContableBo;
import com.atosorigin.deri.contrapartida.agrupcontrapartida.business.AgrupContrapartidaBo;
import com.atosorigin.deri.contrapartida.business.ContrapartidaBo;
import com.atosorigin.deri.contrapartida.docscontrapartida.business.DocsContrapartidaBo;
import com.atosorigin.deri.contrapartida.manttipostocumento.business.MantTiposDocumentoBo;
import com.atosorigin.deri.gestioncampanyas.campanya.business.CampanyaBo;
import com.atosorigin.deri.gestionoperaciones.anexooperacion.business.AnexoOperacionBo;
import com.atosorigin.deri.gestionoperaciones.orden.business.OrdenBo;
import com.atosorigin.deri.gestionoperaciones.productocompuesto.business.BoletaProdCompuestoBo;
import com.atosorigin.deri.gestionoperaciones.productocompuesto.business.MantProdCompuestoBo;
import com.atosorigin.deri.gestiontesoreria.basecalculo.business.BaseCalculoBo;
import com.atosorigin.deri.kondor.avisoscaptura.business.AvisosCapturaBo;
import com.atosorigin.deri.kondor.erroresconciliacion.business.ErroresConciliacionBo;
import com.atosorigin.deri.liquidaciones.business.LiquidacionesBo;
import com.atosorigin.deri.mercado.mantplazo.business.PlazoBo;
import com.atosorigin.deri.mercado.mantsubyacente.business.SubyacenteBo;
import com.atosorigin.deri.model.adminoper.CanalConfirmacion;
import com.atosorigin.deri.model.adminoper.DescripcionClaseFecha;
import com.atosorigin.deri.model.adminoper.DescripcionClaseHisttramIndifiva;
import com.atosorigin.deri.model.adminoper.DescripcionClaseInt;
import com.atosorigin.deri.model.adminoper.DescripcionEntidadOperacion;
import com.atosorigin.deri.model.adminoper.DescripcionFactorLiquidacion;
import com.atosorigin.deri.model.adminoper.DescripcionHisttramSigno;
import com.atosorigin.deri.model.adminoper.DescripcionHisttramTipoConcepto;
import com.atosorigin.deri.model.adminoper.DescripcionIdiomaTipCambio;
import com.atosorigin.deri.model.adminoper.DescripcionMarcaDocumento;
import com.atosorigin.deri.model.adminoper.DescripcionMotivoCancelacion;
import com.atosorigin.deri.model.adminoper.DescripcionOperadorPrimer;
import com.atosorigin.deri.model.adminoper.DescripcionOperadorSegundo;
import com.atosorigin.deri.model.adminoper.DescripcionOperadorSupuesto;
import com.atosorigin.deri.model.adminoper.DescripcionRelacionSupuesto;
import com.atosorigin.deri.model.adminoper.DescripcionSentido;
import com.atosorigin.deri.model.adminoper.DescripcionSentidoAmortizacion;
import com.atosorigin.deri.model.adminoper.DescripcionTipoBarrera;
import com.atosorigin.deri.model.adminoper.DescripcionTipoCancelacion;
import com.atosorigin.deri.model.adminoper.DescripcionTipoConfirmacion;
import com.atosorigin.deri.model.adminoper.DescripcionTipoOperacionHistderi;
import com.atosorigin.deri.model.adminoper.DescripcionTipoPlantilla;
import com.atosorigin.deri.model.adminoper.DescripcionTipoRebate;
import com.atosorigin.deri.model.adminoper.DescripcionTipoRevision;
import com.atosorigin.deri.model.adminoper.DescripcionTipoSwaption;
import com.atosorigin.deri.model.agenda.DescripcionAccionesAvisos;
import com.atosorigin.deri.model.agenda.DescripcionAviso;
import com.atosorigin.deri.model.appListados.Listados;
import com.atosorigin.deri.model.apuntesContables.DescCanalLiqui;
import com.atosorigin.deri.model.catalogo.DescripcionAmortizacion;
import com.atosorigin.deri.model.catalogo.DescripcionTipoAjuste;
import com.atosorigin.deri.model.catalogo.Producto;
import com.atosorigin.deri.model.colat.EsquemaContable;
import com.atosorigin.deri.model.colat.ProductoContraRepo;
import com.atosorigin.deri.model.colat.configuracionesContables.ConceptoTipconta;
import com.atosorigin.deri.model.colat.configuracionesContables.CuentaPosicion;
import com.atosorigin.deri.model.colat.configuracionesContables.GrupoContableColat;
import com.atosorigin.deri.model.common.Idioma;
import com.atosorigin.deri.model.contabilidad.GrupoContableSelect;
import com.atosorigin.deri.model.contabilidad.TiposContable;
import com.atosorigin.deri.model.contrapartida.AgrupContrapartida;
import com.atosorigin.deri.model.contrapartida.CodigoPais;
import com.atosorigin.deri.model.contrapartida.Contrapartida;
import com.atosorigin.deri.model.contrapartida.EstadoDocumento;
import com.atosorigin.deri.model.contrapartida.EstadoDocumentoContrapartida;
import com.atosorigin.deri.model.contrapartida.TipoContrapartida;
import com.atosorigin.deri.model.contrapartida.UnidadNegocio;
import com.atosorigin.deri.model.gestioncampanyas.Campanya;
import com.atosorigin.deri.model.gestioncampanyas.DescripcionModeloCampanya;
import com.atosorigin.deri.model.gestioncampanyas.IndicadorOperacionesCobertura;
import com.atosorigin.deri.model.gestionemir.DescripcionEstadoEmir;
import com.atosorigin.deri.model.gestionemir.DescripcionIndicadorSituacion;
import com.atosorigin.deri.model.gestionemir.DescripcionTipoTransaccion;
import com.atosorigin.deri.model.gestionoperaciones.DescIndSitua;
import com.atosorigin.deri.model.gestionoperaciones.DescSituacionProdCompuesto;
import com.atosorigin.deri.model.gestionoperaciones.DescripcionEstadoConfirmacion;
import com.atosorigin.deri.model.gestionoperaciones.DescripcionPata;
import com.atosorigin.deri.model.gestiontesoreria.BaseCalculo;
import com.atosorigin.deri.model.gestiontesoreria.TipoCurva;
import com.atosorigin.deri.model.kondor.DescripcionDealtype;
import com.atosorigin.deri.model.liquidaciones.DescripcionCanalLiquidacion;
import com.atosorigin.deri.model.liquidaciones.DescripcionEstadoLiquidacion;
import com.atosorigin.deri.model.liquidaciones.DescripcionSituacionLiquidacion;
import com.atosorigin.deri.model.liquidaciones.ModeloColat;
import com.atosorigin.deri.model.mercado.Pagina;
import com.atosorigin.deri.model.mercado.Plaza;
import com.atosorigin.deri.model.mercado.Plazo;
import com.atosorigin.deri.model.mercado.Subyacente;
import com.atosorigin.deri.model.mercado.TipoSubyacente;
import com.atosorigin.deri.model.mercado.Unidad;
import com.atosorigin.deri.model.mercado.UnidadPlazo;
import com.atosorigin.deri.model.murex.ModeloProducto;
import com.atosorigin.deri.model.murex.ProcedenciaProducto;
import com.atosorigin.deri.model.murex.ProductoCatalogo;
import com.atosorigin.deri.model.parametrizacion.DescripcionGruposContables;
import com.atosorigin.deri.model.parametrizacion.DescripcionHistoricoConcepto;
import com.atosorigin.deri.model.parametrizacion.DescripcionParametroCesionTipoCesion;
import com.atosorigin.deri.model.parametrizacion.DescripcionParametroCesionTipoConcepto;
import com.atosorigin.deri.model.parametrizacion.DescripcionParametroCesionTipoOperacion;
import com.atosorigin.deri.model.parametrizacion.DescripcionTipoDestino;
import com.atosorigin.deri.model.parametrizacion.Divisa;
import com.atosorigin.deri.model.parametrizacion.IndicadorActiva;
import com.atosorigin.deri.model.parametrizacion.TipoOperacion;
import com.atosorigin.deri.model.peticiones.DescripcionEstadoPeticion;
import com.atosorigin.deri.model.peticiones.DescripcionTipoPeticion;
import com.atosorigin.deri.model.provisional.ListasTipo;
import com.atosorigin.deri.model.seguridad.TbPersona;
import com.atosorigin.deri.model.swift.DescripcionEstadosSwift;
import com.atosorigin.deri.model.swift.MantenimientoMensajes;
import com.atosorigin.deri.murex.errorescaptura.business.ErroresCapturaBo;
import com.atosorigin.deri.parametrizacion.confirmaciones.business.ConfirmacionesBo;
import com.atosorigin.deri.parametrizacion.divisa.business.DivisaBo;
import com.atosorigin.deri.parametrizacion.parametroscesion.business.ParametrosCesionBo;
import com.atosorigin.deri.parametrizacion.parametrosliquidacion.business.ParametrosLiquidacionBo;
import com.atosorigin.deri.parametrizacion.suscripcion.business.SuscripcionBo;
import com.atosorigin.deri.seguridad.mantusuario.business.UsuarioBo;
import com.atosorigin.deri.seguridad.perfil.business.PerfilBo;
import com.atosorigin.deri.swift.gestionswift.business.SwiftBo;

@Name("comboBoxes")
@Cached
public class ComboBoxes{

	DatosPrimerTramoIrregularBo datosPrimerTramoIrregularBo;
	
	AltaTramosBo altaTramosBo;
	
	UsuarioBo usuarioBo;

	// Se inyecta el bean de spring "subyacenteBo"
	
	SubyacenteBo subyacenteBo;

	// Se inyecta el bean de spring "plazoBO"
	
	PlazoBo plazoBo;

	// Se inyecta el bean de spring "divisaBO"
	
	DivisaBo divisaBo;

	
	PerfilBo perfilBo;

	// Se inyecta el bean de spring "avisoBo"
	
	AvisoBo avisoBo;

	// Se inyecta el bean de spring "suscripcionBo"
	
	SuscripcionBo suscripcionBo;

	
	ContrapartidaBo contrapartidaBo;

	
	DocsContrapartidaBo docsContrapartidaBo;

	// Se inyecta el bean de spring "peticionBo"
	
	PeticionBo peticionBo;

	// Se inyecta el bean de spring "mantTiposDocumentoBo"
	
	MantTiposDocumentoBo mantTiposDocumentoBo;

	// Se inyecta el bean de spring "agrupContrapartidaBo"
	
	AgrupContrapartidaBo agrupContrapartidaBo;

	// Se inyecta el bean de spring "avisosCapturaBo"
	
	AvisosCapturaBo avisosCapturaBo;

	
	ParametroBo parametroBo;

	
	ParametrosCesionBo parametrosCesionBo;

	// Se inyecta el bean de spring "divisaBO"
	
	ErroresConciliacionBo erroresConciliacionBo;

	
	AjustesManualesBo ajustesManualesBo;

	
	SwiftBo swiftBo;

	// Se inyecta el bean de spring "grupoContableBo"
	
	GrupoContableBo grupoContableBo;

	
	ConfirmacionesBo confirmacionesBo;

	
	BoletasBo boletasBo;
	
	
	MantOperBo mantOperBo;
	
	
	ParametrosLiquidacionBo parametrosLiquidacionBo;

	
	CampanyaBo campanyaBo;

	
	OrdenBo ordenBo;

	
	ErroresCapturaBo erroresCapturaBo;

	
	ListadosVisibilidadBo listadosVisibilidadBo;

	
	AnexoOperacionBo anexoOperacionBo;
	
	
	EventosAgendaBo eventosAgendaBo;	
	
	// New BO for AdminConfi
	
	ConfirmacionOperacionesBo admconfirmacionesBo;

	
	HistoricoSubyacenteBo historicoSubyacenteBo;
	
	
	HistoricoFechaFormulaBo historicoFechaFormulaBo ;
	
	
	CondFijacionBo condFijacionBo ;
	
	
	DetallePrimasBo detallePrimasBo; 
		
	
	LiquidacionesBo liquidacionesBo ;	

    CancelacionParcialBo cancelacionParcialBo;

	MantenimientoBarrerasBo mantenimientoBarrerasBo;
	
	BaseCalculoBo baseCalculoBo;
	
	CancelacionBo cancelacionBo;

    EjercicioBo ejercicioBo ;
    
    IndPagoCobroBo indPagoCobroBo;

    MantProdCompuestoBo mantProdCompuestoBo;
    
    BoletaProdCompuestoBo boletaProdCompuestoBo;
    
    PeticionesBo peticionesBo;
    
    ContrapartidasRepoBo contrapartidasRepoBo;
    
    ConfiguracionesContablesBo configuracionesContablesBo;
    
    EmirBo emirBo;

//    EmirBo emirBo;

		//RNS DEB
	private MantoqeBarreraBo mantoqeBarreraBo;
	//RNS FIN

	private <T> T getBo(T bo, String expression, Class<T> clazz) {
		if (bo == null) {
			return Expressions.instance().createValueExpression(expression,
					clazz).getValue();
		}
		return bo;
	}


	// Pongo el ScopeType.CONVERSATION porque se trata de una combo que puede cambiar
	// al darse de alta personas
	// Si los datos no van a cambiar pondremos el ScopeType.APPLICATION.
	@Factory(value = "listaPersonasCombo", scope = ScopeType.CONVERSATION)
	public List<TbPersona> buildListaPersonas() {
		usuarioBo=getBo(usuarioBo,"#{usuarioBo}",UsuarioBo.class);
		return usuarioBo.obtenerPersonasSelect();
	}

	@Factory(value = "listaDivisas", scope = ScopeType.EVENT)
	public List<Divisa> buildListaDivisas(boolean esCotizable) {
		divisaBo=getBo(divisaBo,"#{divisaBo}",DivisaBo.class);
		return divisaBo.obtenerDivisaSelect(esCotizable);
	}
	@Factory(value = "listaDivisasDistinc", scope = ScopeType.CONVERSATION)
	public List<Divisa> buildListaDivisas() {
		divisaBo=getBo(divisaBo,"#{divisaBo}",DivisaBo.class);
		return divisaBo.obtenerDivisaDistinct();
	}

	@Factory(value = "listaPlazos", scope = ScopeType.CONVERSATION)
	public List<Plazo> buildListaPlazos() {
		plazoBo=getBo(plazoBo,"#{plazoBo}",PlazoBo.class);
		return plazoBo.obtenerPlazosSelect();
	}

	// Pongo el ScopeType.CONVERSATION porque se trata de una combo que puede cambiar
	// al darse de alta plazos
	// Si los datos no van a cambiar pondremos el ScopeType.APPLICATION.
	@Factory(value = "listaUnidadCombo", scope = ScopeType.CONVERSATION)
	public List<UnidadPlazo> buildListaUnidad() {
		plazoBo=getBo(plazoBo,"#{plazoBo}",PlazoBo.class);
		return plazoBo.obtenerUnidadSelect();
	}

	@Factory(value = "listaTipoSubyacente", scope = ScopeType.CONVERSATION)
	public List<TipoSubyacente> buildListaTiposSubyacente() {
		subyacenteBo=getBo(subyacenteBo,"#{subyacenteBo}",SubyacenteBo.class);
		return subyacenteBo.obtenerTiposSubyacenteSelect();
	}

//	@Factory(value = "listaTipoSubyacenteProducat", scope = ScopeType.CONVERSATION)
//	public  List<TipoSubyacente> buildListaTipoSubyacenteProducat(ProductoCatalogo producto){
//		subyacenteBo=getBo(subyacenteBo,"#{subyacenteBo}",SubyacenteBo.class);
//		return subyacenteBo.obtenerTiposSubyacenteProducatSelect(producto);
//	}
	
	
	
	@Factory(value = "listaPlazas", scope = ScopeType.CONVERSATION)
	public List<Plaza> buildListaPlazas() {
		subyacenteBo=getBo(subyacenteBo,"#{subyacenteBo}",SubyacenteBo.class);
		return subyacenteBo.obtenerPlazasSelect();
	}

	@Factory(value = "listaPaginas", scope = ScopeType.CONVERSATION)
	public List<Pagina> buildListaPaginas() {
		subyacenteBo=getBo(subyacenteBo,"#{subyacenteBo}",SubyacenteBo.class);
		return subyacenteBo.obtenerPaginasSelect();
	}

	@Factory(value = "listaUnidades", scope = ScopeType.CONVERSATION)
	public List<Unidad> buildListaUnidades() {
		subyacenteBo=getBo(subyacenteBo,"#{subyacenteBo}",SubyacenteBo.class);
		return subyacenteBo.obtenerUnidadesSelect();
	}

	@Factory(value = "listaPerfiles", scope = ScopeType.CONVERSATION)
	public ArrayList<Integer> buildListaPerfiles() {
		perfilBo=getBo(perfilBo,"#{perfilBo}",PerfilBo.class);
		return perfilBo.obtenerPerfilesSelect();
	}

	@Factory(value = "listaPeriodicidades", scope = ScopeType.CONVERSATION)
	public List<DescripcionAviso> buildListaPeriodicidades() {
		avisoBo=getBo(avisoBo,"#{avisoBo}",AvisoBo.class);
		return avisoBo.obtenerPeriodicidadesSelect();
	}

	@Factory(value = "listaContrapartidas", scope = ScopeType.CONVERSATION)
	public List<Contrapartida> buildListaContrapartidas() {
		suscripcionBo=getBo(suscripcionBo,"#{suscripcionBo}",SuscripcionBo.class);
		return suscripcionBo.obtenerContrapartidasSelect();

	}

	@Factory(value = "listaTiposContrapartida", scope = ScopeType.CONVERSATION)
	public List<TipoContrapartida> buildListaTipoContrapartida() {
		contrapartidaBo=getBo(contrapartidaBo,"#{contrapartidaBo}",ContrapartidaBo.class);
		return contrapartidaBo.obtenerTipoContrapartidaSelect();
	}

	@Factory(value = "listaIactivo", scope = ScopeType.CONVERSATION)
	public List<IndicadorActiva> buildListaIactivo() {
		suscripcionBo=getBo(suscripcionBo,"#{suscripcionBo}",SuscripcionBo.class);
		return suscripcionBo.obtenerIactivoSelect();

	}

	@Factory(value = "listaPaises", scope = ScopeType.CONVERSATION)
	public List<CodigoPais> buildPaises() {
		contrapartidaBo=getBo(contrapartidaBo,"#{contrapartidaBo}",ContrapartidaBo.class);
		return contrapartidaBo.obtenerPaisSelect();
	}

	@Factory(value = "listaEstadosDocCo", scope = ScopeType.CONVERSATION)
	public List<EstadoDocumentoContrapartida> buildListaEstadosDocumentoContrapartidas() {
		docsContrapartidaBo=getBo(docsContrapartidaBo,"#{docsContrapartidaBo}",DocsContrapartidaBo.class);
		return docsContrapartidaBo.obtenerEstadoDocsContrapartidaSelect();
	}

	@Factory(value = "listaMarcasDocCo", scope = ScopeType.CONVERSATION)
	public List<DescripcionMarcaDocumento> buildListaMarcasDocumentoContrapartidas() {
		docsContrapartidaBo=getBo(docsContrapartidaBo,"#{docsContrapartidaBo}",DocsContrapartidaBo.class);
		return docsContrapartidaBo.obtenerMarcasDocsContrapartidaSelect();
	}

	@Factory(value= "listaEntidadOperacion", scope = ScopeType.CONVERSATION)
	public List<DescripcionEntidadOperacion> listaDescripcionEntidadOperacions() {
		boletasBo=getBo(boletasBo,"#{boletasBo}",BoletasBo.class);
		return boletasBo.getDescripcionEntidadOperacion(false);
	}
	
	
	@Factory(value = "listaUndidadNegocioSelect", scope = ScopeType.EVENT)
	public List<UnidadNegocio> buildListaUndidadNegocioSelect(
			boolean muestraOtros) {
		contrapartidaBo=getBo(contrapartidaBo,"#{contrapartidaBo}",ContrapartidaBo.class);
		return contrapartidaBo.obtenerUnidadNegocioSelect(muestraOtros);
	}

	@Factory(value = "listaEstadosDocumento", scope = ScopeType.CONVERSATION)
	public List<EstadoDocumento> buildListaEstadosDocumento() {
		mantTiposDocumentoBo=getBo(mantTiposDocumentoBo,"#{mantTiposDocumentoBo}",MantTiposDocumentoBo.class);
		return mantTiposDocumentoBo.obtenerEstadoTipoDocumentoSelect();
	}

	@Factory(value = "listaProductos", scope = ScopeType.CONVERSATION)
	public List<Producto> buildListaProductos() {
		peticionBo=getBo(peticionBo,"#{peticionBo}",PeticionBo.class);
		return peticionBo.obtenerProductosSelect();
	}

	//RNS DEB
	@Factory(value = "listaDescripcionPata", scope = ScopeType.CONVERSATION)
	public List<DescripcionPata> buildListaDescripcionPata() {
		mantoqeBarreraBo=getBo(mantoqeBarreraBo,"#{mantoqeBarreraBo}",MantoqeBarreraBo.class);
		return mantoqeBarreraBo.obtenerPataSelect();
	}
	//RNS FIN

	@Factory(value = "listaTipos", scope = ScopeType.CONVERSATION)
	public List<ListasTipo> buildListaTipos() {
		peticionBo=getBo(peticionBo,"#{peticionBo}",PeticionBo.class);
		return peticionBo.obtenerListasTipoSelect();
	}

	@Factory(value = "listaAgrupContra", scope = ScopeType.CONVERSATION)
	public List<AgrupContrapartida> buildListaAgrupContra() {
		agrupContrapartidaBo=getBo(agrupContrapartidaBo,"#{agrupContrapartidaBo}",AgrupContrapartidaBo.class);
		return agrupContrapartidaBo.obtenerAgrupContrapartidasSelect();
	}
	
	@Factory(value = "listaAgrupContraConContr", scope = ScopeType.CONVERSATION)
	public List<AgrupContrapartida> buildListaAgrupContraConContra() {
		agrupContrapartidaBo=getBo(agrupContrapartidaBo,"#{agrupContrapartidaBo}",AgrupContrapartidaBo.class);
		return agrupContrapartidaBo.obtenerAgrupContrapartidasConContraSelect();
	}	

	@Factory(value = "listaParametros", scope = ScopeType.CONVERSATION)
	public List<String> buildListaTiposParametro() {
		parametroBo=getBo(parametroBo,"#{parametroBo}",ParametroBo.class);
		return parametroBo.obtenerParametrosSelect();
	}

	@Factory(value = "listaProdParamCesion", scope = ScopeType.CONVERSATION)
	public List<Producto> buildListaProdParamCesion() {
		parametrosCesionBo=getBo(parametrosCesionBo,"#{parametrosCesionBo}",ParametrosCesionBo.class);
		return parametrosCesionBo.listaProductos();
	}

	@Factory(value = "listaProdParamCesionPro", scope = ScopeType.CONVERSATION)
	public List<Producto> buildListaProdParamCesionPro(String proyecto) {
		parametrosCesionBo=getBo(parametrosCesionBo,"#{parametrosCesionBo}",ParametrosCesionBo.class);
		return parametrosCesionBo.listaProductos(proyecto);
	}
	
	@Factory(value = "listaConceptos", scope = ScopeType.CONVERSATION)
	public List<DescripcionHistoricoConcepto> buildListaConceptos() {
		parametrosCesionBo=getBo(parametrosCesionBo,"#{parametrosCesionBo}",ParametrosCesionBo.class);
		return parametrosCesionBo.listaConcepto();
	}

	@Factory(value = "listaTiposCesion", scope = ScopeType.CONVERSATION)
	public List<DescripcionParametroCesionTipoCesion> buildListaTiposCesion() {
		parametrosCesionBo=getBo(parametrosCesionBo,"#{parametrosCesionBo}",ParametrosCesionBo.class);
		return parametrosCesionBo.listaTiposCesion();
	}

	@Factory(value = "listaTipoOperaciones", scope = ScopeType.CONVERSATION)
	public List<DescripcionParametroCesionTipoOperacion> buildListaTipoOperaciones() {
		parametrosCesionBo=getBo(parametrosCesionBo,"#{parametrosCesionBo}",ParametrosCesionBo.class);
		return parametrosCesionBo.listaTipoOperacion();
	}

	@Factory(value = "listaTiposConcepto", scope = ScopeType.CONVERSATION)
	public List<DescripcionParametroCesionTipoConcepto> buildListaTiposConcepto() {
		parametrosCesionBo=getBo(parametrosCesionBo,"#{parametrosCesionBo}",ParametrosCesionBo.class);
		return parametrosCesionBo.listaTipoConceptos();
	}

	// @Factory(value="listaFechasEnvio", scope=ScopeType.CONVERSATION)
	// public List<Date> buildListafechasEnvio() {
	// return swiftBo.obtenerFechasEnvioSelect();
	// }

	@Factory(value = "listaDealTypes", scope = ScopeType.CONVERSATION)
	public List<DescripcionDealtype> buildListaDealTypes() {
		avisosCapturaBo=getBo(avisosCapturaBo,"#{avisosCapturaBo}",AvisosCapturaBo.class);
		return avisosCapturaBo.obtenerDescripcionDealTypeSelect();
	}

	@Factory(value = "listaSubyacentes", scope = ScopeType.CONVERSATION)
	public List<Subyacente> buildListaSubyacente() {
		subyacenteBo=getBo(subyacenteBo,"#{subyacenteBo}",SubyacenteBo.class);
		return subyacenteBo.buscarSubyacentesCombo();
	}

	@Factory(value = "listaEntidades", scope = ScopeType.CONVERSATION)
	public List<Short> buildListaEntidades() {
		ajustesManualesBo=getBo(ajustesManualesBo,"#{ajustesManualesBo}",AjustesManualesBo.class);
		return ajustesManualesBo.obtenerEntidadSelect();
	}

	@Factory(value = "listaOficinas", scope = ScopeType.CONVERSATION)
	public List<Short> buildListaOficinas() {
		ajustesManualesBo=getBo(ajustesManualesBo,"#{ajustesManualesBo}",AjustesManualesBo.class);
		return ajustesManualesBo.obtenerOficinaSelect();
	}

	@Factory(value = "listaProdOper", scope = ScopeType.CONVERSATION)
	public List<String> buildListaProdOper() {
		ajustesManualesBo=getBo(ajustesManualesBo,"#{ajustesManualesBo}",AjustesManualesBo.class);
		return ajustesManualesBo.obtenerProdOperSelect();
	}

	@Factory(value = "listaCodOpera", scope = ScopeType.CONVERSATION)
	public List<String> buildListaCodOpera() {
		ajustesManualesBo=getBo(ajustesManualesBo,"#{ajustesManualesBo}",AjustesManualesBo.class);
		return ajustesManualesBo.obtenerCodOperaSelect();
	}

	@Factory(value = "listaCodProd", scope = ScopeType.CONVERSATION)
	public List<String> buildListaCodProd() {
		ajustesManualesBo=getBo(ajustesManualesBo,"#{ajustesManualesBo}",AjustesManualesBo.class);
		return ajustesManualesBo.obtenerCodProdSelect();
	}

	@Factory(value = "listaMomentos", scope = ScopeType.CONVERSATION)
	public List<String> buildListaMomentos() {
		ajustesManualesBo=getBo(ajustesManualesBo,"#{ajustesManualesBo}",AjustesManualesBo.class);
		return ajustesManualesBo.obtenerMomentoSelect();
	}

	@Factory(value = "listaCodImporte", scope = ScopeType.CONVERSATION)
	public List<String> buildListaCodImporte() {
		ajustesManualesBo=getBo(ajustesManualesBo,"#{ajustesManualesBo}",AjustesManualesBo.class);
		return ajustesManualesBo.obtenerCodImporteSelect();
	}

	@Factory(value = "listaFechasEnvio", scope = ScopeType.CONVERSATION)
	public List<Date> buildListafechasEnvio() {
		swiftBo=getBo(swiftBo,"#{swiftBo}",SwiftBo.class);
		return swiftBo.obtenerFechasEnvioSelect();
	}

	// Gestion de Swift
	@Factory(value = "listaDescripcionEstadosSwift", scope = ScopeType.CONVERSATION)
	public List<DescripcionEstadosSwift> buildListaDescripcionEstadosSwift() {
		swiftBo=getBo(swiftBo,"#{swiftBo}",SwiftBo.class);
		return swiftBo.obtenerEstadosSwiftSelect();
	}

	@Factory(value = "listaTiposSwift", scope = ScopeType.CONVERSATION)
	public List<MantenimientoMensajes> buildListaTiposSwift(String projecte) {
		swiftBo=getBo(swiftBo,"#{swiftBo}",SwiftBo.class);
		return swiftBo.obtenerTiposSwiftSelect(projecte);
	}

	@Factory(value = "listaDivisaDistinct", scope = ScopeType.CONVERSATION)
	public List<Divisa> buildDivisaDistinct() {
		divisaBo=getBo(divisaBo,"#{divisaBo}",DivisaBo.class);
		return divisaBo.obtenerDivisaDistinct();
	}

	@Factory(value = "listaProdGrupCont", scope = ScopeType.CONVERSATION)
	public List<Producto> buildListaProdGrupCont() {
		grupoContableBo=getBo(grupoContableBo,"#{grupoContableBo}",GrupoContableBo.class);
		return grupoContableBo.obtenerListaDescripProducto();
	}

	@Factory(value = "listaTipoContable", scope = ScopeType.CONVERSATION)
	public List<TiposContable> buildListaTipoContable() {
		grupoContableBo=getBo(grupoContableBo,"#{grupoContableBo}",GrupoContableBo.class);
		return grupoContableBo.obtenerListaTipoContable();
	}

	@Factory(value = "listaEventos", scope = ScopeType.CONVERSATION)
	public List<DescIndSitua> buildListaEventos() {
		confirmacionesBo=getBo(confirmacionesBo,"#{confirmacionesBo}",ConfirmacionesBo.class);
		return confirmacionesBo.obtenerListaEventos();
	}

	@Factory(value = "listaIdiomaTipoCambio", scope = ScopeType.CONVERSATION)
	public List<DescripcionIdiomaTipCambio> buildListaIdiomaTipoCambio() {
		confirmacionesBo=getBo(confirmacionesBo,"#{confirmacionesBo}",ConfirmacionesBo.class);
		return confirmacionesBo.obtenerListaIdiomaTipoCambio();
	}
	
//	@Factory(value = "listaModelos", scope = ScopeType.CONVERSATION)
//	public List<ModeloConfirmacion> buildListaModelo(String productoId,
//			String indSituacion) {
//		confirmacionesBo=getBo(confirmacionesBo,"#{confirmacionesBo}",ConfirmacionesBo.class);
//		return confirmacionesBo.obtenerListaModelos(productoId, indSituacion);
//	}

	@Factory(value = "listaTodosProductos", scope = ScopeType.CONVERSATION)
	public List<Producto> buildListaTodosProductos() {
		confirmacionesBo=getBo(confirmacionesBo,"#{confirmacionesBo}",ConfirmacionesBo.class);
		return confirmacionesBo.obtenerListaDescripProducto();
	}

	@Factory(value = "listaProductosProyecto", scope = ScopeType.CONVERSATION)
	public List<Producto> buildListaProductos(String proyecto) {
		confirmacionesBo=getBo(confirmacionesBo,"#{confirmacionesBo}",ConfirmacionesBo.class);
		return confirmacionesBo.obtenerListaDescripProducto(proyecto);
	}
	
	@Factory(value = "listaTipoOper", scope = ScopeType.CONVERSATION)
	public List<TipoOperacion> buildListaTipoOper() {
		parametrosLiquidacionBo=getBo(parametrosLiquidacionBo,"#{parametrosLiquidacionBo}",ParametrosLiquidacionBo.class);
		return parametrosLiquidacionBo.obtenerListaTipoOperacion();
	}

	@Factory(value = "listaTipoPago", scope = ScopeType.CONVERSATION)
	public List<DescripcionTipoDestino> buildListaTipoPago() {
		parametrosLiquidacionBo=getBo(parametrosLiquidacionBo,"#{parametrosLiquidacionBo}",ParametrosLiquidacionBo.class);
		return parametrosLiquidacionBo.obtenerListaTiposPago();
	}

	@Factory(value = "listaCanalLiqui", scope = ScopeType.CONVERSATION)
	public List<DescCanalLiqui> buildListaCanalLiqui() {
		ajustesManualesBo=getBo(ajustesManualesBo,"#{ajustesManualesBo}",AjustesManualesBo.class);
		return ajustesManualesBo.obtenerCanalLiquiSelect();
	}

	/*
	 * Pantalla Alta Operaciones (BoletasAlta)
	 */
	@Factory(value = "procedenciaList", scope = ScopeType.CONVERSATION)
	public List<ProcedenciaProducto> buildListaProcedencia() {
		boletasBo=getBo(boletasBo,"#{boletasBo}",BoletasBo.class);
		return boletasBo.getProcedenciaProductos();
	}

	@Factory(value = "modeloList", scope = ScopeType.CONVERSATION)
	public List<ModeloProducto> buildListaModelo() {
		boletasBo=getBo(boletasBo,"#{boletasBo}",BoletasBo.class);
		return boletasBo.getModeloProductos();
	}

//	@Factory(value = "productoList", scope = ScopeType.CONVERSATION)
//	public List<String> buildListaProducto() {
//		return boletasBo.obtenerProductoList(null);
//	}


	@Factory(value = "ListaDescripcionClaseInt", scope = ScopeType.CONVERSATION)
	public List<DescripcionClaseInt> buildListaDescripcionClaseInt() {
		boletasBo = getBo(boletasBo, "#{boletasBo}", BoletasBo.class);
		return boletasBo.getDescripcionClaseInt();
	}

	@Factory(value = "ListaDescripcionAmortizaciones", scope = ScopeType.CONVERSATION)
	public List<DescripcionAmortizacion> getDescripcionAmortizacions() {
		boletasBo = getBo(boletasBo, "#{boletasBo}", BoletasBo.class);
		return boletasBo.getDescripcionAmortizacions();
	}

	@Factory(value = "ListaDescripcionTipoAjuste", scope = ScopeType.CONVERSATION)
	public List<DescripcionTipoAjuste> getDescripcionTipoAjustes() {
		boletasBo = getBo(boletasBo, "#{boletasBo}", BoletasBo.class);
		return boletasBo.getDescripcionTipoAjustes();
	}

	@Factory(value = "ListaTipoCurvas", scope = ScopeType.CONVERSATION)
	public List<TipoCurva> getTipoCurvas() {
		boletasBo = getBo(boletasBo, "#{boletasBo}", BoletasBo.class);
		return boletasBo.getTipoCurvas();
	}
	
	@Factory(value = "listaEntidadesContables", scope = ScopeType.CONVERSATION)
	public List<String> buildListaEntidadesContables() {
		parametrosLiquidacionBo=getBo(parametrosLiquidacionBo,"#{parametrosLiquidacionBo}",ParametrosLiquidacionBo.class);
		return parametrosLiquidacionBo.obtenerEntidadesSelect(Constantes.NOMBRE_PROYECTO_DERI);
	}

	@Factory(value = "listaEntidadesContablesProyecto", scope = ScopeType.CONVERSATION)
	public List<String> buildListaEntidadesContablesProyecto(String proyecto) {
		parametrosLiquidacionBo=getBo(parametrosLiquidacionBo,"#{parametrosLiquidacionBo}",ParametrosLiquidacionBo.class);
		return parametrosLiquidacionBo.obtenerEntidadesSelect(proyecto);
	}

	@Factory(value = "listaGrupoContables", scope = ScopeType.CONVERSATION)
	public List<DescripcionGruposContables> buildListaGruposContables() {
		parametrosLiquidacionBo=getBo(parametrosLiquidacionBo,"#{parametrosLiquidacionBo}",ParametrosLiquidacionBo.class);
		return parametrosLiquidacionBo.obtenerGruposContablesSelect();
	}

	@Factory(value = "listaDivisaOrden", scope = ScopeType.CONVERSATION)
	public List<Divisa> buildListaDivisaOrden() {
		ordenBo=getBo(ordenBo,"#{ordenBo}",OrdenBo.class);
		return ordenBo.obtenerDivisasOrdenSelect();
	}

	@Factory(value = "listaDescripcionProducto", scope = ScopeType.CONVERSATION)
	public List<String> buildListaDescripcionProducto() {
		erroresCapturaBo=getBo(erroresCapturaBo,"#{erroresCapturaBo}",ErroresCapturaBo.class);
		return erroresCapturaBo.obtenerDescripcionProductoSelect();
	}

	@Factory(value = "listaUnidadNegocioOrdenSelect", scope = ScopeType.CONVERSATION)
	public List<UnidadNegocio> buildListaUnidadNegocioSelect() {
		ordenBo=getBo(ordenBo,"#{ordenBo}",OrdenBo.class);
		return ordenBo.obtenerUnidadNegocioOrdenSelect();
	}

	@Factory(value = "listaTipoListado", scope = ScopeType.CONVERSATION)
	public List<Listados> buildListadoVisibilidad() {
		listadosVisibilidadBo=getBo(listadosVisibilidadBo,"#{listadosVisibilidadBo}",ListadosVisibilidadBo.class);
		return listadosVisibilidadBo.obtenerInformesSelect();
	}

	@Factory(value = "listaIdiomaSelect", scope = ScopeType.CONVERSATION)
	public List<Idioma> buildListaIdiomaSelect() {
		ordenBo=getBo(ordenBo,"#{ordenBo}",OrdenBo.class);
		return ordenBo.obtenerIdiomaSelect();
	}

	@Factory(value = "listaEntidadesAnexoCuenta", scope = ScopeType.EVENT)
	public List<String> buildListaEntidadesAnexoCuenta(String proyecto) {
		anexoOperacionBo=getBo(anexoOperacionBo,"#{anexoOperacionBo}",AnexoOperacionBo.class);
		return anexoOperacionBo.obtenerEntidadesSelect(proyecto);
	}

	@Factory(value = "listaGCAnexoCuenta", scope = ScopeType.CONVERSATION)
	public List<DescripcionGruposContables> buildListaGCAnexoCuenta() {
		anexoOperacionBo=getBo(anexoOperacionBo,"#{anexoOperacionBo}",AnexoOperacionBo.class);
		return anexoOperacionBo.obtenerGruposContablesSelect();
	}
	
	@Factory(value = "listaSubyacentesPorTipo", scope = ScopeType.EVENT)
	public List<Subyacente> buildListaSubyacentesPorTipo(String tipoSubya) {
		historicoSubyacenteBo=getBo(historicoSubyacenteBo,"#{historicoSubyacenteBo}",HistoricoSubyacenteBo.class);
		return historicoSubyacenteBo.obtenerCondindic(tipoSubya);
	}

	@Factory(value = "listaModeloCampanyaSelect", scope = ScopeType.CONVERSATION)
	public List<DescripcionModeloCampanya> buildModeloCampanyaSelect() {
		campanyaBo=getBo(campanyaBo,"#{campanyaBo}",CampanyaBo.class);
		return campanyaBo.obtenerDescripcionModeloSelect();
	}

	@Factory(value = "listaDivisaCampanyaSelect", scope = ScopeType.CONVERSATION)
	public List<Divisa> buildlDivisaCampanyaSelect() {
		campanyaBo=getBo(campanyaBo,"#{campanyaBo}",CampanyaBo.class);
		return campanyaBo.obtenerDivisaCampanyaSelect();
	}

	@Factory(value = "listaIndicadorOperacionesCoberturaSelect", scope = ScopeType.CONVERSATION)
	public List<IndicadorOperacionesCobertura> buildlIndicadorOperacionesCoberturaSelect() {
		campanyaBo=getBo(campanyaBo,"#{campanyaBo}",CampanyaBo.class);
		return campanyaBo.obtenerIndicadorOperacionesCoberturaSelect();
	}

	@Factory(value = "listaUnidadNegocioSelect", scope = ScopeType.CONVERSATION)
	public List<UnidadNegocio> buildlUnidadNegocioSelectSelect() {
		campanyaBo=getBo(campanyaBo,"#{campanyaBo}",CampanyaBo.class);
		return campanyaBo.obtenerUnidadNegocioSelect();
	}

	@Factory(value = "listaGrupoContableAntesValorSelect", scope = ScopeType.CONVERSATION)
	public List<GrupoContableSelect> buildGrupoContableAntesValorSelect(
			String modeloCampanya) {
		List<GrupoContableSelect> list = new ArrayList<GrupoContableSelect>();
		if (!GenericUtils.isNullOrBlank(modeloCampanya)) {
			campanyaBo=getBo(campanyaBo,"#{campanyaBo}",CampanyaBo.class);
			list = campanyaBo
					.obtenerGrupoContableAntesValorSelect(modeloCampanya);
		}
		return list;
	}

	@Factory(value = "listaGrupoContableDespuesValorSelect", scope = ScopeType.CONVERSATION)
	public List<GrupoContableSelect> buildListaGrupoContableDespuesValorSelect(
			DescripcionModeloCampanya modeloCampanya) {
		List<GrupoContableSelect> list = new ArrayList<GrupoContableSelect>();
		if (!GenericUtils.isNullOrBlank(modeloCampanya)
				&& !GenericUtils.isNullOrBlank(modeloCampanya.getCodigo())) {
			campanyaBo=getBo(campanyaBo,"#{campanyaBo}",CampanyaBo.class);
			Campanya campanya = new Campanya();
			campanya.setModeloCampanya(modeloCampanya);
			list = campanyaBo.obtenerListaGruposContablesSelect(campanya);
		}
		return list;
	}
	
	@Factory(value="listaGrupoContable", scope=ScopeType.EVENT)
	public List<GrupoContableSelect> buildListaGrupoContable(Campanya campanya) {
		campanyaBo=getBo(campanyaBo,"#{campanyaBo}",CampanyaBo.class);
		return campanyaBo.obtenerListaGruposContablesSelect(campanya);
	}
	// Start of AdminConfi	
	@Factory(value = "listaTipoConfirmacion", scope = ScopeType.CONVERSATION)
	@CachedMethod(name = "listaTipoConfirmacion", region = Region.UN_DIA)
	public List<DescripcionTipoConfirmacion> buildListaTipoConfirmacion() {
		admconfirmacionesBo=getBo(admconfirmacionesBo,"#{admconfirmacionesBo}",ConfirmacionOperacionesBo.class);
		return admconfirmacionesBo.buscarAdmConfirmaciones();
	}

	@Factory(value = "listaIdioma", scope = ScopeType.CONVERSATION)
	@CachedMethod(name = "listaIdioma", region = Region.UN_DIA)
	public List<Idioma> buildListaIdioma() {
		admconfirmacionesBo=getBo(admconfirmacionesBo,"#{admconfirmacionesBo}",ConfirmacionOperacionesBo.class);
		return admconfirmacionesBo.buscarIdioma();
	}

	@Factory(value = "listaCanal", scope = ScopeType.CONVERSATION)
	@CachedMethod(name = "listaCanal", region = Region.UN_DIA)
	public List<CanalConfirmacion> buildListaCanal() {
		admconfirmacionesBo=getBo(admconfirmacionesBo,"#{admconfirmacionesBo}",ConfirmacionOperacionesBo.class);
		return admconfirmacionesBo.buscarCanal();
	}
	@Factory(value = "listaPdtoContable", scope = ScopeType.CONVERSATION)
	@CachedMethod(name = "listaPdtoContable", region = Region.UN_DIA)
	public List<Producto> buildListaPdtoContable() {
		admconfirmacionesBo=getBo(admconfirmacionesBo,"#{admconfirmacionesBo}",ConfirmacionOperacionesBo.class);
		return admconfirmacionesBo.buscarPdtoContable();
	}

	@Factory(value = "listaPdtoCatalogo", scope = ScopeType.CONVERSATION)
	@CachedMethod(name = "listaPdtoCatalogo", region = Region.UN_DIA)
	public List<ProductoCatalogo> buildListaPdtoCatalogo() {
		admconfirmacionesBo=getBo(admconfirmacionesBo,"#{admconfirmacionesBo}",ConfirmacionOperacionesBo.class);
		return admconfirmacionesBo.buscarPdtoCatalogo();
	}

	@Factory(value = "listaEstadoConfirmacion", scope = ScopeType.CONVERSATION)
	@CachedMethod(name = "listaEstadoConfirmacion", region = Region.UN_DIA)
	public List<DescripcionEstadoConfirmacion> buildListaEstadoConfirmacion() {
		admconfirmacionesBo=getBo(admconfirmacionesBo,"#{admconfirmacionesBo}",ConfirmacionOperacionesBo.class);
		return admconfirmacionesBo.buscarEstadoConfirmacion();
	}
	@Factory(value = "listaTipoContrapartida", scope = ScopeType.CONVERSATION)
	@CachedMethod(name = "listaTipoContrapartida", region = Region.UN_DIA)
	public List<TipoContrapartida> buscarTipoContrapartida() {
		admconfirmacionesBo=getBo(admconfirmacionesBo,"#{admconfirmacionesBo}",ConfirmacionOperacionesBo.class);
		return admconfirmacionesBo.buscarTipoContrapartida();
	}
	@Factory(value = "listaSentido", scope = ScopeType.CONVERSATION)
	@CachedMethod(name = "listaSentido", region = Region.UN_DIA)
	public List<DescripcionSentido> buscarSentido() {
		admconfirmacionesBo=getBo(admconfirmacionesBo,"#{admconfirmacionesBo}",ConfirmacionOperacionesBo.class);
		return admconfirmacionesBo.buscarSentido();
	}
	// End of AdminConfi

	@Factory(value="listaAccionesAvisosSelect", scope=ScopeType.CONVERSATION)
	public List<DescripcionAccionesAvisos> buildAccionesAvisosSelect() {
		eventosAgendaBo	=getBo(eventosAgendaBo	,"#{eventosAgendaBo}",EventosAgendaBo.class);
		return eventosAgendaBo.cargarAccionesAvisosSelect();
	}
	
	@Factory(value="listaClaseFechaSelect", scope=ScopeType.CONVERSATION)
	public List<DescripcionClaseFecha> buildClaseFechaSelect() {
		historicoFechaFormulaBo=getBo(historicoFechaFormulaBo,"#{historicoFechaFormulaBo}",HistoricoFechaFormulaBo.class); 
		return historicoFechaFormulaBo.obtenerClase();
	}
	
	@Factory(value="listaClaseFechaSelectSinCupon", scope=ScopeType.CONVERSATION)
	public List<DescripcionClaseFecha> buildClaseFechaSelectSinCupon() {
		historicoFechaFormulaBo=getBo(historicoFechaFormulaBo,"#{historicoFechaFormulaBo}",HistoricoFechaFormulaBo.class); 
		return historicoFechaFormulaBo.obtenerClaseSinCupon();
	}
	
	@Factory(value="listaFactorLiquidacionFechaSelect", scope=ScopeType.CONVERSATION)
	public List<DescripcionFactorLiquidacion> buildFactorLiquidacionFechaSelect() {
		historicoFechaFormulaBo=getBo(historicoFechaFormulaBo,"#{historicoFechaFormulaBo}",HistoricoFechaFormulaBo.class); 
		return historicoFechaFormulaBo.obtenerFactorLiquidacion();
	}
	
	@Factory(value="listaPrimerOperadorSelect", scope=ScopeType.CONVERSATION)
	public List<DescripcionOperadorPrimer> buildPimerOperadorSelect() {
		historicoFechaFormulaBo=getBo(historicoFechaFormulaBo,"#{historicoFechaFormulaBo}",HistoricoFechaFormulaBo.class); 
		return historicoFechaFormulaBo.obtenerPrimerOperador();
	}
	
	@Factory(value="listaSegundoOperadorSelect", scope=ScopeType.CONVERSATION)
	public List<DescripcionOperadorSegundo> buildSegundoOperadorSelect() {
		historicoFechaFormulaBo=getBo(historicoFechaFormulaBo,"#{historicoFechaFormulaBo}",HistoricoFechaFormulaBo.class); 
		return historicoFechaFormulaBo.obtenersegundoOperador();
	}
	
	@Factory(value="listaOperadorSupuesto", scope=ScopeType.CONVERSATION)
	public List<DescripcionOperadorSupuesto> buildOperadorSupuestoSelect(){
		condFijacionBo=getBo(condFijacionBo,"#{condFijacionBo}",CondFijacionBo.class); 
		return condFijacionBo.obtenerOperadorSupuesto();
	}
	
	@Factory(value="listaRelacionesSupuestas", scope=ScopeType.CONVERSATION)
	public List<DescripcionRelacionSupuesto> buildRelacionesSupuestasSelect(){
		condFijacionBo=getBo(condFijacionBo,"#{condFijacionBo}",CondFijacionBo.class); 
		return condFijacionBo.obtenerRelacionSupuesto();
	}
	
/*PANTALLA DETALLE PRIMAS*/
	
	@Factory(value = "ListaDetallePrimasConcepto", scope = ScopeType.CONVERSATION)
	public List<DescripcionHisttramTipoConcepto> buildListaDetallePrimasConcepto() {
		detallePrimasBo=getBo(detallePrimasBo,"#{detallePrimasBo}",DetallePrimasBo.class); 
		return detallePrimasBo.obtenerConcepto();
	}
	@Factory(value = "ListaDetallePrimasConcepto2", scope = ScopeType.CONVERSATION)
	public List<DescripcionHisttramTipoConcepto> buildListaDetallePrimasConcepto2() {
		detallePrimasBo=getBo(detallePrimasBo,"#{detallePrimasBo}",DetallePrimasBo.class); 
		return detallePrimasBo.obtenerConcepto2();
	}
	@Factory(value = "ListaDetallePrimasPagoCobro", scope = ScopeType.CONVERSATION)
	public List<DescripcionTipoOperacionHistderi> buildListaDetallePrimasPagoCobro() {
		detallePrimasBo=getBo(detallePrimasBo,"#{detallePrimasBo}",DetallePrimasBo.class); 
		return detallePrimasBo.obtenerPagoCobro();
	}
	@Factory(value = "ListaDetallePrimasDivisa", scope = ScopeType.CONVERSATION)
	public List<Divisa> buildListaDetallePrimasDivisa() {
		detallePrimasBo=getBo(detallePrimasBo,"#{detallePrimasBo}",DetallePrimasBo.class); 
		return detallePrimasBo.obtenerDivisa();
	}
		
	@Factory(value="listaEstadoLiquidacion", scope=ScopeType.CONVERSATION)
	public List<DescripcionEstadoLiquidacion> buildEstadoLiquidacionSelect(){
		liquidacionesBo=getBo(liquidacionesBo,"#{liquidacionesBo}",LiquidacionesBo.class); 	
		return liquidacionesBo.obtenerEstadoLiquidacion();
	}
	
	@Factory(value="listaSituacionLiquidacion", scope=ScopeType.CONVERSATION)
	public List<DescripcionSituacionLiquidacion> buildSituacionLiquidacionSelect(){
		liquidacionesBo=getBo(liquidacionesBo,"#{liquidacionesBo}",LiquidacionesBo.class); 	
		return liquidacionesBo.obtenerSituacionLiquidacion();
	}	
	@Factory(value="listaTipoOperSelect", scope=ScopeType.CONVERSATION)
	public List<DescripcionTipoOperacionHistderi> buildTipoOperAltaSelect(){
		altaTramosBo=getBo(altaTramosBo,"#{altaTramosBo}",AltaTramosBo.class);
		return altaTramosBo.buildTipoOperAltaSelect();
	}
	
	@Factory(value="listaBaseCalculo", scope=ScopeType.CONVERSATION)
	public List<BaseCalculo> obtenerBaseCalcSelect() {
		baseCalculoBo=getBo(baseCalculoBo,"#{baseCalculoBo}",BaseCalculoBo.class);
		return baseCalculoBo.obtenerBaseCalcSelect();
	}	
		
	@Factory(value="listaClaseSelect", scope=ScopeType.CONVERSATION)
	public List<DescripcionClaseHisttramIndifiva> buildClaseAltaSelect(){
		altaTramosBo=getBo(altaTramosBo,"#{altaTramosBo}",AltaTramosBo.class);
		return altaTramosBo.buildClaseAltaSelect();
	}
	
	
	@Factory(value="listaBaseSelect", scope=ScopeType.CONVERSATION)
	public List<BaseCalculo> buildBaseSelect(){
		altaTramosBo=getBo(altaTramosBo,"#{altaTramosBo}",AltaTramosBo.class);
		return altaTramosBo.buildBaseSelect();
	}
	
	@Factory(value="listaSignoSelect", scope=ScopeType.CONVERSATION)
	public List<DescripcionHisttramSigno> buildSignoSelect(){
		altaTramosBo=getBo(altaTramosBo,"#{altaTramosBo}",AltaTramosBo.class);
		return altaTramosBo.buildSignoSelect();
	}	
	
	@Factory(value="listaDivisaSelect", scope=ScopeType.CONVERSATION)
	public List<Divisa> buildDivisaSelect(){
		altaTramosBo=getBo(altaTramosBo,"#{altaTramosBo}",AltaTramosBo.class);
		return altaTramosBo.buildDivisaSelect();
	}	
	//End for Manttram Tramos 
	
	@Factory(value="listaDivisaLiquidacion", scope=ScopeType.CONVERSATION)
	public List<Divisa> buildDivisaLiquidacion(){
		divisaBo=getBo(divisaBo,"#{divisaBo}",DivisaBo.class);
		return divisaBo.seleccionarDivisaLiquidacion();
	}
        
    @Factory(value = "listaTipoPrimaCancelacion", scope = ScopeType.CONVERSATION)
	public List<DescripcionTipoOperacionHistderi> buildListaTipoPrimaCancelacion() {
        cancelacionParcialBo = getBo(cancelacionParcialBo, "#{cancelacionParcialBo}", CancelacionParcialBo.class);
		return cancelacionParcialBo.obtenerTiposPrimaSelect();
	}
	
	@Factory(value = "listaCanalLiquidacion", scope = ScopeType.CONVERSATION)
	public List<DescripcionCanalLiquidacion> buildListaCanalLiquidacion() {
        liquidacionesBo = getBo(liquidacionesBo, "#{liquidacionesBo}", LiquidacionesBo.class);	
		return liquidacionesBo.obtenerCanalLiquidacionSelect();
	}

        @Factory(value = "listaTipoOperEjercicio", scope = ScopeType.CONVERSATION)
	 public List<DescripcionTipoOperacionHistderi> buildListaTipoOperEjercicio() {
	        ejercicioBo=getBo(ejercicioBo,"#{ejercicioBo}",EjercicioBo.class);
                return ejercicioBo.seleccionarTipoOperacion();
	 }

	@Factory(value="listaClaseIntSelect", scope=ScopeType.CONVERSATION)
	public List<DescripcionClaseInt> buildClaseIntSelect(){
		datosPrimerTramoIrregularBo=getBo(datosPrimerTramoIrregularBo,"#{datosPrimerTramoIrregularBo}",DatosPrimerTramoIrregularBo.class);
		return datosPrimerTramoIrregularBo.buildClaseIntSelect();
	}
	
	@Factory(value="listaTipoCancelacionSelect", scope=ScopeType.CONVERSATION)
	public List<DescripcionTipoCancelacion> buildTipoCancelacionSelect(){
		cancelacionBo=getBo(cancelacionBo,"#{cancelacionBo}",CancelacionBo.class);
		return cancelacionBo.obtenerTipoCancelacionSelect();
	}
	
	@Factory(value="listaMotivoCancelacionSelect", scope=ScopeType.CONVERSATION)
	public List<DescripcionMotivoCancelacion> buildMotivoCancelacionSelect(){
		cancelacionBo=getBo(cancelacionBo,"#{cancelacionBo}",CancelacionBo.class);
		return cancelacionBo.obtenerMotivoCancelacionSelect();
	}
	
	@Factory(value="listaSentidoAmortizacionSelect", scope=ScopeType.CONVERSATION)
	public List<DescripcionSentidoAmortizacion> buildSentidoAmortizacionSelect(){
		cancelacionBo=getBo(cancelacionBo,"#{cancelacionBo}",CancelacionBo.class);
		return cancelacionBo.obtenerSentidoAmortizacionSelect();
	}

	@Factory(value="listaTiposBarreratSelect", scope=ScopeType.CONVERSATION)
	public List<DescripcionTipoBarrera> buildTiposBarreratSelect(){
        mantenimientoBarrerasBo = getBo(mantenimientoBarrerasBo,"#{mantenimientoBarrerasBo}",MantenimientoBarrerasBo.class);
		return mantenimientoBarrerasBo.obtenerTiposBarrera();
	}
	
	@Factory(value="listaTiposRebateSelect", scope=ScopeType.CONVERSATION)
	public List<DescripcionTipoRebate> buildTiposRebateSelect(){
		mantenimientoBarrerasBo = getBo(mantenimientoBarrerasBo,"#{mantenimientoBarrerasBo}",MantenimientoBarrerasBo.class);
		return mantenimientoBarrerasBo.obtenerTiposRebate();
	}
	
	@Factory(value="listaTiposRevisionSelect", scope=ScopeType.CONVERSATION)
	public List<DescripcionTipoRevision> buildTiposRevisionSelect(){
		mantenimientoBarrerasBo = getBo(mantenimientoBarrerasBo,"#{mantenimientoBarrerasBo}",MantenimientoBarrerasBo.class);
		return mantenimientoBarrerasBo.obtenerTiposRevision();
	}
	
	@Factory(value="listaProcedenciaSelect", scope=ScopeType.CONVERSATION)
	public List<ProcedenciaProducto> buildProcedenciaSelect(){
		mantProdCompuestoBo = getBo(mantProdCompuestoBo,"#{mantProdCompuestoBo}",MantProdCompuestoBo.class);
		return mantProdCompuestoBo.getProcedenciaProd();
	}

	@Factory(value="listaTipoPlantilla", scope=ScopeType.CONVERSATION)
	public List<DescripcionTipoPlantilla> buildListaTipoPlantilla(){
		boletaProdCompuestoBo = getBo(boletaProdCompuestoBo,"#{boletaProdCompuestoBo}",BoletaProdCompuestoBo.class);
		return boletaProdCompuestoBo.obtenerTipoPlantilla();
	}	
	
	@Factory(value="listaProcedenciaProductoSelect", scope=ScopeType.EVENT)
	public List<ProcedenciaProducto> buildProcedenciaProductoSelect(){
		mantProdCompuestoBo = getBo(mantProdCompuestoBo,"#{mantProdCompuestoBo}",MantProdCompuestoBo.class);
		return mantProdCompuestoBo.getProcedenciaProd();
	}
	
	@Factory(value="listaSituacionSelect", scope=ScopeType.EVENT)
	public List<DescSituacionProdCompuesto> buildSituacionSelect(){
		mantProdCompuestoBo = getBo(mantProdCompuestoBo,"#{mantProdCompuestoBo}",MantProdCompuestoBo.class);
		return mantProdCompuestoBo.getDescSituacionProdCompuesto();
	}
	
	@Factory(value = "ListaDescripcionTipoSwaption", scope = ScopeType.CONVERSATION)
	public List<DescripcionTipoSwaption> getDescripcionTipoSwaption() {
		boletasBo = getBo(boletasBo, "#{boletasBo}", BoletasBo.class);
		return boletasBo.getDescripcionTipoSwaption();
	}

	/*
	 * Pantalla Alta Operaciones (BoletasAlta)
	 */
	@Factory(value = "tipoPeticionesList", scope = ScopeType.CONVERSATION)
	public List<DescripcionTipoPeticion> getListaTiposPeticion() {
		peticionesBo=getBo(peticionesBo,"#{peticionesBo}",PeticionesBo.class);
		return peticionesBo.obtenerDescripcionTipoPeticion();
	}

	@Factory(value = "estadoPeticionesList", scope = ScopeType.CONVERSATION)
	public List<DescripcionEstadoPeticion> getListaEstadosPeticion() {
		peticionesBo=getBo(peticionesBo,"#{peticionesBo}",PeticionesBo.class);
		return peticionesBo.obtenerDescripcionEstadoPeticion();
	}
	
	@Factory(value = "listaProductosColat", scope = ScopeType.CONVERSATION)
	public List<ProductoContraRepo> getListaProductosColat() {
		contrapartidasRepoBo=getBo(contrapartidasRepoBo,"#{contrapartidasRepoBo}",ContrapartidasRepoBo.class);
		return contrapartidasRepoBo.obtenerListaDescripProducto();
	}
	
	@Factory(value = "listaProductosByTipoProyecto", scope = ScopeType.CONVERSATION)
	public List<Producto> buildListaProductosByTipoProyecto(String tipoProyecto) {
		if(tipoProyecto==null || tipoProyecto.equals(""))
			tipoProyecto=Constantes.NOMBRE_PROYECTO_COLAT;
		peticionBo=getBo(peticionBo,"#{peticionBo}",PeticionBo.class);
		return peticionBo.obtenerProductosSelect(tipoProyecto);
	}
	
	@Factory(value = "listaEsquemasContablesColat", scope = ScopeType.CONVERSATION)
	public List<EsquemaContable> getListaEsquemasColat(String proyecto) {
		if(proyecto==null || proyecto.equals(""))
			proyecto=Constantes.NOMBRE_PROYECTO_COLAT;
		configuracionesContablesBo=getBo(configuracionesContablesBo,"#{configuracionesContablesBo}",ConfiguracionesContablesBo.class);
		List<EsquemaContable> result = configuracionesContablesBo.obtenerEsquemaContableSelect(proyecto); 
		return result;
	}
	
	@Factory(value = "listaEntidadesColat", scope = ScopeType.CONVERSATION)
	public List<DescripcionEntidadOperacion> getListaEntidad() {
		configuracionesContablesBo=getBo(configuracionesContablesBo,"#{configuracionesContablesBo}",ConfiguracionesContablesBo.class);
		return configuracionesContablesBo.obtenerEntidadesSelect();
	}
	
	@Factory(value = "listaGruposContablesColat", scope = ScopeType.CONVERSATION)
	public List<GrupoContableColat> getListaGruposContablesColat(String producto) {
		if(null==producto || producto.equals(""))
			return null;
		configuracionesContablesBo=getBo(configuracionesContablesBo,"#{configuracionesContablesBo}",ConfiguracionesContablesBo.class);
		List<GrupoContableColat> result = configuracionesContablesBo.obtenerGruposContablesSelect(producto);
		return result;
	}
	
	@Factory(value = "listaConceptosTipoContabilizacion", scope = ScopeType.CONVERSATION)
	public List<ConceptoTipconta> getListaConceptosTipoContabilizacion(String proyecto) {
		if(proyecto==null || proyecto.equals(""))
			proyecto=Constantes.NOMBRE_PROYECTO_COLAT;
		configuracionesContablesBo=getBo(configuracionesContablesBo,"#{configuracionesContablesBo}",ConfiguracionesContablesBo.class);
		List<ConceptoTipconta> result = configuracionesContablesBo.obtenerConceptosTipoContabilizacionSelect(proyecto);
		return result;
	}
	
	@Factory(value = "listaCuentasPosicion", scope = ScopeType.CONVERSATION)
	public List<CuentaPosicion> getListaCuentasPosicion() {
		configuracionesContablesBo=getBo(configuracionesContablesBo,"#{configuracionesContablesBo}",ConfiguracionesContablesBo.class);
		List<CuentaPosicion> result = configuracionesContablesBo.obtenerListaCuentasPosicionSelect();
		return result;
	}

	@Factory(value = "modeloColatList", scope = ScopeType.CONVERSATION)
	public List<ModeloColat> buildListaModeloColat() {
		liquidacionesBo=getBo(liquidacionesBo,"#{liquidacionesBo}",LiquidacionesBo.class);
		return liquidacionesBo.getModelosColat();
	}

	@Factory(value = "estadosEmirList", scope = ScopeType.CONVERSATION)
	public List<DescripcionEstadoEmir> getListaEstadosEmir() {
		emirBo=getBo(emirBo,"#{emirBo}",EmirBo.class);
		return emirBo.obtenerDescripcionEstadosEmir();
	}

	@Factory(value = "tipoTransaccionEmirList", scope = ScopeType.CONVERSATION)
	public List<DescripcionTipoTransaccion> getListaTiposTransaccion() {
		emirBo=getBo(emirBo,"#{emirBo}",EmirBo.class);
		return emirBo.obtenerDescripcionTipoTransaccion();
	}

	@Factory(value = "indicadorSituacionList", scope = ScopeType.CONVERSATION)
	public List<DescripcionIndicadorSituacion> getListaIndicadorSituacion() {
		emirBo=getBo(emirBo,"#{emirBo}",EmirBo.class);
		return emirBo.obtenerDescripcionIndicadorSituacion();
	}

	@Factory(value = "proyectosEmirList", scope = ScopeType.CONVERSATION)
	public List<String> getProyectosEmir() {
		emirBo=getBo(emirBo,"#{emirBo}",EmirBo.class);
		return emirBo.obtenerProyectosEmir();
	}

//	@Factory(value = "estadosEmirList", scope = ScopeType.CONVERSATION)
//	public List<DescripcionEstadoEmir> getListaEstadosEmir() {
//		emirBo=getBo(emirBo,"#{emirBo}",EmirBo.class);
//		return emirBo.obtenerDescripcionEstadosEmir();
//	}
//
//	@Factory(value = "tipoTransaccionEmirList", scope = ScopeType.CONVERSATION)
//	public List<DescripcionTipoTransaccion> getListaTiposTransaccion() {
//		emirBo=getBo(emirBo,"#{emirBo}",EmirBo.class);
//		return emirBo.obtenerDescripcionTipoTransaccion();
//	}
//
//	@Factory(value = "indicadorSituacionList", scope = ScopeType.CONVERSATION)
//	public List<DescripcionIndicadorSituacion> getListaIndicadorSituacion() {
//		emirBo=getBo(emirBo,"#{emirBo}",EmirBo.class);
//		return emirBo.obtenerDescripcionIndicadorSituacion();
//	}
//
//	@Factory(value = "proyectosEmirList", scope = ScopeType.CONVERSATION)
//	public List<String> getProyectosEmir() {
//		emirBo=getBo(emirBo,"#{emirBo}",EmirBo.class);
//		return emirBo.obtenerProyectosEmir();
//	}

}