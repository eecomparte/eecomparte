package com.atosorigin.deri.common.dbLock;

import java.io.Serializable;
import java.net.InetAddress;
import java.net.UnknownHostException;

import javax.faces.context.FacesContext;
import javax.servlet.http.HttpServletRequest;

import org.jboss.seam.ScopeType;
import org.jboss.seam.annotations.In;
import org.jboss.seam.annotations.Logger;
import org.jboss.seam.annotations.Name;
import org.jboss.seam.annotations.Scope;
import org.jboss.seam.annotations.TransactionPropagationType;
import org.jboss.seam.annotations.Transactional;
import org.jboss.seam.log.Log;
import org.jboss.seam.security.Identity;

import com.atosorigin.deri.common.dblock.business.DbLockServiceBo;
import com.atosorigin.deri.model.dbblock.DbBloqueo;

/**
 * Componente seam que proporciona el Servicio de bloqueo de registros. 
 */
@Name("dbLockService")
@Scope(ScopeType.CONVERSATION)
public class DbLockService implements java.io.Serializable {

	/** La interfaz de negocio para el bloqueo de registros */
	@In("#{dbLockServiceBo}")
	protected DbLockServiceBo dbLockServiceBo;
	
	/** The logger. */
	@Logger
	protected Log logger;
	
	/**
	 * Bloqueo de un registro en BBDD.
	 * 
	 * @param entity Clase de la entidad persistente a bloquear.
	 * @param pk Id de la entidad a bloquear.
	 * 
	 * @return Booleano que indica si ha ido bien o ha habido algún problema.
	 */
	@Transactional(TransactionPropagationType.REQUIRED )
	public Boolean bloqueo(Class<?> entityClass, Serializable pk) {
		
		String sessionId = getSessionId();
		String userName  = getUserName();
		String ipAddress = getIP();
		return dbLockServiceBo.bloqueo(entityClass, pk, sessionId, userName, ipAddress);
		
	}

	
	/**
	 * Bloqueo de un registro en BBDD.
	 * 
	 * @param entity Clase de la entidad persistente a bloquear.
	 * @param pk Id de la entidad a bloquear.
	 * 
	 * @return Booleano que indica si ha ido bien o ha habido algún problema.
	 */
	@Transactional(TransactionPropagationType.REQUIRED )
	public String bloqueoBoleta(Class<?> entityClass, Serializable pk) {
		
		String sessionId = getSessionId();
		String userName  = getUserName();
		String ipAddress = getIP();
		return dbLockServiceBo.bloqueoBoleta(entityClass, pk, sessionId, userName, ipAddress);
		
	}

	
	
	/**
	 * Devuelve información sobre un registro de bloqueo
	 * 
	 * @param entity the entity
	 * @param pk the pk
	 * 
	 * @return the db bloqueo
	 */
	public DbBloqueo infoBloqueo(Class<?> entityClass, Serializable pk) {
		
		return dbLockServiceBo.infoBloqueo(entityClass, pk);
	}

	/**
	 * Desbloquea un registro
	 * 
	 * @param entity the entity
	 * @param pk the pk
	 * 
	 * @return Booleano que indica si ha ido bien o ha habido algún problema.
	 */
	@Transactional(TransactionPropagationType.REQUIRED )
	public Boolean desbloqueo(Class<?> entityClass, Serializable pk) {
		return dbLockServiceBo.desbloqueo(entityClass, pk, getSessionId());
	}
		

	/**
	 * MÉTODO SÓLO PARA ARQUITECTURA. NO USAR EN DESARROLLO DE CASOS DE USO
	 * Desbloquea todos los registros de un identificador de sesión HTTP.
	 * Usable para desbloquear todos los registros bloqueados durante una sesión cuantdo esta se cierra o expira.
	 * 
	 * @return Booleano que indica si ha ido bien o ha habido algún problema.
	 */
	@Transactional(TransactionPropagationType.REQUIRED )
	public Boolean desbloqueoBloqueadosSesion() {
		return dbLockServiceBo.desbloqueoTodaSesion(getSessionId());
	}

	/**
	 * MÉTODO SÓLO PARA ARQUITECTURA. NO USAR EN DESARROLLO DE CASOS DE USO
	 * Desbloquea todos los registros de un identificador de sesión HTTP.
	 * Usable para desbloquear todos los registros bloqueados durante una sesión cuantdo esta se cierra o expira.
	 * 
	 * @param sessionId El id de la sesión HTTP
	 * 
	 * @return the boolean
	 */
	@Transactional(TransactionPropagationType.REQUIRED )
	public Boolean desbloqueoBloqueadosSesion(String sessionId) {
		return dbLockServiceBo.desbloqueoTodaSesion(sessionId);
	}

	/**
	 * MÉTODO SÓLO PARA ARQUITECTURA. NO USAR EN DESARROLLO DE CASOS DE USO
	 * Desbloquea todos los registros de un identificador de sesión HTTP.
	 * Usable para desbloquear todos los registros bloqueados durante una sesión cuantdo esta se cierra o expira.
	 * 
	 * @return the boolean
	 */
	@Transactional(TransactionPropagationType.REQUIRED )
	public Boolean desbloqueoBloqueadosOnline() {
		return dbLockServiceBo.desbloqueoBloqueadosOnline();
	}

	/**
	 * Gets the iP.
	 * 
	 * @return the iP
	 */
	private String getIP()  {
		HttpServletRequest request = (HttpServletRequest)FacesContext.getCurrentInstance().getExternalContext().getRequest();
//		request.getSession().getServletContext().getServerInfo().
		InetAddress IP = null;
		try {
			IP = InetAddress.getLocalHost();
		} catch (UnknownHostException e) {
			logger.error("No se reconoce el host. Pongo nulo");
		}
		return IP.getHostAddress();
	}
	
	/**
	 * Gets the session id.
	 * 
	 * @return the session id
	 */
	private String getSessionId() {
		HttpServletRequest request = (HttpServletRequest)FacesContext.getCurrentInstance().getExternalContext().getRequest();
		return request.getSession().getId();
	}
	
	/**
	 * Gets the user name.
	 * 
	 * @return the user name
	 */
	private String getUserName() {
		return Identity.instance().getCredentials().getUsername();
	}
	
	
}
