package com.atosorigin.deri.common.initialization;

import org.jboss.seam.annotations.In;
import org.jboss.seam.annotations.Name;
import org.jboss.seam.annotations.Observer;

import com.atosorigin.deri.common.authentication.PantallasNivelesCache;
import com.atosorigin.deri.common.dbLock.DbLockService;

@Name("observeInitialization")
public class ObserveInitialization {

	@In("#{pantallasNivelesCache}")
	private PantallasNivelesCache pantallasNivelesCache;
	
	@In(create=true)
	private DbLockService dbLockService;

	@Observer("org.jboss.seam.postInitialization")
	public void observe() {
		//Carga de los niveles de pantalla como cache para poder agilizar la autorización
		pantallasNivelesCache.inicializar();
		//Borrado de todos los registros bloqueados que tuvieran algún id de sesión.
		//El único caso en que los registros de bloqueo se pueden quedar sin borrar
		//es cuando el servidor se cae. En ese caso al reiniciar borramos todos los
		//registros de bloqueo que hayan sido dados de alta por el online.
		dbLockService.desbloqueoBloqueadosOnline();
	}
}