package com.atosorigin.deri.common.paginate;

import java.util.List;

import com.atosorigin.common.action.PaginationData;


/**
 * Clase genética de action listener que sirve para manejar pantallas con grid paginada en base de datos.
 */
public abstract class PaginatedDelegate {
	
	/** Los datos de paginación del grid que maneja */
	protected PaginationData paginationData = new PaginationData();
	
	protected boolean exportExcel = false;
	
	/**
	 * Obtiene los datos de paginación.
	 * 
	 * @return Datos de paginación.
	 */
	public PaginationData getPaginationData() {
		return paginationData;
	}

	/**
	 * Establece los datos de paginación.
	 * 
	 * @param paginationData Los datos de paginación. 
	 */
	public void setPaginationData(PaginationData paginationData) {
		this.paginationData = paginationData;
	}
	
	/**
	 * Comprueba que hay una página anterior a la que se está mostrando actualmente.
	 * 
	 * @return true si hay página anterior.
	 */
	public boolean isPreviousExists() {
		return paginationData.getFirstResult() > 1;
	}

	/**
	 * Comprueba si hay página siguiente a la que se está mostrando actualmente.
	 * 
	 * @return true, Si hay página siguiente
	 */
	public boolean isNextExists() {
		return getDataTableList() != null && paginationData.getMaxResults() != null
				&& getDataTableList().size() > paginationData.getMaxResults();
	}
	
	/**
	 * Actualiza la lista de datos del grid con la siguiente página de base de datos,
	 */
	public void next() {
		paginationData.setFirstResult(paginationData.getFirstResult() + paginationData.getMaxResults());
		this.refrescarListaDelegate();
	}

	/**
	 * Actualiza la lista de datos del grid con la anterior página de base de datos,
	 */
	public void previous() {
		paginationData.setFirstResult(paginationData.getFirstResult() - paginationData.getMaxResults());
		this.refrescarListaDelegate();
	}

	/**
	 * Actualiza la lista de datos del grid con la primera página de base de datos,
	 */
	public void first() {
		paginationData.setFirstResult(0);
		this.refrescarListaDelegate();
	}

	/**
	 * Establece el criterio de ordenación
	 * 
	 * @param orderKey El criterio de ordenación.
	 */
	public void setOrderKey(String orderKey) {
		paginationData.setOrderKey(orderKey);
		this.refrescarListaDelegate();
	}

	/**
	 * Refresca la lista de elementos del grid con los filtros de pantalla que correspondan.
	 */
	public abstract void refrescarListaDelegate();

	/**
	 * Refresca la lista de elementos del grid para el excel.
	 * Lo que tiene que hacer es poner el first a 0 y el maxresults a la constante
	 * que indica el número máximo de registros para sacar en el excel. (unos 65500)
	 */
	public abstract void refrescarListaDelegateExcel();

	/**
	 * Obtiene la lista de elementos del grid. No va a por ella, sólo la obtiene.
	 * 
	 * @return La lista de elementos del grid.
	 */
	public abstract List<?> getDataTableList();

	/**
	 * Establece la lista de elementos del grid. No la calcula, sólo la 'setea'
	 * 
	 * @param dataTableList La lista de elementos del grid.
	 */
	public abstract void setDataTableList(List<?> dataTableList);

	public boolean isExportExcel() {
		return exportExcel;
	}

	public void setExportExcel(boolean exportExcel) {
		this.exportExcel = exportExcel;
	}
	
	public abstract void setPantalla(Object pantalla);
	
	public abstract Object getPantalla();
	
	public abstract void setBo(Object bo);
	
	public abstract Object getBo();	
}
