package com.atosorigin.deri.common.parametrosPantalla;

import java.util.Date;

import com.atosorigin.deri.model.agenda.EventoAgenda;
import com.atosorigin.deri.model.catalogo.Producto;
import com.atosorigin.deri.model.murex.ModeloProducto;

/**
 * Clase que contiene los parametros que se pasan desde la pantalla de Agenda al resto de 
 * pantallas
 *
 */

public class ParametrosAvisoAgenda {

	private String modo;
	private String codcampa;
	private Long codevent;
	private Date fechaOpe;
	private ModeloProducto modeloPr;
	private Producto producto;
	private Long ncorrelaIni;
	private Long ncorrelaFin;
	private Date fechatraIni;
	private Date fechatraFin;
	private String estadoEv;
	private String estindic;
	private Date fechaEvento;
	private EventoAgenda eventoAgenda;
	
	
	
	public EventoAgenda getEventoAgenda() {
		return eventoAgenda;
	}
	public void setEventoAgenda(EventoAgenda eventoAgenda) {
		this.eventoAgenda = eventoAgenda;
	}
	public Date getFechaEvento() {
		return fechaEvento;
	}
	public void setFechaEvento(Date fechaEvento) {
		this.fechaEvento = fechaEvento;
	}
	public String getModo() {
		return modo;
	}
	public void setModo(String modo) {
		this.modo = modo;
	}
	public String getCodcampa() {
		return codcampa;
	}
	public void setCodcampa(String codcampa) {
		this.codcampa = codcampa;
	}
	public Long getCodevent() {
		return codevent;
	}
	public void setCodevent(Long codevent) {
		this.codevent = codevent;
	}
	
	public Long getNcorrelaIni() {
		return ncorrelaIni;
	}
	public void setNcorrelaIni(Long ncorrelaIni) {
		this.ncorrelaIni = ncorrelaIni;
	}
	public Long getNcorrelaFin() {
		return ncorrelaFin;
	}
	public void setNcorrelaFin(Long ncorrelaFin) {
		this.ncorrelaFin = ncorrelaFin;
	}
	public Producto getProducto() {
		return producto;
	}
	public void setProducto(Producto producto) {
		this.producto = producto;
	}
	public Date getFechaOpe() {
		return fechaOpe;
	}
	public ModeloProducto getModeloPr() {
		return modeloPr;
	}
	public Date getFechatraIni() {
		return fechatraIni;
	}
	public Date getFechatraFin() {
		return fechatraFin;
	}
	public void setFechaOpe(Date fechaOpe) {
		this.fechaOpe = fechaOpe;
	}
	public void setModeloPr(ModeloProducto modeloPr) {
		this.modeloPr = modeloPr;
	}
	public void setFechatraIni(Date fechatraIni) {
		this.fechatraIni = fechatraIni;
	}
	public void setFechatraFin(Date fechatraFin) {
		this.fechatraFin = fechatraFin;
	}
	public String getEstadoEv() {
		return estadoEv;
	}
	public void setEstadoEv(String estadoEv) {
		this.estadoEv = estadoEv;
	}
	public String getEstindic() {
		return estindic;
	}
	public void setEstindic(String estindic) {
		this.estindic = estindic;
	}
}
