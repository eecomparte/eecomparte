package com.atosorigin.deri.common.parametrosPantalla;

import org.jboss.seam.annotations.Name;

import com.atosorigin.deri.dao.mercado.DescripcionFormula;

@Name("parametrosMantdata")
public class ParametrosMantdata {

	private String tipoFecha;
	private String fechaVenhab;
	private String tipoFechasObservacion;
	private String opcion;
	private DescripcionFormula descFormula;
	
	public ParametrosMantdata() {
		super();
	}
	
	public ParametrosMantdata(String tipoFecha, String fechaVenhab,
			String tipoFechasObservacion, String opcion,DescripcionFormula descFormula) {
		super();
		this.tipoFecha = tipoFecha;
		this.fechaVenhab = fechaVenhab;
		this.tipoFechasObservacion = tipoFechasObservacion;
		this.opcion = opcion;
		this.descFormula = descFormula;
	}
	
	public String getTipoFecha() {
		return tipoFecha;
	}
	public void setTipoFecha(String tipoFecha) {
		this.tipoFecha = tipoFecha;
	}
	public String getFechaVenhab() {
		return fechaVenhab;
	}
	public void setFechaVenhab(String fechaVenhab) {
		this.fechaVenhab = fechaVenhab;
	}
	public String getTipoFechasObservacion() {
		return tipoFechasObservacion;
	}
	public void setTipoFechasObservacion(String tipoFechasObservacion) {
		this.tipoFechasObservacion = tipoFechasObservacion;
	}
	public String getOpcion() {
		return opcion;
	}
	public void setOpcion(String opcion) {
		this.opcion = opcion;
	}

	public DescripcionFormula getDescFormula() {
		return descFormula;
	}

	public void setDescFormula(DescripcionFormula descFormula) {
		this.descFormula = descFormula;
	}
}
