package com.atosorigin.deri.common.parametrosPantalla;

import java.util.Date;

import org.jboss.seam.annotations.Name;

import com.atosorigin.deri.model.gestionoperaciones.HistoricoOperacion;

@Name("parametrosManteje")
public class ParametrosManteje {

		private String modo;
		private HistoricoOperacion historicoOperacion;
		private String tipoOperacion;
		private Date fecinitr;
		private Date fecfintr;
		private String concepto;
		private String tipoConcepto;
		private Date fechaeje; 
		
		
		public String getModo() {
			return modo;
		}
		public void setModo(String modo) {
			this.modo = modo;
		}
		public HistoricoOperacion getHistoricoOperacion() {
			return historicoOperacion;
		}
		public void setHistoricoOperacion(HistoricoOperacion historicoOperacion) {
			this.historicoOperacion = historicoOperacion;
		}
		public String getTipoOperacion() {
			return tipoOperacion;
		}
		public void setTipoOperacion(String tipoOperacion) {
			this.tipoOperacion = tipoOperacion;
		}
		public Date getFecinitr() {
			return fecinitr;
		}
		public void setFecinitr(Date fecinitr) {
			this.fecinitr = fecinitr;
		}
		public Date getFecfintr() {
			return fecfintr;
		}
		public void setFecfintr(Date fecfintr) {
			this.fecfintr = fecfintr;
		}
		public String getConcepto() {
			return concepto;
		}
		public void setConcepto(String concepto) {
			this.concepto = concepto;
		}
		public String getTipoConcepto() {
			return tipoConcepto;
		}
		public void setTipoConcepto(String tipoConcepto) {
			this.tipoConcepto = tipoConcepto;
		}
		public Date getFechaeje() {
			return fechaeje;
		}
		public void setFechaeje(Date fechaeje) {
			this.fechaeje = fechaeje;
		}

}
