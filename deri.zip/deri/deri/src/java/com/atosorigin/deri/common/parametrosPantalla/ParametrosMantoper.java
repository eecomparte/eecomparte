package com.atosorigin.deri.common.parametrosPantalla;

import java.util.Date;

import org.jboss.seam.annotations.Name;

import com.atosorigin.deri.model.catalogo.Producto;

@Name("parametrosMantoper")
public class ParametrosMantoper {

	private String modo;
	private String codcampa;
	private Long codevent;
	private Producto producto;
	private Long ncorrelaIni;
	private Long ncorrelaFin;
	private Date fechatra;
	private String estadoev;
	private Long numorden;
	private String tipoBarrera;
	
	public String getModo() {
		return modo;
	}
	public void setModo(String modo) {
		this.modo = modo;
	}
	public String getCodcampa() {
		return codcampa;
	}
	public void setCodcampa(String codcampa) {
		this.codcampa = codcampa;
	}
	public Long getCodevent() {
		return codevent;
	}
	public void setCodevent(Long codevent) {
		this.codevent = codevent;
	}
	
	public Long getNcorrelaIni() {
		return ncorrelaIni;
	}
	public void setNcorrelaIni(Long ncorrelaIni) {
		this.ncorrelaIni = ncorrelaIni;
	}
	public Long getNcorrelaFin() {
		return ncorrelaFin;
	}
	public void setNcorrelaFin(Long ncorrelaFin) {
		this.ncorrelaFin = ncorrelaFin;
	}
	public Date getFechatra() {
		return fechatra;
	}
	public void setFechatra(Date fechatra) {
		this.fechatra = fechatra;
	}
	public String getEstadoev() {
		return estadoev;
	}
	public void setEstadoev(String estadoev) {
		this.estadoev = estadoev;
	}
	public Long getNumorden() {
		return numorden;
	}
	public void setNumorden(Long numorden) {
		this.numorden = numorden;
	}
	public Producto getProducto() {
		return producto;
	}
	public void setProducto(Producto producto) {
		this.producto = producto;
	}
	public String getTipoBarrera() {
		return tipoBarrera;
	}
	public void setTipoBarrera(String tipoBarrera) {
		this.tipoBarrera = tipoBarrera;
	}
}
