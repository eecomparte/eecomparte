package com.atosorigin.deri.common.parametrosPantalla;

import org.jboss.seam.annotations.Name;

@Name("parametrosOpercamp")
public class ParametrosOpercamp {

	private String codcampa;
	private String fechaact;
	private String opcion;
	
	public String getCodcampa() {
		return codcampa;
	}
	public void setCodcampa(String codcampa) {
		this.codcampa = codcampa;
	}
	public String getFechaact() {
		return fechaact;
	}
	public void setFechaact(String fechaact) {
		this.fechaact = fechaact;
	}
	public String getOpcion() {
		return opcion;
	}
	public void setOpcion(String opcion) {
		this.opcion = opcion;
	}
}
