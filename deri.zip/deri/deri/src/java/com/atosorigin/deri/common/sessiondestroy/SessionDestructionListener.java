package com.atosorigin.deri.common.sessiondestroy;

import javax.servlet.http.HttpSessionEvent;
import javax.servlet.http.HttpSessionListener;


/**
 * The listener interface for receiving sessionDestruction events.
 * The class that is interested in processing a sessionDestruction
 * event implements this interface, and the object created
 * with that class is registered with a component using the
 * component's <code>addSessionDestructionListener<code> method. When
 * the sessionDestruction event occurs, that object's appropriate
 * method is invoked.
 * 
 * @see SessionDestructionEvent
 */
public class SessionDestructionListener implements HttpSessionListener {

	/** 
	 * Método que se invoca cada vez que se crea una sesión. 
	 * En este caso se utiliza para poner como parámetro de sesión
	 * el identificador de la sesión creada. Es necesario para poder eliminar
	 * los bloqueos mediante SessionDestructionObserver
	 *  
	 */
	public void sessionCreated(HttpSessionEvent arg0) {
		// TODO Auto-generated method stub
		String id = arg0.getSession().getId();
		arg0.getSession().setAttribute("sessionId", id);
	}

	/* (non-Javadoc)
	 * @see javax.servlet.http.HttpSessionListener#sessionDestroyed(javax.servlet.http.HttpSessionEvent)
	 */
	public void sessionDestroyed(HttpSessionEvent arg0) {
		return;
	}

}
