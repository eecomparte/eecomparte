package com.atosorigin.deri.common.sessiondestroy;

import org.jboss.seam.ScopeType;
import org.jboss.seam.annotations.In;
import org.jboss.seam.annotations.Name;
import org.jboss.seam.annotations.Observer;
import org.jboss.seam.annotations.Scope;
import org.jboss.seam.annotations.Transactional;
import org.jboss.seam.contexts.Contexts;
import org.jboss.seam.contexts.SessionContext;

import com.atosorigin.deri.common.dbLock.DbLockService;

/**
 * Observer que se encarga de controlar las destrucciones de las sesiones
 * para desbloquear todos los registros que sea habían bloqueado con el servicio de
 * bloqueo de registros durante la sesión.
 * 
 */
@Name("sessionObserver")
@Scope(ScopeType.EVENT)
public class SessionDestructionObserver {

	/** The db lock service. */
	@In(create=true)
	private DbLockService dbLockService;

	// Crea este componente justo antes de la destrucción de la sesión.
	/**
	 * Intercepta las destrucciones de sesiones y desbloquea todos los registros bloqueados
	 * por la operativa del usuario durante la vida de la misma.
	 * 
	 */
	@Observer(value = "org.jboss.seam.preDestroyContext.SESSION", create = true)
	@Transactional
	public void onSessionDestroyed() {
		SessionContext sc = (SessionContext)Contexts.getSessionContext();
		String sessionId = (String)sc.get("sessionId");
		dbLockService.desbloqueoBloqueadosSesion(sessionId);
	}
}
