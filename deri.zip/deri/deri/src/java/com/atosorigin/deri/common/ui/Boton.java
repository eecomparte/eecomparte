package com.atosorigin.deri.common.ui;

/**
 * Clase con los atributos de un botón.
 * 
 * @author alejandro.torras@atosorigin.com
 */
public class Boton implements JsfComponent {

	protected boolean enabled;

	protected boolean rendered;

	public Boton() {
		this(true);
	}

	public Boton(boolean enabled) {
		this(true, true);
	}

	public Boton(boolean enabled, boolean rendered) {
		setEnabled(enabled);
		setRendered(rendered);
	}

	public boolean isEnabled() {
		return enabled;
	}

	public void setEnabled(boolean enabled) {
		this.enabled = enabled;
	}

	public boolean isRendered() {
		return rendered;
	}

	public void setRendered(boolean rendered) {
		this.rendered = rendered;
	}

	public boolean isDisabled() {
		return !isEnabled();
	}

	public void setDisabled(boolean disabled) {
		setEnabled(!disabled);
	}

}
