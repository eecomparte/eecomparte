package com.atosorigin.deri.common.ui;

import com.atosorigin.seam.jsf.PercentageConverter;

/**
 * Clase con los atributos de un campo de texto.
 * 
 * En el caso que se necesite forzar un tipo de dato desde JSF se puede usar el
 * atributo <code>converter</code>.
 * 
 * @see PercentageConverter
 * @author alejandro.torras@atosorigin.com
 */
public class Campo<T> implements JsfComponent {

	protected boolean enabled;

	protected boolean rendered;

	protected boolean required;

	protected T value;

	public Campo() {
		this(null);
	}

	public Campo(T value) {
		this(value, false);
	}

	public Campo(T value, boolean enabled) {
		this(value, enabled, false);
	}

	public Campo(T value, boolean enabled, boolean required) {
		this(value, enabled, required, true);
	}

	public Campo(T value, boolean enabled, boolean required, boolean rendered) {

		setEnabled(enabled);
		setRendered(rendered);
		setRequired(required);
		setValue(value);
	}

	public T getValue() {
		return value;
	}

	public boolean isDisabled() {
		return !isEnabled();
	}

	public boolean isEnabled() {
		return enabled;
	}

	public boolean isRendered() {
		return rendered;
	}

	public boolean isRequired() {
		return required;
	}

	public void setDisabled(boolean disabled) {
		setEnabled(!disabled);
	}

	public void setEnabled(boolean enabled) {
		this.enabled = enabled;
	}

	public void setRendered(boolean rendered) {
		this.rendered = rendered;
	}

	public void setRequired(boolean required) {
		this.required = required;
	}

	public void setValue(T value) {
		this.value = value;
	}

	@Override
	public String toString() {

		final StringBuilder sb = new StringBuilder(super.toString());
		sb.append(" enabled:").append(enabled);
		sb.append(" rendered:").append(rendered);
		sb.append(" required:").append(required);
		sb.append(" value:").append(value);

		return sb.toString();
	}

}
