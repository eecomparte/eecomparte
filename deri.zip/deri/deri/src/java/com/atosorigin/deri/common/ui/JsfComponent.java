package com.atosorigin.deri.common.ui;

public interface JsfComponent {

	public boolean isEnabled();

	public boolean isRendered();

	public void setEnabled(boolean enabled);

	public void setRendered(boolean rendered);

}
