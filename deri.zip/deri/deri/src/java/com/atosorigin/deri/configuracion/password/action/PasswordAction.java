package com.atosorigin.deri.configuracion.password.action;

import org.jboss.seam.ScopeType;
import org.jboss.seam.annotations.In;
import org.jboss.seam.annotations.Name;
import org.jboss.seam.annotations.Scope;
import org.jboss.seam.international.StatusMessage.Severity;
import org.jboss.seam.security.Credentials;

import com.atosorigin.common.action.GenericAction;
import com.atosorigin.common.constantes.Constantes;
import com.atosorigin.common.formvalidator.FormValidator;
import com.atosorigin.deri.common.authentication.CustomIdentity;
import com.atosorigin.deri.configuracion.password.screen.PasswordPantalla;
import com.atosorigin.deri.model.seguridad.Usuario;
import com.atosorigin.deri.seguridad.mantusuario.business.UsuarioBo;

@Name("passwordAction")
@Scope(ScopeType.CONVERSATION)
@FormValidator
public class PasswordAction extends GenericAction {
	
	
	@In CustomIdentity identity;
    @In Credentials credentials;
    
    @In(value="#{usuarioBo}")
    private UsuarioBo usuarioBo;
    
	@In(create=true)
    private PasswordPantalla passwordPantalla;
	
	public void guardar(){
		Usuario usuarioLogin = usuarioBo.buscarUsuarioUsername(credentials.getUsername());
		String passEncriptada = usuarioBo.encriptarPassword(passwordPantalla.getNuevaPass(), usuarioLogin);
		if(usuarioLogin.getSeguridad()){
			usuarioBo.modificacionSeguridadActiva(usuarioLogin, passEncriptada);
		}else{
			usuarioBo.modificacionSeguridadNoActiva(usuarioLogin, passEncriptada);
		}
		
	}
	
	public boolean guardarValidator(){
		
		Usuario usuarioLogin = usuarioBo.buscarUsuarioUsername(credentials.getUsername());
		String password = usuarioBo.encriptarPassword(passwordPantalla.getNuevaPass(), usuarioLogin);
		if(!passwordPantalla.getNuevaPass().equals(passwordPantalla.getVerificaPass())){
			statusMessages.add(Severity.ERROR, "#{messages['usuario.error.verificacionIncorrecta']}", Constantes.DEFAULT_MESSAGE_TEMPLATE);
			return false;
		}
		if(	passwordPantalla.getNuevaPass().equals(passwordPantalla.getPassAntigua())){
			statusMessages.add(Severity.ERROR, "#{messages['usuario.error.passwordsIguales']}", Constantes.DEFAULT_MESSAGE_TEMPLATE);
			return false;
		}if(password.equals(usuarioLogin.getPassword())){
			statusMessages.add(Severity.ERROR, "#{messages['usuario.error.passwordAntiguoErroneo']}", Constantes.DEFAULT_MESSAGE_TEMPLATE);
			return false;
		}
		
		if(usuarioLogin.getSeguridad()){
			
			if(password.length()<8){
				statusMessages.add(Severity.ERROR, "usuario.error.verificacionIncorrecta", Constantes.DEFAULT_MESSAGE_TEMPLATE);
				return false;
			}
			if(usuarioLogin.getPassword().equals(usuarioLogin.getPassword01())
					||usuarioLogin.getPassword().equals(usuarioLogin.getPassword02())
					||usuarioLogin.getPassword().equals(usuarioLogin.getPassword03())
					||usuarioLogin.getPassword().equals(usuarioLogin.getPassword04())
					||usuarioLogin.getPassword().equals(usuarioLogin.getPassword05())
					||usuarioLogin.getPassword().equals(usuarioLogin.getPassword06())
					||usuarioLogin.getPassword().equals(usuarioLogin.getPassword07())
					||usuarioLogin.getPassword().equals(usuarioLogin.getPassword08())
					||usuarioLogin.getPassword().equals(usuarioLogin.getPassword09())
					||usuarioLogin.getPassword().equals(usuarioLogin.getPassword10())
					||usuarioLogin.getPassword().equals(usuarioLogin.getPassword11())
			){
				statusMessages.add(Severity.ERROR, "usuario.error.passwordRepetido", Constantes.DEFAULT_MESSAGE_TEMPLATE);
				return false;		
			}
		}
		
		return true;
	}

	public CustomIdentity getIdentity() {
		return identity;
	}

	public void setIdentity(CustomIdentity identity) {
		this.identity = identity;
	}

	public Credentials getCredentials() {
		return credentials;
	}

	public void setCredentials(Credentials credentials) {
		this.credentials = credentials;
	}

	public UsuarioBo getUsuarioBo() {
		return usuarioBo;
	}

	public void setUsuarioBo(UsuarioBo usuarioBo) {
		this.usuarioBo = usuarioBo;
	}

	public PasswordPantalla getPasswordPantalla() {
		return passwordPantalla;
	}

	public void setPasswordPantalla(PasswordPantalla passwordPantalla) {
		this.passwordPantalla = passwordPantalla;
	}

}
