package com.atosorigin.deri.configuracion.password.screen;

import org.jboss.seam.ScopeType;
import org.jboss.seam.annotations.Name;
import org.jboss.seam.annotations.Scope;


@Name("passwordPantalla")
@Scope(ScopeType.CONVERSATION)
public class PasswordPantalla {
	
	private String passAntigua;
	private String nuevaPass;
	private String verificaPass;
	
	
	
	public String getPassAntigua() {
		return passAntigua;
	}
	public void setPassAntigua(String passAntigua) {
		this.passAntigua = passAntigua;
	}
	public String getNuevaPass() {
		return nuevaPass;
	}
	public void setNuevaPass(String nuevaPass) {
		this.nuevaPass = nuevaPass;
	}
	public String getVerificaPass() {
		return verificaPass;
	}
	public void setVerificaPass(String verificaPass) {
		this.verificaPass = verificaPass;
	}

}
