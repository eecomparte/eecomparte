package com.atosorigin.deri.contabilidad.grupocontable.action;

import java.util.List;

import org.jboss.seam.ScopeType;
import org.jboss.seam.annotations.In;
import org.jboss.seam.annotations.Name;
import org.jboss.seam.annotations.Scope;
import org.jboss.seam.international.StatusMessage.Severity;

import com.atosorigin.common.action.ModoPantalla;
import com.atosorigin.common.action.PaginatedListAction;
import com.atosorigin.common.constantes.Constantes;
import com.atosorigin.common.formvalidator.FormValidator;
import com.atosorigin.common.utils.GenericUtils;
import com.atosorigin.deri.contabilidad.grupocontable.business.GrupoContableBo;
import com.atosorigin.deri.contabilidad.grupocontable.screen.GrupoContablePantalla;
import com.atosorigin.deri.model.catalogo.Producto;
import com.atosorigin.deri.model.contabilidad.GrupoContable;
import com.atosorigin.deri.model.contabilidad.GrupoContableId;

/**
 * Clase action listener para el caso de uso de calendario de la Ordén
 */
@Name("grupoContableAction")
@Scope(ScopeType.CONVERSATION)
@FormValidator
public class GrupoContableAction extends PaginatedListAction {
	
	@In(create=true)
	protected GrupoContablePantalla grupoContablePantalla;
	
	@In(value="#{grupoContableBo}")
	protected GrupoContableBo grupoContableBo;

	
	public void buscar(){
		setPrimerAcceso(false);
		paginationData.reset();
		refrescarLista();
	}
	
	@Override
	public List<?> getDataTableList() {
		
		return grupoContablePantalla.getListaGruposContables();
	}

	@Override
	protected void refreshListInternal() {
		setExportExcel(false);
		
		String gc = grupoContablePantalla.getGc();
		String descGc = grupoContablePantalla.getDescGc();
		String tipoContable = Constantes.CADENA_VACIA;
		if(!GenericUtils.isNullOrBlank(grupoContablePantalla.getTipoContableBusqueda())){
			tipoContable = grupoContablePantalla.getTipoContableBusqueda().getCodigo();		
		}

		grupoContablePantalla.setGrupoContableSeleccionado(null);		
		
		if  ( grupoContablePantalla.getListaGruposContables() == null) {
			grupoContablePantalla.setListaGruposContables(
					grupoContableBo.buscar(grupoContablePantalla.getProductoBusqueda(), gc, tipoContable, descGc, paginationData));
		} else {		
		grupoContablePantalla.getListaGruposContables().clear();
		grupoContablePantalla.getListaGruposContables().addAll(
				grupoContableBo.buscar(grupoContablePantalla.getProductoBusqueda(), gc, tipoContable, descGc, paginationData));
		}
		
		setPrimerAcceso(false);
		
	}
	
	public void nuevo(){
		GrupoContableId id = new GrupoContableId(null, new Producto());
		grupoContablePantalla.setGrupoContSel(new GrupoContable(id));
		setModoPantalla(ModoPantalla.CREACION);
	}
	
	public void editar(){
		grupoContablePantalla.setGrupoContSel(grupoContableBo.cargar(grupoContablePantalla.getGrupoContableSeleccionado().getId()));
		//Guardo el id, por si me lo modifican.
		grupoContablePantalla.setProductoEdit(grupoContablePantalla.getGrupoContSel().getId().getProducto());
		grupoContablePantalla.setTipoContableEdit(grupoContablePantalla.getGrupoContSel().getTipoContable());
		
		
		setModoPantalla(ModoPantalla.EDICION);
	}
	
	public String guardar(){
		grupoContablePantalla.getGrupoContSel().getId().setProducto(grupoContablePantalla.getProductoEdit());
		grupoContablePantalla.getGrupoContSel().setTipoContable(grupoContablePantalla.getTipoContableEdit());
		
		grupoContableBo.guardar(grupoContablePantalla.getGrupoContSel());
		refrescarLista();
		return Constantes.CONSTANTE_SUCCESS;
	}
	
	public boolean guardarValidator(){
		if(ModoPantalla.CREACION.equals(getModoPantalla())){
			
			String gc = grupoContablePantalla.getGrupoContSel().getId().getGrupoContable();
			
			
			List<GrupoContable> ql = grupoContableBo.buscar(grupoContablePantalla.getProductoEdit(), gc, null , null, paginationData);
			if(ql.size()>0){
				statusMessages.add(Severity.ERROR, "#{messages['grupoContable.error.grupoYaExiste']}", Constantes.DEFAULT_MESSAGE_TEMPLATE);
				return false;
			}
		}
		return true;
	}

	public void borrar(){
		grupoContablePantalla.getListaGruposContables().remove(grupoContablePantalla.getGrupoContSel());		
		grupoContableBo.borrar(grupoContablePantalla.getGrupoContSel());
		refrescarLista();
	}
	
	@Override
	public void refrescarListaExcel() {
		setExportExcel(true);
		
		String gc = grupoContablePantalla.getGc();
		String descGc = grupoContablePantalla.getDescGc();
		String tipoContable = Constantes.CADENA_VACIA;
		if(!GenericUtils.isNullOrBlank(grupoContablePantalla.getTipoContableBusqueda())){
			tipoContable = grupoContablePantalla.getTipoContableBusqueda().getCodigo();
		}
		List<GrupoContable> ql = grupoContableBo.buscar(grupoContablePantalla.getProductoBusqueda(), gc, tipoContable, descGc, paginationData.getPaginationDataForExcel());
		grupoContablePantalla.setListaGruposContables(ql);
		
	}

	@Override
	public void setDataTableList(List<?> dataTableList) {
		grupoContablePantalla.setListaGruposContables((List<GrupoContable>)dataTableList);
		
	}

	public GrupoContablePantalla getGrupoContablePantalla() {
		return grupoContablePantalla;
	}

	public void setGrupoContablePantalla(GrupoContablePantalla grupoContablePantalla) {
		this.grupoContablePantalla = grupoContablePantalla;
	}

	

}
