package com.atosorigin.deri.contabilidad.grupocontable.screen;

import java.util.List;

import org.jboss.seam.ScopeType;
import org.jboss.seam.annotations.Name;
import org.jboss.seam.annotations.Out;
import org.jboss.seam.annotations.Scope;
import org.jboss.seam.annotations.datamodel.DataModel;
import org.jboss.seam.annotations.datamodel.DataModelSelection;

import com.atosorigin.deri.model.catalogo.Producto;
import com.atosorigin.deri.model.contabilidad.GrupoContable;
import com.atosorigin.deri.model.contabilidad.TiposContable;

/**
 *  Contiene los datos de pantalla necesarios para el caso de uso de titulares de la ordén.
 */

@Name("grupoContablePantalla")
@Scope(ScopeType.CONVERSATION)
public class GrupoContablePantalla {


	protected Producto productoBusqueda;
	
	protected TiposContable tipoContableBusqueda;
	
	protected String gc;
	
	protected String descGc;

	@DataModel(value="listaDtGruposContables")
	protected List<GrupoContable> listaGruposContables;
	
	@DataModelSelection(value="listaDtGruposContables")
	@Out(required=false)
	protected GrupoContable grupoContableSeleccionado;
	
	@Out(value="grupoContSel", required=false)
	protected GrupoContable grupoContSel;
	
	protected Producto productoEdit;
	
	protected TiposContable tipoContableEdit;
	

	public Producto getProductoBusqueda() {
		return productoBusqueda;
	}

	public void setProductoBusqueda(Producto productoBusqueda) {
		this.productoBusqueda = productoBusqueda;
	}

	public TiposContable getTipoContableBusqueda() {
		return tipoContableBusqueda;
	}

	public void setTipoContableBusqueda(TiposContable tipoContableBusqueda) {
		this.tipoContableBusqueda = tipoContableBusqueda;
	}

	public String getGc() {
		return gc;
	}

	public void setGc(String gc) {
		this.gc = gc;
	}

	public String getDescGc() {
		return descGc;
	}

	public void setDescGc(String descGc) {
		this.descGc = descGc;
	}

	public List<GrupoContable> getListaGruposContables() {
		return listaGruposContables;
	}

	public void setListaGruposContables(List<GrupoContable> listaGruposContables) {
		this.listaGruposContables = listaGruposContables;
	}

	public GrupoContable getGrupoContableSeleccionado() {
		return grupoContableSeleccionado;
	}

	public void setGrupoContableSeleccionado(GrupoContable grupoContableSeleccionado) {
		this.grupoContableSeleccionado = grupoContableSeleccionado;
	}

	public GrupoContable getGrupoContSel() {
		return grupoContSel;
	}

	public void setGrupoContSel(GrupoContable grupoContSel) {
		this.grupoContSel = grupoContSel;
	}

	public TiposContable getTipoContableEdit() {
		return tipoContableEdit;
	}

	public void setTipoContableEdit(TiposContable tipoContableEdit) {
		this.tipoContableEdit = tipoContableEdit;
	}

	public Producto getProductoEdit() {
		return productoEdit;
	}

	public void setProductoEdit(Producto productoEdit) {
		this.productoEdit = productoEdit;
	}

}
