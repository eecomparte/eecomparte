package com.atosorigin.deri.contrapartida.agrupcontrapartida.action;

import java.util.ArrayList;
import java.util.List;

import org.jboss.seam.ScopeType;
import org.jboss.seam.annotations.In;
import org.jboss.seam.annotations.Name;
import org.jboss.seam.annotations.Scope;
import org.jboss.seam.international.StatusMessage.Severity;

import com.atosorigin.common.action.PaginatedListAction;
import com.atosorigin.common.action.PaginationData;
import com.atosorigin.common.constantes.Constantes;
import com.atosorigin.common.excelexporter.CustomExcelExporter;
import com.atosorigin.common.formvalidator.FormValidator;
import com.atosorigin.common.utils.GenericUtils;
import com.atosorigin.deri.contrapartida.agrupcontrapartida.business.AgrupContrapartidaBo;
import com.atosorigin.deri.contrapartida.agrupcontrapartida.screen.AgrupContrapartidaPantalla;
import com.atosorigin.deri.contrapartida.business.ContrapartidaBo;
import com.atosorigin.deri.model.contrapartida.AgrupContrapartida;
import com.atosorigin.deri.model.contrapartida.Contrapartida;
import com.atosorigin.deri.model.contrapartida.GrupoBancario;
import com.atosorigin.deri.model.contrapartida.GrupoContrapartida;

/**
 * Clase que actúa de action listener para el caso de uso de agrupación de contrapartidas.
 */
@Name("agrupContrapartidaAction")
@Scope(ScopeType.CONVERSATION)
@FormValidator
public class AgrupContrapartidaAction extends PaginatedListAction{

	/**
	 * Inyección del bean de Spring "agrupContrapartidaBo" que contiene los métodos de negocio
	 * para el caso de uso de agrupación de contrapartidas
	 */
	@In("#{agrupContrapartidaBo}")
	protected AgrupContrapartidaBo agrupContrapartidaBo;
	
	/**
	 * Inyección del bean de Spring "contrapartidaBo" que contiene los métodos de negocio
	 * para el caso de uso de contrapartidas
	 */	
	@In("#{contrapartidaBo}")
	protected ContrapartidaBo contrapartidaBo;

	/**
	 * Inyección del screen bean que contiene los datos de pantalla del caso de uso
	 * mantenimiento de agrupación de contrapartidas.
	 */
	@In(create=true)
	protected AgrupContrapartidaPantalla agrupContrapartidaPantalla;
	
	/**
	 * True si debe habilitarse el botón asignar y deshabilitar desasignar
	 * False si se deshabilita el botón asignar y habilitar desasignar 
	 */
	protected boolean habilitarAsign = false;
	
	/** Los datos de paginación del 2º grid, listado contrapartidas */
	public PaginationData paginationDataDelegate = new PaginationData();
	
	public boolean primerAccesoContra = true;
	
	public void setPrimerAcceso(boolean primerAcceso) {
		this.primerAcceso = primerAcceso;
	}
	
	/**
	 *  Selecciona las contrapartidas marcadas con los CheckBoxs
	 *  Indica si debe habilitarse o no los botones Asignar/Desasignar 
	 */	
	public void setSelectedContraItems() {
		agrupContrapartidaPantalla.getSelectedContraItems();
	}	
	
	/**
	 *  Selecciona los grupo contrapartidas marcados con los CheckBoxs
	 *  Indica si debe habilitarse o no los botones Asignar/Desasignar 
	 */
	public void setSelectedItems() {
		agrupContrapartidaPantalla.getSelectedItems();
		if (agrupContrapartidaPantalla.getSelectedDataList().isEmpty()){
			habilitarAsign = true;
		}else{
			habilitarAsign = false;
		}
	}	
	public boolean isHabilitarAsign() {
		return habilitarAsign;
	}

	public void setHabilitarAsign(boolean habilitarAsign) {
		this.habilitarAsign = habilitarAsign;
	}

	/**
	 * Actualiza la lista del grid de grupos de contrapartidas.
	 * 
	 */
	public void buscar() {
		setHabilitarAsign(true);
		paginationData.reset();
		if (agrupContrapartidaPantalla.getSelectedDataList()!=null){
			agrupContrapartidaPantalla.getSelectedDataList().clear();	
		}
		if (agrupContrapartidaPantalla.getSelectedContraDataList()!=null){
			agrupContrapartidaPantalla.getSelectedContraDataList().clear();	
		}		
		
		refrescarLista();
		setPrimerAcceso(false);
	}
	
	//FLM: Validación de errores
	public String contrapartida(GrupoContrapartida grupoContrapartida) {
		try {
			return grupoContrapartida.getId().getContrapartida().getId();			
		} catch (Exception e) {
			return grupoContrapartida.getContrapa();
		}
	}
	
	//FLM: Validación de errores
	public boolean checkExisteContrapartida(GrupoContrapartida grupoContrapartida) {
		try {
			String id= grupoContrapartida.getId().getContrapartida().getId();
			return true;
		} catch (Exception e) {
			//statusMessages.add(Severity.ERROR, "#{messages['agrupcontrapartida.buscar.notfound']}", e );
			//statusMessages.addFromResourceBundle(Severity.ERROR, "agrupcontrapartida.buscar.notfound",  e.toString() );			
			return false;
		}
	}
	

	public boolean existeContrapartida(GrupoContrapartida grupoContrapartida) {
		try {
			String id= grupoContrapartida.getId().getContrapartida().getId();
			return true;
		} catch (Exception e) {
			return false;
		}
	}
	
	public String contrapartidaDesc(GrupoContrapartida grupoContrapartida) {
		try {
			return grupoContrapartida.getId().getContrapartida().getDescCorta();			
		} catch (Exception e) {
			return "--";
		}
	}
	

	/**
	 * Método de validación de formulario previo a la acción guardar.
	 * El interceptor seam FormValidator lo ejecutará antes del método "guardar".
	 * Verifica la existencia de un grupo con el mismo Código
	 * @return true si no hay errores de validación, false en caso contrario.
	 */
	public boolean guardarValidator() {
		List<Contrapartida> selectedDataContraList = agrupContrapartidaPantalla.getSelectedContraDataList();
		Long existente = new Long(0);
		Contrapartida contrapartidaAux = null;
		
		if (!GenericUtils.isNullOrBlank(selectedDataContraList)
				&&selectedDataContraList.size()>500){
			statusMessages.add(Severity.ERROR,"agrupcontrapartida.asigna.error.maxContr");
			return false;
		}
		
		for (int i=0; i< selectedDataContraList.size(); i++){			
			contrapartidaAux = (Contrapartida) selectedDataContraList.get(i);
			existente = agrupContrapartidaBo.contrapartidaEnGrupoContrapartida(contrapartidaAux.getId(), agrupContrapartidaPantalla.getAgrupContrapartidaSelect().getId());
			if (existente > 0){
				statusMessages.addFromResourceBundle(Severity.ERROR,"agrupcontrapartida.asigna.error.contraExistente", contrapartidaAux.getId(), agrupContrapartidaPantalla.getAgrupContrapartidaSelect().getId());
				return false;				
			}
		}
		
		return true;
	}
	
	/**
	 * Graba el tipo de contrapartida en la base de datos.
	 * 
	 */
	public String guardar() {
		List<Contrapartida> selectedDataContraList = agrupContrapartidaPantalla.getSelectedContraDataList();	
		agrupContrapartidaBo.asignarContrapartida(agrupContrapartidaPantalla.getAgrupContrapartidaSelect(), selectedDataContraList);
		statusMessages.addFromResourceBundle(Severity.INFO,"agrupcontrapartida.asigna.success", agrupContrapartidaPantalla.getAgrupContrapartidaSelect().getDescripcion());		
		refrescarLista();				
		return Constantes.CONSTANTE_SUCCESS;
	}	
		
	//Métodos necesarios para pantallas con grids.
	//Es necesario implementar estos métodos abstractos de PaginatedListAction
	@Override
	public List<?> getDataTableList() {
		return agrupContrapartidaPantalla.getGrupoContrapartidaList();
	}

	@Override
	@SuppressWarnings("unchecked")
	public void setDataTableList(List<?> dataTableList) {
		agrupContrapartidaPantalla.setGrupoContrapartidaList((List<GrupoContrapartida>)dataTableList);				
	}

	@Override
	protected void refreshListInternal() {
		setExportExcel(false);		
		AgrupContrapartida agrupContrapartidaSelect = agrupContrapartidaPantalla.getAgrupContrapartidaSelect();
		List<GrupoContrapartida> contrapartidaList = agrupContrapartidaBo.buscarContrapartidasAgrupadas(agrupContrapartidaSelect==null?null:agrupContrapartidaSelect.getId(), paginationData);
		//FLM : Validar que las contrapartidas existen
		for (GrupoContrapartida grupoContrapartida : contrapartidaList) {
			checkExisteContrapartida(grupoContrapartida);
		}
		setDataTableList(contrapartidaList);
	}

	@Override
	public void refrescarListaExcel() {
		setExportExcel(true);
		List<GrupoContrapartida> grupoContrapartidaList = agrupContrapartidaBo.buscarContrapartidasAgrupadas(agrupContrapartidaPantalla.getAgrupContrapartidaSelect().getId(), paginationData.getPaginationDataForExcel());
		setDataTableList(grupoContrapartidaList);
	}	
	
	public void desasignar(){
		List<GrupoContrapartida> selectedDataList = agrupContrapartidaPantalla.getSelectedDataList();
		agrupContrapartidaBo.desasignarContrapartida(selectedDataList);	
		refrescarLista();
		setHabilitarAsign(true);
	}

	/**
	 * Actualiza la lista del grid de contrapartidas.
	 * 
	 */
	public void asignar() {
		setPrimerAccesoContra(true);
		paginationDataDelegate.reset();	
		//Limpiar parámetros de búsqueda de contrapartidas
		agrupContrapartidaPantalla.setTipoContrapartidaSelect(null);
		agrupContrapartidaPantalla.setContrapartidaList(null);
		agrupContrapartidaPantalla.setDescripcion(null);
		agrupContrapartidaPantalla.setCodigo(null);
		agrupContrapartidaPantalla.setGrupoBancario(new GrupoBancario());
		agrupContrapartidaPantalla.setSelectedContraDataList(new ArrayList<Contrapartida>());
	}

	/**
	 * Actualiza la lista del grid de contrapartidas.
	 * 
	 */
	public void buscarContrapartidas() {
		paginationDataDelegate.reset();		
		refrescarListaContrapartidas();
		setPrimerAccesoContra(false);		
	}
	
	
	public void refrescarListaContrapartidas() {		
		setExportExcel(false);
		List<Contrapartida> contrapartidaList = contrapartidaBo.buscarContrapartidas(agrupContrapartidaPantalla.getTipoContrapartidaSelect()==null?null:agrupContrapartidaPantalla.getTipoContrapartidaSelect().getId(), agrupContrapartidaPantalla.getDescripcion(), agrupContrapartidaPantalla.getCodigo(), agrupContrapartidaPantalla.getGrupoBancario(), paginationDataDelegate);
		agrupContrapartidaPantalla.setContrapartidaList(contrapartidaList);
	}

	
	@In("#{customExcelExporter}")
	protected CustomExcelExporter customExcelExporter;
	/**
   	 * Proxy para la generación de excel. Consiste en cambiar los datos de paginación
   	 * del grid actual por unos adecuados para el excel (los primeros 65000.
   	 * 
   	 * @param dataTableId Identificador del dataTable a exportar.
   	 * @param action ActionListener que contiene la lista paginable.
   	 */
   	public void generarExcelDelegate(String dataTableId)
	   {
		  List<?> resultadosActuales = this.getDataTableList();
		  this.refrescarListaExcelDelegate();
		  customExcelExporter.export(dataTableId);
	      this.setDataTableList(resultadosActuales);
	      //this.setExportExcel(false);
	   }

   	
	public void refrescarListaExcelDelegate() {
		setExportExcel(true);
//		List<GrupoContrapartida> grupoContrapartidaList = agrupContrapartidaBo.buscarContrapartidasAgrupadas(agrupContrapartidaPantalla.getAgrupContrapartidaSelect().getId(), paginationDataDelegate.getPaginationDataForExcel());
//		setDataTableList(grupoContrapartidaList);
		List<Contrapartida> contrapartidaList = contrapartidaBo.buscarContrapartidas(agrupContrapartidaPantalla.getTipoContrapartidaSelect()==null?null:agrupContrapartidaPantalla.getTipoContrapartidaSelect().getId(), agrupContrapartidaPantalla.getDescripcion(), agrupContrapartidaPantalla.getCodigo(), agrupContrapartidaPantalla.getGrupoBancario(), paginationDataDelegate.getPaginationDataForExcel());
		agrupContrapartidaPantalla.setContrapartidaList(contrapartidaList);
	}

	
	/** ****************************
	 * LISTADO DE CONTRAPARTIDAS 
	 ******************************* */
	
	
	public PaginationData getPaginationDataDelegate() {
		return paginationDataDelegate;
	}

	public void setPaginationDataDelegate(PaginationData paginationDataDelegate) {
		this.paginationDataDelegate = paginationDataDelegate;
	}
	
	public void firstDelegate() {
		paginationDataDelegate.setFirstResult(0);
		this.refrescarListaContrapartidas();
	}

	public boolean isPreviousExistsDelegate() {
		return paginationDataDelegate.getFirstResult() > 1;
	}
	
	public void previousDelegate() {
		paginationDataDelegate.setFirstResult(paginationDataDelegate.getFirstResult() - paginationDataDelegate.getMaxResults());
		this.refrescarListaContrapartidas();
	}
	
	public boolean isNextExistsDelegate() {
		return agrupContrapartidaPantalla.getContrapartidaList() != null && paginationDataDelegate.getMaxResults() != null
				&& agrupContrapartidaPantalla.getContrapartidaList().size() > paginationDataDelegate.getMaxResults();
	}	
	
	public void nextDelegate() {
		paginationDataDelegate.setFirstResult(paginationDataDelegate.getFirstResult() + paginationDataDelegate.getMaxResults());
		this.refrescarListaContrapartidas();
	}

	public void setPrimerAccesoContra(boolean primerAccesoContra) {
		this.primerAccesoContra = primerAccesoContra;
	}	
	
	public boolean isPrimerAccesoContra() {
		return primerAccesoContra;
	}	
}
