package com.atosorigin.deri.contrapartida.agrupcontrapartida.screen;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.jboss.seam.ScopeType;
import org.jboss.seam.annotations.Name;
import org.jboss.seam.annotations.Out;
import org.jboss.seam.annotations.Scope;
import org.jboss.seam.annotations.datamodel.DataModel;
import org.jboss.seam.annotations.datamodel.DataModelSelection;

import com.atosorigin.common.utils.GenericUtils;
import com.atosorigin.deri.model.contrapartida.AgrupContrapartida;
import com.atosorigin.deri.model.contrapartida.Contrapartida;
import com.atosorigin.deri.model.contrapartida.GrupoBancario;
import com.atosorigin.deri.model.contrapartida.GrupoContrapartida;
import com.atosorigin.deri.model.contrapartida.GrupoContrapartidaId;
import com.atosorigin.deri.model.contrapartida.TipoContrapartida;


/**
 *  Contiene los datos de pantalla necesarios para el caso de uso de agrupación de contrapartidas.
 */
@Name("agrupContrapartidaPantalla")
@Scope(ScopeType.CONVERSATION)
public class AgrupContrapartidaPantalla {

	protected AgrupContrapartida agrupContrapartidaSelect;

	public AgrupContrapartida getAgrupContrapartidaSelect() {
		return agrupContrapartidaSelect;
	}

	public void setAgrupContrapartidaSelect(
			AgrupContrapartida agrupContrapartidaSelect) {
		this.agrupContrapartidaSelect = agrupContrapartidaSelect;
	}
	
	/** Lista de datos para el grid. */
	@DataModel(value ="listaDtGrupoContrapartida")
	protected List<GrupoContrapartida> grupoContrapartidaList;
	
	@DataModelSelection(value ="listaDtGrupoContrapartida")
    @Out(value="grupoContrapartida", required=false)
	protected GrupoContrapartida grupoContrapartida;
	
	/**
	 * Selección checkbox GrupoContrapartida
	 */
	private Map<GrupoContrapartidaId, Boolean> selectedIds = new HashMap<GrupoContrapartidaId, Boolean>();
    private List<GrupoContrapartida> selectedDataList = new ArrayList<GrupoContrapartida>();
    
    
	/*
	 * Pantalla Asignación Contrapartidas - Ini
	 */
	protected TipoContrapartida tipoContrapartidaSelect;

	public TipoContrapartida getTipoContrapartidaSelect() {
		return tipoContrapartidaSelect;
	}

	public void setTipoContrapartidaSelect(
			TipoContrapartida tipoContrapartidaSelect) {
		this.tipoContrapartidaSelect = tipoContrapartidaSelect;
	}

	protected String descripcion;
	
	protected String codigo;
	
	protected GrupoBancario grupoBancario = new GrupoBancario();
	
	/** Lista de datos para el grid. */
	@DataModel(value ="listaDtContrapartida")
	protected List<Contrapartida> contrapartidaList;
	
	@DataModelSelection(value ="listaDtContrapartida")
    @Out(value="contrapartida", required=false)
	protected Contrapartida contrapartida;

	/**
	 * Selección checkbox Contrapartida
	 */
	private Map<String, Boolean> selectedContraIds = new HashMap<String, Boolean>();
    private List<Contrapartida> selectedContraDataList;

	/*
	 * Pantalla Asignación Contrapartidas - Fin
	 */	

    public String getSelectedItems() {

        for (GrupoContrapartida dataItem : grupoContrapartidaList) {
            if (!GenericUtils.isNullOrBlank(selectedIds.get(dataItem.getId()))){
            	if (selectedIds.get(dataItem.getId()).booleanValue() 
            			&& !selectedDataList.contains(dataItem)) {
            		selectedDataList.add(dataItem);
            		selectedIds.remove(dataItem.getId()); // Reset.
            	}else{
            		selectedDataList.remove(dataItem);
            	}
            }
        }

        return "selected";
    }

    public Map<GrupoContrapartidaId, Boolean> getSelectedIds() {
        return selectedIds;
    }

    public List<GrupoContrapartida> getSelectedDataList() {
        return selectedDataList;
    }

	public List<GrupoContrapartida> getGrupoContrapartidaList() {
		return grupoContrapartidaList;
	}

	public void setGrupoContrapartidaList(
			List<GrupoContrapartida> grupoContrapartidaList) {
		this.grupoContrapartidaList = grupoContrapartidaList;
	}

	public GrupoContrapartida getGrupoContrapartida() {
		return grupoContrapartida;
	}

	public void setGrupoContrapartida(GrupoContrapartida grupoContrapartida) {
		this.grupoContrapartida = grupoContrapartida;
	}

	public String getDescripcion() {
		return descripcion;
	}

	public void setDescripcion(String descripcion) {
		this.descripcion = descripcion;
	}

	public String getCodigo() {
		return codigo;
	}

	public void setCodigo(String codigo) {
		this.codigo = codigo;
	}

	public GrupoBancario getGrupoBancario() {
		return grupoBancario;
	}

	public void setGrupoBancario(GrupoBancario grupoBancario) {
		this.grupoBancario = grupoBancario;
	}

	public List<Contrapartida> getContrapartidaList() {
		return contrapartidaList;
	}

	public void setContrapartidaList(List<Contrapartida> contrapartidaList) {
		this.contrapartidaList = contrapartidaList;
	}

	public Contrapartida getContrapartida() {
		return contrapartida;
	}

	public void setContrapartida(Contrapartida contrapartida) {
		this.contrapartida = contrapartida;
	}
    

    public String getSelectedContraItems() {

        for (Contrapartida dataItem : contrapartidaList) {
            if (!GenericUtils.isNullOrBlank(selectedContraIds.get(dataItem.getId()))){
            	if (selectedContraIds.get(dataItem.getId()).booleanValue() 
            			&& !selectedContraDataList.contains(dataItem)) {
            		selectedContraDataList.add(dataItem);
            		selectedContraIds.remove(dataItem.getId()); // Reset.
            	}else{
            		selectedContraDataList.remove(dataItem);
            	}
            }
        }

        return "selected";
    }

    public Map<String, Boolean> getSelectedContraIds() {
        return selectedContraIds;
    }

    public List<Contrapartida> getSelectedContraDataList() {
        return selectedContraDataList;
    }

	public void setSelectedContraDataList(List<Contrapartida> selectedContraDataList) {
		this.selectedContraDataList = selectedContraDataList;
	}	
}
