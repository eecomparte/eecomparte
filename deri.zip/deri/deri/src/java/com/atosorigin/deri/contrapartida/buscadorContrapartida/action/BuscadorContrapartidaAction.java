package com.atosorigin.deri.contrapartida.buscadorContrapartida.action;

import java.util.List;

import org.jboss.seam.ScopeType;
import org.jboss.seam.annotations.In;
import org.jboss.seam.annotations.Name;
import org.jboss.seam.annotations.Scope;

import com.atosorigin.common.action.PaginatedListAction;
import com.atosorigin.common.constantes.Constantes;
import com.atosorigin.common.formvalidator.FormValidator;
import com.atosorigin.common.utils.GenericUtils;
import com.atosorigin.deri.contrapartida.buscadorContrapartida.screen.BuscadorContrapartidaPantalla;
import com.atosorigin.deri.contrapartida.business.ContrapartidaBo;
import com.atosorigin.deri.model.contrapartida.Contrapartida;

/**
 * Clase que actúa de action listener para el caso de uso de mantenimiento de tipos de contrapartidas.
 */
@Name("buscadorContrapartidaAction")
@Scope(ScopeType.CONVERSATION)
@FormValidator
public class BuscadorContrapartidaAction extends PaginatedListAction{

	/**
	 * Inyección del bean de Spring "tipoContrapartidaBo" que contiene los métodos de negocio
	 * para el caso de uso mantenimiento de tipos de contrapartidas.
	 */
	@In("#{contrapartidaBo}")
	protected ContrapartidaBo contrapartidaBo;


	/**
	 * Inyección del screen bean que contiene los datos de pantalla del caso de uso
	 * mantenimiento de tipos de contrapartidas.
	 */
	@In(create=true)
	protected BuscadorContrapartidaPantalla buscadorContrapartidaPantalla;

	/**
	 * Actualiza la lista del grid de tipos de contrapartidas.
	 * 
	 */
	public void buscar() {
		//SMM BUG - resetear ordenacion
		paginationData.reset();
		refrescarLista();
		setPrimerAcceso(false);
		//statusMessages.add("#{messages['status.busqueda.completada']}");
	}

	public void buscar(String proyecto) {
		//SMM BUG - resetear ordenacion
		paginationData.reset();
		buscadorContrapartidaPantalla.setProyecto(proyecto);
		refrescarLista();
		setPrimerAcceso(false);
		//statusMessages.add("#{messages['status.busqueda.completada']}");
	}

	
	//Métodos necesarios para pantallas con grids.
	//Es necesario implementar estos métodos abstractos de PaginatedListAction
	@Override
	public List<Contrapartida> getDataTableList() {
		return buscadorContrapartidaPantalla.getContrapartidaList();
	}

	@Override
	@SuppressWarnings("unchecked")
	public void setDataTableList(List<?> dataTableList) {
		buscadorContrapartidaPantalla.setContrapartidaList((List<Contrapartida>)dataTableList);
	}

	@SuppressWarnings("unchecked")
	@Override
	protected void refreshListInternal() {
		List ql=null;
		if(!GenericUtils.isNullOrBlank(buscadorContrapartidaPantalla.getProyecto()) 
				&& Constantes.APLICACION_COLAT.equalsIgnoreCase(buscadorContrapartidaPantalla.getProyecto())){
			ql = (List)contrapartidaBo.buscarContrapartidas(null, buscadorContrapartidaPantalla.getDescripcion(), buscadorContrapartidaPantalla.getCodigo(), null,buscadorContrapartidaPantalla.getProyecto(), paginationData);
		}else{
			ql = (List)contrapartidaBo.buscarContrapartidas(null, buscadorContrapartidaPantalla.getDescripcion(), buscadorContrapartidaPantalla.getCodigo(), null, paginationData);
		}
		buscadorContrapartidaPantalla.setContrapartidaList(ql);
	}

	@SuppressWarnings("unchecked")
	@Override
	public void refrescarListaExcel() {
		List ql=null;
		if(!GenericUtils.isNullOrBlank(buscadorContrapartidaPantalla.getProyecto())
				&& Constantes.APLICACION_COLAT.equalsIgnoreCase(buscadorContrapartidaPantalla.getProyecto())){
			 ql = (List)contrapartidaBo.buscarContrapartidas(null, buscadorContrapartidaPantalla.getDescripcion(), buscadorContrapartidaPantalla.getCodigo(), null,buscadorContrapartidaPantalla.getProyecto(), paginationData.getPaginationDataForExcel());			
		}else{
			 ql = (List)contrapartidaBo.buscarContrapartidas(null, buscadorContrapartidaPantalla.getDescripcion(), buscadorContrapartidaPantalla.getCodigo(), null, paginationData.getPaginationDataForExcel());	
		}
		
		buscadorContrapartidaPantalla.setContrapartidaList(ql);
	}	
	
	public String quitaComillas(String textConComillas){
		return textConComillas.replaceAll("'", "\\\\'");
	}
	
}
