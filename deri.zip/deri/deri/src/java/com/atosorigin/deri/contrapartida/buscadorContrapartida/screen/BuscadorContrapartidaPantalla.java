package com.atosorigin.deri.contrapartida.buscadorContrapartida.screen;

import java.util.List;

import org.jboss.seam.ScopeType;
import org.jboss.seam.annotations.Name;
import org.jboss.seam.annotations.Out;
import org.jboss.seam.annotations.Scope;
import org.jboss.seam.annotations.datamodel.DataModel;
import org.jboss.seam.annotations.datamodel.DataModelSelection;

import com.atosorigin.deri.model.contrapartida.Contrapartida;


/**
 *  Contiene los datos de pantalla necesarios para el caso de uso mantenimiento de tipos de contrapartidas.
 */
@Name("buscadorContrapartidaPantalla")
@Scope(ScopeType.CONVERSATION)
public class BuscadorContrapartidaPantalla {

	/** Descripcion. Criterio de búsqueda de tipos de contrapartidas  */
	protected String descripcion;
	
	protected String codigo;
	
	protected boolean tipocliente = false;
	
	protected String proyecto;
	
	/** Lista de datos para el grid. */
	@DataModel(value ="listaBuscadorContrapartidas")
	protected List<Contrapartida> contrapartidaList;
	
	/** Tipo de contrapartida seleccionado en el grid */
	@DataModelSelection(value ="listaBuscadorContrapartidas")
    @Out(required=false)
    protected Contrapartida contrapartida;

	/** Número de resultados totales para los criterios de búsqueda. */
	protected Long numFilas = 0L;
	
	public String getDescripcion() {
		return descripcion;
	}

	public void setDescripcion(String descripcion) {
		this.descripcion = descripcion;
	}

	/**
	 * Obtiene la Lista de datos para el grid.
	 * 
	 * @return la lista de tipos de contrapartidas que mostrará el grid de resultados de la búsqueda.
	 */
	public List<Contrapartida> getContrapartidaList() {
		return contrapartidaList;
	}
	
	/**
	 * Establece la Lista de datos para el grid.
	 * 
	 * @param tipoContrapartidaList la lista de tipos de contrapartidas del grid.
	 */
	public void setContrapartidaList(List<Contrapartida> contrapartidaList) {
		this.contrapartidaList = contrapartidaList;
	}

	public Contrapartida getContrapartida() {
		return contrapartida;
	}

	public void setContrapartida(Contrapartida contrapartida) {
		this.contrapartida = contrapartida;
	}

	public Long getNumFilas() {
		return numFilas;
	}

	public void setNumFilas(Long numFilas) {
		this.numFilas = numFilas;
	}

	public boolean isTipocliente() {
		return tipocliente;
	}

	public void setTipocliente(boolean tipocliente) {
		this.tipocliente = tipocliente;
	}

	public String getCodigo() {
		return codigo;
	}

	public void setCodigo(String codigo) {
		this.codigo = codigo;
	}

	public String getProyecto() {
		return proyecto;
	}

	public void setProyecto(String proyecto) {
		this.proyecto = proyecto;
	}


}
