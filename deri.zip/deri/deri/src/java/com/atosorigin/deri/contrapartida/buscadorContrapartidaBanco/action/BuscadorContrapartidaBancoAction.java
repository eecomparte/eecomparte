package com.atosorigin.deri.contrapartida.buscadorContrapartidaBanco.action;

import java.util.List;

import org.jboss.seam.ScopeType;
import org.jboss.seam.annotations.In;
import org.jboss.seam.annotations.Name;
import org.jboss.seam.annotations.Scope;

import com.atosorigin.common.action.PaginatedListAction;
import com.atosorigin.common.formvalidator.FormValidator;
import com.atosorigin.deri.contrapartida.buscadorContrapartida.screen.BuscadorContrapartidaPantalla;
import com.atosorigin.deri.contrapartida.business.ContrapartidaBo;
import com.atosorigin.deri.model.contrapartida.Contrapartida;

/**
 * Clase que actúa de action listener para el caso de uso de mantenimiento de tipos de contrapartidas.
 */
@Name("buscadorContrapartidaBancoAction")
@Scope(ScopeType.CONVERSATION)
@FormValidator
public class BuscadorContrapartidaBancoAction extends PaginatedListAction{

	/**
	 * Inyección del bean de Spring "tipoContrapartidaBo" que contiene los métodos de negocio
	 * para el caso de uso mantenimiento de tipos de contrapartidas.
	 */
	@In("#{contrapartidaBo}")
	protected ContrapartidaBo contrapartidaBo;


	/**
	 * Inyección del screen bean que contiene los datos de pantalla del caso de uso
	 * mantenimiento de tipos de contrapartidas.
	 */
	@In(create=true)
	protected BuscadorContrapartidaPantalla buscadorContrapartidaPantalla;

	/**
	 * Actualiza la lista del grid de tipos de contrapartidas.
	 * 
	 */
	public void buscar() {
		//SMM BUG - resetear ordenacion
		paginationData.reset();
		refrescarLista();
		setPrimerAcceso(false);
		//statusMessages.add("#{messages['status.busqueda.completada']}");
	}

	//Métodos necesarios para pantallas con grids.
	//Es necesario implementar estos métodos abstractos de PaginatedListAction
	@Override
	public List<Contrapartida> getDataTableList() {
		return buscadorContrapartidaPantalla.getContrapartidaList();
	}

	@Override
	@SuppressWarnings("unchecked")
	public void setDataTableList(List<?> dataTableList) {
		buscadorContrapartidaPantalla.setContrapartidaList((List<Contrapartida>)dataTableList);
	}

	@SuppressWarnings("unchecked")
	@Override
	protected void refreshListInternal() {
		List ql = (List)contrapartidaBo.buscarContrapartidasBanco(null, buscadorContrapartidaPantalla.getDescripcion(), buscadorContrapartidaPantalla.getCodigo(), null, paginationData);
		buscadorContrapartidaPantalla.setContrapartidaList(ql);
	}

	@SuppressWarnings("unchecked")
	@Override
	public void refrescarListaExcel() {
		List ql = (List)contrapartidaBo.buscarContrapartidasBanco(null, buscadorContrapartidaPantalla.getDescripcion(), buscadorContrapartidaPantalla.getCodigo(), null, paginationData.getPaginationDataForExcel());
		buscadorContrapartidaPantalla.setContrapartidaList(ql);
	}	
	
	public String quitaComillas(String textConComillas){
		return textConComillas.replaceAll("'", "\\\\'");
	}
	
}
