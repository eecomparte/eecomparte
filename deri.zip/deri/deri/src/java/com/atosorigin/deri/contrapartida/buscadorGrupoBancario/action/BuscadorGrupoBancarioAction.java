package com.atosorigin.deri.contrapartida.buscadorGrupoBancario.action;

import java.util.List;

import org.jboss.seam.ScopeType;
import org.jboss.seam.annotations.In;
import org.jboss.seam.annotations.Name;
import org.jboss.seam.annotations.Scope;

import com.atosorigin.common.action.PaginatedListAction;
import com.atosorigin.common.formvalidator.FormValidator;
import com.atosorigin.deri.contrapartida.buscadorGrupoBancario.screen.BuscadorGrupoBancarioPantalla;
import com.atosorigin.deri.grupobancario.business.GrupoBancarioBo;
import com.atosorigin.deri.model.contrapartida.GrupoBancario;

/**
 * Clase que actúa de action listener para el caso de uso de mantenimiento de tipos de contrapartidas.
 */
@Name("buscadorGrupoBancarioAction")
@Scope(ScopeType.CONVERSATION)
@FormValidator
public class BuscadorGrupoBancarioAction extends PaginatedListAction {

	@In(create=true)
	protected BuscadorGrupoBancarioPantalla buscadorGrupoBancarioPantalla;
	
	
	/**
	 * Inyección del bean de Spring "grupoBancarioBo" que contiene los métodos de negocio
	 * para el caso de uso mantenimiento de contrapartidas.
	 */
	@In(value="#{grupoBancarioBo}")
	protected GrupoBancarioBo grupoBancarioBo;
	
	@Override
	public List<?> getDataTableList() {
		return buscadorGrupoBancarioPantalla.getGrupoBancarioList();
	}

	@Override
	protected void refreshListInternal() {
		List ql = (List)grupoBancarioBo.buscar(buscadorGrupoBancarioPantalla.getDescripcion(), paginationData);
		buscadorGrupoBancarioPantalla.setGrupoBancarioList(ql);
	}
	
	/**
	 * Actualiza la lista del grid de tipos de contrapartidas.
	 * 
	 */
	public void buscar() {
		refrescarLista();
		setPrimerAcceso(false);
		paginationData.reset();
		//statusMessages.add("#{messages['status.busqueda.completada']}");
	}

	@Override
	public void refrescarListaExcel() {
		// TODO Auto-generated method stub

	}

	@Override
	public void setDataTableList(List<?> dataTableList) {
		buscadorGrupoBancarioPantalla.setGrupoBancarioList((List<GrupoBancario>)dataTableList);

	}

	public BuscadorGrupoBancarioPantalla getBuscadorGrupoBancarioPantalla() {
		return buscadorGrupoBancarioPantalla;
	}

	public void setBuscadorGrupoBancarioPantalla(
			BuscadorGrupoBancarioPantalla buscadorGrupoBancarioPantalla) {
		this.buscadorGrupoBancarioPantalla = buscadorGrupoBancarioPantalla;
	}

}
