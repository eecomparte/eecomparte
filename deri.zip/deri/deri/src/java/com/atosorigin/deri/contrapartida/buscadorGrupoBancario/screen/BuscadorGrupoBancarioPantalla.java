package com.atosorigin.deri.contrapartida.buscadorGrupoBancario.screen;

import java.util.List;

import org.jboss.seam.ScopeType;
import org.jboss.seam.annotations.Name;
import org.jboss.seam.annotations.Out;
import org.jboss.seam.annotations.Scope;
import org.jboss.seam.annotations.datamodel.DataModel;
import org.jboss.seam.annotations.datamodel.DataModelSelection;

import com.atosorigin.deri.model.contrapartida.GrupoBancario;


/**
 *  Contiene los datos de pantalla necesarios para el caso de uso mantenimiento de tipos de contrapartidas.
 */
@Name("buscadorGrupoBancarioPantalla")
@Scope(ScopeType.CONVERSATION)
public class BuscadorGrupoBancarioPantalla {

	/** Descripcion. Criterio de búsqueda de tipos de contrapartidas  */
	protected String descripcion;
	
	
	/** Lista de datos para el grid. */
	@DataModel(value ="listaBuscadorGrupoBancario")
	protected List<GrupoBancario> grupoBancarioList;
	
	/** Tipo de contrapartida seleccionado en el grid */
	@DataModelSelection(value ="listaBuscadorGrupoBancario")
    @Out(required=false)
    protected GrupoBancario grupoBancario;

	/** Número de resultados totales para los criterios de búsqueda. */
	protected Long numFilas = 0L;
	
	public String getDescripcion() {
		return descripcion;
	}

	public void setDescripcion(String descripcion) {
		this.descripcion = descripcion;
	}



	public Long getNumFilas() {
		return numFilas;
	}

	public void setNumFilas(Long numFilas) {
		this.numFilas = numFilas;
	}

	public List<GrupoBancario> getGrupoBancarioList() {
		return grupoBancarioList;
	}

	public void setGrupoBancarioList(List<GrupoBancario> grupoBancarioList) {
		this.grupoBancarioList = grupoBancarioList;
	}

	public GrupoBancario getGrupoBancario() {
		return grupoBancario;
	}

	public void setGrupoBancario(GrupoBancario grupoBancario) {
		this.grupoBancario = grupoBancario;
	}


}
