package com.atosorigin.deri.contrapartida.buscadorTipoDocu.action;

import java.util.List;

import org.jboss.seam.ScopeType;
import org.jboss.seam.annotations.In;
import org.jboss.seam.annotations.Name;
import org.jboss.seam.annotations.Scope;

import com.atosorigin.common.action.PaginatedListAction;
import com.atosorigin.common.formvalidator.FormValidator;
import com.atosorigin.deri.contrapartida.buscadorTipoDocu.screen.BuscadorTipoDocuPantalla;
import com.atosorigin.deri.contrapartida.manttipostocumento.business.MantTiposDocumentoBo;
import com.atosorigin.deri.model.contrapartida.TiposDocumento;

@Name("buscadorTipoDocuAction")
@Scope(ScopeType.CONVERSATION)
@FormValidator
public class BuscadorTipoDocuAction extends PaginatedListAction{

	/**
	 * Inyección del bean de Spring "mantTiposDocumentoBo" que contiene los métodos de negocio
	 * para el caso de uso mantenimiento de tipos de documento.
	 */
	@In("#{mantTiposDocumentoBo}")
	protected MantTiposDocumentoBo mantTiposDocumentoBo;

	/**
	 * Inyección del screen bean que contiene los datos de pantalla del caso de uso
	 * mantenimiento de tipos de contrapartidas.
	 */
	@In(create=true)
	protected BuscadorTipoDocuPantalla buscadorTipoDocuPantalla;

	/**
	 * Actualiza la lista del grid de tipos de documento.
	 * 
	 */
	public void buscar() {
		refrescarLista();
		setPrimerAcceso(false);
	}

	//Métodos necesarios para pantallas con grids.
	//Es necesario implementar estos métodos abstractos de PaginatedListAction
	@Override
	public List<TiposDocumento> getDataTableList() {
		return buscadorTipoDocuPantalla.getTiposDocuList();
	}

	@Override
	@SuppressWarnings("unchecked")
	public void setDataTableList(List<?> dataTableList) {
		buscadorTipoDocuPantalla.setTiposDocuList((List<TiposDocumento>)dataTableList);
	}

	@SuppressWarnings("unchecked")
	@Override
	protected void refreshListInternal() {
		List ql = (List)mantTiposDocumentoBo.buscar(buscadorTipoDocuPantalla.getId(), buscadorTipoDocuPantalla.getDescripcion(), null, null, paginationData);
		buscadorTipoDocuPantalla.setTiposDocuList(ql);
	}

	@SuppressWarnings("unchecked")
	@Override
	public void refrescarListaExcel() {
		List ql = (List)mantTiposDocumentoBo.buscar(buscadorTipoDocuPantalla.getId(), buscadorTipoDocuPantalla.getDescripcion(), null, null, paginationData.getPaginationDataForExcel());
		buscadorTipoDocuPantalla.setTiposDocuList(ql);
	}	
	
}
