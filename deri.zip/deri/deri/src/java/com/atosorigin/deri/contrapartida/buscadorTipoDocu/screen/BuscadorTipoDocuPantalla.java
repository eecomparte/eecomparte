package com.atosorigin.deri.contrapartida.buscadorTipoDocu.screen;

import java.util.List;

import org.jboss.seam.ScopeType;
import org.jboss.seam.annotations.Name;
import org.jboss.seam.annotations.Out;
import org.jboss.seam.annotations.Scope;
import org.jboss.seam.annotations.datamodel.DataModel;
import org.jboss.seam.annotations.datamodel.DataModelSelection;

import com.atosorigin.deri.model.contrapartida.TiposDocumento;

@Name("buscadorTipoDocuPantalla")
@Scope(ScopeType.CONVERSATION)
public class BuscadorTipoDocuPantalla {

	/** Código. Criterio de búsqueda de tipos de documento  */
	protected String id;
	
	/** Descripcion. Criterio de búsqueda de tipos de documento  */
	protected String descripcion;
	
	/** Lista de datos para el grid. */
	@DataModel(value ="listaBuscadorTiposDocu")
	protected List<TiposDocumento> tiposDocuList;
	
	/** Tipo de documento seleccionado en el grid */
	@DataModelSelection(value ="listaBuscadorTiposDocu")
    @Out(required=false)
    protected TiposDocumento tiposDocumento;

	public String getDescripcion() {
		return descripcion;
	}

	public void setDescripcion(String descripcion) {
		this.descripcion = descripcion;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	/**
	 * Obtiene la Lista de datos para el grid.
	 * 
	 * @return la lista de tipos documento que mostrará el grid de resultados de la búsqueda.
	 */
	public List<TiposDocumento> getTiposDocuList() {
		return tiposDocuList;
	}

	public TiposDocumento getTiposDocumento() {
		return tiposDocumento;
	}

	/**
	 * Establece la Lista de datos para el grid.
	 * 
	 * @param tiposDocuList la lista de tipos de documento del grid.
	 */
	public void setTiposDocuList(List<TiposDocumento> tiposDocuList) {
		this.tiposDocuList = tiposDocuList;
	}

	public void setTiposDocumento(TiposDocumento tiposDocumento) {
		this.tiposDocumento = tiposDocumento;
	}

}
