package com.atosorigin.deri.contrapartida.docsporcontrapartida.action;

import java.util.Date;
import java.util.List;

import org.jboss.seam.ScopeType;
import org.jboss.seam.annotations.Factory;
import org.jboss.seam.annotations.In;
import org.jboss.seam.annotations.Name;
import org.jboss.seam.annotations.Out;
import org.jboss.seam.annotations.Scope;
import org.jboss.seam.core.Conversation;
import org.jboss.seam.core.ResourceBundle;
import org.jboss.seam.international.StatusMessage.Severity;

import com.atosorigin.common.action.ModoPantalla;
import com.atosorigin.common.action.PaginatedListAction;
import com.atosorigin.common.action.PaginationData;
import com.atosorigin.common.constantes.Constantes;
import com.atosorigin.common.formvalidator.FormValidator;
import com.atosorigin.common.utils.GenericUtils;
import com.atosorigin.deri.common.parametrosPantalla.ParametrosOutAgenda;
import com.atosorigin.deri.contrapartida.business.ContrapartidaBo;
import com.atosorigin.deri.contrapartida.docscontrapartida.business.DocsContrapartidaBo;
import com.atosorigin.deri.contrapartida.docsporcontrapartida.screen.DocsContrapartidaPantalla;
import com.atosorigin.deri.contrapartida.manttipostocumento.business.MantTiposDocumentoBo;
import com.atosorigin.deri.model.adminoper.DescripcionEntidadOperacion;
import com.atosorigin.deri.model.contrapartida.Contrapartida;
import com.atosorigin.deri.model.contrapartida.DocsContrapartida;
import com.atosorigin.deri.model.contrapartida.DocsContrapartidaId;
import com.atosorigin.deri.model.contrapartida.EstadoDocumentoContrapartida;
import com.atosorigin.deri.model.contrapartida.TipoContrapartida;
import com.atosorigin.deri.model.contrapartida.TiposDocumento;
import com.atosorigin.deri.model.gestionoperaciones.Operacion;
import com.atosorigin.deri.model.preconfirmaciones.Preconfirmaciones;
import com.atosorigin.deri.util.MessageBoxAction;
import com.atosorigin.deri.util.MsgBoxAction;

/**
 * Clase action listener para el caso de uso de documentos por contrapartida.
 */
@Name("docsContrapartidaAction")
@Scope(ScopeType.CONVERSATION)
@FormValidator
public class DocsContrapartidaAction extends PaginatedListAction {

	/**
	 * Inyección del bean de Spring "docsContrapartidaBo" que contiene los métodos de negocio
	 * para el caso de uso documentos por contrapartida.
	 */
	@In("#{docsContrapartidaBo}")
	protected DocsContrapartidaBo docsContrapartidaBo;

	/**
	 * Inyección del bean de Spring "contrapartidaBo" que contiene los métodos de negocio
	 * para el caso de uso contrapartidas.
	 */
	@In("#{contrapartidaBo}")
	protected ContrapartidaBo contrapartidaBo;
	
	/**
	 * Inyección del bean de Spring "mantTiposDocumentoBo" que contiene los métodos de negocio
	 * para el caso de uso mantenimiento de documentos.
	 */
	@In("#{mantTiposDocumentoBo}")
	protected MantTiposDocumentoBo mantTiposDocumentoBo;
	
	/**
	 * Inyección del screen bean que contiene los datos de pantalla del caso de uso
	 * documentos por contrapartida.
	 */
	@In(create=true)
	protected DocsContrapartidaPantalla docsContrapartidaPantalla;

	/** Contrapartida seleccionada en la pantalla de mantenimiento de contrapartidas */
	@In(required=false)
    protected Contrapartida contrapartidaSelection;
	
	/** Variable para establecer si se llega a la pantalla de documentos por contrapartida
	 * desde mantenimiento de contrapartidas o desde agenda */
	private String modo;
	
	/**
	 * Inyección datos provenientes de Agenda
	 */
	@In(required = false, value="#{parametrosOutAgenda}")
	protected ParametrosOutAgenda parametrosOutAgenda;
	
	@In(create = true)
	MsgBoxAction msgBoxAction;
	
	@Out(required = false, value = "docsContrapartidaMessageBoxAction")
	private MessageBoxAction messageBoxDocsContrapartidaAction;
	
	private Boolean primeraEjecucionInit=null;

	/** Actualiza la lista del grid de documentos por contrapartida */
	public void buscar() {
		this.docsContrapartidaPantalla.setVieneAgenda(false);
		this.docsContrapartidaPantalla.setVieneMantContrapa(false);
		paginationData.reset(); /** Limpiamos la información de paginación */
		this.setModo(Constantes.CADENA_VACIA); /** Limpiamos el modo al pulsar buscar */
		refrescarLista();
		setPrimerAcceso(false);
	}
	
	/** Actualiza la lista del grid de documentos por contrapartida
	 * y vuelve a la pantalla de búsqueda */
	public void salirDetalle() {
		paginationData.reset(); /** Limpiamos la información de paginación */
		docsContrapartidaPantalla.setDocContrapartida(new DocsContrapartida());
		docsContrapartidaPantalla.setDocsContrapartidaList(null);
		docsContrapartidaPantalla.setDocContrapartida(null);
		if(this.modoPantalla.equals(ModoPantalla.EDICION)){
			refrescarLista();
		}
	}
	
	public void salir(){
		if(this.modoPantalla.equals(ModoPantalla.EDICION) || this.modoPantalla.equals(ModoPantalla.CREACION) ){
			paginationData.reset(); /** Limpiamos la información de paginación */
			refrescarLista();
		}
		
		Conversation conversacion = Conversation.instance();
		//Volvemos a la anterior conversación
		if(conversacion.isNested()){
			conversacion.redirectToParent();
		} else {
			if(docsContrapartidaPantalla.isVieneMantContrapa()) {
				redirectToURL("/pages/parametrizacion/contrapartida/contrapartida.xhtml");
			} else {
				redirectToURL("/home.seam");
			}
			conversacion.endAndRedirect();
		}
	}

	@Override
	protected void refreshListInternal() {
		this.setExportExcel(false);
		
		this.docsContrapartidaPantalla.setDocContrapartida(new DocsContrapartida());
		
		if(this.docsContrapartidaPantalla.isVieneAgenda()){
			rellenarListaAgenda(paginationData);
		} else {			
			String contrapa = Constantes.CADENA_VACIA;
			String tipoDocumento = Constantes.CADENA_VACIA;
			String estadoDocumento = Constantes.CADENA_VACIA;
					
			/** Cargamos los valores seleccionados en los criterios de búsqueda para realizar la consulta*/
			if (!GenericUtils.isNullOrBlank(this.docsContrapartidaPantalla.getContrapaBusq())){
				contrapa = this.docsContrapartidaPantalla.getContrapaBusq().getId();
				//SMM: necesario porque pierde la descripcion
				if (!GenericUtils.isNullOrBlank(contrapa)){
					Contrapartida contrapartida = contrapartidaBo.cargar(contrapa);
					if (!GenericUtils.isNullOrBlank(contrapartida)){
						docsContrapartidaPantalla.getContrapaBusq().setDescCorta(contrapartida.getDescCorta());
					}
				}
			}
			
			if (!GenericUtils.isNullOrBlank(this.docsContrapartidaPantalla.getTipoDocBusq())){
				tipoDocumento = this.docsContrapartidaPantalla.getTipoDocBusq().getId();
				//SMM: inc 748
				if (!GenericUtils.isNullOrBlank(tipoDocumento))
				{
					//SMM: necesario porque pierde la descripcion
					TiposDocumento tipoDocu = mantTiposDocumentoBo.cargar(tipoDocumento);
					if (!GenericUtils.isNullOrBlank(tipoDocu)){
						docsContrapartidaPantalla.getTipoDocBusq().setDescripcion(tipoDocu.getDescripcion());
					}
				}
			}

			if (!GenericUtils.isNullOrBlank(this.docsContrapartidaPantalla.getEstadoBusq())){
				estadoDocumento = this.docsContrapartidaPantalla.getEstadoBusq().getCodigo();
			}
			
			List<DocsContrapartida> listaDocsContrapa = (List<DocsContrapartida>)docsContrapartidaBo.buscarDocsContrapartida(contrapa,tipoDocumento,estadoDocumento,paginationData);
			docsContrapartidaPantalla.setDocsContrapartidaList(listaDocsContrapa);
		}
		
		
	}
	
	@Override
	public void refrescarListaExcel() {
		this.setExportExcel(true);
		
		if(this.docsContrapartidaPantalla.isVieneAgenda()){
			rellenarListaAgenda(paginationData.getPaginationDataForExcel());
		} else {
			String contrapa = Constantes.CADENA_VACIA;
			String tipoDocumento = Constantes.CADENA_VACIA;
			String estadoDocumento = Constantes.CADENA_VACIA;
			
			/** Cargamos los valores seleccionados en los criterios de búsqueda para realizar la consulta*/
			
			if (!GenericUtils.isNullOrBlank(this.docsContrapartidaPantalla.getContrapaBusq())){
				contrapa = this.docsContrapartidaPantalla.getContrapaBusq().getId();
			}
			
			if (!GenericUtils.isNullOrBlank(this.docsContrapartidaPantalla.getTipoDocBusq())){
				tipoDocumento = this.docsContrapartidaPantalla.getTipoDocBusq().getId();
			}

			if (!GenericUtils.isNullOrBlank(this.docsContrapartidaPantalla.getEstadoBusq())){
				estadoDocumento = this.docsContrapartidaPantalla.getEstadoBusq().getCodigo();
			}
			
			List<DocsContrapartida> listaDocsContrapa = (List<DocsContrapartida>)docsContrapartidaBo.buscarDocsContrapartida(contrapa,tipoDocumento,estadoDocumento,paginationData.getPaginationDataForExcel());
			docsContrapartidaPantalla.setDocsContrapartidaList(listaDocsContrapa);
		}
		
	}
	
	/**
	 * Carga la lista de Liquidaciones cuando venimos de la pantalla de Agenda
	 */
	public void initListaResultados(){
		setExportExcel(false);
		
		//Precargar la lista con Parametros si es la primera vez q entra
		//Si parametrosOutAgenda es nulo es que entramos desde el menú
		if (isPrimerAcceso()){
			if (!GenericUtils.isNullOrBlank(parametrosOutAgenda) 
					&&	!GenericUtils.isNullOrBlank(parametrosOutAgenda.getModo())
					&& parametrosOutAgenda.getModo().equals(Constantes.MODO_AGE)){
				docsContrapartidaPantalla.setVieneAgenda(true);
				rellenarListaAgenda(paginationData);				
			}					
		}	
	}
	
	public void rellenarListaAgenda(PaginationData paginationData){
		
		List<DocsContrapartida> listaDocsContrapa = 
			(List<DocsContrapartida>)docsContrapartidaBo.buscarDocsContrapartidaDesdeAgenda(parametrosOutAgenda.getCodevent().toString(), 
					parametrosOutAgenda.getFechatraIni(), parametrosOutAgenda.getFechatraFin(), 
					parametrosOutAgenda.getEstadoEv(), paginationData);
		docsContrapartidaPantalla.setDocsContrapartidaList(listaDocsContrapa);		
	}
	
	/** Prepara para entrar en el modo edición de un documento por contrapartida. */
	public void editar() {
		docsContrapartidaBo.recargar(docsContrapartidaPantalla.getDocContrapartida());
		beanToForm(docsContrapartidaPantalla.getDocContrapartida());		
		docsContrapartidaPantalla.setDocContrapartida(this.docsContrapartidaPantalla.getDocContrapartida());
//		comprobarContrato(docsContrapartidaPantalla.getDocContrapartida());
		this.setModoPantalla(ModoPantalla.EDICION);
	}

	public void comprobarContrato() {
		if ( docsContrapartidaPantalla.getDocContrapartida().getId()!=null && 
				docsContrapartidaPantalla.getDocContrapartida().getId().getTiposDocumento()!=null &&
				!"CMOF".equals(docsContrapartidaPantalla.getDocContrapartida().getId().getTiposDocumento().getId()) && 
				GenericUtils.isNullOrBlank(docsContrapartidaPantalla.getDocContrapartida().getId().getContrato()) ){
			docsContrapartidaPantalla.getDocContrapartida().getId().setContrato(docsContrapartidaPantalla.getDocContrapartida().getId().getTiposDocumento().getId());
		}
	}

	/** Prepara para entrar en el modo inspección de un documento por contrapartida. */
	public void ver() {
		
		docsContrapartidaBo.recargar(docsContrapartidaPantalla.getDocContrapartida());
		beanToForm(docsContrapartidaPantalla.getDocContrapartida());
		docsContrapartidaPantalla.setDocContrapartida(docsContrapartidaPantalla.getDocContrapartida());
		this.setModoPantalla(ModoPantalla.INSPECCION);
	}
	
	/** Método encargado de realizar las validaciones para el alta y edición de
	 * documentos por contrapartida. Comprueba que la contrapartida y el tipo documento a asociar
	 * existen, compara las fechas de cancelación y/o firma con la fecha de negociación y si es un alta
	 * comprueba que no exista ya un registro con el mismo id */
	public Boolean guardarValidator(){
		
		boolean esCorrecto = true;
		String idTipoDocu = docsContrapartidaPantalla.getDocContrapartida().getId().getTiposDocumento().getId();
		String idContrapa = docsContrapartidaPantalla.getDocContrapartida().getId().getContrapartida().getId();
		
		/** Se validan la contrapartida, el tipo documento y las fechas informadas por el usuario */
		if(!validaContrapaExiste(idContrapa) || !validaTipoDocuExiste(idTipoDocu) || !validaFechas()){
			esCorrecto = false;
		}
		
		if (ModoPantalla.CREACION.equals(this.modoPantalla)) {
			/** Comprobar que no existe ya un DocContrapartida con el mismo id */
			if (!GenericUtils.isNullOrBlank(this.docsContrapartidaBo
					.cargar(docsContrapartidaPantalla.getDocContrapartida()
							.getId()))) {
				esCorrecto = false;
				statusMessages.addToControl("idTipoDocu", Severity.ERROR,
						"#{messages['docsContrapartida.error.docuco.existe']}");
			}
		}
		
		if("CMOF".equalsIgnoreCase(idTipoDocu) && 
			!GenericUtils.isNullOrBlank(docsContrapartidaPantalla.getDocContrapartida().getfCancelacion())
			&& docsContrapartidaBo.existenOperacionesVivas(idContrapa)){
			//TODO DEFINIR EL MENSAJE DE ERROR CORRECTO
			esCorrecto = false;
			statusMessages.addToControl("idTipoDocu", Severity.ERROR,
					"#{messages['docsContrapartida.error.operacionesvivas']}");
		}
		
		if("CMOF".equalsIgnoreCase(idTipoDocu)){
			docsContrapartidaPantalla.getDocContrapartida().getId().setContrato(docsContrapartidaPantalla.getDocContrapartida().getId().getContrato().trim());
		}
				
		return esCorrecto;
	}

	/** Graba el documento por contrapartida en la base de datos. */
	public String guardar() {
		
		/** Guardamos los valores seleccionados en los checkboxes antes de persistir en bbdd */
		DocsContrapartida docsContrapaGuardar = this.formToBean(docsContrapartidaPantalla.getDocContrapartida());
		
		/** En función de las fechas, calcular el estado del documento */
		EstadoDocumentoContrapartida estadoCo = null;
		String idEstadoCo = Constantes.CADENA_VACIA;
		
		if(!GenericUtils.isNullOrBlank(docsContrapaGuardar.getfCancelacion())){
			/** Estado a C y desc_estado a Cancelado */
			idEstadoCo = Constantes.ESTADOCO_C;
		} else if (!GenericUtils.isNullOrBlank(docsContrapaGuardar.getfFirma())){
			/** Estado a F y desc_estado a Firmado */
			idEstadoCo = Constantes.ESTADOCO_F;
		} else if(!GenericUtils.isNullOrBlank(docsContrapaGuardar.getfNegociacion())){
			/** Estado a T y desc_estado a Trámite */
			idEstadoCo = Constantes.ESTADOCO_T;
		}

		estadoCo = docsContrapartidaBo.buscarEstadoDocsContrapartida(idEstadoCo);
		docsContrapaGuardar.setEstado(estadoCo);
		
		/** Si es un alta */
		if(this.getModoPantalla().equals(ModoPantalla.CREACION)){
			docsContrapartidaBo.asociarDocsContrapartida(docsContrapaGuardar);
		} else {
			docsContrapartidaBo.guardar(docsContrapaGuardar);
			docsContrapartidaBo.recargar(docsContrapartidaPantalla.getDocContrapartida());
		}
		
		refrescarLista();
		return Constantes.CONSTANTE_SUCCESS;
	}
	
	/** Validaciones de negocio para la baja de documentos por contrapartida
	 * Si el documento no es obligatorio o no existen operaciones de esa
	 * contrapartida se permite la baja */
	public Boolean borrarValidator(){
		
		boolean permitirBaja = false;
		
		/** Comprobamos si existen documentos asociados a la contrapartida que sean
		 * obligatorios y vigentes */
		
		String idTipoDocu = this.docsContrapartidaPantalla.getDocContrapartidaSelec().getId().getTiposDocumento().getId();
		String idContrapa = this.docsContrapartidaPantalla.getDocContrapartidaSelec().getId().getContrapartida().getId();
		
		if(!docsContrapartidaBo.isDocObligatorio(idTipoDocu, idContrapa)){
			/** Si no hay documentos, comprobamos si existe alguna operación vigente de
			 * esa contrapartida */
			List<Operacion> listaOperaciones = contrapartidaBo.buscarOperacionesVigentes(this.docsContrapartidaPantalla.getDocContrapartidaSelec().getId().getContrapartida());
			
			if(!GenericUtils.isNullOrBlank(listaOperaciones) && listaOperaciones.size() > 0){
				/** Si hay alguna operación */
				statusMessages.add(Severity.ERROR,"#{messages['docsContrapartida.error.baja.hayoperaciones']}");
			} else {
				/** Si no hay ninguna operación */
				permitirBaja = true;
				statusMessages.add(Severity.INFO,"#{messages['docsContrapartida.error.baja.nohayoperaciones']}");
			}
		} else { /** Hay otros documentos obligatorios. Se permite la baja */
			permitirBaja = true;
		}
		
		return permitirBaja;
	}
	
	/** Borra un documento por contrapartida. */
	public void borrar() {
		docsContrapartidaBo.borrar(docsContrapartidaPantalla.getDocContrapartidaSelec());
		refrescarLista();
	}
	
	/** Prepara para entrar en el modo creación de un documento por contrapartida. */
	public void nuevo() {
		docsContrapartidaPantalla.setDocContrapartida(new DocsContrapartida(new DocsContrapartidaId(new Contrapartida(), new TiposDocumento(), new DescripcionEntidadOperacion(), new String()),new TipoContrapartida(),null,null,null,new EstadoDocumentoContrapartida(),Constantes.CONSTANTE_NO,null,null,null,null,null,null,null,null,null,null,null,null,null));
		docsContrapartidaPantalla.setIndDelegacion(false);
		this.setModoPantalla(ModoPantalla.CREACION);
	}
	
	/** Prepara para cargar el grid de la pantalla según se acceda desde Mantenimiento de
	 * contrapartidas o desde la pantalla de Agenda */
	public void preCargarPantalla(String modo, String codevent, String estadoev, Date fechatraIni, Date fechatraFin){
		
		if (modo.equalsIgnoreCase(Constantes.MODO_MC)){ /** Viene desde mantenimiento de contrapartida */
				this.docsContrapartidaPantalla.setVieneMantContrapa(true);
				this.docsContrapartidaPantalla.setVieneAgenda(false);
				this.docsContrapartidaPantalla.getContrapaBusq().setId(contrapartidaSelection.getId());
				// Salvador venimos de Contrapa
				this.docsContrapartidaPantalla.getContrapaBusq().setDescCorta(contrapartidaBo.cargar(contrapartidaSelection.getId()).getDescCorta());				
				paginationData.reset(); /** Limpiamos la información de paginación */
				refrescarLista();
				setPrimerAcceso(false);
				//this.buscar();
		} /*else if (modo.equalsIgnoreCase(Constantes.MODO_AGE)) {
			this.docsContrapartidaPantalla.setVieneMantContrapa(false);
			this.docsContrapartidaPantalla.setVieneAgenda(true);
			paginationData.reset();
			refrescarListaAgenda(codevent, estadoev, fechatraIni, fechatraFin);
		}*/
	}

/*	private void refrescarListaAgenda(String codevent, String estadoev,
			Date fechatraIni, Date fechatraFin) {
		this.setExportExcel(false);
		List<DocsContrapartida> listaDocsContrapa = 
			(List<DocsContrapartida>)docsContrapartidaBo.buscarDocsContrapartidaDesdeAgenda(codevent, 
					fechatraIni, fechatraFin, estadoev, paginationData);
		docsContrapartidaPantalla.setDocsContrapartidaList(listaDocsContrapa);
	}
	
	private void refrescarListaAgendaExcel(String codevent, String estadoev,
			Date fechatraIni, Date fechatraFin) {
		this.setExportExcel(true);
		List<DocsContrapartida> listaDocsContrapa = 
			(List<DocsContrapartida>)docsContrapartidaBo.buscarDocsContrapartidaDesdeAgenda(codevent, 
					fechatraIni, fechatraFin, estadoev, paginationData.getPaginationDataForExcel());
		docsContrapartidaPantalla.setDocsContrapartidaList(listaDocsContrapa);
	}*/
	
	/**
	 * Recoge los valores (boolean) de los checkboxes de pantalla (Requerido, IndicadorAnexo y FirmaAnexo)
	 * y el campo de texto "obligatorio", y los transforma a los valores a persistir en bbdd (S, N) para la 
	 * entity DocsContrapartida.
	 * @param docsContrapartida Entity a persistir en bbdd (ya sea en alta o en edición)
	 * @return DocsContrapartida con los valores de Requerido, IndicadorAnexo y FirmaAnexo adaptados,
	 */
	private DocsContrapartida formToBean(DocsContrapartida docsContrapartida){
		
		DocsContrapartida docsContrapaModif = docsContrapartida;
		
		/** Requerido */
		if (docsContrapartidaPantalla.getEsRequerido()){
			docsContrapaModif.setDocRequerido(Constantes.CONSTANTE_SI);
		} else {
			docsContrapaModif.setDocRequerido(Constantes.CONSTANTE_NO);
		}
		
		/** Firma Anexo */
		if (docsContrapartidaPantalla.getFirmaAnexo()){
			docsContrapaModif.setFirmaAnexo(Constantes.CONSTANTE_SI);
		} else {
			docsContrapaModif.setFirmaAnexo(Constantes.CONSTANTE_NO);
		}
		
		/** Indicador Anexo */
		if (docsContrapartidaPantalla.getIndicadorAnexo()){
			docsContrapaModif.setIndicadorAnexo(Constantes.CONSTANTE_SI);
		} else {
			docsContrapaModif.setIndicadorAnexo(Constantes.CONSTANTE_NO);
		}
		
		/** Obligatorio */
		if (!GenericUtils.isNullOrBlank(docsContrapartidaPantalla.getObligatorio()) && docsContrapartidaPantalla.getObligatorio().equalsIgnoreCase(ResourceBundle.instance().getString("docsContrapartida.obligatorio.si"))){
			docsContrapaModif.getId().getTiposDocumento().setObligatorio(Constantes.CONSTANTE_SI);
		} else {
			docsContrapaModif.getId().getTiposDocumento().setObligatorio(Constantes.CONSTANTE_NO);
		}
		
		/** Indicador Delegacion */
		if (docsContrapartidaPantalla.getIndDelegacion()){
			docsContrapaModif.setIndDelegacion(Constantes.CONSTANTE_SI);
		} else {
			docsContrapaModif.setIndDelegacion(Constantes.CONSTANTE_NO);
		}

		/** Indicador firma documento delegación emir */
		if(docsContrapartidaPantalla.getIndDelegacionFirmado()){
			docsContrapaModif.setIndDelegacionFirmado(Constantes.CONSTANTE_SI);
		}else{
			docsContrapaModif.setIndDelegacionFirmado(Constantes.CONSTANTE_NO);
		}
			
		/** Indicador firma documento apoderados */
		if (docsContrapartidaPantalla.getIndApoderadosFirmado()){
			docsContrapaModif.setIndApoderadosFirmado(Constantes.CONSTANTE_SI);
		} else {
			docsContrapaModif.setIndApoderadosFirmado(Constantes.CONSTANTE_NO);
		}

		
		return docsContrapaModif;
	}
	
	/**
	 * Recoge los valores de Requerido, IndicadorAnexo, FirmaAnexo y Obligatorio del entity
	 * DocsContrapartida y los transforma a los valores a mostrar en pantalla
	 * (Si, No, checked, unchecked...)
	 * 
	 * @param docsContrapartida Entity de bbdd de la que se extrae la información.
	 */
	private void beanToForm(DocsContrapartida docsContrapartida){

		if (!GenericUtils.isNullOrBlank(docsContrapartida)){
			
			/** Requerido */
			if (!GenericUtils.isNullOrBlank(docsContrapartida.getDocRequerido()) && docsContrapartida.getDocRequerido().equalsIgnoreCase(Constantes.CONSTANTE_SI)){
				docsContrapartidaPantalla.setEsRequerido(true);
			} else {
				docsContrapartidaPantalla.setEsRequerido(false);
			}
		
			/** Firma Anexo */
			if (!GenericUtils.isNullOrBlank(docsContrapartida.getFirmaAnexo()) && docsContrapartida.getFirmaAnexo().equalsIgnoreCase(Constantes.CONSTANTE_SI)){
				docsContrapartidaPantalla.setFirmaAnexo(true);
			} else {
				docsContrapartidaPantalla.setFirmaAnexo(false);
			}
			
			/** Indicador Anexo */
			if (!GenericUtils.isNullOrBlank(docsContrapartida.getIndicadorAnexo()) && docsContrapartida.getIndicadorAnexo().equalsIgnoreCase(Constantes.CONSTANTE_SI)){
				docsContrapartidaPantalla.setIndicadorAnexo(true);
			} else {
				docsContrapartidaPantalla.setIndicadorAnexo(false);
			}
		
			/** Obligatorio */
			if (!GenericUtils.isNullOrBlank(docsContrapartida.getId().getTiposDocumento().getObligatorio()) && docsContrapartida.getId().getTiposDocumento().getObligatorio().equalsIgnoreCase(Constantes.CONSTANTE_SI)){
				docsContrapartidaPantalla.setObligatorio(ResourceBundle.instance().getString("docsContrapartida.obligatorio.si"));
			} else {
				docsContrapartidaPantalla.setObligatorio(ResourceBundle.instance().getString("docsContrapartida.obligatorio.no"));
			}
		
		
			/** Indicador Delegacion*/
			if (!GenericUtils.isNullOrBlank(docsContrapartida.getIndDelegacion()) && docsContrapartida.getIndDelegacion().equalsIgnoreCase(Constantes.CONSTANTE_SI)){
				docsContrapartidaPantalla.setIndDelegacion(true);
			} else {
				docsContrapartidaPantalla.setIndDelegacion(false);
			}
			
			/** Indicador firma documento delegación emir */
			if (!GenericUtils.isNullOrBlank(docsContrapartida.getIndDelegacionFirmado()) && docsContrapartida.getIndDelegacionFirmado().equalsIgnoreCase(Constantes.CONSTANTE_SI)){
				docsContrapartidaPantalla.setIndDelegacionFirmado(true);
			} else {
				docsContrapartidaPantalla.setIndDelegacionFirmado(false);
			}
			/** Indicador firma documento apoderados */
			if (!GenericUtils.isNullOrBlank(docsContrapartida.getIndApoderadosFirmado()) && docsContrapartida.getIndApoderadosFirmado().equalsIgnoreCase(Constantes.CONSTANTE_SI)){
				docsContrapartidaPantalla.setIndApoderadosFirmado(true);
			} else {
				docsContrapartidaPantalla.setIndApoderadosFirmado(false);
			}
		
		}
	}
	
	/**
	 * Busca el código de Contrapartida informada. Si no existe, vuelve a buscarla pero con un codigo que empiece
	 * por el nombre introducido. Si encuentra una y sólo una, la informa.
	 * Si no la encuentra, o encuentra más de una, se busca el codigo introducido como descripción
	 * exacta de alguna contrapartida. Si encuentra una y sólo una, la informa.
	 * Si no, muestra mensaje de advertencia al usuario.
	 * @param idContrapa Id de la contrapartida, valor informado por el usuario.
	 * @return true si encuentra una y solo una contrapartida, false en caso contrario
	 */
	private boolean validaContrapaExiste(String idContrapa) {
		
		boolean existeContrapa = true;
		List<Contrapartida> contrapaEncontradas = null;
		
		if(GenericUtils.isNullOrBlank(this.contrapartidaBo.cargar(idContrapa))){
			contrapaEncontradas = this.contrapartidaBo.buscarContrapartidas(null, null, idContrapa.concat(Constantes.CONSTANTE_PERCENT), null, paginationData);
			if(GenericUtils.isNullOrBlank(contrapaEncontradas) || contrapaEncontradas.isEmpty() || 
					contrapaEncontradas.size() > 1){
				contrapaEncontradas = this.contrapartidaBo.buscarContrapartidas(null, idContrapa, null, null, paginationData);
				if(GenericUtils.isNullOrBlank(contrapaEncontradas) || contrapaEncontradas.isEmpty()){
					// Si no la encuentra, emite el mensaje: 'Contrapartida no Definida'
					existeContrapa = false;
					statusMessages.addToControl("idContrapa", Severity.ERROR, "#{messages['docsContrapartida.error.contrapartida.noexiste']}");
				} else if (contrapaEncontradas.size() > 1){
					// Si encuentra más de una, emite: 'Descripción Insuficiente para Decidir el Dato'
					existeContrapa = false;
					statusMessages.addToControl("idContrapa", Severity.ERROR, "#{messages['docsContrapartida.error.nodefinido']}");
				} else { 
					docsContrapartidaPantalla.getDocContrapartida().getId().setContrapartida(contrapaEncontradas.get(0));
				}
			} else {
				docsContrapartidaPantalla.getDocContrapartida().getId().setContrapartida(contrapaEncontradas.get(0));
			}
		}
		return existeContrapa;
	}
	
	/**
	 * Busca el código de Contrapartida informada. Si no existe, vuelve a buscarla pero con un codigo que empiece
	 * por el nombre introducido. Si encuentra una y sólo una, la informa.
	 * Si no la encuentra, o encuentra más de una, se busca el codigo introducido como descripción
	 * exacta de alguna contrapartida. Si encuentra una y sólo una, la informa.
	 * Si no, muestra mensaje de advertencia al usuario.
	 * @param idTipoDocu Id de la contrapartida, valor informado por el usuario.
	 * @return true si encuentra una y solo una contrapartida, false en caso contrario
	 */
	private boolean validaTipoDocuExiste(String idTipoDocu) {
		
		boolean existeTipoDocu = true;
		List<TiposDocumento> tipoDocuEncontrados = null;
		
		if(GenericUtils.isNullOrBlank(this.mantTiposDocumentoBo.cargar(idTipoDocu))){
			tipoDocuEncontrados = this.mantTiposDocumentoBo.buscar(idTipoDocu.concat(Constantes.CONSTANTE_PERCENT), null, null, null, paginationData);
			if(GenericUtils.isNullOrBlank(tipoDocuEncontrados) || tipoDocuEncontrados.isEmpty() || 
					tipoDocuEncontrados.size() > 1){
				tipoDocuEncontrados = this.mantTiposDocumentoBo.buscar(null, idTipoDocu, null, null, paginationData);
				if(GenericUtils.isNullOrBlank(tipoDocuEncontrados) || tipoDocuEncontrados.isEmpty()){
					// Si no encuentra, emite el mensaje: 'Tipo documento no Definido'
					existeTipoDocu = false;
					statusMessages.addToControl("idTipoDocu", Severity.ERROR, "#{messages['docsContrapartida.error.tipodocumento.noexiste']}");
				} else if (tipoDocuEncontrados.size() > 1){
					// Si encuentra más de uno, emite: 'Descripción Insuficiente para Decidir el Dato'
					existeTipoDocu = false;
					statusMessages.addToControl("idTipoDocu", Severity.ERROR, "#{messages['docsContrapartida.error.nodefinido']}");
				} else { 
					docsContrapartidaPantalla.getDocContrapartida().getId().setTiposDocumento(tipoDocuEncontrados.get(0));
				}
			} else {
				docsContrapartidaPantalla.getDocContrapartida().getId().setTiposDocumento(tipoDocuEncontrados.get(0));
			}
		}
		return existeTipoDocu;
	}
	
	/**
	 * Método que comprueba la validez de las fechas informadas por el usuario
	 * en la pantalla de documentos por contrapartida
	 * Fecha cancelación debe ser igual o posterior a fecha negociación.
	 * Fecha firma debe ser posterior a fecha negociación
	 * @return true si las fechas son válidas, false en caso contrario
	 */
	private boolean validaFechas() {
		
		boolean fechasCorrectas = true;
		if(!GenericUtils.isNullOrBlank(docsContrapartidaPantalla.getDocContrapartida().getfFirma())){
			
			long diffFechaFirmaNeg = (docsContrapartidaPantalla.getDocContrapartida().getfFirma().getTime() - 
					docsContrapartidaPantalla.getDocContrapartida().getfNegociacion().getTime())/86400000L;
			
			if (diffFechaFirmaNeg < 0l){
				fechasCorrectas = false;
				statusMessages.addToControl("ffirma", Severity.ERROR, "#{messages['docsContrapartida.error.ffirma']}");
			}
		}
		
		if(!GenericUtils.isNullOrBlank(docsContrapartidaPantalla.getDocContrapartida().getfCancelacion())){
			
			long diffFechaCancelNeg = (docsContrapartidaPantalla.getDocContrapartida().getfCancelacion().getTime() - 
					docsContrapartidaPantalla.getDocContrapartida().getfNegociacion().getTime())/86400000L;
		
			if (diffFechaCancelNeg <= 0l){
				fechasCorrectas = false;
				statusMessages.addToControl("fcancel", Severity.ERROR, "#{messages['docsContrapartida.error.fcancelacion']}");
			}
		}
		
		//validación documentación EMIR firmada. Si check marcado fecha obligatoria. Si no marcado -->sin fecha
		if(docsContrapartidaPantalla.getIndDelegacionFirmado()){
			if(GenericUtils.isNullOrBlank(docsContrapartidaPantalla.getDocContrapartida().getFechaFirmaDelegacion())){
				fechasCorrectas = false;
				statusMessages.addToControl("fechaFirma", Severity.ERROR, "#{messages['docsContrapartida.error.ffirma.informado']}");
			}
		}else if(!GenericUtils.isNullOrBlank(docsContrapartidaPantalla.getDocContrapartida().getFechaFirmaDelegacion())){
			fechasCorrectas = false;
			statusMessages.addToControl("fechaFirma", Severity.ERROR, "#{messages['docsContrapartida.error.ffirma.noinformado']}");
		}
		
		//validación doc apoderados firmado. Si check marcado fecha obligatoria. Si no marcado -->sin fecha
		if(docsContrapartidaPantalla.getIndApoderadosFirmado()){
			if(GenericUtils.isNullOrBlank(docsContrapartidaPantalla.getDocContrapartida().getFechaFirmaApoderados())){
				fechasCorrectas = false;
				statusMessages.addToControl("fechaFirmaApod", Severity.ERROR, "#{messages['docsContrapartida.error.fechaFirmaApod.informado']}");
			}
		}else if(!GenericUtils.isNullOrBlank(docsContrapartidaPantalla.getDocContrapartida().getFechaFirmaApoderados())){
			fechasCorrectas = false;
			statusMessages.addToControl("fechaFirmaApod", Severity.ERROR, "#{messages['docsContrapartida.error.fechaFirmaApod.noinformado']}");
		}
		
		
		return fechasCorrectas;
	}
	
	public void recargarContrapartida(){
		 
		if (!GenericUtils.isNullOrBlank(docsContrapartidaPantalla.getContrapaBusq())){
			String idContrapa =docsContrapartidaPantalla.getContrapaBusq().getId();
			if (!GenericUtils.isNullOrBlank(idContrapa)){
				Contrapartida contrapa = contrapartidaBo.cargar(idContrapa);
				if (!GenericUtils.isNullOrBlank(contrapa)){
					docsContrapartidaPantalla.getContrapaBusq().setDescCorta(contrapa.getDescCorta());
				}
			}
		}
	}
	
	
	public void recargarTipoDocu(){
		 
		if (!GenericUtils.isNullOrBlank(docsContrapartidaPantalla.getTipoDocBusq())){
			String id = docsContrapartidaPantalla.getTipoDocBusq().getId();
			if (!GenericUtils.isNullOrBlank(id)){
				TiposDocumento tipoDocu = mantTiposDocumentoBo.cargar(id);
				if (!GenericUtils.isNullOrBlank(tipoDocu)){
					docsContrapartidaPantalla.getTipoDocBusq().setDescripcion(tipoDocu.getDescripcion());
				}
			}
		}
		
	}
	
	
	@Override
	public List<?> getDataTableList() {
		return docsContrapartidaPantalla.getDocsContrapartidaList();
	}
	
	@SuppressWarnings("unchecked")
	@Override
	public void setDataTableList(List<?> dataTableList) {
		docsContrapartidaPantalla.setDocsContrapartidaList((List<DocsContrapartida>)dataTableList);
	}

	public String getModo() {
		return modo;
	}

	public void setModo(String modo) {
		this.modo = modo;
	}

	@Factory("LlistaEntidadOperacion")
	public List<DescripcionEntidadOperacion> listaDescripcionEntidadOperacions() {
		return docsContrapartidaBo.getDescripcionEntidadOperacion(this.getModoPantalla());
	}
	
	public void init(){
		primeraEjecucionInit = null;
		
		if (messageBoxDocsContrapartidaAction==null){
			messageBoxDocsContrapartidaAction = new MessageBoxAction();
		}
	}

	public void initDetalle(){
		
		if (primeraEjecucionInit == null) {
			primeraEjecucionInit=true;
		} 
		else{
			primeraEjecucionInit = false;
		}
		
		if (messageBoxDocsContrapartidaAction==null){
			messageBoxDocsContrapartidaAction = new MessageBoxAction();
		}
		
		if(primeraEjecucionInit){// && (this.modoPantalla.equals(ModoPantalla.EDICION) || this.modoPantalla.equals(ModoPantalla.CREACION))){
			if(null!=docsContrapartidaPantalla.getDocContrapartidaSelec() && null!=docsContrapartidaPantalla.getDocContrapartidaSelec().getId() && docsContrapartidaPantalla.getDocContrapartidaSelec().getId().getContrapartida() instanceof Contrapartida){
				Contrapartida contrapartida = (Contrapartida) docsContrapartidaPantalla.getDocContrapartidaSelec().getId().getContrapartida();
				if (null!=contrapartida && !GenericUtils.isNullOrBlank(contrapartida.getIndBloqueo()) && "S".equalsIgnoreCase(contrapartida.getIndBloqueo())){
					mostrarPopUpContrapartidaBloqueada();
				}
			}
		}
		
	}
	
	public void voidFunction(){
		msgBoxAction.voidFunction();
	}

	/**
	 * Mostrar PopUp cuando una contrapartida está bloqueada (no bloqueante)
	 */
	public void onVerificarContrapartidaBloqueada() {
		String contrapartida = docsContrapartidaPantalla.getContrapaBusq().getId();
		if (!GenericUtils.isNullOrBlank(contrapartida)){
			 Contrapartida contrapObtenida2 = docsContrapartidaBo.cargarContrapartida(contrapartida.toUpperCase());	
			if (null!=contrapObtenida2 && !GenericUtils.isNullOrBlank(contrapObtenida2.getIndBloqueo()) && "S".equalsIgnoreCase(contrapObtenida2.getIndBloqueo())){
				mostrarPopUpContrapartidaBloqueada();
			}
		}
		
		recargarContrapartida();
    }
	
	public void onVerificarContrapartidaBloqueadaDetalle() {
		if (null!=docsContrapartidaPantalla.getDocContrapartida() && null!=docsContrapartidaPantalla.getDocContrapartida().getId() && null!=docsContrapartidaPantalla.getDocContrapartida().getId().getContrapartida()){
			 Contrapartida contrapObtenida2 = docsContrapartidaBo.cargarContrapartida(docsContrapartidaPantalla.getDocContrapartida().getId().getContrapartida().getId().toUpperCase());	
			if (null!=contrapObtenida2 && !GenericUtils.isNullOrBlank(contrapObtenida2.getIndBloqueo()) && "S".equalsIgnoreCase(contrapObtenida2.getIndBloqueo())){
				mostrarPopUpContrapartidaBloqueada();
			}
		}
    }
	
	private void mostrarPopUpContrapartidaBloqueada(){
		messageBoxDocsContrapartidaAction.init("docsContrapartida.messages.contrapartida.bloqueada.texto", "docsContrapartidaAction.voidFunction()", null,"messageBoxPanelContrapa");
	}
	
	public String getRowClasses(){
		StringBuilder builder = new StringBuilder();
		int i=0;
		for (DocsContrapartida docsContra : docsContrapartidaPantalla.getDocsContrapartidaList()) {
			Contrapartida contrapartida = (Contrapartida) docsContra.getId().getContrapartida();

			if(i>0){
				builder.append(",");
			}
			
			if(i%2==0){
				if(null!=contrapartida && !GenericUtils.isNullOrBlank(contrapartida.getIndBloqueo()) && "S".equalsIgnoreCase(contrapartida.getIndBloqueo())){
					builder.append("oddRowRed");
				}
				else{
					builder.append("oddRow");
				}
			}
			else{
				if(null!=contrapartida && !GenericUtils.isNullOrBlank(contrapartida.getIndBloqueo()) && "S".equalsIgnoreCase(contrapartida.getIndBloqueo())){
					builder.append("evenRowRed");
				}
				else{
					builder.append("evenRow");
				}
			}
			i++;
			contrapartida = null;
		}
		return builder.toString();
	}
}
