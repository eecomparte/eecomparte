package com.atosorigin.deri.contrapartida.docsporcontrapartida.screen;

import java.util.List;

import org.jboss.seam.ScopeType;
import org.jboss.seam.annotations.Name;
import org.jboss.seam.annotations.Out;
import org.jboss.seam.annotations.Scope;
import org.jboss.seam.annotations.datamodel.DataModel;
import org.jboss.seam.annotations.datamodel.DataModelSelection;

import com.atosorigin.deri.model.contrapartida.Contrapartida;
import com.atosorigin.deri.model.contrapartida.DocsContrapartida;
import com.atosorigin.deri.model.contrapartida.EstadoDocumentoContrapartida;
import com.atosorigin.deri.model.contrapartida.TiposDocumento;

/**
 * Contiene los datos de pantalla necesarios para el caso de uso documentos por contrapartida.
 */
@Name("docsContrapartidaPantalla")
@Scope(ScopeType.CONVERSATION)
public class DocsContrapartidaPantalla {
	
	public static final String OBLIGATORIO_SI = "#{messages['docsContrapartida.obligatorio.si']}";
	public static final String OBLIGATORIO_NO = "#{messages['docsContrapartida.obligatorio.no']}";
	
	/** Lista de datos para el grid. */
	@DataModel(value ="listaDtDocsContrapartida")
	protected List<DocsContrapartida>docsContrapartidaList;
	
	/** DocsContrapartida seleccionado en el grid */
	@DataModelSelection(value ="listaDtDocsContrapartida")
	@Out(value="docContrapartidaSelec", required=false)
    protected DocsContrapartida docContrapartidaSelec;

    @Out(value="docContrapartida", required=false)
	protected DocsContrapartida docContrapartida;
    
    /** Criterios de búsqueda */
    protected Contrapartida contrapaBusq;
	protected TiposDocumento tipoDocBusq;
	protected EstadoDocumentoContrapartida estadoBusq;
    
	/** Checkboxes detalle */
	protected Boolean esRequerido;
	protected Boolean indicadorAnexo;
	protected Boolean firmaAnexo;
	protected Boolean indDelegacion;
	
	/**	campos CMOF */
	private Boolean indDelegacionFirmado;
	private Boolean indApoderadosFirmado;
	
	
	/** Campo "obligatorio" S=Si, N=No */
	protected String obligatorio;
	
	/** Campos booleanos para ver desde que pantalla se llega */
	protected boolean vieneMantContrapa;
	protected boolean vieneAgenda;
	
	
	
	public DocsContrapartidaPantalla() {
		this.contrapaBusq = new Contrapartida();
		this.tipoDocBusq = new TiposDocumento();
		this.vieneAgenda = false;
		this.vieneMantContrapa = false;
		this.indApoderadosFirmado=false;
		this.indDelegacionFirmado=false;
		this.indicadorAnexo=false;
		this.indDelegacion=false;
	}
	
	public List<DocsContrapartida> getDocsContrapartidaList() {
		return docsContrapartidaList;
	}

	public void setDocsContrapartidaList(
			List<DocsContrapartida> docsContrapartidaList) {
		this.docsContrapartidaList = docsContrapartidaList;
	}

	public DocsContrapartida getDocContrapartidaSelec() {
		return docContrapartidaSelec;
	}

	public void setDocContrapartidaSelec(DocsContrapartida docContrapartidaSelec) {
		this.docContrapartidaSelec = docContrapartidaSelec;
	}

	public DocsContrapartida getDocContrapartida() {
		return docContrapartida;
	}

	public void setDocContrapartida(DocsContrapartida docContrapartida) {
		this.docContrapartida = docContrapartida;
	}

	public Contrapartida getContrapaBusq() {
		return contrapaBusq;
	}

	public void setContrapaBusq(Contrapartida contrapaBusq) {
		this.contrapaBusq = contrapaBusq;
	}

	public TiposDocumento getTipoDocBusq() {
		return tipoDocBusq;
	}

	public void setTipoDocBusq(TiposDocumento tipoDocBusq) {
		this.tipoDocBusq = tipoDocBusq;
	}

	public EstadoDocumentoContrapartida getEstadoBusq() {
		return estadoBusq;
	}

	public void setEstadoBusq(EstadoDocumentoContrapartida estadoBusq) {
		this.estadoBusq = estadoBusq;
	}

	public Boolean getEsRequerido() {
		return esRequerido;
	}

	public Boolean getIndicadorAnexo() {
		return indicadorAnexo;
	}

	public Boolean getFirmaAnexo() {
		return firmaAnexo;
	}

	public void setEsRequerido(Boolean esRequerido) {
		this.esRequerido = esRequerido;
	}

	public void setIndicadorAnexo(Boolean indicadorAnexo) {
		this.indicadorAnexo = indicadorAnexo;
	}

	public void setFirmaAnexo(Boolean firmaAnexo) {
		this.firmaAnexo = firmaAnexo;
	}

	public String getObligatorio() {
		return obligatorio;
	}

	public void setObligatorio(String obligatorio) {
		this.obligatorio = obligatorio;
	}

	public boolean isVieneMantContrapa() {
		return vieneMantContrapa;
	}

	public boolean isVieneAgenda() {
		return vieneAgenda;
	}

	public void setVieneMantContrapa(boolean vieneMantContrapa) {
		this.vieneMantContrapa = vieneMantContrapa;
	}

	public void setVieneAgenda(boolean vieneAgenda) {
		this.vieneAgenda = vieneAgenda;
	}

	public Boolean getIndDelegacion() {
		return indDelegacion;
	}

	public void setIndDelegacion(Boolean indDelegacion) {
		this.indDelegacion = indDelegacion;
	}

	public Boolean getIndDelegacionFirmado() {
		return indDelegacionFirmado;
	}

	public void setIndDelegacionFirmado(Boolean indDelegacionFirmado) {
		this.indDelegacionFirmado = indDelegacionFirmado;
	}

	public Boolean getIndApoderadosFirmado() {
		return indApoderadosFirmado;
	}

	public void setIndApoderadosFirmado(Boolean indApoderadosFirmado) {
		this.indApoderadosFirmado = indApoderadosFirmado;
	}

}
