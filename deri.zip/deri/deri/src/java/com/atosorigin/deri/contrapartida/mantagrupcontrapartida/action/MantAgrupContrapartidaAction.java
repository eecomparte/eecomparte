package com.atosorigin.deri.contrapartida.mantagrupcontrapartida.action;

import java.util.List;

import org.jboss.seam.ScopeType;
import org.jboss.seam.annotations.In;
import org.jboss.seam.annotations.Name;
import org.jboss.seam.annotations.Scope;
import org.jboss.seam.international.StatusMessage.Severity;

import com.atosorigin.common.action.ModoPantalla;
import com.atosorigin.common.action.PaginatedListAction;
import com.atosorigin.common.constantes.Constantes;
import com.atosorigin.common.formvalidator.FormValidator;
import com.atosorigin.deri.contrapartida.mantagrupcontrapartida.business.MantAgrupContrapartidaBo;
import com.atosorigin.deri.contrapartida.mantagrupcontrapartida.screen.MantAgrupContrapartidaPantalla;
import com.atosorigin.deri.model.contrapartida.AgrupContrapartida;

/**
 * Clase que actúa de action listener para el caso de uso de mantenimiento de grupos de contrapartidas.
 */
@Name("mantAgrupContrapartidaAction")
@Scope(ScopeType.CONVERSATION)
@FormValidator
public class MantAgrupContrapartidaAction extends PaginatedListAction{

	/**
	 * Inyección del bean de Spring "mantAgrupContrapartidaBo" que contiene los métodos de negocio
	 * para el caso de uso mantenimiento de tipos de contrapartidas.
	 */
	@In("#{mantAgrupContrapartidaBo}")
	protected MantAgrupContrapartidaBo mantAgrupContrapartidaBo;


	/**
	 * Inyección del screen bean que contiene los datos de pantalla del caso de uso
	 * mantenimiento de tipos de contrapartidas.
	 */
	@In(create=true)
	protected MantAgrupContrapartidaPantalla mantAgrupContrapartidaPantalla;

	/**
	 * Actualiza la lista del grid de grupos de contrapartidas.
	 * 
	 */
	public void buscar() {
		paginationData.reset();
		refrescarLista();
		setPrimerAcceso(false);
		if (mantAgrupContrapartidaPantalla.getAgrupContrapartidaList()==null || 
				mantAgrupContrapartidaPantalla.getAgrupContrapartidaList().isEmpty()){
			statusMessages.add("#{messages['mantagrupcontrapartida.error.descripcionErronea']");
		}
	}

	/**
	 * Prepara para entrar en el modo edición de un grupo de contrapartida.
	 * 
	 */
	public void editar() {
		mantAgrupContrapartidaPantalla.setAgrupContrapartida(mantAgrupContrapartidaBo.cargar(mantAgrupContrapartidaPantalla.getAgrupContrapartida().getId()));
		setModoPantalla(ModoPantalla.EDICION);
	}

	/**
	 * Prepara para entrar en el modo inspección de un grupo de contrapartida.
	 * 
	 */
	public void ver() {
		mantAgrupContrapartidaPantalla.setAgrupContrapartida(mantAgrupContrapartidaBo.cargar(mantAgrupContrapartidaPantalla.getAgrupContrapartida().getId()));
		setModoPantalla(ModoPantalla.INSPECCION);
	}

	/**
	 * Prepara para entrar en el modo creación de un grupo de contrapartida.
	 * 
	 */
	public void nuevo() {
		mantAgrupContrapartidaPantalla.setAgrupContrapartida(new AgrupContrapartida());
		setModoPantalla(ModoPantalla.CREACION);
	}

	
	/**
	 * Valida el borrado un grupo de contrapartida.
	 * 
	 */
	public boolean borrarValidator() {
		AgrupContrapartida agrupContrapartidaExistente = mantAgrupContrapartidaBo.cargar(mantAgrupContrapartidaPantalla.getAgrupContrapartida().getId());
		if (agrupContrapartidaExistente !=null && !agrupContrapartidaExistente.getContrapartidas().isEmpty()){
			statusMessages.add("#{messages['mantagrupcontrapartida.error.agrupacionAsociada']}");
			return false;
		}
		return true;
	}
	
	/**
	 * Borra un tipo de contrapartida.
	 * 
	 */
	public void borrar() {
		mantAgrupContrapartidaBo.borrar(mantAgrupContrapartidaPantalla.getAgrupContrapartida());		
		refrescarLista();
	}


	/**
	 * Método de validación de formulario previo a la acción guardar.
	 * El interceptor seam FormValidator lo ejecutará antes del método "guardar".
	 * Verifica la existencia de un grupo con el mismo Código
	 * @return true si no hay errores de validación, false en caso contrario.
	 */
	public boolean guardarValidator() {
		if (modoPantalla.equals(ModoPantalla.CREACION)){
			AgrupContrapartida agrupContrapartidaExistente = mantAgrupContrapartidaBo.cargar(mantAgrupContrapartidaPantalla.getAgrupContrapartida().getId());
			if (agrupContrapartidaExistente !=null){
				statusMessages.addToControl("id", Severity.ERROR, "mantagrupcontrapartida.error.agrupacionDuplicada", Constantes.DEFAULT_MESSAGE_TEMPLATE);
				return false;
			}
		}
		return true;
	}
	
	/**
	 * Graba el tipo de contrapartida en la base de datos.
	 * 
	 */
	public String guardar() {
		mantAgrupContrapartidaBo.guardar(mantAgrupContrapartidaPantalla.getAgrupContrapartida());
		refrescarLista();
		return "success";
	}	
		
	//Métodos necesarios para pantallas con grids.
	//Es necesario implementar estos métodos abstractos de PaginatedListAction
	@Override
	public List<AgrupContrapartida> getDataTableList() {
		return mantAgrupContrapartidaPantalla.getAgrupContrapartidaList();
	}

	@Override
	@SuppressWarnings("unchecked")
	public void setDataTableList(List<?> dataTableList) {
		mantAgrupContrapartidaPantalla.setAgrupContrapartidaList((List<AgrupContrapartida>)dataTableList);		
	}

	@Override
	protected void refreshListInternal() {
		setExportExcel(false);
		List<AgrupContrapartida> agrupContrapartidaList = (List<AgrupContrapartida>)mantAgrupContrapartidaBo.buscarAgrupContrapartidas(mantAgrupContrapartidaPantalla.getDescripcion(), paginationData);
		mantAgrupContrapartidaPantalla.setAgrupContrapartidaList(agrupContrapartidaList);
	}

	@Override
	public void refrescarListaExcel() {
		setExportExcel(true);
		List<AgrupContrapartida> agrupContrapartidaList = (List<AgrupContrapartida>)mantAgrupContrapartidaBo.buscarAgrupContrapartidas(mantAgrupContrapartidaPantalla.getDescripcion(), paginationData.getPaginationDataForExcel());		
		mantAgrupContrapartidaPantalla.setAgrupContrapartidaList(agrupContrapartidaList);
	}
	
}
