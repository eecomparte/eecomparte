package com.atosorigin.deri.contrapartida.mantagrupcontrapartida.screen;

import java.util.List;

import org.jboss.seam.ScopeType;
import org.jboss.seam.annotations.Name;
import org.jboss.seam.annotations.Out;
import org.jboss.seam.annotations.Scope;
import org.jboss.seam.annotations.datamodel.DataModel;
import org.jboss.seam.annotations.datamodel.DataModelSelection;

import com.atosorigin.deri.model.contrapartida.AgrupContrapartida;


/**
 *  Contiene los datos de pantalla necesarios para el caso de uso mantenimiento de agrupación de contrapartidas.
 */
@Name("mantAgrupContrapartidaPantalla")
@Scope(ScopeType.CONVERSATION)
public class MantAgrupContrapartidaPantalla {

	/** Descripcion. Criterio de búsqueda de agrupación de contrapartidas  */
	protected String descripcion;

	/** Lista de datos para el grid. */
	@DataModel(value ="listaDtAgrupContrapartida")
	protected List<AgrupContrapartida> agrupContrapartidaList;
	
	/** Tipo de contrapartida seleccionado en el grid */
	@DataModelSelection(value ="listaDtAgrupContrapartida")
    @Out(required=false)
    protected AgrupContrapartida agrupContrapartida;

	
	/** Número de resultados totales para los criterios de búsqueda. */
	protected Long numFilas = 0L;
	
	public String getDescripcion() {
		return descripcion;
	}

	public void setDescripcion(String descripcion) {
		this.descripcion = descripcion;
	}

	public List<AgrupContrapartida> getAgrupContrapartidaList() {
		return agrupContrapartidaList;
	}

	public AgrupContrapartida getAgrupContrapartida() {
		return agrupContrapartida;
	}

	public void setAgrupContrapartidaList(
			List<AgrupContrapartida> agrupContrapartidaList) {
		this.agrupContrapartidaList = agrupContrapartidaList;
	}

	public void setAgrupContrapartida(AgrupContrapartida agrupContrapartida) {
		this.agrupContrapartida = agrupContrapartida;
	}
	
	public Long getNumFilas() {
		return numFilas;
	}

	public void setNumFilas(Long numFilas) {
		this.numFilas = numFilas;
	}


}
