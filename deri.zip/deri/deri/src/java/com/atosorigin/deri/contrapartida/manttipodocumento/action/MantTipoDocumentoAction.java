package com.atosorigin.deri.contrapartida.manttipodocumento.action;

import java.util.Date;
import java.util.List;

import org.jboss.seam.ScopeType;
import org.jboss.seam.annotations.In;
import org.jboss.seam.annotations.Name;
import org.jboss.seam.annotations.Out;
import org.jboss.seam.annotations.Scope;
import org.jboss.seam.international.StatusMessage.Severity;

import com.atosorigin.common.action.ModoPantalla;
import com.atosorigin.common.action.PaginatedListAction;
import com.atosorigin.common.action.PaginationData;
import com.atosorigin.common.constantes.Constantes;
import com.atosorigin.common.excelexporter.CustomExcelExporter;
import com.atosorigin.common.formvalidator.FormValidator;
import com.atosorigin.common.utils.GenericUtils;
import com.atosorigin.deri.contrapartida.manttipodocumento.screen.MantTipoDocumentoPantalla;
import com.atosorigin.deri.contrapartida.manttipostocumento.business.MantTiposDocumentoBo;
import com.atosorigin.deri.model.contrapartida.DocsContrapartida;
import com.atosorigin.deri.model.contrapartida.EstadoDocumento;
import com.atosorigin.deri.model.contrapartida.TiposDocumento;

/**
 * Clase que actúa de action listener para el caso de uso de mantenimiento de tipos de documentos.
 */
@Name("mantTipoDocumentoAction")
@Scope(ScopeType.CONVERSATION)
@FormValidator
public class MantTipoDocumentoAction extends PaginatedListAction{

	
	/**
	 * Inyección del bean de Spring "mantTiposDocumentoBo" que contiene los métodos de negocio
	 * para el caso de uso mantenimiento de tipos de documentos.
	 */
	@In("#{mantTiposDocumentoBo}")
	protected MantTiposDocumentoBo mantTiposDocumentoBo;
	
	/**
	 * Inyección del screen bean que contiene los datos de pantalla del caso de uso
	 * mantenimiento de tipos de documentos.
	 */
	@In(create=true)
	protected MantTipoDocumentoPantalla mantTipoDocumentoPantalla;
	
	@Out(required=false)
	protected TiposDocumento tipoDocumento;

	/** Los datos de paginación del 2º grid */
	public PaginationData paginationDataDelegate = new PaginationData();
		
	@In("#{customExcelExporter}")
	protected CustomExcelExporter customExcelExporter;
	/**
	 * Actualiza la lista del grid de tipos de documentos.
	 * 
	 */
	public void buscar() {
		paginationData.reset();
		refrescarLista();	
		setPrimerAcceso(false);
	}

	/**
	 * Prepara para entrar en el modo edición de un grupo de contrapartida.
	 * 
	 */
	public void editar() {
		mantTipoDocumentoPantalla.setTipoDocumento(mantTiposDocumentoBo.cargar(mantTipoDocumentoPantalla.getTiposDocumento().getId()));
		tipoDocumento = mantTipoDocumentoPantalla.getTiposDocumento();
		setModoPantalla(ModoPantalla.EDICION);
	}

	/**
	 * Prepara para entrar en el modo inspección de un grupo de contrapartida.
	 * 
	 */
	public void ver() {
		mantTipoDocumentoPantalla.setTipoDocumento(mantTiposDocumentoBo.cargar(mantTipoDocumentoPantalla.getTiposDocumento().getId()));
		tipoDocumento = mantTipoDocumentoPantalla.getTiposDocumento();
		setModoPantalla(ModoPantalla.INSPECCION);
	}

	/**
	 * 
	 * Prepara para entrar en el modo creación de un grupo de contrapartida.
	 * 
	 */
	public void nuevo() {
		TiposDocumento tiposDocumento = new TiposDocumento();
		
		tiposDocumento.setfInicio(new Date());
		EstadoDocumento estadoDocumento = new EstadoDocumento();
		estadoDocumento.setCodigo(Constantes.EST_DOC_COD_INICIO);
		estadoDocumento.setDescripcion(Constantes.EST_DOC_DESCR_INICIO);
		tiposDocumento.setEstado(estadoDocumento);
		mantTipoDocumentoPantalla.setTipoDocumento(tiposDocumento);
		tipoDocumento = mantTipoDocumentoPantalla.getTiposDocumento();
		setModoPantalla(ModoPantalla.CREACION);
	}

	
	/**
	 *  VERIFICACION: Que Tipo de Documento no este asociado a ninguna contrapartida
	 * 
	 */
	public boolean borrarValidator() {
		Long numContrapatidasAsociada = new Long(0);
		numContrapatidasAsociada = mantTiposDocumentoBo.obtenerNumContrapartidasAsociada(mantTipoDocumentoPantalla.getTiposDocumento().getId());
		if (numContrapatidasAsociada>0){			
			statusMessages.addFromResourceBundle(Severity.ERROR,"manttipodocumento.error.baja", numContrapatidasAsociada);
			return false;
		}
		
		return true;
	}
	
	/**
	 * Borra un tipo de contrapartida.
	 * 
	 */
	public void borrar() {
		mantTiposDocumentoBo.borrar(mantTipoDocumentoPantalla.getTiposDocumento());
		refrescarLista();
	}


	/**
	 * Método de validación de formulario previo a la acción guardar.
	 * El interceptor seam FormValidator lo ejecutará antes del método "guardar".
	 * VERIFICACION: 
	 *  . Si TipoDocumento.FechaInicio >   TipoDocumento.FechaFin , 
	 * mostrar 'La fecha de prescripción no puede ser superior a la fecha de inicio'
	 * .  Si tipo de documento.Obligatorio = 'No', verificar si hay contrapartidas que teniéndolo asociado, 
	 * al dejar de ser obligatorio, SÓLO se quedan con documentos opcionales. 
	 * En tal caso mostrar Debido al cambio de obligatorio a opcional, las contrapartidas {0} se quedarán sin tipo de documento obligatorio
	 * @return true si no hay errores de validación, false en caso contrario.
	 */
	public boolean guardarValidator() {
		TiposDocumento tiposDocumento = mantTipoDocumentoPantalla.getTiposDocumento();
//		if (!GenericUtils.isNullOrBlank(tiposDocumento.getObligatorio()) 
//				&& tiposDocumento.getObligatorio().equals(Constantes.CONSTANTE_NO)
//				&& modoPantalla.equals(ModoPantalla.EDICION) 
//				&& mantTiposDocumentoBo.checkOpcional(tiposDocumento.getId())){
//			statusMessages.add(Severity.INFO, "manttipodocumento.error.cambioObligatorio.no", Constantes.DEFAULT_MESSAGE_TEMPLATE);
//			return false;
//		}
		if (!GenericUtils.isNullOrBlank(tiposDocumento.getfInicio()) 
			&& !GenericUtils.isNullOrBlank(tiposDocumento.getfFin())){ 
			long diffFechaMayor = (tiposDocumento.getfInicio().getTime() - tiposDocumento.getfFin().getTime())/86400000L;	
			if (diffFechaMayor<0){
				statusMessages.addToControl("fFin",Severity.ERROR, "manttipodocumento.error.fechaInicioMayorFechaFin", Constantes.DEFAULT_MESSAGE_TEMPLATE);				
				return false;
			}
		}
		return true;
	}
	
	/**
	 * Graba el tipo de contrapartida en la base de datos.
	 * 
	 */
	public String guardar() {
		
		mantTiposDocumentoBo.guardar(mantTipoDocumentoPantalla.getTiposDocumento());
//		Solo refrescamos la lista si había una búsqueda hecha
//SMM: inc 767
		if(!(GenericUtils.isNullOrBlank(mantTipoDocumentoPantalla.getTipoDocumentoList()) 
						|| mantTipoDocumentoPantalla.getTipoDocumentoList().isEmpty())){
			refrescarLista();	
		}
		
		return Constantes.CONSTANTE_SUCCESS;
	}	
		
	//Métodos necesarios para pantallas con grids.
	//Es necesario implementar estos métodos abstractos de PaginatedListAction
	@Override
	public List<TiposDocumento> getDataTableList() {
		return mantTipoDocumentoPantalla.getTipoDocumentoList();
	}

	@Override
	@SuppressWarnings("unchecked")
	public void setDataTableList(List<?> dataTableList) {
		mantTipoDocumentoPantalla.setTipoDocumentoList((List<TiposDocumento>)dataTableList);
		
	}

	@Override
	protected void refreshListInternal() {		
		setExportExcel(false);
		List<TiposDocumento> tipoDocumentoList = (List<TiposDocumento>)mantTiposDocumentoBo.buscar(mantTipoDocumentoPantalla.getCodigo(), mantTipoDocumentoPantalla.getDescripcion(), mantTipoDocumentoPantalla.getObligatorio(), mantTipoDocumentoPantalla.getEstado(), paginationData);
		mantTipoDocumentoPantalla.setTipoDocumentoList(tipoDocumentoList);
	}

	@Override
	public void refrescarListaExcel() {
		setExportExcel(true);
		List<TiposDocumento> tipoDocumentoList = (List<TiposDocumento>)mantTiposDocumentoBo.buscar(mantTipoDocumentoPantalla.getCodigo(), mantTipoDocumentoPantalla.getDescripcion(), mantTipoDocumentoPantalla.getObligatorio(), mantTipoDocumentoPantalla.getEstado(), paginationData.getPaginationDataForExcel());						
		mantTipoDocumentoPantalla.setTipoDocumentoList(tipoDocumentoList);
	}
	
	public void actualizarEstado() {
		TiposDocumento tipoDocumento = mantTipoDocumentoPantalla.getTiposDocumento();
		if (!GenericUtils.isNullOrBlank(tipoDocumento.getfFin())){
			EstadoDocumento estadoDocumento = new EstadoDocumento();
			estadoDocumento.setCodigo(Constantes.EST_DOC_COD_PRESCRITO);
			estadoDocumento.setDescripcion(Constantes.EST_DOC_DESCR_PRESCRITO);
			tipoDocumento.setEstado(estadoDocumento);
						
		}else{
			tipoDocumento.setEstado(null);
		}
		mantTipoDocumentoPantalla.setTipoDocumento(tipoDocumento);
		this.tipoDocumento = mantTipoDocumentoPantalla.getTiposDocumento();
	}
	
	/**
	 * Busca la lista de contrapartidas
	 * 
	 */
	public void buscarContrapartidas() {	
		paginationDataDelegate.reset();
		tipoDocumento = mantTipoDocumentoPantalla.getTiposDocumento();
		refrescarContrapartidas();
	}
	
	/**
	 * Busca la lista de contrapartidas
	 * 
	 */
	public void refrescarContrapartidas() {		
		//List<DocsContrapartida> docsContrapartidaList = mantTiposDocumentoBo.buscarContrapartidasPorDocumento(mantTipoDocumentoPantalla.getTiposDocumento().getId(), paginationDataDelegate);		
		List<DocsContrapartida> docsContrapartidaList = mantTiposDocumentoBo.buscarContrapartidasPorDocumento(tipoDocumento.getId(), paginationDataDelegate);
		mantTipoDocumentoPantalla.setDocsContrapartidaList(docsContrapartidaList);
	}
		
	/**
	 * Salir listado contrapartidas
	 * 
	 */
	public void salirDocsContrapartida() {
	}

	public void modificarCampoObligatorio(){		
		//Enric, despues de poner el TiposDocumento en la action y la conversacion no hace falta recuperarlo
		//TiposDocumento tiposDocumento = mantTipoDocumentoPantalla.getTipoDocumento();
		if (!GenericUtils.isNullOrBlank(tipoDocumento.getObligatorio()) && tipoDocumento.getObligatorio().equals(Constantes.CONSTANTE_NO)){
			String listaContrapartidasSt = null;
			listaContrapartidasSt = mantTiposDocumentoBo.modificarCampoObligatorio(tipoDocumento.getId());			
			statusMessages.addFromResourceBundle(Severity.INFO, "manttipodocumento.error.cambioObligatorio.no", listaContrapartidasSt==null?"":listaContrapartidasSt);

		}
	}

	/** ****************************
	 * LISTADO DE CONTRAPARTIDAS - paginación
	 ******************************* */
	
	
	public PaginationData getPaginationDataDelegate() {
		return paginationDataDelegate;
	}

	public void setPaginationDataDelegate(PaginationData paginationDataDelegate) {
		this.paginationDataDelegate = paginationDataDelegate;
	}
	
	public void generarExcelDelegate(String dataTableId){
		List<DocsContrapartida> docsContrapartidaList = mantTiposDocumentoBo.buscarContrapartidasPorDocumento(mantTipoDocumentoPantalla.getTiposDocumento().getId(), paginationDataDelegate.getPaginationDataForExcel());		
		mantTipoDocumentoPantalla.setDocsContrapartidaList(docsContrapartidaList);
		customExcelExporter.export(dataTableId);
	}
	
	public void firstDelegate() {
		paginationDataDelegate.setFirstResult(0);
		this.refrescarContrapartidas();
	}

	public boolean isPreviousExistsDelegate() {
		return paginationDataDelegate.getFirstResult() > 1;
	}
	
	public void previousDelegate() {
		paginationDataDelegate.setFirstResult(paginationDataDelegate.getFirstResult() - paginationDataDelegate.getMaxResults());
		this.refrescarContrapartidas();
	}
	
	public boolean isNextExistsDelegate() {
		return mantTipoDocumentoPantalla.getDocsContrapartidaList() != null && paginationDataDelegate.getMaxResults() != null
				&& mantTipoDocumentoPantalla.getDocsContrapartidaList().size() > paginationDataDelegate.getMaxResults();
	}	
	
	public void nextDelegate() {
		paginationDataDelegate.setFirstResult(paginationDataDelegate.getFirstResult() + paginationDataDelegate.getMaxResults());
		this.refrescarContrapartidas();
	}	
   
}
