package com.atosorigin.deri.contrapartida.manttipodocumento.screen;

import java.util.List;

import org.jboss.seam.ScopeType;
import org.jboss.seam.annotations.Name;
import org.jboss.seam.annotations.Scope;
import org.jboss.seam.annotations.datamodel.DataModel;
import org.jboss.seam.annotations.datamodel.DataModelSelection;

import com.atosorigin.deri.model.contrapartida.DocsContrapartida;
import com.atosorigin.deri.model.contrapartida.EstadoDocumento;
import com.atosorigin.deri.model.contrapartida.TiposDocumento;


/**
 *  Contiene los datos de pantalla necesarios para el caso de uso mantenimiento de tipos de documentos
 */
@Name("mantTipoDocumentoPantalla")
@Scope(ScopeType.CONVERSATION)
public class MantTipoDocumentoPantalla {


		/** código. Criterio de búsqueda de tipos de documentos  */
	protected String codigo;

	/** Descripcion. Criterio de búsqueda de tipos de documentos  */
	protected String descripcion;
	
	/** Obligatorio. Criterio de búsqueda de tipos de documentos  */
	protected String obligatorio;	

	/** Estado. Criterio de búsqueda de tipos de documentos  */
	protected EstadoDocumento estado;	
	
	/** Lista de datos para el grid. */
	@DataModel(value ="listaDtTipoDocumento")
	protected List<TiposDocumento> tipoDocumentoList;
	
	/** Lista de datos para el grid. */
	@DataModel(value ="listaDtDocsContrapartida")
	protected List<DocsContrapartida> docsContrapartidaList;			

	/** Tipo de documento seleccionado en el grid */
    //@Out(required=false) Enric: sacamos el @out del DataModelSelection, a veces causa problemas
	@DataModelSelection(value ="listaDtTipoDocumento")
    protected TiposDocumento tiposDocumento;

	//Enric, añadimos los contructores
	public MantTipoDocumentoPantalla() {
	}
	
	//Enric, añadimos los contructores
	public MantTipoDocumentoPantalla(String codigo, String descripcion, String obligatorio, EstadoDocumento estado,
			List<TiposDocumento> tipoDocumentoList, List<DocsContrapartida> docsContrapartidaList, TiposDocumento tiposDocumento) {
		super();
		this.codigo = codigo;
		this.descripcion = descripcion;
		this.obligatorio = obligatorio;
		this.estado = estado;
		this.tipoDocumentoList = tipoDocumentoList;
		this.docsContrapartidaList = docsContrapartidaList;
		this.tiposDocumento = tiposDocumento;
	}
	
	public String getDescripcion() {
		return descripcion;
	}

	public void setDescripcion(String descripcion) {
		this.descripcion = descripcion;
	}
	
	public String getCodigo() {
		return codigo;
	}

	public void setCodigo(String codigo) {
		this.codigo = codigo;
	}

	public String getObligatorio() {
		return obligatorio;
	}

	public void setObligatorio(String obligatorio) {
		this.obligatorio = obligatorio;
	}

	public EstadoDocumento getEstado() {
		return estado;
	}

	public void setEstado(EstadoDocumento estado) {
		this.estado = estado;
	}

	public List<TiposDocumento> getTipoDocumentoList() {
		return tipoDocumentoList;
	}

	public void setTipoDocumentoList(List<TiposDocumento> tipoDocumentoList) {
		this.tipoDocumentoList = tipoDocumentoList;
	}

	public TiposDocumento getTiposDocumento() {
		return tiposDocumento;
	}

	public void setTipoDocumento(TiposDocumento tiposDocumento) {
		this.tiposDocumento = tiposDocumento;
	}

	public List<DocsContrapartida> getDocsContrapartidaList() {
		return docsContrapartidaList;
	}

	public void setDocsContrapartidaList(
			List<DocsContrapartida> docsContrapartidaList) {
		this.docsContrapartidaList = docsContrapartidaList;
	}
}
