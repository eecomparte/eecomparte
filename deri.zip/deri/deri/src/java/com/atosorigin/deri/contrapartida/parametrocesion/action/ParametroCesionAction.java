package com.atosorigin.deri.contrapartida.parametrocesion.action;

import java.util.List;

import org.jboss.seam.ScopeType;
import org.jboss.seam.annotations.In;
import org.jboss.seam.annotations.Name;
import org.jboss.seam.annotations.Scope;
import org.jboss.seam.core.Conversation;
import org.jboss.seam.international.StatusMessage.Severity;

import com.atosorigin.common.action.ModoPantalla;
import com.atosorigin.common.action.PaginatedListAction;
import com.atosorigin.common.constantes.Constantes;
import com.atosorigin.common.formvalidator.FormValidator;
import com.atosorigin.common.utils.GenericUtils;
import com.atosorigin.deri.contrapartida.parametrocesion.screen.ParametroCesionPantalla;
import com.atosorigin.deri.model.parametrizacion.ParametrosCesion;
import com.atosorigin.deri.model.parametrizacion.ParametrosCesionId;
import com.atosorigin.deri.parametrizacion.parametroscesion.business.ParametrosCesionBo;

/**
 * Clase action listener para el caso de uso de parámetros de cesión.
 */
@Name("parametroCesionAction")
@Scope(ScopeType.CONVERSATION)
@FormValidator
public class ParametroCesionAction extends PaginatedListAction {

	/**
	 * Inyección del bean de Spring "parametrosCesionBo" que contiene los métodos de
	 * negocio para el caso de uso parámetros de cesión.
	 */
	@In("#{parametrosCesionBo}")
	protected ParametrosCesionBo parametrosCesionBo;
	
	/**
	 * Inyección del screen bean que contiene los datos de pantalla del caso de
	 * uso parametros de cesión
	 */
	@In(create = true)
	protected ParametroCesionPantalla parametroCesionPantalla;

	/** Bean necesario para la búsqueda de parámetros de cesión por criterios */
	protected ParametrosCesion criterios;
	
	public ParametroCesionAction() {
		this.criterios = new ParametrosCesion(new ParametrosCesionId());
	}
	
	
	public void proyectoColat(){
		this.parametroCesionPantalla.setProyecto(Constantes.NOMBRE_PROYECTO_COLAT);
	}

	public void proyectoDeri(){
		this.parametroCesionPantalla.setProyecto(Constantes.NOMBRE_PROYECTO_DERI);
	}

	
	
	/** Actualiza la lista del grid de parámetros de cesión */
	public void buscar() {
		paginationData.reset();
		/** Limpiamos la información de paginación */
		refrescarLista();
		setPrimerAcceso(false);
	}

	/**
	 * Actualiza la lista del grid de parámetros de cesión y vuelve a la pantalla
	 * de búsqueda
	 */
	public void salirDetalle() {
		paginationData.reset();
		/** Limpiamos la información de paginación */
		if (this.modoPantalla.equals(ModoPantalla.EDICION)) {
			refrescarLista();
		}
	}
	
	/** Prepara para entrar en el modo edición de un parámetro de cesión. */
	public void editar() {
		
		/** Guardamos la info de la id del seleccionado en el grid, necesaria para poder hacer el update
		 * ya que uno de los campos de la PK es editable */
		String projecte = GenericUtils.isNullOrBlank(this.parametroCesionPantalla.getProyecto())?
				Constantes.NOMBRE_PROYECTO_DERI:this.parametroCesionPantalla.getProyecto();
//		(this.parametroCesionPantalla.getParametrosCesionIdSelec()).setProyecto(Constantes.NOMBRE_PROYECTO_DERI);
		(this.parametroCesionPantalla.getParametrosCesionIdSelec()).setProyecto(projecte);
		
		(this.parametroCesionPantalla.getParametrosCesionIdSelec()).setConcepto(parametroCesionPantalla.getParametroCesionSelec().getId().getConcepto());
		(this.parametroCesionPantalla.getParametrosCesionIdSelec()).setEntidadDestino(parametroCesionPantalla.getParametroCesionSelec().getId().getEntidadDestino());
		(this.parametroCesionPantalla.getParametrosCesionIdSelec()).setProducto(parametroCesionPantalla.getParametroCesionSelec().getId().getProducto());
		(this.parametroCesionPantalla.getParametrosCesionIdSelec()).setTipoCesion(parametroCesionPantalla.getParametroCesionSelec().getId().getTipoCesion());
		(this.parametroCesionPantalla.getParametrosCesionIdSelec()).setTipoConcepto(parametroCesionPantalla.getParametroCesionSelec().getId().getTipoConcepto());
		(this.parametroCesionPantalla.getParametrosCesionIdSelec()).setTipoOperacion(parametroCesionPantalla.getParametroCesionSelec().getId().getTipoOperacion());
			
		parametroCesionPantalla.setParametroCesion(parametroCesionPantalla.getParametroCesionSelec());
		parametroCesionPantalla.setParametrosCesionIdSelec(this.parametroCesionPantalla.getParametrosCesionIdSelec());
		
		this.setModoPantalla(ModoPantalla.EDICION);
	}

	/** Prepara para entrar en el modo inspección de un parámetro de cesión. */
	public void ver() {
		parametroCesionPantalla.setParametroCesion(parametroCesionPantalla.getParametroCesionSelec());
		this.setModoPantalla(ModoPantalla.INSPECCION);
	}
	
	/**
	 * Valida que no se pueda dar de alta un registro con la misma PK que uno que ya
	 * exista en la bbdd
	 * @return
	 */
	public boolean guardarValidator(){
		
		boolean esCorrecto = true;
		ParametrosCesion paramcesEncontrado = null;
		
		// Comprobamos si el id de país se corresponde con uno válido, si no, mostramos mensaje
		// de error al usuario
		if (!parametrosCesionBo.existePais(parametroCesionPantalla.getParametroCesion().getCodigoPais())){
			esCorrecto = false;
			statusMessages.addToControl("codigoPaisTxt",Severity.ERROR, "#{messages['parametrocesion.pais.noexiste']}");
		}
		
		if (ModoPantalla.CREACION.equals(this.modoPantalla)) {
			/** Cuando Concepto sea diferente de Prima y estemos en una alta,
			 * el valor que tomará Tipo Concepto será el mismo que Concepto*/ 
			if(!Constantes.CONCEPTO_PRIMA.equalsIgnoreCase(parametroCesionPantalla.getParametroCesion().getId().getConcepto())){
				String tipoConc = parametroCesionPantalla.getParametroCesion().getId().getConcepto();
				parametroCesionPantalla.getParametroCesion().getId().setTipoConcepto(tipoConc);
			}
			/** En el alta, comprobar si el registro ya existe*/
			paramcesEncontrado = parametrosCesionBo
					.cargar(parametroCesionPantalla.getParametroCesion());
		} else if(ModoPantalla.EDICION.equals(this.getModoPantalla())){
			// Primero comprobamos si se ha cambiado la entidad destino para realizar o no la validación
			if(!parametroCesionPantalla.getParametrosCesionIdSelec().getEntidadDestino().equals(parametroCesionPantalla.getParametroCesion().getId().getEntidadDestino())){
				paramcesEncontrado = parametrosCesionBo.cargar(parametroCesionPantalla.getParametroCesion());
			}
		}
		
		if (!GenericUtils.isNullOrBlank(paramcesEncontrado)) {
			esCorrecto = false;
			statusMessages.add(Severity.ERROR, "#{messages['parametrocesion.error.yaexiste']}");
		}
		
		return esCorrecto;
	}
	
	/** Graba el parámetro de cesión en la base de datos. */
	public String guardar() {
		
		if(ModoPantalla.CREACION.equals(this.modoPantalla)){
			parametrosCesionBo.alta(parametroCesionPantalla.getParametroCesion());
		} else if (ModoPantalla.EDICION.equals(this.modoPantalla)){
			parametrosCesionBo.actualizarParametroCesion(parametroCesionPantalla.getParametroCesion(), parametroCesionPantalla.getParametrosCesionIdSelec());
			parametrosCesionBo.recargar(parametroCesionPantalla.getParametroCesion());
		}
		refrescarLista();
		return Constantes.CONSTANTE_SUCCESS;
	}

	/** Borra un parámetro de cesión. */
	public void borrar() {
		parametrosCesionBo.baja(parametroCesionPantalla.getParametroCesionSelec());
		refrescarLista();
	}

	/** Prepara para entrar en el modo creación de un parámetro de cesión. */
	public void nuevo() {
		String projecte = GenericUtils.isNullOrBlank(this.parametroCesionPantalla.getProyecto())?
				Constantes.NOMBRE_PROYECTO_DERI:this.parametroCesionPantalla.getProyecto();
		
		parametroCesionPantalla.setParametroCesion(new ParametrosCesion(new ParametrosCesionId(projecte,null,null,null,null,null,null)));
		this.setModoPantalla(ModoPantalla.CREACION);
	}
	
	@Override
	protected void refreshListInternal() {
		this.setExportExcel(false);
		fijarCriteriosBusqueda();
		List<ParametrosCesion> listaParametros = (List<ParametrosCesion>) parametrosCesionBo.buscarParametrosCesion(criterios, paginationData);
		parametroCesionPantalla.setParametrosCesionList(listaParametros);
	}

	@Override
	public void refrescarListaExcel() {
		this.setExportExcel(true);
		fijarCriteriosBusqueda();
		List<ParametrosCesion> listaParametros = (List<ParametrosCesion>) parametrosCesionBo.buscarParametrosCesion(criterios, paginationData.getPaginationDataForExcel());
		parametroCesionPantalla.setParametrosCesionList(listaParametros);
	}
	
	/** Recoge los criterios de búsqueda seleccionados por el usuario en una única instancia de
	 * la clase ParametrosCesion
	 */
	private void fijarCriteriosBusqueda(){
		String projecte = GenericUtils.isNullOrBlank(this.parametroCesionPantalla.getProyecto())?
				Constantes.NOMBRE_PROYECTO_DERI:this.parametroCesionPantalla.getProyecto();
		
		criterios.getId().setProyecto(projecte);
		criterios.getId().setConcepto(this.parametroCesionPantalla.getConceptoBusq());
		criterios.getId().setProducto(this.parametroCesionPantalla.getProductoBusq());
		criterios.getId().setTipoCesion(this.parametroCesionPantalla.getTipoCesionBusq());
		criterios.getId().setTipoConcepto(this.parametroCesionPantalla.getTipoConceptoBusq());
		criterios.getId().setTipoOperacion(this.parametroCesionPantalla.getTipoOperacionBusq());
	}
	
	public void salir(){
		Conversation conversacion = Conversation.instance();
		//Volvemos a la anterior conversación
		if(conversacion.isNested()){
			conversacion.redirectToParent();
		} else {
			redirectToURL("/home.seam");
			conversacion.endAndRedirect();
		}
	}
	
	@Override
	public List<?> getDataTableList() {
		return parametroCesionPantalla.getParametrosCesionList();
	}

	@SuppressWarnings("unchecked")
	@Override
	public void setDataTableList(List<?> dataTableList) {
		this.parametroCesionPantalla.setParametrosCesionList((List<ParametrosCesion>) dataTableList);
	}

}
