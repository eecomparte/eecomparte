package com.atosorigin.deri.contrapartida.parametrocesion.screen;

import java.util.List;

import org.jboss.seam.ScopeType;
import org.jboss.seam.annotations.Name;
import org.jboss.seam.annotations.Out;
import org.jboss.seam.annotations.Scope;
import org.jboss.seam.annotations.datamodel.DataModel;
import org.jboss.seam.annotations.datamodel.DataModelSelection;

import com.atosorigin.deri.model.catalogo.Producto;
import com.atosorigin.deri.model.parametrizacion.ParametrosCesion;
import com.atosorigin.deri.model.parametrizacion.ParametrosCesionId;

/**
 * Contiene los datos de pantalla necesarios para el caso de uso mantenimiento de subyacentes.
 */
@Name("parametroCesionPantalla")
@Scope(ScopeType.CONVERSATION)
public class ParametroCesionPantalla {

	/** Lista de datos para el grid. */
	@DataModel(value = "listaDtParametrosCesion")
	protected List<ParametrosCesion> parametrosCesionList;

	/** ParametroCesion seleccionado en el grid */
	@DataModelSelection(value = "listaDtParametrosCesion")
	@Out(value = "parametroCesionSelec", required = false)
	protected ParametrosCesion parametroCesionSelec;

	@Out(value = "parametroCesion", required = false)
	protected ParametrosCesion parametroCesion;
	
	/** Necesario para el update de parametros de cesión */
	protected ParametrosCesionId parametrosCesionIdSelec;

	protected String proyecto;
	
	/** Criterios de seleccion */
	protected Producto productoBusq;
	protected String tipoOperacionBusq;
	protected String tipoCesionBusq;
	protected String conceptoBusq;
	protected String tipoConceptoBusq;

	public ParametroCesionPantalla() {
		this.parametrosCesionIdSelec = new ParametrosCesionId();
	}
	
	//GETTERS - SETTERS
	
	public List<ParametrosCesion> getParametrosCesionList() {
		return parametrosCesionList;
	}

	public ParametrosCesion getParametroCesionSelec() {
		return parametroCesionSelec;
	}

	public ParametrosCesion getParametroCesion() {
		return parametroCesion;
	}

	public void setParametrosCesionList(List<ParametrosCesion> parametrosCesionList) {
		this.parametrosCesionList = parametrosCesionList;
	}

	public void setParametroCesionSelec(ParametrosCesion parametroCesionSelec) {
		this.parametroCesionSelec = parametroCesionSelec;
	}

	public void setParametroCesion(ParametrosCesion parametroCesion) {
		this.parametroCesion = parametroCesion;
	}

	public String getTipoOperacionBusq() {
		return tipoOperacionBusq;
	}

	public String getTipoCesionBusq() {
		return tipoCesionBusq;
	}

	public String getConceptoBusq() {
		return conceptoBusq;
	}

	public String getTipoConceptoBusq() {
		return tipoConceptoBusq;
	}

	public void setTipoOperacionBusq(String tipoOperacionBusq) {
		this.tipoOperacionBusq = tipoOperacionBusq;
	}

	public void setTipoCesionBusq(String tipoCesionBusq) {
		this.tipoCesionBusq = tipoCesionBusq;
	}

	public void setConceptoBusq(String conceptoBusq) {
		this.conceptoBusq = conceptoBusq;
	}

	public void setTipoConceptoBusq(String tipoConceptoBusq) {
		this.tipoConceptoBusq = tipoConceptoBusq;
	}

	public Producto getProductoBusq() {
		return productoBusq;
	}

	public void setProductoBusq(Producto productoBusq) {
		this.productoBusq = productoBusq;
	}

	public ParametrosCesionId getParametrosCesionIdSelec() {
		return parametrosCesionIdSelec;
	}

	public void setParametrosCesionIdSelec(
			ParametrosCesionId parametrosCesionIdSelec) {
		this.parametrosCesionIdSelec = parametrosCesionIdSelec;
	}

	public String getProyecto() {
		return proyecto;
	}

	public void setProyecto(String proyecto) {
		this.proyecto = proyecto;
	}
	
}
