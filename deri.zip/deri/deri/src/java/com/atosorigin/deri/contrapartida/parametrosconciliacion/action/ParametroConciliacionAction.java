package com.atosorigin.deri.contrapartida.parametrosconciliacion.action;

import java.math.BigDecimal;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.jboss.seam.ScopeType;
import org.jboss.seam.annotations.In;
import org.jboss.seam.annotations.Name;
import org.jboss.seam.annotations.Scope;
import org.jboss.seam.international.StatusMessage;

import com.atosorigin.common.action.GenericAction;
import com.atosorigin.common.constantes.Constantes;
import com.atosorigin.common.formvalidator.FormValidator;
import com.atosorigin.common.utils.GenericUtils;
import com.atosorigin.deri.contrapartida.parametrosconciliacion.screen.ParametrosConciliacionPantalla;
import com.atosorigin.deri.gestionoperaciones.parametroconciliacion.business.ParametroConciliacionBo;
import com.atosorigin.deri.model.gestionoperaciones.ParametroConciliacion;

/**
 * Clase que actúa de action listener para el caso de uso de mantenimiento de parametros de conciliación.
 */
@Name("parametroConciliacionAction")
@Scope(ScopeType.CONVERSATION)
@FormValidator
public class ParametroConciliacionAction extends GenericAction{

	private static final String margenMaximo = "999999.999";
	
	/**
	 * Inyección del bean de Spring "ParametroConciliacionBo" que contiene los métodos de negocio
	 * para el caso de uso mantenimiento de parametros de conciliacion.
	 */
	@In("#{parametroConciliacionBo}")
	protected  ParametroConciliacionBo parametroConciliacionBo;
	
	/**
	 * Inyección del screen bean que contiene los datos de pantalla del caso de uso
	 * mantenimiento de parametros de conciliacion.
	 */
	@In(create=true)
	protected ParametrosConciliacionPantalla  parametrosConciliacionPantalla;
	
	/** Carga los valores de inicialización del formulario */ 
	public void newFormInstance() {

		SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMdd");
		try {
			this.parametrosConciliacionPantalla.setFecha(sdf.parse(parametroConciliacionBo.cargar(Constantes.FECHA1).getDescripcion()));
		} catch (ParseException e) {
			statusMessages.add(StatusMessage.Severity.ERROR, "#{messages['parametrocon.error.fecha']}");
		}
		
		String margen = parametroConciliacionBo.cargar(Constantes.MARGEN).getDescripcion();
		
		this.parametrosConciliacionPantalla.setMargen(new BigDecimal(margen.replace(',','.')));
		
	}
	
	/**
	 * Validamos que el formato numérico del campo margen es el correcto
	 * @return
	 */
	public boolean modificarValidator(){
		
		boolean esCorrecto = true;
		BigDecimal valorMaximo = new BigDecimal(margenMaximo);
		BigDecimal valor = this.parametrosConciliacionPantalla.getMargen();
		
		if(valorMaximo.compareTo(valor) == -1){
			esCorrecto = false;
			statusMessages.addToControl("margen1",StatusMessage.Severity.ERROR, "#{messages['parametrocon.margen.superior']}");
		} else {
			
			esCorrecto = GenericUtils.validaFormatoDecimal(valor, 6, 3);
			
			if(!esCorrecto){
				statusMessages.addToControl("margen1",StatusMessage.Severity.ERROR, "#{messages['parametrocon.margen.formato']}");
			}
		}
		
		return esCorrecto;
	}
	
	
	/**
	 * Modifica los parámetros.
	 */
	public String modificar() {
		
		//Modifica los cambios
		ParametroConciliacion parametroConciliacionFecha = parametroConciliacionBo.cargar(Constantes.FECHA1);
		ParametroConciliacion parametroConciliacionMargen = parametroConciliacionBo.cargar(Constantes.MARGEN);
		
		Date fechaInicio = this.parametrosConciliacionPantalla.getFecha();
		SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMdd");
		parametroConciliacionFecha.setCodigo(Constantes.FECHA1);
		parametroConciliacionFecha.setDescripcion(sdf.format(fechaInicio));
	
		BigDecimal margen = this.parametrosConciliacionPantalla.getMargen();
		parametroConciliacionMargen.setCodigo(Constantes.MARGEN);
		parametroConciliacionMargen.setDescripcion(margen.toString().replace('.', ','));
		
		parametroConciliacionBo.guardar(parametroConciliacionFecha);
		parametroConciliacionBo.guardar(parametroConciliacionMargen);
		
		statusMessages.add(StatusMessage.Severity.INFO, "#{messages['parametrocon.modificacion']}");
		return Constantes.CONSTANTE_SUCCESS;	
		
	}
	
	//implementacion de elemento Bo y Pantalla
	public ParametroConciliacionBo getParametroConciliacionBo() {
		return parametroConciliacionBo;
	}

	public void setParametroConciliacionBo(
			ParametroConciliacionBo parametroConciliacionBo) {
		this.parametroConciliacionBo = parametroConciliacionBo;
	}

	public ParametrosConciliacionPantalla getParametrosConciliacionPantalla() {
		return parametrosConciliacionPantalla;
	}

	public void setParametrosConciliacionPantalla(
			ParametrosConciliacionPantalla parametrosConciliacionPantalla) {
		this.parametrosConciliacionPantalla = parametrosConciliacionPantalla;
	}

}
