package com.atosorigin.deri.contrapartida.parametrosconciliacion.screen;

import java.math.BigDecimal;
import java.util.Date;

import org.jboss.seam.ScopeType;
import org.jboss.seam.annotations.Name;
import org.jboss.seam.annotations.Scope;

/**
 *  Contiene los datos de pantalla necesarios para el caso de uso mantenimiento de plazos.
 */
@Name("parametrosConciliacionPantalla")
@Scope(ScopeType.CONVERSATION)
public class ParametrosConciliacionPantalla {

	/** Fecha inicio. Criterio de búsqueda fecha inicio. */
	protected Date fecha;
	
	/** Margen tolerancia. Criterio de búsqueda de margen.*/	
	protected BigDecimal margen;
	
	/*metodos get y set de las variables de pantalla de búsqueda*/
	public Date getFecha() {
		return fecha;
	}

	public void setFecha(Date fecha) {
		this.fecha = fecha;
	}

	public BigDecimal getMargen() {
		return margen;
	}

	public void setMargen(BigDecimal margen) {
		this.margen = margen;
	}

}
