package com.atosorigin.deri.contrapartida.tipocontrapartida.action;

import java.util.List;

import org.jboss.seam.ScopeType;
import org.jboss.seam.annotations.In;
import org.jboss.seam.annotations.Name;
import org.jboss.seam.annotations.Scope;
import org.jboss.seam.annotations.datamodel.DataModel;
import org.jboss.seam.annotations.datamodel.DataModelSelection;
import org.jboss.seam.international.StatusMessage.Severity;

import com.atosorigin.common.action.ModoPantalla;
import com.atosorigin.common.action.PaginatedListAction;
import com.atosorigin.common.formvalidator.FormValidator;
import com.atosorigin.common.utils.GenericUtils;
import com.atosorigin.deri.contrapartida.tipocontrapartida.business.TipoContrapartidaBo;
import com.atosorigin.deri.contrapartida.tipocontrapartida.screen.TipoContrapartidaPantalla;
import com.atosorigin.deri.model.contrapartida.TipoContrapartida;

/**
 * Clase que actúa de action listener para el caso de uso de mantenimiento de tipos de contrapartidas.
 */
@Name("tipoContrapartidaAction")
@Scope(ScopeType.CONVERSATION)
@FormValidator
public class TipoContrapartidaAction extends PaginatedListAction{

	/**
	 * Inyección del bean de Spring "tipoContrapartidaBo" que contiene los métodos de negocio
	 * para el caso de uso mantenimiento de tipos de contrapartidas.
	 */
	@In("#{tipoContrapartidaBo}")
	protected TipoContrapartidaBo tipoContrapartidaBo;
	
	
	/** Lista de datos para el grid. */
	@DataModel(value ="listaDtTiposContrapartida")
	protected List<TipoContrapartida> tipoContrapartidaList;
	
	/** Tipo de contrapartida seleccionado en el grid */
	@DataModelSelection(value ="listaDtTiposContrapartida")
    protected TipoContrapartida tipoContrapartidaSelected;

    public TipoContrapartida getTipoContrapartidaSelected() {
		return tipoContrapartidaSelected;
	}

	public void setTipoContrapartidaSelected(
			TipoContrapartida tipoContrapartidaSelected) {
		this.tipoContrapartidaSelected = tipoContrapartidaSelected;
	}


	/**
	 * Inyección del screen bean que contiene los datos de pantalla del caso de uso
	 * mantenimiento de tipos de contrapartidas.
	 */
	@In(create=true)
	protected TipoContrapartidaPantalla tipoContrapartidaPantalla;

	/**
	 * Actualiza la lista del grid de tipos de contrapartidas.
	 * 
	 */
	public void buscar() {
		paginationData.reset();
		refrescarLista();
		setPrimerAcceso(false);
		//statusMessages.add("#{messages['status.busqueda.completada']}");
	}

	/**
	 * Prepara para entrar en el modo edición de un tipo de contrapartida.
	 * 
	 */
	public void editar() {
		tipoContrapartidaPantalla.setTipoContrapartida(tipoContrapartidaSelected);
		//statusMessages.add("#{messages['status.edicion']}");
		setModoPantalla(ModoPantalla.EDICION);
	}

	/**
	 * Prepara para entrar en el modo inspección de un tipo de contrapartida.
	 * 
	 */
	public void ver() {
		tipoContrapartidaPantalla.setTipoContrapartida(tipoContrapartidaSelected);
		//statusMessages.add("#{messages['status.inspeccion']}");
		setModoPantalla(ModoPantalla.INSPECCION);
	}

	/**
	 * Prepara para entrar en el modo creación de un tipo de contrapartida.
	 * 
	 */
	public void nuevo() {
		TipoContrapartida tipoContrapartida = new TipoContrapartida();
		tipoContrapartidaPantalla.setTipoContrapartida(tipoContrapartida);
		//statusMessages.add("#{messages['status.creacion']}");
		setModoPantalla(ModoPantalla.CREACION);
	}

	
	/**
	 * Borra un tipo de contrapartida.
	 * 
	 */
	public void borrar() {
		//find anterior para evitar detacheds
		tipoContrapartidaBo.borrar(tipoContrapartidaBo.cargar(tipoContrapartidaPantalla.getTipoContrapartida().getId()));
		statusMessages.add("#{messages['status.borrado']}");
		refrescarLista();
	}


	/**
	 * Método de validación de formulario previo a la acción guardar.
	 * El interceptor seam FormValidator lo ejecutará antes del método "guardar".
	 * 
	 * @return true si no hay errores de validación, false en caso contrario.
	 */
	public boolean guardarValidator() {
		TipoContrapartida tipoContrapartida = tipoContrapartidaPantalla.getTipoContrapartida();
		
		if (!GenericUtils.isNullOrBlank(tipoContrapartidaBo.cargar(tipoContrapartida.getId())) && modoPantalla.equals(ModoPantalla.CREACION)) {
			statusMessages.addToControl("tipo1", Severity.ERROR, "#{messages['tipocontrapartida.error.yaExiste']}");
			tipoContrapartida = null;
			return false;
		}		
		return true;
	}
	
	/**
	 * Graba el tipo de contrapartida en la base de datos.
	 * 
	 */
	public String guardar() {
		tipoContrapartidaBo.guardar(tipoContrapartidaPantalla.getTipoContrapartida());
		statusMessages.add("#{messages['status.actualizado.correcto']}");
		refrescarLista();
		return "success";
	}
	

		
	//Métodos necesarios para pantallas con grids.
	//Es necesario implementar estos métodos abstractos de PaginatedListAction

	@Override
	public List<TipoContrapartida> getDataTableList() {
		return tipoContrapartidaList;
	}

	@Override
	protected void refreshListInternal() {
		setExportExcel(false);
		String descripcion = null;
		if (!GenericUtils.isNullOrBlank(this.tipoContrapartidaPantalla.getDescripcion())){
			descripcion = this.tipoContrapartidaPantalla.getDescripcion();
		}
//		setPrimerAcceso(false);
		tipoContrapartidaList = tipoContrapartidaBo.buscarTiposContrapartida(descripcion, paginationData);
	}


	@Override
	public void refrescarListaExcel() {
		setExportExcel(true);
		tipoContrapartidaList = tipoContrapartidaBo.buscarTiposContrapartida(tipoContrapartidaPantalla.getDescripcion(), paginationData.getPaginationDataForExcel());		
	}

	@Override
	public void setDataTableList(List dataTableList) {
		tipoContrapartidaList= (List<TipoContrapartida>)dataTableList;
	}
	

}
