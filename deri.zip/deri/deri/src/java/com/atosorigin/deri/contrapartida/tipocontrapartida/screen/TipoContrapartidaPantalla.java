package com.atosorigin.deri.contrapartida.tipocontrapartida.screen;

import org.jboss.seam.ScopeType;
import org.jboss.seam.annotations.Name;
import org.jboss.seam.annotations.Out;
import org.jboss.seam.annotations.Scope;

import com.atosorigin.deri.model.contrapartida.TipoContrapartida;


/**
 *  Contiene los datos de pantalla necesarios para el caso de uso mantenimiento de tipos de contrapartidas.
 */
@Name("tipoContrapartidaPantalla")
@Scope(ScopeType.CONVERSATION)
public class TipoContrapartidaPantalla {

	/** Descripcion. Criterio de búsqueda de tipos de contrapartidas  */
	protected String descripcion;
	
	

	@Out(required=false)
    protected TipoContrapartida tipoContrapartida;
	
	/** Número de resultados totales para los criterios de búsqueda. */
	protected Long numFilas = 0L;
	
	public String getDescripcion() {
		return descripcion;
	}

	public void setDescripcion(String descripcion) {
		this.descripcion = descripcion;
	}


	public TipoContrapartida getTipoContrapartida() {
		return tipoContrapartida;
	}

	public void setTipoContrapartida(TipoContrapartida tipoContrapartida) {
		this.tipoContrapartida = tipoContrapartida;
	}

	public Long getNumFilas() {
		return numFilas;
	}

	public void setNumFilas(Long numFilas) {
		this.numFilas = numFilas;
	}


}
