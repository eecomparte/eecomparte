package com.atosorigin.deri.eurex.erroresconciliacion.action;

import java.util.ArrayList;
import java.util.List;

import org.jboss.seam.ScopeType;
import org.jboss.seam.annotations.Factory;
import org.jboss.seam.annotations.In;
import org.jboss.seam.annotations.Name;
import org.jboss.seam.annotations.Out;
import org.jboss.seam.annotations.Scope;
import org.jboss.seam.annotations.datamodel.DataModel;
import org.jboss.seam.annotations.datamodel.DataModelSelection;

import com.atosorigin.common.action.ModoPantalla;
import com.atosorigin.common.action.PaginatedListAction;
import com.atosorigin.common.utils.GenericUtils;
import com.atosorigin.deri.eurex.erroresconciliacion.screen.ErroresConciliacionEurexPantalla;
import com.atosorigin.deri.kondor.erroresconciliacion.business.ErroresConciliacionBo;
import com.atosorigin.deri.model.kondor.ErroresConciliacion;
import com.atosorigin.deri.model.kondor.ErroresConciliacionAgrupados;
import com.atosorigin.deri.model.kondor.TipoErroresConciliacion;



/**
 * Clase action listener para el caso de uso de Errores de Conciliacion.
 */
@Name("erroresConciliacionEurexAction")
@Scope(ScopeType.CONVERSATION)
public class ErroresConciliacionEurexAction extends PaginatedListAction {
	
	/**
	 * Inyección del bean de Spring "erroresConciliacionBo" que contiene los tipos de error
	 * para el caso de uso Errores de Conciliación.
	 */
	@In("#{erroresConciliacionBo}")
	protected ErroresConciliacionBo erroresConciliacionBo;

	/**
	 * Inyección del screen bean que contiene los datos de pantalla del caso de uso
	 * Errores de Conciliación..
	 */
	@In(create=true)
	protected ErroresConciliacionEurexPantalla erroresConciliacionEurexPantalla;
	
	
    @Out(required=false)
    protected ErroresConciliacionAgrupados errorSeleccionado;	
    
    @Out(required = false, value = "mantOperaciones.tipoErroresConciliacionEurex")
	List<TipoErroresConciliacion> tipoErroresConciliacionList = null;
    
    @Out(required = false, value = "tipoConciliacionEurex")
	List<String> tipoConciliacionEurexList = null;
    
    /** Lista de datos para el grid. */
	@DataModel(value ="listaDtConcierrEurexExcel")
	protected List<ErroresConciliacion> listaConcierrEurexExcel;
	
	@DataModelSelection(value="listaDtConcierrEurexExcel")
	protected ErroresConciliacion datmo;

	/**
	 * Actualiza la lista del grid de Errores de Conciliación.
	 */
	public void buscar() {
		paginationData.reset();
		refrescarLista();	
		setPrimerAcceso(false);
	}

	@Override
	public List<ErroresConciliacionAgrupados> getDataTableList() {
		return erroresConciliacionEurexPantalla.getErroresConciliacionAgrupList();
	}

	@Override
	protected void refreshListInternal() {
		setExportExcel(false);
		 List<ErroresConciliacionAgrupados> list = erroresConciliacionEurexPantalla.getErroresConciliacionAgrupList();
		if(list==null){
			list = new ArrayList<ErroresConciliacionAgrupados>();
			erroresConciliacionEurexPantalla.setErroresConciliacionAgrupList(list);
		}
		list.clear();
		list.addAll((List<ErroresConciliacionAgrupados>)erroresConciliacionBo.buscarErroresConciliacionAgrupados(erroresConciliacionEurexPantalla.getFechaProceso(), erroresConciliacionEurexPantalla.getTipoConciliacion(), erroresConciliacionEurexPantalla.getIndicActividad(), erroresConciliacionEurexPantalla.getnumOperacionDesde(), erroresConciliacionEurexPantalla.getnumOperacionHasta(), erroresConciliacionEurexPantalla.getCodigoError(), erroresConciliacionEurexPantalla.getDealNumDesde(), erroresConciliacionEurexPantalla.getDealNumHasta(), null, paginationData));

	}

	@Override
	public void refrescarListaExcel() {
		setExportExcel(true);
		if(listaConcierrEurexExcel == null){
			listaConcierrEurexExcel = new ArrayList<ErroresConciliacion>();
		}

		List<ErroresConciliacionAgrupados> listaAux = new ArrayList<ErroresConciliacionAgrupados>();
		listaAux= erroresConciliacionBo.buscarErroresConciliacionAgrupados(erroresConciliacionEurexPantalla.getFechaProceso(), erroresConciliacionEurexPantalla.getTipoConciliacion(), erroresConciliacionEurexPantalla.getIndicActividad(), erroresConciliacionEurexPantalla.getnumOperacionDesde(), erroresConciliacionEurexPantalla.getnumOperacionHasta(), erroresConciliacionEurexPantalla.getCodigoError(), erroresConciliacionEurexPantalla.getDealNumDesde(), erroresConciliacionEurexPantalla.getDealNumHasta(), null, paginationData.getPaginationDataForExcel());

		listaConcierrEurexExcel.clear();
		for (ErroresConciliacionAgrupados error :listaAux){
		
			if (!GenericUtils.isNullOrBlank(erroresConciliacionEurexPantalla.getIndicActividad())){
				error.setIndicActividad(erroresConciliacionEurexPantalla.getIndicActividad());
			}

			listaConcierrEurexExcel.addAll( 
				erroresConciliacionBo.recuperarErroresConciliacionDesdeAgrupado(error, 
						paginationData.getPaginationDataForExcel()));
			}

	}



	@Override
	public void setDataTableList(List<?> dataTableList) {
		erroresConciliacionEurexPantalla.setErroresConciliacionAgrupList((List<ErroresConciliacionAgrupados>)dataTableList);
	}
	
	public String getDescripTipoOper(){
		return null;
 	}
	
	/**
	 * Visualizamos un Error de Conciliación.
	 * 
	 */
	public void ver() {
		errorSeleccionado = erroresConciliacionEurexPantalla.getErroresConciliacionAgrupados();
		erroresConciliacionEurexPantalla.getErroresConciliacionAgrupados().setIndicActividad(erroresConciliacionEurexPantalla.getIndicActividad());
		setModoPantalla(ModoPantalla.INSPECCION);		
	}
	
	public void tiposErroresConciliacionSelect(){
		this.tipoErroresConciliacionList = null;
	}
	
	@Factory(value = "mantOperaciones.tipoErroresConciliacionEurex")
	public void obtenerTiposErroresConciliacionSelect() {
		this.tipoErroresConciliacionList = erroresConciliacionBo.obtenerTiposErroresConciliacionSelect(erroresConciliacionEurexPantalla.getFechaProceso(),erroresConciliacionEurexPantalla.getTipoConciliacion(),erroresConciliacionEurexPantalla.getIndicActividad());
	}

	public void tiposConciliacionSelect(){
		this.tipoConciliacionEurexList = null;
	}
	
	@Factory(value = "tipoConciliacionEurex")
	public void obtenerTiposConciliacionSelect() {
		this.tipoConciliacionEurexList = erroresConciliacionBo.obtenerTiposConciliacionSelect();
	}
	
	
	public void setNumOper(){
		if(!GenericUtils.isNullOrBlank(erroresConciliacionEurexPantalla.getnumOperacionDesde()) &&  GenericUtils.isNullOrBlank(erroresConciliacionEurexPantalla.getnumOperacionHasta()))
			erroresConciliacionEurexPantalla.setnumOperacionHasta(erroresConciliacionEurexPantalla.getnumOperacionDesde());
	}
	public void setDealNumber(){
		if(!GenericUtils.isNullOrBlank(erroresConciliacionEurexPantalla.getDealNumDesde()) &&  GenericUtils.isNullOrBlank(erroresConciliacionEurexPantalla.getDealNumHasta()))
			erroresConciliacionEurexPantalla.setDealNumHasta(erroresConciliacionEurexPantalla.getDealNumDesde());
	}
	
	public void init(){
		if (GenericUtils.isNullOrBlank(this.erroresConciliacionEurexPantalla.getFechaProceso())){
				this.erroresConciliacionEurexPantalla.setFechaProceso(erroresConciliacionBo.obtenerFechaSistema());
		}
	}
	
	
}
