package com.atosorigin.deri.eurex.erroresconciliacion.action;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.HashSet;
import java.util.List;

import org.jboss.seam.ScopeType;
import org.jboss.seam.annotations.Factory;
import org.jboss.seam.annotations.In;
import org.jboss.seam.annotations.Name;
import org.jboss.seam.annotations.Out;
import org.jboss.seam.annotations.Scope;
import org.jboss.seam.annotations.datamodel.DataModel;
import org.jboss.seam.annotations.datamodel.DataModelSelection;
import org.jboss.seam.international.StatusMessage.Severity;

import com.atosorigin.common.action.PaginatedListAction;
import com.atosorigin.common.utils.GenericUtils;
import com.atosorigin.deri.adminoper.mantoper.business.MantOperBo;
import com.atosorigin.deri.kondor.erroresconciliacion.action.ErroresConciliacionDetalleAction.ValuePair;
import com.atosorigin.deri.kondor.erroresconciliacion.business.ErroresConciliacionBo;
import com.atosorigin.deri.model.contrapartida.Contrapartida;
import com.atosorigin.deri.model.gestionoperaciones.Operacion;
import com.atosorigin.deri.model.kondor.ErroresConciliacion;
import com.atosorigin.deri.model.kondor.ErroresConciliacionAgrupados;
import com.atosorigin.deri.util.MessageBoxAction;
import com.atosorigin.deri.util.MsgBoxAction;



/**
 * Clase action listener para el caso de uso de Errores de Conciliacion.
 */
@Name("erroresConciliacionEurexDetalleAction")
@Scope(ScopeType.CONVERSATION)
public class ErroresConciliacionEurexDetalleAction extends PaginatedListAction {

	public static class ValuePair{
		private String campo;
		private String valor;
		public String getCampo() {
			return campo;
		}
		public void setCampo(String campo) {
			this.campo = campo;
		}
		public String getValor() {
			return valor;
		}
		public void setValor(String valor) {
			this.valor = valor;
		}
		public ValuePair(String campo, String valor) {
			super();
			this.campo = campo;
			this.valor = valor;
		}
		
	}
	/**
	 * Inyección del bean de Spring "erroresConciliacionBo" que contiene los tipos de error
	 * para el caso de uso Errores de Conciliación.
	 */
	@In(value = "#{mantOperBo}")
	protected MantOperBo mantOperBo;
	
	@In("#{erroresConciliacionBo}")
	protected ErroresConciliacionBo erroresConciliacionBo;

	
    @In(value="errorSeleccionado")
    protected ErroresConciliacionAgrupados errorConciliacionAgrupado;	

	/** Inyeccion del componente necesario para mostrar mensajes de decisión al usuario */
	@In(create = true)
	private MsgBoxAction msgBoxAction;
   
	@Out(required = false, value = "erroresEurexDetalleMessageBoxAction")
	private MessageBoxAction msgboxPanelErroresEurexDetalleContrapaBloq;
   
	/** Lista de datos para el grid. */
	@DataModel(value ="listaDtErroresConciliacionEurex")
	protected List<ErroresConciliacion> erroresConciliacionEurexList;
	
	@DataModel("listaCamposKondorEurex")
	private List<ValuePair> listaCamposKondorEurex;
	
	@DataModel("listaCamposBOEurex")
	private List<ValuePair> listaCamposBoEurex;
	
	private String onComplete;
	private String motivoDescarte =""; 
	
	@DataModelSelection("listaDtErroresConciliacionEurex") 
	private ErroresConciliacion errorActual;
	
	private Boolean primeraEjecucionInit=null;
	
	private HashSet<ErroresConciliacion> erroresSeleccionados = new HashSet<ErroresConciliacion>();
	@Out
	public Boolean getSelectedRow(){
		return erroresSeleccionados.contains(errorActual);
	}
	public void setSelectedRow(Boolean selected){
		if(selected){
			erroresSeleccionados.add(errorActual);
		}
		else{
			erroresSeleccionados.remove(errorActual);
		}
	}
	
	public void seleccionarError(){
		//erroresSeleccionados.add(errorActual);
	}

	@Override
	public List<ErroresConciliacion> getDataTableList() {
		// TODO Auto-generated method stub
		return erroresConciliacionEurexList;
	}

	@Override
	@Factory(value="listaDtErroresConciliacionEurex")
	public void refreshListInternal() {
		erroresSeleccionados.clear();
		setExportExcel(false);
		erroresConciliacionEurexList = erroresConciliacionBo.recuperarErroresConciliacionDesdeAgrupado(errorConciliacionAgrupado, paginationData);
	}

	@Factory("listaCamposKondorEurex")
	public void refrescarListaCamposKondor(){
		if(errorActual==null){
			listaCamposKondorEurex= Collections.EMPTY_LIST;
		}
		else{
			String camposKondor = errorActual.getCampoKp();
			String contenidoKondor = errorActual.getContenidoKP();
			listaCamposKondorEurex = parseValuePairs(camposKondor, contenidoKondor);
		}
		
	}
	@Factory("listaCamposBOEurex")
	public void refrescarListaCamposBO(){
		if(errorActual==null){
			listaCamposBoEurex= Collections.EMPTY_LIST;
		}
		else{
			String campos = errorActual.getCampoBo();
			String contenido = errorActual.getContenidoBo();
			listaCamposBoEurex = parseValuePairs(campos, contenido);
		}
		
	}
	private List<ValuePair> parseValuePairs(String campos, String contenido) {
		List<ValuePair> result = new ArrayList();
		if(campos!=null && contenido!=null){
			String[] camposArray = campos.split(";");
			String[] contenidoArray = contenido.split(";");
			int index=0;
			for (String campo : camposArray) {
				if(index<contenidoArray.length){
					String valor =contenidoArray[index]; 
					ValuePair pair = new ValuePair(campo, valor);
					result.add(pair);
					index++;
				}
			}
		}
		return result;
	}

	@Override
	public void refrescarListaExcel() {
		setExportExcel(true);
		erroresConciliacionEurexList = 
			erroresConciliacionBo.recuperarErroresConciliacionDesdeAgrupado(
					errorConciliacionAgrupado,
					paginationData.getPaginationDataForExcel());
	}

	public String getDescripTipoOper(){
		return null;
 	}

	@Override
	public void setDataTableList(List<?> dataTableList) {
		// TODO Auto-generated method stub
		
	}
	
	public void changeRow(){
		listaCamposKondorEurex=null;
		listaCamposBoEurex=null;
		refrescarListaCamposBO();
		refrescarListaCamposKondor();
	}

	public void onChangeIndActividad(){
		erroresConciliacionEurexList=null;
		errorActual=null;
		listaCamposKondorEurex=null;
		listaCamposBoEurex=null;
		
	}
	public String getRowClasses(){
		StringBuilder builder = new StringBuilder();
		int i=0;
		for (ErroresConciliacion errores : erroresConciliacionEurexList) {
			if(i>0){
				builder.append(",");
			}
			if(errores.equals(errorActual)){
				builder.append("SelectedRow");
			}
			else{
				if(i%2==0){
					builder.append("oddRow");
				}
				else{
					builder.append("evenRow");
				}
			}
			i++;
		}
		return builder.toString();
	}
	public void activar(){
		if (motivoDescarte == null ){
			erroresConciliacionBo.actualizarErroresConciliacionActivos(new ArrayList<ErroresConciliacion>(erroresSeleccionados), motivoDescarte );
			refrescarLista();
		}else{
			motivoDescarte = motivoDescarte.replaceAll("\r","");
			if (motivoDescarte.length()>250)
				statusMessages.add(Severity.ERROR,"#{messages['erroresConciliacion.error.longExcedida']}");
			else{
				erroresConciliacionBo.actualizarErroresConciliacionActivos(new ArrayList<ErroresConciliacion>(erroresSeleccionados), motivoDescarte );
				setMotivoDescarte(null);			
				refrescarLista();
				}
		}
	}
	public Boolean isActivarDisabled(){
		return erroresSeleccionados.isEmpty();
	}
	public void mostrarMotivo(){
		
		setMotivoDescarte(null);
		setOnCompleteSi();
	}
	
	public void setOnCompleteNo() {
		setOnComplete("$('motivoPanel').component.hide();return false;");
	}

	public void setOnCompleteSi() {
		setOnComplete("$('motivoPanel').component.show();");
	}
	public String getOnComplete() {
		return onComplete;
	}
	public void setOnComplete(String onComplete) {
		this.onComplete = onComplete;
	}
	public String getMotivoDescarte() {
		return motivoDescarte;
	}
	public void setMotivoDescarte(String motivoDescarte) {
		this.motivoDescarte = motivoDescarte;
	}
	public List<ErroresConciliacion> getErroresConciliacionEurexList() {
		return erroresConciliacionEurexList;
	}
	public void setErroresConciliacionEurexList(
			List<ErroresConciliacion> erroresConciliacionEurexList) {
		this.erroresConciliacionEurexList = erroresConciliacionEurexList;
	}
	public List<ValuePair> getListaCamposKondorEurex() {
		return listaCamposKondorEurex;
	}
	public void setListaCamposKondorEurex(List<ValuePair> listaCamposKondorEurex) {
		this.listaCamposKondorEurex = listaCamposKondorEurex;
	}
	public List<ValuePair> getListaCamposBoEurex() {
		return listaCamposBoEurex;
	}
	public void setListaCamposBoEurex(List<ValuePair> listaCamposBoEurex) {
		this.listaCamposBoEurex = listaCamposBoEurex;
	}

	public void voidFunction(){
		msgBoxAction.voidFunction();
	}
}
