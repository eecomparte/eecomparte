package com.atosorigin.deri.gestioncampanyas.action;

import java.util.List;

import org.jboss.seam.ScopeType;
import org.jboss.seam.annotations.In;
import org.jboss.seam.annotations.Name;
import org.jboss.seam.annotations.Scope;

import com.atosorigin.common.action.PaginatedListAction;
import com.atosorigin.common.formvalidator.FormValidator;
import com.atosorigin.common.utils.GenericUtils;
import com.atosorigin.deri.gestioncampanyas.campanya.business.CampanyaBo;
import com.atosorigin.deri.gestioncampanyas.screen.BuscadorCampanyasPantalla;
import com.atosorigin.deri.model.gestioncampanyas.Campanya;

/**
 * Clase action listener para el caso de uso de búsqueda campañas "desde".
 */
@Name("buscadorCampanyaDesdeAction")
@Scope(ScopeType.CONVERSATION)
@FormValidator
public class BuscadorCampanyasDesdeAction extends PaginatedListAction {

	/**
	/**
	 * Inyección del bean de Spring "campanyaBo" que contiene los métodos de negocio
	 * para el caso de uso mantenimiento de campañas.
	 */
	@In("#{campanyaBo}")
	protected CampanyaBo campanyaBo;

	/**
	 * Inyección del screen bean que contiene los datos de pantalla del caso de uso
	 * mantenimiento de búsqueda de campañas
	 */
	@In(create=true)
	protected BuscadorCampanyasPantalla buscadorCampanyasPantalla;

	/**
	 * Actualiza la lista del grid de búsqueda de campañas "desde"
	 * 
	 */
	public void buscar() {
		setPrimerAcceso(false);
		paginationData.reset();
		//Limpiamos también la lista de campañas "hasta"
		if(!GenericUtils.isNullOrBlank(this.buscadorCampanyasPantalla.getListaCampHasta())){
			this.buscadorCampanyasPantalla.getListaCampHasta().clear();
			this.buscadorCampanyasPantalla.setMuestraListaVacia(false);
		}
		refrescarLista();
	}

	//Métodos necesarios para pantallas con grids.
	//Es necesario implementar estos métodos abstractos de PaginatedListAction
	@Override
	public List<Campanya> getDataTableList() {
		return buscadorCampanyasPantalla.getListaCampDesde();
	}

	@Override
	@SuppressWarnings("unchecked")
	public void setDataTableList(List<?> dataTableList) {
		buscadorCampanyasPantalla.setListaCampDesde((List<Campanya>)dataTableList);
	}

	@Override
	protected void refreshListInternal() {
		this.setExportExcel(false);
		List<Campanya> ql = (List<Campanya>)campanyaBo.obtenerListaCampanyas(this.buscadorCampanyasPantalla.getCodigo(), null, this.paginationData);
		buscadorCampanyasPantalla.setListaCampDesde(ql);
	}

	@Override
	public void refrescarListaExcel() {
		this.setExportExcel(true);
		List<Campanya> ql = (List<Campanya>)campanyaBo.obtenerListaCampanyas(this.buscadorCampanyasPantalla.getCodigo(), null, this.paginationData.getPaginationDataForExcel());
		buscadorCampanyasPantalla.setListaCampDesde(ql);
	}	
	
}
