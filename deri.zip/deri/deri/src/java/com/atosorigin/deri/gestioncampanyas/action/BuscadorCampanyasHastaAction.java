package com.atosorigin.deri.gestioncampanyas.action;

import java.util.List;

import org.jboss.seam.ScopeType;
import org.jboss.seam.annotations.In;
import org.jboss.seam.annotations.Name;
import org.jboss.seam.annotations.Scope;

import com.atosorigin.common.action.PaginatedListAction;
import com.atosorigin.common.formvalidator.FormValidator;
import com.atosorigin.deri.gestioncampanyas.campanya.business.CampanyaBo;
import com.atosorigin.deri.gestioncampanyas.screen.BuscadorCampanyasPantalla;
import com.atosorigin.deri.model.gestioncampanyas.Campanya;

/**
 * Clase action listener para el caso de uso de búsqueda campañas "hasta".
 */
@Name("buscadorCampanyaHastaAction")
@Scope(ScopeType.CONVERSATION)
@FormValidator
public class BuscadorCampanyasHastaAction extends PaginatedListAction {

	/**
	/**
	 * Inyección del bean de Spring "campanyaBo" que contiene los métodos de negocio
	 * para el caso de uso mantenimiento de campañas
	 */
	@In("#{campanyaBo}")
	protected CampanyaBo campanyaBo;

	/**
	 * Inyección del screen bean que contiene los datos de pantalla del caso de uso
	 * mantenimiento de búsqueda de campañas.
	 */
	@In(create=true)
	protected BuscadorCampanyasPantalla buscadorCampanyasPantalla;
	
	/**
	 * Actualiza la lista del grid de búsqueda de campañas "hasta"
	 * 
	 */
	public void buscar() {
		paginationData.reset();
		setPrimerAcceso(false);
		this.buscadorCampanyasPantalla.setMuestraListaVacia(true);
		refrescarLista();
		
	}

	//Métodos necesarios para pantallas con grids.
	//Es necesario implementar estos métodos abstractos de PaginatedListAction
	@Override
	public List<Campanya> getDataTableList() {
		return buscadorCampanyasPantalla.getListaCampHasta();
	}

	@Override
	@SuppressWarnings("unchecked")
	public void setDataTableList(List<?> dataTableList) {
		buscadorCampanyasPantalla.setListaCampHasta((List<Campanya>)dataTableList);
	}

	@SuppressWarnings("unchecked")
	@Override
	protected void refreshListInternal() {
		this.setExportExcel(false);
		List ql = (List)campanyaBo.obtenerListaCampanyas(this.buscadorCampanyasPantalla.getCodigo(), 
				this.buscadorCampanyasPantalla.getCampanyaDesdeId(), 
				this.paginationData);
		buscadorCampanyasPantalla.setListaCampHasta(ql);
	}

	@SuppressWarnings("unchecked")
	@Override
	public void refrescarListaExcel() {
		this.setExportExcel(true);
		List ql = (List)campanyaBo.obtenerListaCampanyas(this.buscadorCampanyasPantalla.getCodigo(), 
				this.buscadorCampanyasPantalla.getCampanyaDesdeId(), 
				this.paginationData.getPaginationDataForExcel());
		buscadorCampanyasPantalla.setListaCampHasta(ql);
	}	
	
}
