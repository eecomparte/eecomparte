package com.atosorigin.deri.gestioncampanyas.action;

import java.text.SimpleDateFormat;
import java.util.Arrays;
import java.util.Date;
import java.util.Iterator;
import java.util.List;

import org.jboss.seam.ScopeType;
import org.jboss.seam.annotations.In;
import org.jboss.seam.annotations.Name;
import org.jboss.seam.annotations.Out;
import org.jboss.seam.annotations.Scope;
import org.jboss.seam.annotations.datamodel.DataModel;
import org.jboss.seam.annotations.datamodel.DataModelSelection;
import org.jboss.seam.core.Conversation;
import org.jboss.seam.core.ResourceBundle;
import org.jboss.seam.international.StatusMessage.Severity;

import com.atosorigin.common.action.PaginatedListAction;
import com.atosorigin.common.constantes.Constantes;
import com.atosorigin.common.formvalidator.FormValidator;
import com.atosorigin.common.utils.GenericUtils;
import com.atosorigin.deri.common.dbLock.DbLockService;
import com.atosorigin.deri.common.parametrosPantalla.ParametrosMantoper;
import com.atosorigin.deri.gestioncampanyas.campanya.business.CampanyaBo;
import com.atosorigin.deri.gestioncampanyas.screen.BuscadorCampanyasPantalla;
import com.atosorigin.deri.gestioncampanyas.screen.CampanyasPantalla;
import com.atosorigin.deri.model.agenda.EventoAgenda;
import com.atosorigin.deri.model.gestioncampanyas.Campanya;
import com.atosorigin.deri.model.gestioncampanyas.DescripcionEstadoCampanya;
import com.atosorigin.deri.model.gestioncampanyas.OperacionModelo;

/**
 * Clase action listener para el caso de uso de lista campañas.
 */
@Name("campanyasAction")
@Scope(ScopeType.CONVERSATION)
@FormValidator
public class CampanyasAction extends PaginatedListAction {

	
	@DataModel(value = "listaDtCampanyas")
	protected List<Campanya> campanyasList;

	
	@DataModelSelection(value = "listaDtCampanyas")
	@Out(value = "campanyaEdit", required = false)
	protected Campanya campanyaSelec;
	
	@Out(required = false, value="parametrosMantOper") //Parametros para MantOper
	private ParametrosMantoper parametrosMantOper;

	
	/**
	 * Inyección del bean de Spring "CampanyaBo" que contiene los métodos de
	 * negocio para el caso de uso de gestión de campañas.
	 */
	@In("#{campanyaBo}")
	protected CampanyaBo campanyaBo;

	/** Inyección del servicio que gestiona los bloqueos de registros en base de datos */
	@In(create = true)
	protected DbLockService dbLockService;
	
	/**
	 * Inyección del screen bean que contiene los datos de pantalla del caso de
	 * uso lista de campañas
	 */
	@In(create = true)
	protected CampanyasPantalla campanyasPantalla;
	
	/**
	 * Inyección del screen bean que contiene los datos de pantalla del caso de
	 * uso lista de campañas
	 */
	@In(create = true)
	protected BuscadorCampanyasPantalla buscadorCampanyasPantalla;
	
	@In(required=false)
	private EventoAgenda eventoSelectAgenda;
	
	@In(required=false)
	private Boolean estadoAgenda; 
	 
	@In(required=false)
	private String modo = Constantes.MODO_AGE; 
	
	private static final int EVENTO_PV_ANULACION_CAMPANYA = 5005;
	private static final int EVENTO_CAMPANYA_BLOQUEADA = 5009;
	
	// ### FUNCIONES PARA GESTIONAR LA BÚSQUEDA DE CAMPAÑAS ###
	
	/**
	 * Antes de realizar la búsqueda se comprueba que las fechas sean correctas
	 */
	public boolean buscarValidator(){
		
		boolean esCorrecto = true;
		
		if (!GenericUtils.isNullOrBlank(this.campanyasPantalla.getFechaComerDesde()) && !GenericUtils.isNullOrBlank(this.campanyasPantalla.getFechaComerHasta())){
			
			long difFechaHastaDesde = (this.campanyasPantalla.getFechaComerHasta().getTime() - this.campanyasPantalla.getFechaComerDesde().getTime())/86400000L;
			
			if(difFechaHastaDesde < 0){
				esCorrecto = false;
				statusMessages.addToControl("fechaComerDesde", Severity.ERROR, "#{messages['campanyas.error.fechascomercializacionerroneas']}");
			}
		}
		
		if(!GenericUtils.isNullOrBlank(this.campanyasPantalla.getFechaCampanyaDesde()) && !GenericUtils.isNullOrBlank(this.campanyasPantalla.getFechaCampanyaHasta())){
			
			long difFechaHastaDesde = (this.campanyasPantalla.getFechaCampanyaHasta().getTime() - this.campanyasPantalla.getFechaCampanyaDesde().getTime())/86400000L;
			
			if(difFechaHastaDesde < 0){
				esCorrecto = false;
				statusMessages.addToControl("fechaDesde", Severity.ERROR, "#{messages['campanyas.error.fechascampanyaerroneas']}");
			}
		}
		
		if (!GenericUtils.isNullOrBlank(this.campanyasPantalla.getIdCampanyaDesde()) && !GenericUtils.isNullOrBlank(this.campanyasPantalla.getIdCampanyaHasta())){
			
			if (this.campanyasPantalla.getIdCampanyaDesde().compareTo(this.campanyasPantalla.getIdCampanyaHasta()) > 0){
				esCorrecto = false;
				statusMessages.addToControl("idCampanyaDesde", Severity.ERROR, "#{messages['campanyas.error.idscampanyaerroneos']}");
			}
		}
		
		
		return esCorrecto;
		
	}
	
	public void init(){
		if (Constantes.MODO_AGE.equals(modo) && primerAcceso) {
			paginationData.reset();
			precargarDesdeAgenda();
			setPrimerAcceso(false);
		}
			
	}
	/** Actualiza la lista del grid de campañas */
	public void buscar() {
	
		/** Limpiamos la información de paginación y de los checkbox seleccionados 
		 * Deshabilitamos los botones anular y validar */
		this.campanyasPantalla.setVieneAgenda(false);
		paginationData.reset();
		this.campanyasPantalla.setMostrarAnular(false);
		this.campanyasPantalla.setMostrarValidar(false);
		setPrimerAcceso(false);
		refrescarLista();
	}
	
	/**
	 * Método llamado desde la pantalla de Agenda para mostrar la pantalla de lista de
	 * campañas con el grid cargado con los datos de campañas relativos al evento y estado
	 * de evento seleccionados en la Agenda.
	 * 
	 * @param agenda: Objeto de la clase Agenda con los filtros de búsqueda
	 */
	public void precargarDesdeAgenda(){
		String estadoEvento;
		if  (estadoAgenda)	estadoEvento ="P";
		else estadoEvento ="N";
		
		this.campanyasPantalla.setVieneAgenda(true);
		setPrimerAcceso(false);
		this.campanyasPantalla.setEstadoEvento(estadoEvento);
		this.campanyasPantalla.setEventoAgenda(eventoSelectAgenda);
		
		refrescarListaAgenda(eventoSelectAgenda, estadoEvento);
		
	}
	
	@Override
	protected void refreshListInternal() {
		
		// Limpiamos checkbox
		if(!GenericUtils.isNullOrBlank(this.campanyasPantalla.getSelectedCampanyaIds())){
			this.campanyasPantalla.getSelectedCampanyaIds().clear();
		}
		
		if (!GenericUtils.isNullOrBlank(this.campanyasPantalla.getSelectedCampanyaDataList())){
			this.campanyasPantalla.getSelectedCampanyaDataList().clear();
			this.campanyasPantalla.setSelecTodos(false);
			habilitarDeshabilitarBotones();
		}
		
		if(this.campanyasPantalla.isVieneAgenda()){
			refrescarListaAgenda(this.campanyasPantalla.getEventoAgenda(), this.campanyasPantalla.getEstadoEvento());
		} else {
			this.setExportExcel(false);

			String unidadDeNegocio = Constantes.CADENA_VACIA;
			
			if(!GenericUtils.isNullOrBlank(this.campanyasPantalla.getUnidadNegocioBusq())){
				unidadDeNegocio = this.campanyasPantalla.getUnidadNegocioBusq().getCodigo();
			}
			
			List<Campanya> listaResultados = (List<Campanya>) campanyaBo.buscarCampanyas(
					this.campanyasPantalla.getIdCampanyaDesde(),
					this.campanyasPantalla.getIdCampanyaHasta(), 
					this.campanyasPantalla.getFechaComerDesde(),
					this.campanyasPantalla.getFechaComerHasta(),
					this.campanyasPantalla.getFechaCampanyaDesde(), 
					this.campanyasPantalla.getFechaCampanyaHasta(), 
					unidadDeNegocio, 
					this.campanyasPantalla.getCobertura(), 
					this.campanyasPantalla.getEsVigente(),
					paginationData);
			
			campanyasList = listaResultados;
		}
		
	}

	/**
	 * Refresca la lista de elementos del grid con los filtros de pantalla que
	 * le llegan desde la pantalla de Agenda
	 * @param agenda: objeto de la clase Agenda con los criterios de búsqueda
	 */
	public void refrescarListaAgenda(EventoAgenda eventoAgenda, String estadoEvento) {
		this.setExportExcel(false);
		List<Campanya> listaResultados = (List<Campanya>) campanyaBo.buscarDatosAgenda(eventoAgenda, estadoEvento, paginationData);
		campanyasList = listaResultados;
	}
	
	@Override
	public void refrescarListaExcel() {
		
		if(this.campanyasPantalla.isVieneAgenda()){
			refrescarListaAgendaExcel(this.campanyasPantalla.getEventoAgenda(),this.campanyasPantalla.getEstadoEvento());
		} else {
			this.setExportExcel(true);
			String unidadDeNegocio = Constantes.CADENA_VACIA;
			
			if(!GenericUtils.isNullOrBlank(this.campanyasPantalla.getUnidadNegocioBusq())){
				unidadDeNegocio = this.campanyasPantalla.getUnidadNegocioBusq().getCodigo();
			}
			
			List<Campanya> listaResultados = (List<Campanya>) campanyaBo.buscarCampanyas(
					this.campanyasPantalla.getIdCampanyaDesde(),
					this.campanyasPantalla.getIdCampanyaHasta(), 
					this.campanyasPantalla.getFechaComerDesde(),
					this.campanyasPantalla.getFechaComerHasta(),
					this.campanyasPantalla.getFechaCampanyaDesde(), 
					this.campanyasPantalla.getFechaCampanyaHasta(), 
					unidadDeNegocio, 
					this.campanyasPantalla.getCobertura(), 
					this.campanyasPantalla.getEsVigente(),
					paginationData.getPaginationDataForExcel());
			
			campanyasList = listaResultados;
		}

	}

	/**
	 * Refresca la lista de elementos del grid para el excel cuando se accede
	 * desde la pantalla de agenda
	 * @param agenda: Objeto de la clase Agenda con los criterios de búsqueda
	 */
	public void refrescarListaAgendaExcel(EventoAgenda eventoAgenda, String estadoEvento) {
		this.setExportExcel(true);
		List<Campanya> listaResultados = (List<Campanya>) campanyaBo.buscarDatosAgenda(eventoAgenda, estadoEvento, paginationData.getPaginationDataForExcel());
		campanyasList = listaResultados;

	}
	
	/** Recupera la descripción del estado que se mostrara en la lista calculado con esta logica:
		Si campanya.estado.codigo es 'VA':
			Si campanya.InicioComercializacion > fechasistema: return 'Próx. comerc.'
			Si no: Si campanya.FinComercializacion >= fechasistema: return 'En comerc.' 
			Si no: return 'Finalizada' 
		Si campanya.estado.codigo no es 'VA': return campanya.estado.descripcion
	*/
	public String obtenerDescripcionEstado(Campanya camp){
		
		String desc = Constantes.CADENA_VACIA;
				
		if(!GenericUtils.isNullOrBlank(camp.getEstado()) && Constantes.CAMPANYA_ESTADO_VA.equalsIgnoreCase(camp.getEstado().getCodigo())){
			
			Date fechasistema = campanyaBo.obtenerFechaSistema();
			
			long difIniComerSistema = (camp.getInicioComercializacion().getTime() - fechasistema.getTime())/86400000L;
			long difFinComerSistema = (camp.getFinComercializacion().getTime() - fechasistema.getTime())/86400000L;
			
			if(difIniComerSistema > 0){
				desc = ResourceBundle.instance().getString("campanyas.estado.proxcom");
			} else if(difFinComerSistema >= 0){
				desc = ResourceBundle.instance().getString("campanyas.estado.encomerc");
			} else {
				desc = ResourceBundle.instance().getString("campanyas.estado.finalizada");
			}
			
		} else if(!GenericUtils.isNullOrBlank(camp.getEstado())) {
			desc = camp.getEstado().getDescripcion();
		}
		
		return desc;
	}
	
	/**
	 * Recoge el valor del id de campaña desde el que empezar la búsqueda en la ventana
	 * modal de búsqueda de "id campaña hasta"
	 */
	public void obtenerIdCampanyaDesde(){
		buscadorCampanyasPantalla.setCampanyaDesdeId(campanyasPantalla.getIdCampanyaDesde());
		//Se informa campaña hasta con el mismo valor que campaña desde
		campanyasPantalla.setIdCampanyaHasta(campanyasPantalla.getIdCampanyaDesde());
		//Limpiamos también la lista de campañas "hasta"
		if(!GenericUtils.isNullOrBlank(this.buscadorCampanyasPantalla.getListaCampHasta())){
			this.buscadorCampanyasPantalla.getListaCampHasta().clear();
			this.buscadorCampanyasPantalla.setMuestraListaVacia(false);
		}
	}
	
	@Override
	public List<?> getDataTableList() {
		return campanyasList;
	}
	
	@SuppressWarnings("unchecked")
	@Override
	public void setDataTableList(List<?> dataTableList) {
		campanyasList = (List<Campanya>) dataTableList;

	}
	
	// ### FIN BÚSQUEDA DE CAMPAÑAS ###
	
	// ### FUNCIONES PARA GESTIONAR LOS CHECKBOX ###
	
	/**
	 * Recorre la lista de campañas y carga los elementos seleccionados
	 */
	public void getCampanyasSeleccionadas() {
		
		Campanya dataItem;
		int tamanyoLista = campanyasList.size();
		
		if (tamanyoLista > paginationData.getMaxResults()){ //Cuando hay paginación el último registro no se debe tener en cuenta
			tamanyoLista--;
		}
		
		for (int i = 0; i < tamanyoLista; i++){
			dataItem = campanyasList.get(i);
			
			if (!GenericUtils.isNullOrBlank(campanyasPantalla.getSelectedCampanyaIds().get(dataItem.getId()))){
	            	
	        	if (campanyasPantalla.getSelectedCampanyaIds().get(dataItem.getId()).booleanValue() 
	           			&& !campanyasPantalla.getSelectedCampanyaDataList().contains(dataItem)) {
	           		
	           		campanyasPantalla.getSelectedCampanyaDataList().add(dataItem);
	           		
	           		if(campanyasPantalla.getSelectedCampanyaDataList().size() == tamanyoLista){
	           			campanyasPantalla.setSelecTodos(true);
	           		}
	           	
	           	}else if (!campanyasPantalla.getSelectedCampanyaIds().get(dataItem.getId()).booleanValue() 
            			&& campanyasPantalla.getSelectedCampanyaDataList().contains(dataItem)){
            		campanyasPantalla.getSelectedCampanyaDataList().remove(dataItem);
            		campanyasPantalla.getSelectedCampanyaIds().remove(dataItem.getId());
            		campanyasPantalla.setSelecTodos(false);
            	}
            }
		}
    }
	
	/** Seleccionar o deseleccionar todos los checks del datagrid */
	public void seleccionarTodos(){
	
		int tamanyoLista = campanyasList.size();
		
		if (tamanyoLista > paginationData.getMaxResults()){ //Cuando hay paginación el último registro no se debe tener en cuenta
			tamanyoLista--;
		}
		
		//Lo primero es saber si tenemos que seleccionar o deseleccionar todos. 
		//1- Caso deseleccionar
		if(this.campanyasPantalla.getSelecTodos()){
			
			Campanya camp;
			
			for (int k = 0; k < tamanyoLista; k++ ){
				camp = campanyasList.get(k);
				if(!GenericUtils.isNullOrBlank(campanyasPantalla.getSelectedCampanyaIds()) && campanyasPantalla.getSelectedCampanyaIds().get(camp.getId())){
					this.campanyasPantalla.getSelectedCampanyaIds().remove(camp.getId());
				}
			}
			
			this.campanyasPantalla.setSelecTodos(false);
			
			
		} else { //Caso seleccionar
			
			Campanya camp;
			
			for (int k = 0; k < tamanyoLista; k++ ){
				camp = campanyasList.get(k);
				if(!GenericUtils.isNullOrBlank(this.campanyasPantalla.getSelectedCampanyaIds()) && GenericUtils.isNullOrBlank(campanyasPantalla.getSelectedCampanyaIds().get(camp.getId()))){
					this.campanyasPantalla.getSelectedCampanyaIds().put(camp.getId(), true);
				}
			}
			
			this.campanyasPantalla.setSelecTodos(true);
		}
		
		//Guardamos en memoria las campañas seleccionadas
		if(!GenericUtils.isNullOrBlank(this.campanyasPantalla.getSelectedCampanyaDataList())){
			this.campanyasPantalla.getSelectedCampanyaDataList().clear();
		}
		getCampanyasSeleccionadas();
		
		//Finalmente se comprueba si los botones anular y validar se habilitan
		habilitarDeshabilitarBotones();
	
	}
	
	/**
	 * Cada vez que se selecciona/deselecciona una campaña se actualiza la lista
	 * de las seleccionadas y se comprueba si están habilitados los botones validar y anular
	 */
	public void seleccionarCampanya() {
		this.getCampanyasSeleccionadas();
		habilitarDeshabilitarBotones();
	}

	// ### FIN CHECKBOX ###
	
	// ### FUNCIONES PARA GESTIONAR LAS ACCIONES DE LA PANTALLA ###

	/** Realiza las validaciones previas a la llamada a la pantalla de Mantenimiento
	 * de Suscripciones
	 * @return true si las validaciones son correctas
	 */
	public boolean llamarPantallaOrdenesValidator(){
		
		boolean esCorrecto = true;
		
		if(!campanyaBo.comprobarOrdenesCampanya(campanyaSelec)){
			esCorrecto = false;
			statusMessages.add(Severity.ERROR, "#{messages['campanyas.error.campanyasinordenes']}");
		}
		
		return esCorrecto;
	}
	
//	/**
//	 * Función que llama a la pantalla de mantenimiento de órdenes (suscripciones)
//	 */
//	public String llamarPantallaOrdenes(){
//		//statusMessages.add(Severity.INFO, "La pantalla de Mantenimiento de Suscripciones no está aún implementada");
//		return Constantes.CONSTANTE_SUCCESS;
//	}
	
	/**
	 * Validaciones previas a la llamada a la pantalla de mantenimiento de operaciones
	 * @return true si se pasan las validaciones, false en caso contrario
	 */
	public boolean llamarPantallaMantOperacionesValidator(){
		
		boolean esCorrecto = true;
		
		if(!campanyaBo.comprobarOperacionesCampanya(campanyaSelec)){
			esCorrecto = false;
			statusMessages.add(Severity.ERROR, "#{messages['campanyas.error.campanyasinoperaciones']}");
		} 

		return esCorrecto;
	}
	
	/**
	 * Validaciones previas a la llamada a la pantalla de mantenimiento de operaciones modelo
	 * @return true si se pasan las validaciones, false en caso contrario
	 */
	public boolean llamarPantallaMantOperModeloValidator(){
		
		boolean esCorrecto = true;
		
		if(!campanyaBo.comprobarOperacionesModeloCampanya(campanyaSelec)){
			esCorrecto = false;
			statusMessages.add(Severity.ERROR, "#{messages['campanyas.error.campanyasinoperacionesmodelo']}");
		}
		
		return esCorrecto;
	}
	
	/**
	 * Función que llama a la pantalla de mantenimiento de operaciones
	 */
	public String llamarPantallaMantOperaciones(){
		parametrosMantOper =  new ParametrosMantoper();
		parametrosMantOper.setModo("CAM");
		parametrosMantOper.setCodcampa(campanyaSelec.getId());
		
		return Constantes.CONSTANTE_SUCCESS;
	}
	
	/**
	 * Función que llama a la pantalla de mantenimiento de operaciones modelo
	 */
	public String llamarPantallaMantOperModelo(){
		parametrosMantOper =  new ParametrosMantoper();
		parametrosMantOper.setModo("OPM");
		parametrosMantOper.setCodcampa(campanyaSelec.getId());
		
		return Constantes.CONSTANTE_SUCCESS;
	}
	
	/**
	 * El sistema anula las campañas seleccionadas si cumplen todas las condiciones necesarias
	 * para ello y refresca la lista de campañas, manteniendo el método de búsqueda usado inicialmente
	 */
	public void anular(){
		
		int contadorAnuladas = 0;
		int contadorSinAnular = 0;
		List<String> estados = Arrays.asList(Constantes.CAMPANYA_ESTADO_CA, Constantes.CAMPANYA_ESTADO_AN, Constantes.CAMPANYA_ESTADO_VE);
		Campanya campanyaInsert;
		DescripcionEstadoCampanya descripcionEstadoCampanya = new DescripcionEstadoCampanya();
		descripcionEstadoCampanya.setCodigo(Constantes.CAMPANYA_ESTADO_PV);
		
		for (Campanya campanyaCheck : this.campanyasPantalla.getSelectedCampanyaDataList()) {
			
			//1.Comprobamos estado no sea CA,AN ni VE
			if(!GenericUtils.isNullOrBlank(campanyaCheck.getEstado()) 
					&& estados.contains(campanyaCheck.getEstado().getCodigo().toUpperCase())){
				//Si tiene uno de esos estados, no se anula
				contadorSinAnular++;
			} else { //Si no está entre esos estados
				
				//2.Comprobamos si tiene ordenes activas
				if(this.campanyaBo.comprobarOrdenesActivas(campanyaCheck)){
					//Si tiene ordenes activas, no se anula
					contadorSinAnular++;
				} else { //No tiene ordenes activas
					
					//3.Bloquear registro
					if(dbLockService.bloqueo(Campanya.class, campanyaCheck.getId())){
						//4.Insertar campanya
						campanyaInsert = new Campanya();
						campanyaInsert.setId(campanyaCheck.getId());
						campanyaInsert.setAuditData(campanyaCheck.getAuditData());
						campanyaInsert.setEstado(descripcionEstadoCampanya);
						campanyaInsert.setUltimaAccion(Constantes.CONSTANTE_NO);
						campanyaInsert.setIndicadorBloqueo(null);
						this.campanyaBo.insertarCampanya(campanyaInsert, new Date());
						
						//5.Insertar evento
						this.campanyaBo.insertarEvento(EVENTO_PV_ANULACION_CAMPANYA, campanyaInsert, campanyaInsert.getId());
					
						//Desbloquear registro
						dbLockService.desbloqueo(Campanya.class, campanyaCheck.getId());
						
						//Recargamos
						campanyaBo.recargar(campanyaInsert);
						contadorAnuladas++;
					
					} else {
						statusMessages.addFromResourceBundle(Severity.WARN, "errores.registro.bloqueado", campanyaCheck.getId());
					}
				}
			}
		}
		
		if(contadorAnuladas == 0){
			statusMessages.add(Severity.ERROR,"#{messages['campanyas.error.ningunaanulada']}");
		} else {
			statusMessages.addFromResourceBundle(Severity.INFO,"campanyas.mensaje.campanyasanuladas",contadorAnuladas);
			if(contadorSinAnular != 0){
				statusMessages.addFromResourceBundle(Severity.INFO,"campanyas.mensaje.campanyasnoanuladas",contadorSinAnular);
			}
		}
		
		this.refrescarPantalla();
	}
	
	/**
	 * El sistema valida las campañas seleccionadas si cumplen todas las condiciones necesarias
	 * para ello y refresca la lista de campañas, manteniendo el método de búsqueda usado inicialmente
	 */
	public void validar(){
		
		int contadorValidadas = 0;
		int contadorSinValidar = 0;
		Campanya campanyaInsert;
		DescripcionEstadoCampanya descripcionEstadoCampanya = new DescripcionEstadoCampanya();
		
		for (Campanya campanyaCheck : this.campanyasPantalla.getSelectedCampanyaDataList()) {
			
			if(!GenericUtils.isNullOrBlank(campanyaCheck.getEstado())
					&& Constantes.CAMPANYA_ESTADO_PV.equalsIgnoreCase(campanyaCheck.getEstado().getCodigo())){
				
				if(esPosibleValidar(campanyaCheck)){
					
					if(Constantes.CONSTANTE_NO.equalsIgnoreCase(campanyaCheck.getUltimaAccion())){
						descripcionEstadoCampanya.setCodigo(Constantes.CAMPANYA_ESTADO_AN);
					} else {
						descripcionEstadoCampanya.setCodigo(Constantes.CAMPANYA_ESTADO_VA);
					}
					
					//Bloquear registro
					if(dbLockService.bloqueo(Campanya.class, campanyaCheck.getId())){
						//Insertar campanya
						campanyaInsert = new Campanya();
						campanyaInsert.setId(campanyaCheck.getId());
						campanyaInsert.setAuditData(campanyaCheck.getAuditData());
						campanyaInsert.setEstado(descripcionEstadoCampanya);
						campanyaInsert.setUltimaAccion(campanyaCheck.getUltimaAccion());
						campanyaInsert.setIndicadorBloqueo(null);
						this.campanyaBo.insertarCampanya(campanyaInsert, new Date());
						
						//Desbloquear registro
						dbLockService.desbloqueo(Campanya.class, campanyaCheck.getId());
						
						//Recargamos
						this.campanyaBo.recargar(campanyaInsert);
						contadorValidadas++;
					} else {
						statusMessages.addFromResourceBundle(Severity.WARN, "errores.registro.bloqueado", campanyaCheck.getId());
					}
					
				}
				
			} else {
				contadorSinValidar++;
			}
		}
		
		if(contadorValidadas == 0){
			statusMessages.add(Severity.ERROR,"#{messages['campanyas.error.ningunavalidada']}");
		} else {
			statusMessages.addFromResourceBundle(Severity.INFO,"campanyas.mensaje.campanyasvalidadas",contadorValidadas);
			if(contadorSinValidar != 0){
				statusMessages.addFromResourceBundle(Severity.INFO,"campanyas.mensaje.campanyasnovalidadas",contadorSinValidar);
			}
		}
		
		this.refrescarPantalla();
	}
	
	/**
	 * Se obtiene la lista de todas las operaciones modelo de la campaña
	 * Si todas las operaciones tenían estado ‘VA’, devuelve TRUE, si no FALSE
	 */
	public boolean esPosibleValidar(Campanya camp){
		
		boolean validable = true;
		
		List<OperacionModelo> listaOper = campanyaBo.obtenerOperacionesModeloNoVA(camp, null);
		List<OperacionModelo> listaOperTodas = campanyaBo.obtenerOperacionesModelo(camp, null);
		
		if (!GenericUtils.isNullOrBlank(listaOper) && !listaOper.isEmpty()) {
			Iterator<OperacionModelo> iter = listaOper.iterator();
			OperacionModelo oper;
			while (validable && iter.hasNext()) {
				// Solo con que una operacion no sea VA debemos salir
				oper = iter.next();
				statusMessages.addFromResourceBundle(Severity.ERROR,"campanyas.error.noesposiblevalidar",camp.getId());
				validable = false;
			}
		} else {
			if (!GenericUtils.isNullOrBlank(listaOperTodas) && !listaOperTodas.isEmpty()) 
				validable = true;
			else 
				validable = false;
		}
		
		return validable;
	}
	
	/**
	 * Refresca la pantalla despues de anular, validar, bloquear/desbloquear
	 */
	private void refrescarPantalla(){
		
		// Limpiamos paginación, checkbox, botones y refrescamos la lista de campañas
		paginationData.reset();
		
		if (!GenericUtils.isNullOrBlank(this.campanyasPantalla.getSelectedCampanyaDataList())){
			this.campanyasPantalla.getSelectedCampanyaDataList().clear();
		}
		
		habilitarDeshabilitarBotones();
		this.campanyasList.clear(); //Limpiamos el datamodel
		
		if(this.campanyasPantalla.isVieneAgenda()){
			this.refrescarListaAgenda(this.campanyasPantalla.getEventoAgenda(),this.campanyasPantalla.getEstadoEvento());
		} else {
			this.refrescarLista();
		}
	}
	
	/**
	 * Función para bloquear y desbloquear campañas
	 */
	public void bloquearDesbloquear(){
		
		if (!Constantes.CONSTANTE_SI.equalsIgnoreCase(campanyaSelec.getIndicadorBloqueo())){
			//Bloqueamos la campaña
			if(dbLockService.bloqueo(Campanya.class, campanyaSelec.getId())){
				
				//Insertamos la campaña
				Campanya campanyaInsert = new Campanya();
				DescripcionEstadoCampanya descripcionEstadoCampanya = new DescripcionEstadoCampanya();
				descripcionEstadoCampanya.setCodigo(Constantes.CAMPANYA_ESTADO_VA);
				campanyaInsert.setId(campanyaSelec.getId());
				campanyaInsert.setAuditData(campanyaSelec.getAuditData());
				campanyaInsert.setEstado(descripcionEstadoCampanya);
				campanyaInsert.setUltimaAccion(campanyaSelec.getUltimaAccion());
				campanyaInsert.setIndicadorBloqueo(Constantes.CONSTANTE_SI);
				this.campanyaBo.insertarCampanya(campanyaInsert, new Date());
				
				//Insertamos evento 5009
				SimpleDateFormat sdf = new SimpleDateFormat(Constantes.SISTEMA_BLOQUEO_DATEFORMAT);
				StringBuilder datosgen = new StringBuilder(campanyaInsert.getId());
				datosgen.append(" ");
				datosgen.append(sdf.format(new Date()));
				this.campanyaBo.insertarEvento(EVENTO_CAMPANYA_BLOQUEADA, campanyaInsert, datosgen.toString());
				
				//Desbloquear el registro
				dbLockService.desbloqueo(Campanya.class, campanyaSelec.getId());
				//Recargamos
				this.campanyaBo.recargar(campanyaInsert);
				
			} else {
				statusMessages.addFromResourceBundle(Severity.WARN, "errores.registro.bloqueado",
						campanyaSelec.getId());
			}

		} else {
			//Desbloqueamos la campaña
			
			//Bloquear el registro de la tabla campaña
			if(dbLockService.bloqueo(Campanya.class, campanyaSelec.getId())){
				
				//Insertamos la campaña
				Campanya campanyaInsert = new Campanya();
				DescripcionEstadoCampanya descripcionEstadoCampanya = new DescripcionEstadoCampanya();
				descripcionEstadoCampanya.setCodigo(Constantes.CAMPANYA_ESTADO_VA);
				campanyaInsert.setId(campanyaSelec.getId());
				campanyaInsert.setAuditData(campanyaSelec.getAuditData());
				campanyaInsert.setEstado(descripcionEstadoCampanya);
				campanyaInsert.setUltimaAccion(null);
				campanyaInsert.setIndicadorBloqueo(Constantes.CONSTANTE_NO);
				this.campanyaBo.insertarCampanya(campanyaInsert, new Date());
				
				//Desbloquear el registro
				dbLockService.desbloqueo(Campanya.class, campanyaSelec.getId());
				//Recargamos
				this.campanyaBo.recargar(campanyaInsert);
				
			} else {
				statusMessages.addFromResourceBundle(Severity.WARN, "errores.registro.bloqueado",
						campanyaSelec.getId());
			}
		}
		
		this.refrescarPantalla();
	}
	
	// ### FIN ACCIONES DE LA PANTALLA ###
	
	// ### FUNCIONES PARA GESTIONAR LA VISIBILIDAD DE LOS DISTINTOS BOTONES/ICONOS DE PANTALLA ###
	
	/**
	 * Para una campaña del grid, comprueba si debe mostrarse o no el
	 * botón de Operaciones Modelo.
	 * @param camp: Campaña del grid
	 * @return: true si debe mostrarse, false en caso contrario
	 */
	public boolean isMostrarOperacionesModelo(Campanya camp){
		
		boolean mostrar = true;
		List<String> estadosPosibles = Arrays.asList(Constantes.CAMPANYA_ESTADO_PV, Constantes.CAMPANYA_ESTADO_AN, Constantes.CAMPANYA_ESTADO_VA, Constantes.CAMPANYA_ESTADO_FI, Constantes.CAMPANYA_ESTADO_VE);  
		
		if(!GenericUtils.isNullOrBlank(camp.getEstado())){
			
			String estado = camp.getEstado().getCodigo();
			
			if(GenericUtils.isNullOrBlank(estado) || !estadosPosibles.contains(estado)){
				mostrar = false;
			}
			
		} else {
			mostrar = false;
		}
		
		return mostrar;
	}
	
	public boolean isMostrarOperaciones(Campanya camp){
		boolean mostrar = true;
		
		if(!campanyaBo.comprobarOperacionesCampanya(camp)){
			mostrar = false;
		}
		
		return mostrar;
	}
	
	
	/**
	 * Para una campaña del grid, comprueba si debe mostrarse o no el
	 * botón de Bloquear/Desbloquear
	 * @param camp: Campaña del grid
	 * @return: true si debe mostrarse, false en caso contrario
	 */
	public boolean isMostrarBloquear(Campanya camp){
		
		boolean mostrar = true;
			
		String estado = Constantes.CADENA_VACIA;
		
		if(!GenericUtils.isNullOrBlank(camp.getEstado())){
			estado = camp.getEstado().getCodigo();
		}
		
		boolean estadoVA = Constantes.CAMPANYA_ESTADO_VA.equalsIgnoreCase(estado);
		boolean fechaOk = compruebaFechas(camp);
		
		if(!(estadoVA && fechaOk)){
			
			if(!(Constantes.CONSTANTE_SI.equalsIgnoreCase(camp.getIndicadorBloqueo()))){
				mostrar = false;
			}
		}
		
		return mostrar;
	}
	
	public boolean isMostrarOrdenes(Campanya camp){
		
		boolean mostrar = true;
		
		if(!campanyaBo.comprobarOrdenesCampanya(camp)){
			mostrar = false;
		}
		
		return mostrar;
	}
	
	/**
	 * Para una campaña del grid, comprueba si debe mostrarse o no el
	 * botón de Modificar
	 * El botón Modificar sólo se habilitará si: Campanya.TipoCampanya no está informado 
	 * o es 'L' ó (es 'D' y no tiene órdenes activas (método ComprobarOrdenesActivas = FALSE)) 
	 * y Campanya.Estado es 'IN' ó 'PV' 
	 * ó (es 'VA' y Campanya.InicioComercializacion <= Fecha Sistema y Campanya.FinComercializacion >= Fecha Sistema)
	 * @param camp: Campaña del grid
	 * @return: true si debe mostrarse, false en caso contrario
	 */
	public boolean isMostrarModificar(Campanya camp){
		
		boolean mostrar = false;
		
		if ((GenericUtils.isNullOrBlank(camp.getTipoCampanya())
				|| "-1".equalsIgnoreCase(camp.getTipoCampanya())
				|| "L".equalsIgnoreCase(camp.getTipoCampanya()) 
				|| ("D".equalsIgnoreCase(camp.getTipoCampanya()) 
						&& !campanyaBo.comprobarOrdenesActivas(camp)))
				&& ("IN".equalsIgnoreCase(camp.getEstado().getCodigo())
						|| Constantes.CAMPANYA_ESTADO_PV.equalsIgnoreCase(camp.getEstado().getCodigo()) 
						|| (Constantes.CAMPANYA_ESTADO_VA.equalsIgnoreCase(camp.getEstado().getCodigo()) 
								&& compruebaFechas(camp)))) {
			mostrar = true;
		}
		
		return mostrar;
	}
	
	/**
	 * Para una campaña del grid, comprueba si debe mostrarse o no el
	 * botón de Reclasif. Contable
	 * El botón Reclasif. Contable sólo se activará si campanya.Estado es ‘VA’ 
	 * y Campanya.ModeloCampanya es diferente de 'DD000002'
	 * @param camp: Campaña del grid
	 * @return: true si debe mostrarse, false en caso contrario
	 */
	public boolean isMostrarReclasificar(Campanya camp){
		
		boolean mostrar = false;

		if(!GenericUtils.isNullOrBlank(camp.getEstado()) && !GenericUtils.isNullOrBlank(camp.getModeloCampanya())){
			if(Constantes.CAMPANYA_ESTADO_VA.equalsIgnoreCase(camp.getEstado().getCodigo()) 
					&& !("DD000002".equalsIgnoreCase(camp.getModeloCampanya().getCodigo()))){
				mostrar = true;
			}
		}

		return mostrar;
	}
	
	public void salir(){
		Conversation conversacion = Conversation.instance();
		//Volvemos a la anterior conversación
		if(conversacion.isNested()){
			conversacion.redirectToParent();
		} else {
			redirectToURL("/home.seam");
			conversacion.endAndRedirect();
		}
	}
	
	/**
	 * Habilita o deshabilita los botones validar y anular
	 */
	private void habilitarDeshabilitarBotones(){
		//Por defecto desactivamos los dos botones
		this.campanyasPantalla.setMostrarAnular(false);
		this.campanyasPantalla.setMostrarValidar(false);
		
		/*Si alguna de las campañas seleccionadas cumple las condiciones, se habilita
		* el botón, independientemente de que se hayan seleccionado otras campañas que
		* no las cumplan (eso se controlará en un paso posterior del proceso)*/
		for (Campanya camp : this.campanyasPantalla.getSelectedCampanyaDataList()) {
			if(GenericUtils.isNullOrBlank(camp.getTipoCampanya()) || "L".equalsIgnoreCase(camp.getTipoCampanya())){
				if((!GenericUtils.isNullOrBlank(camp.getEstado()) && Constantes.CAMPANYA_ESTADO_VA.equalsIgnoreCase(camp.getEstado().getCodigo())) && compruebaFechas(camp)){
					this.campanyasPantalla.setMostrarAnular(true);
					break;
				}
			}
		}
		
		for (Campanya camp : this.campanyasPantalla.getSelectedCampanyaDataList()) {
			if(!GenericUtils.isNullOrBlank(camp.getEstado()) && Constantes.CAMPANYA_ESTADO_PV.equalsIgnoreCase(camp.getEstado().getCodigo())){
				this.campanyasPantalla.setMostrarValidar(true);
				break;
			}
		}
	}
	
	/**
	 * Comprueba que la fecha del sistema esté dentro del rango de la fecha
	 * de inicio y la fecha de fin de comercialización de la campanya
	 * @param camp: campaña para la q se comprueban las fechas
	 * @return true si la fecha está en rango
	 */
	private boolean compruebaFechas(Campanya camp){
		
		boolean fechasOk;
		
		Date fechaSistema = campanyaBo.obtenerFechaSistema();
		Date fechaIni = camp.getInicioComercializacion();
		Date fechafin = camp.getFinComercializacion();
		
		if(!GenericUtils.isNullOrBlank(fechaIni) && !GenericUtils.isNullOrBlank(fechafin)){
			long difFechaIniSist = (fechaIni.getTime() - fechaSistema.getTime())/86400000L;
			long difFechaFinSist = (fechafin.getTime() - fechaSistema.getTime())/86400000L;
			fechasOk = (difFechaIniSist <= 0 && difFechaFinSist >=0);
		} else {
			fechasOk = false;
		}
		
		return fechasOk;
	}

	public List<Campanya> getCampanyasList() {
		return campanyasList;
	}

	public void setCampanyasList(List<Campanya> campanyasList) {
		this.campanyasList = campanyasList;
	}
	
	// ### FIN VISIBILIDAD BOTONES/ICONOS DE PANTALLA

}
