package com.atosorigin.deri.gestioncampanyas.action;

import java.math.BigDecimal;
import java.util.Date;

import org.jboss.seam.ScopeType;
import org.jboss.seam.annotations.In;
import org.jboss.seam.annotations.Name;
import org.jboss.seam.annotations.Out;
import org.jboss.seam.annotations.Scope;
import org.jboss.seam.core.Conversation;
import org.jboss.seam.international.StatusMessage.Severity;
import org.jboss.seam.security.Identity;

import com.atosorigin.common.action.GenericAction;
import com.atosorigin.common.action.ModoPantalla;
import com.atosorigin.common.auditdata.AuditData;
import com.atosorigin.common.constantes.Constantes;
import com.atosorigin.common.formvalidator.FormValidator;
import com.atosorigin.common.utils.GenericUtils;
import com.atosorigin.deri.common.parametrosPantalla.ParametrosMantoper;
import com.atosorigin.deri.gestioncampanyas.campanya.business.CampanyaBo;
import com.atosorigin.deri.gestioncampanyas.screen.MantCampanyasPantalla;
import com.atosorigin.deri.model.gestioncampanyas.Campanya;
import com.atosorigin.deri.model.gestioncampanyas.DescripcionEstadoCampanya;
import com.atosorigin.deri.util.FormatUtil;

/**
 * Clase action listener para el caso de uso de mantenimiento campañas.
 */
@Name("mantCampanyasAction")
@Scope(ScopeType.CONVERSATION)
@FormValidator
public class MantCampanyasAction extends GenericAction {

	
	/**
	 * Inyección del screen bean que contiene los datos de pantalla del caso de
	 * uso Mantenimiento de campañas
	 */
	@In(create = true)
	protected MantCampanyasPantalla mantCampanyasPantalla;
	
	@In(value="formatUtil")
	private FormatUtil formatUtil;

	@In(value = "#{campanyaBo}")
	protected CampanyaBo campanyaBo;
	
	protected Date fechasistema;  

	protected String origen;	
	
	protected String opcion=null;
	
	protected String cocampa=null;
	
	protected Date fechaAct;

	protected String usuario = null;
	
	@In(required=false, value="campanyaEdit")
	private Campanya campanyaSelec;
	
	@Out(required = false, value="parametrosMantOper") //Parametros para MantOper
	private ParametrosMantoper parametrosMantOper;
	

	/**Realiza la carga de datos al entrar en la pantalla en modo Alta
	 * 
	 * @param id id de la campanña
	 * @param fecha de última actualización de la campaña
	 * @return navegación
	 */
	public void alta(){
		mantCampanyasPantalla.setFechadia(new Date());
		origen=Constantes.ORIGEN_ALTA;
		mantCampanyasPantalla.setEsDetalle(false);
		//Carga de datos por defecto
		setModoPantalla(ModoPantalla.CREACION);
		opcion = Constantes.MANT_CAMPANYAS_ALTA;
		mantCampanyasPantalla.setSusVigentes(Constantes.ALTA_CAMPANYA_SUS_VIGENTES_NO);
		cocampa = null;
		fechaAct= null;
		
		DescripcionEstadoCampanya descripcionEstadoCampanya = campanyaBo.obtenerDescripcionEstadoPorId("IN");
		Campanya campanya = new Campanya();
		campanya.setEstado(descripcionEstadoCampanya);
		campanya.setOficinaAltaCampanya(Constantes.ALTA_CAMPANYA_OFICINA);
		campanya.setDepartCorreoPostalInterno(Constantes.ALTA_CAMPANYA_CORREO_POSTAL_INTERNO);
		campanya.setFechaAlta(getFechasistema());
		AuditData auditData = new AuditData();
		auditData.setUsuarioUltimaModi(Identity.instance().getCredentials().getUsername());
		fechaAct= mantCampanyasPantalla.getFechadia();
		auditData.setFechaUltimaModi(fechaAct);
		campanya.setAuditData(auditData);
		mantCampanyasPantalla.setCampanya(campanya);

		//Activar botones
		mantCampanyasPantalla.setBtnAltaCompletaDisabled(false);
		mantCampanyasPantalla.setBtnAltaIncompletaDisabled(false);
		mantCampanyasPantalla.setBtnAsignarOpsModeloDisabled(false);
		mantCampanyasPantalla.setBtnOpCoberturaDisabled(false);
		mantCampanyasPantalla.setBtnGuardarDisabled(true);
		
		if (GenericUtils.isNullOrBlank(mantCampanyasPantalla.getCampanya().getClaveCampanya())){
			mantCampanyasPantalla.setBtnCalculoClaveDisabled(false);
		}else{
			mantCampanyasPantalla.setBtnCalculoClaveDisabled(true);
		}
		if (campanyaBo.noHayOperacionModelo(campanya)){
			mantCampanyasPantalla.setBtnConsultarOpsModeloDisabled(true);
		}else{
			mantCampanyasPantalla.setBtnConsultarOpsModeloDisabled(false);
		}
	}
	
	/**
	 * Realiza las validaciones previas a la edición de una campaña
	 * @return TRUE si se pasan las validaciones, false en caso contrario
	 */
	public boolean modificarValidator() {
		boolean esCorrecto = true;
		if(Constantes.CAMPANYA_ESTADO_VA.equalsIgnoreCase(this.campanyaSelec.getEstado().getCodigo()) 
				&& compruebaFechas(this.campanyaSelec)
				&& Constantes.CONSTANTE_NO.equalsIgnoreCase(this.campanyaSelec.getIndicadorBloqueo())){
			
			esCorrecto = false;
			statusMessages.add(Severity.ERROR, "#{messages['campanyas.error.campanyanobloqueada']}");
		}
		return esCorrecto;
	}
	
	
	
	
	
	public void asignarImportesPantalla(){
		if(!GenericUtils.isNullOrBlank( mantCampanyasPantalla.getCampanya().getNominalCampanya())){
			mantCampanyasPantalla.setNomninal(mantCampanyasPantalla.getCampanya().getNominalCampanya().toString());
		}
		if(!GenericUtils.isNullOrBlank( mantCampanyasPantalla.getCampanya().getImporteMinimoOrden() )){
			mantCampanyasPantalla.setImporteMinimo(mantCampanyasPantalla.getCampanya().getImporteMinimoOrden().toString());
		}
		if(!GenericUtils.isNullOrBlank( mantCampanyasPantalla.getCampanya().getImporteMaximoOrden()  )){
			mantCampanyasPantalla.setImporteMaximo(mantCampanyasPantalla.getCampanya().getImporteMaximoOrden().toString());
		}
		if(!GenericUtils.isNullOrBlank( mantCampanyasPantalla.getCampanya().getMultiplicador()  )){
			mantCampanyasPantalla.setMultiplo(mantCampanyasPantalla.getCampanya().getMultiplicador().toString());
		}
		if(!GenericUtils.isNullOrBlank( mantCampanyasPantalla.getCampanya().getPorcentajePrima()  )){
			mantCampanyasPantalla.setPorcentajePrima(mantCampanyasPantalla.getCampanya().getPorcentajePrima().toString());
		}
		if(!GenericUtils.isNullOrBlank( mantCampanyasPantalla.getCampanya().getImportePrima() )){
			mantCampanyasPantalla.setImportePrima(mantCampanyasPantalla.getCampanya().getImportePrima().toString());
		}
		if(!GenericUtils.isNullOrBlank( mantCampanyasPantalla.getCampanya().getMargenCampanya() )){
			mantCampanyasPantalla.setMargenCampanya(mantCampanyasPantalla.getCampanya().getMargenCampanya().toString());
		}
		if(!GenericUtils.isNullOrBlank( mantCampanyasPantalla.getCampanya().getPorcentajeMargenCampanya()  )){
			mantCampanyasPantalla.setPorcentajeMargenCampanya(mantCampanyasPantalla.getCampanya().getPorcentajeMargenCampanya().toString());
		}
		if(!GenericUtils.isNullOrBlank( mantCampanyasPantalla.getCampanya().getImportePrima()  )){
			mantCampanyasPantalla.setImportePrima(mantCampanyasPantalla.getCampanya().getImportePrima().toString());
		}
		if(!GenericUtils.isNullOrBlank( mantCampanyasPantalla.getCampanya().getPorcentajeRiesgo()  )){
			mantCampanyasPantalla.setPorcentajeRiesgo(mantCampanyasPantalla.getCampanya().getPorcentajeRiesgo().toString());
		}
		if(!GenericUtils.isNullOrBlank( mantCampanyasPantalla.getCampanya().getDisponibleOrdenesPV()  )){
			mantCampanyasPantalla.setDisponible(mantCampanyasPantalla.getCampanya().getDisponibleOrdenesPV().toString());
		}
	}
	
	/**Realiza la carga de datos al entrar en la pantalla en modo modificacion
	 * 
	 * @param id id de la campanña
	 * @param fecha de ultima actualizacion de la campaña
	 * @return navegación
	 */
	public String modificar(){
		origen=Constantes.ORIGEN_MODIFICACION;
		mantCampanyasPantalla.setEsDetalle(false);
		opcion=Constantes.MANT_CAMPANYAS_MODIFICACION;
		mantCampanyasPantalla.setFechadia(new Date());
		cocampa = campanyaSelec.getId();
		fechaAct = campanyaSelec.getAuditData().getFechaUltimaModi();
		mantCampanyasPantalla.setNominalCampanyaAnterior(campanyaSelec.getNominalCampanya());
		campanyaBo.prepararModificacionCampanya( campanyaSelec ,mantCampanyasPantalla.getFechadia());
				
		if (campanyaBo.comprobarOrdenesActivas(campanyaSelec)){
			mantCampanyasPantalla.setSusVigentes(Constantes.ALTA_CAMPANYA_SUS_VIGENTES_SI);
		}else{
			mantCampanyasPantalla.setSusVigentes(Constantes.ALTA_CAMPANYA_SUS_VIGENTES_NO);
		}
		mantCampanyasPantalla.setCampanya(campanyaSelec);		
		
		if (Constantes.TIPO_CAMPANYA_DISTRIBUIDA.equals(mantCampanyasPantalla.getCampanya().getTipoCampanya())){
			setModoPantalla(ModoPantalla.INSPECCION);
			mantCampanyasPantalla.setBtnAltaCompletaDisabled(true);
			mantCampanyasPantalla.setBtnAltaIncompletaDisabled(true);
			mantCampanyasPantalla.setBtnOpCoberturaDisabled(true);
			mantCampanyasPantalla.setBtnCalculoClaveDisabled(true);
			mantCampanyasPantalla.setBtnGuardarDisabled(false);
			if("N".equals(mantCampanyasPantalla.getSusVigentes())){
				if(campanyaBo.mensajeSinOperacionModelo(mantCampanyasPantalla.getCampanya())){
					mantCampanyasPantalla.setBtnAsignarOpsModeloDisabled(false);
				}else{
					mantCampanyasPantalla.setBtnAsignarOpsModeloDisabled(true);
				}
			}
			if(Constantes.ALTA_CAMPANYA_SUS_VIGENTES_SI.equals(mantCampanyasPantalla.getSusVigentes())){
				mantCampanyasPantalla.setBtnAsignarOpsModeloDisabled(true);
			}
		}else{
			if(GenericUtils.isNullOrBlank(mantCampanyasPantalla.getCampanya().getClaveCampanya()) ){
				mantCampanyasPantalla.setBtnCalculoClaveDisabled(false);
			}else{
				mantCampanyasPantalla.setBtnCalculoClaveDisabled(true);
			}
			
			if(Constantes.TIPO_COBERTURA_SI.equals(mantCampanyasPantalla.getCampanya().getIndOperacionesCobertura()) 
					|| Constantes.TIPO_COBERTURA_PARCIAL.equals(mantCampanyasPantalla.getCampanya().getIndOperacionesCobertura())
					|| GenericUtils.isNullOrBlank(mantCampanyasPantalla.getCampanya().getIndOperacionesCobertura())){
				mantCampanyasPantalla.setBtnOpCoberturaDisabled(false);
			}else{
				mantCampanyasPantalla.setBtnOpCoberturaDisabled(true);
			}
			if(Constantes.TIPO_ESTADO_IN.equals(mantCampanyasPantalla.getCampanya().getEstado().getCodigo())){
				mantCampanyasPantalla.setBtnAltaCompletaDisabled(false);
				mantCampanyasPantalla.setBtnAltaIncompletaDisabled(false);
				mantCampanyasPantalla.setBtnAsignarOpsModeloDisabled(false);
				
				mantCampanyasPantalla.setBtnGuardarDisabled(true);
			}else{
				mantCampanyasPantalla.setBtnAltaCompletaDisabled(true);
				mantCampanyasPantalla.setBtnAltaIncompletaDisabled(true);
				mantCampanyasPantalla.setBtnGuardarDisabled(false);
				//FLM: comparamos siempre con codigo
				//     el campo de fecha es opcional
				long tempo=0;
				if  (mantCampanyasPantalla.getCampanya().getInicioComercializacion() != null  )
					tempo=mantCampanyasPantalla.getCampanya().getInicioComercializacion().getTime();
				
				if(Constantes.TIPO_ESTADO_PV.equals(mantCampanyasPantalla.getCampanya().getEstado().getCodigo()  ) ||  tempo  > new Date().getTime()){
					mantCampanyasPantalla.setBtnAsignarOpsModeloDisabled(false);
				}else{
					mantCampanyasPantalla.setBtnAsignarOpsModeloDisabled(true);
				}
			}
			
			if(Constantes.ALTA_CAMPANYA_SUS_VIGENTES_NO.equals(mantCampanyasPantalla)){
				setModoPantalla(ModoPantalla.EDICION);
				mantCampanyasPantalla.setInpIdDisabled(true);
			}
			if(Constantes.ALTA_CAMPANYA_SUS_VIGENTES_SI.equals(mantCampanyasPantalla)){
				setModoPantalla(ModoPantalla.EDICION);
				mantCampanyasPantalla.setInpIdDisabled(false);
				mantCampanyasPantalla.setInpFinComercializacionDisabled(false);
				mantCampanyasPantalla.setInpNominalCampanyaDisabled(false);
				mantCampanyasPantalla.setInpPorcentajeMargenCampanyaDisabled(false);
				mantCampanyasPantalla.setInpIndicadorPrimaDisabled(false);
				mantCampanyasPantalla.setInpImporteMinimoOrdenDisabled(false);
				mantCampanyasPantalla.setInpImporteMaximoOrdenDisabled(false);
				mantCampanyasPantalla.setInpMultiplicadorDisabled(false);
				if(GenericUtils.isNullOrBlank(mantCampanyasPantalla.getCampanya().getIndicadorPrima())){
					mantCampanyasPantalla.setInpPorcentajePrimaDisabled(true);
					mantCampanyasPantalla.setInpImportePrimaDisabled(true);
				}else{
					if(Constantes.TIPO_PRIMA_FIJA.equals(mantCampanyasPantalla.getCampanya().getIndicadorPrima())){
						mantCampanyasPantalla.setInpPorcentajePrimaDisabled(true);
						mantCampanyasPantalla.setInpImportePrimaDisabled(false);
					}else{
						mantCampanyasPantalla.setInpPorcentajePrimaDisabled(false);
						mantCampanyasPantalla.setInpImportePrimaDisabled(true);
					}
				}
				if (Constantes.TIPO_MODELO_DD000002.equals(mantCampanyasPantalla.getCampanya().getModeloCampanya())){
					mantCampanyasPantalla.setInpGrupoContableDespuesValorDisabled(true);
				}else{
					mantCampanyasPantalla.setInpGrupoContableDespuesValorDisabled(false);
				}
			}
			
			
		}
		mantCampanyasPantalla.getCampanya().getAuditData().setFechaUltimaModi(mantCampanyasPantalla.getFechadia());
		if (campanyaBo.noHayOperacionModelo(mantCampanyasPantalla.getCampanya())){
			mantCampanyasPantalla.setBtnConsultarOpsModeloDisabled(true);
		}else{
			mantCampanyasPantalla.setBtnConsultarOpsModeloDisabled(false);
		}
		asignarImportesPantalla();
		return Constantes.CONSTANTE_SUCCESS;
	}
	
	//FLM: Si tenemos codigo campañna debemos tener habilitados la botonera
	public void RecalcularBotones() {
		
		if (Constantes.ORIGEN_ALTA.equalsIgnoreCase(origen) && !validarId()){
			statusMessages.addFromResourceBundle(Severity.ERROR, "Campanya.error.CampanyaYaExiste",mantCampanyasPantalla.getCampanya().getId());
			mantCampanyasPantalla.setBtnAsignarOpsModeloDisabled(true);
			mantCampanyasPantalla.setBtnOpCoberturaDisabled(true);
			mantCampanyasPantalla.setBtnAltaCompletaDisabled(true);
			mantCampanyasPantalla.setBtnAltaIncompletaDisabled(true);
			mantCampanyasPantalla.setBtnCalculoClaveDisabled(true);
			return;
		}else{
			mantCampanyasPantalla.setBtnAsignarOpsModeloDisabled(false);
			mantCampanyasPantalla.setBtnOpCoberturaDisabled(false);
			mantCampanyasPantalla.setBtnAltaCompletaDisabled(false);
			mantCampanyasPantalla.setBtnAltaIncompletaDisabled(false);
			mantCampanyasPantalla.setBtnCalculoClaveDisabled(false);
		}
		
		int i = 0;
		try {
			i= mantCampanyasPantalla.getCampanya().getId().indexOf("_");			
		} finally {}
		// Si tenemos codigo pantalla podemos ir al siguiente sitio
		if (  i == -1 ) {
			mantCampanyasPantalla.setBtnAsignarOpsModeloDisabled(false);
			mantCampanyasPantalla.setBtnOpCoberturaDisabled(false);
		} else {
			mantCampanyasPantalla.setBtnAsignarOpsModeloDisabled(true);
			mantCampanyasPantalla.setBtnOpCoberturaDisabled(true);
		}
		// TODO, deshabilitar si tenemos operaciones modelo o cobertura ya informados		mantCampanyasPantalla
		
	}
	
	/**Realiza la carga de datos al entrar en la pantalla en modo consulta desde listado de campañas
	 * 
	 * @param id id de la campanña
	 * @param fecha de ultima actualizacion de la campaña
	 * @return navegación
	 */
	//public void consulta(String id, Date fecha){
	public void consulta(){
		origen=Constantes.ORIGEN_CONSULTA_LIST_COMAPANYAS;
		mantCampanyasPantalla.setEsDetalle(true);
		setModoPantalla(ModoPantalla.INSPECCION);
		opcion=Constantes.MANT_CAMPANYAS_CONSULATA;
		mantCampanyasPantalla.setSusVigentes(Constantes.ALTA_CAMPANYA_SUS_VIGENTES_NO);
	//	cocampa = mantCampanyasPantalla.getCampanya().getId();
	//	fechaAct = mantCampanyasPantalla.getCampanya().getAuditData().getFechaUltimaModi();
		
		mantCampanyasPantalla.setCampanya(campanyaSelec);
		
		activarBotonesConsulta();
		asignarImportesPantalla();
	}

	private void activarBotonesConsulta() {
		mantCampanyasPantalla.setBtnAltaCompletaDisabled(true);
		mantCampanyasPantalla.setBtnAltaIncompletaDisabled(true);
		mantCampanyasPantalla.setBtnAsignarOpsModeloDisabled(true);
		mantCampanyasPantalla.setBtnGuardarDisabled(true);
		mantCampanyasPantalla.setBtnCalculoClaveDisabled(true);
		if (Constantes.TIPO_COBERTURA_PARCIAL.equals(mantCampanyasPantalla.getCampanya().getIndOperacionesCobertura()) 
				|| Constantes.TIPO_COBERTURA_SI.equals(mantCampanyasPantalla.getCampanya().getIndOperacionesCobertura())){
			mantCampanyasPantalla.setBtnOpCoberturaDisabled(false);
		}else{
			mantCampanyasPantalla.setBtnOpCoberturaDisabled(true);
		}
		if (campanyaBo.noHayOperacionModelo(mantCampanyasPantalla.getCampanya())){
			mantCampanyasPantalla.setBtnConsultarOpsModeloDisabled(true);
		}else{
			mantCampanyasPantalla.setBtnConsultarOpsModeloDisabled(false);
		}
	}
	
	
	public void consultaDesdeSuscripciones(String id, String fecha){
		//SMM: inc 714
		origen=Constantes.ORIGEN_CONSULTA_MANTENIMIENTO_SUSCRIPCIONES;
		mantCampanyasPantalla.setEsDetalle(true);
		setModoPantalla(ModoPantalla.INSPECCION);
		opcion=Constantes.MANT_CAMPANYAS_CONSULATA;
		mantCampanyasPantalla.setSusVigentes(Constantes.ALTA_CAMPANYA_SUS_VIGENTES_NO);
	//	cocampa = mantCampanyasPantalla.getCampanya().getId();
	//	fechaAct = mantCampanyasPantalla.getCampanya().getAuditData().getFechaUltimaModi();
		
		mantCampanyasPantalla.setCampanya(campanyaBo.buscarDatosCampanya(id, formatUtil.getDate(Constantes.DDMMYYYYHHMMSS,fecha)));
		
		activarBotonesConsulta();
	}
	
	/**
	 * Habilita campos en funcion del estado de la prima
	 */
	public void cambiarEstadoPrima() {

		String prima = mantCampanyasPantalla.getCampanya().getIndicadorPrima();

		if (Constantes.MANT_CAMPANYAS_CAMPO_NO_INFORMADO.equals(prima)) {
			mantCampanyasPantalla.setPorcentajeDisabled(true);
			mantCampanyasPantalla.setImporteFijoDisabled(true);
		}
		if (Constantes.TIPO_PRIMA_FIJA.equals(prima)) {
			mantCampanyasPantalla.setPorcentajeDisabled(true);
			mantCampanyasPantalla.setImporteFijoDisabled(false);
		}
		if (Constantes.TIPO_PRIMA_PERIODICA.equals(prima)
				|| Constantes.TIPO_PRIMA_PORCENTAJE.equals(prima)) {
			mantCampanyasPantalla.setPorcentajeDisabled(false);
			mantCampanyasPantalla.setImporteFijoDisabled(true);
		}
	}
	
	/**
	 * Habilita campos en función del estado de la prima
	 * y asigna un valor al estilo de la campaña
	 * 
	 */
	public void cambiarModelo() {

		if(!GenericUtils.isNullOrBlank(mantCampanyasPantalla.getCampanya().getModeloCampanya())){
			if (Constantes.TIPO_MODELO_DD000001.equals(mantCampanyasPantalla
					.getCampanya().getModeloCampanya().getCodigo())) {
				mantCampanyasPantalla.getCampanya().setEstiloCampanya(Constantes.TIPO_ESTILO_MODELIZADA);
				mantCampanyasPantalla.setGrupoContableAntesValorDisabled(false);
				mantCampanyasPantalla.setGrupoContableDespuesValorDisabled(false);
			}
			if (Constantes.TIPO_MODELO_DD000002.equals(mantCampanyasPantalla
					.getCampanya().getModeloCampanya().getCodigo())) {
				mantCampanyasPantalla.getCampanya().setEstiloCampanya(Constantes.TIPO_ESTILO_CUSTOMIZADA);
				mantCampanyasPantalla.setGrupoContableAntesValorDisabled(true);
				mantCampanyasPantalla.setGrupoContableDespuesValorDisabled(true);
				mantCampanyasPantalla.getCampanya().setGrupoContableAntesValor("CA");
				mantCampanyasPantalla.getCampanya().setGrupoContableDespuesValor("CA");
			}
		}
	}
	
	
	/**
	 * Habilita campos en función del estilo de la campaña
	 * y asigna un valor a la descripcion de la campaña
	 * 
	 */
	public void cambiarEstadoEstilo() {

		if (Constantes.TIPO_ESTILO_MODELIZADA.equals(mantCampanyasPantalla.getCampanya().getEstiloCampanya())) {
			mantCampanyasPantalla.getCampanya().setModeloCampanya(campanyaBo.obtenerDescripcionModeloPorId(Constantes.TIPO_MODELO_DD000001));
			mantCampanyasPantalla.setGrupoContableAntesValorDisabled(false);
			mantCampanyasPantalla.setGrupoContableDespuesValorDisabled(false);
		} else {
			mantCampanyasPantalla.getCampanya().setModeloCampanya(campanyaBo.obtenerDescripcionModeloPorId(Constantes.TIPO_MODELO_DD000002));
			mantCampanyasPantalla.setGrupoContableAntesValorDisabled(true);
			mantCampanyasPantalla.setGrupoContableDespuesValorDisabled(true);
		}
		
		if (Constantes.TIPO_MODELO_DD000002.equals(mantCampanyasPantalla
				.getCampanya().getModeloCampanya().getCodigo())) {
			mantCampanyasPantalla.getCampanya().setGrupoContableAntesValor("CA");
			mantCampanyasPantalla.getCampanya().setGrupoContableDespuesValor("CA");
		}
	}

	
	/**
	 * Habilita asigna  valores a DisponibleOrdenes de la campaña 
	 */
	 public void cambiarNominal(){
		mantCampanyasPantalla.getCampanya().setNominalCampanya(convertirImporte(mantCampanyasPantalla.getNomninal()));
		if (Constantes.MANT_CAMPANYAS_ALTA.equals(opcion)) {
			if(GenericUtils.isNullOrBlank(mantCampanyasPantalla.getCampanya().getNominalCampanya())){
				mantCampanyasPantalla.setDisponible("");
			}else{
				mantCampanyasPantalla.setDisponible(mantCampanyasPantalla.getCampanya().getNominalCampanya().toString());
				mantCampanyasPantalla.getCampanya().setDisponibleOrdenesPV(mantCampanyasPantalla.getCampanya().getNominalCampanya());
				mantCampanyasPantalla.getCampanya().setDisponibleOrdenesVA(mantCampanyasPantalla.getCampanya().getNominalCampanya());
			}
		}
		if (Constantes.MANT_CAMPANYAS_MODIFICACION.equals(opcion)) {
			//FLM, si es null peta, por tanto si no tenemos nominal de antes lo suponemos a 0
			BigDecimal antes=mantCampanyasPantalla.getNominalCampanyaAnterior();
			if (antes == null)
				antes = new BigDecimal(0);
			if (mantCampanyasPantalla.getCampanya().getNominalCampanya().compareTo(antes) == 1) {
				BigDecimal ordenVA= mantCampanyasPantalla.getCampanya().getDisponibleOrdenesVA();
					if (ordenVA == null)
						ordenVA= new BigDecimal(0);
				mantCampanyasPantalla.getCampanya().setDisponibleOrdenesVA(ordenVA
							.add(mantCampanyasPantalla.getCampanya().getNominalCampanya()
								.subtract(antes)));
				mantCampanyasPantalla.setDisponible(mantCampanyasPantalla.getCampanya().getDisponibleOrdenesVA().toString());
				BigDecimal ordenPV= mantCampanyasPantalla.getCampanya().getDisponibleOrdenesPV();
				if (ordenPV == null)
					ordenPV= new BigDecimal(0);
				
				mantCampanyasPantalla.getCampanya().setDisponibleOrdenesPV(ordenPV
						  .add(mantCampanyasPantalla.getCampanya().getNominalCampanya()
								 .subtract(antes)));
			}
		}
	}
	
	 /**
	  * Si cambia la cobertura valida que tenga operaciones modelo
	  */
	public void cambiarCobertura(){
		if(Constantes.TIPO_COBERTURA_NO.equals(mantCampanyasPantalla.getCampanya().getIndOperacionesCobertura())){
			if (campanyaBo.noHayOperacionCobertura(mantCampanyasPantalla.getCampanya())){
				mantCampanyasPantalla.setBtnOpCoberturaDisabled(true);
			}else{
				mantCampanyasPantalla.getCampanya().setIndOperacionesCobertura(null);
				statusMessages.add(Severity.ERROR, "#{messages['Campanya.error.OpCoberturaAsignadas']}");
			}
		}else{
			mantCampanyasPantalla.setBtnOpCoberturaDisabled(false);
		}
	}
	
	
	public void asignarImportes(){
		mantCampanyasPantalla.getCampanya().setNominalCampanya(convertirImporte(mantCampanyasPantalla.getNomninal()));
		mantCampanyasPantalla.getCampanya().setImporteMinimoOrden(convertirImporte(mantCampanyasPantalla.getImporteMinimo()));
		mantCampanyasPantalla.getCampanya().setImporteMaximoOrden(convertirImporte(mantCampanyasPantalla.getImporteMaximo()));
		mantCampanyasPantalla.getCampanya().setMultiplicador(convertirImporte(mantCampanyasPantalla.getMultiplo()));
		mantCampanyasPantalla.getCampanya().setPorcentajePrima(convertirPorcentaje(mantCampanyasPantalla.getPorcentajePrima()));
		mantCampanyasPantalla.getCampanya().setImportePrima(convertirImporte(mantCampanyasPantalla.getImportePrima()));
		mantCampanyasPantalla.getCampanya().setMargenCampanya(convertirImporte(mantCampanyasPantalla.getMargenCampanya()));
		mantCampanyasPantalla.getCampanya().setPorcentajeMargenCampanya(convertirPorcentaje(mantCampanyasPantalla.getPorcentajeMargenCampanya()));
		mantCampanyasPantalla.getCampanya().setPorcentajeRiesgo(convertirPorcentaje(mantCampanyasPantalla.getPorcentajeRiesgo()));
	}
	
	public boolean altaIncompletaValidator(){
		
		boolean esCorrecto = true;
		
		if(mantCampanyasPantalla.getCampanya().getId().length() < 8){
			esCorrecto = false;
			statusMessages.addToControl("campanyaid", Severity.ERROR, "#{messages['Campanya.error.codigo.noinformado']}");
		}
		
		return esCorrecto;
	}
	
	
	/**
	 * Realiza un alta incompleta de la campaña.Solo es necesario el id.
	 */
	public String altaIncompleta(){
		asignarImportes();
		campanyaBo.altaCampanya(opcion, mantCampanyasPantalla.getCampanya());
		Conversation conversacion=Conversation.instance();
		if (conversacion.isNested()){
			conversacion.redirectToParent();
		}
		
		return Constantes.CONSTANTE_SUCCESS;
	}
	
	/**
	 * Realiza un alta completa de la campaña.
	 */
	public String altaCompleta(){
		if (!Constantes.ORIGEN_ALTA.equalsIgnoreCase(origen) || validarId()){
			if (validar()){
				campanyaBo.altaCompleta(mantCampanyasPantalla.getCampanya());
				Conversation conversacion=Conversation.instance();
				if (conversacion.isNested()){
					conversacion.redirectToParent();
				}
				
				return Constantes.CONSTANTE_SUCCESS;
			}
		}else{
			statusMessages.addFromResourceBundle(Severity.ERROR, "Campanya.error.CampanyaYaExiste",mantCampanyasPantalla.getCampanya().getId());
		}
		return "";
	}
	
	public boolean guardarCampanyaValidator(){
		
		return validar();
	}
	
	/**
	 * Guarda los cambios realizados cuado entra en modo modificación
	 * @return
	 */
	public String  guardarCampanya(){
			mantCampanyasPantalla.getCampanya().setNominalCampanya(convertirImporte(mantCampanyasPantalla.getNomninal()));
			mantCampanyasPantalla.getCampanya().getAuditData().setFechaUltimaModi(mantCampanyasPantalla.getFechadia());
			campanyaBo.guardarCampanya(mantCampanyasPantalla.getCampanya());
			return Constantes.CONSTANTE_SUCCESS;
	}

	
	public String consultarOpsModelo(){
		parametrosMantOper =  new ParametrosMantoper();
		parametrosMantOper.setModo("OPM");
		parametrosMantOper.setCodcampa(campanyaSelec.getId());
		
		return Constantes.CONSTANTE_SUCCESS;
	}
	
	
	/**
	 * Calcula la clave y se la asigna a la campña
	 */
	public void calculoClave(){
		mantCampanyasPantalla.getCampanya().setClaveCampanya(campanyaBo.calculoClave());
		mantCampanyasPantalla.setBtnCalculoClaveDisabled(true);
	}
	
	public String salirAltaModi(){
		if(Constantes.ORIGEN_ALTA.equals(origen)){
			return Constantes.ORIGEN_ALTA;
		}
		if(Constantes.ORIGEN_MODIFICACION.equals(origen)){
			return Constantes.ORIGEN_MODIFICACION;
		}
		return "";
	}
	
	public String salirDetalle(){
		if(Constantes.ORIGEN_CONSULTA_LIST_COMAPANYAS.equals(origen)){
			return Constantes.ORIGEN_CONSULTA_LIST_COMAPANYAS;
		}
		if(Constantes.ORIGEN_CONSULTA_MANTENIMIENTO_SUSCRIPCIONES.equals(origen)){
			return Constantes.ORIGEN_CONSULTA_MANTENIMIENTO_SUSCRIPCIONES;
		}
		return ""; 
	}
	
	public boolean validar(){
		asignarImportes();
		boolean retorno = true;
		if ("N".equals(mantCampanyasPantalla.getSusVigentes())){
			if (!validarCamposObligatorios()){
				retorno = false;
			}
			
			if (!validarFechasComercializacion()){
				retorno = false;
			}
			if (!validarNominal()){
				retorno = false;
			}
			if (!validarImporteMinimo()){
				retorno = false;	
			}
			if (!validarImporteMaximo()){
				retorno = false;
			}
			if (!validarMultiplicador()){
				retorno = false;
			}
			if (!validarMargen()){
				retorno = false;
			}
			if (!validarUnidadDeNegocio()){
				retorno = false;
			}
			if (!validarOficina()){
				retorno = false;
			}	
			if (!validarFolferK()){
				retorno = false;
			}		
			if (!validarModelo()){
				retorno = false;
			}
			if (!validarEntidad()){
				retorno = false;
			}
			

		}
		return retorno;

	}

	private boolean validarEntidad() {
		boolean retorno = true;
		if ( !(GenericUtils.isNullOrBlank(mantCampanyasPantalla.getCampanya().getEntidadCampanya())) 
				&& !campanyaBo.validarEntidad(mantCampanyasPantalla.getCampanya().getEntidadCampanya()) ){
			statusMessages.addToControl("txtEntidad",Severity.ERROR, "#{messages['Campanya.error.entidad.novalida']}");	
			retorno = false;
		}
		return retorno;
	}

	/**
	 * Primero se formateará el código de campaña para que quede en el siguiente formato:  
	 * ‘DEnnnnnn’ (donde n es un número):
	 * Si ya existe una campanya con el mismo código que el informado, se mostrará el mensaje de error
	 * 
	 * @return boolean
	 */
	public boolean validarId(){
		
		boolean retorno = true;
		if (!mantCampanyasPantalla.getCampanya().getId().substring(0, 2).equals("DE")){
			String id = GenericUtils.lpad(mantCampanyasPantalla.getCampanya().getId(),6,'0');
			if (id.length() > 6){
				id = id.substring(2, 8);
			}
			mantCampanyasPantalla.getCampanya().setId("DE" + id);
		}else{
			if(mantCampanyasPantalla.getCampanya().getId().length() <= 8){
				mantCampanyasPantalla.getCampanya().setId(mantCampanyasPantalla.getCampanya().getId().replace('_', ' '));
				mantCampanyasPantalla.getCampanya().setId(mantCampanyasPantalla.getCampanya().getId().trim());
				mantCampanyasPantalla.getCampanya().setId("DE" + GenericUtils.lpad(mantCampanyasPantalla.getCampanya().getId().substring(2, mantCampanyasPantalla.getCampanya().getId().length()), 6, '0'));
			}else{
				statusMessages.addToControl("campanyaid", Severity.ERROR,"#{messages['Campanya.error.ochocaracteres']}");
				retorno = false;
			}
		}
		if (!GenericUtils.isNullOrBlank(campanyaBo.buscarCampanayaPorId(mantCampanyasPantalla.getCampanya().getId()))){
			retorno = false;
		}
		return retorno;
	}
	
	public boolean validarFechasComercializacion(){
		boolean retorno = true;
		
		if (GenericUtils.isNullOrBlank(mantCampanyasPantalla.getCampanya().getInicioComercializacion())){
    		statusMessages.addToControl("txtIniComercializacion", Severity.ERROR,"#{messages['Campanya.error.FechaIniComObligatoria']}");
			retorno = false;
    	}
    	if (GenericUtils.isNullOrBlank(mantCampanyasPantalla.getCampanya().getFinComercializacion())){
    		statusMessages.addToControl("txtFinComercializacion", Severity.ERROR,"#{messages['Campanya.error.FechaFinComObligatoria']}");
			retorno = false;
    	}
    	if (GenericUtils.isNullOrBlank(mantCampanyasPantalla.getCampanya().getInicioCampanya())){
    		statusMessages.addToControl("txtIniCampanya", Severity.ERROR,"#{messages['Campanya.error.InicioCampanyaObligatorio']}");
			retorno = false;
    	}
    	if (GenericUtils.isNullOrBlank(mantCampanyasPantalla.getCampanya().getFechaVencimiento())){
    		statusMessages.addToControl("txtFechaVemcimiento", Severity.ERROR,"#{messages['Campanya.error.FechaVencimientoObligatoria']}");
			retorno = false;
    	}
    	if (retorno == true){
//    		Si OPCION = 'A' y campanya.InicioComercializacion < fechasistema se mostrará el mensaje de error Campanya.error.FechaIniComErronea
    		if (Constantes.MANT_CAMPANYAS_ALTA.equals(opcion) && getFechasistema().compareTo( mantCampanyasPantalla.getCampanya().getInicioComercializacion()) > 0){
    			statusMessages.addToControl("txtIniComercializacion",Severity.ERROR, "#{messages['campanya.error.fechaIniComErronea']}");	
    			retorno = false;
    		}
    		if (mantCampanyasPantalla.getCampanya().getFinComercializacion().compareTo(mantCampanyasPantalla.getCampanya().getInicioComercializacion()) <= 0 
    				|| getFechasistema().compareTo(mantCampanyasPantalla.getCampanya().getFinComercializacion()) > 0){
    			statusMessages.addToControl("txtFinComercializacion",Severity.ERROR, "#{messages['campanya.error.fechaFinComErronea']}");	
    			retorno = false;

    		}
    		if (mantCampanyasPantalla.getCampanya().getFechaVencimiento().compareTo(mantCampanyasPantalla.getCampanya().getInicioCampanya()) <= 0){
    			statusMessages.addToControl("txtFechaVemcimiento",Severity.ERROR, "#{messages['campanya.error.fechaVencimientoErronea']}");	
    			retorno = false;
    		}
    	}	
		

		return retorno;
				
	}
	
	public boolean validarNominal(){
		boolean retorno = true;
		if (GenericUtils.isNullOrBlank(mantCampanyasPantalla.getCampanya().getNominalCampanya())){
    		statusMessages.addToControl("txtNominalCampanya", Severity.ERROR,"#{messages['Campanya.error.NominalObligatorio']}");
			retorno = false;
    	}else{
    		if (BigDecimal.valueOf(0L).equals(mantCampanyasPantalla.getCampanya().getNominalCampanya())){
    			statusMessages.addToControl("txtNominalCampanya",Severity.ERROR, "#{messages['campanya.error.nominalCero']}");	
    			retorno = false;
    		}
    		if(!GenericUtils.isNullOrBlank(mantCampanyasPantalla.getNominalCampanyaAnterior())){
    			if (mantCampanyasPantalla.getCampanya().getNominalCampanya().compareTo(mantCampanyasPantalla.getNominalCampanyaAnterior()) < 0){
        			mantCampanyasPantalla.setNomninal(mantCampanyasPantalla.getNominalCampanyaAnterior().toString());
        			statusMessages.addToControl("txtNominalCampanya",Severity.ERROR, "#{messages['campanya.error.nominalDecrementado']}");	
        			retorno = false;
        		}
    		}
    		
    	}
		
		return retorno;
	}
	
	public boolean validarImporteMinimo(){
		boolean retorno = true;
		if (GenericUtils.isNullOrBlank(mantCampanyasPantalla.getCampanya().getImporteMinimoOrden())){
    		statusMessages.addToControl("txtImporteMinimo", Severity.ERROR,"#{messages['Campanya.error.ImporteMinimoObligatorio']}");
			retorno = false;
    	}else{
    		if (BigDecimal.valueOf(0L).equals(mantCampanyasPantalla.getCampanya().getImporteMinimoOrden())){
    			statusMessages.addToControl("txtImporteMinimo",Severity.ERROR, "#{messages['campanya.error.importeMinimoCero']}");	
    			retorno = false;
    		}
    	}
		return retorno;
	}
	
	public boolean validarImporteMaximo(){
		boolean retorno = true;
		if (GenericUtils.isNullOrBlank(mantCampanyasPantalla.getCampanya().getImporteMaximoOrden())){
    		statusMessages.addToControl("txtImporteMaximo", Severity.ERROR,"#{messages['Campanya.error.ImporteMaximoObligatorio']}");
			retorno = false;
    	}else if (!GenericUtils.isNullOrBlank(mantCampanyasPantalla.getCampanya().getImporteMinimoOrden()) && mantCampanyasPantalla.getCampanya().getImporteMaximoOrden().compareTo(mantCampanyasPantalla.getCampanya().getImporteMinimoOrden()) < 0){
			statusMessages.addToControl("txtImporteMaximo",Severity.ERROR, "#{messages['campanya.error.importeMaximoErroneo']}");	
			retorno = false;
			if(!GenericUtils.isNullOrBlank(mantCampanyasPantalla.getNominalCampanyaAnterior())){
				mantCampanyasPantalla.getCampanya().setNominalCampanya(mantCampanyasPantalla.getNominalCampanyaAnterior());
    		}
   		}
    	
		return retorno;
	}
	public boolean validarMultiplicador(){
		boolean retorno = true;
		if (GenericUtils.isNullOrBlank(mantCampanyasPantalla.getCampanya().getMultiplicador())){
    		statusMessages.addToControl("txtMultiplicador", Severity.ERROR,"#{messages['Campanya.error.MultiplicadorObligatorio']}");
			retorno = false;
    	}else{
    		if (mantCampanyasPantalla.getCampanya().getMultiplicador().equals(BigDecimal.valueOf(0L))){
    			statusMessages.addToControl("txtMultiplicador",Severity.ERROR, "#{messages['campanya.error.multiplicadorCero']}");	
    			retorno = false;
    		}
    	}
		return retorno;
	}
	
	public boolean validarMargen(){
		boolean retorno = true;
		
		/*
		 * Si MargenCampanya no está informado y PorcentajeMargenCampanya no está informado se mostrará
		 * mensaje de error 
		 */
		if(GenericUtils.isNullOrBlank(mantCampanyasPantalla.getCampanya().getMargenCampanya()) 
				&& GenericUtils.isNullOrBlank(mantCampanyasPantalla.getCampanya().getPorcentajeMargenCampanya())){
			statusMessages.addToControl("txtMargen", Severity.ERROR,"#{messages['campanya.error.margenErroneo']}");
			retorno = false;
		} else if(!GenericUtils.isNullOrBlank(mantCampanyasPantalla.getCampanya().getMargenCampanya()) 
				&& !GenericUtils.isNullOrBlank(mantCampanyasPantalla.getCampanya().getPorcentajeMargenCampanya())){
				if (!BigDecimal.valueOf(0L).unscaledValue().equals(mantCampanyasPantalla.getCampanya().getMargenCampanya().unscaledValue()) 
					&& !BigDecimal.valueOf(0L).unscaledValue().equals(mantCampanyasPantalla.getCampanya().getPorcentajeMargenCampanya().unscaledValue()) ){
					statusMessages.addToControl("txtMargen", Severity.ERROR,"#{messages['campanya.error.margenErroneo']}");
					retorno = false;
				} else if (BigDecimal.valueOf(0L).unscaledValue().equals(mantCampanyasPantalla.getCampanya().getMargenCampanya().unscaledValue()) 
						&& BigDecimal.valueOf(0L).unscaledValue().equals(mantCampanyasPantalla.getCampanya().getPorcentajeMargenCampanya().unscaledValue())){
					statusMessages.addToControl("txtMargen", Severity.ERROR,"#{messages['campanya.error.margenErroneo']}");
					retorno = false;
				}
		}
		return retorno;
	}
	
	public boolean validarUnidadDeNegocio(){
		boolean retorno = true;
		if ("".equals(mantCampanyasPantalla.getCampanya().getUnidadNegocio()) 
				&& Constantes.TIPO_CAMPANYA_DISTRIBUIDA.equals(mantCampanyasPantalla.getCampanya().getTipoCampanya())){
			statusMessages.addToControl("txtUnidadNegocio",Severity.ERROR, "#{messages['campanya.error.unidadNegocioObligatoria']}");	
			retorno = false;
		}
		return retorno;
	}
	
	public boolean validarOficina(){
		boolean retorno = true;
		if ( (GenericUtils.isNullOrBlank(mantCampanyasPantalla.getCampanya().getOficinaAltaCampanya())) 
				&& Constantes.TIPO_CAMPANYA_DISTRIBUIDA.equals(mantCampanyasPantalla.getCampanya().getTipoCampanya())){
			statusMessages.addToControl("txtOficinaAlta",Severity.ERROR, "#{messages['campanya.error.oficinaObligatoria']}");	
			retorno = false;
		}
		return retorno;
	}
	
	public boolean validarFolferK(){
		boolean retorno = true;
		if (GenericUtils.isNullOrBlank(mantCampanyasPantalla.getCampanya().getFolderK()) 
				&& campanyaBo.folderObligatorio(mantCampanyasPantalla.getCampanya())){
			statusMessages.addToControl("txtFolderK", Severity.ERROR,"#{messages['campanya.error.folderKObligatorio']}");
			retorno = false;
		}
		return retorno;
	}
	
	public boolean validarModelo(){
		boolean retorno = true;
		
		if (campanyaBo.noHayOperacionModelo(mantCampanyasPantalla.getCampanya())){
			statusMessages.add(Severity.ERROR,"#{messages['campanya.error.operacionmodeloObligatorio']}");	
			retorno = false;
		}
		if(GenericUtils.isNullOrBlank(mantCampanyasPantalla.getCampanya().getModeloCampanya())){
			statusMessages.addToControl("somModeloCampanya", Severity.ERROR,"#{messages['campanya.error.modeloObligatorio']}");	
			retorno = false;
		}
		
		if (campanyaBo.noHayOperacionModelo(mantCampanyasPantalla.getCampanya()) 
				&& (Constantes.TIPO_COBERTURA_PARCIAL.equals(mantCampanyasPantalla.getCampanya().getIndOperacionesCobertura()) 
							|| Constantes.TIPO_COBERTURA_SI.equals(mantCampanyasPantalla.getCampanya().getIndOperacionesCobertura()) )){
			
			statusMessages.add(Severity.ERROR,"#{messages['campanya.error.coberturaObligatoria']}");
			retorno = false;
		}
		return retorno;
	}
	
//	Si campanya.FolderK no está informado y FolderObligatorio(campanya) = TRUE se mostrará el mensaje de error Campanya.error.FolderKObligatorio
//	Si NoHayOperacionModelo(campanya) = TRUE se mostrará el mensaje de error Campanya.error.ModeloObligatoria
//(fin si)
//
//Si NoHayOperacionCobertura(campanya) = TRUE y campanya.IndOperacionesCobertura es 'S' ó 'P' se mostrará el mensaje de error Campanya.error.CoberturaObligatoria		

    private boolean validarCamposObligatorios(){

    	boolean retorno = true;
    	if (GenericUtils.isNullOrBlank(mantCampanyasPantalla.getCampanya().getDescripcionBO())){
    		statusMessages.addToControl("txtDescripcionBO", Severity.ERROR,"#{messages['Campanya.error.DescripcionObligatoria']}");	
			retorno = false;
    	}
    	if (GenericUtils.isNullOrBlank(mantCampanyasPantalla.getCampanya().getDescripcionOficina())){
    		statusMessages.addToControl("txtDescripcionOficina", Severity.ERROR,"#{messages['Campanya.error.DescripcionObligatoria']}");	
			retorno = false;
    	}
    	if (Constantes.MANT_CAMPANYAS_CAMPO_NO_INFORMADO.equals(mantCampanyasPantalla.getCampanya().getTipoCampanya())){
    		statusMessages.addToControl("somTipoCampanya", Severity.ERROR,"#{messages['Campanya.error.TipoObligatorio']}");	
			retorno = false;
    	}
    	if (GenericUtils.isNullOrBlank(mantCampanyasPantalla.getCampanya().getEstiloCampanya())){
    		statusMessages.addToControl("txtEstiloCampanya", Severity.ERROR,"#{messages['Campanya.error.EstiloObligatorio']}");	
			retorno = false;
    	}
    	
//    	Si campanya.InicioCampanya no está informado se mostrará el mensaje de error Campanya.error.InicioCampanyaObligatorio
//    	Si campanya.FechaVencimiento no está informado se mostrará el mensaje de error Campanya.error.FechaVencimientoObligatoria
//    	Si campanya.ModeloCampanya no está informado se mostrará el mensaje de error Campanya.error.ModeloObligatorio
//    	Si campanya.NominalCampanya no está informado se mostrará el mensaje de error Campanya.error.NominalObligatorio	

    		
    	
    	if (GenericUtils.isNullOrBlank(mantCampanyasPantalla.getCampanya().getDivisaCampanya())){
    		statusMessages.addToControl("somDivisa", Severity.ERROR,"#{messages['Campanya.error.DivisaObligatoria']}");
			retorno = false;
    	}
    	if (GenericUtils.isNullOrBlank(mantCampanyasPantalla.getCampanya().getGrupoContableAntesValor())){
    		statusMessages.addToControl("txtGrupoAV", Severity.ERROR,"#{messages['Campanya.error.GrupoAVObligatorio']}");
			retorno = false;
    	}
    	if (GenericUtils.isNullOrBlank(mantCampanyasPantalla.getCampanya().getGrupoContableDespuesValor())){
    		statusMessages.addToControl("txtGrupoDV", Severity.ERROR,"#{messages['Campanya.error.GrupoDVObligatorio']}");
			retorno = false;
    	}
    	if (GenericUtils.isNullOrBlank(mantCampanyasPantalla.getCampanya().getPorcentajeRiesgo())){
    		statusMessages.addToControl("txtPorcentajeRiesgo", Severity.ERROR,"#{messages['Campanya.error.RiesgoObligatorio']}");
			retorno = false;
    	}
    	
    	if (Constantes.TIPO_CAMPANYA_DISTRIBUIDA.equals(mantCampanyasPantalla.getCampanya().getTipoCampanya())){
    		if (GenericUtils.isNullOrBlank(mantCampanyasPantalla.getCampanya().getDepartCorreoPostalInterno())){
        		statusMessages.addToControl("txtCorreoPostalInterno", Severity.ERROR,"#{messages['Campanya.error.DepartCorreoObligatorio']}");
    			retorno = false;
        	}
    	}    	
    	return retorno;
    	
    }

    /**
	 * Comprueba que la fecha del sistema esté dentro del rango de la fecha
	 * de inicio y la fecha de fin de comercialización de la campanya
	 * @param camp: campaña para la q se comprueban las fechas
	 * @return true si la fecha está en rango
	 */
	private boolean compruebaFechas(Campanya camp){
		
		boolean fechasOk;
		
		Date fechaSistema = campanyaBo.obtenerFechaSistema();
		Date fechaIni = camp.getInicioComercializacion();
		Date fechafin = camp.getFinComercializacion();
		
		if(!GenericUtils.isNullOrBlank(fechaIni) && !GenericUtils.isNullOrBlank(fechafin)){
			long difFechaIniSist = (fechaIni.getTime() - fechaSistema.getTime())/86400000L;
			long difFechaFinSist = (fechafin.getTime() - fechaSistema.getTime())/86400000L;
			fechasOk = (difFechaIniSist <= 0 && difFechaFinSist >=0);
		} else {
			fechasOk = false;
		}
		
		return fechasOk;
	}
    /**
     * Cambia un String formateado en tipo moneda(999.999.999.999,99) a un BigDecinal
     * 
     * @param importe
     * @return
     */
	public BigDecimal convertirImporte(String importe){
		if(GenericUtils.isNullOrBlank(importe)){
			return null;
		}else{
			return new BigDecimal(importe.replace(".", "").replace(",", "."));
		}
	}
	
	/**
     * Cambia un String formateado en tipo moneda(999.999.999.999,99) a un BigDecinal
     * 
     * @param importe
     * @return
     */
	public BigDecimal convertirPorcentaje(String porcentaje){
		if(GenericUtils.isNullOrBlank(porcentaje)){
			return null;
		}else{
			return new BigDecimal(porcentaje.replace(",", "."));
		}
	}
	
	public MantCampanyasPantalla getMantCampanyasPantalla() {
		return mantCampanyasPantalla;
	}

	public void setMantCampanyasPantalla(
			MantCampanyasPantalla mantCampanyasPantalla) {
		this.mantCampanyasPantalla = mantCampanyasPantalla;
	}

	public CampanyaBo getCampanyaBo() {
		return campanyaBo;
	}

	public void setCampanyaBo(CampanyaBo campanyaBo) {
		this.campanyaBo = campanyaBo;
	}

	public Date getFechasistema() {
		if (GenericUtils.isNullOrBlank(fechasistema)){
			fechasistema = campanyaBo.obtenerFechaSistema();
		}
		return fechasistema;
	}

	public void setFechasistema(Date fechasistema) {
		this.fechasistema = fechasistema;
	}


	public String getAccion() {
		return opcion;
	}

	public void setAccion(String accion) {
		this.opcion = accion;
	}

	public String getCocampa() {
		return cocampa;
	}

	public void setCocampa(String cocampa) {
		this.cocampa = cocampa;
	}

	public Date getFechaAct() {
		return fechaAct;
	}

	public void setFechaAct(Date fechaAct) {
		this.fechaAct = fechaAct;
	}

	public String getOrigen() {
		return origen;
	}

	public void setOrigen(String origen) {
		this.origen = origen;
	}

	public String getOpcion() {
		return opcion;
	}

	public void setOpcion(String opcion) {
		this.opcion = opcion;
	}
	
	public String getUsuario() {

		if(ModoPantalla.CREACION.equals(this.modoPantalla)){
			if (GenericUtils.isNullOrBlank(usuario)){
				usuario =  Identity.instance().getCredentials().getUsername(); 
			}
		} else {
			usuario = mantCampanyasPantalla.getCampanya().getAuditData().getUsuarioUltimaModi();
		}
				
		return usuario;
	}

	public void setUsuario(String usuario) {
		this.usuario = usuario;
	}
}
