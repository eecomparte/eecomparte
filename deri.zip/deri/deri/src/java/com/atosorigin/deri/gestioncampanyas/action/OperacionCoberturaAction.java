package com.atosorigin.deri.gestioncampanyas.action;

import java.math.BigDecimal;
import java.util.List;

import org.jboss.seam.ScopeType;
import org.jboss.seam.annotations.In;
import org.jboss.seam.annotations.Name;
import org.jboss.seam.annotations.Scope;
import org.jboss.seam.international.StatusMessage.Severity;

import com.atosorigin.common.action.PaginatedListAction;
import com.atosorigin.common.constantes.Constantes;
import com.atosorigin.common.utils.GenericUtils;
import com.atosorigin.deri.gestioncampanyas.campanya.business.CampanyaBo;
import com.atosorigin.deri.gestioncampanyas.screen.MantCampanyasPantalla;
import com.atosorigin.deri.model.gestioncampanyas.OperacionCobertura;
import com.atosorigin.deri.model.gestioncampanyas.OperacionCoberturaId;
import com.atosorigin.deri.model.gestionoperaciones.Operacion;
import com.atosorigin.deri.model.gestionoperaciones.OperacionId;


@Name("operacionCoberturaAction")
@Scope(ScopeType.CONVERSATION)
public class OperacionCoberturaAction extends PaginatedListAction {
	
	@In(create = true)
	protected OperacionCoberturaPantalla operacionCoberturaPantalla;
	
	@In
	protected MantCampanyasPantalla mantCampanyasPantalla;
	
	@In(value = "#{campanyaBo}")
	protected CampanyaBo campanyaBo;
	
	
	protected boolean operacionCorrecta = false;
	
	
	
	@Override
	public List<?> getDataTableList() {
		return operacionCoberturaPantalla.getListaOperacionCobertura();
	}

	@Override
	protected void refreshListInternal() {
		exportExcel = false;
		operacionCoberturaPantalla.setListaOperacionCobertura(campanyaBo.obtenerOperacionesCobertura(mantCampanyasPantalla.getCampanya()));
	}

	@Override
	public void refrescarListaExcel() {
		exportExcel = true;
		operacionCoberturaPantalla.setListaOperacionCobertura(campanyaBo.obtenerOperacionesCobertura(mantCampanyasPantalla.getCampanya()));
		
	}

	@Override
	public void setDataTableList(List<?> dataTableList) {
		 operacionCoberturaPantalla.setListaOperacionCobertura((List<OperacionCobertura>)dataTableList);
		
	}

	public void opCobertura(){
		mantCampanyasPantalla.setProviene("OPERCOBERTURA");
		paginationData.reset();
		setPrimerAcceso(false);
		refrescarLista(); 
		
	}
	
	
	public void cargaAltaOperCob(){
		OperacionCobertura op = new OperacionCobertura(new OperacionCoberturaId());
		op.getId().setOperacion(new Operacion());
		op.getId().getOperacion().setId(new OperacionId());
		op.setOrdenCobertura(campanyaBo.obtencionOrdenCobertura(mantCampanyasPantalla.getCampanya()));
		operacionCoberturaPantalla.setOperacionCoberturaSelec(op);
		
		
	}
	
	public void borraOperaCobertura(){
		
		campanyaBo.bajaOperacionCobertura(operacionCoberturaPantalla.getOperacionCoberturaSeleccionada());
		refrescarLista();
	}
	
	public String guardarOperacionCobertura(){
		if(operacionCorrecta){
			campanyaBo.altaOperacionCobertura(mantCampanyasPantalla.getCampanya(), operacionCoberturaPantalla.getOperacionCoberturaSelec().getId().getOperacion(), operacionCoberturaPantalla.getOperacionCoberturaSelec().getNominal(), operacionCoberturaPantalla.getOperacionCoberturaSelec().getOrdenCobertura());
			refrescarLista();
			return Constantes.CONSTANTE_SUCCESS;
		}else{
			statusMessages.add(Severity.ERROR, "#{messages['Campanya.error.CoberturaNoExiste']}");
			return Constantes.CONSTANTE_NO;
		}
	}
	
	public void obtencionNominalCobertura(){
		if(operacionCoberturaPantalla.getOperacionCoberturaSelec().getId().getOperacion().getId().getNumeroOperacion() > 0){
			if(!GenericUtils.isNullOrBlank(operacionCoberturaPantalla.getOperacionCoberturaSelec().getId().getOperacion().getId().getNumeroOperacion()) && !GenericUtils.isNullOrBlank( operacionCoberturaPantalla.getOperacionCoberturaSelec().getId().getOperacion().getId().getFechaContratacion())){
				
				int nominal = campanyaBo.obtencionNominalCobertura(operacionCoberturaPantalla.getOperacionCoberturaSelec().getId().getOperacion().getId().getNumeroOperacion(), operacionCoberturaPantalla.getOperacionCoberturaSelec().getId().getOperacion().getId().getFechaContratacion());
				if(nominal > 0){
					operacionCoberturaPantalla.getOperacionCoberturaSelec().setNominal(new BigDecimal(nominal));
					operacionCorrecta = true;
					
				}else{
					operacionCorrecta = false;
					statusMessages.add(Severity.ERROR, "#{messages['Campanya.error.CoberturaNoExiste']}");
				}
			}
		}
	}
	

	public void salirOperCobertura(){
		
	}

	


	public boolean isOperacionCorrecta() {
		return operacionCorrecta;
	}

	public void setOperacionCorrecta(boolean operacionCorrecta) {
		this.operacionCorrecta = operacionCorrecta;
	}

	public OperacionCoberturaPantalla getOperacionCoberturaPantalla() {
		return operacionCoberturaPantalla;
	}

	public void setOperacionCoberturaPantalla(
			OperacionCoberturaPantalla operacionCoberturaPantalla) {
		this.operacionCoberturaPantalla = operacionCoberturaPantalla;
	}

	public MantCampanyasPantalla getMantCampanyasPantalla() {
		return mantCampanyasPantalla;
	}

	public void setMantCampanyasPantalla(MantCampanyasPantalla mantCampanyasPantalla) {
		this.mantCampanyasPantalla = mantCampanyasPantalla;
	}
}
