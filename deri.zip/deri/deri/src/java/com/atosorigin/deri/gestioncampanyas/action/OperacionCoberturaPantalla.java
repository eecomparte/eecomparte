package com.atosorigin.deri.gestioncampanyas.action;

import java.util.List;

import org.jboss.seam.ScopeType;
import org.jboss.seam.annotations.Name;
import org.jboss.seam.annotations.Out;
import org.jboss.seam.annotations.Scope;
import org.jboss.seam.annotations.datamodel.DataModel;
import org.jboss.seam.annotations.datamodel.DataModelSelection;

import com.atosorigin.deri.model.gestioncampanyas.OperacionCobertura;


/**
 * Contiene los datos de pantalla necesarios para el caso de uso de mantenimiento de campañas
 */
@Name("operacionCoberturaPantalla")
@Scope(ScopeType.CONVERSATION)
public class OperacionCoberturaPantalla {
	
	
	@DataModel(value="listaDtOperacionCobertura")
	protected List<OperacionCobertura> listaOperacionCobertura;
	
	@DataModelSelection(value="listaDtOperacionCobertura")
	@Out(required=false)
	protected OperacionCobertura operacionCoberturaSeleccionada;
	
	protected OperacionCobertura operacionCoberturaSelec;

	public List<OperacionCobertura> getListaOperacionCobertura() {
		return listaOperacionCobertura;
	}

	public void setListaOperacionCobertura(
			List<OperacionCobertura> listaOperacionCobertura) {
		this.listaOperacionCobertura = listaOperacionCobertura;
	}

	public OperacionCobertura getOperacionCoberturaSeleccionada() {
		return operacionCoberturaSeleccionada;
	}

	public void setOperacionCoberturaSeleccionada(
			OperacionCobertura operacionCoberturaSeleccionada) {
		this.operacionCoberturaSeleccionada = operacionCoberturaSeleccionada;
	}

	public OperacionCobertura getOperacionCoberturaSelec() {
		return operacionCoberturaSelec;
	}

	public void setOperacionCoberturaSelec(
			OperacionCobertura operacionCoberturaSelec) {
		this.operacionCoberturaSelec = operacionCoberturaSelec;
	}
	
	

}
