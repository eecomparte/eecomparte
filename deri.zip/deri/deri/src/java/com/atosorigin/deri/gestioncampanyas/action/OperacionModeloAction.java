package com.atosorigin.deri.gestioncampanyas.action;

import java.util.Date;
import java.util.List;

import org.jboss.seam.ScopeType;
import org.jboss.seam.annotations.In;
import org.jboss.seam.annotations.Name;
import org.jboss.seam.annotations.Scope;

import com.atosorigin.common.action.PaginatedListAction;
import com.atosorigin.common.formvalidator.FormValidator;
import com.atosorigin.common.utils.GenericUtils;
import com.atosorigin.deri.gestioncampanyas.campanya.business.CampanyaBo;
import com.atosorigin.deri.gestioncampanyas.screen.MantCampanyasPantalla;
import com.atosorigin.deri.gestioncampanyas.screen.OperacionModeloPantalla;
import com.atosorigin.deri.model.gestioncampanyas.Campanya;
import com.atosorigin.deri.model.gestioncampanyas.OperacionModelo;

/**
 * Clase action listener para el caso de uso de mantenimiento campañas.
 */
@Name("operacionModeloAction")
@Scope(ScopeType.CONVERSATION)
@FormValidator 
public class OperacionModeloAction extends PaginatedListAction {
	
	@In(create = true)
	protected OperacionModeloPantalla operacionModeloPantalla;
	
	@In(create = true)
	protected MantCampanyasPantalla mantCampanyasPantalla;
	
	@In(value = "#{campanyaBo}")
	protected CampanyaBo campanyaBo;
	
	@In(required=false,value="campanya")
	protected Campanya campanya;
	
	public void preCargar(Date fechadia){
		
		mantCampanyasPantalla.setProviene("OPERMODELO");
		if (!GenericUtils.isNullOrBlank(campanya.getId()) &&  !GenericUtils.isNullOrBlank(mantCampanyasPantalla.getFechadia())){
			operacionModeloPantalla.setListaOperacionModeloSeleccionadas(campanyaBo.obtenerOperacionesModelo(campanya, mantCampanyasPantalla.getFechadia()));
		}
	}
	
	public void preCargarListado(){
		refrescarLista();
	}
	
	public void asignarOperacionModelo(){
		OperacionModelo operacionModelo = new OperacionModelo();
		operacionModelo = operacionModeloPantalla.getOperacionModelo();
		operacionModelo.getId().setCampanya(campanya);
		campanyaBo.altaOperacionModelo(operacionModelo.getId().getCampanya(), operacionModelo.getId().getOperacion());
		operacionModeloPantalla.setListaOperacionModeloSeleccionadas(campanyaBo.obtenerOperacionesModelo(campanya, null));
	}
	
	public void bajaOperacionModelo(){	
		campanyaBo.bajaOperacionModelo(operacionModeloPantalla.getOperacionModelo());
		operacionModeloPantalla.setListaOperacionModeloSeleccionadas(campanyaBo.obtenerOperacionesModelo(campanya, null));
	}

	@Override
	public List<OperacionModelo> getDataTableList() {
		return operacionModeloPantalla.getListaOperacionModelo();
	}

	@Override
	protected void refreshListInternal() {
		operacionModeloPantalla.setListaOperacionModelo(campanyaBo.obtenerListaOperacionesModelo(campanya,paginationData,operacionModeloPantalla.getCodop()));
	}

	@Override
	public void refrescarListaExcel() {
		operacionModeloPantalla.setListaOperacionModelo(campanyaBo.obtenerListaOperacionesModelo(campanya,paginationData.getPaginationDataForExcel(),operacionModeloPantalla.getCodop()));
		
	}

	@SuppressWarnings("unchecked")
	@Override
	public void setDataTableList(List<?> dataTableList) {
		operacionModeloPantalla.setListaOperacionModelo(((List<OperacionModelo>)dataTableList));
	}
	
	/**
	 * Actualiza la lista del grid de tipos de contrapartidas.
	 * 
	 */
	public void buscar() {
		//SMM BUG - resetear ordenacion
		paginationData.reset();
		refrescarLista();
		setPrimerAcceso(false);
		
	}
	
	
}
