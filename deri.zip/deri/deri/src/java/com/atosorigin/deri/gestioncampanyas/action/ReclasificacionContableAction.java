package com.atosorigin.deri.gestioncampanyas.action;

import javax.persistence.RollbackException;

import org.jboss.seam.ScopeType;
import org.jboss.seam.annotations.In;
import org.jboss.seam.annotations.Name;
import org.jboss.seam.annotations.Scope;
import org.jboss.seam.international.StatusMessage.Severity;

import com.atosorigin.common.action.GenericAction;
import com.atosorigin.common.constantes.Constantes;
import com.atosorigin.common.formvalidator.FormValidator;
import com.atosorigin.deri.gestioncampanyas.campanya.business.CampanyaBo;
import com.atosorigin.deri.gestioncampanyas.screen.ReclasificacionContablePantalla;
import com.atosorigin.deri.model.contabilidad.GrupoContableSelect;
import com.atosorigin.deri.model.gestioncampanyas.Campanya;

/**
 * Clase action listener para el caso de uso reclasificación contable.
 */
@Name("reclasificacionContableAction")
@Scope(ScopeType.CONVERSATION)
@FormValidator
public class ReclasificacionContableAction extends GenericAction {

	/**
	/**
	 * Inyección del bean de Spring "campanyaBo" que contiene los métodos de negocio
	 * para el caso de uso reclasificación contable de campañas.
	 */
	@In("#{campanyaBo}")
	protected CampanyaBo campanyaBo;

	/** Campaña seleccionada en el grid de lista de campañas */
	@In(value="campanyaEdit", required=false )
	protected Campanya campanya;
	
	/**
	 * Inyección del screen bean que contiene los datos de pantalla del caso de uso
	 * reclasificación contable de campañas
	 */
	@In(create=true)
	protected ReclasificacionContablePantalla reclasificacionContablePantalla;
	
	/**
	 * Prepara para entrar en la pantalla de reclasificación contable
	 * @return
	 */
	public String reclasificarContable(){
		reclasificacionContablePantalla.setGrupoSeleccionado(new GrupoContableSelect(campanya.getGrupoContableDespuesValor(), null));
		return Constantes.CONSTANTE_SUCCESS;
	}

	/**
	 * Función para la reclasificación contable de las operaciones asociadas a la campaña
	 */
	public String guardar(){
		
		String grupoCont = this.reclasificacionContablePantalla.getGrupoSeleccionado().getIdGrupoContable();
		
		//Modificamos el grupo contable después de valor de la campaña seleccionada
		campanyaBo.modificarGrupoContable(campanya, grupoCont);
		
		//Modificamos la lista de operaciones asignadas a la campaña
		try {
			campanyaBo.reclasificacionContable(campanya, grupoCont);
		} catch (RollbackException e) {
			statusMessages.add(Severity.ERROR, e.getMessage());
		}
	
		return Constantes.CONSTANTE_SUCCESS;
		
	}

	public Campanya getCampanya() {
		return campanya;
	}

	public void setCampanya(Campanya campanya) {
		this.campanya = campanya;
	}

}
