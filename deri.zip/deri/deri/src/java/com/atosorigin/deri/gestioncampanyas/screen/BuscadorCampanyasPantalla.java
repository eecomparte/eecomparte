package com.atosorigin.deri.gestioncampanyas.screen;

import java.util.List;

import org.jboss.seam.ScopeType;
import org.jboss.seam.annotations.Name;
import org.jboss.seam.annotations.Out;
import org.jboss.seam.annotations.Scope;
import org.jboss.seam.annotations.datamodel.DataModel;
import org.jboss.seam.annotations.datamodel.DataModelSelection;

import com.atosorigin.deri.model.gestioncampanyas.Campanya;

/**
 * Contiene los datos de pantalla necesarios para el caso de uso lista campañas
 */
@Name("buscadorCampanyasPantalla")
@Scope(ScopeType.CONVERSATION)
public class BuscadorCampanyasPantalla {

	/** Criterio de búsqueda de campañas  */
	protected String codigo;
	protected String campanyaDesdeId;
	
	protected boolean muestraListaVacia;
	
	/** Lista de datos para el grid desde */
	@DataModel(value = "listaBuscadorCampDesde")
	protected List<Campanya> listaCampDesde;

	/** Campaña seleccionada en el grid desde */
	@DataModelSelection(value = "listaBuscadorCampDesde")
	@Out(value = "campanyaDesdeSelec", required = false)
	protected Campanya campanyaDesdeSelec;

	/** Lista de datos para el grid desde */
	@DataModel(value = "listaBuscadorCampHasta")
	protected List<Campanya> listaCampHasta;

	/** Campaña seleccionada en el grid desde */
	@DataModelSelection(value = "listaBuscadorCampHasta")
	@Out(value = "campanyaHastaSelec", required = false)
	protected Campanya campanyaHastaSelec;

	public List<Campanya> getListaCampDesde() {
		return listaCampDesde;
	}

	public Campanya getCampanyaDesdeSelec() {
		return campanyaDesdeSelec;
	}

	public List<Campanya> getListaCampHasta() {
		return listaCampHasta;
	}

	public Campanya getCampanyaHastaSelec() {
		return campanyaHastaSelec;
	}

	public void setListaCampDesde(List<Campanya> listaCampDesde) {
		this.listaCampDesde = listaCampDesde;
	}

	public void setCampanyaDesdeSelec(Campanya campanyaDesdeSelec) {
		this.campanyaDesdeSelec = campanyaDesdeSelec;
	}

	public void setListaCampHasta(List<Campanya> listaCampHasta) {
		this.listaCampHasta = listaCampHasta;
	}

	public void setCampanyaHastaSelec(Campanya campanyaHastaSelec) {
		this.campanyaHastaSelec = campanyaHastaSelec;
	}

	public String getCodigo() {
		return codigo;
	}

	public void setCodigo(String codigo) {
		this.codigo = codigo;
	}

	public String getCampanyaDesdeId() {
		return campanyaDesdeId;
	}

	public void setCampanyaDesdeId(String campanyaDesdeId) {
		this.campanyaDesdeId = campanyaDesdeId;
	}

	public boolean isMuestraListaVacia() {
		return muestraListaVacia;
	}

	public void setMuestraListaVacia(boolean muestraListaVacia) {
		this.muestraListaVacia = muestraListaVacia;
	}
	
}
