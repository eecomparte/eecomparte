package com.atosorigin.deri.gestioncampanyas.screen;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.jboss.seam.ScopeType;
import org.jboss.seam.annotations.Name;
import org.jboss.seam.annotations.Scope;

import com.atosorigin.deri.model.agenda.EventoAgenda;
import com.atosorigin.deri.model.contrapartida.UnidadNegocio;
import com.atosorigin.deri.model.gestioncampanyas.Campanya;

/**
 * Contiene los datos de pantalla necesarios para el caso de uso lista campañas
 */
@Name("campanyasPantalla")
@Scope(ScopeType.CONVERSATION)
public class CampanyasPantalla {

	/** Lista de datos para el grid. */

	/** Campaña seleccionada en el grid */

	/** Criterios seleccion */
	protected String idCampanyaDesde;
	protected String idCampanyaHasta;
	protected Date fechaComerDesde;
	protected Date fechaComerHasta;
	protected Date fechaCampanyaDesde;
	protected Date fechaCampanyaHasta;
	protected UnidadNegocio unidadNegocioBusq;
	protected Long cobertura;
	protected Boolean esVigente;

	/**
	 * Selección checkbox Campanya
	 */
	protected Map<String, Boolean> selectedCampanyaIds = new HashMap<String, Boolean>();
	protected List<Campanya> selectedCampanyaDataList = new ArrayList<Campanya>();
	protected boolean selecTodos;

	/** Variables booleanas para el renderizado o no de los botones */
	protected boolean mostrarValidar;
	protected boolean mostrarAnular;

	/** Variable para saber si venimos desde la agenda o no */
	protected boolean vieneAgenda;

//	@Out(value = "agendaListaCampañas", required = false)
//	protected Agenda agendaListaCampanyas;

	
	protected EventoAgenda eventoAgenda;
	
	protected String estadoEvento;
	
	// GETTERS y SETTERS

	public String getIdCampanyaDesde() {
		return idCampanyaDesde;
	}

	public String getIdCampanyaHasta() {
		return idCampanyaHasta;
	}

	public Date getFechaComerDesde() {
		return fechaComerDesde;
	}

	public Date getFechaComerHasta() {
		return fechaComerHasta;
	}

	public Date getFechaCampanyaDesde() {
		return fechaCampanyaDesde;
	}

	public Date getFechaCampanyaHasta() {
		return fechaCampanyaHasta;
	}

	public UnidadNegocio getUnidadNegocioBusq() {
		return unidadNegocioBusq;
	}

	public Long getCobertura() {
		return cobertura;
	}

	public Boolean getEsVigente() {
		return esVigente;
	}


	public void setIdCampanyaDesde(String idCampanyaDesde) {
		this.idCampanyaDesde = idCampanyaDesde;
	}

	public void setIdCampanyaHasta(String idCampanyaHasta) {
		this.idCampanyaHasta = idCampanyaHasta;
	}

	public void setFechaComerDesde(Date fechaComerDesde) {
		this.fechaComerDesde = fechaComerDesde;
	}

	public void setFechaComerHasta(Date fechaComerHasta) {
		this.fechaComerHasta = fechaComerHasta;
	}

	public void setFechaCampanyaDesde(Date fechaCampanyaDesde) {
		this.fechaCampanyaDesde = fechaCampanyaDesde;
	}

	public void setFechaCampanyaHasta(Date fechaCampanyaHasta) {
		this.fechaCampanyaHasta = fechaCampanyaHasta;
	}

	public void setUnidadNegocioBusq(UnidadNegocio unidadNegocioBusq) {
		this.unidadNegocioBusq = unidadNegocioBusq;
	}

	public void setCobertura(Long cobertura) {
		this.cobertura = cobertura;
	}

	public void setEsVigente(Boolean esVigente) {
		this.esVigente = esVigente;
	}

	public Map<String, Boolean> getSelectedCampanyaIds() {
		return selectedCampanyaIds;
	}

	public List<Campanya> getSelectedCampanyaDataList() {
		return selectedCampanyaDataList;
	}

	public void setSelectedCampanyaIds(Map<String, Boolean> selectedCampanyaIds) {
		this.selectedCampanyaIds = selectedCampanyaIds;
	}

	public void setSelectedCampanyaDataList(
			List<Campanya> selectedCampanyaDataList) {
		this.selectedCampanyaDataList = selectedCampanyaDataList;
	}

	public boolean getSelecTodos() {
		return selecTodos;
	}

	public void setSelecTodos(boolean selecTodos) {
		this.selecTodos = selecTodos;
	}

	public boolean isMostrarValidar() {
		return mostrarValidar;
	}

	public boolean isMostrarAnular() {
		return mostrarAnular;
	}

	public void setMostrarValidar(boolean mostrarValidar) {
		this.mostrarValidar = mostrarValidar;
	}

	public void setMostrarAnular(boolean mostrarAnular) {
		this.mostrarAnular = mostrarAnular;
	}



	public boolean isVieneAgenda() {
		return vieneAgenda;
	}

	public void setVieneAgenda(boolean vieneAgenda) {
		this.vieneAgenda = vieneAgenda;
	}

//	public Agenda getAgendaListaCampanyas() {
//		return agendaListaCampanyas;
//	}
//
//	public void setAgendaListaCampanyas(Agenda agendaListaCampanyas) {
//		this.agendaListaCampanyas = agendaListaCampanyas;
//	}

	public EventoAgenda getEventoAgenda() {
		return eventoAgenda;
	}

	public void setEventoAgenda(EventoAgenda eventoAgenda) {
		this.eventoAgenda = eventoAgenda;
	}

	public String getEstadoEvento() {
		return estadoEvento;
	}

	public void setEstadoEvento(String estadoEvento) {
		this.estadoEvento = estadoEvento;
	}

}
