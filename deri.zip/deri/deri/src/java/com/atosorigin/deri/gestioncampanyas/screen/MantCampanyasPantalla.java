package com.atosorigin.deri.gestioncampanyas.screen;

import java.math.BigDecimal;
import java.util.Date;

import org.jboss.seam.ScopeType;
import org.jboss.seam.annotations.Name;
import org.jboss.seam.annotations.Out;
import org.jboss.seam.annotations.Scope;

import com.atosorigin.common.constantes.Constantes;
import com.atosorigin.common.utils.GenericUtils;
import com.atosorigin.deri.model.gestioncampanyas.Campanya;
import com.atosorigin.deri.model.parametrizacion.Divisa;

/**
 * Contiene los datos de pantalla necesarios para el caso de uso de mantenimiento de campañas
 */
@Name("mantCampanyasPantalla")
@Scope(ScopeType.CONVERSATION)
public class MantCampanyasPantalla {
	
	
	@Out(required=false,value="campanya")
	protected Campanya campanya = new Campanya();
	
	protected Divisa divisa;
	protected boolean porcentajeDisabled = false;
	protected boolean importeFijoDisabled = false;
	protected boolean grupoContableAntesValorDisabled = false;
	protected boolean grupoContableDespuesValorDisabled = false;
	
	//Propiedad disabled de los botones
	protected boolean btnAltaIncompletaDisabled = false;
	protected boolean btnAltaCompletaDisabled = false;
	protected boolean btnAsignarOpsModeloDisabled = false;
	protected boolean btnConsultarOpsModeloDisabled = false;
	protected boolean btnOpCoberturaDisabled = false;
	protected boolean btnGuardarDisabled = false;
	protected boolean btnCalculoClaveDisabled = false;
	
	//Propiedad disabled de los input
	
	protected boolean InpIdDisabled = false;
	protected boolean InpFinComercializacionDisabled = false;
	protected boolean InpNominalCampanyaDisabled = false;
	protected boolean InpPorcentajeMargenCampanyaDisabled = false;	
	protected boolean InpIndicadorPrimaDisabled = false;   
	protected boolean InpImporteMinimoOrdenDisabled = false;
	protected boolean InpImporteMaximoOrdenDisabled = false;
	protected boolean InpMultiplicadorDisabled = false;
	protected boolean InpImportePrimaDisabled = false;
	protected boolean InpPorcentajePrimaDisabled = false;
	protected boolean InpGrupoContableDespuesValorDisabled = false;
	
	protected Date fechadia = new Date();//la fecha del día con formato dd/mm/yyyy hh24:mi:ss

	protected String proviene;
	
	protected String susVigentes="";
	
	protected boolean esDetalle;
	
	//Importes con mascara "99,999.999.999.999"
	protected String nomninal;
	
	protected String disponible;
	
	protected String importeMinimo;
	
	protected String importeMaximo;
	
	protected String multiplo;
	
	protected String porcentajePrima;
	
	protected String importePrima;
	
	protected String margenCampanya;
	
	protected String porcentajeMargenCampanya;
	
	protected String porcentajeRiesgo;
	

	protected BigDecimal nominalCampanyaAnterior;
 
	public BigDecimal getNominalCampanyaAnterior() {
		return nominalCampanyaAnterior;
	}

	public void setNominalCampanyaAnterior(BigDecimal nominalCampanyaAnterior) {
		this.nominalCampanyaAnterior = nominalCampanyaAnterior;
	}

	public Divisa getDivisa() {
		return divisa;
	}

	public void setDivisa(Divisa divisa) {
		this.divisa = divisa;
	}

	public Campanya getCampanya() {
		return campanya;
	}

	public void setCampanya(Campanya campanya) {
		this.campanya = campanya;
	}

	public boolean isPorcentajeDisabled() {
		return porcentajeDisabled;
	}

	public void setPorcentajeDisabled(boolean porcentajeDisabled) {
		this.porcentajeDisabled = porcentajeDisabled;
	}

	public boolean isImporteFijoDisabled() {
		return importeFijoDisabled;
	}

	public void setImporteFijoDisabled(boolean importeFijoDisabled) {
		this.importeFijoDisabled = importeFijoDisabled;
	}

	public boolean isGrupoContableAntesValorDisabled() {
		return grupoContableAntesValorDisabled;
	}

	public void setGrupoContableAntesValorDisabled(
			boolean grupoContableAntesValorDisabled) {
		this.grupoContableAntesValorDisabled = grupoContableAntesValorDisabled;
	}

	public boolean isGrupoContableDespuesValorDisabled() {
		return grupoContableDespuesValorDisabled;
	}

	public void setGrupoContableDespuesValorDisabled(
			boolean grupoContableDespuesValorDisabled) {
		this.grupoContableDespuesValorDisabled = grupoContableDespuesValorDisabled;
	}

	public boolean isBtnAltaCompletaDisabled() {
		return btnAltaCompletaDisabled;
	}

	public void setBtnAltaCompletaDisabled(boolean btnAltaCompletaDisabled) {
		this.btnAltaCompletaDisabled = btnAltaCompletaDisabled;
	}

	public boolean isBtnAsignarOpsModeloDisabled() {
		return btnAsignarOpsModeloDisabled;
	}

	public void setBtnAsignarOpsModeloDisabled(boolean btnAsignarOpsModeloDisabled) {
		this.btnAsignarOpsModeloDisabled = btnAsignarOpsModeloDisabled;
	}

	public boolean isBtnOpCoberturaDisabled() {
		return btnOpCoberturaDisabled;
	}

	public void setBtnOpCoberturaDisabled(boolean btnOpCoberturaDisabled) {
		this.btnOpCoberturaDisabled = btnOpCoberturaDisabled;
	}

	public boolean isBtnGuardarDisabled() {
		return btnGuardarDisabled;
	}

	public void setBtnGuardarDisabled(boolean btnGuardarDisabled) {
		this.btnGuardarDisabled = btnGuardarDisabled;
	}

	public boolean isBtnCalculoClaveDisabled() {
		return btnCalculoClaveDisabled;
	}

	public void setBtnCalculoClaveDisabled(boolean btnCalculoClaveDisabled) {
		this.btnCalculoClaveDisabled = btnCalculoClaveDisabled;
	}

	public boolean isBtnAltaIncompletaDisabled() {
		return btnAltaIncompletaDisabled;
	}

	public void setBtnAltaIncompletaDisabled(boolean btnAltaIncompletaDisabled) {
		this.btnAltaIncompletaDisabled = btnAltaIncompletaDisabled;
	}

	public boolean isBtnConsultarOpsModeloDisabled() {
		return btnConsultarOpsModeloDisabled;
	}

	public void setBtnConsultarOpsModeloDisabled(
			boolean btnConsultarOpsModeloDisabled) {
		this.btnConsultarOpsModeloDisabled = btnConsultarOpsModeloDisabled;
	}

	public boolean isInpIdDisabled() {
		return InpIdDisabled;
	}

	public void setInpIdDisabled(boolean inpIdDisabled) {
		InpIdDisabled = inpIdDisabled;
	}

	public boolean isInpFinComercializacionDisabled() {
		return InpFinComercializacionDisabled;
	}

	public void setInpFinComercializacionDisabled(
			boolean inpFinComercializacionDisabled) {
		InpFinComercializacionDisabled = inpFinComercializacionDisabled;
	}

	public boolean isInpNominalCampanyaDisabled() {
		return InpNominalCampanyaDisabled;
	}

	public void setInpNominalCampanyaDisabled(boolean inpNominalCampanyaDisabled) {
		InpNominalCampanyaDisabled = inpNominalCampanyaDisabled;
	}

	public boolean isInpPorcentajeMargenCampanyaDisabled() {
		return InpPorcentajeMargenCampanyaDisabled;
	}

	public void setInpPorcentajeMargenCampanyaDisabled(
			boolean inpPorcentajeMargenCampanyaDisabled) {
		InpPorcentajeMargenCampanyaDisabled = inpPorcentajeMargenCampanyaDisabled;
	}

	public boolean isInpIndicadorPrimaDisabled() {
		return InpIndicadorPrimaDisabled;
	}

	public void setInpIndicadorPrimaDisabled(boolean inpIndicadorPrimaDisabled) {
		InpIndicadorPrimaDisabled = inpIndicadorPrimaDisabled;
	}

	public boolean isInpImporteMinimoOrdenDisabled() {
		return InpImporteMinimoOrdenDisabled;
	}

	public void setInpImporteMinimoOrdenDisabled(
			boolean inpImporteMinimoOrdenDisabled) {
		InpImporteMinimoOrdenDisabled = inpImporteMinimoOrdenDisabled;
	}

	public boolean isInpImporteMaximoOrdenDisabled() {
		return InpImporteMaximoOrdenDisabled;
	}

	public void setInpImporteMaximoOrdenDisabled(
			boolean inpImporteMaximoOrdenDisabled) {
		InpImporteMaximoOrdenDisabled = inpImporteMaximoOrdenDisabled;
	}

	public boolean isInpMultiplicadorDisabled() {
		return InpMultiplicadorDisabled;
	}

	public void setInpMultiplicadorDisabled(boolean inpMultiplicadorDisabled) {
		InpMultiplicadorDisabled = inpMultiplicadorDisabled;
	}

	public boolean isInpImportePrimaDisabled() {
		return InpImportePrimaDisabled;
	}

	public void setInpImportePrimaDisabled(boolean inpImportePrimaDisabled) {
		InpImportePrimaDisabled = inpImportePrimaDisabled;
	}

	public boolean isInpPorcentajePrimaDisabled() {
		return InpPorcentajePrimaDisabled;
	}

	public void setInpPorcentajePrimaDisabled(boolean inpPorcentajePrimaDisabled) {
		InpPorcentajePrimaDisabled = inpPorcentajePrimaDisabled;
	}

	public boolean isInpGrupoContableDespuesValorDisabled() {
		return InpGrupoContableDespuesValorDisabled;
	}

	public void setInpGrupoContableDespuesValorDisabled(
			boolean inpGrupoContableDespuesValorDisabled) {
		InpGrupoContableDespuesValorDisabled = inpGrupoContableDespuesValorDisabled;
	}

	public String getSusVigentes() {
		return susVigentes;
	}

	public void setSusVigentes(String susVigentes) {
		this.susVigentes = susVigentes;
	}

	public String getProviene() {
		return proviene;
	}

	public void setProviene(String proviene) {
		this.proviene = proviene;
	}

	public Date getFechadia() {
		return fechadia;
	}

	public void setFechadia(Date fechadia) {
		this.fechadia = fechadia;
	}

	public boolean isEsDetalle() {
		return esDetalle;
	}

	public void setEsDetalle(boolean esDetalle) {
		this.esDetalle = esDetalle;
	}
	
	public String getNomninal() {
		return GenericUtils.aplicarMascaraNumerica(nomninal, Constantes.MASCARA_SEPARADOR_MILES);
	}

	public void setNomninal(String nomninal) {
		this.nomninal = nomninal;
	}

	public String getDisponible() {
		return GenericUtils.aplicarMascaraNumerica(disponible, Constantes.MASCARA_SEPARADOR_MILES);
	}

	public void setDisponible(String disponible) {
		this.disponible = disponible;
	}

	public String getImporteMinimo() {
		return GenericUtils.aplicarMascaraNumerica(importeMinimo, Constantes.MASCARA_SEPARADOR_MILES);
	}

	public void setImporteMinimo(String importeMinimo) {
		this.importeMinimo = importeMinimo;
	}

	public String getImporteMaximo() {
		return GenericUtils.aplicarMascaraNumerica(importeMaximo, Constantes.MASCARA_SEPARADOR_MILES);
	}

	public void setImporteMaximo(String importeMaximo) {
		this.importeMaximo = importeMaximo;
	}

	public String getMultiplo() {
		return GenericUtils.aplicarMascaraNumerica(multiplo, Constantes.MASCARA_SEPARADOR_MILES);
	}

	public void setMultiplo(String multiplo) {
		this.multiplo = multiplo;
	}

	public String getPorcentajePrima() {
		return GenericUtils.aplicarMascaraNumerica(porcentajePrima, Constantes.MASCARA_PORCENTAJES);
	}

	public void setPorcentajePrima(String porcentajePrima) {
		this.porcentajePrima = porcentajePrima;
	}

	public String getImportePrima() {
		return GenericUtils.aplicarMascaraNumerica(importePrima, Constantes.MASCARA_SEPARADOR_MILES);
	}

	public void setImportePrima(String importePrima) {
		this.importePrima = importePrima;
	}

	public String getMargenCampanya() {
		return GenericUtils.aplicarMascaraNumerica(margenCampanya, Constantes.MASCARA_SEPARADOR_MILES);
	}

	public void setMargenCampanya(String margenCampanya) {
		this.margenCampanya = margenCampanya;
	}
	
	public String getPorcentajeRiesgo() {
		return GenericUtils.aplicarMascaraNumerica(porcentajeRiesgo, Constantes.MASCARA_PORCENTAJES);
	}

	public void setPorcentajeRiesgo(String porcentajeRiesgo) {
		this.porcentajeRiesgo = porcentajeRiesgo;
	}

	public String getPorcentajeMargenCampanya() {
		return GenericUtils.aplicarMascaraNumerica(porcentajeMargenCampanya, Constantes.MASCARA_PORCENTAJES);
	}

	public void setPorcentajeMargenCampanya(String porcentajeMargenCampanya) {
		this.porcentajeMargenCampanya = porcentajeMargenCampanya;
	}
}
