package com.atosorigin.deri.gestioncampanyas.screen;

import java.util.List;

import org.jboss.seam.ScopeType;
import org.jboss.seam.annotations.Name;
import org.jboss.seam.annotations.Out;
import org.jboss.seam.annotations.Scope;
import org.jboss.seam.annotations.datamodel.DataModel;
import org.jboss.seam.annotations.datamodel.DataModelSelection;

import com.atosorigin.deri.model.gestioncampanyas.OperacionModelo;

/**
 * Contiene los datos de pantalla necesarios para el popup OperacionModelo
 */
@Name("operacionModeloPantalla")
@Scope(ScopeType.CONVERSATION)
public class OperacionModeloPantalla  {
	
	@DataModel(value="listaDtOperacionModelo")
	protected List<OperacionModelo> listaOperacionModelo;
	
	@DataModelSelection(value="listaDtOperacionModelo")
	@Out(required=false)
	protected OperacionModelo operacionModelo;
	
	
	@DataModel(value="listaDtOperacionModeloSeleccionados")
	protected List<OperacionModelo> listaOperacionModeloSeleccionadas;
	
	@DataModelSelection(value="listaDtOperacionModeloSeleccionados")
	@Out(required=false)
	protected OperacionModelo operacionModeloSeleccionadas;
	
	
	protected String codop = "";

	public OperacionModelo getOperacionModelo() {
		return operacionModelo;
	}

	public void setOperacionModelo(OperacionModelo operacionModelo) {
		this.operacionModelo = operacionModelo;
	}

	public List<OperacionModelo> getListaOperacionModelo() {
		return listaOperacionModelo;
	}

	public void setListaOperacionModelo(List<OperacionModelo> listaOperacionModelo) {
		this.listaOperacionModelo = listaOperacionModelo;
	}

	public List<OperacionModelo> getListaOperacionModeloSeleccionadas() {
		return listaOperacionModeloSeleccionadas;
	}

	public void setListaOperacionModeloSeleccionadas(
			List<OperacionModelo> listaOperacionModeloSeleccionadas) {
		this.listaOperacionModeloSeleccionadas = listaOperacionModeloSeleccionadas;
	}

	public String getCodop() {
		return codop;
	}

	public void setCodop(String codop) {
		this.codop = codop;
	}

}
