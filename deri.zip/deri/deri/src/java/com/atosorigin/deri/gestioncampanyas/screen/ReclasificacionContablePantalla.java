package com.atosorigin.deri.gestioncampanyas.screen;

import java.util.List;

import org.jboss.seam.ScopeType;
import org.jboss.seam.annotations.Name;
import org.jboss.seam.annotations.Scope;

import com.atosorigin.deri.model.contabilidad.GrupoContableSelect;

/**
 * Contiene los datos de pantalla necesarios para el caso de uso lista campañas
 */
@Name("reclasificacionContablePantalla")
@Scope(ScopeType.CONVERSATION)
public class ReclasificacionContablePantalla {

	/** Combo de grupos contables */
	protected List<GrupoContableSelect> listGruposContables;
	
	/** Grupo contable seleccionado */
	GrupoContableSelect grupoSeleccionado;

	public List<GrupoContableSelect> getListGruposContables() {
		return listGruposContables;
	}

	public GrupoContableSelect getGrupoSeleccionado() {
		return grupoSeleccionado;
	}

	public void setListGruposContables(List<GrupoContableSelect> listGruposContables) {
		this.listGruposContables = listGruposContables;
	}

	public void setGrupoSeleccionado(GrupoContableSelect grupoSeleccionado) {
		this.grupoSeleccionado = grupoSeleccionado;
	}
	
}
