package com.atosorigin.deri.gestionoperaciones.anexooperacion.action;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.faces.context.ExternalContext;
import javax.faces.context.FacesContext;
import javax.persistence.EntityManager;
import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServletResponse;

import org.jboss.seam.ScopeType;
import org.jboss.seam.annotations.In;
import org.jboss.seam.annotations.Name;
import org.jboss.seam.annotations.Out;
import org.jboss.seam.annotations.Scope;
import org.jboss.seam.annotations.datamodel.DataModel;
import org.jboss.seam.annotations.datamodel.DataModelSelection;
import org.jboss.seam.core.Conversation;
import org.jboss.seam.international.StatusMessage.Severity;
import org.jboss.seam.security.Identity;
import org.richfaces.event.UploadEvent;
import org.richfaces.model.UploadItem;

import com.atosorigin.common.action.ModoPantalla;
import com.atosorigin.common.action.PaginatedListAction;
import com.atosorigin.common.constantes.Constantes;
import com.atosorigin.common.formvalidator.FormValidator;
import com.atosorigin.common.utils.GenericUtils;
import com.atosorigin.deri.gestionoperaciones.anexooperacion.business.AnexoOperacionBo;
import com.atosorigin.deri.gestionoperaciones.anexooperacion.screen.AnexosPantalla;
import com.atosorigin.deri.model.apuntesContables.Oficina;
import com.atosorigin.deri.model.gestionoperaciones.AnexoOperacion;
import com.atosorigin.deri.model.gestionoperaciones.AnexoOperacionId;
import com.atosorigin.deri.model.gestionoperaciones.ConfOperacion;
import com.atosorigin.deri.model.gestionoperaciones.HistoricoOperacion;
import com.atosorigin.deri.model.gestionoperaciones.Operacion;

/**
 * Clase action listener para el caso de uso de Información Anexa
 */
@Name("anexosAction")
@Scope(ScopeType.CONVERSATION)
@FormValidator
public class AnexosAction extends PaginatedListAction {

	private static final String MANTENIMIENTO = "mantenimiento";
	private static final String CUENTA = "cuenta";
	
	/** Lista de datos para el grid. */
	@DataModel(value = "listaDtAnexoOperacion")
	protected List<AnexoOperacion> anexosOperList;

	/** Anexo seleccionado en el grid */
	@DataModelSelection(value = "listaDtAnexoOperacion")
	protected AnexoOperacion anexoOperacionSelec;

	@Out(value = "anexoOperacion", required = false)
	protected AnexoOperacion anexoOperacion;
	
	@In
	private EntityManager entityManager;
	
	/**
	 * Inyección del bean de Spring "AnexoOperacionBo" que contiene los métodos de
	 * negocio para el caso de uso información anexa.
	 */
	@In("#{anexoOperacionBo}")
	protected AnexoOperacionBo anexoOperacionBo;

	/**
	 * Inyección del screen bean que contiene los datos de pantalla del caso de
	 * uso datos de mercado
	 */
	@In(create = true)
	protected AnexosPantalla anexosPantalla;
	
	@In(value="#{facesContext.externalContext}")
	private ExternalContext extCtx;
	
	//FLM:
	// Para simplificar el paso de parámetros, lo pasaremos por injeccion
	// Haciendo la busqueda en el init
	// Uso: Antes de la llamada se nos pasará el modo y la operacion/confirmacion segun el modo
	//      el init ejecuta la busqueda según sea conveniente
	@In(value="modoTratamiento")
	protected String modo; // A alta, E edicion C Consulta
	@In
	protected String tipoAnexo;	
	@In(required=false)
	protected HistoricoOperacion historicoOperacion;
	@In(value="confOperacionSelect", required=false)
	protected ConfOperacion confirmacion;
	
	@In(required=false)
	private String observaciones;
	
	@In(required=false)
	private Date fechaLiquidacion2;

	@In(required = false)
	protected Boolean anexoGrabado;
	
	protected List<Operacion> operacionesList;
	protected Boolean mantOperdirecto;
	
	//FLM: en el init se ejecuta la búsqueda e inicialización según
	// el parametro Injectado tipoAnexo.
	// el modo habilita o deshabilita controles
	
	public void init(){

		limpiarOperaciones();
		mantOperdirecto = false;
		if (Constantes.TIPOANEXO_MODO_E.equalsIgnoreCase(modo)){
			mantOperdirecto = true;
		}
			
		if (Constantes.TIPOANEXO_OPERACION.equals(tipoAnexo) )
			verInfoAnexaOperaciones(modo, historicoOperacion);
		else if (Constantes.TIPOANEXO_CONFIRMACION.equals(tipoAnexo) )
			verInfoAnexaConfirmaciones(modo, confirmacion);
		else if (Constantes.TIPOANEXO_PRECONFIRMACION.equals(tipoAnexo)){
			anexosPantalla.setTipoAnexo(Constantes.TIPOANEXO_PRECONFIRMACION);
			verInfoAnexaPreConfirmaciones(modo, historicoOperacion);
		}else if (Constantes.TIPOANEXO_CUENTA.equals(tipoAnexo))
			anexosPantalla.setTipoAnexo(Constantes.TIPOANEXO_CUENTA);
		else if (Constantes.TIPOANEXO_LIQUIDACION.equals(tipoAnexo))
			verInfoAnexaLiquidacion(modo, historicoOperacion);
		else if (Constantes.TIPOANEXO_RECLAMACION.equals(tipoAnexo))
			verInfoAnexaReclamaciones(modo, confirmacion);
								
		
	}
	
	private void limpiarOperaciones() {
		anexosPantalla.setMultOperaciones(false);
		anexosPantalla.setOperacion1(null);
		anexosPantalla.setOperacion2(null);
		anexosPantalla.setOperacion3(null);
		anexosPantalla.setOperacion4(null);
		anexosPantalla.setOperacion5(null);
		anexosPantalla.setOperacion6(null);
		anexosPantalla.setOperacion7(null);
		anexosPantalla.setOperacion8(null);
		anexosPantalla.setOperacion9(null);
		anexosPantalla.setOperacion10(null);
		
		
	}

	private String verInfoAnexaReclamaciones(String modo,
			ConfOperacion confirmacion) {


		//Marcamos desde qué pantalla se accede
		anexosPantalla.setVieneOperaciones(false);
		anexosPantalla.setVieneConfirmaciones(true);
		anexosPantalla.setVienePreConfirmaciones(false);
		anexosPantalla.setVieneLiquidaciones(false);
		
		//Recuperamos los valores identificativos de la operación
		if(confirmacion != null) {
			anexosPantalla.setNumConfirmacion(confirmacion.getNumConfirmacion());
			if (confirmacion.getOperacion() != null && confirmacion.getOperacion().getId().getFechaContratacion() != null){
				anexosPantalla.setFechaContratacion(confirmacion.getOperacion().getId().getFechaContratacion());
			}
			if (confirmacion.getOperacion() != null){
				anexosPantalla.setIdOperacion(confirmacion.getOperacion().getId().getNumeroOperacion());
			}
		}
		//Marcamos el modo de acceso y el tipo de anexo
		anexosPantalla.setModoAcceso(modo);
		anexosPantalla.setTipoAnexo(Constantes.TIPOANEXO_RECLAMACION);
		
		//Si el modo es edición, debe mostrarse la lista de anexos informada
		if (!Constantes.TIPOANEXO_MODO_C.equalsIgnoreCase(modo)){
			buscar();
		}
				
		return Constantes.CONSTANTE_SUCCESS;
	
	}

	private String verInfoAnexaLiquidacion(String modo,
			HistoricoOperacion historicoOperacion) {
		
		//Marcamos desde qué pantalla se accede
		anexosPantalla.setVieneOperaciones(false);
		anexosPantalla.setVieneConfirmaciones(false);
		anexosPantalla.setVienePreConfirmaciones(false);
		anexosPantalla.setVieneLiquidaciones(true);
		anexosPantalla.setNumConfirmacion(null);
		
		//Establecemos los valores identificativos de la operación
		anexosPantalla.setIdOperacion(historicoOperacion.getId().getNumeroOperacion());
		anexosPantalla.setFechaContratacion(historicoOperacion.getId().getFechaContratacion());
		
		
		//Marcamos el modo de acceso y el tipo de anexo
		anexosPantalla.setModoAcceso(modo);
		anexosPantalla.setTipoAnexo(Constantes.TIPOANEXO_LIQUIDACION);
		
		//Para la busqueda se usa la fechaAnexo
		anexosPantalla.setFechaInicio(fechaLiquidacion2);
		anexosPantalla.setFechaFin(fechaLiquidacion2);
		
		//Si el modo es edición, debe mostrarse la lista de anexos informada
		if (!Constantes.TIPOANEXO_MODO_C.equalsIgnoreCase(modo)){
			buscar();
		}

		return Constantes.CONSTANTE_SUCCESS;


		
	}

	/**
	 * Se accede a la pantalla desde Mantenimiento de operaciones.
	 * El sistema muestra la pantalla con los parámetros de búsqueda y
	 * la lista de anexos vacía
	 * 
	 * @param modo: C consulta, A alta, E edicion
	 */
	public String verInfoAnexaOperaciones(String modo, HistoricoOperacion historicoOperacion){
		
		//Marcamos desde qué pantalla se accede
		anexosPantalla.setVieneOperaciones(true);
		anexosPantalla.setVieneConfirmaciones(false);
		anexosPantalla.setVienePreConfirmaciones(false);
		anexosPantalla.setNumConfirmacion(null);
		anexosPantalla.setVieneLiquidaciones(false);
		
		//Establecemos los valores identificativos de la operación
		anexosPantalla.setIdOperacion(historicoOperacion.getId().getNumeroOperacion());
		anexosPantalla.setFechaContratacion(historicoOperacion.getId().getFechaContratacion());

		//Marcamos el modo de acceso y el tipo de anexo
		anexosPantalla.setModoAcceso(modo);
		anexosPantalla.setTipoAnexo(Constantes.TIPOANEXO_OPERACION);
		
		return Constantes.CONSTANTE_SUCCESS;
	}
	
	/**
	 * Se accede a la pantalla desde Mantenimiento de confirmaciones.
	 * El sistema muestra la pantalla con los parámetros de búsqueda y
	 * la lista de anexos vacía o informado si modo no es Consulta
	 * @param modo C consulta, A alta, E edicion
	 */
	public String verInfoAnexaConfirmaciones(String modo, ConfOperacion confirmacion){
		
		//Marcamos desde qué pantalla se accede
		anexosPantalla.setVieneOperaciones(false);
		anexosPantalla.setVieneConfirmaciones(true);
		anexosPantalla.setVienePreConfirmaciones(false);
		anexosPantalla.setVieneLiquidaciones(false);
		
		//Recuperamos los valores identificativos de la operación
		if(confirmacion != null) {
			anexosPantalla.setNumConfirmacion(confirmacion.getNumConfirmacion());
			if (confirmacion.getOperacion() != null && confirmacion.getOperacion().getId().getFechaContratacion() != null){
				anexosPantalla.setFechaContratacion(confirmacion.getOperacion().getId().getFechaContratacion());
			}
			if (confirmacion.getOperacion() != null){
				anexosPantalla.setIdOperacion(confirmacion.getOperacion().getId().getNumeroOperacion());
			}
		}
		//Marcamos el modo de acceso y el tipo de anexo
		anexosPantalla.setModoAcceso(modo);
		anexosPantalla.setTipoAnexo(Constantes.TIPOANEXO_CONFIRMACION);
		
		//Si el modo es edición, debe mostrarse la lista de anexos informada
		if (!Constantes.TIPOANEXO_MODO_C.equalsIgnoreCase(modo)){
			buscar();
		}
				
		return Constantes.CONSTANTE_SUCCESS;
	
	}
	

	/**
	 * Se accede a la pantalla desde Mantenimiento de confirmaciones.
	 * El sistema muestra la pantalla con los parámetros de búsqueda y
	 * la lista de anexos vacía o informado si modo no es Consulta
	 * @param modo C consulta, A alta, E edicion
	 */
	public String verInfoAnexaPreConfirmaciones(String modo, HistoricoOperacion historicoOperacion){
		
		//Marcamos desde qué pantalla se accede
		anexosPantalla.setVieneOperaciones(false);
		anexosPantalla.setVieneConfirmaciones(false);
		anexosPantalla.setVienePreConfirmaciones(true);
		anexosPantalla.setVieneLiquidaciones(false);
		
		//Establecemos los valores identificativos de la operación
		anexosPantalla.setIdOperacion(historicoOperacion.getId().getNumeroOperacion());
		anexosPantalla.setFechaContratacion(historicoOperacion.getId().getFechaContratacion());
		
		//Marcamos el modo de acceso y el tipo de anexo
		anexosPantalla.setModoAcceso(modo);
		anexosPantalla.setTipoAnexo(Constantes.TIPOANEXO_PRECONFIRMACION);
		
		//Si el modo es edición, debe mostrarse la lista de anexos informada
		if (!Constantes.TIPOANEXO_MODO_C.equalsIgnoreCase(modo)){
			buscar();
		}
				
		return Constantes.CONSTANTE_SUCCESS;
	}

	
	
	/** ##### MÉTODOS PARA GESTIONAR LA BÚSQUEDA DE ANEXOS ##### */
	
	/** Valida que las fechas sean correctas si ambas están informadas */
	public boolean buscarValidator(){
		
		boolean esCorrecto = true;
		
		if(!GenericUtils.isNullOrBlank(anexosPantalla.getFechaInicio())
				&& !GenericUtils.isNullOrBlank(anexosPantalla.getFechaFin())){
		
			long difFechaFinIni = (anexosPantalla.getFechaFin().getTime() - anexosPantalla.getFechaInicio().getTime())/86400000L;
			
			if(difFechaFinIni < 0){
				esCorrecto = false;
				statusMessages.add(Severity.ERROR, "#{messages['anexos.error.fechas']}");
			}
		}
		
		return esCorrecto;
	}
	
	/** Actualiza la lista del grid de anexos */
	public void buscar() {
		paginationData.reset(); /** Limpiamos la información de paginación */
		refrescarLista();
		setPrimerAcceso(false);
	}
	
	@Override
	protected void refreshListInternal() {
		
		setExportExcel(false);
		String user = null;
		
		//Si está marcado Anexos Usuario recuperamos el nombre de usuario para filtra la búsqueda
		if(anexosPantalla.isAnexosUsuario()){
			user = Identity.instance().getCredentials().getUsername();
		}
		
		if(GenericUtils.isNullOrBlank(anexosOperList)){
			anexosOperList = new ArrayList<AnexoOperacion>();
		}
		anexosOperList.clear();
		anexosOperList.addAll(anexoOperacionBo.buscar(anexosPantalla.getIdOperacion(),
								anexosPantalla.getFechaContratacion(),
								anexosPantalla.getNumConfirmacion(),
								anexosPantalla.getTipoAnexo(),
								user,
								anexosPantalla.getFechaInicio(),
								anexosPantalla.getFechaFin(),
								paginationData));
	}

	@Override
	public void refrescarListaExcel() {
		
		setExportExcel(true);
		
		String user = null;
		
		//Si está marcado Anexos Usuario recuperamos el nombre de usuario para filtra la búsqueda
		if(anexosPantalla.isAnexosUsuario()){
			user = Identity.instance().getCredentials().getUsername();
		}
		
		if(GenericUtils.isNullOrBlank(anexosOperList)){
			anexosOperList = new ArrayList<AnexoOperacion>();
		}
		anexosOperList.clear();
		anexosOperList.addAll(anexoOperacionBo.buscar(anexosPantalla.getIdOperacion(),
								anexosPantalla.getFechaContratacion(),
								anexosPantalla.getNumConfirmacion(),
								anexosPantalla.getTipoAnexo(),
								user,
								anexosPantalla.getFechaInicio(),
								anexosPantalla.getFechaFin(),
								paginationData.getPaginationDataForExcel()));
	}
	
	/**
	 * Establece la descripción del tipo de anexo en función de su código
	 * para mostrarla en el grid de búsqueda de tipos de anexo
	 */
	public String obtenerDescripcionTipoAnexo(String tipoAnex){
		
		String descripcion = Constantes.CADENA_VACIA;

		if(Constantes.TIPOANEXO_OPERACION.equalsIgnoreCase(tipoAnex)){
			descripcion = Constantes.TIPOANEXO_DESCR_OPERACION;
		} else if(Constantes.TIPOANEXO_CONFIRMACION.equalsIgnoreCase(tipoAnex)){
			descripcion = Constantes.TIPOANEXO_DESCR_CONFIRMACION;
		} else if(Constantes.TIPOANEXO_CUENTA.equalsIgnoreCase(tipoAnex)){
			descripcion = Constantes.TIPOANEXO_DESCR_CUENTA;
		} else if (Constantes.TIPOANEXO_PRECONFIRMACION.equalsIgnoreCase(tipoAnex)) {
			descripcion = Constantes.TIPOANEXO_DESCR_PRECONFIRMACION;
		} else if (Constantes.TIPOANEXO_LIQUIDACION.equalsIgnoreCase(tipoAnex)) {
			descripcion = Constantes.TIPOANEXO_DESCR_LIQUIDACION ;
		} else if (Constantes.TIPOANEXO_RECLAMACION.equalsIgnoreCase(tipoAnex)) {
			descripcion = Constantes.TIPOANEXO_DESCR_RECLAMACION;
		}
								
		
		
		
		return descripcion;
	}
	
	/** ##### FIN BÚSQUEDA ##### */
	
	/** ##### MÉTODOS PARA GESTIONAR LAS ACCIONES DE PANTALLA ##### */
	
	/**
	 * No se puede dar de baja un registro con un usuario que no sea el mismo que accede.
	 * Si venimos de Operación no se puede dar de baja un registro si es del tipo Confirmacion.
	 */
	public boolean borrarValidator(){
		
		boolean esCorrecto = true;
		AnexoOperacion anexo = this.getAnexoOperacion();
		
		//Se comprueba el usuario
		if(Identity.instance().getCredentials().getUsername().equals(anexo.getUsuario())){
			//Se comprueba el tipo de anexo
			if(anexosPantalla.isVieneOperaciones() && 
					( Constantes.TIPOANEXO_CONFIRMACION.equalsIgnoreCase(anexo.getTipoAnex()) ||  
					Constantes.TIPOANEXO_RECLAMACION.equalsIgnoreCase(anexo.getTipoAnex()) )
			){
				esCorrecto = false;
				statusMessages.add(Severity.ERROR, "#{messages['anexos.error.notipooper']}");
			}
		} else {
			esCorrecto = false;
			statusMessages.add(Severity.ERROR, "#{messages['anexos.error.nobaja']}");
		}
		
		return esCorrecto;
	}
	
	/** Borra un ANEXO */
	public void borrar() {
		anexoOperacionBo.baja(anexoOperacion);
		entityManager.flush();
		refrescarLista();
		if (anexosPantalla.isVieneConfirmaciones()){
			if (!GenericUtils.isNullOrBlank(confirmacion)){
				confirmacion.setAnexoGrabado(true);
			}
		}
		
	}
	
	/**
	 * Validaciones previas al alta de anexos
	 */
	public boolean nuevoValidator(){
		
		boolean esCorrecto = true;
		
		if(GenericUtils.isNullOrBlank(anexosPantalla.getTipoAnexo())){
			esCorrecto = false;
			statusMessages.addToControl("tipoAnexoCombo",Severity.ERROR,"#{messages['anexos.error.noedicion']}");
		} else {
			
			if(Constantes.TIPOANEXO_CONFIRMACION.equals(anexosPantalla.getTipoAnexo()) && anexosPantalla.isVieneOperaciones()){
				esCorrecto = false;
				statusMessages.addToControl("tipoAnexoCombo",Severity.ERROR,"#{messages['anexos.error.notipooper']}");
			} else if (Constantes.TIPOANEXO_RECLAMACION.equals(anexosPantalla.getTipoAnexo()) 
					&& anexosPantalla.isVieneOperaciones()){
			
				esCorrecto = false;
				statusMessages.addToControl("tipoAnexoCombo",Severity.ERROR,"#{messages['anexos.error.notipooper']}");
			
			} else if(!(Constantes.TIPOANEXO_CONFIRMACION.equals(anexosPantalla.getTipoAnexo()) 
					|| Constantes.TIPOANEXO_RECLAMACION.equals(anexosPantalla.getTipoAnexo())) 
					&& anexosPantalla.isVieneConfirmaciones()){
				esCorrecto = false;
				statusMessages.addToControl("tipoAnexoCombo",Severity.ERROR,"#{messages['anexos.error.notipoconfir']}");
			} else if (!Constantes.TIPOANEXO_PRECONFIRMACION.equals(anexosPantalla.getTipoAnexo()) && anexosPantalla.isVienePreConfirmaciones()){
				esCorrecto = false;
				statusMessages.addToControl("tipoAnexoCombo",Severity.ERROR,"#{messages['anexos.error.notipopre']}");
			} else if (!Constantes.TIPOANEXO_LIQUIDACION.equals(anexosPantalla.getTipoAnexo()) && anexosPantalla.isVieneLiquidaciones()){
				esCorrecto = false;
				statusMessages.addToControl("tipoAnexoCombo",Severity.ERROR,"#{messages['anexos.error.notipoliquidacion']}");
			}
		
		
			
		}
		
		
		return esCorrecto;
	}
	
	/** Prepara para entrar en el modo creación de un anexo */
	public String nuevo() {
		
		String retorno = MANTENIMIENTO;
		
		// Instanciamos el nuevo anexo con los valores por defecto
		AnexoOperacion nuevoAnexo = new AnexoOperacion();
		AnexoOperacionId nuevoId = new AnexoOperacionId();
		nuevoId.setOperacionID(anexosPantalla.getIdOperacion());
		nuevoId.setFechaContratacion(anexosPantalla.getFechaContratacion());
		nuevoAnexo.setId(nuevoId);
		nuevoAnexo.setTipoAnex(anexosPantalla.getTipoAnexo());
		
		if(anexosPantalla.isVieneConfirmaciones()){
			nuevoAnexo.setCodConfi(anexosPantalla.getNumConfirmacion());
		}
		
		nuevoAnexo.setUsuario(Identity.instance().getCredentials().getUsername());
		
		//Vacíamos campos del archivo adjunto y del número de cuenta
		limpiarAdjuntos();
		limpiarValoresCuenta();
		limpiarOperaciones();
		
		if (observaciones!=null && Constantes.TIPOANEXO_PRECONFIRMACION.equals(anexosPantalla.getTipoAnexo())){
			nuevoAnexo.setTextAnex(observaciones);
		}
		
		if (fechaLiquidacion2!=null && Constantes.TIPOANEXO_LIQUIDACION.equals(anexosPantalla.getTipoAnexo())){
			nuevoAnexo.setFechaAnex(fechaLiquidacion2);
		}
		
		this.anexoOperacion = nuevoAnexo;

		this.setModoPantalla(ModoPantalla.CREACION);
		
		if(Constantes.TIPOANEXO_CUENTA.equalsIgnoreCase(anexosPantalla.getTipoAnexo())){
			retorno = CUENTA;
		}
		
		return retorno;
	}
	
	/**
	 * Validaciones previas a la modificación de un anexo
	 */
	public boolean editarValidator() {
		
		boolean esCorrecto = true;
		
		if(Constantes.TIPOANEXO_CONFIRMACION.equals(anexoOperacionSelec.getTipoAnex()) && anexosPantalla.isVieneOperaciones()){
			esCorrecto = false;
			statusMessages.addToControl("tipoAnexoCombo",Severity.ERROR,"#{messages['anexos.error.notipooper']}");
		
		} else if (Constantes.TIPOANEXO_RECLAMACION.equals(anexosPantalla.getTipoAnexo()) 
				&& anexosPantalla.isVieneOperaciones()){
		
			esCorrecto = false;
			statusMessages.addToControl("tipoAnexoCombo",Severity.ERROR,"#{messages['anexos.error.notipooper']}");
		
		} else if(!(Constantes.TIPOANEXO_CONFIRMACION.equals(anexosPantalla.getTipoAnexo()) 
				|| Constantes.TIPOANEXO_RECLAMACION.equals(anexosPantalla.getTipoAnexo()))  
				&& anexosPantalla.isVieneConfirmaciones()){
				esCorrecto = false;
				statusMessages.addToControl("tipoAnexoCombo",Severity.ERROR,"#{messages['anexos.error.notipoconfir']}");
		} else if (!Constantes.TIPOANEXO_PRECONFIRMACION.equals(anexosPantalla.getTipoAnexo()) && anexosPantalla.isVienePreConfirmaciones()){
			esCorrecto = false;
			statusMessages.addToControl("tipoAnexoCombo",Severity.ERROR,"#{messages['anexos.error.notipopre']}");
		} else if (!Constantes.TIPOANEXO_LIQUIDACION.equals(anexosPantalla.getTipoAnexo()) && anexosPantalla.isVieneLiquidaciones()){
			esCorrecto = false;
			statusMessages.addToControl("tipoAnexoCombo",Severity.ERROR,"#{messages['anexos.error.notipoliquidacion']}");
		}
			
		return esCorrecto;
	}
	
	/** Prepara para entrar en el modo edición de un anexo */
	public String editar() {
		
		String retorno = MANTENIMIENTO;
		this.anexoOperacion = this.anexoOperacionSelec;
		this.setModoPantalla(ModoPantalla.EDICION);
		cargarValoresArchAdjunto();
		
		// Guardamos el id del anexo, necesario si queremos hacer update
		anexosPantalla.setAnexoOperacionIdOld(anexoOperacion.getId());
				
		if(anexosPantalla.isVieneOperaciones() && Constantes.TIPOANEXO_CUENTA.equalsIgnoreCase(anexoOperacion.getTipoAnex())){
			
			//Cargamos los valores para la pantalla de anexos cuenta
			limpiarValoresCuenta();
			cargarValoresCuenta();
			
			retorno = CUENTA;
		}
		
		return retorno;
		
	}
	
	/**
	 * Prepara para entrar en el modo de inspección de un anexo
	 */
	public String ver(){
		
		String retorno = MANTENIMIENTO;
		
		this.anexoOperacion = this.anexoOperacionSelec;
		
		this.setModoPantalla(ModoPantalla.INSPECCION);
		cargarValoresArchAdjunto();
		
		if(anexosPantalla.isVieneOperaciones() && Constantes.TIPOANEXO_CUENTA.equalsIgnoreCase(anexoOperacion.getTipoAnex())){
			
			//Cargamos los valores para la pantalla de anexos cuenta
			limpiarValoresCuenta();
			cargarValoresCuenta();			
			retorno = CUENTA;
		}
		
		return retorno;
	}
	
	/**
	 * Actualiza la lista del grid de anexos y vuelve a la pantalla de búsqueda
	 */
	public void salirDetalle() {
		paginationData.reset();
		/** Limpiamos la información de paginación */
		if (this.modoPantalla.equals(ModoPantalla.EDICION)) {
			refrescarLista();
		}
	}
	
	/**
	 * A partir del campo textanex se obtienen los valores para entidad, grupo contable, check
	 * y número de cuenta a mostrar en la pantalla de detalle de anexos cuenta
	 */
	private void cargarValoresCuenta(){
		
		String texto = anexoOperacionSelec.getTextAnex();
		
		if (!GenericUtils.isNullOrBlank(texto)) {
			if (!anexoOperacion.getTextAnex().startsWith("                      ")){
				String entidad = texto.substring(0, 4);
				anexosPantalla.setEntidadPago(entidad);
				String grupoCon = texto.substring(4, 6);
				anexosPantalla.setGrupoContablePago(grupoCon);
				Short ofi = Short.parseShort(texto.substring(6, 10));
				anexosPantalla.setOficinaPago(ofi);
				String cuenta = texto.substring(10, 20);
				anexosPantalla.setNumcuentaPago(cuenta);
				String check = texto.substring(20, 22);
				anexosPantalla.setCheckPago(check);
			}
			if (texto.length()==44){
				String entidadC = texto.substring(22, 26);
				anexosPantalla.setEntidadCobro(entidadC);
				String grupoConC = texto.substring(26, 28);
				anexosPantalla.setGrupoContableCobro(grupoConC);
				Short ofiC = Short.parseShort(texto.substring(28, 32));
				anexosPantalla.setOficinaCobro(ofiC);
				String cuentaC = texto.substring(32, 42);
				anexosPantalla.setNumcuentaCobro(cuentaC);
				String checkC = texto.substring(42, 44);
				anexosPantalla.setCheckCobro(checkC);
			}
		
		}
	}
	
	/**
	 * Vacía los valores introducidos en la pantalla de detalle de anexo cuenta
	 */
	private void limpiarValoresCuenta(){
		anexosPantalla.setEntidadPago(null);
		anexosPantalla.setGrupoContablePago(null);
		anexosPantalla.setOficinaPago(null);
		anexosPantalla.setNumcuentaPago(null);
		anexosPantalla.setCheckPago(null);

		anexosPantalla.setEntidadCobro(null);
		anexosPantalla.setGrupoContableCobro(null);
		anexosPantalla.setOficinaCobro(null);
		anexosPantalla.setNumcuentaCobro(null);
		anexosPantalla.setCheckCobro(null);

	}
	
	/**
	 * Carga en memoria los valores del archivo adjunto al anexo
	 */
	private void cargarValoresArchAdjunto(){
		
		anexosPantalla.setArchivoAdjunto(anexoOperacion.getArchiadj());
		anexosPantalla.setFileName(anexoOperacion.getFileName());
		anexosPantalla.setFileSize(anexoOperacion.getFileSize());
		anexosPantalla.setContentType(anexoOperacion.getMimeType());
	}
	
	
	
	public boolean guardarDetalleValidator(){
		
		boolean esCorrecto = true;
		Operacion oper=null;
		operacionesList = new ArrayList<Operacion>();
		
		if (anexosPantalla.isMultOperaciones()){
			
			Long operacionAComprobar = anexosPantalla.getOperacion1();
			
			if (!GenericUtils.isNullOrBlank(operacionAComprobar)){
				oper = anexoOperacionBo.obtenerOperacion(operacionAComprobar);
				if (GenericUtils.isNullOrBlank(oper)){
					statusMessages.addFromResourceBundle(Severity.ERROR, "anexos.noEncuentraOper", operacionAComprobar.toString());
					esCorrecto = false;
				}else{
					operacionesList.add(oper);
				}
			}
		
			operacionAComprobar = anexosPantalla.getOperacion2();
			
			if (!GenericUtils.isNullOrBlank(operacionAComprobar)){
				oper = anexoOperacionBo.obtenerOperacion(operacionAComprobar);
				if (GenericUtils.isNullOrBlank(oper)){
					statusMessages.addFromResourceBundle(Severity.ERROR, "anexos.noEncuentraOper", operacionAComprobar.toString());
					esCorrecto = false;
				}else{
					operacionesList.add(oper);
				}
			}
		
			operacionAComprobar = anexosPantalla.getOperacion3();
			
			if (!GenericUtils.isNullOrBlank(operacionAComprobar)){
				oper = anexoOperacionBo.obtenerOperacion(operacionAComprobar);
				if (GenericUtils.isNullOrBlank(oper)){
					statusMessages.addFromResourceBundle(Severity.ERROR, "anexos.noEncuentraOper", operacionAComprobar.toString());
					esCorrecto = false;
				}else{
					operacionesList.add(oper);
				}
			}
		
			
			operacionAComprobar = anexosPantalla.getOperacion4();
			
			if (!GenericUtils.isNullOrBlank(operacionAComprobar)){
				oper = anexoOperacionBo.obtenerOperacion(operacionAComprobar);
				if (GenericUtils.isNullOrBlank(oper)){
					statusMessages.addFromResourceBundle(Severity.ERROR, "anexos.noEncuentraOper", operacionAComprobar.toString());
					esCorrecto = false;
				}else{
					operacionesList.add(oper);
				}
			}
		
			
			operacionAComprobar = anexosPantalla.getOperacion5();
			
			if (!GenericUtils.isNullOrBlank(operacionAComprobar)){
				oper = anexoOperacionBo.obtenerOperacion(operacionAComprobar);
				if (GenericUtils.isNullOrBlank(oper)){
					statusMessages.addFromResourceBundle(Severity.ERROR, "anexos.noEncuentraOper", operacionAComprobar.toString());
					esCorrecto = false;
				}else{
					operacionesList.add(oper);
				}
			}
		
			
			operacionAComprobar = anexosPantalla.getOperacion6();
			
			if (!GenericUtils.isNullOrBlank(operacionAComprobar)){
				oper = anexoOperacionBo.obtenerOperacion(operacionAComprobar);
				if (GenericUtils.isNullOrBlank(oper)){
					statusMessages.addFromResourceBundle(Severity.ERROR, "anexos.noEncuentraOper", operacionAComprobar.toString());
					esCorrecto = false;
				}else{
					operacionesList.add(oper);
				}
			}
		
			
			operacionAComprobar = anexosPantalla.getOperacion7();
			
			if (!GenericUtils.isNullOrBlank(operacionAComprobar)){
				oper = anexoOperacionBo.obtenerOperacion(operacionAComprobar);
				if (GenericUtils.isNullOrBlank(oper)){
					statusMessages.addFromResourceBundle(Severity.ERROR, "anexos.noEncuentraOper", operacionAComprobar.toString());
					esCorrecto = false;
				}else{
					operacionesList.add(oper);
				}
			}
		
			
			operacionAComprobar = anexosPantalla.getOperacion8();
			
			if (!GenericUtils.isNullOrBlank(operacionAComprobar)){
				oper = anexoOperacionBo.obtenerOperacion(operacionAComprobar);
				if (GenericUtils.isNullOrBlank(oper)){
					statusMessages.addFromResourceBundle(Severity.ERROR, "anexos.noEncuentraOper", operacionAComprobar.toString());
					esCorrecto = false;
				}else{
					operacionesList.add(oper);
				}
			}
		
			
			operacionAComprobar = anexosPantalla.getOperacion9();
			
			if (!GenericUtils.isNullOrBlank(operacionAComprobar)){
				oper = anexoOperacionBo.obtenerOperacion(operacionAComprobar);
				if (GenericUtils.isNullOrBlank(oper)){
					statusMessages.addFromResourceBundle(Severity.ERROR, "anexos.noEncuentraOper", operacionAComprobar.toString());
					esCorrecto = false;
				}else{
					operacionesList.add(oper);
				}
			}
		
			
			operacionAComprobar = anexosPantalla.getOperacion10();
			
			if (!GenericUtils.isNullOrBlank(operacionAComprobar)){
				oper = anexoOperacionBo.obtenerOperacion(operacionAComprobar);
				if (GenericUtils.isNullOrBlank(oper)){
					statusMessages.addFromResourceBundle(Severity.ERROR, "anexos.noEncuentraOper", operacionAComprobar.toString());
					esCorrecto = false;
				}else{
					operacionesList.add(oper);
				}
			}
		
		
		}
		
		return esCorrecto;
	}
	
	public boolean guardarDetalleAltaValidator(){
		return guardarDetalleValidator();
	}
	public void guardarDetalleAlta(){
		guardarDetalle();
		limpiarAdjuntos();
		limpiarOperaciones();
		generarNuevoAnexo();
		
	}
	
	private void generarNuevoAnexo() {
		AnexoOperacion anex = new AnexoOperacion(new AnexoOperacionId(anexoOperacion.getId().getOperacionID(), 
				anexoOperacion.getId().getFechaContratacion(), new Date()), 
				anexoOperacion.getFechaAnex(), anexoOperacion.getTipoAnex(), anexoOperacion.getCodConfi(), anexoOperacion.getTextAnex(), 
				anexoOperacion.getUsuario(), null, anexoOperacion.getEstructu(), null, null, null);

		anexoOperacion = anex;
	}

	/**
	 * Guarda el anexo de operación/confirmación en base de datos
	 */
	public String guardarDetalle(){
		
		String retorno = Constantes.CADENA_VACIA;
		
		// Actualizamos datos de archivo adjunto
		anexoOperacion.setArchiadj(anexosPantalla.getArchivoAdjunto());
		anexoOperacion.setFileName(anexosPantalla.getFileName());
		anexoOperacion.setMimeType(anexosPantalla.getContentType());
		anexoOperacion.setFileSize(anexosPantalla.getFileSize());
		
		//alta
		if(ModoPantalla.CREACION.equals(modoPantalla)){
			
//			
//			
//			AuditData auditor = new AuditData();
//			AnexoOperacionId id = new AnexoOperacionId(anexoOperacion.getId().getOperacionID(), anexoOperacion.getId().getFechaContratacion(), new Date());
//			AnexoOperacion anexoNuevo = new AnexoOperacion(id);
//			anexoNuevo.setArchiadj(anexosPantalla.getArchivoAdjunto());
//			anexoNuevo.setFileName(anexosPantalla.getFileName());
//			anexoNuevo.setMimeType(anexosPantalla.getContentType());
//			anexoNuevo.setFileSize(anexosPantalla.getFileSize());
//			anexoNuevo.setFechaAnex(anexoOperacion.getFechaAnex());
//			anexoNuevo.setCodConfi(anexoOperacion.getCodConfi());
//			anexoNuevo.setTipoAnex(anexoOperacion.getTipoAnex());
//			anexoNuevo.setTextAnex(anexoOperacion.getTextAnex());
//			anexoNuevo.setUsuario(anexoOperacion.getUsuario());
//			anexoNuevo.setEstructu(anexoOperacion.getEstructu());
//			auditor.setUsuarioUltimaModi(Identity.instance().getCredentials().getUsername());
//			auditor.setFechaUltimaModi(id.getFechaModificacion());
//			anexoNuevo.setAuditData(auditor);
			
			
			if(!anexoOperacionBo.insertar(anexoOperacion)){
				statusMessages.add(Severity.ERROR, "#{messages['anexos.error.guardar']}");
			}else{
				
				if (anexosPantalla.isVieneConfirmaciones()){
					if (!GenericUtils.isNullOrBlank(confirmacion)){
						confirmacion.setAnexoGrabado(true);
					}
				}
				
				if (anexosPantalla.isMultOperaciones() && !GenericUtils.isNullOrBlank(operacionesList) 
						&& operacionesList.size()>0){
					
					AnexoOperacion operacionesAnexas = null;
					for (Operacion oper : operacionesList) {
						operacionesAnexas = new AnexoOperacion(new AnexoOperacionId(oper.getId().getNumeroOperacion(), oper.getId().getFechaContratacion(), new Date()), 
								anexoOperacion.getFechaAnex(),anexoOperacion.getTipoAnex(), null, anexoOperacion.getTextAnex(), 
								Identity.instance().getCredentials().getUsername(), anexosPantalla.getArchivoAdjunto(), 
								null, anexosPantalla.getFileName(), anexosPantalla.getFileSize(), anexosPantalla.getContentType());
						
//						anexoOperacion.getId().setOperacionID( oper.getId().getNumeroOperacion());
//						anexoOperacion.getId().setFechaContratacion(oper.getId().getFechaContratacion());
						//anexoOperacion.setId(new AnexoOperacionId(oper.getId().getNumeroOperacion(), oper.getId().getFechaContratacion(), new Date()));
						
						if(!anexoOperacionBo.insertar(operacionesAnexas)){
							statusMessages.addFromResourceBundle(Severity.ERROR, "anexos.error.guardarOper", oper.getId().getNumeroOperacion());
						}
					
					}
				}
					
			}
			
			retorno = Constantes.TIPOANEXO_MODO_A;

//			anexoOperacionBo.recargar(anexoNuevo);
			
		} else if(ModoPantalla.EDICION.equals(modoPantalla)){	//edicion
			if(!anexoOperacionBo.guardar(anexoOperacion, anexosPantalla.getAnexoOperacionIdOld())){
				statusMessages.add(Severity.ERROR, "#{messages['anexos.error.guardar']}");
			}else{
				if (anexosPantalla.isVieneConfirmaciones()){
					if (!GenericUtils.isNullOrBlank(confirmacion)){
						confirmacion.setAnexoGrabado(true);
					}
				}
			}
			retorno = Constantes.TIPOANEXO_MODO_E;
			//Hay que recargar el registro en el grid porque se puede modificar la PK del registro
			anexoOperacionBo.recargar(anexoOperacion);
		}
		
		paginationData.reset();
		refrescarLista();
		return retorno;
		
	}
	
	/**
	 * Valida que si se ha informado alguno de los campos de la cuenta
	 * se informen todos
	 */
	public boolean guardarCuentaValidator(){
		
		boolean esCorrecto = true;

		boolean entidadInformada = !GenericUtils.isNullOrBlank(anexosPantalla.getEntidadPago());
		boolean grupoContInformado = !GenericUtils.isNullOrBlank(anexosPantalla.getGrupoContablePago());
		boolean oficinaInformada = !GenericUtils.isNullOrBlank(anexosPantalla.getOficinaPago());
		boolean numCuentaInformado = !GenericUtils.isNullOrBlank(anexosPantalla.getNumcuentaPago());
		boolean checkInformado = !GenericUtils.isNullOrBlank(anexosPantalla.getCheckPago());
			
		//Todos los campos deben ser informados, o ninguno informado
		if(entidadInformada
				|| grupoContInformado
				|| oficinaInformada
				|| numCuentaInformado
				|| checkInformado){
			//Hay alguno informado
			if(!entidadInformada
					|| !grupoContInformado
					|| !oficinaInformada
					|| !numCuentaInformado
					|| !checkInformado){
				//Hay algunos informados y algunos no informados
				esCorrecto = false;
				statusMessages.add(Severity.ERROR, "#{messages['anexos.cuenta.obligatorios']}");
			}
		}
		
		
		

		entidadInformada = !GenericUtils.isNullOrBlank(anexosPantalla.getEntidadCobro());
		grupoContInformado = !GenericUtils.isNullOrBlank(anexosPantalla.getGrupoContableCobro());
		oficinaInformada = !GenericUtils.isNullOrBlank(anexosPantalla.getOficinaCobro());
		numCuentaInformado = !GenericUtils.isNullOrBlank(anexosPantalla.getNumcuentaCobro());
		checkInformado = !GenericUtils.isNullOrBlank(anexosPantalla.getCheckCobro());
			
		//Todos los campos deben ser informados, o ninguno informado
		if(entidadInformada
				|| grupoContInformado
				|| oficinaInformada
				|| numCuentaInformado
				|| checkInformado){
			//Hay alguno informado
			if(!entidadInformada
					|| !grupoContInformado
					|| !oficinaInformada
					|| !numCuentaInformado
					|| !checkInformado){
				//Hay algunos informados y algunos no informados
				esCorrecto = false;
				statusMessages.add(Severity.ERROR, "#{messages['anexos.cuenta.obligatorios']}");
			}
		}
		
		
		
		//Volvemos a comprobar oficina
		if (!GenericUtils.isNullOrBlank(anexosPantalla.getOficinaPago())
				&&  GenericUtils.isNullOrBlank(anexoOperacionBo.validarOficina(anexosPantalla.getOficinaPago()))){
			esCorrecto = false;
			statusMessages.addToControl("oficinaTxtPago", Severity.ERROR, "#{messages['anexos.error.oficina']}");
		}
		
		//Comprobamos la existencia de la cuenta
		if (!GenericUtils.isNullOrBlank(anexosPantalla.getNumcuentaPago())
				&& !anexoOperacionBo.validarCuenta(anexosPantalla.getNumcuentaPago())){
			esCorrecto = false;
			statusMessages.addToControl("cuentaTxtPago", Severity.ERROR, "#{messages['anexos.error.cuenta']}");
		}
		
		
		if (!GenericUtils.isNullOrBlank(anexosPantalla.getOficinaCobro())
				&&  GenericUtils.isNullOrBlank(anexoOperacionBo.validarOficina(anexosPantalla.getOficinaCobro()))){
			esCorrecto = false;
			statusMessages.addToControl("oficinaTxtCobro", Severity.ERROR, "#{messages['anexos.error.oficina']}");
		}
		
		//Comprobamos la existencia de la cuenta
		if (!GenericUtils.isNullOrBlank(anexosPantalla.getNumcuentaCobro())
				&& !anexoOperacionBo.validarCuenta(anexosPantalla.getNumcuentaCobro())){
			esCorrecto = false;
			statusMessages.addToControl("cuentaTxtCobro", Severity.ERROR, "#{messages['anexos.error.cuenta']}");
		}
		
		return esCorrecto;
	}
	
	/**
	 * Guarda el anexo de cuenta en base de datos
	 */
	public String guardarCuenta(){
		
		//Comprobamos que se hayan rellenado los campos del múmero de cuenta
		//Basta con comprobar uno de ellos ya que se valida antes que se
		//informen todos o ninguno
		if (!GenericUtils.isNullOrBlank(anexosPantalla.getNumcuentaPago())) {
			/** Construimos textanex a partir de los valores introducidos en entidad, oficina, etc */
			StringBuilder sb = new StringBuilder();
			sb.append(lpad(anexosPantalla.getEntidadPago(), 4, '0'));
			sb.append(lpad(anexosPantalla.getGrupoContablePago(), 2, '0'));
			sb.append(lpad(String.valueOf(anexosPantalla.getOficinaPago()), 4, '0'));
			sb.append(lpad(anexosPantalla.getNumcuentaPago(), 10, '0'));
			sb.append(lpad(anexosPantalla.getCheckPago(), 2, '0'));
			anexoOperacion.setTextAnex(sb.toString());
		}else{
			anexoOperacion.setTextAnex("                      ");
		}
		
		if (!GenericUtils.isNullOrBlank(anexosPantalla.getNumcuentaCobro())) {
			/** Construimos textanex a partir de los valores introducidos en entidad, oficina, etc */
			StringBuilder sb = new StringBuilder();
			sb.append(lpad(anexosPantalla.getEntidadCobro(), 4, '0'));
			sb.append(lpad(anexosPantalla.getGrupoContableCobro(), 2, '0'));
			sb.append(lpad(String.valueOf(anexosPantalla.getOficinaCobro()), 4, '0'));
			sb.append(lpad(anexosPantalla.getNumcuentaCobro(), 10, '0'));
			sb.append(lpad(anexosPantalla.getCheckCobro(), 2, '0'));
			
			anexoOperacion.setTextAnex(anexoOperacion.getTextAnex().concat(sb.toString()));	
			
			
		}

		
		return guardarDetalle();

	}
	
	/**
	 * Valida si la oficina introducida por el usuario existe.
	 * Si existe, actualiza el valor de la Entidad
	 * Si no, muestra mensaje de error
	 */
	public void validarOficinaPago(){
		
		
		if (!GenericUtils.isNullOrBlank(anexosPantalla.getOficinaPago())) {
			Oficina ofi = anexoOperacionBo.validarOficina(anexosPantalla.getOficinaPago());
			if (GenericUtils.isNullOrBlank(ofi)) {
				//Si no existe la oficina, mostrar mensaje de error
				statusMessages.addToControl("oficinaTxtPago", Severity.ERROR, "#{messages['anexos.error.oficina']}");
			} else {
				//Si existe, cambiamos el valor seleccionado en entidad si está en el combo
				List<String> listaEntidades = anexoOperacionBo.obtenerEntidadesSelect(Constantes.NOMBRE_PROYECTO_DERI);
				
				if (listaEntidades.contains(String.valueOf(ofi.getEmpresa())) || listaEntidades.contains(lpad(String.valueOf(ofi.getEmpresa()), 4, '0'))){
					anexosPantalla.setEntidadPago(lpad(String.valueOf(ofi.getEmpresa()), 4, '0') );
				}
			}
		}
	}

	/**
	 * Valida si la oficina introducida por el usuario existe.
	 * Si existe, actualiza el valor de la Entidad
	 * Si no, muestra mensaje de error
	 */
	public void validarOficinaCobro(){
		
		
		if (!GenericUtils.isNullOrBlank(anexosPantalla.getOficinaCobro())) {
			Oficina ofi = anexoOperacionBo.validarOficina(anexosPantalla.getOficinaCobro());
			if (GenericUtils.isNullOrBlank(ofi)) {
				//Si no existe la oficina, mostrar mensaje de error
				statusMessages.addToControl("oficinaTxtCobro", Severity.ERROR, "#{messages['anexos.error.oficina']}");
			} else {
				//Si existe, cambiamos el valor seleccionado en entidad si está en el combo
				List<String> listaEntidades = anexoOperacionBo.obtenerEntidadesSelect(Constantes.NOMBRE_PROYECTO_DERI);
				
				if (listaEntidades.contains(String.valueOf(ofi.getEmpresa())) || listaEntidades.contains(lpad(String.valueOf(ofi.getEmpresa()), 4, '0'))){
					anexosPantalla.setEntidadCobro(lpad(String.valueOf(ofi.getEmpresa()), 4, '0') );
				}
			}
		}
	}

	
	/**
	 * Función que añade caracteres a la izquierda de un string recibido 
	 * como argumento. Añade tantos caracteres como sean necesarios para
	 * que la longitud del string finals ea igual a la recibida como argumento.
	 * El caracter a añadir también se recibe como argumento.
	 * @param origen: string original
	 * @param longitud: longitud final del string
	 * @param caracter: caracter a añadir a la izquierda del string
	 * @return String modificado
	 */
	private String lpad(String origen, int longitud, char caracter){
		
		String aux = origen;
		
		while (aux.length() < longitud){
			aux = caracter + aux;
		}
		
		return aux;
	}
	
	/**
	 * Abre el fichero adjunto a un anexo para su visualización
	 */
	public void verFicheroAdjunto(){
		if (anexosPantalla.getArchivoAdjunto()==null){
			statusMessages.addFromResourceBundle(Severity.ERROR, "anexos.sinadjuntos", anexosPantalla.getFileName());
		}else{
		
			FacesContext context = FacesContext.getCurrentInstance();
			HttpServletResponse response = (HttpServletResponse)extCtx.getResponse();
			response.setContentType(anexosPantalla.getContentType());
			response.addHeader("Content-disposition", "attachment; filename=" + File.separator + anexosPantalla.getFileName());

			try {
				ServletOutputStream os = response.getOutputStream();
				os.write(anexosPantalla.getArchivoAdjunto());
				os.flush();
				os.close();
				context.responseComplete();
			} catch(Exception e) {
				statusMessages.addFromResourceBundle(Severity.ERROR, "anexos.error.abrirarchivo", anexosPantalla.getFileName());
				log.error("\nFailure : " + e.toString() + "\n");
			}
		
		}
	}
	
	/** ##### FIN ACCIONES DE PANTALLA ##### */
	
	/** ##### UPLOAD LISTENER ##### */
	
	/**
	 * Función para gestionar el upload de ficheros adjuntos
	 */
	public void uploadFile(UploadEvent event) throws IOException{
		
		UploadItem item = event.getUploadItem();

        String name = Constantes.CADENA_VACIA;
        int fileSize = -1;
        byte[] data = null;
        String contentType = Constantes.CADENA_VACIA;
               
        if (item.isTempFile()) {
            name = item.getFileName().substring(item.getFileName().lastIndexOf(File.separator) + 1);
       		fileSize = item.getFileSize();
            contentType = item.getContentType();
            
            InputStream is = new FileInputStream(item.getFile());
            
            // Creamos el array de byte para guardar los datos
            data = new byte[fileSize];
            
            // Leemos los bytes
            int offset = 0;
            int numRead = 0;
            while (offset < data.length
                   && (numRead=is.read(data, offset, data.length-offset)) >= 0) {
                offset += numRead;
            }
            
            if (offset < data.length) {
                throw new IOException("No se pudo leer el fichero "+ name);
            }
            
            // Cerramos el inputstream
            is.close();
            anexosPantalla.setArchivoAdjunto(data);
            anexosPantalla.setFileName(name);
            anexosPantalla.setContentType(contentType);
            anexosPantalla.setFileSize(Long.valueOf(fileSize));
        } else {
        	statusMessages.add(Severity.ERROR,"#{messages['anexos.error.noarchivo']}");
        }
	}
	
	/**
	 * Limpia el archivo adjunto al anexo
	 */
	public void limpiarAdjuntos(){
		anexosPantalla.setArchivoAdjunto(null);
		anexosPantalla.setFileName(null);
        anexosPantalla.setContentType(null);
        anexosPantalla.setFileSize(null);
	}
	
	/** ##### FIN UPLOAD ##### */
	
	@Override
	public List<?> getDataTableList() {
		return this.anexosOperList;
	}

	@SuppressWarnings("unchecked")
	@Override
	public void setDataTableList(List<?> dataTableList) {
		this.anexosOperList = (List<AnexoOperacion>)dataTableList;
	}

	public String salirAnexos(){
		//flm seimpre debemos volver al anterior y punto
		Conversation conversacion=Conversation.instance();
		conversacion.end();
		conversacion.redirectToParent();
		return tipoAnexo;
	}



	public List<AnexoOperacion> getAnexosOperList() {
		return anexosOperList;
	}



	public void setAnexosOperList(List<AnexoOperacion> anexosOperList) {
		this.anexosOperList = anexosOperList;
	}



	public AnexoOperacion getAnexoOperacionSelec() {
		return anexoOperacionSelec;
	}



	public void setAnexoOperacionSelec(AnexoOperacion anexoOperacionSelec) {
		this.anexoOperacionSelec = anexoOperacionSelec;
	}



	public AnexoOperacion getAnexoOperacion() {
		return anexoOperacion;
	}



	public void setAnexoOperacion(AnexoOperacion anexoOperacion) {
		this.anexoOperacion = anexoOperacion;
	}

	public EntityManager getEntityManager() {
		return entityManager;
	}

	public void setEntityManager(EntityManager entityManager) {
		this.entityManager = entityManager;
	}

	public Boolean getMantOperdirecto() {
		return mantOperdirecto;
	}

	public void setMantOperdirecto(Boolean mantOperdirecto) {
		this.mantOperdirecto = mantOperdirecto;
	}
}
