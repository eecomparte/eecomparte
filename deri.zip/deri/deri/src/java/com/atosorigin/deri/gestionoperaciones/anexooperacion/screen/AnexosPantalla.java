package com.atosorigin.deri.gestionoperaciones.anexooperacion.screen;

import java.util.Date;

import org.jboss.seam.ScopeType;
import org.jboss.seam.annotations.Name;
import org.jboss.seam.annotations.Scope;

import com.atosorigin.deri.model.gestionoperaciones.AnexoOperacionId;

/**
 * Contiene los datos de pantalla necesarios para el caso de uso de Información
 * Anexa.
 */
@Name("anexosPantalla")
@Scope(ScopeType.CONVERSATION)
public class AnexosPantalla {

	/** Criterios de selección */
	protected Date fechaInicio;
	protected Date fechaFin;
	protected boolean anexosUsuario;
	protected String tipoAnexo;
	protected boolean multOperaciones;
	
	protected Long operacion1;
	protected Long operacion2;
	protected Long  operacion3;
	protected Long operacion4;
	protected Long operacion5;
	protected Long  operacion6;
	protected Long operacion7;
	protected Long operacion8;
	protected Long  operacion9;
	protected Long operacion10;
	
	
	
	/** Necesario para el update de anexos */
	protected AnexoOperacionId anexoOperacionIdOld;
	
	/** Campos anexos cuenta */
//	protected String check;
//	protected String numcuenta;
//	protected Short oficina;
//	protected String entidad;
//	protected String grupoContable;

	
	protected String checkPago;
	protected String numcuentaPago;
	protected Short oficinaPago;
	protected String entidadPago;
	protected String grupoContablePago;
	
	protected String checkCobro;
	protected String numcuentaCobro;
	protected Short oficinaCobro;
	protected String entidadCobro;
	protected String grupoContableCobro;
	
	
	
	/** Parámetros recibidos desde Mant.Operaciones/Mant.Confirmaciones */
	protected Long idOperacion;
	protected Date fechaContratacion;
	protected Long numConfirmacion;
	
	/** Variables para saber desde dónde se accede */
	protected boolean vieneOperaciones;
	protected boolean vieneConfirmaciones;
	protected boolean vienePreConfirmaciones;
	protected boolean vieneLiquidaciones;
	
	/** Modo acceso C consulta, A alta, E edicion */
	protected String modoAcceso;
	
	protected String fileName;
	
	protected String contentType;
	
	protected Long fileSize;
	
	protected byte[] archivoAdjunto;
	
	public Date getFechaInicio() {
		return fechaInicio;
	}

	public Date getFechaFin() {
		return fechaFin;
	}

	public boolean isAnexosUsuario() {
		return anexosUsuario;
	}

	public String getTipoAnexo() {
		return tipoAnexo;
	}

	public void setFechaInicio(Date fechaInicio) {
		this.fechaInicio = fechaInicio;
	}

	public void setFechaFin(Date fechaFin) {
		this.fechaFin = fechaFin;
	}

	public void setAnexosUsuario(boolean anexosUsuario) {
		this.anexosUsuario = anexosUsuario;
	}

	public void setTipoAnexo(String tipoAnexo) {
		this.tipoAnexo = tipoAnexo;
	}

	public boolean isVieneOperaciones() {
		return vieneOperaciones;
	}

	public boolean isVieneConfirmaciones() {
		return vieneConfirmaciones;
	}

	public void setVieneOperaciones(boolean vieneOperaciones) {
		this.vieneOperaciones = vieneOperaciones;
	}

	public void setVieneConfirmaciones(boolean vieneConfirmaciones) {
		this.vieneConfirmaciones = vieneConfirmaciones;
	}

	public String getModoAcceso() {
		return modoAcceso;
	}

	public void setModoAcceso(String modoAcceso) {
		this.modoAcceso = modoAcceso;
	}

	public Long getIdOperacion() {
		return idOperacion;
	}

	public Date getFechaContratacion() {
		return fechaContratacion;
	}

	public Long getNumConfirmacion() {
		return numConfirmacion;
	}

	public void setIdOperacion(Long idOperacion) {
		this.idOperacion = idOperacion;
	}

	public void setFechaContratacion(Date fechaContratacion) {
		this.fechaContratacion = fechaContratacion;
	}

	public void setNumConfirmacion(Long numConfirmacion) {
		this.numConfirmacion = numConfirmacion;
	}

//	public String getCheck() {
//		return check;
//	}
//
//	public String getNumcuenta() {
//		return numcuenta;
//	}
//
//	public Short getOficina() {
//		return oficina;
//	}
//
//	public String getEntidad() {
//		return entidad;
//	}
//
//	public String getGrupoContable() {
//		return grupoContable;
//	}
//
//	public void setCheck(String check) {
//		this.check = check;
//	}
//
//	public void setNumcuenta(String numcuenta) {
//		this.numcuenta = numcuenta;
//	}
//
//	public void setOficina(Short oficina) {
//		this.oficina = oficina;
//	}
//
//	public void setEntidad(String entidad) {
//		this.entidad = entidad;
//	}
//
//	public void setGrupoContable(String grupoContable) {
//		this.grupoContable = grupoContable;
//	}

	public String getFileName() {
		return fileName;
	}

	public String getContentType() {
		return contentType;
	}

	public Long getFileSize() {
		return fileSize;
	}

	public byte[] getArchivoAdjunto() {
		return archivoAdjunto;
	}

	public void setFileName(String fileName) {
		this.fileName = fileName;
	}

	public void setContentType(String contentType) {
		this.contentType = contentType;
	}

	public void setFileSize(Long fileSize) {
		this.fileSize = fileSize;
	}

	public void setArchivoAdjunto(byte[] archivoAdjunto) {
		this.archivoAdjunto = archivoAdjunto;
	}

	public AnexoOperacionId getAnexoOperacionIdOld() {
		return anexoOperacionIdOld;
	}

	public void setAnexoOperacionIdOld(AnexoOperacionId anexoOperacionIdOld) {
		this.anexoOperacionIdOld = anexoOperacionIdOld;
	}

	public boolean isVienePreConfirmaciones() {
		return vienePreConfirmaciones;
	}

	public void setVienePreConfirmaciones(boolean vienePreConfirmaciones) {
		this.vienePreConfirmaciones = vienePreConfirmaciones;
	}

	public boolean isVieneLiquidaciones() {
		return vieneLiquidaciones;
	}

	public void setVieneLiquidaciones(boolean vieneLiquidaciones) {
		this.vieneLiquidaciones = vieneLiquidaciones;
	}

	public boolean isMultOperaciones() {
		return multOperaciones;
	}

	public void setMultOperaciones(boolean multOperaciones) {
		this.multOperaciones = multOperaciones;
	}

	public Long getOperacion1() {
		return operacion1;
	}

	public void setOperacion1(Long operacion1) {
		this.operacion1 = operacion1;
	}

	public Long getOperacion2() {
		return operacion2;
	}

	public void setOperacion2(Long operacion2) {
		this.operacion2 = operacion2;
	}

	public Long getOperacion3() {
		return operacion3;
	}

	public void setOperacion3(Long operacion3) {
		this.operacion3 = operacion3;
	}

	public Long getOperacion4() {
		return operacion4;
	}

	public void setOperacion4(Long operacion4) {
		this.operacion4 = operacion4;
	}

	public Long getOperacion5() {
		return operacion5;
	}

	public void setOperacion5(Long operacion5) {
		this.operacion5 = operacion5;
	}

	public Long getOperacion6() {
		return operacion6;
	}

	public void setOperacion6(Long operacion6) {
		this.operacion6 = operacion6;
	}

	public Long getOperacion7() {
		return operacion7;
	}

	public void setOperacion7(Long operacion7) {
		this.operacion7 = operacion7;
	}

	public Long getOperacion8() {
		return operacion8;
	}

	public void setOperacion8(Long operacion8) {
		this.operacion8 = operacion8;
	}

	public Long getOperacion9() {
		return operacion9;
	}

	public void setOperacion9(Long operacion9) {
		this.operacion9 = operacion9;
	}

	public Long getOperacion10() {
		return operacion10;
	}

	public void setOperacion10(Long operacion10) {
		this.operacion10 = operacion10;
	}

	public String getCheckPago() {
		return checkPago;
	}

	public void setCheckPago(String checkPago) {
		this.checkPago = checkPago;
	}

	public String getNumcuentaPago() {
		return numcuentaPago;
	}

	public void setNumcuentaPago(String numcuentaPago) {
		this.numcuentaPago = numcuentaPago;
	}

	public Short getOficinaPago() {
		return oficinaPago;
	}

	public void setOficinaPago(Short oficinaPago) {
		this.oficinaPago = oficinaPago;
	}

	public String getEntidadPago() {
		return entidadPago;
	}

	public void setEntidadPago(String entidadPago) {
		this.entidadPago = entidadPago;
	}

	public String getGrupoContablePago() {
		return grupoContablePago;
	}

	public void setGrupoContablePago(String grupoContablePago) {
		this.grupoContablePago = grupoContablePago;
	}

	public String getCheckCobro() {
		return checkCobro;
	}

	public void setCheckCobro(String checkCobro) {
		this.checkCobro = checkCobro;
	}

	public String getNumcuentaCobro() {
		return numcuentaCobro;
	}

	public void setNumcuentaCobro(String numcuentaCobro) {
		this.numcuentaCobro = numcuentaCobro;
	}

	public Short getOficinaCobro() {
		return oficinaCobro;
	}

	public void setOficinaCobro(Short oficinaCobro) {
		this.oficinaCobro = oficinaCobro;
	}

	public String getEntidadCobro() {
		return entidadCobro;
	}

	public void setEntidadCobro(String entidadCobro) {
		this.entidadCobro = entidadCobro;
	}

	public String getGrupoContableCobro() {
		return grupoContableCobro;
	}

	public void setGrupoContableCobro(String grupoContableCobro) {
		this.grupoContableCobro = grupoContableCobro;
	}

}
