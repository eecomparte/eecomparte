package com.atosorigin.deri.gestionoperaciones.calendariosuscripcion.action;

import java.math.BigDecimal;
import java.util.Date;
import java.util.List;

import org.jboss.seam.ScopeType;
import org.jboss.seam.annotations.In;
import org.jboss.seam.annotations.Name;
import org.jboss.seam.annotations.Scope;
import org.jboss.seam.international.StatusMessage.Severity;
import org.jboss.seam.security.Identity;

import com.atosorigin.common.action.GenericAction;
import com.atosorigin.common.action.ModoPantalla;
import com.atosorigin.common.constantes.Constantes;
import com.atosorigin.common.formvalidator.FormValidator;
import com.atosorigin.common.utils.GenericUtils;
import com.atosorigin.deri.gestionoperaciones.calendariosuscripcion.business.CalendarioSuscripcionBo;
import com.atosorigin.deri.gestionoperaciones.calendariosuscripcion.screen.CalendarioSuscripcionPantalla;
import com.atosorigin.deri.model.gestionoperaciones.CalendarioSuscripcion;
import com.atosorigin.deri.model.gestionoperaciones.CalendarioSuscripcionId;

/**
 * Clase action listener para el caso de uso de calendario de la Órden
 */
@Name("calendarioSuscripcionAction")
@Scope(ScopeType.CONVERSATION)
@FormValidator
public class CalendarioSuscripcionAction extends GenericAction {

	// oO[Variables]Oo
	@In("#{calendarioSuscripcionBo}")
	protected CalendarioSuscripcionBo calendarioSuscripcionBo;

	@In(create=true)
	protected CalendarioSuscripcionPantalla calendarioSuscripcionPantalla;
	
	protected CalendarioSuscripcion calendario;
		
	@In(value="listaCalendarioSuscripcionOut", required=false)
	protected List<CalendarioSuscripcion> listaCalendarioSuscripcionOut;	
	
	@Override
	public void salir(){
		if(!GenericUtils.isNullOrBlank(getListaCalendarioSuscripcionOut())){
			getListaCalendarioSuscripcionOut().addAll(calendarioSuscripcionPantalla.getCalendarioSuscripcionList());
		}
	}
	
	/**
	 * No hace nada, solamente necesario para la regla de navegación desde la pantalla de
	 * alta y modificación
	 */
	public void salirDetalle(){}
	
	public String modifica(){
		if(GenericUtils.isNullOrBlank(calendarioSuscripcionPantalla.getCalendarioSuscripcion().getNominalTramo())){
			calendarioSuscripcionPantalla.getCalendarioSuscripcion().setNominalTramo(calendario.getNominalTramo());
		}
		calendarioSuscripcionPantalla.setCalendarSelec(calendarioSuscripcionPantalla.getCalendarioSuscripcion());
		return Constantes.CONSTANTE_SUCCESS;
	}
	
	public String nuevo(){
		if(GenericUtils.isNullOrBlank(calendarioSuscripcionPantalla.getCalendarioSuscripcion().getNominalTramo())){
			calendarioSuscripcionPantalla.getCalendarioSuscripcion().setNominalTramo(calendario.getNominalTramo());
		}
		calendarioSuscripcionPantalla.getCalendarioSuscripcionList().add(calendarioSuscripcionPantalla.getCalendarioSuscripcion());
		
		return Constantes.CONSTANTE_SUCCESS;
	}
	
	/**
	 * Valida que fecha fin tramo sea igual o mayor que fecha inicial y que no haya tramos duplicados
	 * @return
	 */
	public boolean nuevoValidator(){
		
		boolean esCorrecto = true;
				
		Date fechaInicio = calendarioSuscripcionPantalla.getCalendarioSuscripcion().getId().getfInicioTramo();
		Date fechaFin = calendarioSuscripcionPantalla.getCalendarioSuscripcion().getId().getfFinTramo();
		String tipoOper = calendarioSuscripcionPantalla.getCalendarioSuscripcion().getId().getTipoOperacion();
		
		long diffFechaFinIni = (fechaFin.getTime() - fechaInicio.getTime())/86400000L;
		
		if(diffFechaFinIni < 0){
			esCorrecto = false;
			statusMessages.addToControl("fecfintrTxt",Severity.ERROR,"#{messages['calendariosuscripciondetalle.error.fechas']}");
		}
		
		//Validamos nominalTramo en formato
		BigDecimal nom = calendarioSuscripcionPantalla.getCalendarioSuscripcion().getNominalTramo();
		if(!GenericUtils.isNullOrBlank(nom) && !GenericUtils.validaFormatoDecimal(nom, 17, 4)){
			esCorrecto = false;
			statusMessages.addToControl("nominaltTxt",Severity.ERROR,"#{messages['calendariosuscripciondetalle.error.formato.nominal']}");
		}
		
		//Recorremos la lista de tramos para comprobar que no haya ninguno duplicado
		if(calendarioSuscripcionBo.getTramoDuplicado(calendarioSuscripcionPantalla.getCalendarioSuscripcionList(),
				fechaInicio, fechaFin, tipoOper)){
			esCorrecto = false;
			statusMessages.add(Severity.ERROR, "#{messages['calendariosuscripciondetalle.error.duplicado']}");
		}
		
		return esCorrecto;
	}
	
	public void mostrarPantalla(String opcion, String codCampa, long numeroOrden, long fechaModificacion, BigDecimal nominalTramo, long numeroOperacion, long fechaOpe){
		//Se ejecuta al inicio de la pantalla
		this.setPrimerAcceso(false);
		Date fechaModificacionDate = null;
		if (!opcion.equals(Constantes.ACCION_A)){
			fechaModificacionDate = new Date(fechaModificacion);
		}
		Date fechaOpeDate = new Date(fechaOpe);
		if(GenericUtils.isNullOrBlank(calendario)){
			CalendarioSuscripcionId idCalendario = new CalendarioSuscripcionId();
			calendario = new CalendarioSuscripcion();
			calendario.setId(idCalendario);
			calendario.getId().setTipoOperacion(opcion);
			calendario.getId().setCodigoCampaya(codCampa);
			calendario.getId().setNumeroOrden(numeroOrden);
			calendario.getId().setFechaModificacion(fechaModificacionDate);
			calendario.setNominalTramo(nominalTramo);
			
			List<CalendarioSuscripcion> lista = (List<CalendarioSuscripcion>)calendarioSuscripcionBo.mostrarPantalla(opcion, numeroOrden, codCampa, fechaModificacionDate, nominalTramo, numeroOperacion, fechaOpeDate);
			
			/*
			 * Si opcion = 'A' y no se encuentran datos, avisa que se ha generado un calendario
			 * y se llama a llenaCalendario()
			 */
			if(Constantes.ACCION_A.equals(opcion) && (GenericUtils.isNullOrBlank(lista) || lista.isEmpty())){
				statusMessages.add(Severity.INFO,"#{messages['calendariosuscripciondetalle.calendario.lleno']}");
				lista = calendarioSuscripcionBo.llenaCalendario(numeroOrden, codCampa, fechaModificacionDate,
						nominalTramo, Identity.instance().getCredentials().getUsername(),
						numeroOperacion, fechaOpeDate);
			}
			
			calendarioSuscripcionPantalla.setCalendarioSuscripcionList(lista);
		}		
		
		this.calendarioSuscripcionPantalla.setCodCanpanyaOpcion(codCampa);
		this.calendarioSuscripcionPantalla.setNumOrdenOpcion(numeroOrden);
		this.calendarioSuscripcionPantalla.setDescCampanyaOpcion(calendarioSuscripcionBo.getDescripcionCampanya(codCampa));
		
	}
	
	public void mostrarPantallaModificar(){
		this.setModoPantalla(ModoPantalla.EDICION);
		calendarioSuscripcionPantalla.setCalendarioSuscripcion(calendarioSuscripcionPantalla.getCalendarSelec());
	}
	
	public void mostrarPantallaAlta(){
		this.setModoPantalla(ModoPantalla.CREACION);
		calendarioSuscripcionPantalla.setCalendarioSuscripcion(new CalendarioSuscripcion(new CalendarioSuscripcionId()));
		calendarioSuscripcionPantalla.getCalendarioSuscripcion().getId().setNumeroOrden(calendario.getId().getNumeroOrden());
		calendarioSuscripcionPantalla.getCalendarioSuscripcion().getId().setCodigoCampaya(calendario.getId().getCodigoCampaya());
		calendarioSuscripcionPantalla.getCalendarioSuscripcion().getId().setFechaModificacion(calendario.getId().getFechaModificacion());
		calendarioSuscripcionPantalla.getCalendarioSuscripcion().setUsuario(Identity.instance().getCredentials().getUsername());
	}
		
	// oO[Getters y Setters]Oo
	public CalendarioSuscripcion getCalendario() {
		return calendario;
	}
	public void setCalendario(CalendarioSuscripcion calendario) {
		this.calendario = calendario;
	}	

	public List<CalendarioSuscripcion> getListaCalendarioSuscripcionOut() {
		return listaCalendarioSuscripcionOut;
	}

	public void setListaCalendarioSuscripcionOut(
			List<CalendarioSuscripcion> listaCalendarioSuscripcionOut) {
		this.listaCalendarioSuscripcionOut = listaCalendarioSuscripcionOut;
	}
	
}
