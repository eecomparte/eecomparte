package com.atosorigin.deri.gestionoperaciones.calendariosuscripcion.screen;

import java.util.List;

import org.jboss.seam.ScopeType;
import org.jboss.seam.annotations.Name;
import org.jboss.seam.annotations.Out;
import org.jboss.seam.annotations.Scope;
import org.jboss.seam.annotations.datamodel.DataModel;
import org.jboss.seam.annotations.datamodel.DataModelSelection;

import com.atosorigin.deri.model.gestionoperaciones.CalendarioSuscripcion;
import com.atosorigin.deri.model.gestionoperaciones.CalendarioSuscripcionId;

/**
 *  Contiene los datos de pantalla necesarios para el caso de uso de titulares de la ordén.
 */

@Name("calendarioSuscripcionPantalla")
@Scope(ScopeType.CONVERSATION)
public class CalendarioSuscripcionPantalla {

	protected CalendarioSuscripcionId id;
	protected Long numFilas = 0L;
	
	@DataModel(value ="listaDtCalendarioSuscripcion")
	protected List<CalendarioSuscripcion> calendarioSuscripcionList;
	
	@DataModelSelection(value ="listaDtCalendarioSuscripcion")
	@Out(value="calendarSelec", required=false)
	protected CalendarioSuscripcion calendarSelec;
	
	@Out(value = "calendarioSuscripcion", required = false)
	protected CalendarioSuscripcion calendarioSuscripcion;
	
	protected long numOrdenOpcion;
	protected String codCanpanyaOpcion;
	protected String descCampanyaOpcion;
	
	public CalendarioSuscripcionId getId() {
		return id;
	}
	public void setId(CalendarioSuscripcionId id) {
		this.id = id;
	}
	public CalendarioSuscripcion getCalendarSelec() {
		return calendarSelec;
	}
	public void setCalendarSelec(CalendarioSuscripcion calendarSelec) {
		this.calendarSelec = calendarSelec;
	}
	public CalendarioSuscripcion getCalendarioSuscripcion() {
		return calendarioSuscripcion;
	}
	public void setCalendarioSuscripcion(CalendarioSuscripcion calendarioSuscripcion) {
		this.calendarioSuscripcion = calendarioSuscripcion;
	}
	public List<CalendarioSuscripcion> getCalendarioSuscripcionList() {
		return calendarioSuscripcionList;
	}
	public void setCalendarioSuscripcionList(List<CalendarioSuscripcion> calendarioSuscripcionList) {
		this.calendarioSuscripcionList = calendarioSuscripcionList;
	}

	public Long getNumFilas() {
		return numFilas;
	}
	public void setNumFilas(Long numFilas) {
		this.numFilas = numFilas;
	}
	public long getNumOrdenOpcion() {
		return numOrdenOpcion;
	}
	public String getCodCanpanyaOpcion() {
		return codCanpanyaOpcion;
	}
	public String getDescCampanyaOpcion() {
		return descCampanyaOpcion;
	}
	public void setNumOrdenOpcion(long numOrdenOpcion) {
		this.numOrdenOpcion = numOrdenOpcion;
	}
	public void setCodCanpanyaOpcion(String codCanpanyaOpcion) {
		this.codCanpanyaOpcion = codCanpanyaOpcion;
	}
	public void setDescCampanyaOpcion(String descCampanyaOpcion) {
		this.descCampanyaOpcion = descCampanyaOpcion;
	}	
}
