package com.atosorigin.deri.gestionoperaciones.casaroperaciones.action;

import java.util.Date;
import java.util.List;

import org.jboss.seam.ScopeType;
import org.jboss.seam.annotations.In;
import org.jboss.seam.annotations.Name;
import org.jboss.seam.annotations.Scope;

import com.atosorigin.common.action.PaginatedListAction;
import com.atosorigin.common.formvalidator.FormValidator;
import com.atosorigin.deri.gestionoperaciones.casaroperaciones.business.CasarOperacionesBo;
import com.atosorigin.deri.gestionoperaciones.casaroperaciones.screen.BuscarOperacionesPantalla;
import com.atosorigin.deri.model.gestionoperaciones.Operacion;


/**
 * Clase action listener para el Buscador de Operaciones
 */
@Name("buscadorOperacionesAction")
@Scope(ScopeType.CONVERSATION)
@FormValidator
public class BuscarOperacionesAction extends PaginatedListAction{
	
	@In(value="#{casarOperacionesBo}")
	protected CasarOperacionesBo casarOperacionesBo;
	
	@In(create=true)
	BuscarOperacionesPantalla buscarOperacionesPantalla;
	
	public void buscar(String clasificacion, Date fechaDesde, String idOperacion){

		setPrimerAcceso(false);

		buscarOperacionesPantalla.setClasificacion(clasificacion);
		buscarOperacionesPantalla.setFechaDesde(fechaDesde);
		buscarOperacionesPantalla.setIdOperacion(idOperacion);		
		refrescarLista();
	}
	
	@Override
	public List<Operacion> getDataTableList() {
		return buscarOperacionesPantalla.getListaOpPendientes();
	}

	@Override
	protected void refreshListInternal() {

		setExportExcel(false);

		setDataTableList(casarOperacionesBo
				.buscarOperacionesPendientesBuscador(buscarOperacionesPantalla
						.getClasificacion(), buscarOperacionesPantalla
						.getFechaDesde(), buscarOperacionesPantalla
						.getIdOperacion(), paginationData));
	}
	
	@Override
	public void refrescarListaExcel() {
		setExportExcel(true);
		buscarOperacionesPantalla.setListaOpPendientes(
				casarOperacionesBo.buscarOperacionesPendientesBuscador(this.buscarOperacionesPantalla.getClasificacion(), this.buscarOperacionesPantalla.getFechaDesde(), this.buscarOperacionesPantalla.getIdOperacion(), paginationData.getPaginationDataForExcel()));
		
	}

	@SuppressWarnings("unchecked")
	@Override
	public void setDataTableList(List<?> dataTableList) {
		buscarOperacionesPantalla.setListaOpPendientes((List<Operacion>)dataTableList);		
	}

}
