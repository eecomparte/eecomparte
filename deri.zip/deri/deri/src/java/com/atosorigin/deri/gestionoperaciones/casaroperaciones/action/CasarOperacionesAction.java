package com.atosorigin.deri.gestionoperaciones.casaroperaciones.action;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Collection;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;

import javax.persistence.EntityManager;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.collections.Predicate;
import org.jboss.seam.ScopeType;
import org.jboss.seam.annotations.In;
import org.jboss.seam.annotations.Name;
import org.jboss.seam.annotations.Out;
import org.jboss.seam.annotations.Scope;
import org.jboss.seam.annotations.datamodel.DataModel;
import org.jboss.seam.international.StatusMessage.Severity;

import com.atosorigin.common.action.PaginatedListAction;
import com.atosorigin.common.constantes.Enumeraciones.ClasificacionOperacion;
import com.atosorigin.common.formvalidator.FormValidator;
import com.atosorigin.common.utils.GenericUtils;
import com.atosorigin.deri.adminoper.mantoper.business.MantOperBo;
import com.atosorigin.deri.gestionoperaciones.casaroperaciones.business.CasarOperacionesBo;
import com.atosorigin.deri.gestionoperaciones.operacioncasada.action.OperacionCasadaAction;
import com.atosorigin.deri.gestionoperaciones.operacioncasada.business.OperacionCasadaBo;
import com.atosorigin.deri.gestionoperaciones.operacionespendientes.action.OperacionPendienteAction;
import com.atosorigin.deri.gestionoperaciones.operacionespendientes.screen.OperacionPendientePantalla;
import com.atosorigin.deri.model.contrapartida.Contrapartida;
import com.atosorigin.deri.model.gestionoperaciones.Operacion;
import com.atosorigin.deri.model.gestionoperaciones.OperacionCasada;
import com.atosorigin.deri.model.gestionoperaciones.OperacionId;
import com.atosorigin.deri.util.MessageBoxAction;
import com.atosorigin.deri.util.MsgBoxAction;

/**
 * Clase action listener para el caso de uso de Casar Operaciones.
 */
@Name("casarOperacionesAction")
@Scope(ScopeType.CONVERSATION)
@FormValidator
public class CasarOperacionesAction extends PaginatedListAction {

	private static final long serialVersionUID = 1L;

	//
	// Inyecciones de dependencias
	//

	@In(required = false)
	OperacionCasada operacionCasadaSelec;

	@In("#{casarOperacionesBo}")
	CasarOperacionesBo casarOperacionesBo;

	@In("#{mantOperBo}")
	MantOperBo mantOperBo;

	@In(required = false)
	List<Operacion> listaOpOut;

	@In(required = false)
	OperacionPendienteAction operacionPendienteAction;

	@In(required = false)
	OperacionPendientePantalla operacionPendientePantalla;

	@In(value = "buscadorOperacionesAction", create = true)
	BuscarOperacionesAction buscarOperacionesAction;

	@In(required = false)
	OperacionCasadaAction operacionCasadaAction;

	@In
	EntityManager entityManager;

	//
	// Inicializaciones externas
	//

	/**
	 * <code>operacionSelec.xhtml</code>
	 */
	Operacion seleccionada;

	//
	// Campos de la búsqueda
	//

	String clasificacion;

	Date fechadesde;

	String idOperacion;

	@DataModel(value = "operacionesPendientesList")
	List<OperacionCasada> operacionesPendientesList;

	@In(create = true)
	MsgBoxAction msgBoxAction;

	@Out(required = false, value = "casarOperacionDetalleMessageBoxAction")
	private MessageBoxAction messageBoxCasarOperacionDetalleAction;

	private Boolean primeraEjecucionInit=null;

	// Outyecciones

	/**
	 * Mapa con el <i>status</i> de los checkboxes.
	 *
	 * @see GenericUtils#getSeleccionCheckbox(Map)
	 */
	@Out
	Map<OperacionCasada, Boolean> seleccionOPMap = new TreeMap<OperacionCasada, Boolean>(
			new OperacionCasadaBo.OperacionCasadaComparator());

	private String pantalla;

	private String origen;

	public void agregar() {

		if (!isAgregarPreparado()) {
			statusMessages.add(Severity.WARN,
					"#{messages['casarOperaciones.error.noAgregable']}");
			return;
		}

		final Operacion op = new Operacion(new OperacionId(fechadesde, Long
				.parseLong(idOperacion)));

		final List<OperacionCasada> datos = casarOperacionesBo.cargarDatosCasadas(op);

		if (GenericUtils.isNullOrEmpty(datos)) {
			statusMessages.add(Severity.ERROR,
					"#{messages['casarOperaciones.error.noExiste']}");
			return;
		}

		//
		// Comprobar que no se vaya a duplicar
		//

		List<OperacionCasada> operaciones = getDataTableList();
		boolean ok = true;
		for (OperacionCasada oc : operaciones) {

			final ClasificacionOperacion clsOp;
			if (ClasificacionOperacion.CLIENTE.equals(oc.getClaseOperacion())) {
				clsOp = ClasificacionOperacion.CLIENTE;
			} else if (ClasificacionOperacion.MERCADO.equals(oc
					.getClaseOperacion())) {
				clsOp = ClasificacionOperacion.MERCADO;
			} else {
				statusMessages.add(Severity.ERROR,
						"#{messages['casarOperaciones.error.clasificacion']}");
				return;
			}

			if (clsOp.equals(clasificacion)
					&& GenericUtils.equals(oc.getId()
							.getfContratacionOperacion(), fechadesde)
					&& GenericUtils.equals(oc.getId().getNumeroOperacion(),
							idOperacion)) {
				ok = false;
				break;
			}
		}

		if (!ok) {
			statusMessages.add(Severity.ERROR,
					"#{messages['casarOperaciones.error.duplicado']}");
			return;
		}

		operacionesPendientesList.add(datos.get(0));
		seleccionOPMap.put(datos.get(0), true);

		// Limpieza

		setClasificacion(null);
		setFechadesde(null);
		setIdOperacion(null);
	}

	@Override
	public void salir() {
		setPrimerAcceso(true);
		super.salir();
	}

	public void cargarOperaciones(String origen, String pantalla) {

		setPrimerAcceso(false);

		this.pantalla = pantalla;
		this.origen = origen;
		refrescarLista();

		for (OperacionCasada op : operacionesPendientesList)
			seleccionOPMap.put(op, true);
	}

	public void buscarOperaciones() {
		buscarOperacionesAction.buscar(getClasificacion(), getFechadesde(),
				getIdOperacion());
	}

	@SuppressWarnings("unchecked")
	public void casar() {

		final List<OperacionCasada> operaciones = GenericUtils
				.getSeleccionCheckbox(seleccionOPMap);

		if (!isReadyAceptar()) {

			// No hay suficientes elementos seleccionados -> ERROR

			statusMessages.addFromResourceBundle(Severity.ERROR,
					"casarOperaciones.error.seleccionInsuficiente");
			return;
		}

		// Añadir las operaciones ya casadas para que se coja el AGRUPAME
		// correcto
		operaciones.addAll(CollectionUtils.select(getDataTableList(),
				new OperacionesCasadasPredicate()));
//30/06/2011: Se permite casar operaciones independientemente de su estado
//		if (!casarOperacionesBo.comprobarCasarOperaciones(operaciones)) {
//
//			statusMessages.addFromResourceBundle(Severity.ERROR,
//					"casarOperaciones.casar.error.invalidas");
//
//			return;
//		}

		//TODO validar que todos los productos de la operación existen en relproca
		//y que todos están relacionados entre ellos
		//OperacionCasada opec = operaciones.get(0);
		//Integer producat = opec.getOperacion().getProductoCatalogo();
		if(!casarOperacionesBo.validarProducatRelacionados(operaciones)){
			statusMessages.addFromResourceBundle(Severity.ERROR,
			"casarOperaciones.error.prods.no.rels");
			return;
		}

		casarOperacionesBo.casarOperaciones(operaciones);

		entityManager.flush();

		statusMessages.addFromResourceBundle(Severity.INFO,
				"casarOperaciones.casar.ok");

		//
		// Actualización de datos de la pantalla padre
		//

		if (operacionCasadaAction != null)
			operacionCasadaAction.refrescarLista();

		if (operacionPendienteAction != null)
			operacionPendienteAction.refrescarLista();

		if (operacionPendientePantalla != null)
			operacionPendientePantalla.getSelectedDataList().clear();

		//
		// Actualización pantalla actual
		//
		// Refrescar datos de la lista sin regenerarla, ya que se
		// eliminarían los registros no ligados
		//

		for (OperacionCasada oc : operaciones) {

			final OperacionCasada oc2 = casarOperacionesBo.recargar(oc);

			oc.setAgrupacionCliente(oc2.getAgrupacionCliente());
			oc.setAgrupacionMercado(oc2.getAgrupacionMercado());

			seleccionOPMap.put(oc2, false);
		}
	}

	public String getClasificacion() {
//		return (seleccionada == null) ? clasificacion
//				: (clasificacion = seleccionada.getOperacionCasada()
//						.getClaseOperacion());
		return clasificacion;
	}

	@Override
	public List<OperacionCasada> getDataTableList() {
		return operacionesPendientesList;
	}

	public Date getFechadesde() {
		return fechadesde;
//		return (seleccionada == null) ? fechadesde : (fechadesde = seleccionada
//				.getId().getFechaContratacion());
	}

	public String getIdOperacion() {
		return idOperacion;
//		return (seleccionada == null) ? idOperacion : (idOperacion = ""
//				+ seleccionada.getId().getNumeroOperacion());
	}

	public OperacionCasada getOperacionCasadaSelec() {
		return operacionCasadaSelec;
	}

	public String getPantalla() {
		return pantalla;
	}

	@Override
	protected void refreshListInternal() {

		setExportExcel(false);

		setDataTableList(casarOperacionesBo.buscarOperacionesPendientes(
				listaOpOut, origen));
	}

	@Override
	public void refrescarListaExcel() {

		setExportExcel(true);

		setDataTableList(casarOperacionesBo.buscarOperacionesPendientes(
				listaOpOut, origen));
	}

	public void setClasificacion(String clasificacion) {
		this.clasificacion = clasificacion;
	}

	@SuppressWarnings("unchecked")
	@Override
	public void setDataTableList(List<?> dataTableList) {
		operacionesPendientesList = (List<OperacionCasada>) dataTableList;
	}

	public void setFechadesde(Date fechadesde) {
		this.fechadesde = fechadesde;
	}

	public void setIdOperacion(String idOperacion) {
		this.idOperacion = idOperacion;
	}

	public void setOperacionCasadaSelec(OperacionCasada operacionCasadaSelec) {
		this.operacionCasadaSelec = operacionCasadaSelec;
	}

	public void setPantalla(String pantalla) {
		this.pantalla = pantalla;
	}

	public boolean isAgregarPreparado() {

		return !(GenericUtils.isNullOrBlank(getClasificacion())
				|| GenericUtils.isNullOrBlank(getFechadesde()) || GenericUtils
				.isNullOrBlank(getIdOperacion()));
	}

	public Operacion getSeleccionada() {
		return seleccionada;
	}

	public void setSeleccionada(Operacion seleccionada) {

		this.seleccionada = seleccionada;

		if (seleccionada == null)
			return ;

		setClasificacion(seleccionada.getOperacionCasada().getClaseOperacion());
		setFechadesde(seleccionada.getId().getFechaContratacion());
		setIdOperacion("" + seleccionada.getId().getNumeroOperacion());
	}

	public BuscarOperacionesAction getBuscarOperacionesAction() {
		return buscarOperacionesAction;
	}

	public boolean isReadyAceptar() {

		final List<OperacionCasada> list = getDataTableList();

		if (GenericUtils.isNullOrEmpty(list))
			return false;

		final List<OperacionCasada> seleccion = GenericUtils
				.getSeleccionCheckbox(seleccionOPMap);

		if (seleccion.isEmpty())
			return false;

		if (2 <= seleccion.size())
			return true;

		return  CollectionUtils.exists(list, new OperacionesCasadasPredicate());
	}

	public void controlPantalla() {

		buscarOperaciones();
		final List<Operacion> list = buscarOperacionesAction.getDataTableList();

		if (GenericUtils.isNullOrEmpty(list) || 2 <= list.size())
			return;

		final Operacion op = list.get(0);
		idOperacion = String.valueOf(op.getId().getNumeroOperacion());
		fechadesde = op.getId().getFechaContratacion();
		clasificacion = op.getOperacionCasada().getClaseOperacion();

		if(null!=idOperacion && null!=fechadesde){
			Operacion operacion = mantOperBo.getOperacion(new Long(idOperacion), fechadesde);
			Contrapartida contrapartida = (Contrapartida) operacion.getContrapartida();
			if (null!=contrapartida && !GenericUtils.isNullOrBlank(contrapartida.getIndBloqueo()) && "S".equalsIgnoreCase(contrapartida.getIndBloqueo())){
				abrirPopUpContrapartidaBloqueada();
			}
		}
	}

	public void initDetalle(){
		if (primeraEjecucionInit == null) {
			primeraEjecucionInit=true;
		}
		else{
			primeraEjecucionInit = false;
		}

		if(null==messageBoxCasarOperacionDetalleAction) messageBoxCasarOperacionDetalleAction = new MessageBoxAction();

		if(primeraEjecucionInit && null!=listaOpOut){
			for(Operacion op : listaOpOut){
				Contrapartida contrapartida = null;
				if(null!=op.getContrapartida()){
					contrapartida = (Contrapartida) op.getContrapartida();
				}
				else{
					if(null!=op.getId() && null!=op.getId().getFechaContratacion() && 0<op.getId().getNumeroOperacion()){
						Operacion operacion = mantOperBo.getOperacion(new Long(op.getId().getNumeroOperacion()), op.getId().getFechaContratacion());
						contrapartida = (Contrapartida) operacion.getContrapartida();
					}
				}


				if (null!=contrapartida && !GenericUtils.isNullOrBlank(contrapartida.getIndBloqueo()) && "S".equalsIgnoreCase(contrapartida.getIndBloqueo())){
					abrirPopUpContrapartidaBloqueada();
					return;
				}
			}
		}
	}

	public void voidFunction(){
		msgBoxAction.voidFunction();
	}

	private void abrirPopUpContrapartidaBloqueada(){
		messageBoxCasarOperacionDetalleAction.init("casarOperaciones.messages.contrapartida.bloqueada.texto", "casarOperacionesAction.voidFunction()",null,"messageBoxPanelContrapa");
	}

}

/**
 * Predicado que selecciona las operaciones casadas.
 *
 * @author alejandro.torras@atosorigin.com
 */
class OperacionesCasadasPredicate implements Predicate {

	public boolean evaluate(Object object) {
		return ((OperacionCasada) object).getAgrupacionMercado() != null;
	}
}