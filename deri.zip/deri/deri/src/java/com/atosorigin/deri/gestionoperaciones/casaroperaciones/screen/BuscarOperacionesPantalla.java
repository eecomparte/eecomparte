package com.atosorigin.deri.gestionoperaciones.casaroperaciones.screen;

import java.util.Date;
import java.util.List;

import org.jboss.seam.ScopeType;
import org.jboss.seam.annotations.Name;
import org.jboss.seam.annotations.Out;
import org.jboss.seam.annotations.Scope;
import org.jboss.seam.annotations.datamodel.DataModel;

import com.atosorigin.deri.model.gestionoperaciones.Operacion;


/**
 * Contiene los datos de pantalla necesarios para el caso de uso Busacr operaciones.
 */
@Name("buscarOperacionesPantalla")
@Scope(ScopeType.CONVERSATION)
public class BuscarOperacionesPantalla {
	
	private String idOperacion;
	
	public String getIdOperacion() {
		return idOperacion;
	}

	public void setIdOperacion(String operacion) {
		this.idOperacion = operacion;
	}

	/** Clasificación. Criterio de búsqueda de operaciones. */
	protected String clasificacion;
	
	/** Fecha desde. Criterio de búsqueda de operaciones.*/	
	protected Date fechaDesde;
	
	@DataModel(value="listaDtOpPendientes")
	List<Operacion> listaOpPendientes;

	@Out(required = false)
	Operacion seleccionada;
	
	public String getClasificacion() {
		return clasificacion;
	}

	public Date getFechaDesde() {
		return fechaDesde;
	}

	public void setClasificacion(String clasificacion) {
		this.clasificacion = clasificacion;
	}

	public void setFechaDesde(Date fechadesde) {
		this.fechaDesde = fechadesde;
	}

	public List<Operacion> getListaOpPendientes() {
		return listaOpPendientes;
	}

	public void setListaOpPendientes(List<Operacion> listaOpPendientes) {
		this.listaOpPendientes = listaOpPendientes;
	}

	public Operacion getSeleccionada() {
		return seleccionada;
	}

	public void setSeleccionada(Operacion seleccionada) {
		this.seleccionada = seleccionada;
	}

	
	
	
}
