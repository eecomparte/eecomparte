package com.atosorigin.deri.gestionoperaciones.casaroperaciones.screen;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.jboss.seam.ScopeType;
import org.jboss.seam.annotations.Name;
import org.jboss.seam.annotations.Out;
import org.jboss.seam.annotations.Scope;
import org.jboss.seam.annotations.datamodel.DataModel;
import org.jboss.seam.annotations.datamodel.DataModelSelection;

import com.atosorigin.common.utils.GenericUtils;
import com.atosorigin.deri.model.gestionoperaciones.OperacionCasada;
import com.atosorigin.deri.model.gestionoperaciones.OperacionCasadaId;


/**
 * Contiene los datos de pantalla necesarios para el caso de uso Casar operaciones.
 */
@Name("casarOperacionesPantalla")
@Scope(ScopeType.CONVERSATION)
public class CasarOperacionesPantalla {

	
	private String listaOps;
	
	/** Clasificación. Criterio de búsqueda de operaciones. */
	protected String clasificacion;
	
	/** Fecha desde. Criterio de búsqueda de operaciones.*/	
	protected Date fechadesde;
		
	/** IdOperacion. Criterio de búsqueda de operaciones.*/	
	protected String idOperacion;

	
	public String getClasificacion() {
		return clasificacion;
	}

	public Date getFechadesde() {
		return fechadesde;
	}

	public void setClasificacion(String clasificacion) {
		this.clasificacion = clasificacion;
	}

	public void setFechadesde(Date fechadesde) {
		this.fechadesde = fechadesde;
	}

	public String getIdOperacion() {
		return idOperacion;
	}

	public void setIdOperacion(String idOperacion) {
		this.idOperacion = idOperacion;
	}

	@DataModel(value="listaDtOperacionesPendientes")
	List<OperacionCasada> listaOperacionesPendientes;
	
	@DataModelSelection(value="listaDtOperacionesPendientes")
	@Out(required=false)
	OperacionCasada operacionPendienteSelec;
	
	
	private Map<OperacionCasadaId, Boolean> selectedIds = new HashMap<OperacionCasadaId, Boolean>();
	private List<OperacionCasada> selectedDataList = new ArrayList<OperacionCasada>();

	public String getListaOps() {
		return listaOps;
	}

	public void setListaOps(String listaOps) {
		this.listaOps = listaOps;
	}

	public List<OperacionCasada> getListaOperacionesPendientes() {
		return listaOperacionesPendientes;
	}

	public void setListaOperacionesPendientes(
			List<OperacionCasada> listaOperacionesPendientes) {
		this.listaOperacionesPendientes = listaOperacionesPendientes;
	}

	public OperacionCasada getOperacionPendienteSelec() {
		return operacionPendienteSelec;
	}

	public void setOperacionPendienteSelec(OperacionCasada operacionPendienteSelec) {
		this.operacionPendienteSelec = operacionPendienteSelec;
	}

    public String getSelectedItems() {

        for (OperacionCasada dataItem : listaOperacionesPendientes) {
            if (!GenericUtils.isNullOrBlank(selectedIds.get(dataItem.getId()))){
            	if (selectedIds.get(dataItem.getId()).booleanValue() 
            			&& !selectedDataList.contains(dataItem)) {
            		selectedDataList.add(dataItem);
            		selectedIds.remove(dataItem.getId()); // Reset.
            	}else if(!selectedIds.get(dataItem.getId()).booleanValue() 
            			&& selectedDataList.contains(dataItem)){
            		selectedDataList.remove(dataItem);
            	}
            }
        }

        return "selected";
    }

	public Map<OperacionCasadaId, Boolean> getSelectedIds() {
		return selectedIds;
	}
	
	public void setSelectedIds(Map<OperacionCasadaId, Boolean> selectedIds) {
		this.selectedIds = selectedIds;
	}

	public List<OperacionCasada> getSelectedDataList() {
		return selectedDataList;
	}

	public void setSelectedDataList(List<OperacionCasada> selectedDataList) {
		this.selectedDataList = selectedDataList;
	}	
	
	
}
