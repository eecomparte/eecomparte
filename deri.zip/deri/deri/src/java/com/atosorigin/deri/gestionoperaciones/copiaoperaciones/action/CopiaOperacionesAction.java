package com.atosorigin.deri.gestionoperaciones.copiaoperaciones.action;

import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashSet;
import java.util.List;

import org.apache.commons.collections.CollectionUtils;
import org.jboss.seam.ScopeType;
import org.jboss.seam.annotations.In;
import org.jboss.seam.annotations.Name;
import org.jboss.seam.annotations.Out;
import org.jboss.seam.annotations.Scope;
import org.jboss.seam.international.StatusMessage.Severity;

import com.atosorigin.common.action.PaginatedListAction;
import com.atosorigin.common.constantes.Constantes;
import com.atosorigin.common.formvalidator.FormValidator;
import com.atosorigin.common.utils.GenericUtils;
import com.atosorigin.deri.common.authentication.CustomIdentity;
import com.atosorigin.deri.gestionoperaciones.copiaoperaciones.business.CopiaOperacionesBo;
import com.atosorigin.deri.gestionoperaciones.copiaoperaciones.screen.CopiaOperacionesPantalla;
import com.atosorigin.deri.model.gestionoperaciones.HistoricoOperacion;

/**
 * Clase que actúa de action listener para el caso de uso de mantenimiento de parametros conciliacion.
 */
@Name("copiaOperacionesAction")
@Scope(ScopeType.CONVERSATION)
@FormValidator
public class CopiaOperacionesAction extends PaginatedListAction{

	private static final long serialVersionUID = 1L;

	/**
	 * Inyección del bean de Spring "operacionPendienteBo" que contiene los métodos de negocio
	 * para el caso de uso copia de operaciones .
	 */
	@In("#{copiaOperacionesBo}")
	protected  CopiaOperacionesBo copiaOperacionesBo;
	
	/**
	 * Inyección del screen bean que contiene los datos de pantalla del caso de uso
	 * copia de operaciones.
	 */
	@In(create=true)
	protected CopiaOperacionesPantalla copiaOperacionesPantalla;

	@In
	CustomIdentity identity;

	@Out(value="listaHistoricoOut", required=false)
	protected List<HistoricoOperacion> listaHistoricoOut;
	
	Long[] idOperaciones = new Long[4];
	Date[] fechaOperaciones = new Date[4];

	/** bsuqueda operaciones destino 
	@DataModel(value ="listaOperacionesDestino")
	@Out(value="operacionesDestinoList", required=false)
	protected List<HistoricoOperacion> operacionesDestinoList;
		
	public List<HistoricoOperacion> getOperacionesDestinoList() {
		return operacionesDestinoList;
	}

	public void setOperacionesDestinoList(List<HistoricoOperacion> operacionesDestinoList) {
		this.operacionesDestinoList = operacionesDestinoList;
	}
	**/

	protected enum Estado {
		INICIO, PANEL2, LISTADO
	}

	protected String estado = Estado.INICIO.toString();

	/**
	 * No en uso
	 */
	public void setSelectedItems() {
		copiaOperacionesPantalla.getSelectedItems();		
	}

	
	public boolean buscarValidator(){
		
		boolean esCorrecto = true;
		
		if (copiaOperacionesPantalla.getOperacionId() == null) {
			statusMessages.addToControl("operacionId",Severity.ERROR,"#{messages['copiaoperaciones.error.operacionIdRequerido']}");
			esCorrecto = false;
		}

		if (copiaOperacionesPantalla.getFechaTratamiento() == null) {
			statusMessages.addToControl("fechaTra",Severity.ERROR,"#{messages['copiaoperaciones.error.fechaTraRequerido']}");
			esCorrecto = false;
		}
		
		return esCorrecto;
	}
	
	/**
	 * Actualiza la lista del grid de consutlas
	 * 
	 */
	public void buscar() {
		cleanDestino();
		estado = Estado.INICIO.toString();
		refrescarLista();
		setPrimerAcceso(false);
	}
	
		
	
	/** Se comprueba si las operaciones seleccionadas son correctas para acceder a la pantalla de Ligar operaciones*/
	public void datosCorrectos(){
		//TODO rellenar
	}
	
	//Métodos necesarios para pantallas con grids.
	@Override
	public List<HistoricoOperacion> getDataTableList() {
		return copiaOperacionesPantalla.getOperacionesDestinoList();
	}

	@Override
	@SuppressWarnings("unchecked")
	public void setDataTableList(List<?> dataTableList) {
		copiaOperacionesPantalla.setOperacionesDestinoList((List<HistoricoOperacion>)dataTableList);
	}

	@Override
	protected void refreshListInternal() {

		this.setExportExcel(false);

		final Long operacionId = this.copiaOperacionesPantalla.getOperacionId();
		final Date fechaTratamiento = this.copiaOperacionesPantalla
				.getFechaTratamiento();
		final String tipoCopia = this.copiaOperacionesPantalla.getTipoCopia();

		if (GenericUtils.isNullOrBlank(operacionId) || operacionId <= 0
				|| GenericUtils.isNullOrBlank(fechaTratamiento)
				|| GenericUtils.isNullOrBlank(tipoCopia)) {

			statusMessages
					.add(Severity.ERROR,
							"#{messages['copiaoperaciones.error.operacionincorrecta']}");
			return;

		}

		String situacion = copiaOperacionesBo.compruebaOperacionOrigen(
				operacionId, fechaTratamiento, tipoCopia);

		if (!GenericUtils.isNullOrBlank(situacion))
			copiaOperacionesPantalla.setEstado(situacion);
	}

	protected Object[] guardarCriterios() {

		final List<Object> list = new ArrayList<Object>(2 * idOperaciones.length);

		for (int i = 0; i < idOperaciones.length; i++) {
			if (idOperaciones[i] == null)
				continue;

			list.add(idOperaciones[i]);
			list.add(fechaOperaciones[i]);
		}

		return list.toArray();
	}
	
	/**
	 * metodo para comprobar que las operaciones de origen y destino no son
	 * iguales
	 * 
	 * @return
	 */
	public boolean mismaOperacion() {
		return GenericUtils.in(copiaOperacionesPantalla.getOperacionId(),
				(Object[]) idOperaciones);
	}

	public void buscarOperacionesDestino() {

		if (verificarCriterios()) {
			
			final Object[] criterios = guardarCriterios();

			if (mismaOperacion()) {
				statusMessages.add(Severity.ERROR,
						"#{messages['copiaoperaciones.error.mismaoperacion']}");
				return;
			}

			List<HistoricoOperacion> hList = copiaOperacionesBo
					.obtenerOperacionDestino(criterios, paginationData);

			if (GenericUtils.isNullOrEmpty(hList)) {
				statusMessages
						.add(Severity.ERROR,
								"#{messages['copiaoperaciones.error.operacionincorrecta']}");
				return;
			}

			copiaOperacionesPantalla.setOperacionesDestinoList(hList);
			copiaOperacionesPantalla.getSelectedDataList().clear();

			copiaOperacionesPantalla.setDestinoPata(copiaOperacionesPantalla
					.getPataAcopiar());

			estado = Estado.LISTADO.toString();
			
		}
		
	}
	
	/**
	 * Método para verificar los criterios de busqueda y obtener el ultimo.
	 * 
	 * @return <code>false</code> en el caso que los criterios sean erróneos.
	 **/
	public boolean verificarCriterios() {

		boolean esCorrecto = true;
		SimpleDateFormat sdf = new SimpleDateFormat(Constantes.DDMMYYYY);
		
		for (int i = 0; i < idOperaciones.length; i++) {
			
			if (idOperaciones[i] == null && fechaOperaciones[i] != null){
				esCorrecto = false;
				statusMessages.addFromResourceBundle(Severity.ERROR,
						"copiaoperaciones.error.fecha.nooperacion",
						sdf.format(fechaOperaciones[i]));
			}
			
			if (idOperaciones[i] != null && fechaOperaciones[i] == null){
				esCorrecto = false;
				statusMessages.addFromResourceBundle(Severity.ERROR,
						"copiaoperaciones.error.operacion.nofecha",
						idOperaciones[i].toString());
			}
				
		}

		return esCorrecto;
	}

	public void copiar() throws SQLException{

		final StringBuilder sb = new StringBuilder();
		Long operacionId = new Long(0);
		Date fechaTratamiento = null;
		Date maxfeultact = null;
		String tipocopia = Constantes.CADENA_VACIA;
		String pataAcopiar = Constantes.CADENA_VACIA;
		String copiaPrima = Constantes.CADENA_VACIA;
		String cruzadas = Constantes.CADENA_VACIA;
		String destinoPata = Constantes.CADENA_VACIA; 
		String destinoPrima = Constantes.CADENA_VACIA;
		if ((!GenericUtils.isNullOrBlank(this.copiaOperacionesPantalla.getOperacionId()) && this.copiaOperacionesPantalla.getOperacionId()>0) && !GenericUtils.isNullOrBlank(this.copiaOperacionesPantalla.getFechaTratamiento())){
			operacionId = this.copiaOperacionesPantalla.getOperacionId();
			fechaTratamiento = this.copiaOperacionesPantalla.getFechaTratamiento();
			tipocopia = this.copiaOperacionesPantalla.getTipoCopia();
			maxfeultact = copiaOperacionesBo.obtenerFechaUltimaModificacion(operacionId, fechaTratamiento);
		}
		HistoricoOperacion operacionOrigen = copiaOperacionesBo.obtenerOperacionOrigen(operacionId, fechaTratamiento, maxfeultact);
		//listaHistoricoOut = copiaOperacionesPantalla.getSelectedDataList();
		//operacionesDestino = listaHistoricoOut;
		//operacionesDestino = listasSeleccionadas;

		if (!"O".equals(tipocopia) && !copiaOperacionesBo.compruebaOperacionOrigen2(operacionOrigen)) {
			copiaOperacionesPantalla
					.setMsg("La operación origen tiene las 2 patas con la fórmula 1022. Revise los datos");
			return ;
		}

		if (Constantes.COND_FIJACION.equals(copiaOperacionesPantalla
				.getTipoCopia())) {

//			if (!GenericUtils.isNullOrBlank(this.copiaOperacionesPantalla
//					.getPataAcopiar())) {

				if (!GenericUtils.isNullOrBlank(this.copiaOperacionesPantalla
						.getDestinoPata())) {
					destinoPata = this.copiaOperacionesPantalla.getDestinoPata();
				
//				pataAcopiar = this.copiaOperacionesPantalla.getPataAcopiar();
				boolean ok = true;

				for (HistoricoOperacion hOperacion : listasSeleccionadas) {
					String result = copiaOperacionesBo
							.copiaOperacionesCondFijacion(operacionOrigen,
									tipocopia, maxfeultact, hOperacion,
									destinoPata, identity);

					ok = GenericUtils.equals("OK", result);
					if (!ok) {
						sb.append(result);
						break;
					}
				}

				if (ok)
					sb.append("Los datos de las condiciones de fijación se han copiado correctamente");
			}
		}

		if (Constantes.FLUJOS.equals(copiaOperacionesPantalla
				.getTipoCopia())) {
			
			if (!GenericUtils.isNullOrBlank(this.copiaOperacionesPantalla
					.getPataAcopiar())) {
				pataAcopiar = this.copiaOperacionesPantalla.getPataAcopiar();
			}
			if (this.copiaOperacionesPantalla.isCopiarPrima()) {
				copiaPrima = Constantes.COPIARPRIMA;
			} else {
				copiaPrima = Constantes.NO_COPIARPRIMA;
			}
			if (this.copiaOperacionesPantalla.isCruzadas()) {
				cruzadas = Constantes.CRUZADAS;
			} else {
				cruzadas = Constantes.NO_CRUZADAS;
			}
			if (!GenericUtils.isNullOrBlank(this.copiaOperacionesPantalla
					.getDestinoPata())) {
				destinoPata = this.copiaOperacionesPantalla.getDestinoPata();
			}
			if (!GenericUtils.isNullOrBlank(this.copiaOperacionesPantalla
					.getDestinoPrima())) {
				destinoPrima = this.copiaOperacionesPantalla.getDestinoPrima();
			}
			boolean ok = true;
			for (HistoricoOperacion hOperacion : listasSeleccionadas) {
				String result = copiaOperacionesBo.copiaFlujos(operacionOrigen,
						tipocopia, pataAcopiar, copiaPrima, maxfeultact,
						cruzadas, hOperacion, destinoPata, destinoPrima, identity);

				ok = GenericUtils.equals("OK", result);
				if (!ok) {
					sb.append(result);
					break;
				}
			}

			if (ok)
				sb.append("Los datos de los flujos se han copiado correctamente. Ahora debe modificar la operación");
		}

		if (Constantes.FECHAS_LIQUIDACION
				.equals(copiaOperacionesPantalla.getTipoCopia())) {

			boolean ok = true;
			for (HistoricoOperacion hOperacion : listasSeleccionadas) {
				String result = copiaOperacionesBo.copiaFechas(operacionOrigen,
						maxfeultact, hOperacion, identity);

				ok = GenericUtils.equals("OK", result);
				if (!ok) {
					sb.append(result);
					break;
				}
			}

			if (ok)
				sb.append("Las fechas de liquidación se han copiado correctamente");
		}
		if (Constantes.DATOS_OPCION.equals(copiaOperacionesPantalla
				.getTipoCopia())) {
			boolean ok = true;
			for (HistoricoOperacion hOperacion : listasSeleccionadas) {
				String result = copiaOperacionesBo.copiaOpcion(operacionOrigen, getPataOpcion(operacionOrigen), maxfeultact, cruzadas, 
						hOperacion,getPataOpcion(hOperacion), identity);				
				ok = GenericUtils.equals("OK", result);
				if (!ok) {
					sb.append(result);
					break;
				}
			}

			if (ok)
				sb.append("Los datos de la opción se han copiado correctamente. Ahora debe modificar la operación");
			
		}
		copiaOperacionesPantalla.setMsg(sb.toString());
	}

	private String getPataOpcion(HistoricoOperacion operacion)
	{
	//	String pata=null;
		return operacion.getHistoricoOpcion().getTipoOperacion();
//		for (RelProductoTransaccion transProdOrigen:operacion.getProductoCatalogo().getProductoTransacciones()){
//			if(transProdOrigen.getId().getTranoper()== operacion.getTransaccion()){
//				if(transProdOrigen.getTppapago()==null)
//					pata =Constantes.PATA_RECIBO;
//				else
//					pata =Constantes.PATA_PAGO;
//			}
//		}
//		return pata;
	}
	public void Mensaje(){
		
	}
	

	@Override
	public void refrescarListaExcel() {
		setExportExcel(true);
		
	}

	public String copiarNuevo() {

		clean();
		return "/pages/gestionoperaciones/copiaoperaciones/copiaOperaciones.xhtml";
	}

	/**
	 * metodos para las funciones seleccionar todos y deseleccionar todos
	 */
	private HashSet<HistoricoOperacion> listasSeleccionadas = new HashSet<HistoricoOperacion>();
	@Out
	public Boolean getSelectedRow(){
		return listasSeleccionadas.contains(copiaOperacionesPantalla.getOperacion());
	}
	public void setSelectedRow(Boolean selected){
		if(selected){
			listasSeleccionadas.add(copiaOperacionesPantalla.getOperacion());
		}
		else{
			listasSeleccionadas.remove(copiaOperacionesPantalla.getOperacion());
		}
	}
	
	public void seleccionarLista(){

	}

	public boolean existeSeleccion() {

		final List<HistoricoOperacion> list = getDataTableScreen();

		return (GenericUtils.isNullOrBlank(list)) ? false : CollectionUtils
				.containsAny(listasSeleccionadas, list);
	}
	
	public boolean existenDatos(){
		return (!GenericUtils.isNullOrBlank(getDataTableScreen()));
	}
	
	public void seleccionarTodos(){
		if(!GenericUtils.isNullOrBlank(getDataTableList()))
		listasSeleccionadas.addAll(getDataTableScreen());
	}
	public void deseleccionarTodos(){		
		if(!GenericUtils.isNullOrBlank(getDataTableScreen()))
			listasSeleccionadas.removeAll(getDataTableScreen());		
	}

	public List<HistoricoOperacion> getDataTableScreen() {

		final List<HistoricoOperacion> ols = copiaOperacionesPantalla
				.getOperacionesDestinoList();

		return GenericUtils.isNullOrBlank(ols) ? null : ols.subList(0, Math
				.min(ols.size(), 10));
	}

	/**
	 * metodo para resetear los valores de buscauqeda operacion origen
	 */
	public void clean() {

		cleanDestino();

		this.copiaOperacionesPantalla.setOperacionId(null);
		this.copiaOperacionesPantalla.setFechaTratamiento(null);
		this.copiaOperacionesPantalla.setTipoCopia(Constantes.COND_FIJACION);
		this.copiaOperacionesPantalla.setPataAcopiar(Constantes.PATA_PAGO);
		this.copiaOperacionesPantalla.setCopiarPrima(false);
		this.copiaOperacionesPantalla.setEstado(null);

		estado = Estado.INICIO.toString();
	}

	/**
	 * metodo para limpiar/resetear los valores de busqueda de ioperacion
	 * destino
	 */
	public void cleanDestino() {

		listasSeleccionadas.clear();

		idOperaciones = new Long[4];
		fechaOperaciones = new Date[4];

		copiaOperacionesPantalla.setOperacionesDestinoList(null);

		estado = Estado.PANEL2.toString();
	}

	public String getEstado() {
		return estado;
	}
	
	public boolean isReadyDestinoPrima() {
		return copiaOperacionesPantalla.isCopiarPrima();
	}

	public boolean isReadyBuscar2() {
		return !verificarCriterios();
	}

	public Long[] getIdOperaciones() {
		return idOperaciones;
	}

	public Date[] getFechaOperaciones() {
		return fechaOperaciones;
	}
}
