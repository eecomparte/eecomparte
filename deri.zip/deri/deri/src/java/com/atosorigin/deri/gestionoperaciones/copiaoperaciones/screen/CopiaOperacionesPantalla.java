package com.atosorigin.deri.gestionoperaciones.copiaoperaciones.screen;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.jboss.seam.ScopeType;
import org.jboss.seam.annotations.Name;
import org.jboss.seam.annotations.Out;
import org.jboss.seam.annotations.Scope;
import org.jboss.seam.annotations.datamodel.DataModel;
import org.jboss.seam.annotations.datamodel.DataModelSelection;

import com.atosorigin.common.constantes.Constantes;
import com.atosorigin.common.utils.GenericUtils;
import com.atosorigin.deri.model.gestionoperaciones.HistoricoOperacion;
import com.atosorigin.deri.model.gestionoperaciones.Operacion;

/**
 *  Contiene los datos de pantalla necesarios para el caso de uso copia operaciones.
 */
@Name("copiaOperacionesPantalla")
@Scope(ScopeType.CONVERSATION)
public class CopiaOperacionesPantalla {

	/** numero operacion. Criterio de búsqueda de operaciones. */
	/*criterios de busqueda primer panel Operacion Origen*/
	protected Long operacionId;
	public Long getOperacionId() {
		return operacionId;
	}

	public void setOperacionId(Long operacionId) {
		this.operacionId = operacionId;
	}

	/** Fecha fechaTratamiento. Criterio de búsqueda de operaciones.*/	
	protected Date fechaTratamiento;
	
	public Date getFechaTratamiento() {
		return fechaTratamiento;
	}

	public void setFechaTratamiento(Date fechaTratamiento) {
		this.fechaTratamiento = fechaTratamiento;
	}
	
    protected String estado;
    
	public String getEstado() {
		return estado;
	}

	public void setEstado(String estado) {
		this.estado = estado;
	}
	protected String msg;
	
	public String getMsg() {
		return msg;
	}

	public void setMsg(String msg) {
		this.msg = msg;
	}

	/** Lista de datos para el grid. */
	@DataModel(value ="listaOperacionesDestino")
	//@Out(value="operacionesDestinoList", required=false)
	protected List<HistoricoOperacion> operacionesDestinoList;
		
	public List<HistoricoOperacion> getOperacionesDestinoList() {
		return operacionesDestinoList;
	}

	public void setOperacionesDestinoList(List<HistoricoOperacion> operacionesDestinoList) {
		this.operacionesDestinoList = operacionesDestinoList;
	}
	@DataModelSelection(value ="listaOperacionesDestino")
    @Out(value="operacion", required=false)
	protected HistoricoOperacion operacion;
	
   /*criterios de busqueda panel Operacion destino*/
	protected Long operacionId1;
	

	public Long getOperacionId1() {
		return operacionId1;
	}

	public void setOperacionId1(Long operacionId1) {
		this.operacionId1 = operacionId1;
	}

	/** Fecha fechaTratamiento. Criterio de búsqueda de operaciones.*/	
	protected Date fechaTratamiento1;
	
	
	public Date getFechaTratamiento1() {
		return fechaTratamiento1;
	}

	public void setFechaTratamiento1(Date fechaTratamiento1) {
		this.fechaTratamiento1 = fechaTratamiento1;
	}
	protected Long operacionId2;
	

	public Long getOperacionId2() {
		return operacionId2;
	}

	public void setOperacionId2(Long operacionId2) {
		this.operacionId2 = operacionId2;
	}

	/** Fecha fechaTratamiento. Criterio de búsqueda de operaciones.*/	
	protected Date fechaTratamiento2;
	
	
	public Date getfechaTratamiento2() {
		return fechaTratamiento2;
	}

	public void setfechaTratamiento2(Date fechaTratamiento2) {
		this.fechaTratamiento2 = fechaTratamiento2;
	}
protected Long operacionId3;
	

	public Long getOperacionId3() {
		return operacionId3;
	}

	public void setOperacionId3(Long operacionId3) {
		this.operacionId3 = operacionId3;
	}

	/** Fecha fechaTratamiento. Criterio de búsqueda de operaciones.*/	
	protected Date fechaTratamiento3;
	
	
	public Date getFechaTratamiento3() {
		return fechaTratamiento3;
	}

	public void setFechaTratamiento3(Date fechaTratamiento3) {
		this.fechaTratamiento3 = fechaTratamiento3;
	}
	protected Long operacionId4;
	

	public Long getOperacionId4() {
		return operacionId4;
	}

	public void setOperacionId4(Long operacionId4) {
		this.operacionId4 = operacionId4;
	}

	/** Fecha fechaTratamiento. Criterio de búsqueda de operaciones.*/	
	protected Date fechaTratamiento4;
	
	
	public Date getfechaTratamiento4() {
		return fechaTratamiento4;
	}

	public void setfechaTratamiento4(Date fechaTratamiento4) {
		this.fechaTratamiento4 = fechaTratamiento4;
	}
	/*panel de confirmacion de Operaciones destino*/
	protected List<Operacion> operacionDestino;
	
	public List<Operacion> getOperacionDestino() {
		return operacionDestino;
	}

	public void setOperacionDestino(List<Operacion> operacionDestino) {
		this.operacionDestino = operacionDestino;
	}
	@Out(required=false)
	protected Operacion operacionDestino1;
	
	public Operacion getOperacionDestino1() {
		return operacionDestino1;
	}

	public void setOperacionDestino1(Operacion operacionDestino1) {
		this.operacionDestino1 = operacionDestino1;
	}

	protected Operacion operacionOrigen;
	
	public Operacion getOperacionOrigen() {
		return operacionOrigen;
	}

	public void setOperacionOrigen(Operacion operacionOrigen) {
		this.operacionOrigen = operacionOrigen;
	}
	/** Cargamos la pantalla con los valores por defecto */
	public CopiaOperacionesPantalla(){
		this.tipoCopia=Constantes.COND_FIJACION;
		this.pataAcopiar=Constantes.PATA_PAGO;
		
	}
	/** String. Criterio de búsqueda de operaciones. */
	protected String tipoCopia;
	
	public String getTipoCopia() {
		return tipoCopia;
	}

	public void setTipoCopia(String tipoCopia) {
		this.tipoCopia = tipoCopia;
	}
	protected String pataAcopiar;
	
	
	public String getPataAcopiar() {
		return pataAcopiar;
	}

	public void setPataAcopiar(String pataAcopiar) {
		this.pataAcopiar = pataAcopiar;
	}
	protected boolean copiarPrima;
	
	
	public boolean isCopiarPrima() {
		return copiarPrima;
	}

	public void setCopiarPrima(boolean copiarPrima) {
		this.copiarPrima = copiarPrima;
	}

	protected boolean cruzadas;
	
	
	public boolean isCruzadas() {
		return cruzadas;
	}

	public void setCruzadas(boolean cruzadas) {
		this.cruzadas = cruzadas;
	}

	public String destinoPata;
	
	public String getDestinoPata() {
		return destinoPata;
	}

	public void setDestinoPata(String destinoPata) {
		this.destinoPata = destinoPata;
	}
	
	public String destinoPrima;
	
	public String getDestinoPrima() {
		return destinoPrima;
	}

	public void setDestinoPrima(String destinoPrima) {
		this.destinoPrima = destinoPrima;
	}

	/** Fecha vencimiento. Criterio de búsqueda de operaciones. */
	protected Date fechavenci;
	
	
	
	
		
	
	/**
	 * Selección checkbox GrupoContrapartida
	 */
	private Map<HistoricoOperacion, Boolean> selectedIds = new HashMap<HistoricoOperacion, Boolean>();
    private List<HistoricoOperacion> selectedDataList = new ArrayList<HistoricoOperacion>();
	
	
	

	public HistoricoOperacion getOperacion() {
		return operacion;
	}

	public void setOperacion(HistoricoOperacion operacion) {
		this.operacion = operacion;
	}

	/*metodos get y set de las variables de pantalla de búsqueda*/
	


	public Date getFechavenci() {
		return fechavenci;
	}

	public void setFechavenci(Date fechavenci) {
		this.fechavenci = fechavenci;
	}

	
	//metodos del checkbox
	
	 public String getSelectedItems() {

	        for (HistoricoOperacion dataItem : operacionesDestinoList) {
	            if (!GenericUtils.isNullOrBlank(selectedIds.get(dataItem.getId()))){
	            	if (selectedIds.get(dataItem.getId()).booleanValue() 
	            			&& !selectedDataList.contains(dataItem)) {
	            		selectedDataList.add(dataItem);
	            		selectedIds.remove(dataItem.getId()); 
	            	}else{
	            		selectedDataList.remove(dataItem);
	            	}
	            }
	        }

	        return "selected";
	    }
	
	//método de selecionar registros
	public Map<HistoricoOperacion, Boolean> getSelectedIds() {
		/*
		for (HistoricoOperacion dataItem : operacionesDestinoList) {
            if (!GenericUtils.isNullOrBlank(selectedIds.get(dataItem.getId()))){
            	if (selectedIds.get(dataItem.getId()).booleanValue() 
            			&& !selectedDataList.contains(dataItem)) {
            		selectedDataList.add(dataItem);
            		selectedDataList.remove(dataItem.getId()); // Reset.
            	}else{
            		selectedDataList.remove(dataItem);
            	}
            }
        }*/
        //return "selected";
		return selectedIds;
	}

	public void setSelectedIds(Map<HistoricoOperacion, Boolean> selectedIds) {
		this.selectedIds = selectedIds;
	}

	public List<HistoricoOperacion> getSelectedDataList() {
		return selectedDataList;
	}

	public void setSelectedDataList(List<HistoricoOperacion> selectedDataList) {
		this.selectedDataList = selectedDataList;
	}
	
	
}
