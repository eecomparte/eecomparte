package com.atosorigin.deri.gestionoperaciones.listasuscripciones.action;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashSet;
import java.util.List;

import org.jboss.seam.ScopeType;
import org.jboss.seam.annotations.In;
import org.jboss.seam.annotations.Name;
import org.jboss.seam.annotations.Out;
import org.jboss.seam.annotations.Scope;
import org.jboss.seam.core.Conversation;
import org.jboss.seam.core.ResourceBundle;
import org.jboss.seam.international.StatusMessage.Severity;

import com.atosorigin.common.action.PaginatedListAction;
import com.atosorigin.common.constantes.Constantes;
import com.atosorigin.common.formvalidator.FormValidator;
import com.atosorigin.common.utils.GenericUtils;
import com.atosorigin.deri.common.dbLock.DbLockService;
import com.atosorigin.deri.common.parametrosPantalla.ParametrosMantoper;
import com.atosorigin.deri.common.parametrosPantalla.ParametrosOpercamp;
import com.atosorigin.deri.gestioncampanyas.campanya.business.CampanyaBo;
import com.atosorigin.deri.gestionoperaciones.listasuscripciones.business.ListaSuscripcionesBo;
import com.atosorigin.deri.gestionoperaciones.listasuscripciones.screen.ListaSuscripcionesPantalla;
import com.atosorigin.deri.model.agenda.EventoAgenda;
import com.atosorigin.deri.model.contrapartida.Contrapartida;
import com.atosorigin.deri.model.contrapartida.DocsContrapartida;
import com.atosorigin.deri.model.gestioncampanyas.Campanya;
import com.atosorigin.deri.model.gestionoperaciones.ListaSuscripciones;
import com.atosorigin.deri.model.gestionoperaciones.Orden;
import com.atosorigin.deri.model.gestionoperaciones.OrdenId;
import com.atosorigin.deri.util.MessageBoxAction;
import com.atosorigin.deri.util.MsgBoxAction;



/**
 * Clase action listener para el caso de uso de Lista de Suscripciones.
 */
@Name("listaSuscripcionesAction")
@Scope(ScopeType.CONVERSATION)
@FormValidator
public class ListaSuscripcionesAction extends PaginatedListAction {

	/**
	 * Inyección del bean de Spring "listaSuscripcionesBo" que contiene los tipos de error
	 * para el caso de uso Lista de Suscripciones.
	 */
	@In("#{listaSuscripcionesBo}")
	protected ListaSuscripcionesBo listaSuscripcionesBo;

	/**
	 * Inyección del screen bean que contiene los datos de pantalla del caso de uso
	 * Lista de Suscripciones.
	 */
	@In(create=true)
	protected ListaSuscripcionesPantalla listaSuscripcionesPantalla;
	
    @Out(required=false)
    protected ListaSuscripciones suscripcionSeleccionada;	

    @Out(required=false, value="campanyaEdit")
	private Campanya campanyaSelec;
	
	@In(required=false)
	private Boolean estadoAgenda; 
	
	@In(required=false)
	private EventoAgenda eventoSelectAgenda; 
	
	@In(required=false)
	private String modo; 
	
	private Boolean busqueda = false;
	
	@Out(required = false, value="parametrosMantOper") //Parametros para MantOper
	private ParametrosMantoper parametrosMantOper;
    
	/**
	 * Inyección del bean de Spring "campanyaBo" que contiene los métodos de negocio
	 * para el caso de uso reclasificación contable de campañas.
	 */
	@In("#{campanyaBo}")
	protected CampanyaBo campanyaBo;

	/** Campaña seleccionada en el grid de lista de campañas */
	@In(value="campanyaEdit", required=false )
	protected Campanya campanya;
	
	private Boolean primeraVez = true;
	private ParametrosOpercamp parametrosOpercamp;	
	
	/** Inyección del servicio que gestiona los bloqueos de registros en base de datos */
	@In(create = true)
	protected DbLockService dbLockService;
	
	@In(required = false)
	@Out(required = false)
	protected String llamada;
    
	@In(create = true)
	private MsgBoxAction msgBoxAction;
	
	@Out(required = false, value = "listaSuscripcionMessageBoxAction")
	private MessageBoxAction msgboxPanelListaSuscripcionContrapaBloq;
	
	/**
     * Orden a enviar a la pantalla Alta Orden Contratación
     */
    protected Orden orden;	
    
	public Orden getOrden() {
		return orden;
	}

	public void setOrden(Orden orden) {
		this.orden = orden;
	}

	
	public void init(){
		 Short codigoEvento;
		String estadoEvento;
		listaSuscripcionesPantalla.setSeleccionTotal(false);
		if (Constantes.MODO_AGE.equals(modo) && primeraVez) {

			paginationData.reset();
			listasSeleccionadas.clear();

			if  (estadoAgenda)	estadoEvento ="P";
			else estadoEvento ="N";
			codigoEvento = eventoSelectAgenda.getCodigoEvento();
			cargarDesdeAgenda(codigoEvento, estadoEvento);
			
		}
	
		if ("SUSCRIPC".equalsIgnoreCase(llamada)){
			recargarLista();
			llamada = "";
		}
	
		if(null==msgboxPanelListaSuscripcionContrapaBloq){
			msgboxPanelListaSuscripcionContrapaBloq = new MessageBoxAction();
		}
		primeraVez = false;	
		
	}
	private void recargarLista() {
		List<ListaSuscripciones> list = listaSuscripcionesPantalla.getListaSuscripcionesList();
		if (list == null) return;
		for (ListaSuscripciones suscrip : list) {
			listaSuscripcionesBo.refresh(suscrip);
		} 
	}

	/**
	 * Actualiza la lista del grid de Lista de Suscripciones.
	 * 
	 */
	public void buscar() {

		if (verificarDatosPantalla()) 
		{
			listaSuscripcionesPantalla.setSeleccionTotal(false);
			paginationData.reset();
			listasSeleccionadas.clear();
			busqueda = true;
			modo ="";
			refrescarLista();	
			setPrimerAcceso(false);
		}
	}

	@Override
	public List<ListaSuscripciones> getDataTableList() {
		return listaSuscripcionesPantalla.getListaSuscripcionesList();
	}

	@Override
	protected void refreshListInternal() {
		if (!busqueda && Constantes.MODO_AGE.equals(modo)){
			 Short codigoEvento;
			 String estadoEvento;
			 
			if  (estadoAgenda)	estadoEvento ="P";
			else estadoEvento ="N";
			codigoEvento = eventoSelectAgenda.getCodigoEvento();
			cargarDesdeAgenda(codigoEvento, estadoEvento);
		}else {
		
		setExportExcel(false);
		 List<ListaSuscripciones> list = listaSuscripcionesPantalla.getListaSuscripcionesList();
		if(list==null){
			list = new ArrayList<ListaSuscripciones>();
			listaSuscripcionesPantalla.setListaSuscripcionesList(list);
		}
		list.clear();
		if (listaSuscripcionesPantalla.getnumOperacionDesde() != null ||
			listaSuscripcionesPantalla.getnumOperacionHasta() !=null){

			list.addAll((List<ListaSuscripciones>) listaSuscripcionesBo
					.buscarDatosOrdenesOperacion(listaSuscripcionesPantalla.getCampanyaId(),
							listaSuscripcionesPantalla.getfComercializacionDesde(),
							listaSuscripcionesPantalla.getfComercializacionHasta(),
							listaSuscripcionesPantalla.getfCampanyaDesde(),
							listaSuscripcionesPantalla.getfCampanyaHasta(),
							listaSuscripcionesPantalla.getnumOperacionDesde(),
							listaSuscripcionesPantalla.getnumOperacionHasta(),
							listaSuscripcionesPantalla.getOficina(),
							listaSuscripcionesPantalla.getSuscripciones(),
							listaSuscripcionesPantalla.getNumSuscripcionDesde(),
							listaSuscripcionesPantalla.getNumSuscripcionHasta(),
							listaSuscripcionesPantalla.getfSuscripcionDesde(),
							listaSuscripcionesPantalla.getfSuscripcionHasta(),
							listaSuscripcionesPantalla.getNif(),
							listaSuscripcionesPantalla.getUnidadCampanya(),
							paginationData));

		}else{
			list.addAll((List<ListaSuscripciones>) listaSuscripcionesBo
					.buscarDatosOrdenes(listaSuscripcionesPantalla.getCampanyaId(),
							listaSuscripcionesPantalla.getfComercializacionDesde(),
							listaSuscripcionesPantalla.getfComercializacionHasta(),
							listaSuscripcionesPantalla.getfCampanyaDesde(),
							listaSuscripcionesPantalla.getfCampanyaHasta(),
							listaSuscripcionesPantalla.getOficina(),
							listaSuscripcionesPantalla.getSuscripciones(),
							listaSuscripcionesPantalla.getNumSuscripcionDesde(),
							listaSuscripcionesPantalla.getNumSuscripcionHasta(),
							listaSuscripcionesPantalla.getfSuscripcionDesde(),
							listaSuscripcionesPantalla.getfSuscripcionHasta(),
							listaSuscripcionesPantalla.getNif(),
							listaSuscripcionesPantalla.getUnidadCampanya(),
							paginationData));
		}

		}
	}

	
	
	public void cargarDesdeAgenda(Short codigoEvento, String estadoEvento){
		setExportExcel(false);
		 List<ListaSuscripciones> list = listaSuscripcionesPantalla.getListaSuscripcionesList();
		if(list==null){
			list = new ArrayList<ListaSuscripciones>();
			listaSuscripcionesPantalla.setListaSuscripcionesList(list);
		}
		list.clear();
		list.addAll(listaSuscripcionesBo.cargarAgenda(codigoEvento, estadoEvento, paginationData));
	}

	
	/**
	 * Se llama desde la Agenda o bien desde la lista de campanas.
	 * 
	 * En caso de la lista los parametros que se recibirán son:
	 * 
	 * MODO = ‘CAM’
	 * ESTADOEV = NULL
	 * CODEVENT = NULL
	 * CAMPANYA = código de la campaña seleccionada (campanya.id)
	 * NUMORDEN_INI = NULL
	 * 
	 * Desde la agenda:
	 * 
	 * MODO = ‘AGE’
	 * ESTADOEV = Estado del evento seleccionado
	 * CODEVENT = Código del evento seleccionado
	 * CAMPANYA = NULL
	 * NUMORDEN_INI = NULL
	 * 
	 * @param modo  
	 * @param estadoEvento
	 * @param codigoEvento
	 * @param campanyaId
	 * @param numeroOrden
	 */
	public String cargar(String modo,String estadoEvento,Short codigoEvento, String campanyaId, Long numeroOrden ){
		if ("CAM".equalsIgnoreCase(modo)) {
			listaSuscripcionesPantalla.setCampanyaId(campanyaId);
			buscar();
		}else if (modo=="AGE") {
			//listaSuscripcionesPantalla.setCampanyaId(campanyaId);
			//buscar();
		}
		
		return Constantes.CONSTANTE_SUCCESS;
	}
	
	/** Realiza las validaciones previas a la llamada a la pantalla de Mantenimiento
	 * de Suscripciones desde lista de campañas
	 * @return true si las validaciones son correctas
	 */
	public boolean cargarValidator(){
		
		boolean esCorrecto = true;
		
		if(!campanyaBo.comprobarOrdenesCampanya(this.getCampanya())){
			esCorrecto = false;
			statusMessages.add(Severity.ERROR, "#{messages['campanyas.error.campanyasinordenes']}");
		}
		
		return esCorrecto;
	}
	 
	private HashSet<ListaSuscripciones> listasSeleccionadas = new HashSet<ListaSuscripciones>();
	
	public Boolean getSelectedRow(){
		return listasSeleccionadas.contains(listaSuscripcionesPantalla.getListaSuscripcionSel());
	}

	public void setSelectedRow(Boolean selected){
		if(selected){
			listasSeleccionadas.add(listaSuscripcionesPantalla.getListaSuscripcionSel());
		}
		else{
			listasSeleccionadas.remove(listaSuscripcionesPantalla.getListaSuscripcionSel());
			listaSuscripcionesPantalla.setSeleccionTotal(false);
		}
	}
	
	public void seleccionarLista(){

	}

	public boolean existeSeleccion(){
//		List<ListaSuscripciones> nls =  getDataTableScreen();
//		if(!GenericUtils.isNullOrBlank(nls) && (nls.size() > 0))	 
//		return listasSeleccionadas.containsAll(nls);			
//		else return false;
		return (!GenericUtils.isNullOrBlank(listasSeleccionadas) && (listasSeleccionadas.size() > 0));
	}
	
	public boolean existenDatos(){
		List<ListaSuscripciones> nls =  listaSuscripcionesPantalla.getListaSuscripcionesList();
		return (!GenericUtils.isNullOrBlank(nls) && (nls.size() > 0));
	}
	
	public void seleccionarTodos(){
		Integer minResul = paginationData.getFirstResult();
		Integer maxResul = paginationData.getMaxResults(); 
		
		paginationData.setFirstResult(0);
		paginationData.setMaxResults(Constantes.MAX_RESULTS_SELECCION_TOTAL);
		
		List<ListaSuscripciones> listaTemp = listaSeleccionarTodos();
		
		if(!GenericUtils.isNullOrBlank(listaTemp)){
			listasSeleccionadas.addAll(listaTemp);
			listaSuscripcionesPantalla.setSeleccionTotal(true);
		}
			
		
		paginationData.setMaxResults(maxResul);
		paginationData.setFirstResult(minResul);
	}

	public void deseleccionarTodos(){
		listasSeleccionadas.clear();
		listaSuscripcionesPantalla.setSeleccionTotal(false);
//		if(!GenericUtils.isNullOrBlank(getDataTableScreen()))
//			listasSeleccionadas.removeAll(getDataTableScreen());
	}
	
	
	public List<ListaSuscripciones> getDataTableScreen() {
		List<ListaSuscripciones> nls = new ArrayList<ListaSuscripciones>();
		List<ListaSuscripciones> ols = new ArrayList<ListaSuscripciones>();
		ols = listaSuscripcionesPantalla.getListaSuscripcionesList();
		if (!GenericUtils.isNullOrBlank(ols)) {
		for(int i = 0;i < ols.size() && i < Constantes.MAX_ROWS;i++)		{
			nls.add(ols.get(i));
		}
		return nls;
		}else return null;
	}

	
	@Override
	public void refrescarListaExcel() {
		setExportExcel(true);
		 List<ListaSuscripciones> list = listaSuscripcionesPantalla.getListaSuscripcionesList();
			if(list==null){
				list = new ArrayList<ListaSuscripciones>();
				listaSuscripcionesPantalla.setListaSuscripcionesList(list);
			}
			list.clear();

			
			if (listaSuscripcionesPantalla.getnumOperacionDesde() != null ||
					listaSuscripcionesPantalla.getnumOperacionHasta() !=null){

					list.addAll((List<ListaSuscripciones>) listaSuscripcionesBo
							.buscarDatosOrdenesOperacion(listaSuscripcionesPantalla.getCampanyaId(),
									listaSuscripcionesPantalla.getfComercializacionDesde(),
									listaSuscripcionesPantalla.getfComercializacionHasta(),
									listaSuscripcionesPantalla.getfCampanyaDesde(),
									listaSuscripcionesPantalla.getfCampanyaHasta(),
									listaSuscripcionesPantalla.getnumOperacionDesde(),
									listaSuscripcionesPantalla.getnumOperacionHasta(),
									listaSuscripcionesPantalla.getOficina(),
									listaSuscripcionesPantalla.getSuscripciones(),
									listaSuscripcionesPantalla.getNumSuscripcionDesde(),
									listaSuscripcionesPantalla.getNumSuscripcionHasta(),
									listaSuscripcionesPantalla.getfSuscripcionDesde(),
									listaSuscripcionesPantalla.getfSuscripcionHasta(),
									listaSuscripcionesPantalla.getNif(),
									listaSuscripcionesPantalla.getUnidadCampanya(),
									paginationData.getPaginationDataForExcel()));

				}else{
					list.addAll((List<ListaSuscripciones>) listaSuscripcionesBo
							.buscarDatosOrdenes(listaSuscripcionesPantalla.getCampanyaId(),
									listaSuscripcionesPantalla.getfComercializacionDesde(),
									listaSuscripcionesPantalla.getfComercializacionHasta(),
									listaSuscripcionesPantalla.getfCampanyaDesde(),
									listaSuscripcionesPantalla.getfCampanyaHasta(),
//									listaSuscripcionesPantalla.getnumOperacionDesde(),
//									listaSuscripcionesPantalla.getnumOperacionHasta(),
									listaSuscripcionesPantalla.getOficina(),
									listaSuscripcionesPantalla.getSuscripciones(),
									listaSuscripcionesPantalla.getNumSuscripcionDesde(),
									listaSuscripcionesPantalla.getNumSuscripcionHasta(),
									listaSuscripcionesPantalla.getfSuscripcionDesde(),
									listaSuscripcionesPantalla.getfSuscripcionHasta(),
									listaSuscripcionesPantalla.getNif(),
									listaSuscripcionesPantalla.getUnidadCampanya(),
									paginationData.getPaginationDataForExcel()));
				}			
			
	}



	@Override
	public void setDataTableList(List<?> dataTableList) {
		listaSuscripcionesPantalla.setListaSuscripcionesList((List<ListaSuscripciones>)dataTableList);
	}
	
		
	public void setNumOper(){
		if(!GenericUtils.isNullOrBlank(listaSuscripcionesPantalla.getnumOperacionDesde()) &&  GenericUtils.isNullOrBlank(listaSuscripcionesPantalla.getnumOperacionHasta()))
			listaSuscripcionesPantalla.setnumOperacionHasta(listaSuscripcionesPantalla.getnumOperacionDesde());
	}
	
	public void setFCampanya(){
		if(!GenericUtils.isNullOrBlank(listaSuscripcionesPantalla.getfCampanyaDesde()) &&  GenericUtils.isNullOrBlank(listaSuscripcionesPantalla.getfCampanyaHasta()))
			listaSuscripcionesPantalla.setfCampanyaHasta(listaSuscripcionesPantalla.getfCampanyaDesde());
	
	}
	
	public void setFComercio(){
		if(!GenericUtils.isNullOrBlank(listaSuscripcionesPantalla.getfComercializacionDesde()) &&  GenericUtils.isNullOrBlank(listaSuscripcionesPantalla.getfComercializacionHasta()))
			listaSuscripcionesPantalla.setfComercializacionHasta(listaSuscripcionesPantalla.getfComercializacionDesde());
	
	}
	

	public void setFSusc(){
		if(!GenericUtils.isNullOrBlank(listaSuscripcionesPantalla.getfSuscripcionDesde()) &&  GenericUtils.isNullOrBlank(listaSuscripcionesPantalla.getfSuscripcionHasta()))
			listaSuscripcionesPantalla.setfSuscripcionHasta(listaSuscripcionesPantalla.getfSuscripcionDesde());
	
	}

	public void setNumSusc(){
		if(!GenericUtils.isNullOrBlank(listaSuscripcionesPantalla.getNumSuscripcionDesde()) &&  GenericUtils.isNullOrBlank(listaSuscripcionesPantalla.getNumSuscripcionHasta()))
			listaSuscripcionesPantalla.setNumSuscripcionHasta(listaSuscripcionesPantalla.getNumSuscripcionDesde());
	
	}	
	/**
	 * 
	 * Para abrir el detalle de la campaña desde Mantenimiento de Suscripciones 
	 * hay que llamar al método “public void consultaDesdeSuscripciones(String id, Date fecha)” 
	 * que está en MantCampanyasAction. 
	 * Hay que pasarle el id de la campaña y la fecha de última actualización. 
	 * - LlamarPantallaOrdenes (Orden orden, string opcion)
	 * 	Se informan los parámetros necesarios y se accede a la pantalla de suscripciones.
	 * 	Los parámetros se informan de la siguiente forma:
	 * 
	 * 	MODO = ‘LIS’
	 * 	CODCAMPA = orden.Campanya.id
	 * 	NUMORDEN = orden.id
	 * 	FEULTACT = orden.FechaModificacion
	 * 	OPCION = opcion
	 * 
	 * @param orden
	 * @param modo
	 */
	public void llamarPantallaOrdenes (Orden orden, String modo){
		setOrden(orden);
	}
	
	/**
	 * Validaciones previas a la llamada a la pantalla de mantenimiento de operaciones
	 * @return true si se pasan las validaciones, false en caso contrario
	 */
	public boolean llamarPantallaMantOperacionesValidator(){
		
		boolean esCorrecto = true;
		
		if(!listaSuscripcionesBo.comprobarOperacionesSuscripcion(listaSuscripcionesPantalla.getListaSuscripcionSel())){
			esCorrecto = false;
			statusMessages.add(Severity.ERROR, "#{messages['listaSuscripciones.error.ordensinoperaciones']}");
		} 

		return esCorrecto;
	}
	
	/**
	 * Función que llama a la pantalla de mantenimiento de operaciones
	 */
	public String llamarPantallaMantOperaciones(){
		parametrosMantOper =  new ParametrosMantoper();
		parametrosMantOper.setModo("CAM");
		parametrosMantOper.setCodcampa(listaSuscripcionesPantalla.getListaSuscripcionSel().getId().getCampanya());
		parametrosMantOper.setNumorden(listaSuscripcionesPantalla.getListaSuscripcionSel().getId().getNumero());
		
		return Constantes.CONSTANTE_SUCCESS;
	}
	
	/**
	 * Función que llama a la pantalla de mantenimiento de campanyas
	 */
	public String llamarPantallaOpercamp(){
		String codcampa = listaSuscripcionesPantalla.getListaSuscripcionSel().getId().getCampanya();
		
		parametrosOpercamp = new ParametrosOpercamp();
		parametrosOpercamp.setCodcampa(codcampa);
		parametrosOpercamp.setFechaact(listaSuscripcionesBo.obtenerMaxFeultact(codcampa));
		parametrosOpercamp.setOpcion("C");

		//Informamos la variable Out campanyaSelec que tambien utiliza en MantCampanyas y sino falla.
		campanyaSelec = listaSuscripcionesBo.obtenerCampanya(codcampa);
		
		return Constantes.CONSTANTE_SUCCESS;
	}

	/**
	 * - DetalleOrden (Orden orden)
	 * 	Acceso a la pantalla de suscripciones en modo consulta: 
	 * LlamarPantallaOrdenes (orden, ‘C’)
	 * @param orden
	 */
	public void detalleOrden (Orden orden){
	
		llamarPantallaOrdenes(orden, "C");
	}
	
	/**
	 * 	Funcion de bloqueo para la tabla deri.suscripc y 
	 * la orden que se está tratando (lista.orden.id)
	 * 	Acceso a la pantalla de suscripciones en modo modificación: 
	 * LlamarPantallaOrdenes (orden, ‘M’) 
	 * @param orden
	 */
	public void modificacionOrden (Orden orden){
		
		llamarPantallaOrdenes(orden, "M");
	}
	
	public String ver(){
	  OrdenId id = new OrdenId();
	  id.setCampanya(listaSuscripcionesPantalla.getListaSuscripcionSel().getId().getCampanya());
	  id.setNumero((listaSuscripcionesPantalla.getListaSuscripcionSel().getId().getNumero()));
	  detalleOrden(listaSuscripcionesBo.recuperarOrden(id));
	  return Constantes.CONSTANTE_SUCCESS;
	}
	

	public String editar(){
		  OrdenId id = new OrdenId();
		  id.setCampanya(listaSuscripcionesPantalla.getListaSuscripcionSel().getId().getCampanya());
		  id.setNumero((listaSuscripcionesPantalla.getListaSuscripcionSel().getId().getNumero()));
		  modificacionOrden( listaSuscripcionesBo.recuperarOrden(id));
		  return Constantes.CONSTANTE_SUCCESS;
	}

	public Campanya getCampanya() {
		return campanya;
	}

	public void setCampanya(Campanya campanya) {
		this.campanya = campanya;
	}

	public void validar(){
		int contador = 0;
		Date fechaUnica = new Date();
		for (ListaSuscripciones listaSuscripciones : listasSeleccionadas) {
			Orden orden = listaSuscripcionesBo.recuperarOrden(new OrdenId(listaSuscripciones.getId().getNumero(),listaSuscripciones.getId().getCampanya()));

			if ((orden.getEstado().equals(Constantes.ORDEN_ESTADO_PV))) {
			
				if (dbLockService.bloqueo(Orden.class, orden.getId())) {

					
					if (listaSuscripcionesBo.insertarOrden(orden, Constantes.ORDEN_ESTADO_VA, orden.getUltimaAccion(), Constantes.ORDEN_VALIDAR,fechaUnica)) 
						contador++;;
						listaSuscripcionesBo.refresh(listaSuscripciones);
				//TODO	HACER COMMIT
					//em.flush();
					dbLockService.desbloqueo(Orden.class, orden.getId());
				}
			}
		}
		if(contador == 0){
			statusMessages.add(Severity.ERROR,"#{messages['listaSuscripciones.error.NingunaValidada']}");
		} else {
			statusMessages.addFromResourceBundle(Severity.INFO,"listaSuscripciones.OrdenesValidadas",contador);
			if((listasSeleccionadas.size() - contador) != 0){
				statusMessages.addFromResourceBundle(Severity.INFO,"listaSuscripciones.OrdenesNoValidadas",(listasSeleccionadas.size() - contador));
			}
		}	
		listasSeleccionadas.clear();
		//SMM: inc 714
		refrescarLista();
	}
	
	
	public void anular(){
		int contador = 0;
		Date fechaUnica = new Date();
		for (ListaSuscripciones listaSuscripciones : listasSeleccionadas) {
				Orden orden = listaSuscripcionesBo.recuperarOrden(new OrdenId(listaSuscripciones.getId().getNumero(),listaSuscripciones.getId().getCampanya()));
			
			if (listaSuscripcionesBo.suscripcionPendienteAgenda(orden) == false) {
				if (!(orden.getEstado().equals(Constantes.ORDEN_ESTADO_PV)) &&
					!(orden.getEstado().equals(Constantes.ORDEN_ESTADO_CA)) &&
					!(orden.getEstado().equals(Constantes.ORDEN_ESTADO_AN)) &&
					!(orden.getEstado().equals(Constantes.ORDEN_ESTADO_VE))) {

					if (dbLockService.bloqueo(Orden.class, orden.getId())) {

						if (listaSuscripcionesBo.insertarOrden(orden, Constantes.ORDEN_ESTADO_PV, "N", Constantes.ORDEN_ANULAR, fechaUnica)) 
							contador++;;
							listaSuscripcionesBo.insertarEvento( Short.valueOf("5017"), orden, fechaUnica);
							listaSuscripcionesBo.refresh(listaSuscripciones);
						//TODO	HACER COMMIT
						//em.flush();
						dbLockService.desbloqueo(Orden.class, orden.getId());
					}





				}
			}else;
			statusMessages.add(Severity.ERROR,"#{messages['listaSuscripciones.error.PendienteProcesar']}");
		}		
					
		
		if(contador == 0){
			statusMessages.add(Severity.ERROR,"#{messages['listaSuscripciones.error.NingunaAnulada']}");
		} else {
			statusMessages.addFromResourceBundle(Severity.INFO,"listaSuscripciones.OrdenesAnuladas",contador);
			if((listasSeleccionadas.size() - contador) != 0){
				statusMessages.addFromResourceBundle(Severity.INFO,"listaSuscripciones.OrdenesNoAnuladas",(listasSeleccionadas.size() - contador));
			}
		
		}
		listasSeleccionadas.clear();	buscar();
	}






	public void cancelar(){
		int contador = 0;
		Date fechaUnica = new Date();
		for (ListaSuscripciones listaSuscripciones : listasSeleccionadas) {
				Orden orden = listaSuscripcionesBo.recuperarOrden(new OrdenId(listaSuscripciones.getId().getNumero(),listaSuscripciones.getId().getCampanya()));
			
			if (listaSuscripcionesBo.suscripcionPendienteAgenda(orden) == false) {
				if (!(orden.getEstado().equals(Constantes.ORDEN_ESTADO_PV)) &&
					!(orden.getEstado().equals(Constantes.ORDEN_ESTADO_CA)) &&
					!(orden.getEstado().equals(Constantes.ORDEN_ESTADO_AN)) &&
					!(orden.getEstado().equals(Constantes.ORDEN_ESTADO_VE))) {
					
					if (dbLockService.bloqueo(Orden.class, orden.getId())) {

						try {
							if (listaSuscripcionesBo.insertarOrden(orden, Constantes.ORDEN_ESTADO_PV, "C", Constantes.ORDEN_CANCELAR, fechaUnica)) 
								contador++;;
								listaSuscripcionesBo.insertarEvento( Short.valueOf("5019"), orden, fechaUnica);
							    listaSuscripcionesBo.refresh(listaSuscripciones);
							//TODO	HACER COMMIT
							//em.flush();
						} finally {
							dbLockService.desbloqueo(Orden.class, orden.getId());
						}
					}

				}
			}else
			statusMessages.add(Severity.ERROR,"#{messages['listaSuscripciones.error.PendienteProcesar']}");
		}		
					
		if(contador == 0){
			statusMessages.add(Severity.ERROR,"#{messages['listaSuscripciones.error.NingunaCancelada']}");
		} else {
			statusMessages.addFromResourceBundle(Severity.INFO,"listaSuscripciones.OrdenesCanceladas",contador);
			if((listasSeleccionadas.size() - contador) != 0){
				statusMessages.addFromResourceBundle(Severity.INFO,"listaSuscripciones.OrdenesNoCanceladas",(listasSeleccionadas.size() - contador));
			}
		refrescarLista();
		}
		listasSeleccionadas.clear(); buscar();
		}


 

	/**
	 *	Los botones Validar, Anular, Cancelar y Modificar se activarán si se marca el check de selección y se cumplen las siguientes condiciones:
	 *	Si orden.UltimaAccion es 'A' ó 'M'
	 *		Si orden.Estado es 'PV'
	 *			Los botones Validar y Modificar estarán activados
	 *		Si orden.Estado es 'VA'
	 *			El botón Modificar estará activado
	 *			Si orden.FechaValor >= sysdate
	 *				El botón Anular estará activado
	 *			si no,
	 *				El botón Cancelar estará activado	
	 *	Si orden.UltimaAccion es 'C'	
	 *		Si orden.Estado es 'PV'
	 *			El botón Validar estará activado
	 *	Si orden.UltimaAccion es 'N'	
	 *		Si orden.Estado es 'PV'
	 *			El botón Validar estará activado	 * 
	 * @param boton
	 * @param ultimaAccion
	 * @return
	 */
	public boolean isBotonDisabled(String boton){
		Date fechaDia = new Date(); // Es obtener Fecha Sistema?
		for (ListaSuscripciones listaSuscripciones : listasSeleccionadas) {
//			Orden orden = listaSuscripcionesBo.recuperarOrden(new OrdenId(listaSuscripciones.getId().getNumero(),listaSuscripciones.getId().getCampanya()));
			 
			switch (listaSuscripciones.getUltimaAccion().charAt(0)) { 
			case 'C':  
		    case 'N': if (Constantes.ORDEN_ESTADO_PV.equals(listaSuscripciones.getEstado()) && Constantes.ORDEN_VALIDAR.equals(boton)) 
		    		  return false; break;
		    case 'A': 
		    case 'M': if (Constantes.ORDEN_ESTADO_PV.equals(listaSuscripciones.getEstado()) && (Constantes.ORDEN_VALIDAR.equals(boton))) 
		    		  return false;
		       		  else if (Constantes.ORDEN_ESTADO_VA.equals(listaSuscripciones.getEstado()) && (fechaDia.compareTo(listaSuscripciones.getFechaValor()) <= 0 ) && Constantes.ORDEN_ANULAR.equals(boton)) 
		       		  return false;
		       		  else if ( Constantes.ORDEN_ESTADO_VA.equals(listaSuscripciones.getEstado()) && (fechaDia.compareTo(listaSuscripciones.getFechaValor()) > 0 ) && Constantes.ORDEN_CANCELAR.equals(boton)) 
		       		  return false;
		    		  break;
		       default: return true;
		       }
		}
		 return true;
	}
	
	public boolean verificarDatosPantalla(){
		char error = ' ';

//		Orden.error.ErrorFechasComercializacion = Fecha inicio comercialización mayor que fecha fin comercialización
		if(!GenericUtils.isNullOrBlank(listaSuscripcionesPantalla.getfComercializacionHasta()) 
				&&  (!GenericUtils.isNullOrBlank(listaSuscripcionesPantalla.getfComercializacionDesde())))
		{ if (listaSuscripcionesPantalla.getfComercializacionHasta().compareTo(listaSuscripcionesPantalla.getfComercializacionDesde()) < 0){
			statusMessages.add(Severity.ERROR,"#{messages['listaSuscripciones.ErrorFechasComercializacion']}");
			error = 'X';}
		}
		 
//		Orden.error.ErrorFechasCampanya = Fecha inicio campaña mayor que fecha fin campaña
		if(!GenericUtils.isNullOrBlank(listaSuscripcionesPantalla.getfCampanyaDesde()) 
				&&  (!GenericUtils.isNullOrBlank(listaSuscripcionesPantalla.getfCampanyaHasta())))
		{ if (listaSuscripcionesPantalla.getfCampanyaHasta().compareTo(listaSuscripcionesPantalla.getfCampanyaDesde()) < 0){
			statusMessages.add(Severity.ERROR,"#{messages['listaSuscripciones.ErrorFechasCampanya']}");
			error = 'X';}
		}

		
//		Orden.error.ErrorFechasSuscripcion = Fecha inicio alta suscripción mayor que fecha finalta suscripción		
		if(!GenericUtils.isNullOrBlank(listaSuscripcionesPantalla.getfSuscripcionDesde()) 
				&&  (!GenericUtils.isNullOrBlank(listaSuscripcionesPantalla.getfSuscripcionHasta())))
		{ if (listaSuscripcionesPantalla.getfSuscripcionHasta().compareTo(listaSuscripcionesPantalla.getfSuscripcionDesde()) < 0){
			statusMessages.add(Severity.ERROR,"#{messages['listaSuscripciones.ErrorFechasSuscripcion']}");
			error = 'X';}
		}

//		Orden.error.ErrorNumOperacion = Operación inicio mayor que Operación fin
		if(!GenericUtils.isNullOrBlank(listaSuscripcionesPantalla.getnumOperacionDesde()) 
				&&  (!GenericUtils.isNullOrBlank(listaSuscripcionesPantalla.getnumOperacionHasta()))) 
		{ if (listaSuscripcionesPantalla.getnumOperacionHasta().compareTo(listaSuscripcionesPantalla.getnumOperacionDesde()) < 0 ){
			statusMessages.add(Severity.ERROR,"#{messages['listaSuscripciones.ErrorNumOperacion']}");
			error = 'X';
		}
		}

		
//		Orden.error.ErrorNumSuscripcion = Nº orden inicio mayor que Nº orden fin
		if(!GenericUtils.isNullOrBlank(listaSuscripcionesPantalla.getNumSuscripcionDesde()) 
				&&  (!GenericUtils.isNullOrBlank(listaSuscripcionesPantalla.getNumSuscripcionHasta()))) 
		{ if (listaSuscripcionesPantalla.getNumSuscripcionHasta().compareTo(listaSuscripcionesPantalla.getNumSuscripcionDesde()) < 0 ){
			statusMessages.add(Severity.ERROR,"#{messages['listaSuscripciones.ErrorNumSuscripcion']}");
			error = 'X';}
		}
		
		if (error == 'X') return false; else return true;

	}
	
	public void salir(){
		Conversation conversacion = Conversation.instance();
		//Volvemos a la anterior conversación
		if(conversacion.isNested()){
			conversacion.redirectToParent();
		} else {
			redirectToURL("/home.seam");
			conversacion.endAndRedirect();
		}
	}
	
	/**
	 * Obtiene la descripción de la campaña para cuando el usuario la introduce de forma manual
	 * en el formulario de búsqueda de suscripciones.
	 */
	public void obtenerDescripcionCampanya(){
		
		
		if(GenericUtils.isNullOrBlank(listaSuscripcionesPantalla.getCampanyaId())){
			listaSuscripcionesPantalla.setDescripcionBO(Constantes.CADENA_VACIA);
		}else{
		Campanya camp = listaSuscripcionesBo.obtenerCampanya(listaSuscripcionesPantalla.getCampanyaId());
		
			if(GenericUtils.isNullOrBlank(camp)){
				
				listaSuscripcionesPantalla.setDescripcionBO(ResourceBundle.instance().getString("listaSuscripciones.campanya.noexiste"));
			} else {
				listaSuscripcionesPantalla.setDescripcionBO(camp.getDescripcionBO());
			}
		}
		
	}
	
	public Boolean getEstadoAgenda() {
		return estadoAgenda;
	}

	public void setEstadoAgenda(Boolean estadoAgenda) {
		this.estadoAgenda = estadoAgenda;
	}

	public EventoAgenda getEventoSelectAgenda() {
		return eventoSelectAgenda;
	}

	public void setEventoSelectAgenda(EventoAgenda eventoSelectAgenda) {
		this.eventoSelectAgenda = eventoSelectAgenda;
	}

	public String getModo() {
		return modo;
	}

	public void setModo(String modo) {
		this.modo = modo;
	}

	public ParametrosOpercamp getParametrosOpercamp() {
		return parametrosOpercamp;
	}

	public void setParametrosOpercamp(ParametrosOpercamp parametrosOpercamp) {
		this.parametrosOpercamp = parametrosOpercamp;
	}

	public Boolean getPrimeraVez() {
		return primeraVez;
	}

	public void setPrimeraVez(Boolean primeraVez) {
		this.primeraVez = primeraVez;
	}

	public void cambioOficina(){
		if(GenericUtils.isNullOrBlank(listaSuscripcionesPantalla.getOficina())){
			listaSuscripcionesPantalla.setDescOficina(null);
		}
	}




	protected List<ListaSuscripciones> listaSeleccionarTodos() {
		if (!busqueda && Constantes.MODO_AGE.equals(modo)){
			 Short codigoEvento;
			 String estadoEvento;
			 
			if  (estadoAgenda)	estadoEvento ="P";
			else estadoEvento ="N";
			codigoEvento = eventoSelectAgenda.getCodigoEvento();
			return listaSuscripcionesBo.cargarAgenda(codigoEvento, estadoEvento, paginationData);
		}else {
		
		if (listaSuscripcionesPantalla.getnumOperacionDesde() != null ||
			listaSuscripcionesPantalla.getnumOperacionHasta() !=null){

			return (List<ListaSuscripciones>) listaSuscripcionesBo
					.buscarDatosOrdenesOperacion(listaSuscripcionesPantalla.getCampanyaId(),
							listaSuscripcionesPantalla.getfComercializacionDesde(),
							listaSuscripcionesPantalla.getfComercializacionHasta(),
							listaSuscripcionesPantalla.getfCampanyaDesde(),
							listaSuscripcionesPantalla.getfCampanyaHasta(),
							listaSuscripcionesPantalla.getnumOperacionDesde(),
							listaSuscripcionesPantalla.getnumOperacionHasta(),
							listaSuscripcionesPantalla.getOficina(),
							listaSuscripcionesPantalla.getSuscripciones(),
							listaSuscripcionesPantalla.getNumSuscripcionDesde(),
							listaSuscripcionesPantalla.getNumSuscripcionHasta(),
							listaSuscripcionesPantalla.getfSuscripcionDesde(),
							listaSuscripcionesPantalla.getfSuscripcionHasta(),
							listaSuscripcionesPantalla.getNif(),
							listaSuscripcionesPantalla.getUnidadCampanya(),
							paginationData);

		}else{
			return (List<ListaSuscripciones>) listaSuscripcionesBo
					.buscarDatosOrdenes(listaSuscripcionesPantalla.getCampanyaId(),
							listaSuscripcionesPantalla.getfComercializacionDesde(),
							listaSuscripcionesPantalla.getfComercializacionHasta(),
							listaSuscripcionesPantalla.getfCampanyaDesde(),
							listaSuscripcionesPantalla.getfCampanyaHasta(),
							listaSuscripcionesPantalla.getOficina(),
							listaSuscripcionesPantalla.getSuscripciones(),
							listaSuscripcionesPantalla.getNumSuscripcionDesde(),
							listaSuscripcionesPantalla.getNumSuscripcionHasta(),
							listaSuscripcionesPantalla.getfSuscripcionDesde(),
							listaSuscripcionesPantalla.getfSuscripcionHasta(),
							listaSuscripcionesPantalla.getNif(),
							listaSuscripcionesPantalla.getUnidadCampanya(),
							paginationData);
		}

		}
	}

	public void voidFunction(){
		msgBoxAction.voidFunction();
	}

	/**
	 * Mostrar PopUp cuando una contrapartida está bloqueada (no bloqueante)
	 */
	public void onVerificarContrapartidaBloqueada() {
		String contrapartida = listaSuscripcionesPantalla.getNif();
		if (!GenericUtils.isNullOrBlank(contrapartida)){
			 Contrapartida contrapObtenida2 = listaSuscripcionesBo.cargarContrapartida(contrapartida.toUpperCase());	
			if (!GenericUtils.isNullOrBlank(contrapObtenida2) && !GenericUtils.isNullOrBlank(contrapObtenida2.getIndBloqueo()) && "S".equalsIgnoreCase(contrapObtenida2.getIndBloqueo())){
				msgboxPanelListaSuscripcionContrapaBloq.init(ResourceBundle.instance().getString("listaSuscripciones.messages.contrapartida.bloqueada.texto"), "listaSuscripcionesAction.voidFunction()", null,"messageBoxPanelContrapa");
			}
		}
	}
	
	public String getRowClasses(){
		StringBuilder builder = new StringBuilder();
		int i=0;
		for (ListaSuscripciones listaSus : listaSuscripcionesPantalla.getListaSuscripcionesList()) {
			Contrapartida contrapartida = null;

			String idContrapartida = listaSus.getContrapartida();
			
			if(i>0){
				builder.append(",");
			}
			
			contrapartida = (Contrapartida) listaSuscripcionesBo.cargarContrapartida(idContrapartida.toUpperCase());
			
			if(i%2==0){
				if(null!=contrapartida && !GenericUtils.isNullOrBlank(contrapartida.getIndBloqueo()) && "S".equalsIgnoreCase(contrapartida.getIndBloqueo())){
					builder.append("oddRowRed");
				}
				else{
					builder.append("oddRow");
				}
			}
			else{
				if(null!=contrapartida && !GenericUtils.isNullOrBlank(contrapartida.getIndBloqueo()) && "S".equalsIgnoreCase(contrapartida.getIndBloqueo())){
					builder.append("evenRowRed");
				}
				else{
					builder.append("evenRow");
				}
			}
			i++;
			contrapartida = null;
		}
		return builder.toString();
	}

}// FIN CLASE ACTION
	
