package com.atosorigin.deri.gestionoperaciones.listasuscripciones.buscadoroficina.action;

import java.util.List;

import org.jboss.seam.ScopeType;
import org.jboss.seam.annotations.In;
import org.jboss.seam.annotations.Name;
import org.jboss.seam.annotations.Scope;

import com.atosorigin.common.action.PaginatedListAction;
import com.atosorigin.common.formvalidator.FormValidator;
import com.atosorigin.deri.apuntescontables.oficina.business.OficinaBo;
import com.atosorigin.deri.gestionoperaciones.listasuscripciones.buscadoroficina.screen.BuscadorOficinaPantalla;
import com.atosorigin.deri.model.apuntesContables.Oficina;


/**
 * Clase que actúa de action listener para el caso de uso de mantenimiento de oficinas.
 */
@Name("buscadorOficinaAction")
@Scope(ScopeType.CONVERSATION)
@FormValidator
public class BuscadorOficinaAction extends PaginatedListAction{

	/**
	 * Inyección del bean de Spring "oficinaBo" que contiene los métodos de negocio
	 * para el caso de uso mantenimiento de Oficinas.
	 */
	@In("#{oficinaBo}")
	protected OficinaBo oficinaBo;


	/**
	 * Inyección del screen bean que contiene los datos de pantalla del caso de uso
	 * mantenimiento de oficinas.
	 */
	@In(create=true)
	protected BuscadorOficinaPantalla buscadorOficinaPantalla;

	/**
	 * Actualiza la lista del grid de oficinas.
	 * 
	 */
	public void buscar() {
		//SMM BUG - resetear ordenacion
		paginationData.reset();
		refrescarLista();
		setPrimerAcceso(false);
		//statusMessages.add("#{messages['status.busqueda.completada']}");
	}

	//Métodos necesarios para pantallas con grids.
	//Es necesario implementar estos métodos abstractos de PaginatedListAction
	@Override
	public List<Oficina> getDataTableList() {
		return buscadorOficinaPantalla.getOficinaList();
	}

	@Override
	@SuppressWarnings("unchecked")
	public void setDataTableList(List<?> dataTableList) {
		buscadorOficinaPantalla.setOficinaList((List<Oficina>)dataTableList);
	}

	@SuppressWarnings("unchecked")
	@Override
	protected void refreshListInternal() {
		List ql = (List)oficinaBo.buscarOficinas(buscadorOficinaPantalla.getCodigo(), buscadorOficinaPantalla.getDescripcion(), null, paginationData);
		buscadorOficinaPantalla.setOficinaList(ql);
	}

	@SuppressWarnings("unchecked")
	@Override
	public void refrescarListaExcel() {
		List ql = (List) oficinaBo.buscarOficinas(null, buscadorOficinaPantalla.getDescripcion(), null,  paginationData.getPaginationDataForExcel());
		buscadorOficinaPantalla.setOficinaList(ql);
	}	
	
}
