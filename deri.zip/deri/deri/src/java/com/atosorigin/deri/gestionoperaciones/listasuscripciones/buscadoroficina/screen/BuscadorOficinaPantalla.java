package com.atosorigin.deri.gestionoperaciones.listasuscripciones.buscadoroficina.screen;

import java.util.List;

import org.jboss.seam.ScopeType;
import org.jboss.seam.annotations.Name;
import org.jboss.seam.annotations.Out;
import org.jboss.seam.annotations.Scope;
import org.jboss.seam.annotations.datamodel.DataModel;
import org.jboss.seam.annotations.datamodel.DataModelSelection;

import com.atosorigin.deri.model.apuntesContables.Oficina;


/**
 *  Contiene los datos de pantalla necesarios para el caso de uso mantenimiento de Oficinas.
 */
@Name("buscadorOficinaPantalla")
@Scope(ScopeType.CONVERSATION)
public class BuscadorOficinaPantalla {

	/** Descripcion. Criterio de búsqueda de oficinas  */
	protected String descripcion;
	
	protected String codigo;
	
	
	/** Lista de datos para el grid. */
	@DataModel(value ="listaBuscadorOficinas")
	protected List<Oficina> oficinaList;
	
	/** Oficina seleccionada en el grid */
	@DataModelSelection(value ="listaBuscadorOficinas")
    @Out(required=false)
    protected Oficina oficina;

	/** Número de resultados totales para los criterios de búsqueda. */
	protected Long numFilas = 0L;
	
	public String getDescripcion() {
		return descripcion;
	}

	public void setDescripcion(String descripcion) {
		this.descripcion = descripcion;
	}

	/**
	 * Obtiene la Lista de datos para el grid.
	 * 
	 * @return la lista de tipos de contrapartidas que mostrará el grid de resultados de la búsqueda.
	 */
	public List<Oficina> getOficinaList() {
		return oficinaList;
	}
	
	/**
	 * Establece la Lista de datos para el grid.
	 * 
	 * @param tipoContrapartidaList la lista de tipos de contrapartidas del grid.
	 */
	public void setOficinaList(List<Oficina> oficinaList) {
		this.oficinaList = oficinaList;
	}

	public Oficina getOficina() {
		return oficina;
	}

	public void setOficina(Oficina oficina) {
		this.oficina = oficina;
	}

	public Long getNumFilas() {
		return numFilas;
	}

	public void setNumFilas(Long numFilas) {
		this.numFilas = numFilas;
	}

	public String getCodigo() {
		return codigo;
	}

	public void setCodigo(String codigo) {
		this.codigo = codigo;
	}

}
