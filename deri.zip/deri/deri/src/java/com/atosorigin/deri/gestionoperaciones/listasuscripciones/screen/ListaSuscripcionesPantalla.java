package com.atosorigin.deri.gestionoperaciones.listasuscripciones.screen;

import java.util.Date;
import java.util.List;

import org.jboss.seam.ScopeType;
import org.jboss.seam.annotations.Name;
import org.jboss.seam.annotations.Out;
import org.jboss.seam.annotations.Scope;
import org.jboss.seam.annotations.datamodel.DataModel;
import org.jboss.seam.annotations.datamodel.DataModelSelection;

import com.atosorigin.deri.model.contrapartida.UnidadNegocio;
import com.atosorigin.deri.model.gestionoperaciones.ListaSuscripciones;


/**
 *  Contiene los datos de pantalla necesarios para el caso de uso Lista de Suscripciones
 */
@Name("listaSuscripcionesPantalla")
@Scope(ScopeType.CONVERSATION)
public class ListaSuscripcionesPantalla {



	/** campanyaId  Criterio de búsqueda de Lista de Suscripciones  */
	protected  String campanyaId;

	/** descripcionBO DescripcionCampanya. Criterio de búsqueda de Lista de Suscripciones  */
	protected  String descripcionBO;
	
	/** fComercializacionDesde. Criterio de búsqueda de Lista de Suscripciones  */
	protected Date fComercializacionDesde;

	/** fComercializacionHasta. Criterio de búsqueda de Lista de Suscripciones  */
	protected Date fComercializacionHasta;

	/** fCampanyaDesde. Criterio de búsqueda de Lista de Suscripciones  */
	protected Date fCampanyaDesde;

	/** fCampanyaHasta. Criterio de búsqueda de Lista de Suscripciones  */
	protected Date fCampanyaHasta;
	
	/** fSuscripcionDesde. Criterio de búsqueda de Lista de Suscripciones  */
	protected Date fSuscripcionDesde;

	/** fSuscripcionHasta. Criterio de búsqueda de Lista de Suscripciones  */
	protected Date fSuscripcionHasta;
	
	/** numOperacionDesde. Criterio de búsqueda de Lista de Suscripciones  */
	protected Long numOperacionDesde;
	
	/** numOperacionHasta. Criterio de búsqueda de Lista de Suscripciones  */
	protected Long numOperacionHasta;
	
	/** numSuscripcionDesde. Criterio de búsqueda de Lista de Suscripciones  */
	protected Long numSuscripcionDesde;
	
	/** numSuscripcionHasta. Criterio de búsqueda de Lista de Suscripciones  */
	protected Long numSuscripcionHasta;
	
	/** oficina. Criterio de búsqueda de Lista de Suscripciones  */
	protected String oficina;
	/** descOficina. Criterio de búsqueda de Lista de Suscripciones  */
	protected String descOficina;
	
	/** suscripciones. Criterio de búsqueda de Lista de Suscripciones  */
	protected String suscripciones;
	
	/** nif. Criterio de búsqueda de Lista de Suscripciones  */
	protected String nif;
	
	/** unidadCampanya. Criterio de búsqueda de Lista de Suscripciones  */
	protected UnidadNegocio unidadCampanya;

	/** Número de resultados totales para los criterios de búsqueda. */
	protected Long numFilas = 0L;	
	
	/** Lista de datos para el grid. */
	@DataModel(value ="listaDtListaSuscripciones")
	protected List<ListaSuscripciones> listaSuscripcionesList;
	
	/** Tipo de documento seleccionado en el grid */
	@DataModelSelection(value ="listaDtListaSuscripciones")
    @Out(required=false)
    protected ListaSuscripciones listaSuscripcionSel;	
	
	@Out(required=false)
	protected ListaSuscripciones listaSuscripcionesSel;
	
	protected Boolean seleccionTotal = false;
	
	public ListaSuscripcionesPantalla(){
		super();
	}
	
	
	public Long getnumOperacionDesde() {
		return numOperacionDesde;
	}

	public void setnumOperacionDesde(Long numOperacionDesde) {
		//if(GenericUtils.isNullOrBlank(this.numOperacionHasta))
			//	this.setnumOperacionHasta(numOperacionDesde);
		this.numOperacionDesde = numOperacionDesde;
	}	

	public Long getnumOperacionHasta() {
		return numOperacionHasta;
	}

	public void setnumOperacionHasta(Long numOperacionHasta) {
		this.numOperacionHasta = numOperacionHasta;
	}	

	
	public List<ListaSuscripciones> getListaSuscripcionesList() {
		return listaSuscripcionesList;
	}

	public void setListaSuscripcionesList(List<ListaSuscripciones> listaSuscripcionesList) {
		this.listaSuscripcionesList = listaSuscripcionesList;
	}	 

	public ListaSuscripciones getListaSuscripcionSel() {
		return listaSuscripcionSel;
	}

	public void setListaSuscripcionSel(ListaSuscripciones listaSuscripcionSel) {
		this.listaSuscripcionSel = listaSuscripcionSel;
	}
	
	public void setListaSuscripcionesSel(ListaSuscripciones listaSuscripcionesSel){
		this.listaSuscripcionesSel = listaSuscripcionesSel; 
	}
	
	 public ListaSuscripciones getListaSuscripcionesSel(){
		 return this.listaSuscripcionesSel;
	 }
	
	public Long getNumFilas() {
		return numFilas;
	}

	public void setNumFilas(Long numFilas) {
		this.numFilas = numFilas;
	}


	public String getCampanyaId() {
		return campanyaId;
	}


	public void setCampanyaId(String campanyaId) {
		this.campanyaId = campanyaId;
	}


	public String getDescripcionBO() {
		return descripcionBO;
	}


	public void setDescripcionBO(String descripcionBO) {
		this.descripcionBO = descripcionBO;
	}


	public Date getfComercializacionDesde() {
		return fComercializacionDesde;
	}


	public void setfComercializacionDesde(Date fComercializacionDesde) {
		this.fComercializacionDesde = fComercializacionDesde;
	}


	public Date getfComercializacionHasta() {
		return fComercializacionHasta;
	}


	public void setfComercializacionHasta(Date fComercializacionHasta) {
		this.fComercializacionHasta = fComercializacionHasta;
	}


	public Date getfCampanyaDesde() {
		return fCampanyaDesde;
	}


	public void setfCampanyaDesde(Date fCampanyaDesde) {
		this.fCampanyaDesde = fCampanyaDesde;
	}


	public Date getfCampanyaHasta() {
		return fCampanyaHasta;
	}


	public void setfCampanyaHasta(Date fCampanyaHasta) {
		this.fCampanyaHasta = fCampanyaHasta;
	}


	public Date getfSuscripcionDesde() {
		return fSuscripcionDesde;
	}


	public void setfSuscripcionDesde(Date fSuscripcionDesde) {
		this.fSuscripcionDesde = fSuscripcionDesde;
	}


	public Date getfSuscripcionHasta() {
		return fSuscripcionHasta;
	}


	public void setfSuscripcionHasta(Date fSuscripcionHasta) {
		this.fSuscripcionHasta = fSuscripcionHasta;
	}


	public Long getNumSuscripcionDesde() {
		return numSuscripcionDesde;
	}


	public void setNumSuscripcionDesde(Long numSuscripcionDesde) {
		this.numSuscripcionDesde = numSuscripcionDesde;
	}


	public Long getNumSuscripcionHasta() {
		return numSuscripcionHasta;
	}


	public void setNumSuscripcionHasta(Long numSuscripcionHasta) {
		this.numSuscripcionHasta = numSuscripcionHasta;
	}


	public String getOficina() {
		return oficina;
	}


	public void setOficina(String oficina) {
		this.oficina = oficina;
	}


	public String getDescOficina() {
		return descOficina;
	}


	public void setDescOficina(String descOficina) {
		this.descOficina = descOficina;
	}


	public String getSuscripciones() {
		return suscripciones;
	}


	public void setSuscripciones(String suscripciones) {
		this.suscripciones = suscripciones;
	}


	public String getNif() {
		return nif;
	}


	public void setNif(String nif) {
		this.nif = nif;
	}


	public UnidadNegocio getUnidadCampanya() {
		return unidadCampanya;
	}


	public void setUnidadCampanya(UnidadNegocio unidadCampanya) {
		this.unidadCampanya = unidadCampanya;
	}


	public Boolean getSeleccionTotal() {
		return seleccionTotal;
	}


	public void setSeleccionTotal(Boolean seleccionTotal) {
		this.seleccionTotal = seleccionTotal;
	}




	

}
