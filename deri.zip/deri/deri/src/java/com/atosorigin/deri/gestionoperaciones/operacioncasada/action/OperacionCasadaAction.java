package com.atosorigin.deri.gestionoperaciones.operacioncasada.action;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.persistence.EntityManager;

import org.jboss.seam.ScopeType;
import org.jboss.seam.annotations.In;
import org.jboss.seam.annotations.Name;
import org.jboss.seam.annotations.Out;
import org.jboss.seam.annotations.Scope;
import org.jboss.seam.core.Init;
import org.jboss.seam.international.StatusMessage.Severity;
import org.jboss.seam.security.Credentials;

import com.atosorigin.common.action.ModoPantalla;
import com.atosorigin.common.action.PaginatedListAction;
import com.atosorigin.common.auditdata.AuditData;
import com.atosorigin.common.constantes.Constantes;
import com.atosorigin.common.constantes.Enumeraciones.ClasificacionOperacion;
import com.atosorigin.common.formvalidator.FormValidator;
import com.atosorigin.common.utils.GenericUtils;
import com.atosorigin.deri.gestionoperaciones.casaroperaciones.action.CasarOperacionesAction;
import com.atosorigin.deri.gestionoperaciones.casaroperaciones.business.CasarOperacionesBo;
import com.atosorigin.deri.gestionoperaciones.operacioncasada.business.OperacionCasadaBo;
import com.atosorigin.deri.gestionoperaciones.operacioncasada.business.OperacionCasadaBo.AgregadoTotales;
import com.atosorigin.deri.gestionoperaciones.operacioncasada.screen.OperacionCasadaPantalla;
import com.atosorigin.deri.model.gestionoperaciones.ExclusionErrores;
import com.atosorigin.deri.model.gestionoperaciones.ExclusionErroresId;
import com.atosorigin.deri.model.gestionoperaciones.Operacion;
import com.atosorigin.deri.model.gestionoperaciones.OperacionCasada;
import com.atosorigin.deri.model.gestionoperaciones.OperacionCasadaId;
import com.atosorigin.deri.model.gestionoperaciones.OperacionId;

@Name("operacionCasadaAction")
@Scope(ScopeType.CONVERSATION)
@FormValidator
public class OperacionCasadaAction extends PaginatedListAction {

	private static final long serialVersionUID = 1L;

	//
	// Campos del panel de búsqueda
	//

	Long numOperacion;

	//
	// Inyecciones
	//

	@In
	Init init;

	@In
	Credentials credentials;

	@In
	EntityManager entityManager;

	@In(value = "#{operacionCasadaBo}")
	protected OperacionCasadaBo operacionCasadaBo;

	@In(value = "#{casarOperacionesBo}")
	protected CasarOperacionesBo casarOperacionesBo;

	@In(create = true)
	protected OperacionCasadaPantalla operacionCasadaPantalla;

//	@In(value = "#{customExcelExporter}")
//	protected CustomExcelExporter customExcelExporter;

	protected boolean habilitarBotones = true;

	protected boolean selecTodos = true;

	
	List<OperacionCasada> listaTotal = null;
	//
	// Outyecciones
	//

//	@DataModel(value = "listaDtOperacionesCasadas")
//	List<OperacionCasada> listaOperacionesCasadas;

//	@DataModelSelection(value = "listaDtOperacionesCasadas")
	@Out(required = false)
	OperacionCasada operacionCasada;

	/** 
	 * @see CasarOperacionesAction#refrescarLista()
	 */
	@Out(required = false)
	List<Operacion> listaOpOut;

	// Modo para la pantalla de detalle

	@Out(value = "modoPantalla", required = false)
	ModoPantalla modoPantallaDetalle;

	private AgregadoTotales agregadoTotales;

	public boolean buscarValidator() {
		
		try {
			numOperacion.longValue();
			
			return true;
		} catch (NumberFormatException e) {
		} catch (NullPointerException e) {
		}

		return false;
	}
	
	public void buscar() {

		paginationData.reset();

		setPrimerAcceso(false);
		operacionCasada = null;
		operacionCasadaPantalla.getSelectedIds().clear();

		listaTotal=null;
		
		refrescarLista();
	}

	public void seleccionarTodos() {

		final List<OperacionCasada> dataTableList = listaTotal;
//		getDataTableList();

		for (OperacionCasada oc : dataTableList) 
			operacionCasadaPantalla.getSelectedIds().put(oc, true);
	}

	public boolean isReadyLigar() {
		return !GenericUtils.getSeleccionCheckbox(
				operacionCasadaPantalla.getSelectedIds()).isEmpty();
	}

	public boolean isReadyDesligar() {
		return !GenericUtils.getSeleccionCheckbox(
				operacionCasadaPantalla.getSelectedIds()).isEmpty();
	}

	public void desligar() {

		final List<OperacionCasada> operaciones = GenericUtils
				.getSeleccionCheckbox(operacionCasadaPantalla.getSelectedIds());

		if (operaciones.isEmpty()) {
			statusMessages
					.add(Severity.ERROR,
							"#{messages['operacionCasada.error.noOperacionSeleccionada']}");
			return;
		}

		final SimpleDateFormat sdf = new SimpleDateFormat(Constantes.DDMMYYYY);

		for (final OperacionCasada oc : operaciones) {

			final OperacionCasada ope = operacionCasadaBo.recargar(oc);
			final long numeroOperacion = oc.getId().getNumeroOperacion();
			final Date fContratacionOperacion = oc.getId()
					.getfContratacionOperacion();

			if (ope.getAgrupacionMercado() == null) {
				statusMessages.addFromResourceBundle(Severity.WARN,
						"operacionCasada.error.opNoAgrupame", String
								.valueOf(numeroOperacion), sdf
								.format(fContratacionOperacion));
				continue;
			}

			if (GenericUtils.equals("S", ope.getIndRelacionEspecial())
					|| GenericUtils.equals(ope.getClaseOperacion(),
							ClasificacionOperacion.MERCADO)) {

				operacionCasadaBo.desligarOperacionRelacionMercado(ope
						.getAgrupacionMercado(), ope.getId()
						.getNumeroOperacion());

				statusMessages.addFromResourceBundle(Severity.INFO,
						"operacionCasada.okOperacionMercadoDesligada", String
								.valueOf(numeroOperacion), sdf
								.format(fContratacionOperacion));
			} else {

				if (ope.getAgrupacionCliente() == null) {
					statusMessages.addFromResourceBundle(Severity.WARN,
							"operacionCasada.error.opClienteNoAgrupacl", String
									.valueOf(numeroOperacion), sdf
									.format(fContratacionOperacion));
				}

				operacionCasadaBo.desligarRelacionCliente(ope.getId()
						.getNumeroOperacion(), ope.getAgrupacionCliente());

				/*
				 * if (ope.getAgrupacionMercado() != null ) {
				 * statusMessages.addFromResourceBundle(Severity.ERROR,
				 * "operacionCasada.error.desligarNoPermitido", id
				 * .getNumeroOperacion(), sdf.format(id
				 * .getfContratacionOperacion())); // continue; }
				 */
				statusMessages.addFromResourceBundle(Severity.INFO,
						"operacionCasada.okOperacionClienteDesligada", String
								.valueOf(numeroOperacion), sdf
								.format(fContratacionOperacion));
			}

			// Refrescar datos de la lista sin regenerarla, ya que se
			// eliminarían los registros no ligados
			final OperacionCasada oc2 = operacionCasadaBo.recargar(oc.getId());

			oc.setAgrupacionCliente(oc2.getAgrupacionCliente());
			oc.setAgrupacionMercado(oc2.getAgrupacionMercado());
		}

		entityManager.flush();
	}

	public void editar() {
		operacionCasada = this.operacionCasadaPantalla.getOperacionCasadaSelec();
		operacionCasada = operacionCasadaBo.cargar(operacionCasada.getId());

		modoPantallaDetalle = ModoPantalla.EDICION;
	}

	public void excluir() {

		ExclusionErrores exErr = new ExclusionErrores();
		ExclusionErroresId exErrId = new ExclusionErroresId();

		if (operacionCasadaPantalla.getOperacionCasadaSelec()
				.getAgrupacionMercado() != null) {

			exErrId.setAgrupacionMercado(operacionCasadaPantalla
					.getOperacionCasadaSelec().getAgrupacionMercado());
		}

		exErr.setId(exErrId);
		operacionCasadaPantalla.setErrorExcluir(exErr);
		statusMessages.add(Severity.INFO,
				"#{messages['operacionCasada.error.yaExcluido']}");
	}

	@Override
	public List<OperacionCasada> getDataTableList() {
		return operacionCasadaPantalla.getListaOperacionesCasadas();
	}

	public String getDescripcionEstado(String estado) {
		return operacionCasadaBo.obtenerDescripcionEstado(estado);
	}

	public String getDescripcionTransaccion(String transaccion) {
		return operacionCasadaBo.obtenerDescripcionTransaccion(transaccion);
	}

	public Long getNumOperacion() {
		return numOperacion;
	}

	public OperacionCasada getOperacionCasada() {
		return operacionCasada;
	}

	public OperacionCasadaPantalla getOperacionCasadaPantalla() {
		return operacionCasadaPantalla;
	}

	public String guardarError() {
		operacionCasadaBo.excluirError(operacionCasadaPantalla
				.getErrorExcluir().getId().getAgrupacionMercado(),
				operacionCasadaPantalla.getErrorExcluir().getId()
						.getCodigoError());
		return "success";
	}

	public boolean guardarErrorValidator() {
		if (!operacionCasadaBo.comprobarError(operacionCasadaPantalla
				.getErrorExcluir().getId().getAgrupacionMercado(),
				operacionCasadaPantalla.getErrorExcluir().getId()
						.getCodigoError())) {
			statusMessages.add(Severity.ERROR,
					"#{messages['operacionCasada.error.yaExcluido']}");
			return false;
		}

		return true;
	}

	public void init() {
//		init.setDebug(true);
	}

	public boolean isHabilitarBotones() {
		return habilitarBotones;
	}

	public boolean isSelecTodos() {
		return selecTodos;
	}

	public void ligar() {

		final List<OperacionCasada> seleccionados = GenericUtils
				.getSeleccionCheckbox(operacionCasadaPantalla.getSelectedIds());

		if (seleccionados.isEmpty()) {
			statusMessages
					.add(Severity.ERROR,
							"#{messages['operacionCasada.error.noOperacionSeleccionada']}");
			return;
		}

		final List<OperacionCasada> operaciones = casarOperacionesBo
				.cargar(seleccionados);

		// casarOperacionesBo.casarOperaciones(operaciones);

		//
		// Outyecciones
		//

		listaOpOut = new ArrayList<Operacion>(operaciones.size());
		for (OperacionCasada oc : operaciones)
			listaOpOut.add(oc.getOperacion());
	}

	public void nuevo() {

		operacionCasada = new OperacionCasada(new OperacionCasadaId());

		final AuditData auditData = new AuditData();
		auditData.setUsuarioUltimaModi(credentials.getUsername());
		operacionCasada.setAuditData(auditData);

		modoPantallaDetalle = ModoPantalla.CREACION;
	}

	public Number obtenerNominal(Long numeroOperacion, Date fecha) {

		if (fecha == null)
			return null;

		return operacionCasadaBo.obtenerNominal(new OperacionCasadaId(
				numeroOperacion, fecha));
	}

	@Override
	protected void refreshListInternal() {

		if (numOperacion == null) {
			statusMessages.addToControl("numOper", Severity.ERROR,
					"#{messages['operacionCasada.error.numOper']}");
			return;
		}

		setExportExcel(false);

		if (listaTotal==null || listaTotal.size()== 0){
			listaTotal = operacionCasadaBo.busqueda(numOperacion);
			agregadoTotales = operacionCasadaBo.obtenerAgregadoTotales(listaTotal);
		}
		
//		setDataTableList(operacionCasadaBo.busqueda(numOperacion));
//
//		agregadoTotales = operacionCasadaBo
//				.obtenerAgregadoTotales(getDataTableList());

		Integer maxResults; 
		if (paginationData !=null && listaTotal !=null && listaTotal.size()!= 0){

			maxResults = paginationData.getMaxResults()*paginationData.getActivePage()+1;
			if (listaTotal.size() < maxResults){
				maxResults = listaTotal.size(); 
			}
			setDataTableList(listaTotal.subList(paginationData.getFirstResult(),maxResults ));
		}
		
		
	}

	@Override
	public void refrescarListaExcel() {

		setExportExcel(true);

//		paginationData = paginationData.getPaginationDataForExcel();

		setDataTableList(operacionCasadaBo.busqueda(numOperacion));

		// customExcelExporter.generarExcel("tablaResultados:table", this);
	}

	@SuppressWarnings("unchecked")
	@Override
	public void setDataTableList(List<?> dataTableList) {
		operacionCasadaPantalla.setListaOperacionesCasadas((List<OperacionCasada>) dataTableList);
	}

	public void setHabilitarBotones(boolean habilitarBotones) {
		this.habilitarBotones = habilitarBotones;
	}

	public void setNumOperacion(Long numOperacion) {
		this.numOperacion = numOperacion;
	}

	public void setOperacionCasada(OperacionCasada operacionCasada) {
		this.operacionCasada = operacionCasada;
	}

	public void setOperacionCasadaPantalla(
			OperacionCasadaPantalla operacionCasadaPantalla) {
		this.operacionCasadaPantalla = operacionCasadaPantalla;
	}

	/**
	 * Selecciona los grupo contrapartidas marcados con los CheckBoxs Indica si
	 * debe habilitarse o no los botones Asignar/Desasignar
	 */
	public void setSelectedItems() {
		operacionCasadaPantalla.getSelectedItems();
		if (operacionCasadaPantalla.getSelectedDataList().isEmpty()) {
			habilitarBotones = true;
			selecTodos = true;
		} else {
			habilitarBotones = false;
			if (operacionCasadaPantalla.getSelectedDataList().size() == operacionCasadaPantalla
					.getListaOperacionesCasadas().size()) {
				selecTodos = false;
			} else {
				selecTodos = true;
			}

		}
	}

	public void setSelecTodos(boolean selecTodos) {
		this.selecTodos = selecTodos;
	}

//	public List<OperacionCasada> getListaOperacionesCasadas() {
//		return listaOperacionesCasadas;
//	}

	public boolean isReadyExcluir() {

		final List<OperacionCasada> seleccionados = GenericUtils
				.getSeleccionCheckbox(operacionCasadaPantalla.getSelectedIds());

		if (seleccionados.size() != 1)
			return false;

		final OperacionCasada operacion = casarOperacionesBo.recargar(
				seleccionados.get(0));

		return operacion.getAgrupacionMercado() != null;
	}

	public AgregadoTotales getAgregadoTotales() {
		return agregadoTotales;
	}
}
