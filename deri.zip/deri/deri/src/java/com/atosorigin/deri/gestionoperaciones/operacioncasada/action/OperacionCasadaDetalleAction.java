package com.atosorigin.deri.gestionoperaciones.operacioncasada.action;

import javax.persistence.EntityManager;

import org.jboss.seam.ScopeType;
import org.jboss.seam.annotations.In;
import org.jboss.seam.annotations.Name;
import org.jboss.seam.annotations.Out;
import org.jboss.seam.annotations.Scope;
import org.jboss.seam.core.ResourceBundle;
import org.jboss.seam.international.StatusMessage.Severity;

import com.atosorigin.common.action.GenericAction;
import com.atosorigin.common.action.ModoPantalla;
import com.atosorigin.common.constantes.Enumeraciones.ClasificacionOperacion;
import com.atosorigin.common.utils.GenericUtils;
import com.atosorigin.deri.gestionoperaciones.operacioncasada.business.OperacionCasadaBo;
import com.atosorigin.deri.model.contrapartida.Contrapartida;
import com.atosorigin.deri.model.gestionoperaciones.OperacionCasada;
import com.atosorigin.deri.model.gestionoperaciones.RequisitosAlta;
import com.atosorigin.deri.util.MessageBoxAction;
import com.atosorigin.deri.util.MsgBoxAction;

@Name("operacionCasadaDetalleAction")
@Scope(ScopeType.CONVERSATION)
public class OperacionCasadaDetalleAction extends GenericAction {

	private static final long serialVersionUID = 1L;

	//
	// Inyecciones
	//

	@In("#{operacionCasadaBo}")
	protected OperacionCasadaBo operacionCasadaBo;

	@In
	protected OperacionCasada operacionCasada;

	@In("modoPantalla")
	protected ModoPantalla modoPantallaIn;

	@In(required = false)
	OperacionCasadaAction operacionCasadaAction;
	
	@In
	EntityManager entityManager;

	@In(create = true)
	MsgBoxAction msgBoxAction;
	
	@Out(required = false, value = "operacionCasadaMessageBoxAction")
	private MessageBoxAction messageBoxOperacionCasadaAction;
	
	private Boolean primeraEjecucionInit=null;
	
	public enum EstadoPantalla {
		INICIO, GUARDAR_READY, GUARDAR_FORZADO_READY;
	}

	EstadoPantalla estadoPantalla = EstadoPantalla.INICIO;

	public String guardar() {

		if (ModoPantalla.INSPECCION.equals(getModoPantalla())) {
			statusMessages.add(Severity.ERROR,
					"#{messages['errores.errorgenerico']}");
			return "failure";
		}

		if (ModoPantalla.EDICION.equals(getModoPantalla())) {

			operacionCasadaBo.modificacionOperacion(operacionCasada);

			entityManager.flush();

			if (operacionCasadaAction != null)
				operacionCasadaAction.refrescarLista();

			return "success";
		}

		if (ModoPantalla.CREACION.equals(getModoPantalla())) {

			final RequisitosAlta requisito = operacionCasadaBo
					.comprobarRequisitosAlta(operacionCasada.getId()
							.getNumeroOperacion());

			if (!requisito.isCumple()) {
				statusMessages.add(Severity.ERROR,
						"#{messages['errores.errorgenerico']}");
				return "failure";
			}

			final OperacionCasada operCasadaRequisito = requisito
					.getOperCasada();

			operacionCasadaBo.altaOperacion(operCasadaRequisito.getId()
					.getNumeroOperacion(), operCasadaRequisito.getId()
					.getfContratacionOperacion(), operCasadaRequisito
					.getDealType(), operCasadaRequisito.getDealNumber(),
					operacionCasada.getClaseOperacion(),operacionCasada.getIndSignoInverso());

			entityManager.flush();

			// Actualizar listado padre

			if (operacionCasadaAction != null) {

				operacionCasadaAction.setNumOperacion(operacionCasada.getId()
						.getNumeroOperacion());
				operacionCasadaAction.buscar();
			}

			return "success";
		}

		return "failure";
	}

	public void init() {

		// init. modo pantalla
		if (modoPantallaIn != null)
			setModoPantalla(modoPantallaIn);
		
	
		if (primeraEjecucionInit == null) {
			primeraEjecucionInit=true;
		} 
		else{
			primeraEjecucionInit = false;
		}

		if(null==messageBoxOperacionCasadaAction) messageBoxOperacionCasadaAction = new MessageBoxAction();

		Contrapartida contrapartida;
		if(primeraEjecucionInit && null!=operacionCasada.getOperacion()){
			contrapartida = (Contrapartida) operacionCasada.getOperacion().getContrapartida();
			if (null!=contrapartida && !GenericUtils.isNullOrBlank(contrapartida.getIndBloqueo()) && "S".equalsIgnoreCase(contrapartida.getIndBloqueo())){
				iniciarPopUpContrapartidaBloqueada();
			}
		}
	}

	public OperacionCasada getOperacionCasada() {
		return operacionCasada;
	}

	public EstadoPantalla getEstadoPantalla() {
		return estadoPantalla;
	}

	public void controlPantalla() {

		if (ModoPantalla.INSPECCION.equals(getModoPantalla()))
			return;

		if (GenericUtils.isNullOrBlank(operacionCasada.getClaseOperacion()))
			return;

		if (ModoPantalla.EDICION.equals(getModoPantalla())) {
			estadoPantalla = EstadoPantalla.GUARDAR_READY;
			return;
		}

		if (ModoPantalla.CREACION.equals(getModoPantalla())) {

			final RequisitosAlta requisito = operacionCasadaBo
					.comprobarRequisitosAlta(operacionCasada.getId()
							.getNumeroOperacion());

			final OperacionCasada operCasadaRequisito = requisito
					.getOperCasada();

			if (requisito.isCumple()) {

				if (operacionCasadaBo.comprobarClasificacionCorrecta(requisito
						.getContrapartida(), operacionCasada
						.getClaseOperacion())) {

					estadoPantalla = EstadoPantalla.GUARDAR_READY;
				} else {
					estadoPantalla = EstadoPantalla.GUARDAR_FORZADO_READY;
				}

				return;
			}

			estadoPantalla = EstadoPantalla.INICIO;

			// Si la operacion casada no es nula, tiene que ser problema del
			// estado
			if (operCasadaRequisito == null) {
				statusMessages
						.add(Severity.ERROR,
								"#{messages['operacionCasada.error.operacionNoExiste']}");
			} else {
				statusMessages
						.add(Severity.ERROR,
								"#{messages['operacionCasada.error.operacionNoValidada']}");
			}
		}
	}
	
	protected ClasificacionOperacion getClasificacion(Object op) {
		
//		if (operacionCasadaBo.comprobarClasificacionCorrecta(operacionCasada
//				.getId().get, ClasificacionOperacion.CLIENTE.toString()))
//			return ClasificacionOperacion.CLIENTE;

		
		return null;
	}
	
	private void iniciarPopUpContrapartidaBloqueada(){
		messageBoxOperacionCasadaAction.init(ResourceBundle.instance().getString("contrapartida.messages.contrapartida.bloqueada.texto"), "operacionCasadaDetalleAction.voidFunction()", null,"messageBoxPanelContrapa");
	}

	public void voidFunction(){
		msgBoxAction.voidFunction();
	}
	
}
