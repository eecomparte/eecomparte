package com.atosorigin.deri.gestionoperaciones.operacioncasada.screen;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.jboss.seam.ScopeType;
import org.jboss.seam.annotations.Name;
import org.jboss.seam.annotations.Out;
import org.jboss.seam.annotations.Scope;
import org.jboss.seam.annotations.datamodel.DataModel;
import org.jboss.seam.annotations.datamodel.DataModelSelection;

import com.atosorigin.common.constantes.Constantes;
import com.atosorigin.common.utils.GenericUtils;
import com.atosorigin.deri.model.gestionoperaciones.ExclusionErrores;
import com.atosorigin.deri.model.gestionoperaciones.Operacion;
import com.atosorigin.deri.model.gestionoperaciones.OperacionCasada;
import com.atosorigin.deri.model.gestionoperaciones.OperacionId;
import com.atosorigin.deri.model.gestionoperaciones.RetOperCasadasBusqueda;


/**
 *  Contiene los datos de pantalla necesarios para el caso de uso mantenimiento de OperacionCasada.
 */
@Name("operacionCasadaPantalla")
@Scope(ScopeType.CONVERSATION)
public class OperacionCasadaPantalla {
	
	@DataModel(value="listaDtOperacionesCasadas")
	protected List<OperacionCasada> listaOperacionesCasadas;
	
	@DataModelSelection(value="listaDtOperacionesCasadas")
	@Out(required=false)
	protected OperacionCasada operacionCasadaSelec;
	
	@Out(value="opCasadaSele", required=false)
	protected OperacionCasada opCasadaSele;
	
	@Out(value="errorExcluir", required=false)
	protected ExclusionErrores errorExcluir;
	
	protected RetOperCasadasBusqueda retOperCasadasBusqueda;

	protected long totalCliente;
	
	protected long totalMercado;
	
	protected Long numOperacion;
	
	
	@Out(value="listaOpOut", required=false)
	protected List<Operacion> listaOpOut;
	
	protected String origenOut;
	
	protected String pantallaOut;

	protected String cadenaLigar = Constantes.CADENA_VACIA;
	
	protected String agrupacion;
	
	protected long agrupOperacion;
	
	protected boolean disabExcluir = true;
	
	/**
	 * Selección checkbox Operacion Casada
	 */
	private Map<OperacionCasada, Boolean> selectedIds = new HashMap<OperacionCasada, Boolean>(10);

	private List<OperacionCasada> selectedDataList = new ArrayList<OperacionCasada>();
	
	public Long getNumOperacion() {
		return numOperacion;
	}
	
	public List<OperacionCasada> getListaOperacionesCasadas() {
		return listaOperacionesCasadas;
	}

	public void setListaOperacionesCasadas(
			List<OperacionCasada> listaOperacionesCasadas) {
		this.listaOperacionesCasadas = listaOperacionesCasadas;
	}

	public OperacionCasada getOperacionCasadaSelec() {
		return operacionCasadaSelec;
	}

	public void setOperacionCasadaSelec(OperacionCasada operacionCasadaSelec) {
		this.operacionCasadaSelec = operacionCasadaSelec;
	}

	public RetOperCasadasBusqueda getRetOperCasadasBusqueda() {
		return retOperCasadasBusqueda;
	}

	public void setRetOperCasadasBusqueda(
			RetOperCasadasBusqueda retOperCasadasBusqueda) {
		this.retOperCasadasBusqueda = retOperCasadasBusqueda;
	}

	public OperacionCasada getOpCasadaSele() {
		return opCasadaSele;
	}

	public void setOpCasadaSele(OperacionCasada opCasadaSele) {
		this.opCasadaSele = opCasadaSele;
	}

	public long getTotalCliente() {
		return totalCliente;
	}

	public void setTotalCliente(long totalCliente) {
		this.totalCliente = totalCliente;
	}

	public long getTotalMercado() {
		return totalMercado;
	}

	public void setTotalMercado(long totalMercado) {
		this.totalMercado = totalMercado;
	}

	public void setNumOperacion(Long numOperacion) {
		this.numOperacion = numOperacion;
	}

	public ExclusionErrores getErrorExcluir() {
		return errorExcluir;
	}

	public void setErrorExcluir(ExclusionErrores errorExcluir) {
		this.errorExcluir = errorExcluir;
	}

    public String getSelectedItems() {
    	boolean borrado = false;
    	 Operacion op = null;
    	 OperacionId opId = null;

		for (OperacionCasada dataItem : GenericUtils
				.getSafeCollection(listaOperacionesCasadas)) {

			if (!GenericUtils.isNullOrBlank(selectedIds.get(dataItem.getId()))) {
				if (selectedIds.get(dataItem.getId()).booleanValue()
						&& !selectedDataList.contains(dataItem)) {
					selectedDataList.add(dataItem);
					selectedIds.remove(dataItem.getId()); // Reset.
					op = new Operacion();
					opId = new OperacionId();
					opId.setNumeroOperacion(dataItem.getId()
							.getNumeroOperacion());
					opId.setFechaContratacion(dataItem.getId()
							.getfContratacionOperacion());
					op.setId(opId);
					if (GenericUtils.isNullOrBlank(dataItem
							.getAgrupacionMercado())) {
						disabExcluir = true;
					} else {
						disabExcluir = false;
					}

				} else if (!selectedIds.get(dataItem.getId()).booleanValue()
						&& selectedDataList.contains(dataItem)) {
					borrado = true;
					selectedDataList.remove(dataItem);
				}
			}
		}
       
        if(borrado){
        	if(!selectedDataList.isEmpty()){
        		for(OperacionCasada opFoco : selectedDataList){
        			if(!GenericUtils.isNullOrBlank(op)){
        				opId.setNumeroOperacion(opFoco.getId().getNumeroOperacion());
        				opId.setFechaContratacion(opFoco.getId().getfContratacionOperacion());
        				op.setId(opId);
        				if(GenericUtils.isNullOrBlank(opFoco.getAgrupacionMercado())){
                			disabExcluir = true;
                		}else{
                			disabExcluir = false;
                		}
        			}
        		}

        	}else{
        		listaOpOut.clear();
        		disabExcluir = true;
        	}
        	
        }

        if (op != null) {
			listaOpOut = new ArrayList<Operacion>();
			listaOpOut.add(op);
		}

        return "selected";
    }

	public Map<OperacionCasada, Boolean> getSelectedIds() {
		return selectedIds;
	}

	public void setSelectedIds(Map<OperacionCasada, Boolean> selectedIds) {
		this.selectedIds = selectedIds;
	}

	public List<OperacionCasada> getSelectedDataList() {
		return selectedDataList;
	}

	public void setSelectedDataList(List<OperacionCasada> selectedDataList) {
		this.selectedDataList = selectedDataList;
	}

	public String getCadenaLigar() {
		return cadenaLigar;
	}

	public void setCadenaLigar(String cadenaLigar) {
		this.cadenaLigar = cadenaLigar;
	}

	public String getAgrupacion() {
		return agrupacion;
	}

	public void setAgrupacion(String agrupacion) {
		this.agrupacion = agrupacion;
	}

	public long getAgrupOperacion() {
		return agrupOperacion;
	}

	public void setAgrupOperacion(long agrupOperacion) {
		this.agrupOperacion = agrupOperacion;
	}

	public List<Operacion> getListaOpOut() {
		return listaOpOut;
	}

	public void setListaOpOut(List<Operacion> listaOpOut) {
		this.listaOpOut = listaOpOut;
	}

	public String getOrigenOut() {
		return origenOut;
	}

	public void setOrigenOut(String origenOut) {
		this.origenOut = origenOut;
	}

	public String getPantallaOut() {
		return pantallaOut;
	}

	public void setPantallaOut(String pantallaOut) {
		this.pantallaOut = pantallaOut;
	}

	public boolean isDisabExcluir() {
		return disabExcluir;
	}

	public void setDisabExcluir(boolean disabExcluir) {
		this.disabExcluir = disabExcluir;
	}

}
