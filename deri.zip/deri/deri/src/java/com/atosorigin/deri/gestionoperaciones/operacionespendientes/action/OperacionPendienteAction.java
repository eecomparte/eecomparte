package com.atosorigin.deri.gestionoperaciones.operacionespendientes.action;

import java.util.List;

import org.jboss.seam.ScopeType;
import org.jboss.seam.annotations.In;
import org.jboss.seam.annotations.Name;
import org.jboss.seam.annotations.Out;
import org.jboss.seam.annotations.Scope;
import org.jboss.seam.international.StatusMessage.Severity;

import com.atosorigin.common.action.PaginatedListAction;
import com.atosorigin.common.constantes.Constantes;
import com.atosorigin.common.formvalidator.FormValidator;
import com.atosorigin.common.utils.GenericUtils;
import com.atosorigin.deri.gestionoperaciones.operacionespendientes.screen.OperacionPendientePantalla;
import com.atosorigin.deri.gestionoperaciones.operacionpendiente.business.OperacionPendienteBo;
import com.atosorigin.deri.model.gestionoperaciones.Operacion;
import com.atosorigin.deri.model.gestionoperaciones.OperacionId;

/**
 * Clase que actúa de action listener para el caso de uso de mantenimiento de
 * operaciones pendientes de casar.
 */
@Name("operacionPendienteAction")
@Scope(ScopeType.CONVERSATION)
@FormValidator
public class OperacionPendienteAction extends PaginatedListAction {

	@Out(value = "listaOpOut", required = false)
	protected List<Operacion> listaOpOut;

	/**
	 * Inyección del bean de Spring "operacionPendienteBo" que contiene los
	 * métodos de negocio para el caso de uso operaciones pendientes de casar.
	 */
	@In("#{operacionPendienteBo}")
	protected OperacionPendienteBo operacionPendienteBo;

	/**
	 * Inyección del screen bean que contiene los datos de pantalla del caso de
	 * uso operaciones pendientes de casar.
	 */
	@In(create = true)
	protected OperacionPendientePantalla operacionPendientePantalla;

	/**
	 * True si debe seleccionar el registro
	 */
	protected boolean exportExcel = false;

	public void setSelectedItems() {
		operacionPendientePantalla.getSelectedItems();
		if (operacionPendientePantalla.getSelectedDataList().isEmpty()
				&& listaOpOut != null)
			listaOpOut.clear();

	}

	/**
	 * Actualiza la lista del grid de consutlas
	 * 
	 */
	public void buscar() {
		paginationData.reset();
		refrescarLista();
		// if (operacionPendientePantalla.getSelectedIds()!=null)
		// operacionPendientePantalla.getSelectedIds().clear();
		if (operacionPendientePantalla.getSelectedDataList() != null) {
			operacionPendientePantalla.getSelectedDataList().clear();
			if (this.listaOpOut != null)
				this.listaOpOut.clear();
		}
		setPrimerAcceso(false);
	}

	/**
	 * Se comprueba si las operaciones seleccionadas son correctas para acceder
	 * a la pantalla de Ligar operaciones
	 */
	public boolean ligarValidator() {
		OperacionPendientePantalla operacionPendientePantalla = this.operacionPendientePantalla;
		// Verificar si no se ha seleccionado ninguna operacion de cl o mercado
		// mostrar mensaje de error
		if (!operacionPendienteBo
				.operacionesAgrupClMeValidas(operacionPendientePantalla
						.getSelectedDataList())) {
			statusMessages.add(Severity.ERROR,
					"operacionpen.error.seleccionerronea");
			return false;
		}
		return true;

	}

	/**
	 * Recupera la lista de operacion a ligar y llamar a la conversacion ligar
	 * Operaciones
	 */
	public String ligar() {

		if (GenericUtils.isNullOrEmpty(operacionPendientePantalla
				.getSelectedDataList())) {

			statusMessages.add(Severity.ERROR,
					"#{messages['operacionpen.error.seleccionerronea']}");

			return Constantes.CONSTANTE_FAIL;
		}

		listaOpOut = operacionPendienteBo
				.operacionesOk(operacionPendientePantalla.getSelectedDataList());
		if (listaOpOut.size() >= 41) {
			statusMessages.add(Severity.INFO,
					"#{messages['operacionpen.aviso.ligarprimeras']}");
		}

		// si son de la misma agrupación sólo se selecciona una operación para la siguienta pantalla, pero la selección continua siendo válida
//		if (listaOpOut.size() == operacionPendientePantalla
//				.getSelectedDataList().size())
			return Constantes.CONSTANTE_SUCCESS;
//
//		statusMessages.add(Severity.ERROR,
//				"#{messages['operacionpen.error.seleccionNoOperacionesOk']}");
//
//		return Constantes.CONSTANTE_FAIL;
	}

	// Métodos necesarios para pantallas con grids.
	@Override
	public List<Operacion> getDataTableList() {
		return operacionPendientePantalla.getOperacionList();
	}

	@Override
	@SuppressWarnings("unchecked")
	public void setDataTableList(List<?> dataTableList) {
		operacionPendientePantalla
				.setOperacionList((List<Operacion>) dataTableList);
	}

	public OperacionPendientePantalla getOperacionPendientePantalla() {
		return operacionPendientePantalla;
	}

	public void setOperacionPendientePantalla(
			OperacionPendientePantalla operacionPendientePantalla) {
		this.operacionPendientePantalla = operacionPendientePantalla;
	}

	@Override
	protected void refreshListInternal() {
		setExportExcel(false);
		OperacionPendientePantalla operacionPendientePantalla = this.operacionPendientePantalla;
		Operacion operacion = new Operacion();
		OperacionId operacionId = new OperacionId();

		operacionId.setFechaContratacion(operacionPendientePantalla
				.getFechadesde());
		operacion.setFechaValor(operacionPendientePantalla.getFechavalor());
		operacion.setFechaVencimiento(operacionPendientePantalla.getFechavenci());
		operacion.setId(operacionId);
		List<Operacion> ql = (List<Operacion>) operacionPendienteBo
				.buscarPendientes(operacion, operacionPendientePantalla
						.getClasificacion(), paginationData);
		setDataTableList(ql);
	}

	@Override
	public void refrescarListaExcel() {
		setExportExcel(true);
		OperacionPendientePantalla operacionPendientePantalla = this.operacionPendientePantalla;
		Operacion operacion = new Operacion();
		OperacionId operacionId = new OperacionId();

		operacionId.setFechaContratacion(operacionPendientePantalla
				.getFechadesde());
		operacion.setFechaValor(operacionPendientePantalla.getFechavalor());
		operacionId.setFechaContratacion(operacionPendientePantalla
				.getFechadesde());
		operacion.setId(operacionId);
		List<Operacion> ql = (List<Operacion>) operacionPendienteBo
				.buscarPendientes(operacion, operacionPendientePantalla
						.getClasificacion(), paginationData
						.getPaginationDataForExcel());
		operacionPendientePantalla.setOperacionList(ql);
	}

}
