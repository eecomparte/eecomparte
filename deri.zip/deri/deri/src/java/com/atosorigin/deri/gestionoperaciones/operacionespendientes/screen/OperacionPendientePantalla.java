package com.atosorigin.deri.gestionoperaciones.operacionespendientes.screen;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.jboss.seam.ScopeType;
import org.jboss.seam.annotations.Name;
import org.jboss.seam.annotations.Out;
import org.jboss.seam.annotations.Scope;
import org.jboss.seam.annotations.datamodel.DataModel;
import org.jboss.seam.annotations.datamodel.DataModelSelection;

import com.atosorigin.common.utils.GenericUtils;
import com.atosorigin.deri.model.gestionoperaciones.Operacion;

/**
 *  Contiene los datos de pantalla necesarios para el caso de uso operaciones pendientes de casar.
 */
@Name("operacionPendientePantalla")
@Scope(ScopeType.CONVERSATION)
public class OperacionPendientePantalla {

	/** Clasificación. Criterio de búsqueda de operaciones. */
	protected String clasificacion;
	
	/** Fecha desde. Criterio de búsqueda de operaciones.*/	
	protected Date fechadesde;
	
	/** Fecha valor. Criterio de búsqueda de operaciones. */
	protected Date fechavalor;
	
	/** Fecha vencimiento. Criterio de búsqueda de operaciones. */
	protected Date fechavenci;
	
	
	/** Lista de datos para el grid. */
	@DataModel(value ="listaDtOperacionesPen")
	protected List<Operacion> operacionList;
	
	@DataModelSelection(value ="listaDtOperacionesPen")
    @Out(value="operacion", required=false)
	protected Operacion operacion;

	/**
	 * Selección checkbox Operacion
	 */
	private Map<Operacion, Boolean> selectedIds = new HashMap<Operacion, Boolean>();
    private List<Operacion> selectedDataList = new ArrayList<Operacion>();
	
	public List<Operacion> getOperacionList() {
		return operacionList;
	}

	public void setOperacionList(List<Operacion> operacionList) {
		this.operacionList = operacionList;
	}

	public Operacion getOperacion() {
		return operacion;
	}

	public void setOperacion(Operacion operacion) {
		this.operacion = operacion;
	}
	
	/*metodos get y set de las variables de pantalla de búsqueda*/
	public String getClasificacion() {
		return clasificacion;
	}

	public void setClasificacion(String clasificacion) {
		this.clasificacion = clasificacion;
	}

	public Date getFechadesde() {
		return fechadesde;
	}

	public void setFechadesde(Date fechadesde) {
		this.fechadesde = fechadesde;
	}

	public Date getFechavalor() {
		return fechavalor;
	}

	public void setFechavalor(Date fechavalor) {
		this.fechavalor = fechavalor;
	}

	public Date getFechavenci() {
		return fechavenci;
	}

	public void setFechavenci(Date fechavenci) {
		this.fechavenci = fechavenci;
	}

	
	//metodos del checkbox
	
	 public String getSelectedItems() {

	        for (Operacion dataItem : operacionList) {
	            if (!GenericUtils.isNullOrBlank(selectedIds.get(dataItem.getId()))){
	            	if (selectedIds.get(dataItem.getId()).booleanValue() 
	            			&& !selectedDataList.contains(dataItem)) {	            		
	            		selectedDataList.add(dataItem);
	            		//selectedIds.remove(dataItem.getId()); 
	            	}else if (!selectedIds.get(dataItem.getId()).booleanValue() 
	            			&& selectedDataList.contains(dataItem)){	            		
	            		selectedDataList.remove(dataItem);
	            	}
	            }
	        }
	        
	        return "selected";
	    }
	
	//método para seleccionar registros
	public Map<Operacion, Boolean> getSelectedIds() {		
		return selectedIds;
	}

	public void setSelectedIds(Map<Operacion, Boolean> selectedIds) {
		this.selectedIds = selectedIds;
	}

	public List<Operacion> getSelectedDataList() {
		return selectedDataList;
	}

	public void setSelectedDataList(List<Operacion> selectedDataList) {
		this.selectedDataList = selectedDataList;
	}
	
}
