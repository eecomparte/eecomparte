package com.atosorigin.deri.gestionoperaciones.ordencontratacion.action;

import java.util.List;

import org.jboss.seam.ScopeType;
import org.jboss.seam.annotations.In;
import org.jboss.seam.annotations.Name;
import org.jboss.seam.annotations.Scope;

import com.atosorigin.common.action.PaginatedListAction;
import com.atosorigin.common.formvalidator.FormValidator;
import com.atosorigin.deri.gestioncampanyas.screen.BuscadorCampanyasPantalla;
import com.atosorigin.deri.gestionoperaciones.orden.business.OrdenBo;
import com.atosorigin.deri.model.gestioncampanyas.Campanya;

/**
 * Clase action listener para el caso de uso de búsqueda campañas desde pantalla de ordenes
 */
@Name("buscadorCampanyaOrdenAction")
@Scope(ScopeType.CONVERSATION)
@FormValidator
public class BuscadorCampanyaOrdenAction extends PaginatedListAction {

	/**
	/**
	 * Inyección del bean de Spring "campanyaBo" que contiene los métodos de negocio
	 * para el caso de uso ordenes.
	 */
	@In("#{ordenBo}")
	protected OrdenBo ordenBo;

	/**
	 * Inyección del screen bean que contiene los datos de pantalla del caso de uso
	 * mantenimiento de búsqueda de campañas
	 */
	@In(create=true)
	protected BuscadorCampanyasPantalla buscadorCampanyasPantalla;

	/**
	 * Actualiza la lista del grid de búsqueda de campañas "desde"
	 * 
	 */
	public void buscar() {
		setPrimerAcceso(false);
		paginationData.reset();		
		refrescarLista();
	}

	//Métodos necesarios para pantallas con grids.
	//Es necesario implementar estos métodos abstractos de PaginatedListAction
	@Override
	public List<Campanya> getDataTableList() {
		return buscadorCampanyasPantalla.getListaCampDesde();
	}

	@Override
	@SuppressWarnings("unchecked")
	public void setDataTableList(List<?> dataTableList) {
		buscadorCampanyasPantalla.setListaCampDesde((List<Campanya>)dataTableList);
	}

	@Override
	protected void refreshListInternal() {
		this.setExportExcel(false);
		String codigo = (this.buscadorCampanyasPantalla.getCodigo()==null || this.buscadorCampanyasPantalla.getCodigo().equals(""))?null:this.buscadorCampanyasPantalla.getCodigo();
		List<Campanya> ql = (List<Campanya>)ordenBo.obtListaCampanya(codigo, this.paginationData);
		buscadorCampanyasPantalla.setListaCampDesde(ql);
	}

	@Override
	public void refrescarListaExcel() {
		this.setExportExcel(true);
		String codigo = (this.buscadorCampanyasPantalla.getCodigo()==null || this.buscadorCampanyasPantalla.getCodigo().equals(""))?null:this.buscadorCampanyasPantalla.getCodigo();
		List<Campanya> ql = (List<Campanya>)ordenBo.obtListaCampanya(codigo, this.paginationData.getPaginationDataForExcel());
		buscadorCampanyasPantalla.setListaCampDesde(ql);
	}	
	
}
