package com.atosorigin.deri.gestionoperaciones.ordencontratacion.action;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.faces.context.ExternalContext;
import javax.faces.context.FacesContext;
import javax.persistence.EntityNotFoundException;

import org.drools.util.StringUtils;
import org.jboss.seam.ScopeType;
import org.jboss.seam.annotations.In;
import org.jboss.seam.annotations.Name;
import org.jboss.seam.annotations.Out;
import org.jboss.seam.annotations.Scope;
import org.jboss.seam.core.ResourceBundle;
import org.jboss.seam.international.StatusMessage.Severity;

import com.atosorigin.common.action.GenericAction;
import com.atosorigin.common.action.ModoPantalla;
import com.atosorigin.common.auditdata.AuditData;
import com.atosorigin.common.constantes.Constantes;
import com.atosorigin.common.formvalidator.FormValidator;
import com.atosorigin.common.utils.GenericUtils;
import com.atosorigin.deri.common.parametrosPantalla.ParametrosMantoper;
import com.atosorigin.deri.contrapartida.business.ContrapartidaBo;
import com.atosorigin.deri.gestioncampanyas.campanya.business.CampanyaBo;
import com.atosorigin.deri.gestionoperaciones.calendariosuscripcion.business.CalendarioSuscripcionBo;
import com.atosorigin.deri.gestionoperaciones.clientessuscripcion.business.ClientesSuscripcionBo;
import com.atosorigin.deri.gestionoperaciones.orden.business.OrdenBo;
import com.atosorigin.deri.gestionoperaciones.ordencontratacion.screen.OrdenContratacionPantalla;
import com.atosorigin.deri.model.contrapartida.Contrapartida;
import com.atosorigin.deri.model.gestioncampanyas.Campanya;
import com.atosorigin.deri.model.gestioncampanyas.OperacionModelo;
import com.atosorigin.deri.model.gestionoperaciones.CalendarioSuscripcion;
import com.atosorigin.deri.model.gestionoperaciones.ClientesSuscripcion;
import com.atosorigin.deri.model.gestionoperaciones.ClientesSuscripcionId;
import com.atosorigin.deri.model.gestionoperaciones.Orden;
import com.atosorigin.deri.util.MessageBoxAction;
import com.atosorigin.deri.util.MsgBoxAction;
/**
 * Clase action listener para el caso de uso de suscripciones
 */
@Name("ordenContratacionAction")
@Scope(ScopeType.CONVERSATION)
@FormValidator
public class OrdenContratacionAction extends GenericAction {

	/**
	 * Inyección del bean de Spring "ordenBo" que contiene los métodos de negocio
	 * para el caso de uso orden de contratación
	 */
	@In("#{ordenBo}")
	protected OrdenBo ordenBo;
	
	@In("#{contrapartidaBo}")
	protected ContrapartidaBo contrapartidaBo;
	
	@In("#{campanyaBo}")
	protected CampanyaBo campanyaBo;
	
	@In("#{clientesSuscripcionBo}")
	protected ClientesSuscripcionBo clientesSuscripcionBo;
	
	@In("#{calendarioSuscripcionBo}")
	protected CalendarioSuscripcionBo calendarioSuscripcionBo;
	
	@Out(required = false, value="parametrosMantOper") //Parametros para MantOper
	private ParametrosMantoper parametrosMantOper;
	
	@In(required=false)
	@Out(required=false)
	protected String llamada;
	
	/**
	 * OperacionModelo con la información a pasar a Calendario
	 */
	private OperacionModelo operacionModelo;
	
	/**
	 * 
	 */
	private BigDecimal disponiblePV_ant;
	
	private BigDecimal importeOrden_ant;
	
	/**
	 * Si true margenOrdenHabilitado estará habilitado en la pantalla 
	 * Si false margenOrdenHabilitado estará deshabilitado
	 */
	private boolean margenOrdenHabilitado = true;
	
	/**
	 * Si true fechaLiqPrimaOrdenHabilitado estará habilitado en la pantalla 
	 * Si false fechaLiqPrimaOrdenHabilitado estará deshabilitado
	 */
	private boolean fechaLiqPrimaOrdenHabilitado = true;
			
	private long numeroTramos;
	
	protected boolean pasaValidacion = false;
	
	protected String opcion;	
	
	private static BigDecimal bdZero = new BigDecimal(0);
	private static BigDecimal bdCien = new BigDecimal(100);
	
	/**
	 * Fecha de la orden a Editar o Ver
	 */
	private Date fechaModifDetalle;
	
	/**
	 * Inyección del screen bean que contiene los datos de pantalla del caso de uso
	 * mantenimiento de orden contratacion.
	 */
	@In(create=true)
	protected OrdenContratacionPantalla ordenContratacionPantalla;
	
	@Out(value="listaClienteSuscripcionOut",required=false)
	protected List<ClientesSuscripcion> listaClienteSuscripcionOut;
	
	@Out(value="listaCalendarioSuscripcionOut", required=false)
	protected List<CalendarioSuscripcion> listaCalendarioSuscripcionOut;
	
	@In(create = true)
	MsgBoxAction msgBoxAction;
	
	@Out(required = false, value = "ordenContratacionDetalleMessageBoxAction")
	private MessageBoxAction messageBoxOrdenContratacionDetalleAction;
	
	public boolean altaValidator(){
		
		setModoPantalla(ModoPantalla.CREACION);
		Campanya campanya = ordenBo.cargarDatosCampanya(ordenContratacionPantalla.getIdCampanya());
		if (GenericUtils.isNullOrBlank(campanya)){
			statusMessages.addToControl("idCampanya", Severity.ERROR, "orden.error.CampanyaInexistente", Constantes.DEFAULT_MESSAGE_TEMPLATE);						
			return false;		
		}
		
		if (!GenericUtils.isNullOrBlank(campanya.getTipoCampanya()) && 
				!campanya.getTipoCampanya().equals(Constantes.CAMP_NO_DISTRIBUIDAS)){
			statusMessages.addToControl("idCampanya", Severity.ERROR, "orden.error.CampanyaErronea", Constantes.DEFAULT_MESSAGE_TEMPLATE);									
			return false;
		}
		ordenContratacionPantalla.setCampanya(campanya);
		return true;
	}

	public String alta(){
		setOpcion("A");
		setModoPantalla(ModoPantalla.CREACION);
		disponiblePV_ant = ordenContratacionPantalla.getCampanya().getDisponibleOrdenesPV();
		importeOrden_ant = bdZero;
		ordenContratacionPantalla.setOrden(ordenBo.cargarDatosFijos(ordenContratacionPantalla.getCampanya()));
		habilitarMargenOrden();
		crearListaClienteSuscripcion();
		//limpiar la descripción del NIF Titular
		ordenContratacionPantalla.setDescContrapartida("");
		return Constantes.CONSTANTE_SUCCESS;
	}

	public void crearListaClienteSuscripcion() {
		if (listaClienteSuscripcionOut==null){
			listaClienteSuscripcionOut = new ArrayList<ClientesSuscripcion>();
		}
	}
	
	public void habilitarMargenOrden(){
		
		Orden orden = ordenContratacionPantalla.getOrden();
		Campanya campanya = ordenContratacionPantalla.getCampanya();
		
		if (GenericUtils.isNullOrBlank(orden.getTipoMargen())
				|| orden.getTipoMargen().equals(Constantes.AUTOMATICO)){
			
			if(!GenericUtils.isNullOrBlank(orden.getImporteOrden())){
				if (!GenericUtils.isNullOrBlank(campanya.getPorcentajeMargenCampanya()) 
						&& campanya.getPorcentajeMargenCampanya().compareTo(bdZero)==1){
					BigDecimal margenOrden = orden.getImporteOrden().multiply(campanya.getPorcentajeMargenCampanya());
					orden.setMargenOrden(margenOrden.divide(bdCien));
				}else if (!GenericUtils.isNullOrBlank(campanya.getMargenCampanya()) 
							&& campanya.getMargenCampanya().compareTo(bdZero)==1){
					orden.setMargenOrden(campanya.getMargenCampanya());	
				}else{
					orden.setMargenOrden(bdZero);
				}
			} else {
				orden.setMargenOrden(null);
			}
			
			setMargenOrdenHabilitado(false);
		//SMM			
		}else if (!GenericUtils.isNullOrBlank(ordenContratacionPantalla.getOrden().getTipoMargen()) &&
				Constantes.MANUAL.equalsIgnoreCase(ordenContratacionPantalla.getOrden().getTipoMargen())){
			setMargenOrdenHabilitado(true);
		}
	}

	public void init(){
		crearListaClienteSuscripcion();
	}
	
	private Boolean primeraEjecucionInit=null;
	public void initDetalle(){
		
		if (primeraEjecucionInit == null) {
			primeraEjecucionInit=true;
		} 
		else{
			primeraEjecucionInit = false;
		}
		
		if(null==messageBoxOrdenContratacionDetalleAction){
			messageBoxOrdenContratacionDetalleAction = new MessageBoxAction();
		}
		
		if(primeraEjecucionInit){
			if(null!=ordenContratacionPantalla.getOrden() && null!=ordenContratacionPantalla.getOrden().getContrapartida() && ordenContratacionPantalla.getOrden().getContrapartida().trim().length()>0){
				String idContrapa = ordenContratacionPantalla.getOrden().getContrapartida();
				Contrapartida contrapartida = contrapartidaBo.cargarContrapartida(idContrapa);
				if (!GenericUtils.isNullOrBlank(contrapartida) && !GenericUtils.isNullOrBlank(contrapartida.getIndBloqueo()) && "S".equalsIgnoreCase(contrapartida.getIndBloqueo())){
					messageBoxOrdenContratacionDetalleAction.init(ResourceBundle.instance().getString("orden.messages.contrapartida.bloqueada.texto"), "ordenContratacionAction.voidFunction()", null,"messageBoxPanelContrapa");
				}
			}
		}
	}
	/*
	 * Proviene de Detalle/Modificar pantalla lista de suscripciones
	 * El sistema muestra la pantalla de detalle de órdenes en modo consulta (ver método DetalleOrden)
	*/
	public void ordenDetalle(String modo, String opcion, String idCampanya, Long feultact, Long numOrden){		
		llamada = "SUSCRIPC";
		setOpcion(opcion);
		setPrimerAcceso(false);
		if (opcion.equals("C"))
			setModoPantalla(ModoPantalla.INSPECCION);
		else if (opcion.equals(Constantes.ACCION_M))
			setModoPantalla(ModoPantalla.EDICION);			
		Date fechaModif = new Date(feultact);
		setFechaModifDetalle(fechaModif);
		Campanya campanya = ordenBo.cargarDatosCampanya(idCampanya);
		Orden orden = ordenBo.cargarDatosOrden(numOrden, campanya, fechaModif);
		
		ordenContratacionPantalla.setCampanya(campanya);
		ordenContratacionPantalla.setOrden(orden);
		
		long numTitulares = ordenBo.obtenerNumeroTitulares(numOrden, campanya.getId(), fechaModif);
		if (numTitulares > 0){
			orden.setIndMultiplesTitulares(Constantes.CONSTANTE_SI);			
		}else{
			orden.setIndMultiplesTitulares(Constantes.CONSTANTE_NO);
		}
		
		long numeroTramos = ordenBo.obtenerNumeroTramos(numOrden, campanya.getId(), fechaModif);		
		 
		if (opcion.equals(Constantes.ACCION_M)){
			AuditData auditData = orden.getAuditData();
			auditData.setFechaUltimaModi(new Date());
			orden.setAuditData(auditData);
			if (numTitulares>0){
				ClientesSuscripcionId clienteSuscripcionId = new ClientesSuscripcionId();
				clienteSuscripcionId.setNumeroOrden(numOrden);
				clienteSuscripcionId.setCodigoCampanya(campanya.getId());
				clienteSuscripcionId.setFechaModificacion(fechaModif);
				listaClienteSuscripcionOut = clientesSuscripcionBo.getTitularesOrden(clienteSuscripcionId);
				crearListaClienteSuscripcion();
			}
			
			if (numeroTramos>0)	{			
				listaCalendarioSuscripcionOut = ordenBo.obtenerTramos(numOrden, campanya.getId(), fechaModif);				
			}
			// SMM actualizamos la fecha de modificación de la lista de Titulares y de Tramos 
			// con el valor de orden.getAuditData.getFechaUltimaModi
			actualizarFechaModificacion(fechaModif);
			habilitarMargenOrden();
		}
		
		if (modoPantalla.equals(ModoPantalla.INSPECCION))	{
			setMargenOrdenHabilitado(false);
			setFechaLiqPrimaOrdenHabilitado(false);
		}
		
		disponiblePV_ant = campanya.getDisponibleOrdenesPV();
		importeOrden_ant = orden.getImporteOrden();

		// HPQC 1819

		final Contrapartida con = contrapartidaBo.cargar(orden
				.getContrapartida());

		if (!GenericUtils.isNullOrBlank(con))
			ordenContratacionPantalla.setDescContrapartida(con.getDescCorta());
	}
	
	/**
	 * Actualización de la Fecha Modificación de las listas de Titulares y de Tramos en el caso de la modificación
	 */
	public void actualizarFechaModificacion(Date fechaModificacion){	
		if (!GenericUtils.isNullOrBlank(listaClienteSuscripcionOut)){
			for (ClientesSuscripcion cls: listaClienteSuscripcionOut){
				cls.getId().setFechaModificacion(fechaModificacion);
			}
		}
		if (!GenericUtils.isNullOrBlank(listaCalendarioSuscripcionOut)){
			for (CalendarioSuscripcion cas: listaCalendarioSuscripcionOut){
				cas.getId().setFechaModificacion(fechaModificacion);
			}
		}
	}
	
	public void validar(){
		
		OrdenContratacionPantalla ordenContratacionPantalla = this.ordenContratacionPantalla;
		Campanya campanya = ordenContratacionPantalla.getCampanya();
		Orden orden = ordenContratacionPantalla.getOrden();
		if (orden.getImporteOrden().compareTo(bdZero)==0){
			statusMessages.addToControl("importeOrden", Severity.ERROR, "orden.error.ImporteNoZero", Constantes.DEFAULT_MESSAGE_TEMPLATE);
			setPasaValidacion(false);
			return;
		}		
		
		if (campanya.getDisponibleOrdenesPV().compareTo(bdZero)<0){
			campanya.setDisponibleOrdenesPV(disponiblePV_ant);
			orden.setImporteOrden(importeOrden_ant);
			statusMessages.addToControl("idCampanya", Severity.ERROR, "orden.error.DisponibleCampanyaNegativo", Constantes.DEFAULT_MESSAGE_TEMPLATE);						
			setPasaValidacion(false);
			return;
		}
		
		if (!validarImporte())	{		
			statusMessages.addToControl("importeOrden", Severity.ERROR, "orden.error.ImporteErroneo", Constantes.DEFAULT_MESSAGE_TEMPLATE);						
			setPasaValidacion(false);
			return;
		}
		
		if (orden.getIndicadorPrima().equals(Constantes.CONSTANTE_NO))	{
			if ((!GenericUtils.isNullOrBlank(orden.getImportePrima()) && orden.getImportePrima().intValue()!=0) 
					||!GenericUtils.isNullOrBlank(orden.getDivisaPrima())
							||!GenericUtils.isNullOrBlank(orden.getFechaLiqPrima())){
				statusMessages.addToControl("indicadorPrima", Severity.ERROR, "orden.error.NoPrima", Constantes.DEFAULT_MESSAGE_TEMPLATE);			
				setPasaValidacion(false);
				return;			
			}
		}else if (orden.getIndicadorPrima().equals(Constantes.ESTADOCO_T)){
			if (!GenericUtils.isNullOrBlank(orden.getFechaLiqPrima())){
				statusMessages.addToControl("indicadorPrima", Severity.ERROR, "orden.error.PrimaPeriodicaFecha", Constantes.DEFAULT_MESSAGE_TEMPLATE);			
				setPasaValidacion(false);
				return;
			}
			if ((GenericUtils.isNullOrBlank(orden.getImportePrima()) || orden.getImportePrima().intValue()==0) 
					||GenericUtils.isNullOrBlank(orden.getDivisaPrima())){
				statusMessages.addToControl("indicadorPrima", Severity.ERROR, "orden.error.PrimaPeriodicaImporte", Constantes.DEFAULT_MESSAGE_TEMPLATE);			
				setPasaValidacion(false);
				return;	
			}			
		}else{
			if ((GenericUtils.isNullOrBlank(orden.getImportePrima()) || orden.getImportePrima().intValue()==0) 
					||GenericUtils.isNullOrBlank(orden.getDivisaPrima())
							||GenericUtils.isNullOrBlank(orden.getFechaLiqPrima())){
				statusMessages.addToControl("indicadorPrima", Severity.ERROR, "orden.error.HayPrima", Constantes.DEFAULT_MESSAGE_TEMPLATE);			
				setPasaValidacion(false);
				return;		
			}
		}
		
		if (modoPantalla.equals(ModoPantalla.CREACION)){
			if (campanya.getEstiloCampanya().equals(Constantes.ESTADOCO_C)){
				//SMM siempre en BBDD será 0 long numeroTramos = ordenBo.obtenerNumeroTramos(orden.getId().getNumero(), campanya.getId(), orden.getAuditData().getFechaUltimaModi());
				int numeroTramos = listaCalendarioSuscripcionOut==null?0:listaCalendarioSuscripcionOut.size();
				if (numeroTramos==0){
					statusMessages.add("#{messages['orden.error.NoHayCalendario']}");			
					this.setPasaValidacion(false);
					return;
				}
			}
		}
		
		BigDecimal disponiblePv_reciente = campanyaBo.buscarDatosCampanya(campanya.getId(), campanya.getAuditData().getFechaUltimaModi()).getDisponibleOrdenesPV();
		if (disponiblePV_ant.compareTo(disponiblePv_reciente)!=0){
			statusMessages.add("#{messages['orden.error.DisponibleModificado']}");			
			this.setPasaValidacion(false);
			return;
		}
		
		//Defect 1569
		/** Se valida la contrapartida introducida por el usuario */
		if(GenericUtils.isNullOrBlank(this.contrapartidaBo.cargar(orden.getContrapartida()))){
			statusMessages.addToControl("idContrapartida", Severity.ERROR,
			"#{messages['preconfirmaciones.error.contrapartida']}");
			setPasaValidacion(false);
			return;
		}
		
		setPasaValidacion(true);
	}
	
	
	public boolean guardarValidator(){		
		return true;
	}
	
	public String guardar(){
		
		Campanya campanya = ordenContratacionPantalla.getCampanya();
		Orden orden = ordenContratacionPantalla.getOrden();
		
		if (modoPantalla.equals(ModoPantalla.CREACION)){		
			//Para Alta
	//		dispsupv + nvl(ImporteOrden_Ant,0) - orden.ImporteOrden
			BigDecimal importe = bdZero;
			if (!GenericUtils.isNullOrBlank(importeOrden_ant)){
				importe = importeOrden_ant;
			}
			importe = importe.subtract(ordenContratacionPantalla.getOrden().getImporteOrden());
			importe = campanya.getDisponibleOrdenesPV().add(importe);
			campanya.setDisponibleOrdenesPV(importe);
			orden.getAuditData().setFechaUltimaModi(new Date());
			ordenBo.altaOrden(campanya, orden);
		}else{
			ordenBo.modificacionOrden(campanya, orden);
		}
		
		actualizarFechaModificacion(orden.getAuditData().getFechaUltimaModi());
		ordenBo.insertarTitulares(listaClienteSuscripcionOut);		
		ordenBo.insertarTramos(listaCalendarioSuscripcionOut);
		setPasaValidacion(false);		
		llamada ="SUSCRIPC";
		return Constantes.SUCCESS;
	}
	
	public void mostrarCalendario(){

		//Recuperar operacion Modelo
		List<OperacionModelo> operacionModeloList = campanyaBo.obtenerOperacionesModelo(ordenContratacionPantalla.getCampanya(), null);
		if (!GenericUtils.isNullOrBlank(operacionModeloList)&&
				!operacionModeloList.isEmpty()){
			setOperacionModelo((OperacionModelo)operacionModeloList.get(0));
		}
		
		if (listaCalendarioSuscripcionOut==null || listaCalendarioSuscripcionOut.isEmpty()){
			listaCalendarioSuscripcionOut = new ArrayList<CalendarioSuscripcion>();
		}
	}
	
	public String opcionesModelo(){
		parametrosMantOper =  new ParametrosMantoper();
		parametrosMantOper.setModo("OPM");
		parametrosMantOper.setCodcampa(ordenContratacionPantalla.getCampanya().getId());
		
		return Constantes.CONSTANTE_SUCCESS;
	}
	
	public String operaciones(){
		parametrosMantOper =  new ParametrosMantoper();
		parametrosMantOper.setModo("CAM");
		parametrosMantOper.setCodcampa(ordenContratacionPantalla.getCampanya().getId());
		parametrosMantOper.setNumorden(ordenContratacionPantalla.getOrden().getId().getNumero());
		
		return Constantes.CONSTANTE_SUCCESS;
	}
	
	public void actualizarContrato(){		
		Orden orden = ordenContratacionPantalla.getOrden();
		if (!GenericUtils.isNullOrBlank(orden.getContrapartida())) {
			
			//Defect 1569
			/** Se valida la contrapartida introducida por el usuario */
			if(GenericUtils.isNullOrBlank(this.contrapartidaBo.cargar(orden.getContrapartida()))){
				statusMessages.addToControl("idContrapartida", Severity.ERROR,
				"#{messages['preconfirmaciones.error.contrapartida']}");
				return;
			}			
		}
		
		String contrato = ordenBo.obtenerContratoContrapartida(orden.getContrapartida());
			
		if (GenericUtils.isNullOrBlank(contrato)){
			orden.setContratoSibis(null);
			orden.setEntidadSibis(null);
			orden.setOficinaSibis(null);
		}else{
			orden.setContratoSibis(contrato.substring(0, 10));
			orden.setEntidadSibis(contrato.substring(11, 15));
			orden.setOficinaSibis(contrato.substring(16, 18));
		}
		Contrapartida con = null;
		try{
			
			con = contrapartidaBo.cargar(orden.getContrapartida());
			if(!GenericUtils.isNullOrBlank(con)){
				ordenContratacionPantalla.setDescContrapartida(con.getDescCorta());
				orden.setOficinaCuentaVista(con.getOficinaCta());
				orden.setDigitoControlCuentaVista("??");
				orden.setCheckCuentaVista(con.getCheckCta());
				orden.setNumeroCuentaVista(con.getNumeroCta().longValue());
			}else{
				ordenContratacionPantalla.setDescContrapartida("-");
				orden.setOficinaCuentaVista(null);
				orden.setDigitoControlCuentaVista(null);
				orden.setCheckCuentaVista(null);
				orden.setNumeroCuentaVista(null);
			}
		}catch(EntityNotFoundException enfe){
			ordenContratacionPantalla.setDescContrapartida("-");
			orden.setOficinaCuentaVista(null);
			orden.setDigitoControlCuentaVista(null);
			orden.setCheckCuentaVista(null);
			orden.setNumeroCuentaVista(null);
		}
		
	}
	
	public OperacionModelo getOperacionModelo() {
		return operacionModelo;
	}

	public void setOperacionModelo(OperacionModelo operacionModelo) {
		this.operacionModelo = operacionModelo;
	}

	public BigDecimal getDisponiblePV_ant() {
		return disponiblePV_ant;
	}

	public void setDisponiblePV_ant(BigDecimal disponiblePVAnt) {
		disponiblePV_ant = disponiblePVAnt;
	}

	public BigDecimal getImporteOrden_ant() {
		return importeOrden_ant;
	}

	public void setImporteOrden_ant(BigDecimal importeOrdenAnt) {
		importeOrden_ant = importeOrdenAnt;
	}	
	
	public boolean actualizarDisponibleOrdenPvValidator(){
		Orden orden = ordenContratacionPantalla.getOrden();
		//SMM: cuando esté vacío no hacer nada
		if (GenericUtils.isNullOrBlank(orden.getImporteOrden())){
			return false;
		}
		if (!validarImporte()){			
			statusMessages.addToControl("importeOrden", Severity.ERROR, "orden.error.ImporteErroneo", Constantes.DEFAULT_MESSAGE_TEMPLATE);
			return false;
		}
		return true;
	}	
	
	public void actualizarDisponibleOrdenPv(){
		
		Campanya campanya = ordenContratacionPantalla.getCampanya();
		Orden orden = ordenContratacionPantalla.getOrden();			
		
		if (orden.getTipoMargen().equals(Constantes.AUTOMATICO)){
			if (!GenericUtils.isNullOrBlank(campanya.getPorcentajeMargenCampanya()) 
					&& campanya.getPorcentajeMargenCampanya().compareTo(bdZero)==1){
				BigDecimal margenOrden = orden.getImporteOrden().multiply(campanya.getPorcentajeMargenCampanya());
				orden.setMargenOrden(margenOrden.divide(bdCien));
			}else if (!GenericUtils.isNullOrBlank(campanya.getMargenCampanya()) 
						&& campanya.getMargenCampanya().compareTo(bdZero)==1){
				orden.setMargenOrden(campanya.getMargenCampanya());	
			}else{
				orden.setMargenOrden(bdZero);
			}
			setMargenOrdenHabilitado(false);
		}else{
			setMargenOrdenHabilitado(true);
		}
		orden.setIndicadorPrima(campanya.getIndicadorPrima());
		
		actualizarCamposPrima();
		
		BigDecimal importe = bdZero;
		if (!GenericUtils.isNullOrBlank(importeOrden_ant)){
			importe = importeOrden_ant;
		}
		importe = importe.subtract(orden.getImporteOrden());
		importe = disponiblePV_ant.add(importe);
		campanya.setDisponibleOrdenesPV(importe);
		ordenContratacionPantalla.setCampanya(campanya);
		
	}
	
	public void actualizarCamposPrima(){
		
		Campanya campanya = ordenContratacionPantalla.getCampanya();
		Orden orden = ordenContratacionPantalla.getOrden();		
		setFechaLiqPrimaOrdenHabilitado(true);	
		BigDecimal importePrima = null;
		if(orden.getIndicadorPrima()== null || orden.getIndicadorPrima().equals(Constantes.CONSTANTE_NO)){
			orden.setImportePrima(bdZero);
			orden.setDivisaPrima(null);
			orden.setFechaLiqPrima(null);
		}else if(orden.getIndicadorPrima().equals("P")){
			BigDecimal porcPrima = campanya.getPorcentajePrima()==null?bdZero:campanya.getPorcentajePrima();
			//Salva
			if (orden.getImporteOrden() !=null) {
				importePrima = orden.getImporteOrden().multiply(porcPrima );	
				orden.setImportePrima(importePrima.divide(bdCien));
			}else{
				importePrima = bdZero;
			}
			orden.setDivisaPrima(orden.getDivisaOrden());;			
		}else if(orden.getIndicadorPrima().equals("F")){
			importePrima = campanya.getImportePrima()==null?bdZero:campanya.getImportePrima();			
			orden.setImportePrima(importePrima);
			orden.setDivisaPrima(orden.getDivisaOrden());
		}else if(orden.getIndicadorPrima().equals("T")){
			BigDecimal porcentajePrima = campanya.getPorcentajePrima()==null?bdZero:campanya.getPorcentajePrima();
			//Salva
			if (orden.getImporteOrden() !=null) {
				importePrima = orden.getImporteOrden().multiply(porcentajePrima);			
				orden.setImportePrima(importePrima.divide(bdCien));
			}else{
				importePrima = bdZero;
			}
			orden.setDivisaPrima(orden.getDivisaOrden());
			orden.setFechaLiqPrima(null);
			setFechaLiqPrimaOrdenHabilitado(false);		
		}
		ordenContratacionPantalla.setCampanya(campanya);
		ordenContratacionPantalla.setOrden(orden);
	}
	
	public boolean isMargenOrdenHabilitado() {
		return margenOrdenHabilitado;
	}

	public void setMargenOrdenHabilitado(boolean margenOrdenHabilitado) {
		this.margenOrdenHabilitado = margenOrdenHabilitado;
	}

	public boolean isFechaLiqPrimaOrdenHabilitado() {
		return fechaLiqPrimaOrdenHabilitado;
	}

	public void setFechaLiqPrimaOrdenHabilitado(boolean fechaLiqPrimaOrdenHabilitado) {
		this.fechaLiqPrimaOrdenHabilitado = fechaLiqPrimaOrdenHabilitado;
	}

	public long getNumeroTramos() {
		return numeroTramos;
	}

	public void setNumeroTramos(long numeroTramos) {
		this.numeroTramos = numeroTramos;
	}

	public Date getFechaModifDetalle() {
		return fechaModifDetalle;
	}

	public void setFechaModifDetalle(Date fechaModifDetalle) {
		this.fechaModifDetalle = fechaModifDetalle;
	}

	public boolean isPasaValidacion() {
		return pasaValidacion;
	}

	public void setPasaValidacion(boolean pasaValidacion) {
		this.pasaValidacion = pasaValidacion;
	}

	public String getOpcion() {
		return opcion;
	}

	public void setOpcion(String opcion) {
		this.opcion = opcion;
	}

	public boolean validarImporte(){
		Campanya campanya = ordenContratacionPantalla.getCampanya();
		Orden orden = ordenContratacionPantalla.getOrden();		
		if (orden.getImporteOrden().compareTo(campanya.getImporteMinimoOrden())==-1 
				||orden.getImporteOrden().compareTo(campanya.getImporteMaximoOrden())==1)	{						
			return false;
		}
		return true;
	}
	
	public void actualizarDivisa(){
		Orden orden = ordenContratacionPantalla.getOrden();	
		if (GenericUtils.isNullOrBlank(orden.getIndicadorPrima()) 
				||!orden.getIndicadorPrima().equals(Constantes.CONSTANTE_NO)){
			orden.setDivisaPrima(orden.getDivisaOrden());			
		}
	}
	
	public void actualizarIndPrima(){
		actualizarCamposPrima();
		
	}
	
	public boolean isDisabledBtnVer() {
		if (modoPantalla.equals(ModoPantalla.INSPECCION)) {
			Orden orden = ordenContratacionPantalla.getOrden();
			if (GenericUtils.isNullOrBlank(orden) 
					|| GenericUtils.isNullOrBlank(orden.getIndMultiplesTitulares())
					|| Constantes.CONSTANTE_NO.equals(orden.getIndMultiplesTitulares())){
				return true;
			}
		}
		return false;
	}	
	
	public boolean isDisabledBtnCalendario() {
		Orden orden = ordenContratacionPantalla.getOrden();
		if (!GenericUtils.isNullOrBlank(orden) 
				&& Constantes.MODELIZADA.equals(orden.getEstiloCampanya())){
			return true;
		}else{
			if (ModoPantalla.INSPECCION.equals(modoPantalla) && numeroTramos==0 ){
				return true;
			}
		}
		return false;
	}
	
	public void salirDetalle(){
		super.salir();
		if (ordenContratacionPantalla.getCampanya()!=null){
			campanyaBo.recargar(ordenContratacionPantalla.getCampanya());
		}
	}
	
	public void rollBack(){
		setPasaValidacion(false);
		listaClienteSuscripcionOut=null;
		listaCalendarioSuscripcionOut=null;
		
		String campanyaId = new String(ordenContratacionPantalla.getCampanya().getId());
		Long numOperacion = new Long(ordenContratacionPantalla.getOrden().getId().getNumero());
		
		ordenContratacionPantalla.setCampanya(null);
		ordenContratacionPantalla.setCheckMasTitulares(false);
		ordenContratacionPantalla.setOrden(null);
		
		if (modoPantalla.equals(ModoPantalla.CREACION)){			
			altaValidator();
			alta();
		}else{
			String opcion = null;
			if (modoPantalla.equals(ModoPantalla.INSPECCION)){
				opcion = "C";
			}else{
				opcion = "M";
			}
			ordenDetalle("LSIS", opcion, campanyaId, getFechaModifDetalle().getTime(), numOperacion);
			
		}
		FacesContext facesContext = FacesContext.getCurrentInstance();
		ExternalContext ctx = facesContext.getExternalContext();
		try {
			ctx.redirect(ctx.encodeResourceURL("ordenContratacionDetalle.seam"));
		}catch (Exception e) {
			System.err.println("OrdenContratacionDetalle exception: " + e);
		}
		FacesContext.getCurrentInstance().responseComplete();
	}
	
	public void obtenerDescripcionCampanya(){
		
		Campanya camp = ordenBo.cargarDatosCampanya(ordenContratacionPantalla.getIdCampanya());
		
		if(GenericUtils.isNullOrBlank(camp)){
			ordenContratacionPantalla.setDescCampanya(ResourceBundle.instance().getString("orden.error.campanya.noexiste"));
		} else {
			ordenContratacionPantalla.setDescCampanya(camp.getDescripcionBO());
		}
		
	}
	
	public boolean crearListaSuscripcion(){
		crearListaClienteSuscripcion();
		return true;
	}

	public void voidFunction(){
		msgBoxAction.voidFunction();
	}

	/**
	 * Mostrar PopUp cuando una contrapartida está bloqueada (no bloqueante)
	 */
	public void onVerificarContrapartidaBloqueada() {
		if(null!=ordenContratacionPantalla.getOrden() && null!=ordenContratacionPantalla.getOrden().getContrapartida() && ordenContratacionPantalla.getOrden().getContrapartida().trim().length()>0){
			String idContrapa = ordenContratacionPantalla.getOrden().getContrapartida();
			Contrapartida contrapartida = contrapartidaBo.cargarContrapartida(idContrapa.toUpperCase());
			if (!GenericUtils.isNullOrBlank(contrapartida) && !GenericUtils.isNullOrBlank(contrapartida.getIndBloqueo()) && "S".equalsIgnoreCase(contrapartida.getIndBloqueo())){
				messageBoxOrdenContratacionDetalleAction.init(ResourceBundle.instance().getString("orden.messages.contrapartida.bloqueada.texto"), "ordenContratacionAction.voidFunction()", null,"messageBoxPanelContrapa");
			}
		}
		actualizarContrato();
	}
	
	public void borrarPimeraEjecucion(){
		primeraEjecucionInit = null;
	}

}
