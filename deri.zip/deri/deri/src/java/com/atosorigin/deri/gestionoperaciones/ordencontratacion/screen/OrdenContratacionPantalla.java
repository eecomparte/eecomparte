package com.atosorigin.deri.gestionoperaciones.ordencontratacion.screen;

import org.jboss.seam.ScopeType;
import org.jboss.seam.annotations.Name;
import org.jboss.seam.annotations.Scope;

import com.atosorigin.common.constantes.Constantes;
import com.atosorigin.common.utils.GenericUtils;
import com.atosorigin.deri.model.gestioncampanyas.Campanya;
import com.atosorigin.deri.model.gestionoperaciones.Orden;

/**
 *  Contiene los datos de pantalla necesarios para el caso de uso de suscripciones.
 */

@Name("ordenContratacionPantalla")
@Scope(ScopeType.CONVERSATION)
public class OrdenContratacionPantalla {

	/** Clasificación. Criterio de búsqueda de campanya. */
	protected String idCampanya;	
	
	/** Clasificación. Visualización de descripción campanya. */
	protected String descCampanya;	
	
	protected Campanya campanya;
	
	protected Orden orden;		

	protected Boolean checkMasTitulares;
	
	protected String descContrapartida;
	
	public String getIdCampanya() {
		return idCampanya;
	}

	public void setIdCampanya(String idCampanya) {
		this.idCampanya = idCampanya;
	}

	public Campanya getCampanya() {
		return campanya;
	}

	public Orden getOrden() {
		return orden;
	}

	public void setCampanya(Campanya campanya) {
		this.campanya = campanya;
	}

	public String getDescCampanya() {
		return descCampanya;
	}

	public void setDescCampanya(String descCampanya) {
		this.descCampanya = descCampanya;
	}

	public void setOrden(Orden orden) {
		this.orden = orden;
	}

	public Boolean getCheckMasTitulares() {
		
		if(!GenericUtils.isNullOrBlank(orden)
				&& !GenericUtils.isNullOrBlank(orden.getIndMultiplesTitulares())
				&& Constantes.CONSTANTE_SI.equalsIgnoreCase(orden.getIndMultiplesTitulares())){
			return true;
		} else {
			return false;
		}
	}

	public void setCheckMasTitulares(Boolean checkMasTitulares) {
		this.checkMasTitulares = checkMasTitulares;
	}

	public String getDescContrapartida() {
		return descContrapartida;
	}

	public void setDescContrapartida(String descContrapartida) {
		this.descContrapartida = descContrapartida;
	}

}
