package com.atosorigin.deri.gestionoperaciones.productocompuesto.action;

import java.math.BigDecimal;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import javax.persistence.RollbackException;

import org.apache.commons.beanutils.BeanUtils;
import org.jboss.seam.ScopeType;
import org.jboss.seam.annotations.In;
import org.jboss.seam.annotations.Name;
import org.jboss.seam.annotations.Out;
import org.jboss.seam.annotations.Scope;
import org.jboss.seam.core.Conversation;
import org.jboss.seam.core.ResourceBundle;
import org.jboss.seam.international.StatusMessage.Severity;
import org.jboss.seam.security.Identity;

import com.atosorigin.common.action.ModoPantalla;
import com.atosorigin.common.action.PaginatedListAction;
import com.atosorigin.common.constantes.Constantes;
import com.atosorigin.common.formvalidator.FormValidator;
import com.atosorigin.common.utils.GenericUtils;
import com.atosorigin.deri.common.dbLock.DbLockService;
import com.atosorigin.deri.common.parametrosPantalla.ParametrosOutAgenda;
import com.atosorigin.deri.gestionoperaciones.productocompuesto.business.MantProdCompuestoBo;
import com.atosorigin.deri.gestionoperaciones.productocompuesto.screen.MantProdCompuestoPantalla;
import com.atosorigin.deri.model.catalogo.HistoricoProductoCompuesto;
import com.atosorigin.deri.model.contrapartida.Contrapartida;
import com.atosorigin.deri.model.contrapartida.DocsContrapartida;
import com.atosorigin.deri.model.gestionoperaciones.HistoricoOperacion;
import com.atosorigin.deri.model.gestionoperaciones.VistaOperacion;
import com.atosorigin.deri.util.MessageBoxAction;
import com.atosorigin.deri.util.MsgBoxAction;

@Name("mantProdCompuestoAction")
@Scope(ScopeType.CONVERSATION)
@FormValidator
public class MantProdCompuestoAction extends PaginatedListAction {
	
	//Para formatear las fechas en los mensajes de aviso.
	protected SimpleDateFormat sdf1 = new SimpleDateFormat(Constantes.DDMMYYYY);
	
	/** Inyección del servicio que gestiona los bloqueos de registros en base de datos */
	@In(create = true)
	protected DbLockService dbLockService;

	// outjectar el registro selccionado para mod y consulta
	@Out(value = "historicoProductoCompuesto", required = false)
	protected HistoricoProductoCompuesto historicoProductoCompuesto;
	
	//outjectar el string pantalla para que la pagina de Lista de Operaciones de la boleta sepa quien la ha llamado
	@Out(value = "pantalla", required = false)
	protected String pantalla;
	

	@Out(value = "timestampInicial", required = false)
	protected Date timestampInicial;

	//outjectar el long estructuraId para la pagina de Lista de confirmaciones ADMCONFI
	@Out(required=false)
	private Long estructuraId;
	
	@Out(required=false)
	private Boolean consulta;
	
	@Out(required=false)
	private Boolean alta;

	@In("#{mantProdCompuestoBo}")
	protected MantProdCompuestoBo mantProdCompuestoBo;

	@In(create = true)
	protected MantProdCompuestoPantalla mantProdCompuestoPantalla;

	/** Inyección datos provenientes de Agenda*/
	@In(required = false, value="#{parametrosOutAgenda}")
	protected ParametrosOutAgenda parametrosOutAgenda;
	
	protected boolean vieneAgenda;
	
	@In(create = true)
	MsgBoxAction msgBoxAction;
	
	@Out(required = false, value = "mantProdCompuestoMessageBoxAction")
	private MessageBoxAction messageBoxmantProdCompuestoAction;
	
	public void copiarSeleccionado() {
		this.historicoProductoCompuesto = mantProdCompuestoPantalla.getProductoCompuestoSelect();
	}

	// ### FUNCIONES PARA GESTIONAR LOS CHECKBOX ###
	/**
	 * Cada vez que se selecciona/deselecciona un prod comp se actualiza la
	 * lista de las seleccionadas y se comprueba si están habilitados los
	 * botones
	 */
	public void seleccionarProdComp() {
		this.getProdCompSeleccionados();
	}

	/**
	 * Recorre la lista de liquidaciones y carga los elementos seleccionados
	 */
	public void getProdCompSeleccionados() {

		// Contiene todas las prod comp visibles
		List<HistoricoProductoCompuesto> prodCompList = mantProdCompuestoPantalla.getProdCompuestoResultados();

		HistoricoProductoCompuesto dataItem = null;

		int tamanyoLista = prodCompList.size();

		if (tamanyoLista > paginationData.getMaxResults()) { // Cuando hay
																// paginación el
																// último
																// registro no
																// se debe tener
																// en cuenta
			tamanyoLista--;
		}

		// Recorremos toda la lista de prod comp, verificando cual está y no
		// seleccionada
		// para asignarla a SelectedProdCompList
		for (int i = 0; i < tamanyoLista; i++) {
			dataItem = prodCompList.get(i);

			if (!GenericUtils.isNullOrBlank(mantProdCompuestoPantalla.getSelectedProdCompIds().get(dataItem.getId()))) {

				if (mantProdCompuestoPantalla.getSelectedProdCompIds().get(dataItem.getId()).booleanValue()
						&& !mantProdCompuestoPantalla.getSelectedProdCompList().contains(dataItem)) {

					mantProdCompuestoPantalla.getSelectedProdCompList().add(dataItem);

					// if(mantProdCompuestoPantalla.getSelectedProdCompList().size()
					// == tamanyoLista){
					// mantProdCompuestoPantalla.setSelecTodos(true);
					// }
				} else if (!mantProdCompuestoPantalla.getSelectedProdCompIds().get(dataItem.getId()).booleanValue()
						&& mantProdCompuestoPantalla.getSelectedProdCompList().contains(dataItem)) {
					mantProdCompuestoPantalla.getSelectedProdCompList().remove(dataItem);
					mantProdCompuestoPantalla.getSelectedProdCompIds().remove(dataItem.getId());
					// mantProdCompuestoPantalla.setSelecTodos(false);
				}
			}
			dataItem = null;
		}
	}
	// ### FIN CHECKBOX ###
	

	// Muestra el icono de modificar para los registros que cumplan los
	// requisitos necesarios.
	public boolean mostrarIconoModificar(HistoricoProductoCompuesto registro) {
		boolean mostrarIcono = false;
		String estadoco = "";
		String indsitua = "";

		estadoco = registro.getEstado();
		indsitua = registro.getUltimaAccion();

		if (estadoco.equals("PV") && (indsitua.equals("A") || indsitua.equals("M"))) {
			mostrarIcono = true;
		} else if (estadoco.equals("VA") || estadoco.equals("IN")) {
			mostrarIcono = true;
		}

		return mostrarIcono;
	}
	
	// Muestra el icono de confirmar para los registros que cumplan los
	// requisitos necesarios.
	public boolean mostrarIconoConfirmar(HistoricoProductoCompuesto registro) {
		boolean mostrarIcono = false;
		String estadoco = "";
		String indsitua = "";

		estadoco = registro.getEstado();
		indsitua = registro.getUltimaAccion();

		if (estadoco.equals("VA") && (indsitua.equals("S"))){
			mostrarIcono = true;
		} 

		return mostrarIcono;
	}

	// Muestra el icono de anular para los registros que cumplan los
	// requisitos necesarios.
	public boolean mostrarIconoAnular(HistoricoProductoCompuesto registro) {
		boolean mostrarIcono = false;
		String estadoco = "";
		String indsitua = "";

		estadoco = registro.getEstado();
		indsitua = registro.getUltimaAccion();

		if ((estadoco.equals("PV") && indsitua.equals("A")) || estadoco.equals("IN")) {
			mostrarIcono = true;
		} else {
			mostrarIcono = false;
		}

		return mostrarIcono;
	}
	public String salirMantProdComp() {
		Conversation conversacion = Conversation.instance();
		//Volvemos a la anterior conversación
		if(conversacion.isNested()){
			conversacion.redirectToParent();
		} else {
			redirectToURL("/home.seam");
			conversacion.endAndRedirect();
		}
		return "";
	}

	public String modificarProdCompuesto() {
		
		//Outjectamos historicoProductoCompuesto
		copiarSeleccionado();
		
		this.estructuraId = historicoProductoCompuesto.getId().getEstructu();
		//BLOQUEAR LA ESTRUCTURA (tabla deri.oprodcom, clave ESTRUCTU, FECHAOPE, FEULTACT)
		if(!dbLockService.bloqueo(HistoricoProductoCompuesto.class, historicoProductoCompuesto.getId())){
			statusMessages.addFromResourceBundle(Severity.ERROR,
					"mantProdCompuesto.messages.modificar.blocked",
					historicoProductoCompuesto.getId().getEstructu());
			return Constantes.FAIL;
		}
		
		/*
		 * Según el Detallado: Diremos que estamos en modo ‘Alta’: Si viene
		 * desde Mantenimiento Productos Compuestos y deri.oprodcom.estadoco =
		 * ‘PV’ o ‘IN’ y deri.oprodcom.indisitua = ‘A’
		 */
		if((mantProdCompuestoPantalla.getProductoCompuestoSelect().getEstado().equals("PV") 
				|| mantProdCompuestoPantalla.getProductoCompuestoSelect().getEstado().equals("IN"))
				&& mantProdCompuestoPantalla.getProductoCompuestoSelect().getUltimaAccion().equals("A")){
			alta = true;
			this.modoPantalla=ModoPantalla.CREACION;
		} else {
			alta = false;
			this.modoPantalla=ModoPantalla.EDICION;
		}
		consulta = false;
		this.pantalla = "MANTPROD";		
		timestampInicial = new Date();
//		log.info(timestampInicial.toString());log.error(timestampInicial.toString());
//		timestampInicial = mantProdCompuestoBo.obtenerSysdate();
//		log.info(timestampInicial.toString());log.error(timestampInicial.toString());
		return Constantes.SUCCESS;
	}
	
	public boolean modificarProdCompuestoValidator() {
		
		HistoricoProductoCompuesto registro = mantProdCompuestoPantalla.getProductoCompuestoSelect();
		
		boolean sePuedeModificar = true;
		
		Long estructu = registro.getId().getEstructu();
		Date fechaope = registro.getFechaContratacion();
		Date feultact = registro.getId().getFechaModificacion();
		
		if(!mantProdCompuestoBo.comprobarFechaUltimaModi(estructu, fechaope, feultact)){
			sePuedeModificar = false;
			statusMessages.addFromResourceBundle(Severity.ERROR,
			        "mantProdCompuesto.validar.modificada",
			        estructu,
			        sdf1.format(fechaope));
		}		
		
		return sePuedeModificar;
	}

	

	public void anularProdCompuesto() {
		
		mantProdCompuestoBo.cambiarEstadoProdCompuesto(this.historicoProductoCompuesto, Constantes.ESTADO_AN, 
				this.historicoProductoCompuesto.getUltimaAccion());
		
		dbLockService.desbloqueo(HistoricoProductoCompuesto.class, this.historicoProductoCompuesto.getId());
		
		refrescarLista();
		
	}
	
	public boolean anularProdCompuestoValidator() {
		
		HistoricoProductoCompuesto registro = this.historicoProductoCompuesto; 
//			mantProdCompuestoPantalla.getProductoCompuestoSelect();
		List<VistaOperacion> vistaList = mantProdCompuestoBo.obtenerOperEstructura(registro);
		
		boolean sePuedeAnular = true;
		
		if(vistaList != null && vistaList.size() > 0) {
			sePuedeAnular = false;
			statusMessages.addFromResourceBundle(Severity.ERROR,
			        "mantProdCompuesto.anular.conoperaciones");
			return sePuedeAnular;
		}		

		//BLOQUEAR LA ESTRUCTURA (tabla deri.oprodcom, clave ESTRUCTU, FECHAOPE, FEULTACT)
		if(!dbLockService.bloqueo(HistoricoProductoCompuesto.class, registro.getId())){
			statusMessages.addFromResourceBundle(Severity.ERROR,
					"mantProdCompuesto.messages.modificar.blocked",
					registro.getId().getEstructu());
			sePuedeAnular = false;
		}
		return sePuedeAnular;
	}


	
	public String confirmarProdCompuesto() {
		
		copiarSeleccionado();
		this.estructuraId = historicoProductoCompuesto.getId().getEstructu();
		return Constantes.SUCCESS;
	}

	public String consultarProdCompuesto() {
		
		//Outjectamos historicoProductoCompuesto
		copiarSeleccionado();
		
		this.estructuraId = historicoProductoCompuesto.getId().getEstructu();
		
		//Ponemos la pantalla en modo consultar/inspeccion
		this.setModoPantalla(ModoPantalla.INSPECCION);
		alta=false;
		consulta = true;
		this.pantalla = "MANTPROD";
		
		return Constantes.SUCCESS;
	}

	public boolean buscarBotonValidator(){
		return validacionesDesdeHasta();
	}
	
	public void buscarBoton() {
		primerAcceso = false;
		paginationData.reset();
		refrescarLista();
	}

	public void obtenerCatalogoProdCompuesto() {
		String procedencia = "";
		if (!GenericUtils.isNullOrBlank(mantProdCompuestoPantalla.getProcedencia())) {
			procedencia = mantProdCompuestoPantalla.getProcedencia();
			mantProdCompuestoPantalla.setProdCompuestoList(mantProdCompuestoBo.getCatalogoProdCompuesto(procedencia));
//			for (CatalogoProdCompuesto element : mantProdCompuestoPantalla.getProdCompuestoList()) {
//			
//				if ("A".equals(element.getDescripcion())){
//					if (element.getHistoricoProductoCompuestos()==null){
//						continue;
//					}
//				}
//				element.getId(); 	
//			}
		} else {
			mantProdCompuestoPantalla.setProdCompuestoList(null);
		}
	}

	@Override
	public List<?> getDataTableList() {

		return mantProdCompuestoPantalla.getProdCompuestoResultados();
	}

	@Override
	protected void refreshListInternal() {

		// Limpiamos checkbox
		if(!GenericUtils.isNullOrBlank(this.mantProdCompuestoPantalla.getSelectedProdCompIds())){
			this.mantProdCompuestoPantalla.getSelectedProdCompIds().clear();
		}
		
		if (!GenericUtils.isNullOrBlank(this.mantProdCompuestoPantalla.getSelectedProdCompList())){
			this.mantProdCompuestoPantalla.getSelectedProdCompList().clear();
		}
		
		exportExcel = false;
		setVieneAgenda(false);
		String procedencia = Constantes.CADENA_VACIA;
		String prodCompuesto = Constantes.CADENA_VACIA;
		String contrapartida = Constantes.CADENA_VACIA;
		String situacion = Constantes.CADENA_VACIA;
		Date fechaValorDesde = null;
		Date fechaValorHasta = null;
		Date fechaVtoDesde = null;
		Date fechaVtoHasta = null;
		Date fContratDesde = null;
		Date fContratHasta = null;
		String numEstructDesde = Constantes.CADENA_VACIA;
		String numEstructHasta = Constantes.CADENA_VACIA;

		if (!GenericUtils.isNullOrBlank(mantProdCompuestoPantalla.getProcedencia())) {
			procedencia = mantProdCompuestoPantalla.getProcedencia();
		}
		if (!GenericUtils.isNullOrBlank(mantProdCompuestoPantalla.getProdCompuesto())) {
			if (!GenericUtils.isNullOrBlank(mantProdCompuestoPantalla.getProdCompuesto().getId())) {
				prodCompuesto = new Integer(mantProdCompuestoPantalla.getProdCompuesto().getId()).toString();
			}
		}
		if (!GenericUtils.isNullOrBlank(mantProdCompuestoPantalla.getContrapartida())) {
			contrapartida = mantProdCompuestoPantalla.getContrapartida();
		}
		if (!GenericUtils.isNullOrBlank(mantProdCompuestoPantalla.getSituacion())) {
			situacion = mantProdCompuestoPantalla.getSituacion();
		}
		if (!GenericUtils.isNullOrBlank(mantProdCompuestoPantalla.getFechaValorDesde())) {
			fechaValorDesde = mantProdCompuestoPantalla.getFechaValorDesde();
		}
		if (!GenericUtils.isNullOrBlank(mantProdCompuestoPantalla.getFechaValorHasta())) {
			fechaValorHasta = mantProdCompuestoPantalla.getFechaValorHasta();
		}
		if (!GenericUtils.isNullOrBlank(mantProdCompuestoPantalla.getFechaVtoDesde())) {
			fechaVtoDesde = mantProdCompuestoPantalla.getFechaVtoDesde();
		}
		if (!GenericUtils.isNullOrBlank(mantProdCompuestoPantalla.getFechaVtoHasta())) {
			fechaVtoHasta = mantProdCompuestoPantalla.getFechaVtoHasta();
		}
		if (!GenericUtils.isNullOrBlank(mantProdCompuestoPantalla.getfContratDesde())) {
			fContratDesde = mantProdCompuestoPantalla.getfContratDesde();
		}
		if (!GenericUtils.isNullOrBlank(mantProdCompuestoPantalla.getfContratHasta())) {
			fContratHasta = mantProdCompuestoPantalla.getfContratHasta();
		}
		if (!GenericUtils.isNullOrBlank(mantProdCompuestoPantalla.getNumEstructDesde())) {
			numEstructDesde = mantProdCompuestoPantalla.getNumEstructDesde();
		}
		if (!GenericUtils.isNullOrBlank(mantProdCompuestoPantalla.getNumEstructHasta())) {
			numEstructHasta = mantProdCompuestoPantalla.getNumEstructHasta();
		}

		mantProdCompuestoPantalla.setProdCompuestoResultados(mantProdCompuestoBo.buscarOperacionesCompuestas(procedencia, prodCompuesto,
				contrapartida, situacion, fechaValorDesde, fechaValorHasta, fechaVtoDesde, fechaVtoHasta, fContratDesde, fContratHasta,
				numEstructDesde, numEstructHasta, paginationData));

	}

	@Override
	public void refrescarListaExcel() {
		
		exportExcel = true;
		
		if(isVieneAgenda()){
			this.rellenarListaAgendaExcel();
		} else {
			String procedencia = Constantes.CADENA_VACIA;
			String prodCompuesto = Constantes.CADENA_VACIA;
			String contrapartida = Constantes.CADENA_VACIA;
			String situacion = Constantes.CADENA_VACIA;
			Date fechaValorDesde = null;
			Date fechaValorHasta = null;
			Date fechaVtoDesde = null;
			Date fechaVtoHasta = null;
			Date fContratDesde = null;
			Date fContratHasta = null;
			String numEstructDesde = Constantes.CADENA_VACIA;
			String numEstructHasta = Constantes.CADENA_VACIA;

			if (!GenericUtils.isNullOrBlank(mantProdCompuestoPantalla.getProcedencia())) {
				procedencia = mantProdCompuestoPantalla.getProcedencia();
			}
			if (!GenericUtils.isNullOrBlank(mantProdCompuestoPantalla.getProdCompuesto())) {
				if (!GenericUtils.isNullOrBlank(mantProdCompuestoPantalla.getProdCompuesto().getId())) {
					prodCompuesto = new Integer(mantProdCompuestoPantalla.getProdCompuesto().getId()).toString();
				}
			}
			if (!GenericUtils.isNullOrBlank(mantProdCompuestoPantalla.getContrapartida())) {
				contrapartida = mantProdCompuestoPantalla.getContrapartida();
			}
			if (!GenericUtils.isNullOrBlank(mantProdCompuestoPantalla.getSituacion())) {
				situacion = mantProdCompuestoPantalla.getSituacion();
			}
			if (!GenericUtils.isNullOrBlank(mantProdCompuestoPantalla.getFechaValorDesde())) {
				fechaValorDesde = mantProdCompuestoPantalla.getFechaValorDesde();
			}
			if (!GenericUtils.isNullOrBlank(mantProdCompuestoPantalla.getFechaValorHasta())) {
				fechaValorHasta = mantProdCompuestoPantalla.getFechaValorHasta();
			}
			if (!GenericUtils.isNullOrBlank(mantProdCompuestoPantalla.getFechaVtoDesde())) {
				fechaVtoDesde = mantProdCompuestoPantalla.getFechaVtoDesde();
			}
			if (!GenericUtils.isNullOrBlank(mantProdCompuestoPantalla.getFechaVtoHasta())) {
				fechaVtoHasta = mantProdCompuestoPantalla.getFechaVtoHasta();
			}
			if (!GenericUtils.isNullOrBlank(mantProdCompuestoPantalla.getfContratDesde())) {
				fContratDesde = mantProdCompuestoPantalla.getfContratDesde();
			}
			if (!GenericUtils.isNullOrBlank(mantProdCompuestoPantalla.getfContratHasta())) {
				fContratHasta = mantProdCompuestoPantalla.getfContratHasta();
			}
			if (!GenericUtils.isNullOrBlank(mantProdCompuestoPantalla.getNumEstructDesde())) {
				numEstructDesde = mantProdCompuestoPantalla.getNumEstructDesde();
			}
			if (!GenericUtils.isNullOrBlank(mantProdCompuestoPantalla.getNumEstructHasta())) {
				numEstructHasta = mantProdCompuestoPantalla.getNumEstructHasta();
			}

			mantProdCompuestoPantalla.setProdCompuestoResultados(mantProdCompuestoBo.buscarOperacionesCompuestas(procedencia, prodCompuesto,
					contrapartida, situacion, fechaValorDesde, fechaValorHasta, fechaVtoDesde, fechaVtoHasta, fContratDesde, fContratHasta,
					numEstructDesde, numEstructHasta, paginationData.getPaginationDataForExcel()));
		}
		
	}

	/**
	 * Para cada uno de los registros seleccionados recupera las operaciones
	 * pertenecientes a esa estructura, y para cada una de ellas llama al módulo
	 * de validación, como en MANTOPER
	 */
	public void validarProductoCompuesto() {

		List<VistaOperacion> listaOperaciones;
		HistoricoProductoCompuesto histproNuevo;
		Date fecUltAct = new Date();
		boolean validacionCorrecta = true;

		for (HistoricoProductoCompuesto prodComp : mantProdCompuestoPantalla.getSelectedProdCompList()) {
			
			//Comprobamos el estado y también la fecha de ultima actualización
			if (this.comprobarEsValidable(prodComp)){
				
				if (!mantProdCompuestoBo.validateExistenciaAgendaValid(prodComp)) {
				
					listaOperaciones = mantProdCompuestoBo.obtenerOperEstructura(prodComp);
				
				for (VistaOperacion vistaOperacion : listaOperaciones) {
					//0 - OPERACION SOLO PV SINO NO COMPROBAR NADA NI HACER NADA
					//Si no es PV que hacemos se puede validar la Estructura?
					if ("PV".equalsIgnoreCase(vistaOperacion.getHistOper().getEstado().getCodigo())){
					
					//1 - LLAMAR A PDTE_AGENDA
					if (!mantProdCompuestoBo.pdtValidarOperAgenda(vistaOperacion.getNcorrela(),
							vistaOperacion.getFechaope())){
						//2 - BLOQUEAR
						if (dbLockService.bloqueo(HistoricoOperacion.class, vistaOperacion.getHistOper().getId())){
							//3 - COMPROBAR FECHA ULTIMA ACTUALIZACIÓN
							if (!mantProdCompuestoBo.comprobarFecultact(vistaOperacion)){
								dbLockService.desbloqueo(HistoricoOperacion.class, vistaOperacion.getHistOper().getId());
								//Fechas coinciden, mostrar aviso
								statusMessages.addFromResourceBundle(Severity.ERROR,
									"mantProdCompuesto.validar.operacion.modificada",
									vistaOperacion.getNcorrela(),
									sdf1.format(vistaOperacion.getFechaope()));
								validacionCorrecta = false;
							} else {
								//4 - VALIDAR
								try {
									if(!mantProdCompuestoBo.validarProductoCompuesto(vistaOperacion)){
										validacionCorrecta = false;
									}
								} catch (RollbackException e) {
									validacionCorrecta = false;
									statusMessages.addFromResourceBundle(Severity.ERROR,
											"mantProdCompuesto.validar.rollback",
											prodComp.getId().getEstructu(),
											sdf1.format(prodComp.getFechaContratacion()));
									throw new RollbackException(e);
								} finally {
									dbLockService.desbloqueo(HistoricoOperacion.class, vistaOperacion.getHistOper().getId());
								}
								//5 - DESBLOQUEAR
								dbLockService.desbloqueo(HistoricoOperacion.class, vistaOperacion.getHistOper().getId());
							}
						} else {
							//Registro bloqueado: mostrar aviso
							statusMessages.addFromResourceBundle(Severity.WARN,
									"mantProdCompuesto.validar.bloqueado",
									vistaOperacion.getNcorrela(),
									sdf1.format(vistaOperacion.getHistOper().getFechaValor()),
									sdf1.format(vistaOperacion.getHistOper().getFechaVencimiento()));
							validacionCorrecta = false;
						}
					} else {//Pendiente Agenda: Mostrar aviso
						statusMessages.addFromResourceBundle(Severity.WARN,
							"mantProdCompuesto.validar.pte",
							vistaOperacion.getNcorrela(),
							sdf1.format(vistaOperacion.getHistOper().getFechaValor()),
							sdf1.format(vistaOperacion.getHistOper().getFechaVencimiento()));
						validacionCorrecta = false;
					}
					} //ESTADO PV
					
				}
				
				if (validacionCorrecta){
					
					String estadoNuevo = null;
					listaOperaciones = mantProdCompuestoBo.obtenerOperEstructura(prodComp);
				
					
//					ESTADOCO: se revisarán las operaciones que componen el producto y se pondrá (siguiendo el orden indicado:
//						•	VA, si hay alguna operación con ESTADOCO = ‘VA’
//						•	VE, si hay alguna operación con ESTADOCO = ‘VE’
//						•	EJ, si hay alguna operación con ESTADOCO = ‘EJ’ 
//						•	CA, si hay alguna operación con ESTADOCO = ‘CA’

					for (VistaOperacion vistaOperacion : listaOperaciones) {

						if (Constantes.ESTADO_VA.equals(vistaOperacion.getHistOper().getEstado().getCodigo())){
							estadoNuevo = Constantes.ESTADO_VA;
							break;
						}else if (Constantes.ESTADO_VE.equals(vistaOperacion.getHistOper().getEstado().getCodigo())){
							if (!Constantes.ESTADO_VA.equals(estadoNuevo)) estadoNuevo = Constantes.ESTADO_VE;
						}else if ("EJ".equals(vistaOperacion.getHistOper().getEstado().getCodigo())){
							if (!Constantes.ESTADO_VA.equals(estadoNuevo) && !Constantes.ESTADO_VE.equals(estadoNuevo) ) 
							estadoNuevo = "EJ";
						}else if ("CA".equals(vistaOperacion.getHistOper().getEstado().getCodigo())){
							if (!Constantes.ESTADO_VA.equals(estadoNuevo) && !Constantes.ESTADO_VE.equals(estadoNuevo) &&
									!"EJ".equals(estadoNuevo) )
							estadoNuevo = "CA";
						}
					}
					
					if (estadoNuevo!=null){
						histproNuevo = copiarProductoCompuesto(prodComp,fecUltAct,estadoNuevo);
						mantProdCompuestoBo.altaProductoCompuesto(histproNuevo);
					}
				}
			
			}else{//No hay los eventos ptes Agenda necesarios.
					statusMessages.addFromResourceBundle(Severity.ERROR,
							"mantProdCompuesto.validar.evento",
							prodComp.getId().getEstructu(),
							sdf1.format(prodComp.getFechaContratacion()));
			}	
		}
		}
		
		if (isVieneAgenda()){
			rellenarListaAgenda();
		}else{
			refrescarLista();	
		}
		
	}
	
	/**
	 * Hace una copia del producto compuesto para su validación, cambiando los campos de fecha y
	 * usuario de última actualización, así como el estado que pasa a ser VA
	 * @param estadoNuevo 
	 */
	private HistoricoProductoCompuesto copiarProductoCompuesto(
			HistoricoProductoCompuesto prodComp, Date fecUltAct, String estadoNuevo) {
		
		HistoricoProductoCompuesto nuevo = new HistoricoProductoCompuesto();
		
		try {
			nuevo = (HistoricoProductoCompuesto) BeanUtils.cloneBean(prodComp);
		} catch (Exception e) {
			e.printStackTrace();
		} 
		
		nuevo.setEstado(estadoNuevo);
		nuevo.getId().setFechaModificacion(fecUltAct);
		nuevo.setUsuario(Identity.instance().getCredentials().getUsername());
		(nuevo.getAuditData()).setFechaUltimaModi(fecUltAct);
		(nuevo.getAuditData()).setUsuarioUltimaModi(Identity.instance().getCredentials().getUsername());
		
		return nuevo;
	}

	public boolean habilitarBotonValidar(){
		
		String estadoco;
		boolean habilitado = false;
		
		if (!GenericUtils.isNullOrBlank(mantProdCompuestoPantalla.getSelectedProdCompList())
				&& !mantProdCompuestoPantalla.getSelectedProdCompList().isEmpty()){
			for (HistoricoProductoCompuesto histprod : mantProdCompuestoPantalla.getSelectedProdCompList()) {
				estadoco = histprod.getEstado();
				if (Constantes.TIPO_ESTADO_PV.equalsIgnoreCase(estadoco)){
					habilitado = true;
				}
			}
		}
		
		return habilitado;
	}
	
	/**
	 * Comprueba su el registro seleccionado por el usuario cumple las condiciones
	 * para su validación
	 */
	private boolean comprobarEsValidable(HistoricoProductoCompuesto prodComp) {

		boolean esValidable = true;
		 
		if(!Constantes.TIPO_ESTADO_PV.equalsIgnoreCase(prodComp.getEstado())){
			esValidable = false;
			statusMessages.addFromResourceBundle(Severity.ERROR,
				"mantProdCompuesto.validar.nopv",
				prodComp.getId().getEstructu(),
				sdf1.format(prodComp.getFechaContratacion()));
		} else if (!mantProdCompuestoBo.comprobarFechaUltimaModi(prodComp.getId().getEstructu(),
					prodComp.getFechaContratacion(),
					prodComp.getId().getFechaModificacion())){
			esValidable = false;
			statusMessages.addFromResourceBundle(Severity.ERROR,
					"mantProdCompuesto.validar.modificada",
					prodComp.getId().getEstructu(),
					sdf1.format(prodComp.getFechaContratacion()));
		}
			
		return esValidable;
		
	}

	@SuppressWarnings("unchecked")
	@Override
	public void setDataTableList(List<?> dataTableList) {
		mantProdCompuestoPantalla.setProdCompuestoResultados((List<HistoricoProductoCompuesto>)dataTableList);

	}

	public DbLockService getDbLockService() {
		return dbLockService;
	}

	public void setDbLockService(DbLockService dbLockService) {
		this.dbLockService = dbLockService;
	}

	
	public String getPantalla() {
		return pantalla;
	}

	public void setPantalla(String pantalla) {
		this.pantalla = pantalla;
	}

	public HistoricoProductoCompuesto getHistoricoProductoCompuesto() {
		return historicoProductoCompuesto;
	}

	public void setHistoricoProductoCompuesto(
			HistoricoProductoCompuesto historicoProductoCompuesto) {
		this.historicoProductoCompuesto = historicoProductoCompuesto;
	}

	public String obtenerDescSituacion(String estadoco, String indSitua){
		
		return mantProdCompuestoBo.obtenerDescSituacion(estadoco , indSitua);
	}

	public Boolean getAlta() {
		return alta;
	}

	public void setAlta(Boolean alta) {
		this.alta = alta;
	}
	
//	public void validaDesdeHasta(){
//		BigDecimal estructuDesde = null; 
//		BigDecimal estructuHasta = null;
//		boolean continuar = true;
//		try{
//			if(!GenericUtils.isNullOrBlank(mantProdCompuestoPantalla.getNumEstructDesde())){
//				estructuDesde = new BigDecimal(mantProdCompuestoPantalla.getNumEstructDesde());
//			}
//		}catch(NumberFormatException nfe) {
//			statusMessages.addToControl("numEstrucDesde",Severity.ERROR, "#{messages['mantProdCompuesto.error.desde.numero']}");
//			continuar = false;
//			
//		}
//		try{
//			if(!GenericUtils.isNullOrBlank(mantProdCompuestoPantalla.getNumEstructHasta())){
//				estructuHasta = new BigDecimal(mantProdCompuestoPantalla.getNumEstructHasta());
//			}
//		}catch(NumberFormatException nfe) {
//			statusMessages.addToControl("numEstrucHasta",Severity.ERROR, "#{messages['mantProdCompuesto.error.hasta.numero']}");
//			continuar = false;
//			
//		}
//	}

	public void asignarDesdeHastaEstructu(){
		
		BigDecimal estructuDesde = null;
		
		if(!GenericUtils.isNullOrBlank(mantProdCompuestoPantalla.getNumEstructDesde()) 
				&& validaEstructuDesde(mantProdCompuestoPantalla.getNumEstructDesde())){
			mantProdCompuestoPantalla.setNumEstructHasta(mantProdCompuestoPantalla.getNumEstructDesde());
			validacionesDesdeHasta();
		}
	}
	
	private boolean validaEstructuDesde(String estructu){
		
		BigDecimal estructuDesde = null; 
		boolean esValido = true;
		
		try{
			estructuDesde = new BigDecimal(estructu);
		} catch(NumberFormatException nfe) {
			esValido = false;
			statusMessages.addToControl("numEstrucDesde",Severity.ERROR, "#{messages['mantProdCompuesto.error.desde.numero']}");
		}
		
		return esValido;
		
	}
	
	public void asignarDesdeHastaFechaValor(){
		if(!GenericUtils.isNullOrBlank(mantProdCompuestoPantalla.getFechaValorDesde())){
			mantProdCompuestoPantalla.setFechaValorHasta(mantProdCompuestoPantalla.getFechaValorDesde());
		}
		validacionesDesdeHasta();
	}

	public void asignarDesdeHastaFechaVto(){
		if(!GenericUtils.isNullOrBlank(mantProdCompuestoPantalla.getFechaVtoDesde())){
			mantProdCompuestoPantalla.setFechaVtoHasta(mantProdCompuestoPantalla.getFechaVtoDesde());
		}
		validacionesDesdeHasta();
	}

	public void asignarDesdeHastaFechaContr(){
		if(!GenericUtils.isNullOrBlank(mantProdCompuestoPantalla.getfContratDesde())){
			mantProdCompuestoPantalla.setfContratHasta(mantProdCompuestoPantalla.getfContratDesde());
		}
		validacionesDesdeHasta();
	}
	
	public boolean validacionesDesdeHasta(){
		
		boolean esCorrecto = true;
		BigDecimal estructuDesde = null; 
		BigDecimal estructuHasta = null;
		
		try{
			if(!GenericUtils.isNullOrBlank(mantProdCompuestoPantalla.getNumEstructDesde())){
				estructuDesde = new BigDecimal(mantProdCompuestoPantalla.getNumEstructDesde());
			}
		}catch(NumberFormatException nfe) {
			statusMessages.addToControl("numEstrucDesde",Severity.ERROR, "#{messages['mantProdCompuesto.error.desde.numero']}");
			esCorrecto = false;
		}
		
		try{
			if(!GenericUtils.isNullOrBlank(mantProdCompuestoPantalla.getNumEstructHasta())){
				estructuHasta = new BigDecimal(mantProdCompuestoPantalla.getNumEstructHasta());
			}
		}catch(NumberFormatException nfe) {
			statusMessages.addToControl("numEstrucHasta",Severity.ERROR, "#{messages['mantProdCompuesto.error.hasta.numero']}");
			esCorrecto = false;
		}		
		
		if(!GenericUtils.isNullOrBlank(estructuDesde) && !GenericUtils.isNullOrBlank(estructuHasta)){
			if(estructuDesde.longValue() > estructuHasta.longValue()){
				statusMessages.add(Severity.ERROR, "#{messages['mantProdCompuesto.error.estructu.desdehasta']}");
				esCorrecto = false;
			}
		}
		
		if(!GenericUtils.isNullOrBlank(mantProdCompuestoPantalla.getFechaValorDesde()) 
				&& !GenericUtils.isNullOrBlank(mantProdCompuestoPantalla.getFechaValorHasta())){
			if(mantProdCompuestoPantalla.getFechaValorDesde().getTime() > mantProdCompuestoPantalla.getFechaValorHasta().getTime()){
				statusMessages.addToControl("fechaValorDesde", Severity.ERROR, "#{messages['mantProdCompuesto.error.fechaValor.desdehasta']}");
				esCorrecto = false;
			}
		}

		if(!GenericUtils.isNullOrBlank(mantProdCompuestoPantalla.getFechaVtoDesde()) 
				&& !GenericUtils.isNullOrBlank(mantProdCompuestoPantalla.getFechaVtoHasta())){
			if(mantProdCompuestoPantalla.getFechaVtoDesde().getTime() > mantProdCompuestoPantalla.getFechaVtoHasta().getTime()){
				statusMessages.addToControl("fechaVtoDesde", Severity.ERROR, "#{messages['mantProdCompuesto.error.fechaVto.desdehasta']}");
				esCorrecto = false;
			}
		}
		
		if(!GenericUtils.isNullOrBlank(mantProdCompuestoPantalla.getfContratDesde()) 
				&& !GenericUtils.isNullOrBlank(mantProdCompuestoPantalla.getfContratHasta())){
			if(mantProdCompuestoPantalla.getfContratDesde().getTime() > mantProdCompuestoPantalla.getfContratHasta().getTime()){
				statusMessages.addToControl("fechaContratDesde", Severity.ERROR, "#{messages['mantProdCompuesto.error.fContrat.desdehasta']}");
				esCorrecto = false;
			}
		}
		
		return esCorrecto;
	}
	
	public void rellenarListaAgenda(){
		setVieneAgenda(true);
		setExportExcel(false);
		mantProdCompuestoPantalla.setProdCompuestoResultados(
				mantProdCompuestoBo.buscarOperacionesCompuestasAgenda(parametrosOutAgenda.getFechatraIni(),
						parametrosOutAgenda.getEstadoEv(),
						parametrosOutAgenda.getCodevent(),
						this.paginationData));
	}
	
	public void rellenarListaAgendaExcel(){
		setExportExcel(true);
		mantProdCompuestoPantalla.setProdCompuestoResultados(
				mantProdCompuestoBo.buscarOperacionesCompuestasAgenda(parametrosOutAgenda.getFechatraIni(),
						parametrosOutAgenda.getEstadoEv(),
						parametrosOutAgenda.getCodevent(),
						this.paginationData.getPaginationDataForExcel()));
	}
	
	public Boolean getConsulta() {
		return consulta;
	}

	public void setConsulta(Boolean consulta) {
		this.consulta = consulta;
	}

	public boolean isVieneAgenda() {
		return vieneAgenda;
	}

	public void setVieneAgenda(boolean vieneAgenda) {
		this.vieneAgenda = vieneAgenda;
	}

	
	
	public void init(){
		
//		if (primerAcceso){
//			if (parametrosOutAgenda!=null){
//				setVieneAgenda(true);
//			}
//			if (isVieneAgenda()){
//				rellenarListaAgenda();
//			}else{
				refrescarLista();	
//			}
//		}
				
		if(messageBoxmantProdCompuestoAction==null){
			messageBoxmantProdCompuestoAction = new MessageBoxAction();
		}
	}
	
	public void voidFunction(){
		msgBoxAction.voidFunction();
	}
	
	public void onVerificarContrapartidaBloqueada() {
		String idContrapa = mantProdCompuestoPantalla.getContrapartida();
	    Contrapartida contrapObtenida2 = null;
		if (!GenericUtils.isNullOrBlank(idContrapa)){
			contrapObtenida2 = mantProdCompuestoBo.cargarContrapartida(idContrapa.toUpperCase());
			if (null!=contrapObtenida2 && !GenericUtils.isNullOrBlank(contrapObtenida2.getIndBloqueo()) && "S".equalsIgnoreCase(contrapObtenida2.getIndBloqueo())){
				messageBoxmantProdCompuestoAction.init("mantProdCompuesto.messages.contrapartida.bloqueada.texto", "mantProdCompuestoAction.voidFunction()", null,"messageBoxPanelContrapa");
			}
		}
	 }
	
	public String getRowClasses(){
		StringBuilder builder = new StringBuilder();
		int i=0;
		for (HistoricoProductoCompuesto histProCom : mantProdCompuestoPantalla.getProdCompuestoResultados()) {

			Contrapartida contrapartida = (Contrapartida) histProCom.getContrapartida();

			if(i>0){
				builder.append(",");
			}
			
			if(i%2==0){
				if(null!=contrapartida && !GenericUtils.isNullOrBlank(contrapartida.getIndBloqueo()) && "S".equalsIgnoreCase(contrapartida.getIndBloqueo())){
					builder.append("oddRowRed");
				}
				else{
					builder.append("oddRow");
				}
			}
			else{
				if(null!=contrapartida && !GenericUtils.isNullOrBlank(contrapartida.getIndBloqueo()) && "S".equalsIgnoreCase(contrapartida.getIndBloqueo())){
					builder.append("evenRowRed");
				}
				else{
					builder.append("evenRow");
				}
			}
			i++;
			contrapartida = null;
		}
		return builder.toString();
	}
	
}
