package com.atosorigin.deri.gestionoperaciones.productocompuesto.screen;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.jboss.seam.ScopeType;
import org.jboss.seam.annotations.Name;
import org.jboss.seam.annotations.Scope;
import org.jboss.seam.annotations.datamodel.DataModel;
import org.jboss.seam.annotations.datamodel.DataModelSelection;

import com.atosorigin.deri.model.catalogo.CatalogoProdCompuesto;
import com.atosorigin.deri.model.catalogo.HistoricoProductoCompuesto;
import com.atosorigin.deri.model.catalogo.HistoricoProductoCompuestoId;

@Name("mantProdCompuestoPantalla")
@Scope(ScopeType.CONVERSATION)


public class MantProdCompuestoPantalla {

	protected String procedencia;
	//protected String descProdCompuesto;	
	protected CatalogoProdCompuesto prodCompuesto;
	protected String contrapartida;
	protected String situacion;
	protected Date fechaValorDesde;
	protected Date fechaValorHasta;
	protected Date fechaVtoDesde;
	protected Date fechaVtoHasta;
	protected Date fContratDesde;
	protected Date fContratHasta;
	protected String numEstructDesde;
	protected String numEstructHasta;
	
	
	protected List<CatalogoProdCompuesto> prodCompuestoList;
	
	@DataModel(value="listaDtProdCompuestoResultados")
	protected List<HistoricoProductoCompuesto> prodCompuestoResultados;
	
	@DataModelSelection(value="listaDtProdCompuestoResultados")
	protected HistoricoProductoCompuesto productoCompuestoSelect;	
	
	
	
	/**
	 * Selección checkbox prod comp
	 */
	protected Map<HistoricoProductoCompuestoId, Boolean> selectedProdCompIds = new HashMap<HistoricoProductoCompuestoId, Boolean>();
	//Lista donde guardo los checks seleccionados
	protected List<HistoricoProductoCompuesto> selectedProdCompList = new ArrayList<HistoricoProductoCompuesto>();
	//protected boolean selecTodos;
	
	public String getProcedencia() {
		return procedencia;
	}
	public void setProcedencia(String procedencia) {
		this.procedencia = procedencia;
	}
	public String getContrapartida() {
		return contrapartida;
	}
	public void setContrapartida(String contrapartida) {
		this.contrapartida = contrapartida;
	}
	public String getSituacion() {
		return situacion;
	}
	public void setSituacion(String situacion) {
		this.situacion = situacion;
	}
	public Date getFechaValorDesde() {
		return fechaValorDesde;
	}
	public void setFechaValorDesde(Date fechaValorDesde) {
		this.fechaValorDesde = fechaValorDesde;
	}
	public Date getFechaValorHasta() {
		return fechaValorHasta;
	}
	public void setFechaValorHasta(Date fechaValorHasta) {
		this.fechaValorHasta = fechaValorHasta;
	}
	public Date getFechaVtoDesde() {
		return fechaVtoDesde;
	}
	public void setFechaVtoDesde(Date fechaVtoDesde) {
		this.fechaVtoDesde = fechaVtoDesde;
	}
	public Date getFechaVtoHasta() {
		return fechaVtoHasta;
	}
	public void setFechaVtoHasta(Date fechaVtoHasta) {
		this.fechaVtoHasta = fechaVtoHasta;
	}
	public Date getfContratDesde() {
		return fContratDesde;
	}
	public void setfContratDesde(Date fContratDesde) {
		this.fContratDesde = fContratDesde;
	}
	public Date getfContratHasta() {
		return fContratHasta;
	}
	public void setfContratHasta(Date fContratHasta) {
		this.fContratHasta = fContratHasta;
	}
	public String getNumEstructDesde() {
		return numEstructDesde;
	}
	public void setNumEstructDesde(String numEstructDesde) {
		this.numEstructDesde = numEstructDesde;
	}
	public String getNumEstructHasta() {
		return numEstructHasta;
	}
	public void setNumEstructHasta(String numEstructHasta) {
		this.numEstructHasta = numEstructHasta;
	}
	public List<CatalogoProdCompuesto> getProdCompuestoList() {
		return prodCompuestoList;
	}
	public void setProdCompuestoList(List<CatalogoProdCompuesto> prodCompuestoList) {
		this.prodCompuestoList = prodCompuestoList;
	}
	public CatalogoProdCompuesto getProdCompuesto() {
		return prodCompuesto;
	}
	public void setProdCompuesto(CatalogoProdCompuesto prodCompuesto) {
		this.prodCompuesto = prodCompuesto;
	}
	public void setProductoCompuestoSelect(HistoricoProductoCompuesto productoCompuestoSelect) {
		this.productoCompuestoSelect = productoCompuestoSelect;
	}
	public List<HistoricoProductoCompuesto> getProdCompuestoResultados() {
		return prodCompuestoResultados;
	}
	public void setProdCompuestoResultados(List<HistoricoProductoCompuesto> prodCompuestoResultados) {
		this.prodCompuestoResultados = prodCompuestoResultados;
	}
	public HistoricoProductoCompuesto getProductoCompuestoSelect() {
		return productoCompuestoSelect;
	}
	public Map<HistoricoProductoCompuestoId, Boolean> getSelectedProdCompIds() {
		return selectedProdCompIds;
	}
	public void setSelectedProdCompIds(Map<HistoricoProductoCompuestoId, Boolean> selectedProdCompIds) {
		this.selectedProdCompIds = selectedProdCompIds;
	}
	public List<HistoricoProductoCompuesto> getSelectedProdCompList() {
		return selectedProdCompList;
	}
	public void setSelectedProdCompList(List<HistoricoProductoCompuesto> selectedProdCompList) {
		this.selectedProdCompList = selectedProdCompList;
	}
//	public boolean isSelecTodos() {
//		return selecTodos;
//	}
//	public void setSelecTodos(boolean selecTodos) {
//		this.selecTodos = selecTodos;
//	}
	
	
}
