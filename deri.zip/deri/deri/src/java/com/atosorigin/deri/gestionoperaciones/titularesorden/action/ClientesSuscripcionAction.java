package com.atosorigin.deri.gestionoperaciones.titularesorden.action;

import java.util.ArrayList;
import java.util.List;

import org.jboss.seam.ScopeType;
import org.jboss.seam.annotations.In;
import org.jboss.seam.annotations.Name;
import org.jboss.seam.annotations.Scope;

import com.atosorigin.common.action.GenericAction;
import com.atosorigin.common.action.ModoPantalla;
import com.atosorigin.common.formvalidator.FormValidator;
import com.atosorigin.common.utils.GenericUtils;
import com.atosorigin.deri.contrapartida.buscadorContrapartida.screen.BuscadorContrapartidaPantalla;
import com.atosorigin.deri.gestionoperaciones.clientessuscripcion.business.ClientesSuscripcionBo;
import com.atosorigin.deri.gestionoperaciones.ordencontratacion.screen.OrdenContratacionPantalla;
import com.atosorigin.deri.gestionoperaciones.titularesorden.screen.ClientesSuscripcionPantalla;
import com.atosorigin.deri.model.gestionoperaciones.ClientesSuscripcion;
import com.atosorigin.deri.model.gestionoperaciones.ClientesSuscripcionId;

/**
 * Clase action listener para el caso de uso de titulares de la Orden
 */
@Name("clientesSuscripcionAction")
@Scope(ScopeType.CONVERSATION)
@FormValidator
public class ClientesSuscripcionAction extends GenericAction {

	@In(value = "ordenContratacionPantalla")
	protected OrdenContratacionPantalla ordenContratacionPantalla;

	@In(create = true)	
	protected ClientesSuscripcionPantalla clientesSuscripcionPantalla;

	@In(value = "#{clientesSuscripcionBo}")
	protected ClientesSuscripcionBo clientesSuscripcionBo;

	@In(create = true)
	protected BuscadorContrapartidaPantalla buscadorContrapartidaPantalla;

	@In(value="listaClienteSuscripcionOut", required=false)	
	protected List<ClientesSuscripcion> listaClienteSuscripcionOut;
	
	public void tratarContrapartida() {

		if (!contrapaRepetida(buscadorContrapartidaPantalla.getContrapartida().getId())) {
			ClientesSuscripcion clientesSuscripcion = new ClientesSuscripcion();
			ClientesSuscripcionId clientesSuscripcionId = new ClientesSuscripcionId();
			if (getModoPantalla().equals(ModoPantalla.CREACION)) {
				clientesSuscripcionId.setContrapartida(buscadorContrapartidaPantalla.getContrapartida().getId());
				clientesSuscripcionId.setCodigoCampanya(ordenContratacionPantalla.getCampanya().getId());
				clientesSuscripcionId.setNumeroOrden(ordenContratacionPantalla.getOrden().getId().getNumero());
				
				clientesSuscripcion.setId(clientesSuscripcionId);
				
				if (clientesSuscripcionPantalla.getListaClienteSuscripcion()!= null){
					clientesSuscripcionPantalla.getListaClienteSuscripcion().add(
							clientesSuscripcion);
				}else{
					clientesSuscripcionPantalla.setListaClienteSuscripcion(new ArrayList<ClientesSuscripcion>());
					clientesSuscripcionPantalla.getListaClienteSuscripcion().add(
							clientesSuscripcion);
				}
			}
			if (getModoPantalla().equals(ModoPantalla.EDICION)) {
				clientesSuscripcionPantalla.getClienteSuscripcionSeleccionado()
						.getId().setContrapartida(buscadorContrapartidaPantalla.getContrapartida().getId());
			}
			buscadorContrapartidaPantalla.setTipocliente(false);
		}
	}

	public boolean contrapaRepetida(String contrapa) {
		boolean retorno = false;
		List<ClientesSuscripcion> listaClientesSuscripcion = clientesSuscripcionPantalla
				.getListaClienteSuscripcion();
		if (listaClientesSuscripcion!=null){
			for (ClientesSuscripcion clientesSuscripcion : listaClientesSuscripcion) {
				if (clientesSuscripcion.getId().getContrapartida().equals(contrapa)) {
					retorno = true;
					break;
				}
			}
		}
		return retorno;
	}

	public void eliminar() {
		List<ClientesSuscripcion> listaClientesSuscripcion = clientesSuscripcionPantalla
				.getListaClienteSuscripcion();
		for (ClientesSuscripcion clientesSuscripcion : listaClientesSuscripcion) {
			if (clientesSuscripcion.getId().getContrapartida().equals(
					clientesSuscripcionPantalla
							.getClienteSuscripcionSeleccionado().getId()
							.getContrapartida())) {
				listaClientesSuscripcion.remove(clientesSuscripcion);
				break;
			}
		}
		clientesSuscripcionPantalla.getClienteSuscripcionSeleccionado();
	}

	public void aceptar() {
		buscadorContrapartidaPantalla.setTipocliente(false);
		crearListaClienteSuscripcion();
		listaClienteSuscripcionOut.clear();
		listaClienteSuscripcionOut.addAll(clientesSuscripcionPantalla.getListaClienteSuscripcion());
	}
	
	public void preCargar() {
		crearListaClienteSuscripcion();
		if (!GenericUtils.isNullOrBlank(clientesSuscripcionPantalla)
				&& !GenericUtils.isNullOrBlank(clientesSuscripcionPantalla
						.getListaClienteSuscripcion())
				&& (clientesSuscripcionPantalla.getListaClienteSuscripcion()
						.isEmpty() || clientesSuscripcionPantalla
						.getListaClienteSuscripcion() == null)
				|| (!GenericUtils.isNullOrBlank(clientesSuscripcionPantalla) && GenericUtils
						.isNullOrBlank(clientesSuscripcionPantalla
								.getListaClienteSuscripcion()))) {
			ClientesSuscripcionId clientesSuscripcionId = new ClientesSuscripcionId();
			this.clientesSuscripcionPantalla
					.setCodcampa(ordenContratacionPantalla.getCampanya()
							.getId());
			clientesSuscripcionId.setCodigoCampanya(ordenContratacionPantalla
					.getCampanya().getId());
			this.clientesSuscripcionPantalla.setNumorden(Long
					.toString(ordenContratacionPantalla.getOrden().getId()
							.getNumero()));
			clientesSuscripcionId.setNumeroOrden(ordenContratacionPantalla
					.getOrden().getId().getNumero());
			//Inc 321
			if (listaClienteSuscripcionOut!=null){
				this.clientesSuscripcionPantalla.setListaClienteSuscripcion( new ArrayList<ClientesSuscripcion>());
				this.clientesSuscripcionPantalla.getListaClienteSuscripcion().addAll(listaClienteSuscripcionOut);
			}
			
		}
	}

	public void crearListaClienteSuscripcion() {
		if (listaClienteSuscripcionOut==null){
			listaClienteSuscripcionOut = new ArrayList<ClientesSuscripcion>();
		}
	}
	public void abrirPopUp(String contrapa) {

		clientesSuscripcionPantalla.setContrapaSeleccionada(contrapa);
		setModoPantalla(ModoPantalla.EDICION);
		buscadorContrapartidaPantalla.setTipocliente(true);
	}

	public void nuevo() {
		setModoPantalla(ModoPantalla.CREACION);
		buscadorContrapartidaPantalla.setTipocliente(true);
	}

	public String obtenerDescripcionCampanya(String idCampanya) {
		if (!GenericUtils.isNullOrBlank(idCampanya)) {
			return clientesSuscripcionBo.getDescripcionCampanya(idCampanya);
		} else {
			return "";
		}
	}

	public String obtenerDescripcionContrapa(String idContrapartida) {
		if (!GenericUtils.isNullOrBlank(idContrapartida)) {
			return clientesSuscripcionBo
					.getDescripcionContrapa(idContrapartida);
		} else {
			return "";
		}
	}

	public void setOrdenContratacionPantalla(
			OrdenContratacionPantalla ordenContratacionPantalla) {
		this.ordenContratacionPantalla = ordenContratacionPantalla;
	}

	public OrdenContratacionPantalla getOrdenContratacionPantalla() {
		return ordenContratacionPantalla;
	}

	public ClientesSuscripcionPantalla getClientesSuscripcionPantalla() {
		return clientesSuscripcionPantalla;
	}

	public void setClientesSuscripcionPantalla(
			ClientesSuscripcionPantalla clientesSuscripcionPantalla) {
		this.clientesSuscripcionPantalla = clientesSuscripcionPantalla;
	}

	public ClientesSuscripcionBo getClientesSuscripcionBo() {
		return clientesSuscripcionBo;
	}

	public void setClientesSuscripcionBo(
			ClientesSuscripcionBo clientesSuscripcionBo) {
		this.clientesSuscripcionBo = clientesSuscripcionBo;
	}

	public BuscadorContrapartidaPantalla getBuscadorContrapartidaPantalla() {
		return buscadorContrapartidaPantalla;
	}

	public void setBuscadorContrapartidaPantalla(
			BuscadorContrapartidaPantalla buscadorContrapartidaPantalla) {
		this.buscadorContrapartidaPantalla = buscadorContrapartidaPantalla;
	}

	public List<ClientesSuscripcion> getListaClienteSuscripcionOut() {
		return listaClienteSuscripcionOut;
	}

	public void setListaClienteSuscripcionOut(
			List<ClientesSuscripcion> listaClienteSuscripcionOut) {
		this.listaClienteSuscripcionOut = listaClienteSuscripcionOut;
	}

}
