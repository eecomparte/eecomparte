package com.atosorigin.deri.gestionoperaciones.titularesorden.screen;

import java.util.List;

import org.jboss.seam.ScopeType;
import org.jboss.seam.annotations.Name;
import org.jboss.seam.annotations.Scope;
import org.jboss.seam.annotations.datamodel.DataModel;
import org.jboss.seam.annotations.datamodel.DataModelSelection;

import com.atosorigin.deri.model.gestionoperaciones.ClientesSuscripcion;

/**
 *  Contiene los datos de pantalla necesarios para el caso de uso de titulares de la ordén.
 */

@Name("clientesSuscripcionPantalla")
@Scope(ScopeType.CONVERSATION)
public class ClientesSuscripcionPantalla {

	protected  String codcampa;
	protected  String descampa ;
	protected  String numorden;
	protected  String contrapaSeleccionada; 

	@DataModel(value="listaDtClienteSuscripcion")
	protected List<ClientesSuscripcion> listaClienteSuscripcion;
	
	@DataModelSelection(value="listaDtClienteSuscripcion")
	ClientesSuscripcion clienteSuscripcionSeleccionado;

	public String getCodcampa() {
		return codcampa;
	}

	public void setCodcampa(String codcampa) {
		this.codcampa = codcampa;
	}

	public String getDescampa() {
		return descampa;
	}

	public void setDescampa(String descampa) {
		this.descampa = descampa;
	}

	public String getNumorden() {
		return numorden;
	}

	public void setNumorden(String numorden) {
		this.numorden = numorden;
	}

	public List<ClientesSuscripcion> getListaClienteSuscripcion() {
		return listaClienteSuscripcion;
	}

	public void setListaClienteSuscripcion(
			List<ClientesSuscripcion> listaClienteSuscripcion) {
		this.listaClienteSuscripcion = listaClienteSuscripcion;
	}

	public String getContrapaSeleccionada() {
		return contrapaSeleccionada;
	}

	public void setContrapaSeleccionada(String contrapaSeleccionada) {
		this.contrapaSeleccionada = contrapaSeleccionada;
	}

	public ClientesSuscripcion getClienteSuscripcionSeleccionado() {
		return clienteSuscripcionSeleccionado;
	}

	public void setClienteSuscripcionSeleccionado(
			ClientesSuscripcion clienteSuscripcionSeleccionado) {
		this.clienteSuscripcionSeleccionado = clienteSuscripcionSeleccionado;
	}
	
	
}
