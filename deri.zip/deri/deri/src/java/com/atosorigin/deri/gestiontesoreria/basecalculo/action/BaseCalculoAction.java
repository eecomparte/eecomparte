package com.atosorigin.deri.gestiontesoreria.basecalculo.action;

import java.util.List;

import org.jboss.seam.ScopeType;
import org.jboss.seam.annotations.In;
import org.jboss.seam.annotations.Name;
import org.jboss.seam.annotations.Scope;

import com.atosorigin.common.action.PaginatedListAction;
import com.atosorigin.common.formvalidator.FormValidator;
import com.atosorigin.deri.gestiontesoreria.basecalculo.business.BaseCalculoBo;
import com.atosorigin.deri.gestiontesoreria.basecalculo.screen.BaseCalculoPantalla;


/**
 * Clase que actúa de action listener para el caso de uso de base de calculo.
 */
@Name("baseCalculoAction")
@Scope(ScopeType.CONVERSATION)
@FormValidator
public class BaseCalculoAction extends PaginatedListAction {
	
	
	
	/**
	 * Inyección del bean de Spring "baseCalculoBo" que contiene los métodos de negocio
	 * para el caso de uso base calculo.
	 */
	@In("#{baseCalculoBo}")
	protected BaseCalculoBo baseCalculoBo;

	@In(create=true)
	protected BaseCalculoPantalla baseCalculoPantalla;
	
	
	
	//Metodos necesarios para pantallas con grids.
	//Es necesario implementar estos metodos abstractos de PaginatedListAction
	
	/**@Override
	public List<BaseCalculo> getDataTableList() {
		// dudaaaaaaaaaaaaaaaa
		//return baseCalculoPantalla.getUsuarioList();
	}**/

	@Override
	protected void refreshListInternal() {		
		List ql = (List)baseCalculoBo.busqueda(baseCalculoPantalla.getCodigo(), baseCalculoPantalla.getDescripcion(), paginationData);
		baseCalculoPantalla.setBaseCalculoList(ql);
		
	}

	@Override
	public void refrescarListaExcel() {		
		List ql = (List)baseCalculoBo.busqueda(baseCalculoPantalla.getCodigo(), baseCalculoPantalla.getDescripcion(), paginationData.getPaginationDataForExcel());
		baseCalculoPantalla.setBaseCalculoList(ql);
	}

	@Override
	public void setDataTableList(List<?> dataTableList) {
		// duda
		//usuarioPantalla.setUsuarioList((List<TbUsuario>)dataTableList);
		
	}

	@Override
	public List<?> getDataTableList() {
		// TODO Auto-generated method stub
		return baseCalculoPantalla.getBaseCalculoList();
	}

	
	/**
	 * Actualiza la lista del grid de base de calculo
	 * 
	 */
	public void buscar() {
		//SMM HPQC BUG ID=11
		paginationData.reset();
		//SMM HPQC BUG ID=6
		setPrimerAcceso(false);
		refrescarLista();
	}
	
	
	
	
}
