package com.atosorigin.deri.gestiontesoreria.basecalculo.screen;

import java.util.List;

import org.jboss.seam.ScopeType;
import org.jboss.seam.annotations.Name;
import org.jboss.seam.annotations.Scope;
import org.jboss.seam.annotations.datamodel.DataModel;

import com.atosorigin.deri.model.gestiontesoreria.BaseCalculo;

/**
 *  Contiene los datos de pantalla necesarios para el caso de uso base calculo.
 */

@Name("baseCalculoPantalla")
@Scope(ScopeType.CONVERSATION)
public class BaseCalculoPantalla {

	/** codigo. Criterio de búsqueda de basecalculo.  */
	protected String codigo;
	
	public String getCodigo() {
		return codigo;
	}

	public void setCodigo(String codigo) {
		this.codigo = codigo;
	}

	public String getDescripcion() {
		return descripcion;
	}

	public void setDescripcion(String descripcion) {
		this.descripcion = descripcion;
	}

	public BaseCalculo getBaseCalculoSelect() {
		return baseCalculoSelect;
	}

	public void setBaseCalculoSelect(BaseCalculo baseCalculoSelect) {
		this.baseCalculoSelect = baseCalculoSelect;
	}

	/** Descripcion. Criterio de búsqueda de basecalculo.  */
	protected String descripcion;
	
	/** basecalculo. Criterio de búsqueda de usuarios.  */
	protected BaseCalculo baseCalculoSelect;
	
	
	
	/** Lista de datos para el grid. */
	@DataModel(value ="listaDtbaseCalculo")
	protected List<BaseCalculo> baseCalculoList;
	

	/**
	 * Obtiene la Lista de datos para el grid.
	 * 
	 * @return la lista de basecalculo que mostrará el grid de resultados de la busqueda.
	 */
	
	public void setBaseCalculoList(List<BaseCalculo> baseCalculoList) {
		this.baseCalculoList = baseCalculoList;
	}

	/**
	 * Obtiene la Lista de datos para el grid.
	 * 
	 * @return la lista de basecalculo que mostrará el grid de resultados de la búsqueda.
	 */
	public List<BaseCalculo> getBaseCalculoList() {
		return baseCalculoList;
	}
	
	
}
