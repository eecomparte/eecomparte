package com.atosorigin.deri.kondor.avisocaptura.action;


import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import org.jboss.seam.ScopeType;
import org.jboss.seam.annotations.In;
import org.jboss.seam.annotations.Name;
import org.jboss.seam.annotations.Scope;
import org.jboss.seam.annotations.datamodel.DataModel;
import org.jboss.seam.annotations.datamodel.DataModelSelection;
import org.jboss.seam.core.Conversation;
import org.jboss.seam.international.StatusMessage.Severity;
import org.jboss.seam.security.Identity;

import com.atosorigin.common.action.PaginatedListAction;
import com.atosorigin.common.action.PaginationData;
import com.atosorigin.common.auditdata.AuditData;
import com.atosorigin.common.constantes.Constantes;
import com.atosorigin.common.formvalidator.FormValidator;
import com.atosorigin.common.utils.GenericUtils;
import com.atosorigin.deri.kondor.avisocaptura.screen.AvisoCapturaPantalla;
import com.atosorigin.deri.kondor.avisoscaptura.business.AvisosCapturaBo;
import com.atosorigin.deri.model.kondor.BuzonError;


@Name("avisoCapturaAction")
@Scope(ScopeType.CONVERSATION)
@FormValidator
public class AvisoCapturaAction extends PaginatedListAction{
	
	@In(value="#{avisosCapturaBo}")
	AvisosCapturaBo avisosCapturaBo;
	
	@In(create=true)
	AvisoCapturaPantalla avisoCapturaPantalla;
	
	@DataModel(value="listaDtBuzonError")
	protected List<BuzonError> buzonErrorList;
	
	@DataModelSelection(value="listaDtBuzonError")
	protected BuzonError buzonErrorSelec;

	/** Los datos de paginación del 2º grid (erorres detalle) */
	public PaginationData paginationDataDelegate = new PaginationData();
	
	@In(required=false)
	private String modo; 
	@In(required=false)
	private String fecInsfo;
	
	public void buscar(){

		paginationData.reset();
		refrescarLista();
		if(buzonErrorList.size() == 0){
			statusMessages.add(Severity.INFO, "#{messages['contrapartida.lista.vacia']}");
		}
		setPrimerAcceso(false);
		
	}
	
	public boolean buscarValidator(){
		if(!GenericUtils.isNullOrBlank(avisoCapturaPantalla.getFechaDesde()) && !GenericUtils.isNullOrBlank(avisoCapturaPantalla.getFechaHasta())){
			if(avisoCapturaPantalla.getFechaDesde().getTime() > avisoCapturaPantalla.getFechaHasta().getTime()){
				statusMessages.add(Severity.ERROR, "#{messages['avisocaptura.error.fecha']}");
				return false;
			}
		}

		if(!GenericUtils.isNullOrBlank(avisoCapturaPantalla.getDealNumberDesde()) && !GenericUtils.isNullOrBlank(avisoCapturaPantalla.getDealNumberHasta())){
			if(avisoCapturaPantalla.getDealNumberDesde() > avisoCapturaPantalla.getDealNumberHasta()){
				statusMessages.add(Severity.ERROR, "#{messages['avisocaptura.errorDealNum']}");
				return false;
			}
		}
		
		
		return true;
	}
	
	public void init(){
		if(primerAcceso){
			if(Constantes.MODO_AGE.equals(modo) && fecInsfo != null){
				DateFormat df = new SimpleDateFormat("dd/MM/yyyy");
				Date fPro = null;
				try {
					fPro = df.parse(fecInsfo);
				} catch (ParseException e) {;}
				avisoCapturaPantalla.setFechaDesde(fPro);
				avisoCapturaPantalla.setFechaHasta(fPro);
				refrescarLista();
			}
			primerAcceso = false;
		}
	}
	
	public void trataSeleccionado(){
		paginationDataDelegate.reset();
		avisoCapturaPantalla.setBuzonErrorSeleccionado(this.getBuzonErrorSelec());
		refrescarSeleccionado();
	}
	
	public void refrescarSeleccionado(){
		List<BuzonError> qb = avisosCapturaBo.obtenerDetalleBuzonErrSel(
				avisoCapturaPantalla.getBuzonErrorSeleccionado().getId().getDealType(), 
				avisoCapturaPantalla.getBuzonErrorSeleccionado().getId().getDealNumber(),
				avisoCapturaPantalla.getBuzonErrorSeleccionado().getId().getfInsercion(), 
				paginationDataDelegate);
		
		avisoCapturaPantalla.setBuzonErrorDetalleList(qb);
	}
	
	public String getAvisoError(String codigo){
		return avisosCapturaBo.getDescripcionAvisoError(codigo);
	}
	public String getTipoOperacion(String codigo){
		return avisosCapturaBo.getDescripcionTipoOperacion(codigo);
	}
	
	public void marcaVisto(){
		if(GenericUtils.isNullOrBlank(avisoCapturaPantalla.getBuzonErrorSeleccionado().getAuditData())){
			avisoCapturaPantalla.getBuzonErrorSeleccionado().setAuditData(new AuditData());
		}
		avisoCapturaPantalla.getBuzonErrorSeleccionado().getAuditData().setUsuarioUltimaModi(Identity.instance().getCredentials().getUsername());
		avisosCapturaBo.darVistoBueno(avisoCapturaPantalla.getBuzonErrorSeleccionado());
		avisoCapturaPantalla.getBuzonErrorSeleccionado().setRevisado("S");
	}
	
	public void relanzar(){
		if(GenericUtils.isNullOrBlank(avisoCapturaPantalla.getBuzonErrorSeleccionado().getAuditData())){
			avisoCapturaPantalla.getBuzonErrorSeleccionado().setAuditData(new AuditData());
		}
		avisoCapturaPantalla.getBuzonErrorSeleccionado().getAuditData().setUsuarioUltimaModi(Identity.instance().getCredentials().getUsername());
		avisosCapturaBo.relanzar(avisoCapturaPantalla.getBuzonErrorSeleccionado());
		refrescarLista();
	}
	
	@Override
	public List<?> getDataTableList() {
		return buzonErrorList;
	}

	@Override
	protected void refreshListInternal() {
		setExportExcel(false);
		String dealTypeString = null;
		if(!GenericUtils.isNullOrBlank(avisoCapturaPantalla.getDealTypeSel())){
			dealTypeString =avisoCapturaPantalla.getDealTypeSel().getDescripcion(); 
		}
		List<BuzonError>  ql = (List<BuzonError>)avisosCapturaBo.buscarAvisosCapturaK(
				dealTypeString, 
				avisoCapturaPantalla.getAviserro(), 
				avisoCapturaPantalla.getVisto(), 
				avisoCapturaPantalla.getFechaDesde(), 
				avisoCapturaPantalla.getFechaHasta(), 
				avisoCapturaPantalla.getDealNumberDesde(), 
				avisoCapturaPantalla.getDealNumberHasta(), 
				paginationData);
		this.setDataTableList(ql);
		
	}

	@Override
	public void refrescarListaExcel() {
		setExportExcel(true);
		String dealTypeString = null;
		if(!GenericUtils.isNullOrBlank(avisoCapturaPantalla.getDealTypeSel())){
			dealTypeString =avisoCapturaPantalla.getDealTypeSel().getDescripcion(); 
		}
		List<BuzonError>  ql = (List<BuzonError> )avisosCapturaBo.buscarAvisosCapturaK(
				dealTypeString, 
				avisoCapturaPantalla.getAviserro(), 
				avisoCapturaPantalla.getVisto(), 
				avisoCapturaPantalla.getFechaDesde(), 
				avisoCapturaPantalla.getFechaHasta(), 
				avisoCapturaPantalla.getDealNumberDesde(), 
				avisoCapturaPantalla.getDealNumberHasta(), 
				paginationData.getPaginationDataForExcel());
		this.setDataTableList(ql);
	}

	/**
	 * Autorrellena fecha hasta con el valor introducido en fecha desde
	 */
	public void rellenarFechaHasta(){
		
		if(!GenericUtils.isNullOrBlank(avisoCapturaPantalla.getFechaDesde())){
			avisoCapturaPantalla.setFechaHasta(avisoCapturaPantalla.getFechaDesde());
		}
	}

	/**
	 * Autorrellena deal number hasta con el valor introducido en deal number desde
	 */
	public void rellenarDealNumberHasta(){
		
		if(!GenericUtils.isNullOrBlank(avisoCapturaPantalla.getDealNumberDesde())){
			avisoCapturaPantalla.setDealNumberHasta(avisoCapturaPantalla.getDealNumberDesde());
		}
	}
	
	public void firstDelegate() {
		paginationDataDelegate.setFirstResult(0);
		this.refrescarSeleccionado();
	}

	public boolean isPreviousExistsDelegate() {
		return paginationDataDelegate.getFirstResult() > 1;
	}
	
	public void previousDelegate() {
		paginationDataDelegate.setFirstResult(paginationDataDelegate.getFirstResult() - paginationDataDelegate.getMaxResults());
		this.refrescarSeleccionado();
	}
	
	public boolean isNextExistsDelegate() {
		return avisoCapturaPantalla.getBuzonErrorDetalleList() != null && paginationDataDelegate.getMaxResults() != null
				&& avisoCapturaPantalla.getBuzonErrorDetalleList().size() > paginationDataDelegate.getMaxResults();
	}	
	
	public void nextDelegate() {
		paginationDataDelegate.setFirstResult(paginationDataDelegate.getFirstResult() + paginationDataDelegate.getMaxResults());
		this.refrescarSeleccionado();
	}
	
	public void salir(){
		Conversation conversacion = Conversation.instance();
		//Volvemos a la anterior conversación
		if(conversacion.isNested()){
			conversacion.redirectToParent();
		} else {
			redirectToURL("/home.seam");
			conversacion.endAndRedirect();
		}
	}	
	
	@SuppressWarnings("unchecked")
	public void setDataTableList(List<?> dataTableList) {
		this.buzonErrorList = (List<BuzonError>) dataTableList;
	}

	public PaginationData getPaginationDataDelegate() {
		return paginationDataDelegate;
	}

	public void setPaginationDataDelegate(PaginationData paginationDataDelegate) {
		this.paginationDataDelegate = paginationDataDelegate;
	}

	public List<BuzonError> getBuzonErrorList() {
		return buzonErrorList;
	}

	public void setBuzonErrorList(List<BuzonError> buzonErrorList) {
		this.buzonErrorList = buzonErrorList;
	}

	public BuzonError getBuzonErrorSelec() {
		return buzonErrorSelec;
	}

	public void setBuzonErrorSelec(BuzonError buzonErrorSelec) {
		this.buzonErrorSelec = buzonErrorSelec;
	}

}
