package com.atosorigin.deri.kondor.avisocaptura.screen;

import java.util.Date;
import java.util.List;

import org.jboss.seam.ScopeType;
import org.jboss.seam.annotations.Name;
import org.jboss.seam.annotations.Out;
import org.jboss.seam.annotations.Scope;
import org.jboss.seam.annotations.datamodel.DataModel;
import org.jboss.seam.annotations.datamodel.DataModelSelection;

import com.atosorigin.deri.model.kondor.BuzonError;
import com.atosorigin.deri.model.kondor.DescripcionDealtype;


/**
 * Contiene los datos de pantalla necesarios para el caso de uso lanzamiento de integración.
 */
@Name("avisoCapturaPantalla")
@Scope(ScopeType.CONVERSATION)
public class AvisoCapturaPantalla {
	
	protected DescripcionDealtype dealTypeSel;
	protected Long dealNumberDesde;
	protected Long dealNumberHasta;
	protected Date fechaDesde;
	protected Date fechaHasta;
	protected String aviserro = "M";
	protected String visto ="M";
	protected Boolean marcado = true;
		
	@Out(value = "buzonErrorSeleccionado", required = false)
	protected BuzonError buzonErrorSeleccionado;
	
	@DataModel(value="listaDtBuzonErrorDetalle")
	protected List<BuzonError> buzonErrorDetalleList;

	@DataModelSelection(value="listaDtBuzonErrorDetalle")
	@Out(required=false)
	protected BuzonError buzonErrorDetalleSelec;

	public DescripcionDealtype getDealTypeSel() {
		return dealTypeSel;
	}

	public void setDealTypeSel(DescripcionDealtype dealTypeSel) {
		this.dealTypeSel = dealTypeSel;
	}

	public Long getDealNumberDesde() {
		return dealNumberDesde;
	}

	public void setDealNumberDesde(Long dealNumberDesde) {
		this.dealNumberDesde = dealNumberDesde;
	}

	public Long getDealNumberHasta() {
		return dealNumberHasta;
	}

	public void setDealNumberHasta(Long dealNumberHasta) {
		this.dealNumberHasta = dealNumberHasta;
	}

	public Date getFechaDesde() {
		return fechaDesde;
	}

	public void setFechaDesde(Date fechaDesde) {
		this.fechaDesde = fechaDesde;
	}

	public Date getFechaHasta() {
		return fechaHasta;
	}

	public void setFechaHasta(Date fechaHasta) {
		this.fechaHasta = fechaHasta;
	}

	public String getAviserro() {
		return aviserro;
	}

	public void setAviserro(String aviserro) {
		this.aviserro = aviserro;
	}

	public String getVisto() {
		return visto;
	}

	public void setVisto(String visto) {
		this.visto = visto;
	}

	public Boolean getMarcado() {
		return marcado;
	}

	public void setMarcado(Boolean marcado) {
		this.marcado = marcado;
	}

	public BuzonError getBuzonErrorSeleccionado() {
		return buzonErrorSeleccionado;
	}

	public void setBuzonErrorSeleccionado(BuzonError buzonErrorSeleccionado) {
		this.buzonErrorSeleccionado = buzonErrorSeleccionado;
	}

	public List<BuzonError> getBuzonErrorDetalleList() {
		return buzonErrorDetalleList;
	}

	public void setBuzonErrorDetalleList(List<BuzonError> buzonErrorDetalleList) {
		this.buzonErrorDetalleList = buzonErrorDetalleList;
	}

	public BuzonError getBuzonErrorDetalleSelec() {
		return buzonErrorDetalleSelec;
	}

	public void setBuzonErrorDetalleSelec(BuzonError buzonErrorDetalleSelec) {
		this.buzonErrorDetalleSelec = buzonErrorDetalleSelec;
	}
	
	

}
