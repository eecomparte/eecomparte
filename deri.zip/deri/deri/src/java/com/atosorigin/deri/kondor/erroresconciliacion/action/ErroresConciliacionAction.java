package com.atosorigin.deri.kondor.erroresconciliacion.action;

import java.util.ArrayList;
import java.util.List;

import org.jboss.seam.ScopeType;
import org.jboss.seam.annotations.Factory;
import org.jboss.seam.annotations.In;
import org.jboss.seam.annotations.Name;
import org.jboss.seam.annotations.Out;
import org.jboss.seam.annotations.Scope;
import org.jboss.seam.annotations.datamodel.DataModel;
import org.jboss.seam.annotations.datamodel.DataModelSelection;

import com.atosorigin.common.action.ModoPantalla;
import com.atosorigin.common.action.PaginatedListAction;
import com.atosorigin.common.utils.GenericUtils;
import com.atosorigin.deri.kondor.erroresconciliacion.business.ErroresConciliacionBo;
import com.atosorigin.deri.kondor.erroresconciliacion.screen.ErroresConciliacionPantalla;
import com.atosorigin.deri.model.kondor.ErroresConciliacion;
import com.atosorigin.deri.model.kondor.ErroresConciliacionAgrupados;
import com.atosorigin.deri.model.kondor.TipoErroresConciliacion;



/**
 * Clase action listener para el caso de uso de Errores de Conciliacion.
 */
@Name("erroresConciliacionAction")
@Scope(ScopeType.CONVERSATION)
public class ErroresConciliacionAction extends PaginatedListAction {

	/**
	 * Inyección del bean de Spring "erroresConciliacionBo" que contiene los tipos de error
	 * para el caso de uso Errores de Conciliación.
	 */
	@In("#{erroresConciliacionBo}")
	protected ErroresConciliacionBo erroresConciliacionBo;

	/**
	 * Inyección del screen bean que contiene los datos de pantalla del caso de uso
	 * Errores de Conciliación..
	 */
	@In(create=true)
	protected ErroresConciliacionPantalla erroresConciliacionPantalla;
	
	
    @Out(required=false)
    protected ErroresConciliacionAgrupados errorSeleccionado;	
    
    @Out(required = false, value = "mantOperaciones.tipoErroresConciliacion")
	List<TipoErroresConciliacion> tipoErroresConciliacionList = null;
    
    /** Lista de datos para el grid. */
	@DataModel(value ="listaDtConcierrExcel")
	protected List<ErroresConciliacion> listaConcierrExcel;
	
	@DataModelSelection(value="listaDtConcierrExcel")
	protected ErroresConciliacion datmo;

	/**
	 * Actualiza la lista del grid de Errores de Conciliación.
	 */
	public void buscar() {
		paginationData.reset();
		refrescarLista();	
		setPrimerAcceso(false);
	}

	@Override
	public List<ErroresConciliacionAgrupados> getDataTableList() {
		return erroresConciliacionPantalla.getErroresConciliacionAgrupList();
	}

	@Override
	protected void refreshListInternal() {
		setExportExcel(false);
		 List<ErroresConciliacionAgrupados> list = erroresConciliacionPantalla.getErroresConciliacionAgrupList();
		if(list==null){
			list = new ArrayList<ErroresConciliacionAgrupados>();
			erroresConciliacionPantalla.setErroresConciliacionAgrupList(list);
		}
		list.clear();
		list.addAll((List<ErroresConciliacionAgrupados>)erroresConciliacionBo.buscarErroresConciliacionAgrupados(erroresConciliacionPantalla.getFechaProceso(), erroresConciliacionPantalla.getTipoConciliacion(), erroresConciliacionPantalla.getIndicActividad(), erroresConciliacionPantalla.getnumOperacionDesde(), erroresConciliacionPantalla.getnumOperacionHasta(), erroresConciliacionPantalla.getCodigoError(), erroresConciliacionPantalla.getDealNumDesde(), erroresConciliacionPantalla.getDealNumHasta(), erroresConciliacionPantalla.getDealType(), paginationData));

	}

	@Override
	public void refrescarListaExcel() {
//		setExportExcel(true);
//		 List<ErroresConciliacionAgrupados> list = erroresConciliacionPantalla.getErroresConciliacionAgrupList();
//			if(list==null){
//				list = new ArrayList<ErroresConciliacionAgrupados>();
//				erroresConciliacionPantalla.setErroresConciliacionAgrupList(list);
//			}
//			list.clear();
//		
//			list.addAll((List<ErroresConciliacionAgrupados>)erroresConciliacionBo.buscarErroresConciliacionAgrupados(erroresConciliacionPantalla.getFechaProceso(),
//				  erroresConciliacionPantalla.getTipoConciliacion(), erroresConciliacionPantalla.getIndicActividad(), 
//				  erroresConciliacionPantalla.getnumOperacionDesde(), erroresConciliacionPantalla.getnumOperacionHasta(),
//				  erroresConciliacionPantalla.getCodigoError(), 
//				  erroresConciliacionPantalla.getDealNumDesde(), erroresConciliacionPantalla.getDealNumHasta(),
//				  erroresConciliacionPantalla.getDealType(), paginationData.getPaginationDataForExcel()));
////		erroresConciliacionPantalla.setErroresConciliacionAgrupList(erroresConciliacionAgrupList);

		setExportExcel(true);
		if(listaConcierrExcel == null){
			listaConcierrExcel = new ArrayList<ErroresConciliacion>();
		}
		List<ErroresConciliacionAgrupados> listaAux = new ArrayList<ErroresConciliacionAgrupados>();
		listaAux= erroresConciliacionBo.buscarErroresConciliacionAgrupados(erroresConciliacionPantalla.getFechaProceso(), erroresConciliacionPantalla.getTipoConciliacion(), erroresConciliacionPantalla.getIndicActividad(), erroresConciliacionPantalla.getnumOperacionDesde(), erroresConciliacionPantalla.getnumOperacionHasta(), erroresConciliacionPantalla.getCodigoError(), erroresConciliacionPantalla.getDealNumDesde(), erroresConciliacionPantalla.getDealNumHasta(), erroresConciliacionPantalla.getDealType(), paginationData.getPaginationDataForExcel());

		
		listaConcierrExcel.clear();
		listaConcierrExcel.addAll(erroresConciliacionBo.recuperarErroresConciliacionDesdePantalla(erroresConciliacionPantalla.getFechaProceso(), erroresConciliacionPantalla.getTipoConciliacion(), erroresConciliacionPantalla.getIndicActividad(), erroresConciliacionPantalla.getnumOperacionDesde(), erroresConciliacionPantalla.getnumOperacionHasta(), erroresConciliacionPantalla.getCodigoError(), erroresConciliacionPantalla.getDealNumDesde(), erroresConciliacionPantalla.getDealNumHasta(), erroresConciliacionPantalla.getDealType(), paginationData.getPaginationDataForExcel()));
		
////FORMA ORIGINAL		
//		List<ErroresConciliacionAgrupados> listaAux = new ArrayList<ErroresConciliacionAgrupados>();
//		listaAux= erroresConciliacionBo.buscarErroresConciliacionAgrupados(erroresConciliacionPantalla.getFechaProceso(), erroresConciliacionPantalla.getTipoConciliacion(), erroresConciliacionPantalla.getIndicActividad(), erroresConciliacionPantalla.getnumOperacionDesde(), erroresConciliacionPantalla.getnumOperacionHasta(), erroresConciliacionPantalla.getCodigoError(), erroresConciliacionPantalla.getDealNumDesde(), erroresConciliacionPantalla.getDealNumHasta(), erroresConciliacionPantalla.getDealType(), paginationData.getPaginationDataForExcel());
//
//		listaConcierrExcel.clear();
//		for (ErroresConciliacionAgrupados error :listaAux){
//		
//			//SMM Incidencia Indicador de Actividad, en fichero Excel muestra todos los registros
//			if (!GenericUtils.isNullOrBlank(erroresConciliacionPantalla.getIndicActividad())){
//				error.setIndicActividad(erroresConciliacionPantalla.getIndicActividad());
//			}
//
//			listaConcierrExcel.addAll( 
//				erroresConciliacionBo.recuperarErroresConciliacionDesdeAgrupado(error, 
//						paginationData.getPaginationDataForExcel()));
//			}
	
//		}

/*
//  Nova Forma EN DOS PASOS

List<ErroresConciliacionAgrupados> listaAux = new ArrayList<ErroresConciliacionAgrupados>();
		listaAux= erroresConciliacionBo.buscarErroresConciliacionAgrupados(erroresConciliacionPantalla.getFechaProceso(), erroresConciliacionPantalla.getTipoConciliacion(), erroresConciliacionPantalla.getIndicActividad(), erroresConciliacionPantalla.getnumOperacionDesde(), erroresConciliacionPantalla.getnumOperacionHasta(), erroresConciliacionPantalla.getCodigoError(), erroresConciliacionPantalla.getDealNumDesde(), erroresConciliacionPantalla.getDealNumHasta(), erroresConciliacionPantalla.getDealType(), paginationData.getPaginationDataForExcel());

		listaConcierrExcel.clear();
		for (ErroresConciliacionAgrupados error :listaAux){
		
			listaConcierrExcel.addAll( 
				erroresConciliacionBo.recuperarErroresConciliacionDesdeAgrupadoV2(error, 
						paginationData.getPaginationDataForExcel()));
			}



 */
		
/*		

//NOVA FORMA AMB UN SOL SELECT		
		
		listaConcierrExcel.clear();

		
			listaConcierrExcel.addAll( 
				erroresConciliacionBo.recuperarErroresConciliacionDesdeAgrupadoV4(erroresConciliacionPantalla.getFechaProceso(), 
						erroresConciliacionPantalla.getTipoConciliacion(), erroresConciliacionPantalla.getIndicActividad(), 
						erroresConciliacionPantalla.getnumOperacionDesde(), erroresConciliacionPantalla.getnumOperacionHasta(), 
						erroresConciliacionPantalla.getCodigoError(), erroresConciliacionPantalla.getDealNumDesde(), 
						erroresConciliacionPantalla.getDealNumHasta(), erroresConciliacionPantalla.getDealType(), 
						paginationData.getPaginationDataForExcel()));

*/

	}



	@Override
	public void setDataTableList(List<?> dataTableList) {
		erroresConciliacionPantalla.setErroresConciliacionAgrupList((List<ErroresConciliacionAgrupados>)dataTableList);
	}
	
	public String getDescripTipoOper(){
		return null;
 	}
	
	/**
	 * Visualizamos un Error de Conciliación.
	 * 
	 */
	public void ver() {
		//erroresConciliacionPantalla.setErrorConciliacionSel(erroresConciliacionBo.cargar(erroresConciliacionPantalla.getErroresConciliacionAgrupados().getId()));
		errorSeleccionado = erroresConciliacionPantalla.getErroresConciliacionAgrupados();
		erroresConciliacionPantalla.getErroresConciliacionAgrupados().setIndicActividad(erroresConciliacionPantalla.getIndicActividad());
		setModoPantalla(ModoPantalla.INSPECCION);		
	}
	
	public void tiposErroresConciliacionSelect(){
		this.tipoErroresConciliacionList = null;
	}
	
	@Factory(value = "mantOperaciones.tipoErroresConciliacion")
	public void obtenerTiposErroresConciliacionSelect() {
		//String origen, Date fechaProceso, String indicActividad
//		erroresConciliacionPantalla.setIndicActividad(erroresConciliacionPantalla.getIndicActividad());
		this.tipoErroresConciliacionList = erroresConciliacionBo.obtenerTiposErroresConciliacionSelect(erroresConciliacionPantalla.getFechaProceso(),erroresConciliacionPantalla.getTipoConciliacion(),erroresConciliacionPantalla.getIndicActividad());
	}
	
	public void setNumOper(){
		if(!GenericUtils.isNullOrBlank(erroresConciliacionPantalla.getnumOperacionDesde()) &&  GenericUtils.isNullOrBlank(erroresConciliacionPantalla.getnumOperacionHasta()))
			erroresConciliacionPantalla.setnumOperacionHasta(erroresConciliacionPantalla.getnumOperacionDesde());
	}
	public void setDealNumber(){
		if(!GenericUtils.isNullOrBlank(erroresConciliacionPantalla.getDealNumDesde()) &&  GenericUtils.isNullOrBlank(erroresConciliacionPantalla.getDealNumHasta()))
			erroresConciliacionPantalla.setDealNumHasta(erroresConciliacionPantalla.getDealNumDesde());
	}
	
	public void init(){
		if (GenericUtils.isNullOrBlank(this.erroresConciliacionPantalla.getFechaProceso())){
			this.erroresConciliacionPantalla.setFechaProceso(erroresConciliacionBo.obtenerFechaSistema());
		}
	}
	
}
