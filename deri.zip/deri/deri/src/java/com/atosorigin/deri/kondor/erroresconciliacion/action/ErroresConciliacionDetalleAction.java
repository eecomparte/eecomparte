package com.atosorigin.deri.kondor.erroresconciliacion.action;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;

import org.jboss.seam.ScopeType;
import org.jboss.seam.annotations.Factory;
import org.jboss.seam.annotations.In;
import org.jboss.seam.annotations.Name;
import org.jboss.seam.annotations.Out;
import org.jboss.seam.annotations.Scope;
import org.jboss.seam.annotations.datamodel.DataModel;
import org.jboss.seam.annotations.datamodel.DataModelSelection;
import org.jboss.seam.international.StatusMessage.Severity;

import com.atosorigin.common.action.PaginatedListAction;
import com.atosorigin.common.utils.GenericUtils;
import com.atosorigin.deri.adminoper.admconfirmaciones.business.ConfirmacionOperacionesBo;
import com.atosorigin.deri.kondor.erroresconciliacion.business.ErroresConciliacionBo;
import com.atosorigin.deri.model.contrapartida.Contrapartida;
import com.atosorigin.deri.model.gestionoperaciones.Operacion;
import com.atosorigin.deri.model.gestionoperaciones.OperacionId;
import com.atosorigin.deri.model.kondor.ErroresConciliacion;
import com.atosorigin.deri.model.kondor.ErroresConciliacionAgrupados;
import com.atosorigin.deri.util.MessageBoxAction;
import com.atosorigin.deri.util.MsgBoxAction;



/**
 * Clase action listener para el caso de uso de Errores de Conciliacion.
 */
@Name("erroresConciliacionDetalleAction")
@Scope(ScopeType.CONVERSATION)
public class ErroresConciliacionDetalleAction extends PaginatedListAction {

	public static class ValuePair{
		private String campo;
		private String valor;
		public String getCampo() {
			return campo;
		}
		public void setCampo(String campo) {
			this.campo = campo;
		}
		public String getValor() {
			return valor;
		}
		public void setValor(String valor) {
			this.valor = valor;
		}
		public ValuePair(String campo, String valor) {
			super();
			this.campo = campo;
			this.valor = valor;
		}
		
	}
	/**
	 * Inyección del bean de Spring "erroresConciliacionBo" que contiene los tipos de error
	 * para el caso de uso Errores de Conciliación.
	 */
	@In("#{erroresConciliacionBo}")
	protected ErroresConciliacionBo erroresConciliacionBo;

	@In("#{admconfirmacionesBo}")
	protected ConfirmacionOperacionesBo admConfirmacionesBo;
	
   @In(value="errorSeleccionado")
    protected ErroresConciliacionAgrupados errorConciliacionAgrupado;	

	/** Lista de datos para el grid. */
	@DataModel(value ="listaDtErroresConciliacion")
	protected List<ErroresConciliacion> erroresConciliacionList;
	
	@DataModel("listaCamposKondor")
	private List<ValuePair> listaCamposKondor;
	
	@DataModel("listaCamposBO")
	private List<ValuePair> listaCamposBo;

	
	private String onComplete;
	private String motivoDescarte =""; 
	
	@DataModelSelection("listaDtErroresConciliacion") 
	private ErroresConciliacion errorActual;
	
	
	private HashSet<ErroresConciliacion> erroresSeleccionados = new HashSet<ErroresConciliacion>();
	
	private Boolean primeraEjecucionInit = null;
	
	@In(create = true)
	MsgBoxAction msgBoxAction;
	
	@Out(required = false, value = "erroresConciliacionDetalleMessageBoxAction")
	private MessageBoxAction messageBoxErroresConciliacionDetalleAction;
	
	@Out
	public Boolean getSelectedRow(){
		return erroresSeleccionados.contains(errorActual);
	}
	public void setSelectedRow(Boolean selected){
		if(selected){
			erroresSeleccionados.add(errorActual);
		}
		else{
			erroresSeleccionados.remove(errorActual);
		}
	}
	
	public void seleccionarError(){
		//erroresSeleccionados.add(errorActual);
	}

	@Override
	public List<ErroresConciliacion> getDataTableList() {
		// TODO Auto-generated method stub
		return erroresConciliacionList;
	}

	@Override
	@Factory(value="listaDtErroresConciliacion")
	public void refreshListInternal() {
		erroresSeleccionados.clear();
		setExportExcel(false);
		erroresConciliacionList = erroresConciliacionBo.recuperarErroresConciliacionDesdeAgrupado(errorConciliacionAgrupado, paginationData);
	}

	@Factory("listaCamposKondor")
	public void refrescarListaCamposKondor(){
		if(errorActual==null){
			listaCamposKondor= Collections.EMPTY_LIST;
		}
		else{
			String camposKondor = errorActual.getCampoKp();
			String contenidoKondor = errorActual.getContenidoKP();
			listaCamposKondor = parseValuePairs(camposKondor, contenidoKondor);
		}
		
	}
	@Factory("listaCamposBO")
	public void refrescarListaCamposBO(){
		if(errorActual==null){
			listaCamposBo= Collections.EMPTY_LIST;
		}
		else{
			String campos = errorActual.getCampoBo();
			String contenido = errorActual.getContenidoBo();
			listaCamposBo = parseValuePairs(campos, contenido);
		}
		
	}
	private List<ValuePair> parseValuePairs(String campos, String contenido) {
		List<ValuePair> result = new ArrayList();
		if(campos!=null && contenido!=null){
			String[] camposArray = campos.split(";");
			String[] contenidoArray = contenido.split(";");
			int index=0;
			for (String campo : camposArray) {
				if(index<contenidoArray.length){
					String valor =contenidoArray[index]; 
					ValuePair pair = new ValuePair(campo, valor);
					result.add(pair);
					index++;
				}
			}
		}
		return result;
	}

	@Override
	public void refrescarListaExcel() {
		setExportExcel(true);
		erroresConciliacionList = 
			erroresConciliacionBo.recuperarErroresConciliacionDesdeAgrupado(
					errorConciliacionAgrupado,
					paginationData.getPaginationDataForExcel());
	}

	public String getDescripTipoOper(){
		return null;
 	}

	@Override
	public void setDataTableList(List<?> dataTableList) {
		// TODO Auto-generated method stub
		
	}
	
	public void voidFunction(){
		msgBoxAction.voidFunction();
	}
	
	public void initDetalle(){
		if (primeraEjecucionInit == null) {
			primeraEjecucionInit=true;
		} 
		else{
			primeraEjecucionInit = false;
		}
		
		if(null==messageBoxErroresConciliacionDetalleAction){
			messageBoxErroresConciliacionDetalleAction = new MessageBoxAction();
		}
		
		if(primeraEjecucionInit){
			OperacionId opId = new OperacionId();
			opId.setNumeroOperacion(errorConciliacionAgrupado.getNumeroOperacion());
			opId.setFechaContratacion(errorConciliacionAgrupado.getfContratacionOperacion());
			
			Operacion ope = admConfirmacionesBo.buscarOperacion(opId);
			Contrapartida contrapartida = (Contrapartida) ope.getContrapartida();
			if (null!=contrapartida && !GenericUtils.isNullOrBlank(contrapartida.getIndBloqueo()) && "S".equalsIgnoreCase(contrapartida.getIndBloqueo())){
				abrirPopUpContrapartidaBloqueada();
			}
		}
	}
	
	public void changeRow(){
		listaCamposKondor=null;
		listaCamposBo=null;
		refrescarListaCamposBO();
		refrescarListaCamposKondor();
	}

	public void onChangeIndActividad(){
		erroresConciliacionList=null;
		errorActual=null;
		listaCamposKondor=null;
		listaCamposBo=null;
		
	}
	public String getRowClasses(){
		StringBuilder builder = new StringBuilder();
		int i=0;
		for (ErroresConciliacion errores : erroresConciliacionList) {
			if(i>0){
				builder.append(",");
			}
			if(errores.equals(errorActual)){
				builder.append("SelectedRow");
			}
			else{
				if(i%2==0){
					builder.append("oddRow");
				}
				else{
					builder.append("evenRow");
				}
			}
			i++;
		}
		return builder.toString();
	}
	public void activar(){
		if (motivoDescarte == null ){
			erroresConciliacionBo.actualizarErroresConciliacionActivos(new ArrayList<ErroresConciliacion>(erroresSeleccionados), motivoDescarte );
			refrescarLista();
		}else{
			motivoDescarte = motivoDescarte.replaceAll("\r","");
			if (motivoDescarte.length()>250)
				statusMessages.add(Severity.ERROR,"#{messages['erroresConciliacion.error.longExcedida']}");
			else{
				erroresConciliacionBo.actualizarErroresConciliacionActivos(new ArrayList<ErroresConciliacion>(erroresSeleccionados), motivoDescarte );
				setMotivoDescarte(null);			
				refrescarLista();
				}
		}
	}
	public Boolean isActivarDisabled(){
		return erroresSeleccionados.isEmpty();
	}
	public List<ErroresConciliacion> getErroresConciliacionList() {
		return erroresConciliacionList;
	}
	public void setErroresConciliacionList(
			List<ErroresConciliacion> erroresConciliacionList) {
		this.erroresConciliacionList = erroresConciliacionList;
	}
	
	public void mostrarMotivo(){
		
		setMotivoDescarte(null);
//		if (Constantes.CONTRAPA_GRUPOBAN_CLIENTE.equalsIgnoreCase(contrapa.getGrupoBancario().getId())){
//			statusMessages.add(Severity.ERROR,"#{messages['admconfirmaciones.error.contrapanobanco']}");
//			setOnCompleteNo();
//		}else{
//			setOnCompleteSi();
//		}
		setOnCompleteSi();
	}
	
	public void setOnCompleteNo() {
		setOnComplete("$('motivoPanel').component.hide();return false;");
	}

	public void setOnCompleteSi() {
		setOnComplete("$('motivoPanel').component.show();");
	}
	public String getOnComplete() {
		return onComplete;
	}
	public void setOnComplete(String onComplete) {
		this.onComplete = onComplete;
	}
	public String getMotivoDescarte() {
		return motivoDescarte;
	}
	public void setMotivoDescarte(String motivoDescarte) {
		this.motivoDescarte = motivoDescarte;
	}

	private void abrirPopUpContrapartidaBloqueada(){
		messageBoxErroresConciliacionDetalleAction.init("erroresConciliacion.messages.contrapartida.bloqueada.texto", "erroresConciliacionDetalleAction.voidFunction()",null,"messageBoxPanelContrapa");
	}
	
}
