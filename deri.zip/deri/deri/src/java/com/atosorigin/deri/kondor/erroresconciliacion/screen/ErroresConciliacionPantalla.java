package com.atosorigin.deri.kondor.erroresconciliacion.screen;

import java.util.Date;
import java.util.List;

import org.jboss.seam.ScopeType;
import org.jboss.seam.annotations.Name;
import org.jboss.seam.annotations.Out;
import org.jboss.seam.annotations.Scope;
import org.jboss.seam.annotations.datamodel.DataModel;
import org.jboss.seam.annotations.datamodel.DataModelSelection;

import com.atosorigin.common.utils.GenericUtils;
import com.atosorigin.deri.model.kondor.ErroresConciliacion;
import com.atosorigin.deri.model.kondor.ErroresConciliacionAgrupados;
import com.atosorigin.deri.model.kondor.TipoErroresConciliacion;


/**
 *  Contiene los datos de pantalla necesarios para el caso de uso Errores de Conciliacion
 */
@Name("erroresConciliacionPantalla")
@Scope(ScopeType.CONVERSATION)
public class ErroresConciliacionPantalla {

	private static final String TIPO_CONCILIACION_DEFAULT = "DERI";

	/** fechaProceso. Criterio de búsqueda de Errores de Conciliacion  */
	protected Date fechaProceso;
	
	/** tipoConciliacion. Criterio de búsqueda de Errores de Conciliacion  */
	/** Origen */
	protected String tipoConciliacion = TIPO_CONCILIACION_DEFAULT;
	
	/** indicActividad. Criterio de búsqueda de Errores de Conciliacion  */
	/** estado */
	protected String indicActividad;;
	
	/** numOperacionDesde. Criterio de búsqueda de Errores de Conciliacion  */
	protected Long numOperacionDesde;
	
	/** numOperacionHasta. Criterio de búsqueda de Errores de Conciliacion  */
	protected Long numOperacionHasta;
	
	/** codigoError. Criterio de búsqueda de Errores de Conciliacion  */
	protected TipoErroresConciliacion codigoError;
	
	/** dealNumDesde. Criterio de búsqueda de Errores de Conciliacion  */
	protected Long dealNumDesde;
	
	/** dealNumHasta. Criterio de búsqueda de Errores de Conciliacion  */
	protected Long dealNumHasta;
	
	/** dealType. Criterio de búsqueda de Errores de Conciliacion  */
	protected String dealType;

	/** Número de resultados totales para los criterios de búsqueda. */
	protected Long numFilas = 0L;	
	
	/** Operación (P_Tratamiento_Sel) */
	protected String operacion;
	
	/** Titulo Tabla Kondor */
	protected String tituloK;

	/** Titulo Tabla BO */
	protected String tituloBO;	
	
	/** Seleccionada */
	protected Boolean esCotizable;

	protected String motivoDescarte;
	
	

	/** Lista de datos para el grid. */
	@DataModel(value ="listaDtErrorConciAgrup")
	protected List<ErroresConciliacionAgrupados> erroresConciliacionAgrupList;
	


	/** Tipo de documento seleccionado en el grid */
	@DataModelSelection(value ="listaDtErrorConciAgrup")
    @Out(required=false)
    protected ErroresConciliacionAgrupados errorConciliacionAgrupado;	
	
	
	@Out(required=false)
	protected ErroresConciliacion errorConciliacionSel;
	
	public ErroresConciliacionPantalla(){
		super();
	}
	
	public Date getFechaProceso() {
		return fechaProceso;
	}

	public void setFechaProceso(Date fechaProceso) {
		this.fechaProceso = fechaProceso;
	}	

	
	public String getTipoConciliacion() {
		return tipoConciliacion;
	}

	public void setTipoConciliacion(String tipoConciliacion) {
		if(!TIPO_CONCILIACION_DEFAULT.equals(tipoConciliacion)){
			setDealNumDesde(null);
			setDealNumHasta(null);
			setDealType(null);
		}
		this.tipoConciliacion = tipoConciliacion;
	}

	public String getIndicActividad() {
		return indicActividad;
	}

	public void setIndicActividad(String indicActividad) {
		if (!GenericUtils.isNullOrBlank(indicActividad)) {
			setCodigoError(null);		
			}
		this.indicActividad = indicActividad;
	}

	public String getDealType() {
		return dealType;
	}

	public void setDealType(String dealType) {
		this.dealType = dealType;
	}	
	

	public TipoErroresConciliacion getCodigoError() {
		return codigoError;//.getTipoError();
	}

	public void setCodigoError(TipoErroresConciliacion codigoError) {
		this.codigoError = codigoError;
	}	

	public Long getDealNumDesde() {
		return dealNumDesde;
	}

	public void setDealNumDesde(Long dealNumDesde) {
		this.dealNumDesde = dealNumDesde;
	}	

	public Long getDealNumHasta() {
		return dealNumHasta;
	}

	public void setDealNumHasta(Long dealNumHasta) {
		this.dealNumHasta = dealNumHasta;
	}	

	
	public Long getnumOperacionDesde() {
		return numOperacionDesde;
	}

	public void setnumOperacionDesde(Long numOperacionDesde) {
		//if(GenericUtils.isNullOrBlank(this.numOperacionHasta))
			//	this.setnumOperacionHasta(numOperacionDesde);
		this.numOperacionDesde = numOperacionDesde;
	}	

	public Long getnumOperacionHasta() {
		return numOperacionHasta;
	}

	public void setnumOperacionHasta(Long numOperacionHasta) {
		this.numOperacionHasta = numOperacionHasta;
	}	

	
	public List<ErroresConciliacionAgrupados> getErroresConciliacionAgrupList() {
		return erroresConciliacionAgrupList;
	}

	public void setErroresConciliacionAgrupList(List<ErroresConciliacionAgrupados> erroresConciliacionAgrupList) {
		this.erroresConciliacionAgrupList = erroresConciliacionAgrupList;
	}	 

	public ErroresConciliacionAgrupados getErroresConciliacionAgrupados() {
		return errorConciliacionAgrupado;
	}

	public void setErroresConciliacionAgrupados(ErroresConciliacionAgrupados errorConciliacionAgrupado) {
		this.errorConciliacionAgrupado = errorConciliacionAgrupado;
	}
	
	public void setErrorConciliacionSel(ErroresConciliacion errConciSel){
		this.errorConciliacionSel = errConciSel; 
	}
	
	 public ErroresConciliacion getErrorConciliacionSel(){
		 return this.errorConciliacionSel;
	 }
	
	public Long getNumFilas() {
		return numFilas;
	}

	public void setNumFilas(Long numFilas) {
		this.numFilas = numFilas;
	}

	public String getOperacion() {
		return this.operacion;
	}

	public String getTituloK(){
	 return this.tituloK;	
	}
	
	public void setTituloK(){
		if  ( tipoConciliacion == TIPO_CONCILIACION_DEFAULT ) 
		     this.tituloK = "#{messages['erroresConciliacion.DatosK']}"; 
		else this.tituloK = "#{messages['erroresConciliacion.DatosA']}" ;	
		}

	public String getTituloBO(){
		 return this.tituloBO;	
		}
		
		public void setTituloBO(){
			if  ( tipoConciliacion == TIPO_CONCILIACION_DEFAULT ) 
			     this.tituloBO = "#{messages['erroresConciliacion.DatosBO']}"; 
			else this.tituloBO = "#{messages['erroresConciliacion.DatosB']}" ;	
			}

		public String getMotivoDescarte() {
			return motivoDescarte;
		}

		public void setMotivoDescarte(String motivoDescarte) {
			this.motivoDescarte = motivoDescarte;
		}
}
