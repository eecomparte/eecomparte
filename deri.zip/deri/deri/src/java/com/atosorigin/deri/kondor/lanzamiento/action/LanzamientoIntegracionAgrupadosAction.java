package com.atosorigin.deri.kondor.lanzamiento.action;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashSet;
import java.util.List;

import javax.persistence.RollbackException;

import org.jboss.seam.ScopeType;
import org.jboss.seam.annotations.In;
import org.jboss.seam.annotations.Name;
import org.jboss.seam.annotations.Out;
import org.jboss.seam.annotations.Scope;
import org.jboss.seam.core.Conversation;
import org.jboss.seam.faces.FacesMessages;
import org.jboss.seam.international.StatusMessage;
import org.jboss.seam.international.StatusMessages;
import org.jboss.seam.international.StatusMessage.Severity;

import com.atosorigin.common.action.PaginatedListAction;
import com.atosorigin.common.constantes.Constantes;
import com.atosorigin.common.utils.GenericUtils;
import com.atosorigin.deri.common.dbLock.DbLockService;
import com.atosorigin.deri.kondor.lanzamiento.screen.LanzamientoIntegracionPantalla;
import com.atosorigin.deri.kondor.lanzamientointegracion.business.LanzamientoIntegracionBo;
import com.atosorigin.deri.liquidaciones.business.LiquidacionesBo;
import com.atosorigin.deri.model.kondor.BuzonDeri;
import com.atosorigin.deri.model.kondor.ListaBuzonOrdenada;
import com.atosorigin.deri.model.kondor.VistaBuzonDeri;
import com.atosorigin.deri.model.liquidaciones.Liquidacion;
import com.atosorigin.deri.model.liquidaciones.VistaLiquidacion;
import com.atosorigin.deri.model.murex.BuzonLogInt;
import com.atosorigin.deri.model.murex.VistaBuzonLogInt;
import com.atosorigin.deri.util.MessageBoxAction;

/**
 * Clase action listener para el caso de uso de lanzamiento de integración.
 */
@Name("lanzamientoIntegracionAgrupadosAction")
@Scope(ScopeType.CONVERSATION)
public class LanzamientoIntegracionAgrupadosAction extends PaginatedListAction {

	/**
	 * Inyección del bean de Spring "lanzamientoIntegracionBo" que contiene los métodos de negocio
	 * para el caso de uso lanzamiento integración.
	 */
	@In("#{lanzamientoIntegracionBo}")
	protected LanzamientoIntegracionBo lanzamientoIntegracionBo;

	@In("#{liquidacionesBo}")
	protected LiquidacionesBo liquidacionesBo;
	
	
	/** Inyección del servicio que gestiona los bloqueos de registros en base de datos */
	@In(create = true)
	protected DbLockService dbLockService;	
	
	/**
	 * Inyección del screen bean que contiene los datos de pantalla del caso de uso
	 * lanzamiento de integracion.
	 */
	@In(create=true)
	protected LanzamientoIntegracionPantalla lanzamientoIntegracionPantalla;
	
	
	@Out(required = false, value = "buzonDeriSeleccionado")
	protected BuzonDeri buzonSeleccionado;
	
	
	@Out(required = false, value = "lanzaAgrMessageBoxAction")
	private MessageBoxAction messageBoxActionMO;
	
//	protected  List<BuzonDeri>  lanzamientosKondorTotal;
	protected  List<VistaBuzonDeri>  lanzamientosKondorTotal;
	private boolean bmn = false;
	private boolean migracion = false;
	
	public void onMessageBoxSalirOk(){
		Conversation conversacion = Conversation.instance();
//		//Volvemos al anterior
//		conversacion.redirectToParent();
		redirectToURL("/home.seam");
//		conversacion.endBeforeRedirect();
		conversacion.endAndRedirect();
	
	}

	/** Carga los valores de inicialización del formulario */ 
	public void newFormInstance() {
//		if(lanzamientoIntegracionBo.isAvisosCodigoEvento4001()){
//		
//			if (messageBoxActionMO==null){
//				messageBoxActionMO = new MessageBoxAction();
//			}
//			messageBoxActionMO.init("aceptar.lanzamientopendiente.errorfin", "lanzamientoIntegracionAgrupadosAction.onMessageBoxSalirOk()",
//					null,"helperPanel");	
//
//			
////			statusMessages.add(StatusMessage.Severity.ERROR, "#{messages['aceptar.lanzamientopendiente.errorfin']}");
//		}else{
		
		this.lanzamientoIntegracionPantalla.setFecha(new Date()); // Cargamos con la fecha actual
		this.lanzamientoIntegracionPantalla.setOperaciones(getOperacionesPendientes()); // Cargamos número operaciones
		lanzamientosKondorTotal = getRegistrosPendientes();
		this.setBmn(false);
		this.setMigracion(false);
		refrescarLista();
//		}
	}
	
//	public void newFormInstanceBMN() {
//		this.lanzamientoIntegracionPantalla.setFecha(new Date()); // Cargamos con la fecha actual
//		this.lanzamientoIntegracionPantalla.setOperaciones(getOperacionesPendientesBMN()); // Cargamos número operaciones
//		lanzamientosKondorTotal = getRegistrosPendientesBMN();
//		this.setBmn(true);
//		this.setMigracion(false);
//		refrescarLista();
//	}
//
//	public void newFormInstanceMigra() {
//		this.lanzamientoIntegracionPantalla.setFecha(new Date()); // Cargamos con la fecha actual
//		this.lanzamientoIntegracionPantalla.setOperaciones(getOperacionesPendientesMigra()); // Cargamos número operaciones
//		lanzamientosKondorTotal = getRegistrosPendientesMigra();
//		this.setBmn(false);
//		this.setMigracion(true);
//		refrescarLista();
//	}

	//	SMM 12/04/2017 Codigo Naranja
	//1 - Si tiene liquidaciones validadas.
	//2 - Si tiene liquidaciones liquidadas.(en el caso de cancelaciones solo con fecha del dia)
	//3 - Si tiene liquidaciones validadas y liquidadas ((en el caso de cancelaciones solo con fecha del dia).
	//0 - Resto de casos, valor por defecto.
	
	// 1 - M  Aviso desvalidar liquidacion
	// 1 - NCP desvalidar directamente liquidacion
	// 2 - N  Aviso para integrar
	// 2 - CP  Aviso para integrar
	// 3 - NCP  Aviso para integrar si si desvalidar directamente
	// 3 - M  Aviso desvalidar liquidacion validadas
	
	public void tratamientoNaranja(){
		boolean unico = false;
		if (listasSeleccionadas!=null && !listasSeleccionadas.isEmpty() && listasSeleccionadas.size()==1){
			VistaBuzonDeri buzontmp = null;
			for (VistaBuzonDeri buzon : listasSeleccionadas) {
				buzontmp = buzon;
			}
			if (buzontmp.getCodigoNaranja()==0 || !buzontmp.isIntegrable() ){
				actualizarAgenda();
			}else{

			if(lanzamientoIntegracionBo.isAvisosCodigoEvento4001()){
				/** Avisamos de que hay un lanzamiento pendiente de procesar */
				statusMessages.add(StatusMessage.Severity.ERROR, "#{messages['aceptar.lanzamientopendiente.error']}");
				refrescarPantalla();
				return;
			}
			
			//UNICO NARANJA	
				if (buzontmp.getCodigoNaranja()==1){
			
					if (buzontmp.getIndicadorSituacion().equalsIgnoreCase("M")){
						//Aviso desvalidar
						avisoDesvalidar();
						
					}else{
						//Ya llama a la integracion 
						onMessageBoxDesvalidar();
					}
				
				
			}else if (buzontmp.getCodigoNaranja()==2){
				if (GenericUtils.in(buzontmp.getIndicadorSituacion(), "N","C","P")){
					//Aviso integrar
					avisoLiquidadas();
				}else{
					onMessageBoxIntegrar();
				}
			
			}else if (buzontmp.getCodigoNaranja()==3){
				if (GenericUtils.in(buzontmp.getIndicadorSituacion(), "N","C","P")){
					avisoLiquidadasVal();
				}else{
					//Aviso desvalidar
					avisoDesvalidar();
				}
				
			}
			
			
			}
			
			
		}else{
			actualizarAgenda();
		}
		
//		refrescarPantalla();
	}
	
	public void onMessageBoxDesvalidar(){
		VistaBuzonDeri buzontmp = null;
		for (VistaBuzonDeri buzon : listasSeleccionadas) {
			buzontmp = buzon;
		}
		List<Liquidacion> liquidacionList = new ArrayList<Liquidacion>();
		List<String> estados = new ArrayList<String>();
		estados.clear();
		estados.add("VA");
		
//		liquidacionList = lanzamientoIntegracionBo.obtenerLiquidaciones(Constantes.NOMBRE_PROYECTO_DERI,buzontmp.getNumeroOperacion(), buzontmp.getBuzon().getfContratacionOperacion(),estados,null);
		liquidacionList = lanzamientoIntegracionBo.obtenerLiquidaciones(Constantes.NOMBRE_PROYECTO_DERI,buzontmp.getDealType(), buzontmp.getDealNumber(),estados,null);
		for (Liquidacion liquidac : liquidacionList) {
			desvalidar(liquidac);
		}
		
		
		
		onMessageBoxIntegrar();
	}
	
	
	
	public boolean bloquearLiquidacion(Liquidacion liquidacion, String accion){
		
		String tipoOpera = null;
		if (liquidacion.getTipopera().equals(Constantes.LIQUIDACION_TIPOPERA_P)){
			tipoOpera = Constantes.LIQUIDACION_TIPOPERA_PAGO;
		}else{
			tipoOpera = Constantes.LIQUIDACION_TIPOPERA_COBRO;
		}
		//si devuelve false es que el registro ya está bloqueado
		if (!dbLockService.bloqueo(Liquidacion.class, liquidacion.getId())){					
			statusMessages.addFromResourceBundle(Severity.ERROR,"liquidaciones.error.noBloqueo", liquidacion.getNcorrela(), 
					liquidacion.getProducto(), liquidacion.getFechaliq(), tipoOpera, liquidacion.getImportel(), accion);
			return false; 
		}
		//El registro sigue bloqueado
		return true;
		
	}
	
	private void desvalidar(Liquidacion liquidac) {
		
		if (this.bloquearLiquidacion(liquidac, "desvalidar")) {

			
			if (comprobarDesvalidacion(liquidac)){
				statusMessages.addFromResourceBundle(Severity.WARN,"liquidaciones.warning.desvalidar", liquidac.getNcorrela(),liquidac.getId().getCodliqui());
			}
			
				try {
					liquidac.setEstado(Constantes.LIQUIDACION_VALIDADA);
					liquidacionesBo.desvalidarLiquidacion(liquidac);
					liquidacionesBo.flush();
				} catch (RollbackException r) {
					statusMessages.add(Severity.ERROR, "#{messages['liquidaciones.error.rollback']}");
					throw new RollbackException();
				} finally {
					dbLockService.desbloqueo(Liquidacion.class, liquidac.getId());
				}
		
		}
		
	}

		
		private Boolean comprobarDesvalidacion(Liquidacion liquidacion) {
			Date fechamis=null ;
			
			if (Constantes.LIQ_ENVIADA.equalsIgnoreCase(liquidacion.getSitualiq())){
				return true;
			}

			if (liquidacionesBo.esProductoRAD(liquidacion.getProducto())){ 

				if (Constantes.CANAL_SWIFT.equalsIgnoreCase(liquidacion.getCanaliqi())){
					
					fechamis = liquidacionesBo.obtenerFechaSistema(); //Recuperamos la fecha del sistema
					if (fechamis.after(liquidacion.getSwift().getFechaenv())){
						return true;
					}
					
				}
				
			}else{
	/**
	 * 							CTA P/C	D-1 (FECHALIQ-1)	Fecha Liquidación = Fecha dia
	 *  						TAR Pago	D-1 (FECHALIQ-1)	Fecha Liquidación = Fecha dia
	 *  						TAR Cobro	D (FECHALIQ)	No corresponde
	 *  						SW  P/C	FECHAENV (SWMT0202)	Fecha día > FECHAENV
	 */
				if (Constantes.CANAL_CLIENTE.equalsIgnoreCase(liquidacion.getCanaliqi())){
					fechamis = liquidacionesBo.obtenerFechaSistema(); //Recuperamos la fecha del sistema	
					if (liquidacion.getFechaliq().equals(fechamis)){
						return true;
					}
				}else if (Constantes.CANAL_TARGET.equalsIgnoreCase(liquidacion.getCanaliqi())){
					if (Constantes.LIQUIDACION_TIPOPERA_P.equalsIgnoreCase(liquidacion.getTipopera())){
						fechamis = liquidacionesBo.obtenerFechaSistema(); //Recuperamos la fecha del sistema	
						if (liquidacion.getFechaliq().equals(fechamis)){
							return true;
						}
					}
				}else if (Constantes.CANAL_SWIFT.equalsIgnoreCase(liquidacion.getCanaliqi())){
					fechamis = liquidacionesBo.obtenerFechaSistema(); //Recuperamos la fecha del sistema
					if (fechamis.after(liquidacion.getSwift().getFechaenv())){
						return true;
					}
				}
			
			}
			
			return false;
		}
		

	public void voidFunction(){
		
	}
	
	public void onMessageBoxIntegrar(){
		
		/** Comprueba si hay eventos 4001 tratados en la agenda */
		if(!lanzamientoIntegracionBo.isAvisosCodigoEvento4001()){
	
			//Actualizamos la tabla
			lanzamientoIntegracionBo.actualizarSeleccionadosAgrupados(listasSeleccionadas,4L);
			statusMessages.add(StatusMessage.Severity.INFO, "#{messages['lanzamiento.registros']}");
		
			/** Buscamos número de evento e insertamos nuevo registro */
			if (lanzamientoIntegracionBo.updateAgenda()){
			
				/** Avisamos de que el lanzamiento se ha realizado con éxito */
				statusMessages.add(StatusMessage.Severity.INFO, "#{messages['aceptar.lanzamientorealizado']}");
			}else{
				statusMessages.add(StatusMessage.Severity.ERROR, "#{messages['aceptar.eventoError']}");
			}
	
		} else {
			/** Avisamos de que hay un lanzamiento pendiente de procesar */
			statusMessages.add(StatusMessage.Severity.ERROR, "#{messages['aceptar.lanzamientopendiente.error']}");
		}
	
		refrescarPantalla();
	
	}
	
	private void avisoDesvalidar() {
		
		if (messageBoxActionMO==null){
			messageBoxActionMO = new MessageBoxAction();
		}
		
		messageBoxActionMO.init("integracion.modif.liquidacion.validada", "lanzamientoIntegracionAgrupadosAction.onMessageBoxDesvalidar()",
				"lanzamientoIntegracionAgrupadosAction.onMessageBoxIntegrar()","resultadosConsulta, LanzamientoIntegracionForm, helperPanel");	

//		
////		statusMessages.add(StatusMessage.Severity.ERROR, "#{messages['aceptar.lanzamientopendiente.errorfin']}");
		
	}

	private void avisoLiquidadas() {
		
		if (messageBoxActionMO==null){
			messageBoxActionMO = new MessageBoxAction();
		}
		
		messageBoxActionMO.init("integracion.modif.liquidacion.liquidadas", "lanzamientoIntegracionAgrupadosAction.onMessageBoxIntegrar()",
				"lanzamientoIntegracionAgrupadosAction.voidFunction()","resultadosConsulta, LanzamientoIntegracionForm, helperPanel");	

//		
////		statusMessages.add(StatusMessage.Severity.ERROR, "#{messages['aceptar.lanzamientopendiente.errorfin']}");
		
	}
	
	private void avisoLiquidadasVal() {
		
		if (messageBoxActionMO==null){
			messageBoxActionMO = new MessageBoxAction();
		}
		
		messageBoxActionMO.init("integracion.modif.liquidacion.liquidadas", "lanzamientoIntegracionAgrupadosAction.onMessageBoxDesvalidar()",
				"lanzamientoIntegracionAgrupadosAction.voidFunction()","resultadosConsulta, LanzamientoIntegracionForm, helperPanel");	

//		
////		statusMessages.add(StatusMessage.Severity.ERROR, "#{messages['aceptar.lanzamientopendiente.errorfin']}");
		
	}

	
	/** Lanza el proceso Kondor + insertando un solo evento del tipo 4001 */
	public void actualizarAgenda(){
		HashSet<VistaBuzonDeri> listasSelecIntegrables = new HashSet<VistaBuzonDeri>();
		boolean todasIntegrables = true;
		if (listasSeleccionadas!=null && !listasSeleccionadas.isEmpty()){

			
			
			for (VistaBuzonDeri buzon : listasSeleccionadas) {
				if (buzon.isIntegrable() && buzon.getCodigoNaranja()==0){
					listasSelecIntegrables.add(buzon);
				}else{
					todasIntegrables=false;	
				}
			}
			
		}
		
		if (!todasIntegrables){
			statusMessages.add(StatusMessage.Severity.INFO, "#{messages['aceptar.nointegradas']}");
		}
		
		if (listasSelecIntegrables!=null && !listasSelecIntegrables.isEmpty()){	
			
			/** Comprueba si hay eventos 4001 tratados en la agenda */
			if(!lanzamientoIntegracionBo.isAvisosCodigoEvento4001()){
		
				//Actualizamos la tabla
				lanzamientoIntegracionBo.actualizarSeleccionadosAgrupados(listasSelecIntegrables,4L);
				statusMessages.add(StatusMessage.Severity.INFO, "#{messages['lanzamiento.registros']}");
			
				/** Buscamos número de evento e insertamos nuevo registro */
				if (lanzamientoIntegracionBo.updateAgenda()){
				
					/** Avisamos de que el lanzamiento se ha realizado con éxito */
					statusMessages.add(StatusMessage.Severity.INFO, "#{messages['aceptar.lanzamientorealizado']}");
				}else{
					statusMessages.add(StatusMessage.Severity.ERROR, "#{messages['aceptar.eventoError']}");
				}
		
			} else {
				/** Avisamos de que hay un lanzamiento pendiente de procesar */
				statusMessages.add(StatusMessage.Severity.ERROR, "#{messages['aceptar.lanzamientopendiente.error']}");
			}
			refrescarPantalla();
		}else{
			statusMessages.add(StatusMessage.Severity.INFO, "#{messages['lanzamiento.sin.registros']}");
		}

		}
	
	/** Recupera el número de operaciones pendientes */
	private Integer getOperacionesPendientes(){
		return lanzamientoIntegracionBo.getOperacionesPendientes();
	}

	private Integer getOperacionesPendientesBMN(){
		return lanzamientoIntegracionBo.getOperacionesPendientesBMN();
	}

	private Integer getOperacionesPendientesMigra(){
		return lanzamientoIntegracionBo.getOperacionesPendientesMigra();
	}

	
	private List<VistaBuzonDeri> getRegistrosPendientes(){
		return lanzamientoIntegracionBo.getRegistrosPendientesResumido();
	}
	
	private List<BuzonDeri> getRegistrosPendientesBMN(){
		return lanzamientoIntegracionBo.getRegistrosPendientesBMN();
	}

	private List<BuzonDeri> getRegistrosPendientesMigra(){
		return lanzamientoIntegracionBo.getRegistrosPendientesMigra();
	}

	
	@Override
	public List<VistaBuzonDeri> getDataTableList() {
		// TODO Auto-generated method stub
		return 	this.lanzamientoIntegracionPantalla.getLanzamientoIntKondorAgrupList();
	}

	@Override
	public void refrescarListaExcel() {
		// TODO Auto-generated method stub
		setExportExcel(true);
		setDataTableList(lanzamientosKondorTotal);
	}

	@Override
	protected void refreshListInternal() {
		// TODO Auto-generated method stub
		setExportExcel(false);
		Integer maxResults; 
		if (paginationData !=null && lanzamientosKondorTotal !=null 
				&& lanzamientosKondorTotal.size()!= 0){

			maxResults = paginationData.getMaxResults()*paginationData.getActivePage()+1;
			if (lanzamientosKondorTotal.size() < maxResults){
				maxResults = lanzamientosKondorTotal.size(); 
			}
			setDataTableList(lanzamientosKondorTotal.subList(paginationData.getFirstResult(),maxResults ));
		}else{
			setDataTableList(null);
		}

		
		
	}

	@Override
	public void setDataTableList(List<?> dataTableList) {
		// TODO Auto-generated method stub
		this.lanzamientoIntegracionPantalla.setLanzamientoIntKondorAgrupList((List<VistaBuzonDeri>)dataTableList);
	}

	public List<VistaBuzonDeri> getLanzamientosKondorTotal() {
		return lanzamientosKondorTotal;
	}

	public void setLanzamientosKondorTotal(List<VistaBuzonDeri> lanzamientosKondorTotal) {
		this.lanzamientosKondorTotal = lanzamientosKondorTotal;
	}


	private HashSet<VistaBuzonDeri> listasSeleccionadas = new HashSet<VistaBuzonDeri>();

	public Boolean getSelectedRow(){
		return listasSeleccionadas.contains(lanzamientoIntegracionPantalla.getLanzamientoIntKondorAgrupSel());
	}

	public void setSelectedRow(Boolean selected){
		if(selected){
			listasSeleccionadas.add(lanzamientoIntegracionPantalla.getLanzamientoIntKondorAgrupSel());
		}
		else{
			listasSeleccionadas.remove(lanzamientoIntegracionPantalla.getLanzamientoIntKondorAgrupSel());
//			listaSuscripcionesPantalla.setSeleccionTotal(false);
		}
	}
	
	public void seleccionarLista(){

	}

	public void seleccionarTodos(){
		listasSeleccionadas.clear();
		listasSeleccionadas.addAll(lanzamientosKondorTotal);
	}

	public void deseleccionarTodos(){
		listasSeleccionadas.clear();
	}

	public void recuperar(){
		
	}

	public void desintegrar(){

		if (listasSeleccionadas!=null && !listasSeleccionadas.isEmpty()){
			//Actualizamos la tabla
			lanzamientoIntegracionBo.actualizarSeleccionadosAgrupados(listasSeleccionadas, 9L);		
			/** Avisamos de que el lanzamiento se ha realizado con éxito */
			statusMessages.add(StatusMessage.Severity.INFO, "#{messages['lanzamiento.registros']}");
			refrescarPantalla();
		}else{
			statusMessages.add(StatusMessage.Severity.INFO, "#{messages['lanzamiento.sin.registros']}");
		}
	}

	public String obtenerDescripcion(BuzonDeri buzon){
		return lanzamientoIntegracionBo.obtenerDescripcion(buzon);
	}

	private void refrescarPantalla() {
		// TODO Auto-generated method stub
		 listasSeleccionadas.clear();
		 paginationData.setFirstResult(0);
		 if (isBmn()){
//			 newFormInstanceBMN();
		 }else if(isMigracion()){
//			 newFormInstanceMigra();
		 }else{
			 newFormInstance();		
		 }
	}

	public boolean isBmn() {
		return bmn;
	}

	public void setBmn(boolean bmn) {
		this.bmn = bmn;
	}
	
	public boolean isMigracion() {
		return migracion;
	}

	public void setMigracion(boolean migracion) {
		this.migracion = migracion;
	}

	public void verDetalle(){
		setBuzonSeleccionado(lanzamientoIntegracionPantalla.getLanzamientoIntKondorAgrupSel().getBuzon());
	}

	public BuzonDeri getBuzonSeleccionado() {
		return buzonSeleccionado;
	}

	public void setBuzonSeleccionado(BuzonDeri buzonSeleccionado) {
		this.buzonSeleccionado = buzonSeleccionado;
	}

	/**
	 * Miramos si la operacion asociada al buzon tiene un estado que nos permita su integracion
	 * 
	 * @param buzon
	 * @return
	 */
	public Boolean esIntegrable(VistaBuzonDeri buzon){
		return lanzamientoIntegracionBo.esIntegrable(buzon.getDealType(),buzon.getDealNumber());
	}
	
	public String getRowClasses(){
		StringBuilder builder = new StringBuilder();
		int i=0;
		for (VistaBuzonDeri vl : lanzamientoIntegracionPantalla.getLanzamientoIntKondorAgrupList()) {
			if(i>0){
				builder.append(",");
			}
			
			if (!vl.isIntegrable()){
					builder.append("redRow");	

			}else{
					
				if (vl.getCodigoNaranja() > 0){
					
					builder.append("naranjaRow");
				
				}else{
				
					if(i%2==0){
						builder.append("oddRow");
					}
					else{
						builder.append("evenRow");
					}
				}
			}
			
			i++;
		}
		return builder.toString();
	}

}
