package com.atosorigin.deri.kondor.lanzamiento.action;

import java.util.Date;
import java.util.HashSet;
import java.util.List;

import org.jboss.seam.ScopeType;
import org.jboss.seam.annotations.In;
import org.jboss.seam.annotations.Name;
import org.jboss.seam.annotations.Scope;
import org.jboss.seam.core.Conversation;
import org.jboss.seam.international.StatusMessage;
import org.jboss.seam.international.StatusMessage.Severity;

import com.atosorigin.common.action.PaginatedListAction;
import com.atosorigin.common.action.PaginationData;
import com.atosorigin.common.constantes.Constantes;
import com.atosorigin.common.formvalidator.FormValidator;
import com.atosorigin.common.utils.GenericUtils;
import com.atosorigin.deri.kondor.lanzamiento.screen.LanzamientoIntegracionPantalla;
import com.atosorigin.deri.kondor.lanzamientointegracion.business.LanzamientoIntegracionBo;
import com.atosorigin.deri.model.gestionoperaciones.ConfOperacion;
import com.atosorigin.deri.model.gestionoperaciones.VistaOperacion;
import com.atosorigin.deri.model.kondor.BuzonDeri;
import com.atosorigin.deri.model.kondor.VistaBuzonDeri;
import com.atosorigin.deri.model.murex.BuzonLogInt;

/**
 * Clase action listener para el caso de uso de lanzamiento de integración.
 */
@Name("lanzamientoIntegracionRecuperarAction")
@Scope(ScopeType.CONVERSATION)
@FormValidator
public class LanzamientoIntegracionRecuperarAction extends PaginatedListAction {

	/**
	 * Inyección del bean de Spring "lanzamientoIntegracionBo" que contiene los métodos de negocio
	 * para el caso de uso lanzamiento integración.
	 */
	@In("#{lanzamientoIntegracionBo}")
	protected LanzamientoIntegracionBo lanzamientoIntegracionBo;
	
	/**
	 * Inyección del screen bean que contiene los datos de pantalla del caso de uso
	 * lanzamiento de integracion.
	 */
	@In(create=true)
	protected LanzamientoIntegracionPantalla lanzamientoIntegracionPantalla;
	
	@In(required = false, value = "buzonDeriSeleccionado")
	protected BuzonDeri buzonSeleccionado;
	
	protected  List<BuzonDeri>  lanzamientosKondorTotal;
	private boolean bmn = false;
	private boolean migracion = false;
	
	private int maxSelected;
	
	/** Carga los valores de inicialización del formulario */ 
	public void newFormInstance() {
		if (isPrimerAcceso()){
			informarParametrosDefecto();
		}
		setPrimerAcceso(false);
		if (GenericUtils.isNullOrBlank(buzonSeleccionado)){
			lanzamientosKondorTotal = 
				getRegistrosDescartados(lanzamientoIntegracionPantalla.getDealNumberDesde(),
						lanzamientoIntegracionPantalla.getDealNumberHasta(),
						lanzamientoIntegracionPantalla.getFechaDesde(),
						lanzamientoIntegracionPantalla.getFechaHasta(),paginationData);	
		}else{
			lanzamientosKondorTotal = getRegistroSeleccionado(buzonSeleccionado);
		}
		
		this.setBmn(false);
		this.setMigracion(false);
		refrescarLista();
	}
	
	public void buscar(){
		if (GenericUtils.isNullOrBlank(buzonSeleccionado)){
			lanzamientosKondorTotal = 
				getRegistrosDescartados(lanzamientoIntegracionPantalla.getDealNumberDesde(),
						lanzamientoIntegracionPantalla.getDealNumberHasta(),
						lanzamientoIntegracionPantalla.getFechaDesde(),
						lanzamientoIntegracionPantalla.getFechaHasta(),paginationData);	
		}else{
			lanzamientosKondorTotal = getRegistroSeleccionado(buzonSeleccionado);
		}
		
		this.setBmn(false);
		this.setMigracion(false);
		refrescarLista();
	}
	
	private void informarParametrosDefecto() {
		Integer numdias = lanzamientoIntegracionBo.obtenerNumDiasARecuperar();
		Date fechamis = lanzamientoIntegracionBo.getFechaDeri();
		Date fechadesde = GenericUtils.ajustarFecha(fechamis, -numdias);
		lanzamientoIntegracionPantalla.setFechaDesde(fechadesde);
		lanzamientoIntegracionPantalla.setFechaHasta(fechamis);
		lanzamientoIntegracionPantalla.setDealNumberDesde(null);
		lanzamientoIntegracionPantalla.setDealNumberHasta(null);
		
	}

	public boolean buscarValidator() {
		if (GenericUtils.isNullOrBlank(lanzamientoIntegracionPantalla.getDealNumberDesde()) &&
			GenericUtils.isNullOrBlank(lanzamientoIntegracionPantalla.getDealNumberHasta()) &&
			GenericUtils.isNullOrBlank(lanzamientoIntegracionPantalla.getFechaDesde()) && 
			GenericUtils.isNullOrBlank(lanzamientoIntegracionPantalla.getFechaHasta())){
			
			statusMessages.add(StatusMessage.Severity.ERROR, "#{messages['lanzamiento.integracion.filtro']}");
			return false;
		}else{
			return true;	
		}
		
		
		
	}
	
	public void newFormInstanceBMN() {
		lanzamientosKondorTotal = getRegistrosPendientesBMN();
		this.setBmn(true);
		this.setMigracion(false);
		refrescarLista();
	}

	public void newFormInstanceMigra() {
		this.lanzamientoIntegracionPantalla.setFecha(new Date()); // Cargamos con la fecha actual
		this.lanzamientoIntegracionPantalla.setOperaciones(getOperacionesPendientesMigra()); // Cargamos número operaciones
		lanzamientosKondorTotal = getRegistrosPendientesMigra();
		this.setBmn(false);
		this.setMigracion(true);
		refrescarLista();
	}

	/** Lanza el proceso Kondor + insertando un solo evento del tipo 4001 */
	public void actualizarAgenda(){
		HashSet<BuzonDeri> listasSelecIntegrables = new HashSet<BuzonDeri>();
		boolean todasIntegrables = true;
		if (listasSeleccionadas!=null && !listasSeleccionadas.isEmpty()){

			
		
			for (BuzonDeri buzon : listasSeleccionadas) {
				if (buzon.isIntegrable()){
					listasSelecIntegrables.add(buzon);
				}else{
					todasIntegrables=false;	
				}
			}
			
		}
		
		if (!todasIntegrables){
			statusMessages.add(StatusMessage.Severity.INFO, "#{messages['aceptar.nointegradas']}");
		}
		
		if (listasSelecIntegrables!=null && !listasSelecIntegrables.isEmpty()){	
//		if (listasSeleccionadas!=null && !listasSeleccionadas.isEmpty()){
			//Actualizamos la tabla
			lanzamientoIntegracionBo.actualizarSeleccionados(listasSelecIntegrables,4L);
			statusMessages.add(StatusMessage.Severity.INFO, "#{messages['lanzamiento.registros']}");
			
			/** Comprueba si hay eventos 4001 tratados en la agenda */
			if(!lanzamientoIntegracionBo.isAvisosCodigoEvento4001()){
				/** Buscamos número de evento e insertamos nuevo registro */
				if (lanzamientoIntegracionBo.updateAgenda()){
				
					/** Avisamos de que el lanzamiento se ha realizado con éxito */
					statusMessages.add(StatusMessage.Severity.INFO, "#{messages['aceptar.lanzamientorealizado']}");
				}else{
					statusMessages.add(StatusMessage.Severity.ERROR, "#{messages['aceptar.eventoError']}");
				}
		
			} else {
				/** Avisamos de que hay un lanzamiento pendiente de procesar */
				statusMessages.add(StatusMessage.Severity.ERROR, "#{messages['aceptar.lanzamientopendiente.error']}");
			}
			refrescarPantalla();
		}else{
			statusMessages.add(StatusMessage.Severity.INFO, "#{messages['lanzamiento.sin.registros']}");
		}

		}
	
	/** Recupera el número de operaciones pendientes */
	private Integer getOperacionesPendientes(){
		return lanzamientoIntegracionBo.getOperacionesPendientes();
	}

	private Integer getOperacionesPendientesBMN(){
		return lanzamientoIntegracionBo.getOperacionesPendientesBMN();
	}

	private Integer getOperacionesPendientesMigra(){
		return lanzamientoIntegracionBo.getOperacionesPendientesMigra();
	}

	private List<BuzonDeri> getRegistrosDescartados(Long dealNumberDesde,
			Long dealNumberHasta, Date fechaDesde, Date fechaHasta, PaginationData paginationData) {
		List<BuzonDeri> lista =
			lanzamientoIntegracionBo.getRegistrosDescartados(dealNumberDesde,
					dealNumberHasta, fechaDesde, fechaHasta, paginationData);
		for (BuzonDeri buzonDeri : lista) {
			buzonDeri.setIntegrable(true);
			buzonDeri.setDescripcionProductoTgr(obtenerProductoTGR(buzonDeri));
		}
		return lista;
	}

	private List<BuzonDeri> getRegistrosPendientes(){
		List<BuzonDeri> lista =lanzamientoIntegracionBo.getRegistrosPendientes();
		for (BuzonDeri buzonDeri : lista) {
			buzonDeri.setIntegrable(esIntegrable(buzonDeri));
			buzonDeri.setDescripcionProductoTgr(obtenerProductoTGR(buzonDeri));
		}
		return lista;
//		return lanzamientoIntegracionBo.getRegistrosPendientes();
	}
	
	private List<BuzonDeri> getRegistroSeleccionado(BuzonDeri buzonSeleccionado) {
//		return lanzamientoIntegracionBo.getRegistrosSeleccionados(buzonSeleccionado);
		List<BuzonDeri> lista =lanzamientoIntegracionBo.getRegistrosSeleccionados(buzonSeleccionado);
		for (BuzonDeri buzonDeri : lista) {
			buzonDeri.setIntegrable(esIntegrable(buzonDeri));
			buzonDeri.setDescripcionProductoTgr(obtenerProductoTGR(buzonDeri));
		}
		return lista;
	}
	
	private List<BuzonDeri> getRegistrosPendientesBMN(){
//		return lanzamientoIntegracionBo.getRegistrosPendientesBMN();
		List<BuzonDeri> lista =lanzamientoIntegracionBo.getRegistrosPendientesBMN();
		for (BuzonDeri buzonDeri : lista) {
			buzonDeri.setIntegrable(esIntegrable(buzonDeri));
			buzonDeri.setDescripcionProductoTgr(obtenerProductoTGR(buzonDeri));
		}
		return lista;
	}

	private List<BuzonDeri> getRegistrosPendientesMigra(){
//		return lanzamientoIntegracionBo.getRegistrosPendientesMigra();
		List<BuzonDeri> lista =lanzamientoIntegracionBo.getRegistrosPendientesMigra();
		for (BuzonDeri buzonDeri : lista) {
			buzonDeri.setIntegrable(esIntegrable(buzonDeri));
			buzonDeri.setDescripcionProductoTgr(obtenerProductoTGR(buzonDeri));
		}
		return lista;
	}

	
	@Override
	public List<BuzonDeri> getDataTableList() {
		// TODO Auto-generated method stub
		return 	this.lanzamientoIntegracionPantalla.getLanzamientoIntKondorList();
	}

	@Override
	public void refrescarListaExcel() {
		// TODO Auto-generated method stub
		setExportExcel(true);
		lanzamientosKondorTotal = 
			getRegistrosDescartados(lanzamientoIntegracionPantalla.getDealNumberDesde(),
					lanzamientoIntegracionPantalla.getDealNumberHasta(),
					lanzamientoIntegracionPantalla.getFechaDesde(),
					lanzamientoIntegracionPantalla.getFechaHasta(),paginationData.getPaginationDataForExcel());	


		setDataTableList(lanzamientosKondorTotal);
	}

	@Override
	protected void refreshListInternal() {
		// TODO Auto-generated method stub
		setExportExcel(false);
		
		lanzamientosKondorTotal = 
			getRegistrosDescartados(lanzamientoIntegracionPantalla.getDealNumberDesde(),
					lanzamientoIntegracionPantalla.getDealNumberHasta(),
					lanzamientoIntegracionPantalla.getFechaDesde(),
					lanzamientoIntegracionPantalla.getFechaHasta(),paginationData);	

		
		setDataTableList(lanzamientosKondorTotal);
		
	}

	@Override
	public void setDataTableList(List<?> dataTableList) {
		// TODO Auto-generated method stub
		this.lanzamientoIntegracionPantalla.setLanzamientoIntKondorList((List<BuzonDeri>)dataTableList);
	}

	public List<BuzonDeri> getLanzamientosKondorTotal() {
		return lanzamientosKondorTotal;
	}

	public void setLanzamientosKondorTotal(List<BuzonDeri> lanzamientosKondorTotal) {
		this.lanzamientosKondorTotal = lanzamientosKondorTotal;
	}


	private HashSet<BuzonDeri> listasSeleccionadas = new HashSet<BuzonDeri>();

	public Boolean getSelectedRow(){
		return listasSeleccionadas.contains(lanzamientoIntegracionPantalla.getLanzamientoIntKondorSel());
	}

	public void setSelectedRow(Boolean selected){
		if(selected){
			listasSeleccionadas.add(lanzamientoIntegracionPantalla.getLanzamientoIntKondorSel());
		}
		else{
			listasSeleccionadas.remove(lanzamientoIntegracionPantalla.getLanzamientoIntKondorSel());
//			listaSuscripcionesPantalla.setSeleccionTotal(false);
		}
	}
	
	public void seleccionarLista(){

	}

	public void seleccionarTodos(){
//		listasSeleccionadas.clear();
//		listasSeleccionadas.addAll(lanzamientosKondorTotal);
		
		
		int tmpMaxResults = paginationData.getMaxResults();
		int tmpFirstResult = paginationData.getFirstResult();
		
		paginationData.setMaxResults(501);
		paginationData.setFirstResult(0);
		List<BuzonDeri> buzonesList = getRegistrosDescartados(lanzamientoIntegracionPantalla.getDealNumberDesde(),
				lanzamientoIntegracionPantalla.getDealNumberHasta(),
				lanzamientoIntegracionPantalla.getFechaDesde(),
				lanzamientoIntegracionPantalla.getFechaHasta(),paginationData);	
		
		int iteraciones = buzonesList.size();
		if(buzonesList.size() > 500){
			statusMessages.add(Severity.INFO, "#{messages['mantoper.seleccionados.primeros.cincuenta']}");
			iteraciones = 500;
			tmpFirstResult=0;
			maxSelected = 499;
		} else {
			maxSelected = buzonesList.size()-1;
		}
		listasSeleccionadas.clear(); 
		for(int i = 0; i<iteraciones; i++){
			listasSeleccionadas.add(buzonesList.get(i));
		}
		paginationData.setMaxResults(tmpMaxResults);
		paginationData.setFirstResult(tmpFirstResult);

	}

	public void deseleccionarTodos(){
		listasSeleccionadas.clear();
		maxSelected = 0;
	}

	public String obtenerDescripcion(BuzonDeri buzon){
		return lanzamientoIntegracionBo.obtenerDescripcion(buzon);
	}

	private void refrescarPantalla() {
		// TODO Auto-generated method stub
		 listasSeleccionadas.clear();
		 paginationData.setFirstResult(0);
		 if (isBmn()){
			 newFormInstanceBMN();
		 }else if(isMigracion()){
			 newFormInstanceMigra();
		 }else{
			 newFormInstance();		
		 }
	}

	public boolean isBmn() {
		return bmn;
	}

	public void setBmn(boolean bmn) {
		this.bmn = bmn;
	}
	
	public boolean isMigracion() {
		return migracion;
	}

	public void setMigracion(boolean migracion) {
		this.migracion = migracion;
	}

	public void salir(){
		Conversation conversacion = Conversation.instance();
		//Volvemos a la anterior conversación
		if(conversacion.isNested()){
			conversacion.redirectToParent();
		} else {
			redirectToURL("/home.seam");
			conversacion.endAndRedirect();
		}
	}

	
	public BuzonDeri getBuzonSeleccionado() {
		return buzonSeleccionado;
	}

	public void setBuzonSeleccionado(BuzonDeri buzonSeleccionado) {
		this.buzonSeleccionado = buzonSeleccionado;
	}
	
	public Boolean esIntegrable(BuzonDeri buzon){
		return lanzamientoIntegracionBo.esIntegrable(buzon.getId().getDealType(),buzon.getId().getDealNumber());
	}
	
	public String obtenerProductoTGR(BuzonDeri buzon){
		return lanzamientoIntegracionBo.obtenerProductoTGR(buzon);	
	}
	
	
	public String getRowClasses(){
		StringBuilder builder = new StringBuilder();
		int i=0;
		for (BuzonDeri vl : lanzamientoIntegracionPantalla.getLanzamientoIntKondorList()) {
			if(i>0){
				builder.append(",");
			}
			
			if (!vl.isIntegrable()){
					builder.append("redRow");	

			}else{
					
					if(i%2==0){
						builder.append("oddRow");
					}
					else{
						builder.append("evenRow");
					}
			}
			
			i++;
		}
		return builder.toString();
	}

	public void recuperar(){
		if (listasSeleccionadas!=null && !listasSeleccionadas.isEmpty()){

			//Actualizamos la tabla
			lanzamientoIntegracionBo.recuperarSeleccionados(listasSeleccionadas,0L);
			statusMessages.add(StatusMessage.Severity.INFO, "#{messages['lanzamiento.registros']}");
			refrescarPantalla();
		}else{
			statusMessages.add(StatusMessage.Severity.INFO, "#{messages['lanzamiento.sin.registros']}");
			
		}
		
	}
	
	/**
	 * Autorrellena fecha hasta con el valor introducido en fecha desde
	 */
	public void rellenarFechaHasta(){
		
		if(!GenericUtils.isNullOrBlank(lanzamientoIntegracionPantalla.getFechaDesde())){
			lanzamientoIntegracionPantalla.setFechaHasta(lanzamientoIntegracionPantalla.getFechaDesde());
		}
	}

	/**
	 * Autorrellena deal number hasta con el valor introducido en deal number desde
	 */
	public void rellenarDealNumberHasta(){
		
		if(!GenericUtils.isNullOrBlank(lanzamientoIntegracionPantalla.getDealNumberDesde())){
			lanzamientoIntegracionPantalla.setDealNumberHasta(lanzamientoIntegracionPantalla.getDealNumberDesde());
		}
	}

	public int getMaxSelected() {
		return maxSelected;
	}

	public void setMaxSelected(int maxSelected) {
		this.maxSelected = maxSelected;
	}

	public HashSet<BuzonDeri> getListasSeleccionadas() {
		return listasSeleccionadas;
	}

	public void setListasSeleccionadas(HashSet<BuzonDeri> listasSeleccionadas) {
		this.listasSeleccionadas = listasSeleccionadas;
	}
	
}
