package com.atosorigin.deri.kondor.lanzamiento.screen;

import java.util.Date;
import java.util.List;

import org.jboss.seam.ScopeType;
import org.jboss.seam.annotations.Name;
import org.jboss.seam.annotations.Out;
import org.jboss.seam.annotations.Scope;
import org.jboss.seam.annotations.datamodel.DataModel;
import org.jboss.seam.annotations.datamodel.DataModelSelection;

import com.atosorigin.deri.model.kondor.BuzonDeri;
import com.atosorigin.deri.model.kondor.VistaBuzonDeri;
import com.atosorigin.deri.model.murex.VistaBuzonLogInt;

/**
 * Contiene los datos de pantalla necesarios para el caso de uso lanzamiento de integración.
 */
@Name("lanzamientoIntegracionPantalla")
@Scope(ScopeType.CONVERSATION)
public class LanzamientoIntegracionPantalla {

	protected Date fecha;
	protected Integer operaciones;
	
	protected Long dealNumberDesde;
	protected Long dealNumberHasta;
	protected Date fechaDesde;
	protected Date fechaHasta;
	
	/** Lista de datos para el grid. */
	@DataModel(value ="lanzamientoIntKondor")
	protected List<BuzonDeri> lanzamientoIntKondorList;
	
	/** Tipo de documento seleccionado en el grid */
	@DataModelSelection(value ="lanzamientoIntKondor")
    @Out(required=false)
    protected BuzonDeri lanzamientoIntKondorSel;	
	
	/** Lista de datos para el grid. */
	@DataModel(value ="lanzamientoIntKondorAgrup")
	protected List<VistaBuzonDeri> lanzamientoIntKondorAgrupList;
	
	/** Tipo de documento seleccionado en el grid */
	@DataModelSelection(value ="lanzamientoIntKondorAgrup")
    @Out(required=false)
    protected VistaBuzonDeri lanzamientoIntKondorAgrupSel;	
	
	public Date getFecha() {
		return fecha;
	}
	public Integer getOperaciones() {
		return operaciones;
	}
	public void setFecha(Date fecha) {
		this.fecha = fecha;
	}
	public void setOperaciones(Integer operaciones) {
		this.operaciones = operaciones;
	}
	public List<BuzonDeri> getLanzamientoIntKondorList() {
		return lanzamientoIntKondorList;
	}
	public void setLanzamientoIntKondorList(List<BuzonDeri> lanzamientoIntKondorList) {
		this.lanzamientoIntKondorList = lanzamientoIntKondorList;
	}
	public BuzonDeri getLanzamientoIntKondorSel() {
		return lanzamientoIntKondorSel;
	}
	public void setLanzamientoIntKondorSel(BuzonDeri lanzamientoIntKondorSel) {
		this.lanzamientoIntKondorSel = lanzamientoIntKondorSel;
	}
	public List<VistaBuzonDeri> getLanzamientoIntKondorAgrupList() {
		return lanzamientoIntKondorAgrupList;
	}
	public void setLanzamientoIntKondorAgrupList(
			List<VistaBuzonDeri> lanzamientoIntKondorAgrupList) {
		this.lanzamientoIntKondorAgrupList = lanzamientoIntKondorAgrupList;
	}
	public VistaBuzonDeri getLanzamientoIntKondorAgrupSel() {
		return lanzamientoIntKondorAgrupSel;
	}
	public void setLanzamientoIntKondorAgrupSel(
			VistaBuzonDeri lanzamientoIntKondorAgrupSel) {
		this.lanzamientoIntKondorAgrupSel = lanzamientoIntKondorAgrupSel;
	}
	public Long getDealNumberDesde() {
		return dealNumberDesde;
	}
	public void setDealNumberDesde(Long dealNumberDesde) {
		this.dealNumberDesde = dealNumberDesde;
	}
	public Long getDealNumberHasta() {
		return dealNumberHasta;
	}
	public void setDealNumberHasta(Long dealNumberHasta) {
		this.dealNumberHasta = dealNumberHasta;
	}
	public Date getFechaDesde() {
		return fechaDesde;
	}
	public void setFechaDesde(Date fechaDesde) {
		this.fechaDesde = fechaDesde;
	}
	public Date getFechaHasta() {
		return fechaHasta;
	}
	public void setFechaHasta(Date fechaHasta) {
		this.fechaHasta = fechaHasta;
	}
	
}
