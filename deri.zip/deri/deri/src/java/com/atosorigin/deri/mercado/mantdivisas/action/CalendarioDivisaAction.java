package com.atosorigin.deri.mercado.mantdivisas.action;

import java.util.Calendar;
import java.util.Collections;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.jboss.seam.ScopeType;
import org.jboss.seam.annotations.Factory;
import org.jboss.seam.annotations.In;
import org.jboss.seam.annotations.Name;
import org.jboss.seam.annotations.Out;
import org.jboss.seam.annotations.Scope;
import org.jboss.seam.annotations.datamodel.DataModel;
import org.jboss.seam.annotations.datamodel.DataModelSelection;
import org.jboss.seam.international.StatusMessage.Severity;

import com.atosorigin.common.action.PaginatedListAction;
import com.atosorigin.common.utils.GenericUtils;
import com.atosorigin.deri.mercado.mantdivisas.screen.CalendarioDivisaDataModel;
import com.atosorigin.deri.model.parametrizacion.CalendarioDivisa;
import com.atosorigin.deri.model.parametrizacion.CalendarioDivisaId;
import com.atosorigin.deri.model.parametrizacion.Divisa;
import com.atosorigin.deri.parametrizacion.calendariodivisa.CalendarioDivisaBo;

@Name("calendarioDivisaAction")
@Scope(ScopeType.CONVERSATION)
/**
 * Clase action listener para el caso de uso de calendario de divisas.
 */
public class CalendarioDivisaAction extends PaginatedListAction {

	
	
	@DataModel(value = "listaDtCalendarioDivisa")
	protected List<CalendarioDivisa> calendarioDivisaList;

	@DataModelSelection
	protected CalendarioDivisa calendarioDivisaActual;

	/**
	 * Inyección del bean de Spring "calendarioDivisaBo" que contiene los
	 * métodos de negocio para el caso de uso calendario de divisas.
	 */
	@In("#{calendarioDivisaBo}")
	protected CalendarioDivisaBo calendarioDivisaBo;

	@Out(required = false, value = "divisaCalendarDataModel")
	private CalendarioDivisaDataModel divisaCalendarDataModel;
	
	private List<CalendarioDivisa> listaFestivos;

	@Factory("divisaCalendarDataModel")
	public void initDataModel() {
		divisaCalendarDataModel = new CalendarioDivisaDataModel(){

			@Override
			protected boolean esFestivoDivisa(Date fecha, Divisa divisa) {
				CalendarioDivisa calendarioDivisa = newCalendarioDivisa(divisa, fecha);
				return esFechaFestiva(calendarioDivisa);
			}
			
		};
		setDivisas();
		/* Recuperamos aquellos días que son festivos */
		listaFestivos = calendarioDivisaBo
				.buscarCalendarioDivisas(divisaCalendarDataModel.getFecha(),
						divisaModif,
						divisaConsulta);
		if (listaFestivos == null) {
			listaFestivos = Collections.EMPTY_LIST;
		}
	}

	private Set<CalendarioDivisa> fechasQuitadas = new HashSet<CalendarioDivisa>();
	public Set<CalendarioDivisa> getFechasQuitadas() {
		return fechasQuitadas;
	}

	public void setFechasQuitadas(Set<CalendarioDivisa> fechasQuitadas) {
		this.fechasQuitadas = fechasQuitadas;
	}

	public Set<CalendarioDivisa> getFechasPuestas() {
		return fechasPuestas;
	}

	public void setFechasPuestas(Set<CalendarioDivisa> fechasPuestas) {
		this.fechasPuestas = fechasPuestas;
	}

	private Set<CalendarioDivisa> fechasPuestas = new HashSet<CalendarioDivisa>();

	private Divisa divisaModif;
	
	private Divisa divisaConsulta;

	
	public Divisa getDivisaModif() {
		return divisaModif;
	}

	public void setDivisaModif(Divisa divisaModif) {
		this.divisaModif = divisaModif;
	}

	public Divisa getDivisaConsulta() {
		return divisaConsulta;
	}

	public void setDivisaConsulta(Divisa divisaConsulta) {
		this.divisaConsulta = divisaConsulta;
	}

	/**
	 * Función que recupera de bbdd los días festivos para las divisas
	 * seleccionadas en los comboboxes de la pantalla.
	 */
	public void buscarFestivosDivisas() {
		if(!GenericUtils.isNullOrBlank(divisaModif) && !GenericUtils.isNullOrBlank(divisaConsulta)){
			statusMessages.add(Severity.INFO, "#{messages['info.calendar.ambasFechas']}");
		}
		divisaCalendarDataModel=null;
	}

	public String guardar() {
		// TODO Implementar
		calendarioDivisaBo.actualizarFechas(fechasPuestas, fechasQuitadas);
		return "success";
	}

	/**
	 * Función que busca en bbdd los días festivos para el mes seleccionado en
	 * pantalla de todas las divisas
	 */
	public void buscarFestivosMes() {
		setDivisas();
		/* Recuperamos aquellos días que son festivos de todas las divisas */
		this.calendarioDivisaList = calendarioDivisaBo.buscarCalendarioFestivosMes(divisaCalendarDataModel.getFecha(), paginationData);
	}

	public List<?> getDataTableList() {
		return this.calendarioDivisaList;
	}

	@SuppressWarnings("unchecked")
	public void setDataTableList(List<?> dataTableList) {
		this.calendarioDivisaList = ((List<CalendarioDivisa>) dataTableList);
	}

	public void changeMonth() {
		log.info(divisaCalendarDataModel.getFecha());
		divisaCalendarDataModel=null;
		checkFechasMessages();
	}

	/**
	 * Método que nos indica si la fecha introducida 
	 * se trata de un dia entre el Lunes y el Viernes
	 * 
	 * @param currentCalendarDate
	 * @return
	 */
	public boolean esDiario(Date currentCalendarDate){
		Calendar gc = GregorianCalendar.getInstance();
		gc.setTime(currentCalendarDate);
		boolean retorno = true;
		if( gc.get(GregorianCalendar.DAY_OF_WEEK) == GregorianCalendar.SUNDAY || gc.get(GregorianCalendar.DAY_OF_WEEK) == GregorianCalendar.SATURDAY){
			retorno = false;
			statusMessages.add(Severity.ERROR, "#{messages['error.festivo.finde']}");
		}
		return retorno;
	}
	
	
	public void onClick() {
		if (divisaModif != null) {
			
			setDivisas();
			Date currentCalendarDate = (Date) divisaCalendarDataModel
					.getFecha();
			if(esDiario(currentCalendarDate)){
				CalendarioDivisa cal = newCalendarioDivisa(divisaModif, currentCalendarDate);
	
				if (esFechaFestiva(cal)) {
					if (listaFestivos.contains(cal)) {
						fechasQuitadas.add(cal);
					}
					if (fechasPuestas.contains(cal)) {
						fechasPuestas.remove(cal);
					}
				} else {
					if (fechasQuitadas.contains(cal)) {
						fechasQuitadas.remove(cal);
					}
					if (!fechasPuestas.contains(cal) && !listaFestivos.contains(cal)) {
						fechasPuestas.add(cal);
					}
				}
			
			}
			divisaCalendarDataModel.compruebaEstilo(currentCalendarDate);
		}
		checkFechasMessages();
	}

	private boolean esFechaFestiva(CalendarioDivisa cal) {
		return (listaFestivos.contains(cal) && !fechasQuitadas.contains(cal)) || fechasPuestas.contains(cal);
	}
	public void deshacer(){
		fechasPuestas.clear();
		fechasQuitadas.clear();
		checkFechasMessages();
		divisaCalendarDataModel=null;
	}

	public  void checkFechasMessages() {
		if(fechasPuestas.size()>0){
			statusMessages.add(Severity.INFO, "#{messages['info.calendar.fechas.puestas']}", new Object[]{});
		}
		if(fechasQuitadas.size()>0){
			statusMessages.add(Severity.INFO, "#{messages['info.calendar.fechas.quitadas']}", new Object[]{});
		}
	}

	private CalendarioDivisa newCalendarioDivisa(Divisa divisa, Date currentCalendarDate) {
		CalendarioDivisa cal = new CalendarioDivisa(new CalendarioDivisaId(
				divisa,
				currentCalendarDate));
		return cal;
	}

	private void setDivisas() {
		if(divisaCalendarDataModel!=null){
			divisaCalendarDataModel.setDivisaConsulta(divisaConsulta);
			divisaCalendarDataModel.setDivisaModif(divisaModif);
			divisaCalendarDataModel.checkEnabled();
		}
	}

	@Override
	protected void refreshListInternal() {
		buscarFestivosMes();		
	}

	@Override
	public void refrescarListaExcel() {
		buscarFestivosMes();		
	}





}
