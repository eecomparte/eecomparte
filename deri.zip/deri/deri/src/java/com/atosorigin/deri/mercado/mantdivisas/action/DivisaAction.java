package com.atosorigin.deri.mercado.mantdivisas.action;

import org.jboss.seam.ScopeType;
import org.jboss.seam.annotations.In;
import org.jboss.seam.annotations.Name;
import org.jboss.seam.annotations.Scope;

import com.atosorigin.common.action.GenericAction;
import com.atosorigin.common.constantes.Constantes;
import com.atosorigin.common.formvalidator.FormValidator;
import com.atosorigin.common.utils.GenericUtils;
import com.atosorigin.deri.mercado.mantdivisas.screen.DivisaPantalla;
import com.atosorigin.deri.model.parametrizacion.Divisa;
import com.atosorigin.deri.parametrizacion.divisa.business.DivisaBo;

@Name("divisaAction")
@Scope(ScopeType.CONVERSATION)
@FormValidator
/**
 * Clase action listener para el caso de uso de mantenimiento de subyacentes.
 */
public class DivisaAction extends GenericAction {
	
	/**
	 * Inyección del bean de Spring "divisaBo" que contiene los métodos de negocio
	 * para el caso de uso mantenimiento de divisas.
	 */
	@In("#{divisaBo}")
	protected DivisaBo divisaBo;
	
	/**
	 * Inyección del screen bean que contiene los datos de pantalla del caso de uso
	 * mantenimiento de divisas.
	 */
	@In(create=true)
	protected DivisaPantalla divisaPantalla;
	
	/** Graba la divisa en la base de datos. */
	public String guardar() {
		
		Divisa divisaModificada = this.divisaPantalla.getDivisa();
		
		if(!GenericUtils.isNullOrBlank(divisaModificada)){
			
			/** Guardamos los valores seleccionados de Base Cálculo, Cotizable y Div.UME */
			divisaModificada.setBaseCalculo(Short.parseShort(this.divisaPantalla.getBaseCalc()));
			
			if(this.divisaPantalla.getEsCotizable()){
				divisaModificada.setDivisaMist(Constantes.DIVISA_COTIZABLE);
			} else {
				divisaModificada.setDivisaMist(null);
			}
			
			if(this.divisaPantalla.getEsDivUME()){
				divisaModificada.setIndicDivUme(Constantes.CONSTANTE_SI);
			} else {
				divisaModificada.setIndicDivUme(Constantes.CONSTANTE_NO);
			}
		}

		divisaBo.guardar(divisaModificada);
		return Constantes.CONSTANTE_SUCCESS;
	}

	/** Carga en el form la información de la divisa seleccionada en el combobox de Divisas */
	public void refrescarFormulario() {

		Divisa divisaSeleccionada = divisaBo.cargar(divisaPantalla.getDivisa().getId());
		divisaPantalla.setDivisa(divisaSeleccionada);
		
		/** Cargamos en el form los valores para base cálculo, cotizable y Div.Ume */
		if (GenericUtils.isNullOrBlank(divisaSeleccionada.getDivisaMist())){
			divisaPantalla.setEsCotizable(false); // Valor por defecto
		} else if(Constantes.DIVISA_COTIZABLE.equals(divisaSeleccionada.getDivisaMist())){
			divisaPantalla.setEsCotizable(true);
		}
		
		if (GenericUtils.isNullOrBlank(divisaSeleccionada.getIndicDivUme()) || Constantes.CONSTANTE_NO.equals(divisaSeleccionada.getIndicDivUme())){
			divisaPantalla.setEsDivUME(false);
		} else if (Constantes.CONSTANTE_SI.equals(divisaSeleccionada.getIndicDivUme())){
			divisaPantalla.setEsDivUME(true);
		}
		
		if (!GenericUtils.isNullOrBlank(divisaSeleccionada.getBaseCalculo())){
			divisaPantalla.setBaseCalc(divisaSeleccionada.getBaseCalculo().toString());
		} else {
			divisaPantalla.setBaseCalc(Constantes.DIVISA_BASECALC_360.toString()); // Valor por defecto
		}
	}
}
