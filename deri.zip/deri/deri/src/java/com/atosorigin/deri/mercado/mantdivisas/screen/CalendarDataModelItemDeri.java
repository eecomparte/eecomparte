package com.atosorigin.deri.mercado.mantdivisas.screen;

import org.richfaces.model.CalendarDataModelItem;

public class CalendarDataModelItemDeri implements CalendarDataModelItem {

	private Object data;
	private int day;
	private String styleClass;
	private Object toolTip;
	private boolean enabled = true;

	/*
	 * (non-Javadoc)
	 * @see org.richfaces.model.CalendarDataModelItem#getData()
	 */
	public Object getData() {
		return data;
	}

	/*
	 * (non-Javadoc)
	 * @see org.richfaces.model.CalendarDataModelItem#getDay()
	 */
	public int getDay() {
		return day;
	}

	/*
	 * (non-Javadoc)
	 * @see org.richfaces.model.CalendarDataModelItem#getStyleClass()
	 */
	public String getStyleClass() {
		return styleClass;
	}

	/*
	 * (non-Javadoc)
	 * @see org.richfaces.model.CalendarDataModelItem#getToolTip()
	 */
	public Object getToolTip() {
		return toolTip;
	}

	/*
	 * (non-Javadoc)
	 * @see org.richfaces.model.CalendarDataModelItem#hasToolTip()
	 */
	public boolean hasToolTip() {
		return getToolTip() != null;
	}

	/*
	 * (non-Javadoc)
	 * @see org.richfaces.model.CalendarDataModelItem#isEnabled()
	 */
	public boolean isEnabled() {
		return enabled;
	}

	public void setData(Object data) {
		this.data = data;
	}

	public void setStyleClass(String styleClass) {
		this.styleClass = styleClass;
	}

	public void setToolTip(Object toolTip) {
		this.toolTip = toolTip;
	}

	public void setEnabled(boolean enabled) {
		this.enabled = enabled;
	}

	public void setDay(int day) {
		this.day = day;
	}

	@Override
	public String toString() {
		return "CalendarDataModelItemDeri [data=" + data + ", day=" + day
				+ ", enabled=" + enabled + ", styleClass=" + styleClass
				+ ", toolTip=" + toolTip + "]";
	}

}
