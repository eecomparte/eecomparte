package com.atosorigin.deri.mercado.mantdivisas.screen;

import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.HashMap;

import org.richfaces.model.CalendarDataModel;
import org.richfaces.model.CalendarDataModelItem;

import com.atosorigin.common.utils.GenericUtils;
import com.atosorigin.deri.model.parametrizacion.Divisa;

/**
 * Contiene los datos de pantalla necesarios para el caso de uso calendario de divisas.
 */
public abstract  class CalendarioDivisaDataModel implements CalendarDataModel{

	
	private Divisa divisaModif;
	
	private Divisa divisaConsulta;
	
	protected Date fecha = new Date();
	
	
	private HashMap<Date, CalendarDataModelItemDeri> mapItems = new HashMap<Date, CalendarDataModelItemDeri>();

	
	CalendarDataModelItemDeri[] items=null;

	

	
	public Object getToolTip(Date arg0) {
		// TODO Auto-generated method stub
		return null;
	}
	
	public CalendarDataModelItem[] getData(Date[] arrayFechas) {
		if(items!=null){
			return items;
		}
		if (GenericUtils.isNullOrBlank(arrayFechas)) {
			return null;
		}
					
		items = new CalendarDataModelItemDeri[arrayFechas.length];
		mapItems.clear();
		
		for (int i = 0; i < arrayFechas.length; i++) {
			items[i] = crearItem(arrayFechas[i]);
			mapItems.put(arrayFechas[i], items[i]);
		}
			
		checkEnabled();
		return items;
	}
	
	
	public void checkEnabled(){
		if(items!=null){
			for (CalendarDataModelItemDeri item : items) {
				item.setEnabled((divisaModif!=null) && (divisaConsulta==null));
			}
		}
	}
	
	
	public void compruebaEstilo(Date date){
		CalendarDataModelItemDeri it = mapItems.get(date);
		if(it!=null){
			preparaEstilo(date, it);
		}
	}
	
	/** Lista de datos para el grid de festivos del mes. */
	
	
	public CalendarioDivisaDataModel() {
		/** Cargamos la pantalla con los valores por defecto */
		this.fecha=new Date();
		
		/** Inicializamos las listas de festivos, en principio vacía */
	}
	


	private CalendarDataModelItemDeri crearItem(Date fecha){
		
		  CalendarDataModelItemDeri item = new CalendarDataModelItemDeri();
	      Calendar c = GregorianCalendar.getInstance();
	      c.setTime(fecha);
	      item.setDay(c.get(Calendar.DAY_OF_MONTH));
	      
	      preparaEstilo(fecha, item, this.getDivisaModif(), this.getDivisaConsulta());
	      
	      return item;

	}
	private void preparaEstilo(Date fecha, CalendarDataModelItemDeri item){
	      preparaEstilo(fecha, item, this.getDivisaModif(), this.getDivisaConsulta());
	}

	private void preparaEstilo(Date fecha, CalendarDataModelItemDeri item,
			Divisa idDivisaModif, Divisa idDivisaConsul) {
		/** Si es fin de semana lo pintamos en verde */
	      if(esFinSemana(fecha)){
	    	  item.setStyleClass("diaFinSemana");
	      } else if(esFestivoDivisa(fecha, idDivisaModif) && esFestivoDivisa(fecha, idDivisaConsul)) {
	    	  /** Comprobamos si el día es festivo en alguna de las divisas */
	    	  item.setStyleClass("diaAmarillo"); /** Festivo en ambas divisas */
	      } else if(esFestivoDivisa(fecha, idDivisaModif)) { 
	    	  item.setStyleClass("diaRojo"); /** Festivo en divisa editable */
	      } else if(esFestivoDivisa(fecha, idDivisaConsul)){
	    	  item.setStyleClass("diaAzul"); /** Festivo en divisa consulta */
	      } else { /** Si no es festivo ni fin de semana*/ 
	    	  item.setStyleClass("diaNormal");
	      }
	}
	
	/** Función que comprueba si un día dado es Sábado o Domingo
	 * retorna true si es Sábado o Domingo, false en caso contrario */
	private boolean esFinSemana(Date fecha){
		
		boolean esFinSemana = false;
		Calendar cal = GregorianCalendar.getInstance();
		
		cal.setTime(fecha);
		int diaSemana = cal.get(GregorianCalendar.DAY_OF_WEEK);
		
		if(diaSemana == GregorianCalendar.SATURDAY || diaSemana == GregorianCalendar.SUNDAY){
			esFinSemana = true;
		}
		
		return esFinSemana;
		
	}
	
	/**
	 * Funcion que comprueba si una determinada fecha es festiva para una divisa concreta
	 * @param fecha Fecha de la que queremos saber si es festivo
	 * @param idDivisa Identificador de la divisa
	 * @return true si la fecha es festiva para la divisa
	 */
	protected abstract boolean esFestivoDivisa (Date fecha, Divisa idDivisa);

	public Divisa getDivisaModif() {
		return divisaModif;
	}

	public Divisa getDivisaConsulta() {
		return divisaConsulta;
	}

	public void setDivisaModif(Divisa divisaModif) {
		this.divisaModif = divisaModif;
	}

	public void setDivisaConsulta(Divisa divisaConsulta) {
		this.divisaConsulta = divisaConsulta;
	}

	public Date getFecha() {
		return fecha;
	}

	public void setFecha(Date fecha) {
		this.fecha = fecha;
	}




	


}
