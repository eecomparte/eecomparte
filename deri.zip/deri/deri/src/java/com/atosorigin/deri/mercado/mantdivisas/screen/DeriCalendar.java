package com.atosorigin.deri.mercado.mantdivisas.screen;

import java.util.Date;

import javax.faces.application.Application;
import javax.faces.context.FacesContext;

import org.jboss.seam.ScopeType;
import org.jboss.seam.annotations.Name;
import org.jboss.seam.annotations.Scope;
import org.richfaces.component.html.HtmlCalendar;

@Name("deriCalendar")
@Scope(ScopeType.EVENT)
public class DeriCalendar {

	protected HtmlCalendar calendar;
	protected Date currentDate;

	
	public DeriCalendar() {
		this.currentDate = new Date();
	}
	
	public DeriCalendar(Date currentDate){
		this.currentDate = currentDate;
		this.calendar = getCalendar();
	}

	public HtmlCalendar getCalendar() {
		FacesContext ctx = FacesContext.getCurrentInstance();
		Application app = ctx.getApplication();
		calendar = (HtmlCalendar)app.createComponent(HtmlCalendar.COMPONENT_TYPE);
		calendar.setCurrentDate(currentDate);
		calendar.getCalendar().setTime(currentDate);
		return calendar;
	}
	
	public void setCalendar(HtmlCalendar calendar) {
		this.calendar = calendar;
	}

	public Date getCurrentDate() {
		return currentDate;
	}

	public void setCurrentDate(Date currentDate) {
		this.currentDate = currentDate;
	}

	
}
