package com.atosorigin.deri.mercado.mantdivisas.screen;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

import org.jboss.seam.ScopeType;
import org.jboss.seam.annotations.Name;
import org.jboss.seam.annotations.Out;
import org.jboss.seam.annotations.Scope;

import com.atosorigin.common.constantes.Constantes;
import com.atosorigin.deri.model.parametrizacion.Divisa;

/**
 * Contiene los datos de pantalla necesarios para el caso de uso mantenimiento de divisas.
 */
@Name("divisaPantalla")
@Scope(ScopeType.CONVERSATION)
public class DivisaPantalla {
	
	@Out(value="divisa", required=false)
	protected Divisa divisa;
	protected Boolean esCotizable;
	protected Boolean esDivUME;
	protected List<BigDecimal> listaValores;
	protected String baseCalc;

	public DivisaPantalla(){
		/** Cargamos la pantalla con los valores por defecto */
		this.esCotizable = Boolean.FALSE;
		this.esDivUME = Boolean.TRUE;
		this.baseCalc = Constantes.DIVISA_BASECALC_360.toString();
		this.divisa = new Divisa(null,null,Constantes.DIVISA_BASECALC_360,null,Constantes.DIVISA_TIPO_B,Constantes.DIVISA_MARGEN_10,
				Constantes.DIVISA_MARGEN_5,Constantes.DIVISA_MARGEN_10,Constantes.DIVISA_MARGEN_5,Constantes.DIVISA_MARGEN_20,Constantes.DIVISA_MARGEN_10,
				Constantes.DIVISA_MARGEN_5,Constantes.DIVISA_MARGEN_20,Constantes.DIVISA_MARGEN_5,Constantes.DIVISA_MARGEN_20,Constantes.DIVISA_MARGEN_5,
				Constantes.DIVISA_MARGEN_20,Constantes.DIVISA_MARGEN_10,Constantes.DIVISA_MARGEN_5,null,Constantes.CONSTANTE_SI,null,null,null,null);
		this.listaValores = new ArrayList<BigDecimal>();
		this.listaValores.add(Constantes.DIVISA_MARGEN_5);
		this.listaValores.add(Constantes.DIVISA_MARGEN_10);
		this.listaValores.add(Constantes.DIVISA_MARGEN_20);
	}
	
	public Divisa getDivisa() {
		return divisa;
	}

	public void setDivisa(Divisa divisa) {
		this.divisa = divisa;
	}

	public Boolean getEsCotizable() {
		return esCotizable;
	}

	public Boolean getEsDivUME() {
		return esDivUME;
	}

	public void setEsCotizable(Boolean esCotizable) {
		this.esCotizable = esCotizable;
	}

	public void setEsDivUME(Boolean esDivUME) {
		this.esDivUME = esDivUME;
	}

	public List<BigDecimal> getListaValores() {
		return listaValores;
	}

	public String getBaseCalc() {
		return baseCalc;
	}

	public void setBaseCalc(String baseCalc) {
		this.baseCalc = baseCalc;
	}
}

