package com.atosorigin.deri.mercado.mantplazo.action;

import java.util.List;

import org.jboss.seam.ScopeType;
import org.jboss.seam.annotations.In;
import org.jboss.seam.annotations.Name;
import org.jboss.seam.annotations.Out;
import org.jboss.seam.annotations.Scope;
import org.jboss.seam.international.StatusMessage.Severity;

import com.atosorigin.common.action.ModoPantalla;
import com.atosorigin.common.action.PaginatedListAction;
import com.atosorigin.common.constantes.Constantes;
import com.atosorigin.common.formvalidator.FormValidator;
import com.atosorigin.deri.mercado.mantplazo.business.PlazoBo;
import com.atosorigin.deri.mercado.mantplazo.screen.PlazoPantalla;
import com.atosorigin.deri.model.mercado.Plazo;

/**
 * Clase que actúa de action listener para el caso de uso de mantenimiento de plazos.
 */
@Name("plazoAction")
@Scope(ScopeType.CONVERSATION)
@FormValidator
public class PlazoAction extends PaginatedListAction{

	/**
	 * Inyección del bean de Spring "plazoBo" que contiene los métodos de negocio
	 * para el caso de uso mantenimiento de plazos.
	 */
	@In("#{plazoBo}")
	protected PlazoBo plazoBo;


	/**
	 * Inyección del screen bean que contiene los datos de pantalla del caso de uso
	 * mantenimiento de plazos.
	 */
	@In(create=true)
	protected PlazoPantalla plazoPantalla;
	
	
	@Out(required=false)
	private Plazo plazoEdit;
	
	public boolean guardarValidator(){
		if (modoPantalla.equals(ModoPantalla.CREACION)){			
			return crearValidator();
		}
		return true;
	}
	
	public String guardar() {
		if (modoPantalla.equals(ModoPantalla.CREACION)){			
			return crear();
		}else if (modoPantalla.equals(ModoPantalla.EDICION)){				
			return modificar();
		}
		return "";
	}


	/**
	 * Actualiza la lista del grid de plazos
	 * 
	 */
	public void buscar() {
		paginationData.reset();
		refrescarLista();
		//SMM BUG HPQC ID 29
		setPrimerAcceso(false);		
	}
	

		
	//Métodos necesarios para pantallas con grids.
	//Es necesario implementar estos métodos abstractos de PaginatedListAction
	@Override
	public List<Plazo> getDataTableList() {
		return plazoPantalla.getPlazoList();
	}

	@Override
	@SuppressWarnings("unchecked")
	public void setDataTableList(List<?> dataTableList) {
		plazoPantalla.setPlazoList((List<Plazo>)dataTableList);
	}

	@Override
	protected void refreshListInternal() {
		setExportExcel(false);
		List<Plazo> ql = (List<Plazo>)plazoBo.busqueda(plazoPantalla.getCodigo(), plazoPantalla.getUnidadSelect(), plazoPantalla.getNumeroPlazos(), plazoPantalla.getDescripcion(), paginationData);
		plazoPantalla.setPlazoList(ql);
	}


	/**
	 * Prepara para entrar en el modo inspección de un plazo.
	 * 
	 */
	public void ver() {
		setModoPantalla(ModoPantalla.INSPECCION);
		plazoEdit = plazoPantalla.getPlazo();
	}
	
	/**
	 * Prepara para entrar en el modo edición de un plazo.
	 * 
	 */
	public void editar() {
		setModoPantalla(ModoPantalla.EDICION);
		plazoEdit = plazoPantalla.getPlazo();
	}

	/**
	 * Prepara para entrar en el modo creación de un plazo.
	 * 
	 */
	public void nuevo() {
		setModoPantalla(ModoPantalla.CREACION);
		plazoEdit = new Plazo();
		//plazoPantalla.setPlazo(new Plazo());		
	}
	
	/**
	 * Valida el plazo antes de insertarlo en la base de datos.
	 * 
	 */
	public boolean crearValidator() {
		//Plazo plazoForm = plazoPantalla.getPlazo();
		Plazo plazoForm = this.plazoEdit;
		long plazos = plazoBo.getObtenerPlazoPorCodigo(plazoForm.getCodigo());
		if (plazos > 0){
			statusMessages.addToControl("codigo", Severity.ERROR, "plazo.error.plazoyaexiste", Constantes.DEFAULT_MESSAGE_TEMPLATE);
			return false;
		}
		return true;
	}	
	
	/**
	 * Graba el plazo en la base de datos.
	 * 
	 */
	public String crear() {
		plazoBo.alta(this.plazoEdit);
		//plazoBo.alta(plazoPantalla.getPlazo());		
		refrescarLista();
		return "success";
	}
	
	/**
	 * Verifica la existencia de un indice con el plazo a borrar.
	 * 
	 */
	public boolean borrarValidator() {
		Plazo plazo = this.plazoPantalla.getPlazo();
		long plazos = plazoBo.getObtenerIndicePorCodigo(plazo.getCodigo());
		if (plazos > 0){
			statusMessages.addToControl("codigo", Severity.ERROR, "plazo.error.bajanopermitida", Constantes.DEFAULT_MESSAGE_TEMPLATE);
			return false;
		}		
		return true;
	}	
	/**
	 * Borra un plazo.
	 * 
	 */
	public void borrar() {
		plazoBo.borrar(plazoPantalla.getPlazo());		
		refrescarLista();
		
	}

	/**
	 * Modifica un plazo.
	 * 
	 */
	public String modificar() {
		plazoBo.alta(this.plazoEdit);
		//plazoBo.alta(plazoPantalla.getPlazo());		
		refrescarLista();
		return "success";		
	}
	
	@Override
	public void refrescarListaExcel() { 
		setExportExcel(true);
		plazoPantalla.setPlazoList(plazoBo.busqueda(plazoPantalla.getCodigo(), plazoPantalla.getUnidadSelect(), plazoPantalla.getNumeroPlazos(), plazoPantalla.getDescripcion(), paginationData.getPaginationDataForExcel()));	
	}
	
}
