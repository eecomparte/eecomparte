package com.atosorigin.deri.mercado.mantplazo.screen;

import java.util.List;

import org.jboss.seam.ScopeType;
import org.jboss.seam.annotations.Name;
import org.jboss.seam.annotations.Scope;
import org.jboss.seam.annotations.datamodel.DataModel;
import org.jboss.seam.annotations.datamodel.DataModelSelection;

import com.atosorigin.deri.model.mercado.Plazo;
import com.atosorigin.deri.model.mercado.UnidadPlazo;


/**
 *  Contiene los datos de pantalla necesarios para el caso de uso mantenimiento de plazos.
 */
@Name("plazoPantalla")
@Scope(ScopeType.CONVERSATION)
public class PlazoPantalla {

	/** Codigo. Criterio de búsqueda de plazos. */
	protected String codigo;
	
	/** Unidad Plazo. Criterio de búsqueda de plazos.  */	
	protected UnidadPlazo unidadSelect;
	
	public UnidadPlazo getUnidadSelect() {
		return unidadSelect;
	}

	public void setUnidadSelect(UnidadPlazo unidadSelect) {
		this.unidadSelect = unidadSelect;
	}

	/** Numero de Plazos. Criterio de búsqueda de plazos.  - Cantidad */
	protected Long numeroPlazos ;
	
	/** Descripcion. Criterio de búsqueda de plazos.  */
	protected String descripcion;
	
	/** Lista de datos para el grid. */
	@DataModel(value ="listaDtPlazos")
	protected List<Plazo> plazoList;
	
	@DataModelSelection(value ="listaDtPlazos")
	protected Plazo plazo;
	
	public String getCodigo() {
		return codigo;
	}

	public void setCodigo(String codigo) {
		this.codigo = codigo;
	}
	
	public Long getNumeroPlazos() {
		return numeroPlazos;
	}

	public void setNumeroPlazos(Long numeroPlazos) {
		this.numeroPlazos = numeroPlazos;
	}

	public String getDescripcion() {
		return descripcion;
	}

	public void setDescripcion(String descripcion) {
		this.descripcion = descripcion;
	}

	public List<Plazo> getPlazoList() {
		return plazoList;
	}

	public void setPlazoList(List<Plazo> plazoList) {
		this.plazoList = plazoList;				
	}

	public Plazo getPlazo() {
		return plazo;
	}

	public void setPlazo(Plazo plazo) {
		this.plazo = plazo;
	}


	
}
