package com.atosorigin.deri.mercado.mantsubyacente.action;

import java.util.ArrayList;
import java.util.List;

import org.jboss.seam.ScopeType;
import org.jboss.seam.annotations.In;
import org.jboss.seam.annotations.Name;
import org.jboss.seam.annotations.Out;
import org.jboss.seam.annotations.Scope;
import org.jboss.seam.core.Expressions;
import org.jboss.seam.international.StatusMessage.Severity;

import com.atosorigin.common.action.ModoPantalla;
import com.atosorigin.common.action.PaginatedListAction;
import com.atosorigin.common.constantes.Constantes;
import com.atosorigin.common.formvalidator.FormValidator;
import com.atosorigin.common.utils.GenericUtils;
import com.atosorigin.deri.mercado.mantsubyacente.business.SubyacenteBo;
import com.atosorigin.deri.mercado.mantsubyacente.screen.SubyacentePantalla;
import com.atosorigin.deri.model.adminoper.CamaraIndiceDesc;
import com.atosorigin.deri.model.mercado.DescripcionesSubyacente;
import com.atosorigin.deri.model.mercado.Subyacente;
import com.atosorigin.deri.model.parametrizacion.Divisa;

/**
 * Clase action listener para el caso de uso de mantenimiento de subyacentes.
 */
@Name("subyacenteAction")
@Scope(ScopeType.CONVERSATION)
@FormValidator
public class SubyacenteAction extends PaginatedListAction {

	
	/**
	 * Inyección del bean de Spring "subyacenteBo" que contiene los métodos de negocio
	 * para el caso de uso mantenimiento de subyacentes.
	 */
	@In("#{subyacenteBo}")
	protected SubyacenteBo subyacenteBo;

	/**
	 * Inyección del screen bean que contiene los datos de pantalla del caso de uso
	 * mantenimiento de subyacentes.
	 */
	@In(create=true)
	protected SubyacentePantalla subyacentePantalla;
	
	@Out(required=false)
	protected List<DescripcionesSubyacente> descripcionesList;
	
	@Out(required=false	,scope=ScopeType.SESSION)
	protected List<CamaraIndiceDesc> camaraIndiceList;
	
		
	/** Actualiza la lista del grid de subyacentes */
	public void buscar() {
		paginationData.reset(); /** Limpiamos la informción de paginación */
		descripcionesList = null;
		camaraIndiceList = null;
		refrescarLista();
		setPrimerAcceso(false);
	}
	
	/** Borra un subyacente. */
	public void borrar() {
		try {
			
		subyacenteBo.borrar(subyacentePantalla.getSubyacente());
		subyacenteBo.borrarDescripciones(subyacentePantalla.getSubyacente().getCodigo());
		subyacenteBo.borrarCamaras(subyacentePantalla.getSubyacente().getCodigo());
		subyacenteBo.flush();
		descripcionesList = null;
		camaraIndiceList =null;
		refrescarLista();
		} catch (Exception e) {
			statusMessages.add( Severity.FATAL,"Error desconocido {0}",e ) ;
		}
		
	}
	
	/** Prepara para entrar en el modo edición de un subyacente. */
	public void editar() {
		try {
		descripcionesList=null;
		camaraIndiceList=null;
		subyacentePantalla.setSubyacente(subyacentePantalla.getSubyacenteSelec());
		subyacentePantalla.getSubyacente().getPlaza();
		setModoPantalla(ModoPantalla.EDICION);
		} catch (Exception e) {
			statusMessages.add( Severity.FATAL,"Error desconocido {0}",e ) ;
		}
		
	}

	/** Prepara para entrar en el modo inspección de un subyacente. */
	public void ver() {
		try {
		descripcionesList=null;
		camaraIndiceList=null;
		subyacentePantalla.setSubyacente(subyacentePantalla.getSubyacenteSelec());
		
			
//		Object invoke = Expressions.instance().createMethodExpression("#{comboBoxes.buildListaPlazas()}").invoke();
//		subyacentePantalla.getSubyacente().getPlaza();
		
		setModoPantalla(ModoPantalla.INSPECCION);
		} catch (Exception e) {
			statusMessages.add( Severity.FATAL,"Error desconocido {0}",e ) ;
		}
		
	}
	
	/** Graba el subyacente en la base de datos. */
	public String guardar() {
		try {
		subyacenteBo.guardar(subyacentePantalla.getSubyacente());
		
		
		if (subyacentePantalla.getSubyacente().getTipoSubyacente()!=null && "CM".equals(subyacentePantalla.getSubyacente().getTipoSubyacente().getCodigo())){
			
			if (GenericUtils.isNullOrBlank(descripcionesList) || descripcionesList.size()==0){
				datosConf();
			}
			
			if (descripcionesList!=null && descripcionesList.size()!=0){
				for (DescripcionesSubyacente desc : descripcionesList) {
					if ("08".equals(desc.getId().getIdioma().getCodigo())){
						if(!GenericUtils.isNullOrBlank(subyacentePantalla.getSubyacente().getDescripcionCorta()) && !subyacentePantalla.getSubyacente().getDescripcionCorta().equals(desc.getDescripcionCorta())){
							desc.setDescripcionCorta(subyacentePantalla.getSubyacente().getDescripcionCorta());
						}

						if(!GenericUtils.isNullOrBlank(subyacentePantalla.getSubyacente().getDescripcionLarga()) && !subyacentePantalla.getSubyacente().getDescripcionLarga().equals(desc.getDescripcionLarga())){
							desc.setDescripcionLarga(subyacentePantalla.getSubyacente().getDescripcionLarga());
						}
					}
				}

			}
			
		}
		
		
		if (descripcionesList!=null && descripcionesList.size()!=0){
			subyacenteBo.guardarDescripciones(descripcionesList);	
		}
//		if (camaraIndiceListMod!=null ){
			subyacenteBo.guardarCamarasIndices(subyacentePantalla.getSubyacente(),camaraIndiceList);
//		}
			
		subyacenteBo.flush();
		descripcionesList = null;
		camaraIndiceList=null;
		refrescarLista();		
		return Constantes.CONSTANTE_SUCCESS;
		} catch (Exception e) {
			statusMessages.add( Severity.FATAL,"Error desconocido {0}",e ) ;
			return Constantes.CONSTANTE_FAIL;
		}
		
	}
	
	/**
	 * Método de validación de formulario previo a la acción guardar.
	 * El interceptor seam FormValidator lo ejecutará antes del método "guardar".
	 * 
	 * @return true si no hay errores de validación, false en caso contrario.
	 */
	public boolean guardarValidator(){
		
		boolean esCorrecto = true;	
		Subyacente subyacente = this.subyacentePantalla.getSubyacente(); 
		if (!GenericUtils.isNullOrBlank(subyacente) 
				&& !GenericUtils.isNullOrBlank(subyacente.getVariacionMaxima())) {
			
			/** Validamos el formato del campo Var Máx (5 enteros, 12 decimales) */
			esCorrecto = GenericUtils.validaFormatoDecimal(subyacente.getVariacionMaxima(), 5, 12);
			if (!esCorrecto){
				statusMessages.addToControl("inputVarMax", org.jboss.seam.international.StatusMessage.Severity.ERROR, "#{messages['subyacente.error.varmax']}");
			}			
		}		
		//SMM 12/06/2013
		if (subyacente.getTipoSubyacente()!=null 
				&& "DI".equalsIgnoreCase(subyacente.getTipoSubyacente().getCodigo()) &&  subyacente.getPlaza()==null ){
			statusMessages
			.addToControl("listPlaza", Severity.ERROR,
					"#{messages['subyacente.error.PlazaObligatoria']}");
			esCorrecto = false;
		}

		//SMM 14/08/2017
		if (subyacente.getTipoSubyacente()!=null 
				&& "BN".equalsIgnoreCase(subyacente.getTipoSubyacente().getCodigo()) &&  GenericUtils.isNullOrBlank(subyacente.getFechaVencimiento())){
			
			statusMessages.addToControl("fechaVtoSub", Severity.ERROR,
					"#{messages['subyacente.error.FechaVtoObligatoria']}");
			esCorrecto = false;
		}

		
		if (ModoPantalla.CREACION.equals(this.getModoPantalla())) {
			/** subyacente con la misma descripción corta */
			if (!GenericUtils.isNullOrBlank(subyacente)
					&& !GenericUtils.isNullOrBlank(subyacente
							.getDescripcionCorta())) {
				List<Subyacente> listaIndices = subyacenteBo.busqueda(
						subyacente.getDescripcionCorta(), null, null, null,
						null,null, paginationData);
				if (!GenericUtils.isNullOrBlank(listaIndices)
						&& !listaIndices.isEmpty()) {
					statusMessages
							.addToControl("descripcionCorta", Severity.ERROR,
									"#{messages['subyacente.error.subyacenteYaExiste']}");
					esCorrecto = false;
				}
			}
		}
		//SMM 05/02/2018 Descripcion Emir no mayor de 25
		if(!GenericUtils.isNullOrBlank(subyacente) && !GenericUtils.isNullOrBlank(subyacente.getDescripcionEmir()) && subyacente.getDescripcionEmir().length()>25){
				statusMessages
				.addToControl("descripcionEmir", Severity.ERROR,
						"#{messages['subyacente.error.descripcionEmir']}");
				esCorrecto = false;
		}
		
		
		return esCorrecto;
	}

	/** Prepara para entrar en el modo creación de un subyacente. */
	public void nuevo() {
		try {
		descripcionesList=null;
		camaraIndiceList=null;
		Long codigoNuevo = subyacenteBo.obtenerNuevoCodigo();
		subyacentePantalla.setSubyacente(new Subyacente(null,codigoNuevo,null,
				null,new Divisa("EUR"),null,null,null,null,null,null,null,null,null, null));
		setModoPantalla(ModoPantalla.CREACION);
		} catch (Exception e) {
			statusMessages.add( Severity.FATAL,"Error desconocido {0}",e ) ;
		}
		
	}
	
	@Override
	public List<?> getDataTableList() {
		return subyacentePantalla.getSubyacenteList();
	}

	@Override
	protected void refreshListInternal() {
		setExportExcel(false);
		List<Subyacente> listaIndices = (List<Subyacente>)subyacenteBo.busqueda(subyacentePantalla.getDescCorta(), subyacentePantalla.getDescLarga(), 
				subyacentePantalla.getDivisaSelect(), subyacentePantalla.getPlazoSelect(), subyacentePantalla.getTipoSubySelect(),subyacentePantalla.getGrupoSubySelect(), paginationData);
		subyacentePantalla.setSubyacenteList(listaIndices);
	}

	@Override
	public void refrescarListaExcel() {
		setExportExcel(true);
		List<Subyacente> listaIndices = (List<Subyacente>)subyacenteBo.busqueda(subyacentePantalla.getDescCorta(), subyacentePantalla.getDescLarga(), 
				subyacentePantalla.getDivisaSelect(), subyacentePantalla.getPlazoSelect(), subyacentePantalla.getTipoSubySelect(),subyacentePantalla.getGrupoSubySelect(), paginationData.getPaginationDataForExcel());
		subyacentePantalla.setSubyacenteList(listaIndices);
	}

	@SuppressWarnings("unchecked")
	@Override
	public void setDataTableList(List<?> dataTableList) {
		subyacentePantalla.setSubyacenteList((List<Subyacente>)dataTableList);
	}
	
	public String otrosIdiomas(){
		if (descripcionesList==null){
			descripcionesList = new ArrayList<DescripcionesSubyacente>();
			descripcionesList.addAll(subyacenteBo.getListaDescripciones(subyacentePantalla.getSubyacente().getCodigo()));
		}else{
			if (descripcionesList.size()==0) {
				descripcionesList.addAll(subyacenteBo.getListaDescripciones(subyacentePantalla.getSubyacente().getCodigo()));	
			}
		}
		
		
		return Constantes.CONSTANTE_SUCCESS;		
	}

	public String camaras(){
		

		if (camaraIndiceList==null){
			camaraIndiceList = new ArrayList<CamaraIndiceDesc>();
			camaraIndiceList.addAll(subyacenteBo.getCamaraIndice_Desc(subyacentePantalla.getSubyacente().getCodigo()));
		}else{
			if (camaraIndiceList.size()==0) {
				camaraIndiceList.addAll(subyacenteBo.getCamaraIndice_Desc(subyacentePantalla.getSubyacente().getCodigo()));	
			}
		}
		
		
		
//		camaraIndice  = subyacenteBo.getCamaraIndice_Desc(subyacentePantalla.getSubyacente().getCodigo());
		
//		if (descripcionesList==null){
//			descripcionesList = new ArrayList<DescripcionesSubyacente>();
//			descripcionesList.addAll(subyacenteBo.getListaDescripciones(subyacentePantalla.getSubyacente().getCodigo()));
//		}else{
//			if (descripcionesList.size()==0) {
//				descripcionesList.addAll(subyacenteBo.getListaDescripciones(subyacentePantalla.getSubyacente().getCodigo()));	
//			}
//		}
//		
		
		return Constantes.CONSTANTE_SUCCESS;		
	}

	public void onChangeTipoSubyacente(){
		if (!GenericUtils.isNullOrBlank(subyacentePantalla.getSubyacente().getTipoSubyacente()) && "FI".equalsIgnoreCase(subyacentePantalla.getSubyacente().getTipoSubyacente().getCodigo())){
			//Resetear campos que no se permite actualizar
			
			subyacentePantalla.getSubyacente().setCutoff(null);
			subyacentePantalla.getSubyacente().setGrupoSubyacente(null);
			subyacentePantalla.getSubyacente().setFechaVencimiento(null);
			subyacentePantalla.getSubyacente().setDivisa(null);
			subyacentePantalla.getSubyacente().setDescripcionEmir(null);
			subyacentePantalla.getSubyacente().setVariacionMaxima(null);
			subyacentePantalla.getSubyacente().setPagina(null);
			subyacentePantalla.getSubyacente().setPlaza(null);
			subyacentePantalla.getSubyacente().setPlazo(null);
			subyacentePantalla.getSubyacente().setDiasPreviosFixing(null);
			subyacentePantalla.getSubyacente().setUnidad(null);
			subyacentePantalla.getSubyacente().setReferenciaBDU(null);
			subyacentePantalla.getSubyacente().setReferenciaPad(null);
			subyacentePantalla.getSubyacente().setTiposPorIndices(null);
			
		}
	}

	public String datosConf(){
		if (descripcionesList==null){
			descripcionesList = new ArrayList<DescripcionesSubyacente>();
			descripcionesList.addAll(subyacenteBo.getListaDescripciones(subyacentePantalla.getSubyacente().getCodigo()));
		}else{
			if (descripcionesList.size()==0) {
				descripcionesList = new ArrayList<DescripcionesSubyacente>();
				descripcionesList.addAll(subyacenteBo.getListaDescripciones(subyacentePantalla.getSubyacente().getCodigo()));	
			}
		}

		return Constantes.CONSTANTE_SUCCESS;		
	}
	
}
