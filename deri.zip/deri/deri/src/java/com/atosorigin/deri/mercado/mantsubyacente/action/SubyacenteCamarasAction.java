package com.atosorigin.deri.mercado.mantsubyacente.action;

import java.util.ArrayList;
import java.util.List;

import org.jboss.seam.ScopeType;
import org.jboss.seam.annotations.Factory;
import org.jboss.seam.annotations.In;
import org.jboss.seam.annotations.Name;
import org.jboss.seam.annotations.Out;
import org.jboss.seam.annotations.Scope;

import com.atosorigin.common.action.GenericAction;
import com.atosorigin.common.action.PaginatedListAction;
import com.atosorigin.common.constantes.Constantes;
import com.atosorigin.common.formvalidator.FormValidator;
import com.atosorigin.common.utils.GenericUtils;
import com.atosorigin.deri.mercado.mantsubyacente.business.SubyacenteBo;
import com.atosorigin.deri.mercado.mantsubyacente.screen.SubyacenteCamarasPantalla;
import com.atosorigin.deri.model.adminoper.CamaraIndiceDesc;
import com.atosorigin.deri.model.adminoper.CamaraIndiceDescId;
import com.atosorigin.deri.model.adminoper.Camaras;
import com.atosorigin.deri.model.common.Idioma;
import com.atosorigin.deri.model.mercado.DescripcionesSubyacente;
import com.atosorigin.deri.model.mercado.DescripcionesSubyacenteId;
import com.atosorigin.deri.model.murex.ProcedenciaProducto;

/**
 * Clase action listener para el caso de uso de mantenimiento de subyacentes.
 */
@Name("subyacenteCamarasAction")
@Scope(ScopeType.CONVERSATION)
@FormValidator
public class SubyacenteCamarasAction extends PaginatedListAction {

	
	/**
	 * Inyección del bean de Spring "subyacenteBo" que contiene los métodos de negocio
	 * para el caso de uso mantenimiento de subyacentes.
	 */
	@In("#{subyacenteBo}")
	protected SubyacenteBo subyacenteBo;

	/**
	 * Inyección del screen bean que contiene los datos de pantalla del caso de uso
	 * mantenimiento de subyacentes.
	 */
	@In(create=true)
	protected SubyacenteCamarasPantalla subyacenteCamarasPantalla;
	
	@Out(required = false, value = "camarasList")
	List<Camaras> camarasList = null;
	
	@Factory(value = "camarasList")
	public void initCamaras() {
		camarasList = subyacenteBo.getCamaras();
	}

	private List<CamaraIndiceDesc> listaTotal;
	
	@In
	protected List<CamaraIndiceDesc> camaraIndiceList;

	
	public void init() {

//		listaTotal = subyacenteBo.generarDescripciones(subyacenteCamarasPantalla.getSubyacente().getCodigo());
		
//		listaTotal = new ArrayList<CamaraIndiceDesc>();
//		
//		if (camaraIndiceList!=null && camaraIndiceList.size()==0){
//		
////			camaraIndiceList.addAll(listaTotal);	
//			
//		}else if (camaraIndiceList!=null && listaTotal.size() > camaraIndiceList.size()){
//				
//			for (CamaraIndiceDesc desc : listaTotal) {
//					camaraIndiceList.add(desc);
//			}
//		
//		}
//		if (isPrimerAcceso()){
			if (subyacenteCamarasPantalla.getCamarasList()==null){
				subyacenteCamarasPantalla.setCamarasList(new ArrayList<CamaraIndiceDesc>());
			}
			subyacenteCamarasPantalla.getCamarasList().clear();
			subyacenteCamarasPantalla.getCamarasList().addAll(camaraIndiceList);	
//			setPrimerAcceso(false);
//		}
		
		
	}


	
	public void nuevo() {
		subyacenteCamarasPantalla.setCamaraComboAlta(new Camaras());
		subyacenteCamarasPantalla.setReferenciaCam(new String());
	}
	
	public void borrar() {
	
//		subyacenteBo.borrar(
				subyacenteCamarasPantalla.getCamaraSelec();
				if (camaraIndiceList.contains(subyacenteCamarasPantalla.getCamaraSelec()))
//						subyacenteCamarasPantalla.getCamarasList().contains(subyacenteCamarasPantalla.getCamaraSelec()))
				{
					camaraIndiceList.remove(subyacenteCamarasPantalla.getCamaraSelec());
//					subyacenteCamarasPantalla.getCamarasList().remove(subyacenteCamarasPantalla.getCamaraSelec());
				}
//				);
//				init();
	}
	
	public void editar() {
		
		subyacenteCamarasPantalla.setCamaraComboAlta(subyacenteCamarasPantalla.getCamaraSelec().getId().getCamara());
		subyacenteCamarasPantalla.setReferenciaCam(subyacenteCamarasPantalla.getCamaraSelec().getReferenciaCamara());
	}

	/** Graba el subyacente en la base de datos. */
	public String guardarDetalle() {
//		camaraIndiceList.clear();
		CamaraIndiceDescId  id = new CamaraIndiceDescId(subyacenteCamarasPantalla.getCamaraComboAlta(), subyacenteCamarasPantalla.getSubyacente());
		CamaraIndiceDesc cam_desc = new CamaraIndiceDesc(id, subyacenteCamarasPantalla.getReferenciaCam()); 
		
//		if (subyacenteCamarasPantalla.getCamarasList().contains(cam_desc)){
//		if (camaraIndiceList.contains(cam_desc)){	
			Boolean encontrada = false;
			if (!GenericUtils.isNullOrBlank(camaraIndiceList)){
			for (CamaraIndiceDesc camaraEncontrada : camaraIndiceList) {
				if (camaraEncontrada.getId().equals(cam_desc.getId())){
					camaraEncontrada.setReferenciaCamara(subyacenteCamarasPantalla.getReferenciaCam());
					encontrada = true;
				}
			}
			}
//		}else{
			if (!encontrada){
				camaraIndiceList.add(cam_desc);
//			subyacenteCamarasPantalla.getCamarasList().add(cam_desc);	
			}
		
		return Constantes.CONSTANTE_SUCCESS;
		
	}
	
	/** Graba el subyacente en la base de datos. */
	public String guardar() {
		camaraIndiceList.clear();
		camaraIndiceList.addAll(subyacenteCamarasPantalla.getCamarasList());
		return Constantes.CONSTANTE_SUCCESS;
		
	}



	@Override
	public List<?> getDataTableList() {
		return subyacenteCamarasPantalla.getCamarasList();
	}



	@Override
	public void refrescarListaExcel() {
		setExportExcel(true);
		List<CamaraIndiceDesc> listaIndices = null;
		subyacenteCamarasPantalla.setCamarasList(listaIndices);
	}



	@Override
	protected void refreshListInternal() {
		setExportExcel(false);
		List<CamaraIndiceDesc> listaIndices = null;
		subyacenteCamarasPantalla.setCamarasList(listaIndices);
	}



	@Override
	public void setDataTableList(List<?> dataTableList) {
		subyacenteCamarasPantalla.setCamarasList((List<CamaraIndiceDesc>)dataTableList);
		
	}
//	@Override
//	public void salir() {
//		setPrimerAcceso(true);
//		camaraIndiceList.clear();
//		camaraIndiceList.addAll(subyacenteCamarasPantalla.getCamarasList());	
//	}


}
