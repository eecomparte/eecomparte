package com.atosorigin.deri.mercado.mantsubyacente.action;

import java.util.ArrayList;
import java.util.List;

import org.jboss.seam.ScopeType;
import org.jboss.seam.annotations.In;
import org.jboss.seam.annotations.Name;
import org.jboss.seam.annotations.Scope;
import org.jboss.seam.international.StatusMessage.Severity;

import com.atosorigin.common.action.PaginatedListAction;
import com.atosorigin.common.constantes.Constantes;
import com.atosorigin.common.formvalidator.FormValidator;
import com.atosorigin.common.utils.GenericUtils;
import com.atosorigin.deri.mercado.mantsubyacente.business.SubyacenteBo;
import com.atosorigin.deri.mercado.mantsubyacente.screen.SubyacenteDatosConfPantalla;
import com.atosorigin.deri.mercado.mantsubyacente.screen.SubyacenteIdiomasPantalla;
import com.atosorigin.deri.model.common.Idioma;
import com.atosorigin.deri.model.mercado.DescripcionesSubyacente;
import com.atosorigin.deri.model.mercado.DescripcionesSubyacenteId;

/**
 * Clase action listener para el caso de uso de mantenimiento de subyacentes.
 */
@Name("subyacenteDatosConfAction")
@Scope(ScopeType.CONVERSATION)
@FormValidator
public class SubyacenteDatosConfAction extends PaginatedListAction {

	
	/**
	 * Inyección del bean de Spring "subyacenteBo" que contiene los métodos de negocio
	 * para el caso de uso mantenimiento de subyacentes.
	 */
	@In("#{subyacenteBo}")
	protected SubyacenteBo subyacenteBo;

	/**
	 * Inyección del screen bean que contiene los datos de pantalla del caso de uso
	 * mantenimiento de subyacentes.
	 */
	@In(create=true)
	protected SubyacenteDatosConfPantalla subyacenteDatosConfPantalla;
	
	@In
	protected List<DescripcionesSubyacente> descripcionesList;
	
	
	private List<DescripcionesSubyacente> listaTotal;
	public Integer grandariaDescVar;
	
	/** Actualiza la lista del grid de subyacentes */
	public void buscar() {
		paginationData.reset(); /** Limpiamos la informción de paginación */
		refrescarLista();
		setPrimerAcceso(false);
	}
	

	public void init() {
		listaTotal = new ArrayList<DescripcionesSubyacente>();
		listaTotal = subyacenteBo.generarDescripciones(subyacenteDatosConfPantalla.getSubyacente().getCodigo());
		
		if (descripcionesList!=null && descripcionesList.size()==0){
		
			descripcionesList.addAll(listaTotal);	
			
		}else if (descripcionesList!=null && listaTotal.size() > descripcionesList.size()){
				
			for (DescripcionesSubyacente desc : listaTotal) {
				if (!existeIdioma(desc)){
					descripcionesList.add(desc);
				}
			}
		
		}
			if (subyacenteDatosConfPantalla.getIdiomasList()==null){
				subyacenteDatosConfPantalla.setIdiomasList(new ArrayList<DescripcionesSubyacente>());
			}
			subyacenteDatosConfPantalla.getIdiomasList().clear();
			
			for (DescripcionesSubyacente desc : descripcionesList) {
				DescripcionesSubyacente idioma = new DescripcionesSubyacente();
				DescripcionesSubyacenteId idiomaId = new DescripcionesSubyacenteId();
				
				idiomaId.setCodigoSub(desc.getId().getCodigoSub());
				idiomaId.setIdioma(desc.getId().getIdioma());
				idioma.setId(idiomaId);
				idioma.setAbrevUnidadMedida(desc.getAbrevUnidadMedida());
				idioma.setDescripcionCorta(desc.getDescripcionCorta());
				idioma.setDescripcionLarga(desc.getDescripcionLarga());
				idioma.setDescripcionVariable(desc.getDescripcionVariable());
				idioma.setDescripcionMatPrima(desc.getDescripcionMatPrima());
			
				subyacenteDatosConfPantalla.getIdiomasList().add(idioma);
			}
			
//			subyacenteDatosConfPantalla.getIdiomasList().addAll(descripcionesList);	
		
		
		grandariaDescVar = subyacenteBo.obtenerGrandariaDescVar();
		if (GenericUtils.isNullOrBlank(grandariaDescVar) || grandariaDescVar == 0){
			grandariaDescVar = 2900;
		}
	}


	private Boolean existeIdioma(DescripcionesSubyacente desc) {
		for (DescripcionesSubyacente desc2 : descripcionesList) {
			if (desc2.getId().getCodigoSub().equals(desc.getId().getCodigoSub()) 
				&& desc2.getId().getIdioma().equals(desc.getId().getIdioma()) ){
				return true;
			}
		}
	return false;
	}
	
	private DescripcionesSubyacente generarRegistro(Idioma idioma) {
		// TODO Auto-generated method stub
		DescripcionesSubyacenteId id = new DescripcionesSubyacenteId(subyacenteDatosConfPantalla.getSubyacente().getCodigo(), idioma);
		
		return null;
	}

	
	public void onDescLargaChange(DescripcionesSubyacente changed){
		
		if (!GenericUtils.isNullOrBlank(changed) && "08".equals(changed.getId().getIdioma().getCodigo())){
			subyacenteDatosConfPantalla.getSubyacente().setDescripcionLarga(changed.getDescripcionLarga());
		}
		
	}
	
	public void onDescCortaChange(DescripcionesSubyacente changed){
		
		if (!GenericUtils.isNullOrBlank(changed) && "08".equals(changed.getId().getIdioma().getCodigo())){
			subyacenteDatosConfPantalla.getSubyacente().setDescripcionCorta(changed.getDescripcionCorta());
		}
		
	}

	/** Graba el subyacente en la base de datos. */
	public Boolean guardarValidator() {
		
		if (GenericUtils.isNullOrBlank(grandariaDescVar) || grandariaDescVar == 0){
			grandariaDescVar = 2900;
		}
		for (DescripcionesSubyacente desc : subyacenteDatosConfPantalla.getIdiomasList()) {
	
			if (!GenericUtils.isNullOrBlank(desc.getDescripcionVariable()) && desc.getDescripcionVariable().length() > grandariaDescVar){
				
				statusMessages.add(Severity.ERROR, "#{messages['subyacente.error.descripVaria']}");
				return false;
			}
			
//			if ("08".equals(desc.getId().getIdioma().getCodigo())){
//				if((GenericUtils.isNullOrBlank(desc.getDescripcionCorta()) && !GenericUtils.isNullOrBlank(subyacenteDatosConfPantalla.getSubyacente().getDescripcionCorta()))
//				|| (GenericUtils.isNullOrBlank(desc.getDescripcionLarga()) && !GenericUtils.isNullOrBlank(subyacenteDatosConfPantalla.getSubyacente().getDescripcionLarga()))		
//				|| (!GenericUtils.isNullOrBlank(desc.getDescripcionCorta()) && !desc.getDescripcionCorta().equals(subyacenteDatosConfPantalla.getSubyacente().getDescripcionCorta()))
//				|| (!GenericUtils.isNullOrBlank(desc.getDescripcionLarga()) && !desc.getDescripcionLarga().equals(subyacenteDatosConfPantalla.getSubyacente().getDescripcionLarga()))
//				){
//					
//					statusMessages.add(Severity.ERROR, "#{messages['subyacente.error.descripciones']}");
//					return false;
//					
//				}
//			}
			
		}
		
		return true;
	
	}
	
	/** Graba el subyacente en la base de datos. */
	public String guardar() {
		descripcionesList.clear();
		descripcionesList.addAll(subyacenteDatosConfPantalla.getIdiomasList());
		
		for (DescripcionesSubyacente desc : subyacenteDatosConfPantalla.getIdiomasList()) {
			
			
			if ("08".equals(desc.getId().getIdioma().getCodigo())){
				if(!GenericUtils.isNullOrBlank(desc.getDescripcionCorta()) && !desc.getDescripcionCorta().equals(subyacenteDatosConfPantalla.getSubyacente().getDescripcionCorta())){
					subyacenteDatosConfPantalla.getSubyacente().setDescripcionCorta(desc.getDescripcionCorta());
				}
		
				if(!GenericUtils.isNullOrBlank(desc.getDescripcionLarga()) && !desc.getDescripcionLarga().equals(subyacenteDatosConfPantalla.getSubyacente().getDescripcionLarga())){
					subyacenteDatosConfPantalla.getSubyacente().setDescripcionLarga(desc.getDescripcionLarga());
				}
				
			}
			
		}
		
		return Constantes.CONSTANTE_SUCCESS;
		
	}
	
//	/**
//	 * Método de validación de formulario previo a la acción guardar.
//	 * El interceptor seam FormValidator lo ejecutará antes del método "guardar".
//	 * 
//	 * @return true si no hay errores de validación, false en caso contrario.
//	 */
//	public boolean guardarValidator(){
//		
//		boolean esCorrecto = true;	
//		Subyacente subyacente = this.subyacenteIdiomasPantalla.getSubyacente(); 
//		if (!GenericUtils.isNullOrBlank(subyacente) 
//				&& !GenericUtils.isNullOrBlank(subyacente.getVariacionMaxima())) {
//			
//			/** Validamos el formato del campo Var Máx (5 enteros, 12 decimales) */
//			esCorrecto = GenericUtils.validaFormatoDecimal(subyacente.getVariacionMaxima(), 5, 12);
//			if (!esCorrecto){
//				statusMessages.addToControl("inputVarMax", org.jboss.seam.international.StatusMessage.Severity.ERROR, "#{messages['subyacente.error.varmax']}");
//			}			
//		}		
//
//		if (ModoPantalla.CREACION.equals(this.getModoPantalla())) {
//			/** subyacente con la misma descripción corta */
//			if (!GenericUtils.isNullOrBlank(subyacente)
//					&& !GenericUtils.isNullOrBlank(subyacente
//							.getDescripcionCorta())) {
//				List<Subyacente> listaIndices = subyacenteBo.busqueda(
//						subyacente.getDescripcionCorta(), null, null, null,
//						null, paginationData);
//				if (!GenericUtils.isNullOrBlank(listaIndices)
//						&& !listaIndices.isEmpty()) {
//					statusMessages
//							.addToControl("descripcionCorta", Severity.ERROR,
//									"#{messages['subyacente.error.subyacenteYaExiste']}");
//					esCorrecto = false;
//				}
//			}
//		}
//		return esCorrecto;
//	}


	
	@Override
	public List<?> getDataTableList() {
		return subyacenteDatosConfPantalla.getIdiomasList();
	}

	@Override
	protected void refreshListInternal() {
		setExportExcel(false);
		List<DescripcionesSubyacente> listaIndices = null;
		subyacenteDatosConfPantalla.setIdiomasList(listaIndices);
	}

	@Override
	public void refrescarListaExcel() {
		setExportExcel(true);
		List<DescripcionesSubyacente> listaIndices = null;
		subyacenteDatosConfPantalla.setIdiomasList(listaIndices);
	}

	@SuppressWarnings("unchecked")
	@Override
	public void setDataTableList(List<?> dataTableList) {
		subyacenteDatosConfPantalla.setIdiomasList((List<DescripcionesSubyacente>)dataTableList);
	}
	
	public String otrosIdiomas(){
		return Constantes.CONSTANTE_SUCCESS;		
	}

}
