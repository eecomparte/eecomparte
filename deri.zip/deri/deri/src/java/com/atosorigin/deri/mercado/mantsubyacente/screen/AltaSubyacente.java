package com.atosorigin.deri.mercado.mantsubyacente.screen;

import java.math.BigDecimal;

import org.jboss.seam.ScopeType;
import org.jboss.seam.annotations.Name;
import org.jboss.seam.annotations.Scope;

import com.atosorigin.deri.model.mercado.Pagina;
import com.atosorigin.deri.model.mercado.Plaza;
import com.atosorigin.deri.model.mercado.Plazo;
import com.atosorigin.deri.model.mercado.TipoSubyacente;
import com.atosorigin.deri.model.mercado.UnidadPlazo;

@Name("altaSubyacente")
@Scope(ScopeType.CONVERSATION)
/**
 * 
 */
public class AltaSubyacente implements java.io.Serializable {

	protected String descCorta;
	protected String descLarga;
	protected String divisaSelect = "EUR"; //Por defecto la divisa es EUR
	protected Plazo plazoSelect;
	protected TipoSubyacente tipoSubySelect;
	protected Long codigo;
	protected Integer numDias;
	protected BigDecimal varMax;
	protected Plaza plazaSelect;
	protected Pagina paginaSelect;
	protected String codIsin;
	protected UnidadPlazo unidadSelect;
	
	public String getDescCorta() {
		return descCorta;
	}
	public String getDescLarga() {
		return descLarga;
	}
	public String getDivisaSelect() {
		return divisaSelect;
	}
	public Plazo getPlazoSelect() {
		return plazoSelect;
	}
	public TipoSubyacente getTipoSubySelect() {
		return tipoSubySelect;
	}
	public Long getCodigo() {
		return codigo;
	}
	public Integer getNumDias() {
		return numDias;
	}
	public BigDecimal getVarMax() {
		return varMax;
	}
	public Plaza getPlazaSelect() {
		return plazaSelect;
	}
	public Pagina getPaginaSelect() {
		return paginaSelect;
	}
	public String getCodIsin() {
		return codIsin;
	}
	public UnidadPlazo getUnidadSelect() {
		return unidadSelect;
	}
	public void setDescCorta(String descCorta) {
		this.descCorta = descCorta;
	}
	public void setDescLarga(String descLarga) {
		this.descLarga = descLarga;
	}
	public void setDivisaSelect(String divisaSelect) {
		this.divisaSelect = divisaSelect;
	}
	public void setPlazoSelect(Plazo plazoSelect) {
		this.plazoSelect = plazoSelect;
	}
	public void setTipoSubySelect(TipoSubyacente tipoSubySelect) {
		this.tipoSubySelect = tipoSubySelect;
	}
	public void setCodigo(Long codigo) {
		this.codigo = codigo;
	}
	public void setNumDias(Integer numDias) {
		this.numDias = numDias;
	}
	public void setVarMax(BigDecimal varMax) {
		this.varMax = varMax;
	}
	public void setPlazaSelect(Plaza plazaSelect) {
		this.plazaSelect = plazaSelect;
	}
	public void setPaginaSelect(Pagina paginaSelect) {
		this.paginaSelect = paginaSelect;
	}
	public void setCodIsin(String codIsin) {
		this.codIsin = codIsin;
	}
	public void setUnidadSelect(UnidadPlazo unidadSelect) {
		this.unidadSelect = unidadSelect;
	}
	
}
