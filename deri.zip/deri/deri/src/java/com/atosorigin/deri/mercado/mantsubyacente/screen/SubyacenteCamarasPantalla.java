package com.atosorigin.deri.mercado.mantsubyacente.screen;

import java.util.List;

import org.jboss.seam.ScopeType;
import org.jboss.seam.annotations.In;
import org.jboss.seam.annotations.Name;
import org.jboss.seam.annotations.Scope;
import org.jboss.seam.annotations.datamodel.DataModel;
import org.jboss.seam.annotations.datamodel.DataModelSelection;

import com.atosorigin.common.constantes.Constantes;
import com.atosorigin.deri.model.adminoper.CamaraIndiceDesc;
import com.atosorigin.deri.model.adminoper.Camaras;
import com.atosorigin.deri.model.mercado.DescripcionesSubyacente;
import com.atosorigin.deri.model.mercado.Pagina;
import com.atosorigin.deri.model.mercado.Plaza;
import com.atosorigin.deri.model.mercado.Plazo;
import com.atosorigin.deri.model.mercado.Subyacente;
import com.atosorigin.deri.model.mercado.TipoSubyacente;
import com.atosorigin.deri.model.mercado.Unidad;
import com.atosorigin.deri.model.parametrizacion.Divisa;

/**
 * Contiene los datos de pantalla necesarios para el caso de uso mantenimiento de subyacentes.
 */
@Name("subyacenteCamarasPantalla")
@Scope(ScopeType.CONVERSATION)
public class SubyacenteCamarasPantalla {
	
	protected String referenciaCam;
	protected String descLarga;
	protected Divisa divisaSelect;
	protected Plazo plazoSelect;
	protected TipoSubyacente tipoSubySelect;
	protected CamaraIndiceDesc camaraIndi;
	protected Camaras camaraComboAlta;
	
	public SubyacenteCamarasPantalla() {
		/** Valor por defecto del combobox de divisas */
		this.divisaSelect = new Divisa(Constantes.DIVISA_EUR);
	}
	
	/** Lista de datos para el grid. */
	@DataModel(value ="listaDtCamaras")
	protected List<CamaraIndiceDesc> camarasList;
	
	/** Subyacente seleccionado en el grid */
	@DataModelSelection(value ="listaDtCamaras")
//	@Out(value="subyacenteSelec", required=false)
    protected CamaraIndiceDesc camaraSelec;
	
    @In(value="subyacente", required=true)
	protected Subyacente subyacente;

	public String getReferenciaCam() {
		return referenciaCam;
	}

	public String getDescLarga() {
		return descLarga;
	}

	public Divisa getDivisaSelect() {
		return divisaSelect;
	}

	public Plazo getPlazoSelect() {
		return plazoSelect;
	}

	public TipoSubyacente getTipoSubySelect() {
		return tipoSubySelect;
	}


	public Subyacente getSubyacente() {
		return subyacente;
	}

	public void setReferenciaCam(String referenciaCam) {
		this.referenciaCam = referenciaCam;
	}

	public void setDescLarga(String descLarga) {
		this.descLarga = descLarga;
	}

	public void setDivisaSelect(Divisa divisaSelect) {
		this.divisaSelect = divisaSelect;
	}

	public void setPlazoSelect(Plazo plazoSelect) {
		this.plazoSelect = plazoSelect;
	}

	public void setTipoSubySelect(TipoSubyacente tipoSubySelect) {
		this.tipoSubySelect = tipoSubySelect;
	}

	public void setSubyacente(Subyacente subyacente) {
		this.subyacente = subyacente;
	}

	public CamaraIndiceDesc getCamaraIndi() {
		return camaraIndi;
	}

	public void setCamaraIndi(CamaraIndiceDesc camaraIndi) {
		this.camaraIndi = camaraIndi;
	}


	public List<CamaraIndiceDesc> getCamarasList() {
		return camarasList;
	}

	public void setCamarasList(List<CamaraIndiceDesc> camarasList) {
		this.camarasList = camarasList;
	}

	public void setCamaraSelec(CamaraIndiceDesc camaraSelec) {
		this.camaraSelec = camaraSelec;
	}

	public Camaras getCamaraComboAlta() {
		return camaraComboAlta;
	}

	public void setCamaraComboAlta(Camaras camaraComboAlta) {
		this.camaraComboAlta = camaraComboAlta;
	}

	public CamaraIndiceDesc getCamaraSelec() {
		return camaraSelec;
	}
}