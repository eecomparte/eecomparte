package com.atosorigin.deri.mercado.mantsubyacente.screen;

import java.util.List;

import org.jboss.seam.ScopeType;
import org.jboss.seam.annotations.In;
import org.jboss.seam.annotations.Name;
import org.jboss.seam.annotations.Scope;
import org.jboss.seam.annotations.datamodel.DataModel;
import org.jboss.seam.annotations.datamodel.DataModelSelection;

import com.atosorigin.common.constantes.Constantes;
import com.atosorigin.deri.model.mercado.DescripcionesSubyacente;
import com.atosorigin.deri.model.mercado.Pagina;
import com.atosorigin.deri.model.mercado.Plaza;
import com.atosorigin.deri.model.mercado.Plazo;
import com.atosorigin.deri.model.mercado.Subyacente;
import com.atosorigin.deri.model.mercado.TipoSubyacente;
import com.atosorigin.deri.model.mercado.Unidad;
import com.atosorigin.deri.model.parametrizacion.Divisa;

/**
 * Contiene los datos de pantalla necesarios para el caso de uso mantenimiento de subyacentes.
 */
@Name("subyacenteDatosConfPantalla")
@Scope(ScopeType.CONVERSATION)
public class SubyacenteDatosConfPantalla {
	
	protected String descCorta;
	protected String descLarga;
	protected Divisa divisaSelect;
	protected Plazo plazoSelect;
	protected TipoSubyacente tipoSubySelect;

	/** Campos necesarios para la pantalla de edición */
	protected Plaza plazaSelect;
	protected Pagina paginaSelect;
	protected Unidad unidadSelect;
	
	public SubyacenteDatosConfPantalla() {
		/** Valor por defecto del combobox de divisas */
		this.divisaSelect = new Divisa(Constantes.DIVISA_EUR);
	}
	
	/** Lista de datos para el grid. */
	@DataModel(value ="listaDtIdiomas")
	protected List<DescripcionesSubyacente> idiomasList;
	
	/** Subyacente seleccionado en el grid */
	@DataModelSelection(value ="listaDtIdiomas")
//	@Out(value="subyacenteSelec", required=false)
    protected DescripcionesSubyacente idiomaSelec;

    @In(value="subyacente", required=true)
	protected Subyacente subyacente;

	public String getDescCorta() {
		return descCorta;
	}

	public String getDescLarga() {
		return descLarga;
	}

	public Divisa getDivisaSelect() {
		return divisaSelect;
	}

	public Plazo getPlazoSelect() {
		return plazoSelect;
	}

	public TipoSubyacente getTipoSubySelect() {
		return tipoSubySelect;
	}

	public Plaza getPlazaSelect() {
		return plazaSelect;
	}

	public Pagina getPaginaSelect() {
		return paginaSelect;
	}

	public Unidad getUnidadSelect() {
		return unidadSelect;
	}

	public List<DescripcionesSubyacente> getIdiomasList() {
		return idiomasList;
	}

	public DescripcionesSubyacente getIdiomaSelec() {
		return idiomaSelec;
	}

	public Subyacente getSubyacente() {
		return subyacente;
	}

	public void setDescCorta(String descCorta) {
		this.descCorta = descCorta;
	}

	public void setDescLarga(String descLarga) {
		this.descLarga = descLarga;
	}

	public void setDivisaSelect(Divisa divisaSelect) {
		this.divisaSelect = divisaSelect;
	}

	public void setPlazoSelect(Plazo plazoSelect) {
		this.plazoSelect = plazoSelect;
	}

	public void setTipoSubySelect(TipoSubyacente tipoSubySelect) {
		this.tipoSubySelect = tipoSubySelect;
	}

	public void setPlazaSelect(Plaza plazaSelect) {
		this.plazaSelect = plazaSelect;
	}

	public void setPaginaSelect(Pagina paginaSelect) {
		this.paginaSelect = paginaSelect;
	}

	public void setUnidadSelect(Unidad unidadSelect) {
		this.unidadSelect = unidadSelect;
	}

	public void setIdiomasList(List<DescripcionesSubyacente> idiomasList) {
		this.idiomasList = idiomasList;
	}

	public void setIdiomaSelec(DescripcionesSubyacente idiomaSelec) {
		this.idiomaSelec = idiomaSelec;
	}

	public void setSubyacente(Subyacente subyacente) {
		this.subyacente = subyacente;
	}
}