package com.atosorigin.deri.mercado.mantsubyacente.screen;

import java.util.List;

import org.jboss.seam.ScopeType;
import org.jboss.seam.annotations.Name;
import org.jboss.seam.annotations.Out;
import org.jboss.seam.annotations.Scope;
import org.jboss.seam.annotations.datamodel.DataModel;
import org.jboss.seam.annotations.datamodel.DataModelSelection;

import com.atosorigin.common.constantes.Constantes;
import com.atosorigin.deri.model.mercado.Pagina;
import com.atosorigin.deri.model.mercado.Plaza;
import com.atosorigin.deri.model.mercado.Plazo;
import com.atosorigin.deri.model.mercado.Subyacente;
import com.atosorigin.deri.model.mercado.TipoSubyacente;
import com.atosorigin.deri.model.mercado.Unidad;
import com.atosorigin.deri.model.parametrizacion.Divisa;

/**
 * Contiene los datos de pantalla necesarios para el caso de uso mantenimiento de subyacentes.
 */
@Name("subyacentePantalla")
@Scope(ScopeType.CONVERSATION)
public class SubyacentePantalla {
	
	protected String descCorta;
	protected String descLarga;
	protected Divisa divisaSelect;
	protected Plazo plazoSelect;
	protected TipoSubyacente tipoSubySelect;
	protected String grupoSubySelect;

	/** Campos necesarios para la pantalla de edición */
	protected Plaza plazaSelect;
	protected Pagina paginaSelect;
	protected Unidad unidadSelect;
	
	public SubyacentePantalla() {
		/** Valor por defecto del combobox de divisas */
		this.divisaSelect = new Divisa(Constantes.DIVISA_EUR);
	}
	
	/** Lista de datos para el grid. */
	@DataModel(value ="listaDtSubyacentes")
	protected List<Subyacente>subyacenteList;
	
	/** Subyacente seleccionado en el grid */
	@DataModelSelection(value ="listaDtSubyacentes")
	@Out(value="subyacenteSelec", required=false)
    protected Subyacente subyacenteSelec;

    @Out(value="subyacente", required=false)
	protected Subyacente subyacente;

	public String getDescCorta() {
		return descCorta;
	}

	public String getDescLarga() {
		return descLarga;
	}

	public Divisa getDivisaSelect() {
		return divisaSelect;
	}

	public Plazo getPlazoSelect() {
		return plazoSelect;
	}

	public TipoSubyacente getTipoSubySelect() {
		return tipoSubySelect;
	}

	public Plaza getPlazaSelect() {
		return plazaSelect;
	}

	public Pagina getPaginaSelect() {
		return paginaSelect;
	}

	public Unidad getUnidadSelect() {
		return unidadSelect;
	}

	public List<Subyacente> getSubyacenteList() {
		return subyacenteList;
	}

	public Subyacente getSubyacenteSelec() {
		return subyacenteSelec;
	}

	public Subyacente getSubyacente() {
		return subyacente;
	}

	public void setDescCorta(String descCorta) {
		this.descCorta = descCorta;
	}

	public void setDescLarga(String descLarga) {
		this.descLarga = descLarga;
	}

	public void setDivisaSelect(Divisa divisaSelect) {
		this.divisaSelect = divisaSelect;
	}

	public void setPlazoSelect(Plazo plazoSelect) {
		this.plazoSelect = plazoSelect;
	}

	public void setTipoSubySelect(TipoSubyacente tipoSubySelect) {
		this.tipoSubySelect = tipoSubySelect;
	}

	public void setPlazaSelect(Plaza plazaSelect) {
		this.plazaSelect = plazaSelect;
	}

	public void setPaginaSelect(Pagina paginaSelect) {
		this.paginaSelect = paginaSelect;
	}

	public void setUnidadSelect(Unidad unidadSelect) {
		this.unidadSelect = unidadSelect;
	}

	public void setSubyacenteList(List<Subyacente> subyacenteList) {
		this.subyacenteList = subyacenteList;
	}

	public void setSubyacenteSelec(Subyacente suyacenteSelec) {
		this.subyacenteSelec = suyacenteSelec;
	}

	public void setSubyacente(Subyacente subyacente) {
		this.subyacente = subyacente;
	}

	public String getGrupoSubySelect() {
		return grupoSubySelect;
	}

	public void setGrupoSubySelect(String grupoSubySelect) {
		this.grupoSubySelect = grupoSubySelect;
	}
}