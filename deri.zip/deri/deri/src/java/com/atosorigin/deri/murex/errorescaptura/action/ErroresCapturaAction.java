package com.atosorigin.deri.murex.errorescaptura.action;

import java.util.ArrayList;
import java.util.List;

import org.jboss.seam.ScopeType;
import org.jboss.seam.annotations.In;
import org.jboss.seam.annotations.Name;
import org.jboss.seam.annotations.Scope;
import org.jboss.seam.core.Conversation;
import org.jboss.seam.international.StatusMessage.Severity;
import org.jboss.seam.security.Credentials;

import com.atosorigin.common.action.PaginatedListAction;
import com.atosorigin.common.action.PaginationData;
import com.atosorigin.common.constantes.Constantes;
import com.atosorigin.common.formvalidator.FormValidator;
import com.atosorigin.common.utils.GenericUtils;
import com.atosorigin.deri.common.parametrosPantalla.ParametrosOutAgenda;
import com.atosorigin.deri.model.murex.BuzonErrorInt;
import com.atosorigin.deri.model.murex.BuzonLogInt;
import com.atosorigin.deri.murex.errorescaptura.business.ErroresCapturaBo;
import com.atosorigin.deri.murex.errorescaptura.screen.ErroresCapturaPantalla;


@Name("erroresCapturaAction")
@Scope(ScopeType.CONVERSATION)
@FormValidator
public class ErroresCapturaAction extends PaginatedListAction{
	
	@In(value="#{erroresCapturaBo}")
	ErroresCapturaBo erroresCapturaBo;
	
	@In(create=true)
	ErroresCapturaPantalla erroresCapturaPantalla;
	
	@In(required=false)
	private ParametrosOutAgenda parametrosOutAgenda;
	
	private Boolean primeraVez = true;

	/** Los datos de paginación del 2º grid (erorres detalle) */
	public PaginationData paginationDataDelegate = new PaginationData();
	
	
	/** BuzonErrorInt seleccionado en la pantalla de detallede errores */
	@In(required=false,  value="buzonErrorIntDetalleSelec")
	protected BuzonErrorInt buzonErrorIntDetalleSelec;
	
	@In Credentials credentials;

	
	public void init(){
		
		if (primeraVez && parametrosOutAgenda != null && Constantes.MODO_AGE.equals(parametrosOutAgenda.getModo())) {

			paginationData.reset();
			if (erroresCapturaPantalla.getBuzonLogIntList()!=null) erroresCapturaPantalla.getBuzonLogIntList().clear();
			
			cargarDesdeAgenda(parametrosOutAgenda);
			
		}
	
	
		primeraVez = false;	
			
	}
	
	public void buscar() {

		paginationData.reset();
		refrescarLista();

		setPrimerAcceso(false);
	}
	
	public boolean buscarValidator(){
		if(!GenericUtils.isNullOrBlank(erroresCapturaPantalla.getFechaDesde()) && !GenericUtils.isNullOrBlank(erroresCapturaPantalla.getFechaHasta())){
			if(erroresCapturaPantalla.getFechaDesde().getTime() > erroresCapturaPantalla.getFechaHasta().getTime()){
				statusMessages.add(Severity.ERROR, "#{messages['avisocaptura.error.fecha']}");
				return false;
			}
		}
		if(!GenericUtils.isNullOrBlank(erroresCapturaPantalla.getOperDesde()) && !GenericUtils.isNullOrBlank(erroresCapturaPantalla.getOperHasta())){
			if(erroresCapturaPantalla.getOperDesde() > erroresCapturaPantalla.getOperHasta() ){
				statusMessages.add(Severity.ERROR, "#{messages['avisocaptura.errorOper']}");
				return false;
			}
		}
		if(!GenericUtils.isNullOrBlank(erroresCapturaPantalla.getEstructDesde()) && !GenericUtils.isNullOrBlank(erroresCapturaPantalla.getEstructHasta())){
			if(erroresCapturaPantalla.getEstructDesde() > erroresCapturaPantalla.getEstructHasta() ){
				statusMessages.add(Severity.ERROR, "#{messages['avisocaptura.errorEstruc']}");
				return false;
			}
		}
		
		return true;
	}
	
	public void trataSeleccionado(){
		List<BuzonErrorInt> beiList = new ArrayList<BuzonErrorInt>();
		beiList = erroresCapturaBo.obtenerListaErrores(erroresCapturaPantalla.getBuzonLogIntSelec().getContador());
		erroresCapturaPantalla.setBuzonErrorIntDetalleList(beiList);
		if (!beiList.isEmpty()){
		erroresCapturaPantalla.setBuzonErrorInt(beiList.get(0));
		}else{
			erroresCapturaPantalla.setBuzonErrorInt(null);
			statusMessages.add(Severity.INFO, "#{messages['errorcaptura.trataseleccionado']}");
		}
	}
	
	public void inicializar(){
		try{
		erroresCapturaBo.actualizaCodigoError(buzonErrorIntDetalleSelec.getId().getContador());
		erroresCapturaBo.actualizaCodError(buzonErrorIntDetalleSelec);
		}catch (Exception ex) { 
			statusMessages.add(Severity.ERROR, "#{messages['errorcaptura.actualizacion.error'] } #{buzonErrorIntDetalleSelec.getId().getNumerror()}");
		}
		
	}
	
	/*
	public void refrescarSeleccionado(){
		List<BuzonError> qb = avisosCapturaBo.obtenerDetalleBuzonErrSel(
				avisoCapturaPantalla.getBuzonErrorSeleccionado().getId().getDealType(), 
				avisoCapturaPantalla.getBuzonErrorSeleccionado().getId().getDealNumber(),
				avisoCapturaPantalla.getBuzonErrorSeleccionado().getId().getfInsercion(), 
				paginationDataDelegate);
		
		avisoCapturaPantalla.setBuzonErrorDetalleList(qb);
	}
	*/
	/*
	public String getAvisoError(String codigo){
		return avisosCapturaBo.getDescripcionAvisoError(codigo);
	}
	public String getTipoOperacion(String codigo){
		return avisosCapturaBo.getDescripcionTipoOperacion(codigo);
	}
	*/
	/*
	
	*/
	/*
	public void relanzar(){
		if(GenericUtils.isNullOrBlank(avisoCapturaPantalla.getBuzonErrorSeleccionado().getAuditData())){
			avisoCapturaPantalla.getBuzonErrorSeleccionado().setAuditData(new AuditData());
		}
		avisoCapturaPantalla.getBuzonErrorSeleccionado().getAuditData().setUsuarioUltimaModi(credentials.getUsername());
		avisosCapturaBo.relanzar(avisoCapturaPantalla.getBuzonErrorSeleccionado());
		refrescarLista();
	}
	*/
	@Override
	public List<?> getDataTableList() {
		return erroresCapturaPantalla.getBuzonLogIntList();
	}

	@Override
	protected void refreshListInternal() {
		setExportExcel(false);
		Long producto = new Long(0);
		String descripcion = Constantes.CADENA_VACIA;
		
		if(!GenericUtils.isNullOrBlank(this.erroresCapturaPantalla.getDescripcion())){
			descripcion =this.erroresCapturaPantalla.getDescripcion();
		producto = erroresCapturaBo.obtenerCodProducto(descripcion)	;		
		}else{
			producto = null;
		}
		
		erroresCapturaPantalla.setBuzonLogIntList(
				(List<BuzonLogInt>)erroresCapturaBo.buscarErroresCapturaM(
					producto,
					this.erroresCapturaPantalla.getOperDesde(),
					this.erroresCapturaPantalla.getOperHasta(),
					this.erroresCapturaPantalla.getTipo(),
					this.erroresCapturaPantalla.getEstructDesde(),
					this.erroresCapturaPantalla.getEstructHasta(),
					this.erroresCapturaPantalla.getFechaDesde(),
					this.erroresCapturaPantalla.getFechaHasta(),
					paginationData));
	}

	@Override
	public void refrescarListaExcel() {
		setExportExcel(true);	
	}

	@SuppressWarnings("unchecked")
	@Override
	public void setDataTableList(List<?> dataTableList) {
		erroresCapturaPantalla.setBuzonLogIntList((List<BuzonLogInt>) dataTableList);
	}





	protected void cargarDesdeAgenda(ParametrosOutAgenda parametrosOutAgenda) {
		setExportExcel(false);
		
		erroresCapturaPantalla.setBuzonLogIntList(
				(List<BuzonLogInt>)erroresCapturaBo.buscarErroresCapturaMAgenda(
						parametrosOutAgenda.getFechatraIni(),
						parametrosOutAgenda.getCodevent(),
						parametrosOutAgenda.getEstadoEv(),
						paginationData));
	}

	public void salir(){
		Conversation conversacion = Conversation.instance();
		//Volvemos a la anterior conversación
		if(conversacion.isNested()){
			conversacion.redirectToParent();
		} else {
			redirectToURL("/home.seam");
			conversacion.endAndRedirect();
		}
	}
	

}
