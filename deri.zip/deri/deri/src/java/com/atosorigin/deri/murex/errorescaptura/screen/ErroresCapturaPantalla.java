package com.atosorigin.deri.murex.errorescaptura.screen;

import java.util.Date;
import java.util.List;

import org.jboss.seam.ScopeType;
import org.jboss.seam.annotations.Name;
import org.jboss.seam.annotations.Out;
import org.jboss.seam.annotations.Scope;
import org.jboss.seam.annotations.datamodel.DataModel;
import org.jboss.seam.annotations.datamodel.DataModelSelection;

import com.atosorigin.deri.model.murex.BuzonErrorInt;
import com.atosorigin.deri.model.murex.BuzonLogInt;


/**
 * Contiene los datos de pantalla necesarios para el caso de uso captura de errores murex.
 */
@Name("erroresCapturaPantalla")
@Scope(ScopeType.CONVERSATION)
public class ErroresCapturaPantalla {
	
	protected String descripcion;
	protected Long operDesde;
	protected Long operHasta;
	protected Long estructDesde;
	

	protected Long estructHasta;
	protected Date fechaDesde;
	protected Date fechaHasta;
	protected String tipo;
	protected BuzonErrorInt buzonErrorInt;
	

	@DataModel(value="listaDtBuzonLogInt")
	protected List<BuzonLogInt> buzonLogIntList;
	
	/** BuzonLogInt seleccionado en el grid */
	@DataModelSelection(value="listaDtBuzonLogInt")
	@Out(value="buzonLogIntSelec", required=false)
	protected BuzonLogInt buzonLogIntSelec;
		
	@DataModel(value="listaDtBuzonErrorIntDetalle")
	protected List<BuzonErrorInt> buzonErrorIntDetalleList;

	

	@DataModelSelection(value="listaDtBuzonErrorIntDetalle")
	@Out(value="buzonErrorIntDetalleSelec", required=false)
	protected BuzonErrorInt buzonErrorIntDetalleSelec;
	
	

	public Date getFechaDesde() {
		return fechaDesde;
	}

	public void setFechaDesde(Date fechaDesde) {
		this.fechaDesde = fechaDesde;
	}

	public Date getFechaHasta() {
		return fechaHasta;
	}

	public void setFechaHasta(Date fechaHasta) {
		this.fechaHasta = fechaHasta;
	}

	public String getDescripcion() {
		return descripcion;
	}

	public void setDescripcion(String descripcion) {
		this.descripcion = descripcion;
	}

	public Long getOperDesde() {
		return operDesde;
	}

	public void setOperDesde(Long operDesde) {
		this.operDesde = operDesde;
	}

	public Long getOperHasta() {
		return operHasta;
	}

	public void setOperHasta(Long operHasta) {
		this.operHasta = operHasta;
	}
	public Long getEstructDesde() {
		return estructDesde;
	}

	public void setEstructDesde(Long estructDesde) {
		this.estructDesde = estructDesde;
	}

	public Long getEstructHasta() {
		return estructHasta;
	}

	public void setEstructHasta(Long estructHasta) {
		this.estructHasta = estructHasta;
	}

	
	public String getTipo() {
		return tipo;
	}

	public void setTipo(String tipo) {
		this.tipo = tipo;
	}
	public List<BuzonLogInt> getBuzonLogIntList() {
		return buzonLogIntList;
	}

	public void setBuzonLogIntList(List<BuzonLogInt> buzonLogIntList) {
		this.buzonLogIntList = buzonLogIntList;
	}

	
	public void setBuzonLogIntSelec(BuzonLogInt buzonLogIntSelec) {
		this.buzonLogIntSelec = buzonLogIntSelec;
	}

	
	public List<BuzonErrorInt> getBuzonErrorIntDetalleList() {
		return buzonErrorIntDetalleList;
	}

	public void setBuzonErrorIntDetalleList(List<BuzonErrorInt> buzonErrorIntDetalleList) {
		this.buzonErrorIntDetalleList = buzonErrorIntDetalleList;
	}

	public BuzonErrorInt getBuzonErrorIntDetalleSelec() {
		return buzonErrorIntDetalleSelec;
	}

	public void setBuzonErrorIntDetalleSelec(BuzonErrorInt buzonErrorIntDetalleSelec) {
		this.buzonErrorIntDetalleSelec = buzonErrorIntDetalleSelec;
	}

	public BuzonLogInt getBuzonLogIntSelec() {
		return buzonLogIntSelec;
	}

	
	public BuzonErrorInt getBuzonErrorInt() {
		return buzonErrorInt;
	}

	public void setBuzonErrorInt(BuzonErrorInt buzonErrorInt) {
		this.buzonErrorInt = buzonErrorInt;
	}

}
