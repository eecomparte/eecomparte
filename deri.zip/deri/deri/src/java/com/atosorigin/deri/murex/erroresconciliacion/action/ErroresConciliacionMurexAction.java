package com.atosorigin.deri.murex.erroresconciliacion.action;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.jboss.seam.ScopeType;
import org.jboss.seam.annotations.In;
import org.jboss.seam.annotations.Name;
import org.jboss.seam.annotations.Out;
import org.jboss.seam.annotations.Scope;
import org.jboss.seam.annotations.datamodel.DataModel;
import org.jboss.seam.annotations.datamodel.DataModelSelection;

import com.atosorigin.common.action.ModoPantalla;
import com.atosorigin.common.action.PaginatedListAction;
import com.atosorigin.common.constantes.Constantes;
import com.atosorigin.common.utils.GenericUtils;
import com.atosorigin.deri.model.kondor.TipoErroresConciliacion;
import com.atosorigin.deri.model.murex.ErroresConciliacionAgrupacion;
import com.atosorigin.deri.murex.erroresconciliacion.business.ErroresConciliacionMurexBo;



/**
 * Clase action listener para el caso de uso de Errores de Conciliacion.
 */
@Name("erroresConciliacionMurexAction")
@Scope(ScopeType.CONVERSATION)
public class ErroresConciliacionMurexAction extends PaginatedListAction {
	
	//
	// Campos de la búsqueda
	//

	String clasificacion;

	protected Date fechaProceso;
	protected String indicActividad;
	String idOperacion;

	/** codigoError. Criterio de búsqueda de Errores de Conciliacion  */
	protected TipoErroresConciliacion codigoError;
	
	/** dealNumDesde. Criterio de búsqueda de Errores de Conciliacion  */
	protected Long dealNumDesde;
	
	/** dealNumHasta. Criterio de búsqueda de Errores de Conciliacion  */
	protected Long dealNumHasta;
	
	/** numOperacionDesde. Criterio de búsqueda de Errores de Conciliacion  */
	protected Long numOperacionDesde;
	
	/** numOperacionHasta. Criterio de búsqueda de Errores de Conciliacion  */
	protected Long numOperacionHasta;
	

	/**
	 * Inyección del bean de Spring "erroresConciliacionBo" que contiene los tipos de error
	 * para el caso de uso Errores de Conciliación.
	 */
	@In("#{erroresConciliacionMurexBo}")
	protected ErroresConciliacionMurexBo erroresConciliacionMurexBo;

    @Out(required=false)
    protected ErroresConciliacionAgrupacion errorSeleccionado;	
    
	List<TipoErroresConciliacion> tipoErroresConciliacionList;

	public List<TipoErroresConciliacion> getTipoErroresConciliacionList() {
		return tipoErroresConciliacionList;
	}

	
	
	public void setTipoErroresConciliacionList(
			List<TipoErroresConciliacion> tipoErroresConciliacionList) {
		this.tipoErroresConciliacionList = tipoErroresConciliacionList;
	}

	/** Lista de datos para el grid. */
	@DataModel(value ="listaDtConcierrMurexExcel")
	protected List<ErroresConciliacionAgrupacion> listaConcierrExcel;
	
	@DataModelSelection(value="listaDtConcierrMurexExcel")
	protected ErroresConciliacionAgrupacion datmo;

	/** Lista de datos para el grid. */
	@DataModel(value= "erroresConciliacionAgrupList")
	protected List<ErroresConciliacionAgrupacion> erroresConciliacionAgrupList;

	/** Tipo de documento seleccionado en el grid */
	@DataModelSelection(value= "erroresConciliacionAgrupList")
    @Out(required=false)
    protected ErroresConciliacionAgrupacion errorConciliacionAgrupacionSelect;	
	
	
	
	public ErroresConciliacionAgrupacion getErrorConciliacionAgrupacionSelect() {
		return errorConciliacionAgrupacionSelect;
	}


	public void setErrorConciliacionAgrupacionSelect(
			ErroresConciliacionAgrupacion errorConciliacionAgrupado) {
		this.errorConciliacionAgrupacionSelect = errorConciliacionAgrupado;
	}


	public TipoErroresConciliacion getCodigoError() {
		return codigoError;//.getTipoError();
	}

	public void setCodigoError(TipoErroresConciliacion codigoError) {
		this.codigoError = codigoError;
	}	

	public Long getDealNumDesde() {
		return dealNumDesde;
	}

	public void setDealNumDesde(Long dealNumDesde) {
		this.dealNumDesde = dealNumDesde;
	}	

	public Long getDealNumHasta() {
		return dealNumHasta;
	}

	public void setDealNumHasta(Long dealNumHasta) {
		this.dealNumHasta = dealNumHasta;
	}	

	public Date getFechaProceso() {
		return fechaProceso;
	}

	public void setFechaProceso(Date fechaProceso) {
		this.fechaProceso = fechaProceso;
	}	

	public String getIndicActividad() {
		return indicActividad;
	}

	public void setIndicActividad(String indicActividad) {
		if (!GenericUtils.isNullOrBlank(indicActividad)) {
	//		setCodigoError(null);		
			}
		this.indicActividad = indicActividad;
	}
	
	public Long getnumOperacionDesde() {
		return numOperacionDesde;
	}

	public void setnumOperacionDesde(Long numOperacionDesde) {
		this.numOperacionDesde = numOperacionDesde;
	}	

	public Long getnumOperacionHasta() {
		return numOperacionHasta;
	}

	public void setnumOperacionHasta(Long numOperacionHasta) {
		this.numOperacionHasta = numOperacionHasta;
	}	

	//---****************************************************
	/**
	 * Actualiza la lista del grid de Errores de Conciliación.
	 */
	public void buscar() {
		paginationData.reset();
		refrescarLista();	
//		final List<ErroresConciliacionAgrupacion> lista = getDataTableList();
//		for (ErroresConciliacionAgrupacion co: lista) {
//			erroresConciliacionMurexBo.recargar(co);
//		}
 
		setPrimerAcceso(false);
	}

	@Override
	public List<ErroresConciliacionAgrupacion> getDataTableList() {
		return erroresConciliacionAgrupList;
	}

	public List<ErroresConciliacionAgrupacion> getErroresConciliacionAgrupList() {
		return erroresConciliacionAgrupList;
	}

	
	@Override
	protected void refreshListInternal() {

		setExportExcel(false);
		setDataTableList(erroresConciliacionMurexBo
				.buscarErroresConciliacionAgrupados(getFechaProceso(), "MU",
						getIndicActividad(), getnumOperacionDesde(),
						getnumOperacionHasta(), getCodigoError(),
						getDealNumDesde(), getDealNumHasta(),
						paginationData));
		// recorremos la lista para que agrupe los registros del mismo dealnumber (tanto si tienen informado el núm de operación o no)
	}

	@Override
	public void refrescarListaExcel() {
		
		setExportExcel(true);
		List<ErroresConciliacionAgrupacion> listaAux = new ArrayList<ErroresConciliacionAgrupacion>();
		listaAux = erroresConciliacionMurexBo
		.buscarErroresConciliacionAgrupados(getFechaProceso(), "MU",
				getIndicActividad(), getnumOperacionDesde(),
				getnumOperacionHasta(), getCodigoError(),
				getDealNumDesde(), getDealNumHasta(),
				paginationData.getPaginationDataForExcel());
		
		if(listaConcierrExcel == null){
			listaConcierrExcel = new ArrayList<ErroresConciliacionAgrupacion>();
		}
		
		listaConcierrExcel.clear();
		for (ErroresConciliacionAgrupacion error : listaAux) 
		{	
			if(!GenericUtils.isNullOrBlank(getIndicActividad())){
				error.setIndicActividad(getIndicActividad());
			}
			
			if(GenericUtils.isNullOrBlank(getnumOperacionDesde()) && GenericUtils.isNullOrBlank(getnumOperacionHasta())){
				error.setNumeroOperacion(getnumOperacionDesde());
			}

			listaConcierrExcel.addAll( 
				erroresConciliacionMurexBo.recuperarErroresConciliacionDesdeAgrupado(
						 error,
						paginationData.getPaginationDataForExcel()));

//versio nova		
//			listaConcierrExcel.addAll( 
//					erroresConciliacionMurexBo.recuperarErroresConciliacionDesdeAgrupadoV2(
//							 error,
//							paginationData.getPaginationDataForExcel()));

		
		}
		
	}



	@Override
	@SuppressWarnings("unchecked")
	public void setDataTableList(List<?> dataTableList) {
		erroresConciliacionAgrupList = (List<ErroresConciliacionAgrupacion>) dataTableList;
	}
	
	public String getDescripTipoOper(){
		return null;
 	}
	
	
	/**
	 * Visualizamos un Error de Conciliación.
	 * 
	 */
	public String ver(ErroresConciliacionAgrupacion errMeu) {
		if (errorSeleccionado==null) 
			errorSeleccionado = new ErroresConciliacionAgrupacion();
		errorSeleccionado.setId(errMeu.getId());
		errorSeleccionado.setDealNumber(errMeu.getDealNumber());
		errorSeleccionado.setDealType(errMeu.getDealType());
		errorSeleccionado.setTipoConciliacion(errMeu.getTipoConciliacion());
		errorSeleccionado.setfContratacionOperacion(errMeu.getfContratacionOperacion());
		
		if(!GenericUtils.isNullOrBlank(getIndicActividad())){
			errorSeleccionado.setIndicActividad(getIndicActividad());
		}else
		{
			errorSeleccionado.setIndicActividad(errMeu.getIndicActividad());
		}
		
		if(GenericUtils.isNullOrBlank(getnumOperacionDesde()) && GenericUtils.isNullOrBlank(getnumOperacionHasta())){
			errorSeleccionado.setNumeroOperacion(getnumOperacionDesde());
		}else {
			errorSeleccionado.setNumeroOperacion(errMeu.getNumeroOperacion());
		}
		
		if(errorSeleccionado.getNumeroOperacion()==null){
			errorSeleccionado.setNumeroOperacion(errMeu.getNumeroOperacion());
		}

//			errorSeleccionado = getErrorConciliacionAgrupacionSelect();
//			errorSeleccionado.setIndicActividad(getIndicActividad());
		
		setModoPantalla(ModoPantalla.INSPECCION);
		return Constantes.SUCCESS;
	}
	
	public void tiposErroresConciliacionSelect(){
		this.tipoErroresConciliacionList = erroresConciliacionMurexBo.obtenerTiposErroresConciliacionSelect(getFechaProceso(),"MU",getIndicActividad());
	}
	
	public void obtenerTiposErroresConciliacionSelect() {
		this.tipoErroresConciliacionList = erroresConciliacionMurexBo.obtenerTiposErroresConciliacionSelect(getFechaProceso(),"MU",getIndicActividad());
	}
	
	public void setNumOper(){
		if(!GenericUtils.isNullOrBlank(getnumOperacionDesde()) &&  GenericUtils.isNullOrBlank(getnumOperacionHasta()))
			setnumOperacionHasta(getnumOperacionDesde());
	}
	public void setDealNumber(){
		if(!GenericUtils.isNullOrBlank(getDealNumDesde()) &&  GenericUtils.isNullOrBlank(getDealNumHasta()))
			setDealNumHasta(getDealNumDesde());
	}
	
	public void init(){
		if(GenericUtils.isNullOrBlank(getFechaProceso()))
		this.setFechaProceso(erroresConciliacionMurexBo.obtenerFechaSistema());
	}

	
}
