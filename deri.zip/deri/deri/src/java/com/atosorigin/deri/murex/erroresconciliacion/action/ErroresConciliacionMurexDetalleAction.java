package com.atosorigin.deri.murex.erroresconciliacion.action;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;

import org.jboss.seam.ScopeType;
import org.jboss.seam.annotations.Factory;
import org.jboss.seam.annotations.In;
import org.jboss.seam.annotations.Name;
import org.jboss.seam.annotations.Out;
import org.jboss.seam.annotations.Scope;
import org.jboss.seam.annotations.datamodel.DataModel;
import org.jboss.seam.annotations.datamodel.DataModelSelection;
import org.jboss.seam.international.StatusMessage.Severity;

import com.atosorigin.common.action.PaginatedListAction;
import com.atosorigin.common.constantes.Enumeraciones.TipoDesglose;
import com.atosorigin.common.utils.GenericUtils;
import com.atosorigin.deri.adminoper.admconfirmaciones.business.ConfirmacionOperacionesBo;
import com.atosorigin.deri.model.contrapartida.Contrapartida;
import com.atosorigin.deri.model.gestionoperaciones.Operacion;
import com.atosorigin.deri.model.gestionoperaciones.OperacionId;
import com.atosorigin.deri.model.murex.ErroresConciliacionAgrupacion;
import com.atosorigin.deri.model.murex.ErroresConciliacionDesglose;
import com.atosorigin.deri.murex.erroresconciliacion.business.ErroresConciliacionMurexBo;
import com.atosorigin.deri.util.MessageBoxAction;
import com.atosorigin.deri.util.MsgBoxAction;



/**
 * Clase action listener para el caso de uso de Errores de Conciliacion.
 */
@Name("erroresConciliacionMurexDetalleAction")
@Scope(ScopeType.CONVERSATION)
public class ErroresConciliacionMurexDetalleAction extends PaginatedListAction {

	public static class ValuePair{
		private String campo;
		private String valor;
		public String getCampo() {
			return campo;
		}
		public void setCampo(String campo) {
			this.campo = campo;
		}
		public String getValor() {
			return valor;
		}
		public void setValor(String valor) {
			this.valor = valor;
		}
		public ValuePair(String campo, String valor) {
			super();
			this.campo = campo;
			this.valor = valor;
		}
		
	}
	/**
	 * Inyección del bean de Spring "erroresConciliacionBo" que contiene los tipos de error
	 * para el caso de uso Errores de Conciliación.
	 */
	@In("#{erroresConciliacionMurexBo}")
	protected ErroresConciliacionMurexBo erroresConciliacionMurexBo;
	
   @In(value="errorSeleccionado", required = false)
    protected ErroresConciliacionAgrupacion errorConciliacionAgrupacion;	

	/** Lista de datos para el grid. */
	@DataModel(value ="listaDtErroresConciliacionMurex")
	protected List<ErroresConciliacionAgrupacion> erroresConciliacionList;
	
	@DataModel("listaCamposMurex")
	private List<ErroresConciliacionDesglose> listaCamposMurex;
	
	@DataModel("listaCamposBo")
	private List<ErroresConciliacionDesglose> listaCamposBo;
	
	
	
	@DataModelSelection("listaDtErroresConciliacionMurex") 
	private ErroresConciliacionAgrupacion errorActual;

	
	@Out(required = false, value = "errMurexMessageBoxAction")
	private MessageBoxAction messageBoxActionMO;
	
	private String onComplete;
	private String motivoDescarte;
	private int primerPase = 0;

	private HashSet<ErroresConciliacionAgrupacion> erroresSeleccionados = new HashSet<ErroresConciliacionAgrupacion>();
	
	private Boolean primeraEjecucionInit=null;
	
	@In(create = true)
	MsgBoxAction msgBoxAction;
	
	@Out(required = false, value = "erroresConciliacionMurexDetalleMessageBoxAction")
	private MessageBoxAction messageBoxErroresConciliacionMurexDetalleAction;
	
	@In("#{admconfirmacionesBo}")
	protected ConfirmacionOperacionesBo admConfirmacionesBo;
	
	@Out
	public Boolean getSelectedRow(){
		return erroresSeleccionados.contains(errorActual);
	}
	
	public void setSelectedRow(Boolean selected){
		if(selected){
			erroresSeleccionados.add(errorActual);
		}
		else{
			erroresSeleccionados.remove(errorActual);
		}
	}
	
	public void seleccionarError(){
		//erroresSeleccionados.add(errorActual);
	}

	@Override
	public List<ErroresConciliacionAgrupacion> getDataTableList() {
		// TODO Auto-generated method stub
		return erroresConciliacionList;
	}

	@Override
	@Factory(value="listaDtErroresConciliacionMurex")
	public void refreshListInternal() {
		erroresSeleccionados.clear();
		setExportExcel(false);
		erroresConciliacionList = erroresConciliacionMurexBo.recuperarErroresConciliacionDesdeAgrupado(errorConciliacionAgrupacion, paginationData);
		primerPase = 0;
		listaCamposMurex = null;
		listaCamposBo=null;
	}

	@Factory("listaCamposMurex")
	public void refrescarListaCamposKondor(){
		if(erroresConciliacionList!=null && primerPase < 2){
			errorActual =this.erroresConciliacionList.get(0);
			primerPase++;
		}
		if(errorActual==null){
			listaCamposMurex= Collections.EMPTY_LIST;
		}
		else{
			listaCamposMurex = erroresConciliacionMurexBo.getDesglose(errorActual,TipoDesglose.OTROS);
		}
		
	}
	@Factory("listaCamposBo")
	public void refrescarListaCamposBO(){
		if(erroresConciliacionList!=null && primerPase < 2){
			errorActual =this.erroresConciliacionList.get(0);
			primerPase++;
		}
		if(errorActual==null){
			listaCamposBo= Collections.EMPTY_LIST;
		}
		else{
			listaCamposBo = erroresConciliacionMurexBo.getDesglose(errorActual,TipoDesglose.DERI);
		}
		
	}
/*	private List<ValuePair> parseValuePairs(String campos, String contenido) {
		List<ValuePair> result = new ArrayList();
		if(campos!=null && contenido!=null){
			String[] camposArray = campos.split(";");
			String[] contenidoArray = contenido.split(";");
			int index=0;
			for (String campo : camposArray) {
				if(index<=contenidoArray.length){
					String valor =contenidoArray[index]; 
					ValuePair pair = new ValuePair(campo, valor);
					result.add(pair);
				}
			}
		}
		return result;
	}*/

	@Override
	public void refrescarListaExcel() {
		setExportExcel(true);
		erroresConciliacionList = 
			erroresConciliacionMurexBo.recuperarErroresConciliacionDesdeAgrupado(
					errorConciliacionAgrupacion,
					paginationData.getPaginationDataForExcel());
	}

	public String getDescripTipoOper(){
		return null;
 	}

	@Override
	public void setDataTableList(List<?> dataTableList) {
		// TODO Auto-generated method stub
	}
	
	public void changeRow(){
		listaCamposMurex=null;
		listaCamposBo=null;
		refrescarListaCamposBO();
		refrescarListaCamposKondor();
	}

	public void onChangeIndActividad(){
		erroresConciliacionList=null;
		errorActual=null;
		listaCamposMurex=null;
		listaCamposBo=null;
		
	}
	public String getRowClasses(){
		StringBuilder builder = new StringBuilder();
		int i=0;
		for (ErroresConciliacionAgrupacion errores : erroresConciliacionList) {
			if(i>0){
				builder.append(",");
			}
			if(errores.equals(errorActual)){
				builder.append("SelectedRow");
			}
			else{
				if(i%2==0){
					builder.append("oddRow");
				}
				else{
					builder.append("evenRow");
				}
			}
			i++;
		}
		return builder.toString();
	}
	
	public void activar(){
		if (motivoDescarte ==null){

			if (messageBoxActionMO==null){
				messageBoxActionMO = new MessageBoxAction();
			}
				
			messageBoxActionMO.init("erroresConciliacionMurex.error.motivoSinInformar", "erroresConciliacionMurexDetalleAction.activarNow()",
					"erroresConciliacionMurexDetalleAction.voidFunction()","helperPanel");	
		}else{
			activarNow();
		}
		
	}
	
	public void voidFunction(){
		msgBoxAction.voidFunction();
	}
	
	public void activarNow(){
			if (motivoDescarte!=null){
				motivoDescarte = motivoDescarte.replaceAll("\r","");
			if (motivoDescarte.length()>250)
				statusMessages.add(Severity.ERROR,"#{messages['erroresConciliacionMurex.error.longExcedida']}");
			else{
				erroresConciliacionMurexBo.actualizarErroresConciliacionActivos(new ArrayList<ErroresConciliacionAgrupacion>(erroresSeleccionados), motivoDescarte);			
				refrescarLista();
				setMotivoDescarte(null);
			}
			
			}else{
				erroresConciliacionMurexBo.actualizarErroresConciliacionActivos(new ArrayList<ErroresConciliacionAgrupacion>(erroresSeleccionados), motivoDescarte);			
				refrescarLista();
				setMotivoDescarte(null);	
			}
	}

	

	public Boolean isActivarDisabled(){
		return erroresSeleccionados.isEmpty();
	}
	public List<ErroresConciliacionAgrupacion> getErroresConciliacionList() {
		return erroresConciliacionList;
	}
	public void setErroresConciliacionList(
			List<ErroresConciliacionAgrupacion> erroresConciliacionList) {
		this.erroresConciliacionList = erroresConciliacionList;
	}
	public void mostrarMotivo(){
		
		setMotivoDescarte(null);
//		if (Constantes.CONTRAPA_GRUPOBAN_CLIENTE.equalsIgnoreCase(contrapa.getGrupoBancario().getId())){
//			statusMessages.add(Severity.ERROR,"#{messages['admconfirmaciones.error.contrapanobanco']}");
//			setOnCompleteNo();
//		}else{
//			setOnCompleteSi();
//		}
		setOnCompleteSi();
	}
	
	public void setOnCompleteNo() {
		setOnComplete("$('motivoPanel').component.hide();return false;");
	}

	public void setOnCompleteSi() {
		setOnComplete("$('motivoPanel').component.show();");
	}
	public String getOnComplete() {
		return onComplete;
	}
	public void setOnComplete(String onComplete) {
		this.onComplete = onComplete;
	}
	public String getMotivoDescarte() {
		return motivoDescarte;
	}
	public void setMotivoDescarte(String motivoDescarte) {
		this.motivoDescarte = motivoDescarte;
	}
	public int getPrimerPase() {
		return primerPase;
	}
	public void setPrimerPase(int primerPase) {
		this.primerPase = primerPase;
	}

	public void initDetalle(){
		if (primeraEjecucionInit == null) {
			primeraEjecucionInit=true;
		} 
		else{
			primeraEjecucionInit = false;
		}
		
		if(null==messageBoxErroresConciliacionMurexDetalleAction){
			messageBoxErroresConciliacionMurexDetalleAction = new MessageBoxAction();
		}
		
		if(primeraEjecucionInit){
			OperacionId opId = new OperacionId();
			opId.setNumeroOperacion(errorConciliacionAgrupacion.getNumeroOperacion());
			opId.setFechaContratacion(errorConciliacionAgrupacion.getfContratacionOperacion());
			
			Operacion ope = admConfirmacionesBo.buscarOperacion(opId);
			Contrapartida contrapartida = (Contrapartida) ope.getContrapartida();
			if (null!=contrapartida && !GenericUtils.isNullOrBlank(contrapartida.getIndBloqueo()) && "S".equalsIgnoreCase(contrapartida.getIndBloqueo())){
				abrirPopUpContrapartidaBloqueada();
			}
			
		}
	}

	private void abrirPopUpContrapartidaBloqueada(){
		messageBoxErroresConciliacionMurexDetalleAction.init("erroresConciliacionMurex.messages.contrapartida.bloqueada.texto", "erroresConciliacionMurexDetalleAction.voidFunction()",null,"messageBoxPanelContrapa");
	}
	
}
