package com.atosorigin.deri.murex.lanzamiento.action;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashSet;
import java.util.List;

import javax.persistence.RollbackException;


import org.jboss.seam.ScopeType;
import org.jboss.seam.annotations.In;
import org.jboss.seam.annotations.Name;
import org.jboss.seam.annotations.Out;
import org.jboss.seam.annotations.Scope;
import org.jboss.seam.core.Conversation;
import org.jboss.seam.international.StatusMessage;
import org.jboss.seam.international.StatusMessage.Severity;

import com.atosorigin.common.action.PaginatedListAction;
import com.atosorigin.common.constantes.Constantes;
import com.atosorigin.common.utils.GenericUtils;
import com.atosorigin.deri.common.dbLock.DbLockService;
import com.atosorigin.deri.liquidaciones.business.LiquidacionesBo;
import com.atosorigin.deri.model.kondor.BuzonDeri;
import com.atosorigin.deri.model.liquidaciones.Liquidacion;
import com.atosorigin.deri.model.murex.BuzonLogInt;
import com.atosorigin.deri.model.murex.VistaBuzonLogInt;
import com.atosorigin.deri.murex.lanzamiento.screen.LanzamientoIntMurexPantalla;
import com.atosorigin.deri.util.MessageBoxAction;
import com.atosrigin.deri.murex.lanzamientointegracion.business.LanzamientoIntMurexBo;

/**
 * Clase action listener para el caso de uso de lanzamiento de integración.
 */
@Name("lanzamientoIntMurexAction")
@Scope(ScopeType.CONVERSATION)
public class LanzamientoIntMurexAction extends PaginatedListAction {

	/**
	 * Inyección del bean de Spring "lanzamientoIntegracionBo" que contiene los métodos de negocio
	 * para el caso de uso lanzamiento integración.
	 */
	@In("#{lanzamientoIntMurexBo}")
	protected LanzamientoIntMurexBo lanzamientoIntMurexBo;

	@In("#{liquidacionesBo}")
	protected LiquidacionesBo liquidacionesBo;
	
	/** Inyección del servicio que gestiona los bloqueos de registros en base de datos */
	@In(create = true)
	protected DbLockService dbLockService;	
	
	
	@In(create=true)
	protected LanzamientoIntMurexPantalla lanzamientoIntMurexPantalla;
	
	@In(required = false, value = "buzonSeleccionado")
	protected BuzonLogInt buzonSeleccionado;
	
	@Out(required = false, value = "lanzaMxMessageBoxAction")
	private MessageBoxAction messageBoxActionMO;
	
	protected  List<BuzonLogInt>  lanzamientosTotal;
	protected  List<VistaBuzonLogInt>  lanzamientosTotalAgrupado;
	private boolean bmn = false;
	private boolean migracion = false;
	
	public void onMessageBoxSalirOk(){
		Conversation conversacion = Conversation.instance();
//		//Volvemos al anterior
//		conversacion.redirectToParent();
		redirectToURL("/home.seam");
//		conversacion.endBeforeRedirect();
		conversacion.endAndRedirect();
	
	}

	
	/** Carga los valores de inicialización del formulario */ 
	public void newFormInstance() {
		
//		if(lanzamientoIntMurexBo.isAvisosCodigoEvento6018()){
//			
//			if (messageBoxActionMO==null){
//				messageBoxActionMO = new MessageBoxAction();
//			}
//			messageBoxActionMO.init("aceptar.lanzamientopendiente.errorfin", "lanzamientoIntMurexAction.onMessageBoxSalirOk()",
//					null,"helperPanel");	
//
////			statusMessages.add(StatusMessage.Severity.ERROR, "#{messages['aceptar.lanzamientopendiente.errorfin']}");
//		}else{
		
			this.lanzamientoIntMurexPantalla.setFecha(new Date()); // Cargamos con la fecha actual
			this.lanzamientoIntMurexPantalla.setOperaciones(getOperacionesPendientes()); // Cargamos número operaciones
			this.lanzamientoIntMurexPantalla.setEstructuras(getEstructurasPendientes());
			if (GenericUtils.isNullOrBlank(buzonSeleccionado)){
				lanzamientosTotal = getRegistrosPendientes();	
			}else{
				lanzamientosTotal = getRegistroSeleccionado(buzonSeleccionado);
			}
			
			this.setBmn(false);
			this.setMigracion(false);
			refrescarLista();

//		}
		
	}



	public void newFormInstanceBMN() {
		
		
//		if(lanzamientoIntMurexBo.isAvisosCodigoEvento6018()){
//			
//			if (messageBoxActionMO==null){
//				messageBoxActionMO = new MessageBoxAction();
//			}
//			messageBoxActionMO.init("aceptar.lanzamientopendiente.errorfin", "lanzamientoIntMurexAction.onMessageBoxSalirOk()",
//					null,"helperPanel");	
//
////			statusMessages.add(StatusMessage.Severity.ERROR, "#{messages['aceptar.lanzamientopendiente.errorfin']}");
//		}else{

			this.lanzamientoIntMurexPantalla.setFecha(new Date()); // Cargamos con la fecha actual
			this.lanzamientoIntMurexPantalla.setOperaciones(getOperacionesPendientesBMN()); // Cargamos número operaciones
			this.lanzamientoIntMurexPantalla.setEstructuras(getEstructurasPendientesBMN());
			lanzamientosTotal = getRegistrosPendientesBMN();
			this.setBmn(true);
			this.setMigracion(false);
			refrescarLista();
			
//		}
	}

	public void newFormInstanceMigra() {
		
//		if(lanzamientoIntMurexBo.isAvisosCodigoEvento6018()){
//			
//			if (messageBoxActionMO==null){
//				messageBoxActionMO = new MessageBoxAction();
//			}
//			messageBoxActionMO.init("aceptar.lanzamientopendiente.errorfin", "lanzamientoIntMurexAction.onMessageBoxSalirOk()",
//					null,"helperPanel");	
//
////			statusMessages.add(StatusMessage.Severity.ERROR, "#{messages['aceptar.lanzamientopendiente.errorfin']}");
//		}else{

			this.lanzamientoIntMurexPantalla.setFecha(new Date()); // Cargamos con la fecha actual
			this.lanzamientoIntMurexPantalla.setOperaciones(getOperacionesPendientesMigra()); // Cargamos número operaciones
			this.lanzamientoIntMurexPantalla.setEstructuras(getEstructurasPendientesMigra());
			lanzamientosTotal = getRegistrosPendientesMigra();
			this.setBmn(false);
			this.setMigracion(true);
			refrescarLista();

//		}
	}
	
	
	
	
	//	SMM 12/04/2017 Codigo Naranja
	//1 - Si tiene liquidaciones validadas.
	//2 - Si tiene liquidaciones liquidadas.(en el caso de cancelaciones solo con fecha del dia)
	//3 - Si tiene liquidaciones validadas y liquidadas ((en el caso de cancelaciones solo con fecha del dia).
	//0 - Resto de casos, valor por defecto.
	
	// 1 - M  Aviso desvalidar liquidacion
	// 1 - NCP desvalidar directamente liquidacion
	// 2 - N  Aviso para integrar
	// 2 - CP  Aviso para integrar
	// 3 - NCP  Aviso para integrar si si desvalidar directamente
	// 3 - M  Aviso desvalidar liquidacion validadas
	
	public void tratamientoNaranja(){
		boolean unico = false;
		if (listasSeleccionadas!=null && !listasSeleccionadas.isEmpty() && listasSeleccionadas.size()==1){
			BuzonLogInt buzontmp = null;
			for (BuzonLogInt buzon : listasSeleccionadas) {
				buzontmp = buzon;
			}
			if (buzontmp.getCodigoNaranja()==0 || !buzontmp.isIntegrable() ){
				actualizarAgenda();
			}else{

			if(lanzamientoIntMurexBo.isAvisosCodigoEvento6018()){
				/** Avisamos de que hay un lanzamiento pendiente de procesar */
				statusMessages.add(StatusMessage.Severity.ERROR, "#{messages['aceptar.lanzamientopendiente.error']}");
				refrescarPantalla();
				return;
			}
			
			//UNICO NARANJA	
				if (buzontmp.getCodigoNaranja()==1){
			
					if (buzontmp.getIndicadorSituacion().equalsIgnoreCase("M")){
						//Aviso desvalidar
						avisoDesvalidar();
						
					}else{
						//Ya llama a la integracion 
						onMessageBoxDesvalidar();
					}
				
				
			}else if (buzontmp.getCodigoNaranja()==2){
				if (GenericUtils.in(buzontmp.getIndicadorSituacion(), "N","C","P")){
					//Aviso integrar
					avisoLiquidadas();
				}else{
					onMessageBoxIntegrar();
				}
			
			}else if (buzontmp.getCodigoNaranja()==3){
				if (GenericUtils.in(buzontmp.getIndicadorSituacion(), "N","C","P")){
					avisoLiquidadasVal();
				}else{
					//Aviso desvalidar
					avisoDesvalidar();
				}
				
			}
			
			
			}
			
			
		}else{
			actualizarAgenda();
		}
		
//		refrescarPantalla();
	}
	
	
	
	public void onMessageBoxDesvalidar(){
		BuzonLogInt buzontmp = null;
		for (BuzonLogInt buzon : listasSeleccionadas) {
			buzontmp = buzon;
		}
		List<Liquidacion> liquidacionList = new ArrayList<Liquidacion>();
		List<String> estados = new ArrayList<String>();
		estados.clear();
		estados.add("VA");
		
		liquidacionList = lanzamientoIntMurexBo.obtenerLiquidaciones(Constantes.NOMBRE_PROYECTO_DERI,buzontmp.getIndicadorOperacion(),buzontmp.getClaveOperacion(),buzontmp.getIdProductoCompuesto(),estados,null);
		
		for (Liquidacion liquidac : liquidacionList) {
			desvalidar(liquidac);
		}
		
		
		
		onMessageBoxIntegrar();
	}
	
	
	
	public boolean bloquearLiquidacion(Liquidacion liquidacion, String accion){
		
		String tipoOpera = null;
		if (liquidacion.getTipopera().equals(Constantes.LIQUIDACION_TIPOPERA_P)){
			tipoOpera = Constantes.LIQUIDACION_TIPOPERA_PAGO;
		}else{
			tipoOpera = Constantes.LIQUIDACION_TIPOPERA_COBRO;
		}
		//si devuelve false es que el registro ya está bloqueado
		if (!dbLockService.bloqueo(Liquidacion.class, liquidacion.getId())){					
			statusMessages.addFromResourceBundle(Severity.ERROR,"liquidaciones.error.noBloqueo", liquidacion.getNcorrela(), 
					liquidacion.getProducto(), liquidacion.getFechaliq(), tipoOpera, liquidacion.getImportel(), accion);
			return false; 
		}
		//El registro sigue bloqueado
		return true;
		
	}
	
	private void desvalidar(Liquidacion liquidac) {
		
		if (this.bloquearLiquidacion(liquidac, "desvalidar")) {

			
			if (comprobarDesvalidacion(liquidac)){
				statusMessages.addFromResourceBundle(Severity.WARN,"liquidaciones.warning.desvalidar", liquidac.getNcorrela(),liquidac.getId().getCodliqui());
			}
			
				try {
					liquidac.setEstado(Constantes.LIQUIDACION_VALIDADA);
					liquidacionesBo.desvalidarLiquidacion(liquidac);
					liquidacionesBo.flush();
				} catch (RollbackException r) {
					statusMessages.add(Severity.ERROR, "#{messages['liquidaciones.error.rollback']}");
					throw new RollbackException();
				} finally {
					dbLockService.desbloqueo(Liquidacion.class, liquidac.getId());
				}
		
		}
		
	}

		
		private Boolean comprobarDesvalidacion(Liquidacion liquidacion) {
			Date fechamis=null ;
			
			if (Constantes.LIQ_ENVIADA.equalsIgnoreCase(liquidacion.getSitualiq())){
				return true;
			}

			if (liquidacionesBo.esProductoRAD(liquidacion.getProducto())){ 

				if (Constantes.CANAL_SWIFT.equalsIgnoreCase(liquidacion.getCanaliqi())){
					
					fechamis = liquidacionesBo.obtenerFechaSistema(); //Recuperamos la fecha del sistema
					if (fechamis.after(liquidacion.getSwift().getFechaenv())){
						return true;
					}
					
				}
				
			}else{
	/**
	 * 							CTA P/C	D-1 (FECHALIQ-1)	Fecha Liquidación = Fecha dia
	 *  						TAR Pago	D-1 (FECHALIQ-1)	Fecha Liquidación = Fecha dia
	 *  						TAR Cobro	D (FECHALIQ)	No corresponde
	 *  						SW  P/C	FECHAENV (SWMT0202)	Fecha día > FECHAENV
	 */
				if (Constantes.CANAL_CLIENTE.equalsIgnoreCase(liquidacion.getCanaliqi())){
					fechamis = liquidacionesBo.obtenerFechaSistema(); //Recuperamos la fecha del sistema	
					if (liquidacion.getFechaliq().equals(fechamis)){
						return true;
					}
				}else if (Constantes.CANAL_TARGET.equalsIgnoreCase(liquidacion.getCanaliqi())){
					if (Constantes.LIQUIDACION_TIPOPERA_P.equalsIgnoreCase(liquidacion.getTipopera())){
						fechamis = liquidacionesBo.obtenerFechaSistema(); //Recuperamos la fecha del sistema	
						if (liquidacion.getFechaliq().equals(fechamis)){
							return true;
						}
					}
				}else if (Constantes.CANAL_SWIFT.equalsIgnoreCase(liquidacion.getCanaliqi())){
					fechamis = liquidacionesBo.obtenerFechaSistema(); //Recuperamos la fecha del sistema
					if (fechamis.after(liquidacion.getSwift().getFechaenv())){
						return true;
					}
				}
			
			}
			
			return false;
		}
		

	public void voidFunction(){
		
	}
	
	public void onMessageBoxIntegrar(){
		
		/** Comprueba si hay eventos 4001 tratados en la agenda */
		if(!lanzamientoIntMurexBo.isAvisosCodigoEvento6018()){
	
			lanzamientoIntMurexBo.actualizarSeleccionados(listasSeleccionadas,4L);
			statusMessages.add(StatusMessage.Severity.INFO, "#{messages['lanzamiento.registros']}");

			
			/** Buscamos número de evento e insertamos nuevo registro */

			if (lanzamientoIntMurexBo.updateAgenda()){
				/** Avisamos de que el lanzamiento se ha realizado con éxito */
				statusMessages.add(StatusMessage.Severity.INFO, "#{messages['aceptar.lanzamientorealizado']}");
			}else{
				statusMessages.add(StatusMessage.Severity.ERROR, "#{messages['aceptar.eventoError']}");
			}
			
		} else {
			/** Avisamos de que hay un lanzamiento pendiente de procesar */
			statusMessages.add(StatusMessage.Severity.ERROR, "#{messages['aceptar.lanzamientopendiente.error']}");
		}
	
		refrescarPantalla();
	
	}
	
	private void avisoDesvalidar() {
		
		if (messageBoxActionMO==null){
			messageBoxActionMO = new MessageBoxAction();
		}
		
		messageBoxActionMO.init("integracion.modif.liquidacion.validada", "lanzamientoIntMurexAction.onMessageBoxDesvalidar()",
				"lanzamientoIntMurexAction.onMessageBoxIntegrar()","resultadosConsulta, LanzamientoIntMurexForm, helperPanel");	

//		
////		statusMessages.add(StatusMessage.Severity.ERROR, "#{messages['aceptar.lanzamientopendiente.errorfin']}");
		
	}

	private void avisoLiquidadas() {
		
		if (messageBoxActionMO==null){
			messageBoxActionMO = new MessageBoxAction();
		}
		
		messageBoxActionMO.init("integracion.modif.liquidacion.liquidadas", "lanzamientoIntMurexAction.onMessageBoxIntegrar()",
				"lanzamientoIntMurexAction.voidFunction()","resultadosConsulta, LanzamientoIntMurexForm, helperPanel");	

//		
////		statusMessages.add(StatusMessage.Severity.ERROR, "#{messages['aceptar.lanzamientopendiente.errorfin']}");
		
	}
	
	private void avisoLiquidadasVal() {
		
		if (messageBoxActionMO==null){
			messageBoxActionMO = new MessageBoxAction();
		}
		
		messageBoxActionMO.init("integracion.modif.liquidacion.liquidadas", "lanzamientoIntMurexAction.onMessageBoxDesvalidar()",
				"lanzamientoIntMurexAction.voidFunction()","resultadosConsulta, LanzamientoIntMurexForm, helperPanel");	

//		
////		statusMessages.add(StatusMessage.Severity.ERROR, "#{messages['aceptar.lanzamientopendiente.errorfin']}");
		
	}


	
	
	/** Lanza el proceso Kondor + insertando un solo evento del tipo 4001 */
	public void actualizarAgenda(){

		HashSet<BuzonLogInt> listasSelecIntegrables = new HashSet<BuzonLogInt>();
		boolean todasIntegrables = true;
		if (listasSeleccionadas!=null && !listasSeleccionadas.isEmpty()){
			for (BuzonLogInt vistaBuzonLogInt : listasSeleccionadas) {
			
				if (vistaBuzonLogInt.isIntegrable() && vistaBuzonLogInt.getCodigoNaranja()==0){
					listasSelecIntegrables.add(vistaBuzonLogInt);
				}else{
					todasIntegrables=false;	
				}
			
			}
		}
		
		if (!todasIntegrables){
			statusMessages.add(StatusMessage.Severity.INFO, "#{messages['aceptar.nointegradas']}");
		}
		
		
		if (listasSelecIntegrables!=null && !listasSelecIntegrables.isEmpty()){
		
		/** Comprueba si hay eventos 6018 tratados en la agenda */
		if(!lanzamientoIntMurexBo.isAvisosCodigoEvento6018()){

			
			//Actualizamos la tabla
			lanzamientoIntMurexBo.actualizarSeleccionados(listasSelecIntegrables,4L);
			statusMessages.add(StatusMessage.Severity.INFO, "#{messages['lanzamiento.registros']}");

			
			/** Buscamos número de evento e insertamos nuevo registro */

			if (lanzamientoIntMurexBo.updateAgenda()){
				/** Avisamos de que el lanzamiento se ha realizado con éxito */
				statusMessages.add(StatusMessage.Severity.INFO, "#{messages['aceptar.lanzamientorealizado']}");
			}else{
				statusMessages.add(StatusMessage.Severity.ERROR, "#{messages['aceptar.eventoError']}");
			}
			
			} else {
			/** Avisamos de que hay un lanzamiento pendiente de procesar */
				statusMessages.add(StatusMessage.Severity.ERROR, "#{messages['aceptar.lanzamientopendiente.error']}");
			}
		refrescarPantalla();
	
	}else{
		statusMessages.add(StatusMessage.Severity.INFO, "#{messages['lanzamiento.sin.registros']}");
	}
	
	}
	

	private void refrescarPantalla() {
		// TODO Auto-generated method stub
		 listasSeleccionadas.clear();
		 paginationData.setFirstResult(0);
		 if (isBmn()){
			 newFormInstanceBMN();
		 }else if (isMigracion()){
			 newFormInstanceMigra();
		 }else{
			 newFormInstance();		
		 }

	}

	/** Recupera el número de operaciones pendientes */
	private Integer getOperacionesPendientes(){
		return lanzamientoIntMurexBo.getOperacionesPendientes();
	}
	private Integer getEstructurasPendientes(){
		return lanzamientoIntMurexBo.getEstructurasPendientes();
	}

	private List<BuzonLogInt> getRegistrosPendientes(){
//		return lanzamientoIntMurexBo.getRegistrosPendientes();
		List<BuzonLogInt> lista =lanzamientoIntMurexBo.getRegistrosPendientes();
		for (BuzonLogInt buzon : lista) {
			buzon.setIntegrable(esIntegrable(buzon));
			buzon.setDescripcionProductoTgr(obtenerProductoTGR(buzon));
			buzon.setCodigoNaranja(obtenerCodigoNaranja(buzon));
			
		}
		return lista;		
	}

	

	public int obtenerCodigoNaranja(BuzonLogInt buzon){
		return lanzamientoIntMurexBo.obtenerCodigoNaranja(buzon);	
	}
	
	private List<BuzonLogInt> getRegistroSeleccionado(BuzonLogInt buzonSeleccionado) {
//		return lanzamientoIntMurexBo.getRegistrosSeleccionados(buzonSeleccionado);
		List<BuzonLogInt> lista =lanzamientoIntMurexBo.getRegistrosSeleccionados(buzonSeleccionado);
		for (BuzonLogInt buzon : lista) {
			buzon.setIntegrable(esIntegrable(buzon));
			buzon.setDescripcionProductoTgr(obtenerProductoTGR(buzon));
			buzon.setCodigoNaranja(obtenerCodigoNaranja(buzon));
		}
		return lista;
	}
	
	private Integer getOperacionesPendientesBMN(){
		return lanzamientoIntMurexBo.getOperacionesPendientesBMN();
	}
	private Integer getEstructurasPendientesBMN(){
		return lanzamientoIntMurexBo.getEstructurasPendientesBMN();
	}

	private List<BuzonLogInt> getRegistrosPendientesBMN(){
//		return lanzamientoIntMurexBo.getRegistrosPendientesBMN();
		List<BuzonLogInt> lista =lanzamientoIntMurexBo.getRegistrosPendientesBMN();
		for (BuzonLogInt buzon : lista) {
			buzon.setIntegrable(esIntegrable(buzon));
			buzon.setDescripcionProductoTgr(obtenerProductoTGR(buzon));
			buzon.setCodigoNaranja(obtenerCodigoNaranja(buzon));
		}
		return lista;
		
	}


	private Integer getOperacionesPendientesMigra(){
		return lanzamientoIntMurexBo.getOperacionesPendientesMigra();
	}
	private Integer getEstructurasPendientesMigra(){
		return lanzamientoIntMurexBo.getEstructurasPendientesMigra();
	}

	private List<BuzonLogInt> getRegistrosPendientesMigra(){
//		return lanzamientoIntMurexBo.getRegistrosPendientesMigra();
		List<BuzonLogInt> lista =lanzamientoIntMurexBo.getRegistrosPendientesMigra();
		for (BuzonLogInt buzon : lista) {
			buzon.setIntegrable(esIntegrable(buzon));
			buzon.setDescripcionProductoTgr(obtenerProductoTGR(buzon));
			buzon.setCodigoNaranja(obtenerCodigoNaranja(buzon));
		}
		return lista;
	}

	
	@Override
	public List<BuzonLogInt> getDataTableList() {
		// TODO Auto-generated method stub
		return 	this.lanzamientoIntMurexPantalla.getLanzamientoIntMurexList();
	}

	@Override
	public void refrescarListaExcel() {
		// TODO Auto-generated method stub
		setExportExcel(true);
		setDataTableList(lanzamientosTotal);
	}

	@Override
	protected void refreshListInternal() {
		// TODO Auto-generated method stub
		setExportExcel(false);
		Integer maxResults; 
		if (paginationData !=null && lanzamientosTotal !=null 
				&& lanzamientosTotal.size()!= 0){

			maxResults = paginationData.getMaxResults()*paginationData.getActivePage()+1;
			if (lanzamientosTotal.size() < maxResults){
				maxResults = lanzamientosTotal.size(); 
			}
			setDataTableList(lanzamientosTotal.subList(paginationData.getFirstResult(),maxResults ));
		}else{
			setDataTableList(null);
		}

		
		
	}

	@Override
	public void setDataTableList(List<?> dataTableList) {
		// TODO Auto-generated method stub
		this.lanzamientoIntMurexPantalla.setLanzamientoIntMurexList((List<BuzonLogInt>)dataTableList);
	}

	public List<BuzonLogInt> getLanzamientosTotal() {
		return lanzamientosTotal;
	}

	public void setLanzamientosTotal(List<BuzonLogInt> lanzamientosTotal) {
		this.lanzamientosTotal = lanzamientosTotal;
	}


	private HashSet<BuzonLogInt> listasSeleccionadas = new HashSet<BuzonLogInt>();

	public Boolean getSelectedRow(){
		return listasSeleccionadas.contains(lanzamientoIntMurexPantalla.getLanzamientoIntMurexSel());
	}

	public void setSelectedRow(Boolean selected){
		if(selected){
			listasSeleccionadas.add(lanzamientoIntMurexPantalla.getLanzamientoIntMurexSel());
		}
		else{
			listasSeleccionadas.remove(lanzamientoIntMurexPantalla.getLanzamientoIntMurexSel());
//			listaSuscripcionesPantalla.setSeleccionTotal(false);
		}
	}
	
	public void seleccionarLista(){

	}

	public void seleccionarTodos(){
		listasSeleccionadas.clear();
		listasSeleccionadas.addAll(lanzamientosTotal);
	}

	public void deseleccionarTodos(){
		listasSeleccionadas.clear();
	}

	public void desintegrar(){

		if (listasSeleccionadas!=null && !listasSeleccionadas.isEmpty()){
			//Actualizamos la tabla
			lanzamientoIntMurexBo.actualizarSeleccionados(listasSeleccionadas, 9L);		
			/** Avisamos de que el lanzamiento se ha realizado con éxito */
			statusMessages.add(StatusMessage.Severity.INFO, "#{messages['lanzamiento.registros']}");
			refrescarPantalla();
		}else{
			statusMessages.add(StatusMessage.Severity.INFO, "#{messages['lanzamiento.sin.registros']}");
		}
	}

	public String obtenerDescripcion(BuzonLogInt buzon){
		return lanzamientoIntMurexBo.obtenerDescripcion(buzon);
	}




	public boolean isBmn() {
		return bmn;
	}

	public void setBmn(boolean bmn) {
		this.bmn = bmn;
	}

	public boolean isMigracion() {
		return migracion;
	}

	public void setMigracion(boolean migracion) {
		this.migracion = migracion;
	}

	public List<VistaBuzonLogInt> getLanzamientosTotalAgrupado() {
		return lanzamientosTotalAgrupado;
	}

	public void setLanzamientosTotalAgrupado(
			List<VistaBuzonLogInt> lanzamientosTotalAgrupado) {
		this.lanzamientosTotalAgrupado = lanzamientosTotalAgrupado;
	}

	public BuzonLogInt getBuzonSeleccionado() {
		return buzonSeleccionado;
	}

	public void setBuzonSeleccionado(BuzonLogInt buzonSeleccionado) {
		this.buzonSeleccionado = buzonSeleccionado;
	}

	public void salir(){
		Conversation conversacion = Conversation.instance();
		//Volvemos a la anterior conversación
		if(conversacion.isNested()){
			conversacion.redirectToParent();
		} else {
			redirectToURL("/home.seam");
			conversacion.endAndRedirect();
		}
	}
	/**
	 * Miramos si la operacion asociada al buzon tiene un estado que nos permita su integracion
	 * 
	 * @param buzon
	 * @return
	 */
	public Boolean esIntegrable(BuzonLogInt buzon){
		return lanzamientoIntMurexBo.esIntegrable(buzon.getClaveOperacion(),
				buzon.getIdProductoCompuesto(),buzon.getIndicadorOperacion());
	}
	
	public String obtenerProductoTGR(BuzonLogInt buzon){
		return lanzamientoIntMurexBo.obtenerProductoTGR(buzon);	
	}
	
	public String getRowClasses(){
		StringBuilder builder = new StringBuilder();
		int i=0;
		for (BuzonLogInt vl : lanzamientoIntMurexPantalla.getLanzamientoIntMurexList()) {
			if(i>0){
				builder.append(",");
			}
			
			if (!vl.isIntegrable()){
					builder.append("redRow");	

			}else{
				
				if (vl.getCodigoNaranja() > 0){
					
					builder.append("naranjaRow");
				
				}else{
					
				
					if(i%2==0){
						builder.append("oddRow");
					}
					else{
						builder.append("evenRow");
					}
			
				}
			}
			i++;
		}
		return builder.toString();
	}


	
	
}
