package com.atosorigin.deri.murex.lanzamiento.action;

import java.util.Date;
import java.util.HashSet;
import java.util.List;


import org.jboss.seam.ScopeType;
import org.jboss.seam.annotations.In;
import org.jboss.seam.annotations.Name;
import org.jboss.seam.annotations.Out;
import org.jboss.seam.annotations.Scope;
import org.jboss.seam.core.Conversation;
import org.jboss.seam.international.StatusMessage;
import org.jboss.seam.international.StatusMessage.Severity;

import com.atosorigin.common.action.PaginatedListAction;
import com.atosorigin.common.action.PaginationData;
import com.atosorigin.common.utils.GenericUtils;
import com.atosorigin.deri.model.kondor.BuzonDeri;
import com.atosorigin.deri.model.murex.BuzonLogInt;
import com.atosorigin.deri.model.murex.VistaBuzonLogInt;
import com.atosorigin.deri.murex.lanzamiento.screen.LanzamientoIntMurexPantalla;
import com.atosrigin.deri.murex.lanzamientointegracion.business.LanzamientoIntMurexBo;

/**
 * Clase action listener para el caso de uso de lanzamiento de integración.
 */
@Name("lanzamientoIntMurexRecuperarAction")
@Scope(ScopeType.CONVERSATION)
public class LanzamientoIntMurexRecuperarAction extends PaginatedListAction {

	/**
	 * Inyección del bean de Spring "lanzamientoIntegracionBo" que contiene los métodos de negocio
	 * para el caso de uso lanzamiento integración.
	 */
	@In("#{lanzamientoIntMurexBo}")
	protected LanzamientoIntMurexBo lanzamientoIntMurexBo;
	
	@In(create=true)
	protected LanzamientoIntMurexPantalla lanzamientoIntMurexPantalla;
	
	@In(required = false, value = "buzonSeleccionado")
	protected BuzonLogInt buzonSeleccionado;
	
	protected  List<BuzonLogInt>  lanzamientosTotal;
	protected  List<VistaBuzonLogInt>  lanzamientosTotalAgrupado;
	private boolean bmn = false;
	private boolean migracion = false;
	
	private int maxSelected;
	
	/** Carga los valores de inicialización del formulario */ 
	public void newFormInstance() {
		if (isPrimerAcceso()){
			informarParametrosDefecto();
		}
		setPrimerAcceso(false);
		this.lanzamientoIntMurexPantalla.setFecha(new Date()); // Cargamos con la fecha actual
		if (GenericUtils.isNullOrBlank(buzonSeleccionado)){

			lanzamientosTotal = getRegistrosDescartados(lanzamientoIntMurexPantalla.getClaveOperacionDesde(),
					lanzamientoIntMurexPantalla.getClaveOperacionHasta(),
					lanzamientoIntMurexPantalla.getFechaDesde(),
					lanzamientoIntMurexPantalla.getFechaHasta(),paginationData);	
		}else{
			lanzamientosTotal = getRegistroSeleccionado(buzonSeleccionado);
		}
		
		this.setBmn(false);
		this.setMigracion(false);
		refrescarLista();
	}

	
	private List<BuzonLogInt> getRegistrosDescartados(Long claveOperacionDesde,
			Long claveOperacionHasta, Date fechaDesde, Date fechaHasta,
			PaginationData paginationData) {
		List<BuzonLogInt> lista =
			lanzamientoIntMurexBo.getRegistrosDescartados(claveOperacionDesde,
					claveOperacionHasta, fechaDesde, fechaHasta, paginationData);
		for (BuzonLogInt buzonLogInt : lista) {
			buzonLogInt.setIntegrable(true);
			buzonLogInt.setDescripcionProductoTgr(obtenerProductoTGR(buzonLogInt));
		}
		return lista;

	}


	private void informarParametrosDefecto() {
		Integer numdias = lanzamientoIntMurexBo.obtenerNumDiasARecuperar();
		Date fechamis = lanzamientoIntMurexBo.getFechaDeri();
		Date fechadesde = GenericUtils.ajustarFecha(fechamis, -numdias);
		lanzamientoIntMurexPantalla.setFechaDesde(fechadesde);
		lanzamientoIntMurexPantalla.setFechaHasta(fechamis);
		lanzamientoIntMurexPantalla.setClaveOperacionDesde(null);
		lanzamientoIntMurexPantalla.setClaveOperacionHasta(null);
		
	}

	public void newFormInstanceBMN() {
		this.lanzamientoIntMurexPantalla.setFecha(new Date()); // Cargamos con la fecha actual
		this.lanzamientoIntMurexPantalla.setOperaciones(getOperacionesPendientesBMN()); // Cargamos número operaciones
		this.lanzamientoIntMurexPantalla.setEstructuras(getEstructurasPendientesBMN());
		lanzamientosTotal = getRegistrosPendientesBMN();
		this.setBmn(true);
		this.setMigracion(false);
		refrescarLista();
	}

	public void newFormInstanceMigra() {
		this.lanzamientoIntMurexPantalla.setFecha(new Date()); // Cargamos con la fecha actual
		this.lanzamientoIntMurexPantalla.setOperaciones(getOperacionesPendientesMigra()); // Cargamos número operaciones
		this.lanzamientoIntMurexPantalla.setEstructuras(getEstructurasPendientesMigra());
		lanzamientosTotal = getRegistrosPendientesMigra();
		this.setBmn(false);
		this.setMigracion(true);
		refrescarLista();
	}
	
	public boolean buscarValidator() {
		if (GenericUtils.isNullOrBlank(lanzamientoIntMurexPantalla.getClaveOperacionDesde()) &&
			GenericUtils.isNullOrBlank(lanzamientoIntMurexPantalla.getClaveOperacionHasta()) &&
			GenericUtils.isNullOrBlank(lanzamientoIntMurexPantalla.getFechaDesde()) && 
			GenericUtils.isNullOrBlank(lanzamientoIntMurexPantalla.getFechaHasta())){
			
			statusMessages.add(StatusMessage.Severity.ERROR, "#{messages['lanzamiento.integracion.filtro']}");
			return false;
		}else{
			return true;	
		}
		
		
		
	}
	
	public void buscar(){
		if (GenericUtils.isNullOrBlank(buzonSeleccionado)){
			lanzamientosTotal = getRegistrosDescartados(lanzamientoIntMurexPantalla.getClaveOperacionDesde(),
					lanzamientoIntMurexPantalla.getClaveOperacionHasta(),
					lanzamientoIntMurexPantalla.getFechaDesde(),
					lanzamientoIntMurexPantalla.getFechaHasta(),paginationData);	
		}else{
			lanzamientosTotal = getRegistroSeleccionado(buzonSeleccionado);
		}		
		this.setBmn(false);
		this.setMigracion(false);
		refrescarLista();
	}

	
	
	/** Lanza el proceso Kondor + insertando un solo evento del tipo 4001 */
	public void actualizarAgenda(){

		HashSet<BuzonLogInt> listasSelecIntegrables = new HashSet<BuzonLogInt>();
		boolean todasIntegrables = true;
		if (listasSeleccionadas!=null && !listasSeleccionadas.isEmpty()){
			for (BuzonLogInt vistaBuzonLogInt : listasSeleccionadas) {
			
				if (vistaBuzonLogInt.isIntegrable()){
					listasSelecIntegrables.add(vistaBuzonLogInt);
				}else{
					todasIntegrables=false;	
				}
			
			}
		}
		
		if (!todasIntegrables){
			statusMessages.add(StatusMessage.Severity.INFO, "#{messages['aceptar.nointegradas']}");
		}
		
		
		if (listasSelecIntegrables!=null && !listasSelecIntegrables.isEmpty()){
		//Actualizamos la tabla
		lanzamientoIntMurexBo.actualizarSeleccionados(listasSelecIntegrables,4L);
		statusMessages.add(StatusMessage.Severity.INFO, "#{messages['lanzamiento.registros']}");
		
		/** Comprueba si hay eventos 6018 tratados en la agenda */
		if(!lanzamientoIntMurexBo.isAvisosCodigoEvento6018()){

			/** Buscamos número de evento e insertamos nuevo registro */

			if (lanzamientoIntMurexBo.updateAgenda()){
				/** Avisamos de que el lanzamiento se ha realizado con éxito */
				statusMessages.add(StatusMessage.Severity.INFO, "#{messages['aceptar.lanzamientorealizado']}");
			}else{
				statusMessages.add(StatusMessage.Severity.ERROR, "#{messages['aceptar.eventoError']}");
			}
			
			} else {
			/** Avisamos de que hay un lanzamiento pendiente de procesar */
				statusMessages.add(StatusMessage.Severity.ERROR, "#{messages['aceptar.lanzamientopendiente.error']}");
			}
		refrescarPantalla();
	
	}else{
		statusMessages.add(StatusMessage.Severity.INFO, "#{messages['lanzamiento.sin.registros']}");
	}
	
	}
	

	private void refrescarPantalla() {
		// TODO Auto-generated method stub
		 listasSeleccionadas.clear();
		 paginationData.setFirstResult(0);
		 if (isBmn()){
			 newFormInstanceBMN();
		 }else if (isMigracion()){
			 newFormInstanceMigra();
		 }else{
			 newFormInstance();		
		 }

	}

	/** Recupera el número de operaciones pendientes */
	private Integer getOperacionesPendientes(){
		return lanzamientoIntMurexBo.getOperacionesPendientes();
	}
	private Integer getEstructurasPendientes(){
		return lanzamientoIntMurexBo.getEstructurasPendientes();
	}

	private List<BuzonLogInt> getRegistrosPendientes(){
//		return lanzamientoIntMurexBo.getRegistrosPendientes();
		List<BuzonLogInt> lista =lanzamientoIntMurexBo.getRegistrosPendientes();
		for (BuzonLogInt buzon : lista) {
			buzon.setIntegrable(esIntegrable(buzon));
			buzon.setDescripcionProductoTgr(obtenerProductoTGR(buzon));
			
		}
		return lista;		
	}
	
	private List<BuzonLogInt> getRegistroSeleccionado(BuzonLogInt buzonSeleccionado) {
//		return lanzamientoIntMurexBo.getRegistrosSeleccionados(buzonSeleccionado);
		List<BuzonLogInt> lista =lanzamientoIntMurexBo.getRegistrosSeleccionados(buzonSeleccionado);
		for (BuzonLogInt buzon : lista) {
			buzon.setIntegrable(esIntegrable(buzon));
			buzon.setDescripcionProductoTgr(obtenerProductoTGR(buzon));
		}
		return lista;
	}
	
	private Integer getOperacionesPendientesBMN(){
		return lanzamientoIntMurexBo.getOperacionesPendientesBMN();
	}
	private Integer getEstructurasPendientesBMN(){
		return lanzamientoIntMurexBo.getEstructurasPendientesBMN();
	}

	private List<BuzonLogInt> getRegistrosPendientesBMN(){
//		return lanzamientoIntMurexBo.getRegistrosPendientesBMN();
		List<BuzonLogInt> lista =lanzamientoIntMurexBo.getRegistrosPendientesBMN();
		for (BuzonLogInt buzon : lista) {
			buzon.setIntegrable(esIntegrable(buzon));
			buzon.setDescripcionProductoTgr(obtenerProductoTGR(buzon));
		}
		return lista;
		
	}


	private Integer getOperacionesPendientesMigra(){
		return lanzamientoIntMurexBo.getOperacionesPendientesMigra();
	}
	private Integer getEstructurasPendientesMigra(){
		return lanzamientoIntMurexBo.getEstructurasPendientesMigra();
	}

	private List<BuzonLogInt> getRegistrosPendientesMigra(){
//		return lanzamientoIntMurexBo.getRegistrosPendientesMigra();
		List<BuzonLogInt> lista =lanzamientoIntMurexBo.getRegistrosPendientesMigra();
		for (BuzonLogInt buzon : lista) {
			buzon.setIntegrable(esIntegrable(buzon));
			buzon.setDescripcionProductoTgr(obtenerProductoTGR(buzon));
		}
		return lista;
	}

	
	@Override
	public List<BuzonLogInt> getDataTableList() {
		// TODO Auto-generated method stub
		return 	this.lanzamientoIntMurexPantalla.getLanzamientoIntMurexList();
	}

	
	@Override
	public void refrescarListaExcel() {
		// TODO Auto-generated method stub
		setExportExcel(true);
		
		lanzamientosTotal = getRegistrosDescartados(lanzamientoIntMurexPantalla.getClaveOperacionDesde(),
					lanzamientoIntMurexPantalla.getClaveOperacionHasta(),
					lanzamientoIntMurexPantalla.getFechaDesde(),
					lanzamientoIntMurexPantalla.getFechaHasta(),paginationData.getPaginationDataForExcel());	


		setDataTableList(lanzamientosTotal);
	}

	@Override
	protected void refreshListInternal() {
		// TODO Auto-generated method stub
		setExportExcel(false);
		lanzamientosTotal =
		getRegistrosDescartados(lanzamientoIntMurexPantalla.getClaveOperacionDesde(),
				lanzamientoIntMurexPantalla.getClaveOperacionHasta(),
				lanzamientoIntMurexPantalla.getFechaDesde(),
				lanzamientoIntMurexPantalla.getFechaHasta(),paginationData);	

		
		setDataTableList(lanzamientosTotal);
		
	}

	@Override
	public void setDataTableList(List<?> dataTableList) {
		// TODO Auto-generated method stub
		this.lanzamientoIntMurexPantalla.setLanzamientoIntMurexList((List<BuzonLogInt>)dataTableList);
	}

	public List<BuzonLogInt> getLanzamientosTotal() {
		return lanzamientosTotal;
	}

	public void setLanzamientosTotal(List<BuzonLogInt> lanzamientosTotal) {
		this.lanzamientosTotal = lanzamientosTotal;
	}


	private HashSet<BuzonLogInt> listasSeleccionadas = new HashSet<BuzonLogInt>();

	public Boolean getSelectedRow(){
		return listasSeleccionadas.contains(lanzamientoIntMurexPantalla.getLanzamientoIntMurexSel());
	}

	public void setSelectedRow(Boolean selected){
		if(selected){
			listasSeleccionadas.add(lanzamientoIntMurexPantalla.getLanzamientoIntMurexSel());
		}
		else{
			listasSeleccionadas.remove(lanzamientoIntMurexPantalla.getLanzamientoIntMurexSel());
//			listaSuscripcionesPantalla.setSeleccionTotal(false);
		}
	}
	
	public void seleccionarLista(){

	}

	public void seleccionarTodos(){
		
		int tmpMaxResults = paginationData.getMaxResults();
		int tmpFirstResult = paginationData.getFirstResult();
		
		paginationData.setMaxResults(501);
		paginationData.setFirstResult(0);
		List<BuzonLogInt> buzonesList = getRegistrosDescartados(lanzamientoIntMurexPantalla.getClaveOperacionDesde(),
				lanzamientoIntMurexPantalla.getClaveOperacionHasta(),
				lanzamientoIntMurexPantalla.getFechaDesde(),
				lanzamientoIntMurexPantalla.getFechaHasta(),paginationData);	
	
		
		int iteraciones = buzonesList.size();
		if(buzonesList.size() > 500){
			statusMessages.add(Severity.INFO, "#{messages['mantoper.seleccionados.primeros.cincuenta']}");
			iteraciones = 500;
			tmpFirstResult=0;
			maxSelected = 499;
		} else {
			maxSelected = buzonesList.size()-1;
		}
		listasSeleccionadas.clear(); 
		for(int i = 0; i<iteraciones; i++){
			listasSeleccionadas.add(buzonesList.get(i));
		}
		paginationData.setMaxResults(tmpMaxResults);
		paginationData.setFirstResult(tmpFirstResult);

	}

	public void deseleccionarTodos(){
		listasSeleccionadas.clear();
		maxSelected = 0;
	}

	public void desintegrar(){

		if (listasSeleccionadas!=null && !listasSeleccionadas.isEmpty()){
			//Actualizamos la tabla
			lanzamientoIntMurexBo.actualizarSeleccionados(listasSeleccionadas, 9L);		
			/** Avisamos de que el lanzamiento se ha realizado con éxito */
			statusMessages.add(StatusMessage.Severity.INFO, "#{messages['lanzamiento.registros']}");
			refrescarPantalla();
		}else{
			statusMessages.add(StatusMessage.Severity.INFO, "#{messages['lanzamiento.sin.registros']}");
		}
	}

	public String obtenerDescripcion(BuzonLogInt buzon){
		return lanzamientoIntMurexBo.obtenerDescripcion(buzon);
	}




	public boolean isBmn() {
		return bmn;
	}

	public void setBmn(boolean bmn) {
		this.bmn = bmn;
	}

	public boolean isMigracion() {
		return migracion;
	}

	public void setMigracion(boolean migracion) {
		this.migracion = migracion;
	}

	public List<VistaBuzonLogInt> getLanzamientosTotalAgrupado() {
		return lanzamientosTotalAgrupado;
	}

	public void setLanzamientosTotalAgrupado(
			List<VistaBuzonLogInt> lanzamientosTotalAgrupado) {
		this.lanzamientosTotalAgrupado = lanzamientosTotalAgrupado;
	}

	public BuzonLogInt getBuzonSeleccionado() {
		return buzonSeleccionado;
	}

	public void setBuzonSeleccionado(BuzonLogInt buzonSeleccionado) {
		this.buzonSeleccionado = buzonSeleccionado;
	}

	public void salir(){
		Conversation conversacion = Conversation.instance();
		//Volvemos a la anterior conversación
		if(conversacion.isNested()){
			conversacion.redirectToParent();
		} else {
			redirectToURL("/home.seam");
			conversacion.endAndRedirect();
		}
	}
	/**
	 * Miramos si la operacion asociada al buzon tiene un estado que nos permita su integracion
	 * 
	 * @param buzon
	 * @return
	 */
	public Boolean esIntegrable(BuzonLogInt buzon){
		return lanzamientoIntMurexBo.esIntegrable(buzon.getClaveOperacion(),
				buzon.getIdProductoCompuesto(),buzon.getIndicadorOperacion());
	}
	
	public String obtenerProductoTGR(BuzonLogInt buzon){
		return lanzamientoIntMurexBo.obtenerProductoTGR(buzon);	
	}
	
	public String getRowClasses(){
		StringBuilder builder = new StringBuilder();
		int i=0;
		for (BuzonLogInt vl : lanzamientoIntMurexPantalla.getLanzamientoIntMurexList()) {
			if(i>0){
				builder.append(",");
			}
			
			if (!vl.isIntegrable()){
					builder.append("redRow");	

			}else{
					
					if(i%2==0){
						builder.append("oddRow");
					}
					else{
						builder.append("evenRow");
					}
			}
			
			i++;
		}
		return builder.toString();
	}

	public void recuperar(){
		if (listasSeleccionadas!=null && !listasSeleccionadas.isEmpty()){

			//Actualizamos la tabla
			lanzamientoIntMurexBo.recuperarSeleccionados(listasSeleccionadas,0L);
			statusMessages.add(StatusMessage.Severity.INFO, "#{messages['lanzamiento.registros']}");
			refrescarPantalla();
		}else{
			statusMessages.add(StatusMessage.Severity.INFO, "#{messages['lanzamiento.sin.registros']}");
			
		}
		
	}
	
	/**
	 * Autorrellena fecha hasta con el valor introducido en fecha desde
	 */
	public void rellenarFechaHasta(){
		
		if(!GenericUtils.isNullOrBlank(lanzamientoIntMurexPantalla.getFechaDesde())){
			lanzamientoIntMurexPantalla.setFechaHasta(lanzamientoIntMurexPantalla.getFechaDesde());
		}
	}

	/**
	 * Autorrellena deal number hasta con el valor introducido en deal number desde
	 */
	public void rellenarClaveOperacionHasta(){
		
		if(!GenericUtils.isNullOrBlank(lanzamientoIntMurexPantalla.getClaveOperacionDesde())){
			lanzamientoIntMurexPantalla.setClaveOperacionHasta(lanzamientoIntMurexPantalla.getClaveOperacionDesde());
		}
	}


	public int getMaxSelected() {
		return maxSelected;
	}


	public void setMaxSelected(int maxSelected) {
		this.maxSelected = maxSelected;
	}


	public HashSet<BuzonLogInt> getListasSeleccionadas() {
		return listasSeleccionadas;
	}


	public void setListasSeleccionadas(HashSet<BuzonLogInt> listasSeleccionadas) {
		this.listasSeleccionadas = listasSeleccionadas;
	}	
	
}
