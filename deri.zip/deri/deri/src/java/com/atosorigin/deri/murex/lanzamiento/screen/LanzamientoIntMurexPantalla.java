package com.atosorigin.deri.murex.lanzamiento.screen;

import java.util.Date;
import java.util.List;

import org.jboss.seam.ScopeType;
import org.jboss.seam.annotations.Name;
import org.jboss.seam.annotations.Out;
import org.jboss.seam.annotations.Scope;
import org.jboss.seam.annotations.datamodel.DataModel;
import org.jboss.seam.annotations.datamodel.DataModelSelection;

import com.atosorigin.deri.model.murex.BuzonLogInt;
import com.atosorigin.deri.model.murex.VistaBuzonLogInt;

/**
 * Contiene los datos de pantalla necesarios para el caso de uso lanzamiento de integración.
 */
@Name("lanzamientoIntMurexPantalla")
@Scope(ScopeType.CONVERSATION)
public class LanzamientoIntMurexPantalla {

	protected Date fecha;
	protected Integer operaciones;
	protected Integer estructuras;
	
	protected Date fechaDesde;
	protected Date fechaHasta;
	protected Long claveOperacionDesde;
	protected Long claveOperacionHasta;
		
	
	
	/** Lista de datos para el grid. */
	@DataModel(value ="lanzamientoIntMurex")
	protected List<BuzonLogInt> lanzamientoIntMurexList;
	
	/** Tipo de documento seleccionado en el grid */
	@DataModelSelection(value ="lanzamientoIntMurex")
    @Out(required=false)
    protected BuzonLogInt lanzamientoIntMurexSel;	

	/** Lista de datos para el grid. */
	@DataModel(value ="lanzamientoIntMurexAgrup")
	protected List<VistaBuzonLogInt> lanzamientoIntMurexAgrupList;
	
	/** Tipo de documento seleccionado en el grid */
	@DataModelSelection(value ="lanzamientoIntMurexAgrup")
    @Out(required=false)
    protected VistaBuzonLogInt lanzamientoIntMurexAgrupSel;	
	
	public Integer getEstructuras() {
		return estructuras;
	}
	public void setEstructuras(Integer estructuras) {
		this.estructuras = estructuras;
	}
	public Date getFecha() {
		return fecha;
	}
	public Integer getOperaciones() {
		return operaciones;
	}
	public void setFecha(Date fecha) {
		this.fecha = fecha;
	}
	public void setOperaciones(Integer operaciones) {
		this.operaciones = operaciones;
	}
	public List<BuzonLogInt> getLanzamientoIntMurexList() {
		return lanzamientoIntMurexList;
	}
	public void setLanzamientoIntMurexList(List<BuzonLogInt> lanzamientoIntMurexList) {
		this.lanzamientoIntMurexList = lanzamientoIntMurexList;
	}
	public BuzonLogInt getLanzamientoIntMurexSel() {
		return lanzamientoIntMurexSel;
	}
	public void setLanzamientoIntMurexSel(BuzonLogInt lanzamientoIntMurexSel) {
		this.lanzamientoIntMurexSel = lanzamientoIntMurexSel;
	}
	public List<VistaBuzonLogInt> getLanzamientoIntMurexAgrupList() {
		return lanzamientoIntMurexAgrupList;
	}
	public void setLanzamientoIntMurexAgrupList(
			List<VistaBuzonLogInt> lanzamientoIntMurexAgrupList) {
		this.lanzamientoIntMurexAgrupList = lanzamientoIntMurexAgrupList;
	}
	public VistaBuzonLogInt getLanzamientoIntMurexAgrupSel() {
		return lanzamientoIntMurexAgrupSel;
	}
	public void setLanzamientoIntMurexAgrupSel(
			VistaBuzonLogInt lanzamientoIntMurexAgrupSel) {
		this.lanzamientoIntMurexAgrupSel = lanzamientoIntMurexAgrupSel;
	}
	public Date getFechaDesde() {
		return fechaDesde;
	}
	public void setFechaDesde(Date fechaDesde) {
		this.fechaDesde = fechaDesde;
	}
	public Date getFechaHasta() {
		return fechaHasta;
	}
	public void setFechaHasta(Date fechaHasta) {
		this.fechaHasta = fechaHasta;
	}
	public Long getClaveOperacionDesde() {
		return claveOperacionDesde;
	}
	public void setClaveOperacionDesde(Long claveOperacionDesde) {
		this.claveOperacionDesde = claveOperacionDesde;
	}
	public Long getClaveOperacionHasta() {
		return claveOperacionHasta;
	}
	public void setClaveOperacionHasta(Long claveOperacionHasta) {
		this.claveOperacionHasta = claveOperacionHasta;
	}
	
}
