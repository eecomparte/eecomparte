package com.atosorigin.deri.parametrizacion.confirmaciones.action;

import java.util.List;

import org.jboss.seam.ScopeType;
import org.jboss.seam.annotations.In;
import org.jboss.seam.annotations.Name;
import org.jboss.seam.annotations.Out;
import org.jboss.seam.annotations.Scope;
import org.jboss.seam.international.StatusMessage.Severity;

import com.atosorigin.common.action.ModoPantalla;
import com.atosorigin.common.action.PaginatedListAction;
import com.atosorigin.common.constantes.Constantes;
import com.atosorigin.common.formvalidator.FormValidator;
import com.atosorigin.common.utils.GenericUtils;
import com.atosorigin.deri.model.contrapartida.Contrapartida;
import com.atosorigin.deri.model.gestionoperaciones.TipoConfirmacion;
import com.atosorigin.deri.model.gestionoperaciones.TipoConfirmacionId;
import com.atosorigin.deri.parametrizacion.confirmaciones.business.ConfirmacionesBo;
import com.atosorigin.deri.parametrizacion.confirmaciones.screen.ConfirmacionesPantalla;
import com.atosorigin.deri.util.MessageBoxAction;
import com.atosorigin.deri.util.MsgBoxAction;

/**
 * Clase action listener para el caso de uso de parametrización de Confirmaciones
 */
@Name("confirmacionesAction")
@Scope(ScopeType.CONVERSATION)
@FormValidator
public class ConfirmacionesAction extends PaginatedListAction {

	@In(value="#{confirmacionesBo}")
	ConfirmacionesBo confirmacionesBo;
	
	@In(create=true)
	ConfirmacionesPantalla confirmacionesPantalla; 
	
	@In(create = true)
	MsgBoxAction msgBoxAction;
	
	@Out(required = false, value = "confirmacionesMessageBoxAction")
	private MessageBoxAction messageBoxConfirmacionesAction;
	
	private Boolean primeraEjecucionInit=null;

	public void buscar(){
		setPrimerAcceso(false);
		paginationData.reset();
		refrescarLista();		
	}
	
	public String obtenerDescProducto(String idProd){
		return confirmacionesBo.obtenerDescProducto(idProd);
	}
	public String obtenerDescEvento(String idEvento){
		return confirmacionesBo.obtenerDescEvento(idEvento);
	}
	
	public String guardar(){
		if(ModoPantalla.CREACION.equals(getModoPantalla())){
			if(GenericUtils.isNullOrBlank(confirmacionesBo.cargar(confirmacionesPantalla.getConfirmacionSelec().getId()))){
				confirmacionesBo.alta(confirmacionesPantalla.getConfirmacionSelec());
				statusMessages.add(Severity.INFO, "#{messages['confirmaciones.altacorrecta']}", Constantes.DEFAULT_MESSAGE_TEMPLATE);
			}
		}if(ModoPantalla.EDICION.equals(getModoPantalla())){
			confirmacionesBo.modifica(confirmacionesPantalla.getConfirmacionSelec());
			statusMessages.add(Severity.INFO, "#{messages['confirmaciones.modificacioncorrecta']}", Constantes.DEFAULT_MESSAGE_TEMPLATE);
		}
		return Constantes.CONSTANTE_SUCCESS;
	}
	
	public void nuevo(){
		confirmacionesPantalla.setConfirmacionSelec(new TipoConfirmacion(new TipoConfirmacionId()));
		setModoPantalla(ModoPantalla.CREACION);
	}
	
	public void editar(){
		TipoConfirmacion tipoConf = confirmacionesBo.cargar(confirmacionesPantalla.getConfirmacionSeleccionada().getId());
		confirmacionesPantalla.setIdProductoSel(tipoConf.getId().getProducto());
		confirmacionesPantalla.setIdEventoSel(tipoConf.getId().getIndSituacion());
		
		confirmacionesPantalla.setConfirmacionSelec(tipoConf);
		setModoPantalla(ModoPantalla.EDICION);
	}
	
	public void borrar(){
		confirmacionesBo.baja(confirmacionesPantalla.getConfirmacionSelec());
		statusMessages.add(Severity.INFO, "#{messages['confirmaciones.borradoCorrecto']}", Constantes.DEFAULT_MESSAGE_TEMPLATE);	
		refrescarLista();
	}
	
	@Override
	public List<?> getDataTableList() {
		
		return confirmacionesPantalla.getListaTiposConfirm();
	}
	
	public void ver(){
		confirmacionesPantalla.setConfirmacionSelec(confirmacionesPantalla.getConfirmacionSeleccionada());
		setModoPantalla(ModoPantalla.INSPECCION);
	}

	@Override
	protected void refreshListInternal() {
		String prod = null;
		setExportExcel(false);
		String evento = null;
		if(!GenericUtils.isNullOrBlank(confirmacionesPantalla.getProductoBusqueda())){
			prod = confirmacionesPantalla.getProductoBusqueda().getId();
		}
		if(!GenericUtils.isNullOrBlank(confirmacionesPantalla.getEventoBusqueda())){
			evento = confirmacionesPantalla.getEventoBusqueda().getCodigo();
		}
		List<TipoConfirmacion> listaConfir = confirmacionesBo
				.buscarConfirmaciones(prod, evento,
						confirmacionesPantalla.getIdContrapartida(),
						paginationData);
		confirmacionesPantalla.setListaTiposConfirm(listaConfir);
		
		
	}

	@Override
	public void refrescarListaExcel() {
		
		setExportExcel(true);
		String prod = null;
		String evento = null;
		if(!GenericUtils.isNullOrBlank(confirmacionesPantalla.getProductoBusqueda())){
			prod = confirmacionesPantalla.getProductoBusqueda().getId();
		}
		if(!GenericUtils.isNullOrBlank(confirmacionesPantalla.getEventoBusqueda())){
			evento = confirmacionesPantalla.getEventoBusqueda().getCodigo();
		}
		List<TipoConfirmacion> listaConfir = confirmacionesBo
				.buscarConfirmaciones(prod, evento,
						confirmacionesPantalla.getIdContrapartida(),
						paginationData.getPaginationDataForExcel());
		
		confirmacionesPantalla.setListaTiposConfirm(listaConfir);
		
	}

	@Override
	public void setDataTableList(List<?> dataTableList) {
		confirmacionesPantalla.setListaTiposConfirm((List<TipoConfirmacion>)dataTableList);
		
	}

	public void init(){
		primeraEjecucionInit=null;
		
		if(null==messageBoxConfirmacionesAction){
			messageBoxConfirmacionesAction = new MessageBoxAction();
		}
	}
	
	public void initDetalle(){
		if (primeraEjecucionInit == null) {
			primeraEjecucionInit=true;
		} 
		else{
			primeraEjecucionInit = false;
		}
		
		if(null==messageBoxConfirmacionesAction){
			messageBoxConfirmacionesAction = new MessageBoxAction();
		}
		
		if(primeraEjecucionInit){
			if(null!=confirmacionesPantalla.getConfirmacionSelec() && null!=confirmacionesPantalla.getConfirmacionSelec().getId() && null!=confirmacionesPantalla.getConfirmacionSelec().getId().getContrapartida()){
				String idContrapartida = confirmacionesPantalla.getConfirmacionSelec().getId().getContrapartida();
				if(null!=idContrapartida && idContrapartida.trim().length()>0){
					Contrapartida contrapartida = confirmacionesBo.cargarContrapartida(idContrapartida.toUpperCase());	
					if (null!=contrapartida && !GenericUtils.isNullOrBlank(contrapartida.getIndBloqueo()) && "S".equalsIgnoreCase(contrapartida.getIndBloqueo())){
						abrirPopUpContrapartidaBloqueada();
					}
				}
			}
		}
	}

	public void voidFunction(){
		msgBoxAction.voidFunction();
	}
	
	/**
	 * Mostrar PopUp cuando una contrapartida está bloqueada (no bloqueante)
	 */
	public void onVerificarContrapartidaBloqueada() {
		String contrapartida = confirmacionesPantalla.getIdContrapartida();
		if (!GenericUtils.isNullOrBlank(contrapartida)){
			 Contrapartida contrapObtenida2 = confirmacionesBo.cargarContrapartida(contrapartida.toUpperCase());	
			if (null!=contrapObtenida2 && !GenericUtils.isNullOrBlank(contrapObtenida2.getIndBloqueo()) && "S".equalsIgnoreCase(contrapObtenida2.getIndBloqueo())){
				abrirPopUpContrapartidaBloqueada();
			}
		}
	}
	
	public void onVerificarContrapartidaBloqueadaNueva() {
		if(null!=confirmacionesPantalla.getConfirmacionSelec() && null!=confirmacionesPantalla.getConfirmacionSelec().getId()){
		String contrapartida = confirmacionesPantalla.getConfirmacionSelec().getId().getContrapartida();
			if (!GenericUtils.isNullOrBlank(contrapartida)){
				 Contrapartida contrapObtenida2 = confirmacionesBo.cargarContrapartida(contrapartida.toUpperCase());	
				if (null!=contrapObtenida2 && !GenericUtils.isNullOrBlank(contrapObtenida2.getIndBloqueo()) && "S".equalsIgnoreCase(contrapObtenida2.getIndBloqueo())){
					abrirPopUpContrapartidaBloqueada();
				}
			}
		}
	}
	
	private void abrirPopUpContrapartidaBloqueada(){
		messageBoxConfirmacionesAction.init("confirmaciones.messages.contrapartida.bloqueada.texto", "confirmacionesAction.voidFunction()",null,"messageBoxPanelContrapa");
	}

}
