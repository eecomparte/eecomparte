package com.atosorigin.deri.parametrizacion.confirmaciones.action;

import java.util.List;

import org.jboss.seam.ScopeType;
import org.jboss.seam.annotations.In;
import org.jboss.seam.annotations.Name;
import org.jboss.seam.annotations.Scope;
import org.jboss.seam.international.StatusMessage.Severity;

import com.atosorigin.common.action.ModoPantalla;
import com.atosorigin.common.action.PaginatedListAction;
import com.atosorigin.common.constantes.Constantes;
import com.atosorigin.common.formvalidator.FormValidator;
import com.atosorigin.common.utils.GenericUtils;
import com.atosorigin.deri.model.adminoper.TextoConfirmaciones;
import com.atosorigin.deri.model.adminoper.TextoConfirmacionesId;
import com.atosorigin.deri.model.gestionoperaciones.TipoConfirmacion;
import com.atosorigin.deri.model.gestionoperaciones.TipoConfirmacionId;
import com.atosorigin.deri.parametrizacion.confirmaciones.business.ConfirmacionesBo;
import com.atosorigin.deri.parametrizacion.confirmaciones.screen.ConfirmacionesPantalla;
import com.atosorigin.deri.parametrizacion.confirmaciones.screen.TextoConfirmacionesPantalla;

/**
 * Clase action listener para el caso de uso de parametrización de Confirmaciones
 */
@Name("textoConfirmacionesAction")
@Scope(ScopeType.CONVERSATION)
@FormValidator
public class TextoConfirmacionesAction extends PaginatedListAction {

	@In(value="#{confirmacionesBo}")
	ConfirmacionesBo confirmacionesBo;
	
	@In(create=true)
	TextoConfirmacionesPantalla textoConfirmacionesPantalla; 
	
	
	public void buscar(){
		setPrimerAcceso(false);
		paginationData.reset();
		refrescarLista();		
	}
	

	public String guardar(){
		if(ModoPantalla.CREACION.equals(getModoPantalla())){
			if(GenericUtils.isNullOrBlank(confirmacionesBo.cargarTexto(textoConfirmacionesPantalla.getTextoConfirmacionSeleccionada().getId()))){
				confirmacionesBo.altaTexto(textoConfirmacionesPantalla.getTextoConfirmacionSeleccionada());
				statusMessages.add(Severity.INFO, "#{messages['confirmaciones.textos.altacorrecta']}", Constantes.DEFAULT_MESSAGE_TEMPLATE);
			}
		}if(ModoPantalla.EDICION.equals(getModoPantalla())){
			confirmacionesBo.modificaTexto(textoConfirmacionesPantalla.getTextoConfirmacionSeleccionada());
			statusMessages.add(Severity.INFO, "#{messages['confirmaciones.textos.modificacioncorrecta']}", Constantes.DEFAULT_MESSAGE_TEMPLATE);
		}
		return Constantes.CONSTANTE_SUCCESS;
	}
	
	public void nuevo(){
		textoConfirmacionesPantalla.setTextoConfirmacionSeleccionada(new TextoConfirmaciones(new TextoConfirmacionesId(),null,null,null));
		setModoPantalla(ModoPantalla.CREACION);
	}
	
	public void editar(){
//		TipoConfirmacion tipoConf = confirmacionesBo.cargar(textoConfirmacionesPantalla.getConfirmacionSeleccionada().getId());
//	
//		textoConfirmacionesPantalla.setConfirmacionSelec(tipoConf);
		textoConfirmacionesPantalla.getTextoConfirmacionSeleccionada();
		setModoPantalla(ModoPantalla.EDICION);
	}
	
	public void borrar(){
		textoConfirmacionesPantalla.getTextoConfirmacionSeleccionada();
		confirmacionesBo.bajaTexto(textoConfirmacionesPantalla.getTextoConfirmacionSeleccionada());
		statusMessages.add(Severity.INFO, "#{messages['confirmaciones.borradoCorrecto']}", Constantes.DEFAULT_MESSAGE_TEMPLATE);	
		refrescarLista();
	}
	
	@Override
	public List<?> getDataTableList() {
		
		return textoConfirmacionesPantalla.getListaTextoConfirm();
	}
	
	public void ver(){
		textoConfirmacionesPantalla.getTextoConfirmacionSeleccionada();
//		textoConfirmacionesPantalla.setConfirmacionSelec(textoConfirmacionesPantalla.getConfirmacionSeleccionada());
		setModoPantalla(ModoPantalla.INSPECCION);
	}

	@Override
	protected void refreshListInternal() {
		String codIdioma = null;
		setExportExcel(false);
		
		if(!GenericUtils.isNullOrBlank(textoConfirmacionesPantalla.getIdioma())){
			codIdioma = textoConfirmacionesPantalla.getIdioma().getCodigo();
		}
		List<TextoConfirmaciones> listaTex = confirmacionesBo
				.buscarTextosConfirmaciones(codIdioma,
						textoConfirmacionesPantalla.getGrupoSubyacente(),
						paginationData);
		textoConfirmacionesPantalla.setListaTextoConfirm(listaTex);
		
		
	}

	@Override
	public void refrescarListaExcel() {
		
		setExportExcel(true);
		String codIdioma = null;
		if(!GenericUtils.isNullOrBlank(textoConfirmacionesPantalla.getProductoBusqueda())){
			codIdioma = textoConfirmacionesPantalla.getIdioma().getCodigo();
		}
		
		List<TextoConfirmaciones> listaTex = confirmacionesBo
				.buscarTextosConfirmaciones(codIdioma, 
						textoConfirmacionesPantalla.getGrupoSubyacente(),
						paginationData.getPaginationDataForExcel());
		
		textoConfirmacionesPantalla.setListaTextoConfirm(listaTex);
		
	}

	@Override
	public void setDataTableList(List<?> dataTableList) {
		textoConfirmacionesPantalla.setListaTextoConfirm((List<TextoConfirmaciones>)dataTableList);
		
	}

	

}
