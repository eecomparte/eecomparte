package com.atosorigin.deri.parametrizacion.confirmaciones.screen;

import java.util.List;

import org.jboss.seam.ScopeType;
import org.jboss.seam.annotations.Name;
import org.jboss.seam.annotations.Out;
import org.jboss.seam.annotations.Scope;
import org.jboss.seam.annotations.datamodel.DataModel;
import org.jboss.seam.annotations.datamodel.DataModelSelection;

import com.atosorigin.deri.model.catalogo.Producto;
import com.atosorigin.deri.model.contrapartida.Contrapartida;
import com.atosorigin.deri.model.gestionoperaciones.DescIndSitua;
import com.atosorigin.deri.model.gestionoperaciones.TipoConfirmacion;

/**
 *  Contiene los datos de pantalla necesarios para el caso de uso de parametrizacion de confirmaciones.
 */

@Name("confirmacionesPantalla")
@Scope(ScopeType.CONVERSATION)
public class ConfirmacionesPantalla {

	protected Producto productoBusqueda;
	
	protected DescIndSitua eventoBusqueda;
	
	protected Contrapartida contrapaBusq;
	
	protected String idContrapartida;
	
	protected String idContrapartidaEdit;
	
	protected String idProductoSel;
	
	protected String idEventoSel;
	
//	protected ModeloConfirmacion modelo;
	
	@DataModel(value="listaDtTiposConfirmaciones")
	List<TipoConfirmacion> listaTiposConfirm;
	
	@DataModelSelection(value="listaDtTiposConfirmaciones")
	@Out(required=false)
	protected TipoConfirmacion confirmacionSeleccionada;
	
	protected TipoConfirmacion confirmacionSelec;
	
	
	public Producto getProductoBusqueda() {
		return productoBusqueda;
	}

	public void setProductoBusqueda(Producto productoBusqueda) {
		this.productoBusqueda = productoBusqueda;
	}

	public DescIndSitua getEventoBusqueda() {
		return eventoBusqueda;
	}

	public void setEventoBusqueda(DescIndSitua eventoBusqueda) {
		this.eventoBusqueda = eventoBusqueda;
	}

	public Contrapartida getContrapaBusq() {
		return contrapaBusq;
	}

	public void setContrapaBusq(Contrapartida contrapaBusq) {
		this.contrapaBusq = contrapaBusq;
	}

	public String getIdContrapartida() {
		return idContrapartida;
	}

	public void setIdContrapartida(String idContrapartida) {
		this.idContrapartida = idContrapartida;
	}

	public List<TipoConfirmacion> getListaTiposConfirm() {
		return listaTiposConfirm;
	}

	public void setListaTiposConfirm(List<TipoConfirmacion> listaTiposConfirm) {
		this.listaTiposConfirm = listaTiposConfirm;
	}

	public TipoConfirmacion getConfirmacionSelec() {
		return confirmacionSelec;
	}

	public void setConfirmacionSelec(TipoConfirmacion confirmacionSelec) {
		this.confirmacionSelec = confirmacionSelec;
	}

	public TipoConfirmacion getConfirmacionSeleccionada() {
		return confirmacionSeleccionada;
	}

	public void setConfirmacionSeleccionada(
			TipoConfirmacion confirmacionSeleccionada) {
		this.confirmacionSeleccionada = confirmacionSeleccionada;
	}

	public String getIdProductoSel() {
		return idProductoSel;
	}

	public void setIdProductoSel(String idProductoSel) {
		this.idProductoSel = idProductoSel;
	}

	public String getIdEventoSel() {
		return idEventoSel;
	}

	public void setIdEventoSel(String idEventoSel) {
		this.idEventoSel = idEventoSel;
	}

//	public ModeloConfirmacion getModelo() {
//		return modelo;
//	}
//
//	public void setModelo(ModeloConfirmacion modelo) {
//		this.modelo = modelo;
//	}

	public String getIdContrapartidaEdit() {
		return idContrapartidaEdit;
	}

	public void setIdContrapartidaEdit(String idContrapartidaEdit) {
		this.idContrapartidaEdit = idContrapartidaEdit;
	}
	
	
	
	
}
