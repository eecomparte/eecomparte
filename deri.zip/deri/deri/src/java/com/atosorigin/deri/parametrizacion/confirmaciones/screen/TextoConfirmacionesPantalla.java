package com.atosorigin.deri.parametrizacion.confirmaciones.screen;

import java.util.List;

import org.jboss.seam.ScopeType;
import org.jboss.seam.annotations.Name;
import org.jboss.seam.annotations.Out;
import org.jboss.seam.annotations.Scope;
import org.jboss.seam.annotations.datamodel.DataModel;
import org.jboss.seam.annotations.datamodel.DataModelSelection;

import com.atosorigin.deri.model.adminoper.DescripcionIdiomaTipCambio;
import com.atosorigin.deri.model.adminoper.TextoConfirmaciones;
import com.atosorigin.deri.model.catalogo.Producto;
import com.atosorigin.deri.model.contrapartida.Contrapartida;
import com.atosorigin.deri.model.gestionoperaciones.DescIndSitua;
import com.atosorigin.deri.model.gestionoperaciones.TipoConfirmacion;

/**
 *  Contiene los datos de pantalla necesarios para el caso de uso de parametrizacion de confirmaciones.
 */

@Name("textoConfirmacionesPantalla")
@Scope(ScopeType.CONVERSATION)
public class TextoConfirmacionesPantalla {

	protected String grupoSubyacente;
	private DescripcionIdiomaTipCambio idioma;
	
	
	protected Producto productoBusqueda;
	
	protected DescIndSitua eventoBusqueda;
	
	protected Contrapartida contrapaBusq;
	
	protected String idContrapartida;
	
	protected String idContrapartidaEdit;
	
	protected String idProductoSel;
	
	protected String idEventoSel;
	
//	protected ModeloConfirmacion modelo;
	

	@DataModel(value="listaDtTextoConfirmaciones")
	List<TextoConfirmaciones> listaTextoConfirm;
	
	@DataModelSelection(value="listaDtTextoConfirmaciones")
	@Out(required=false)
	protected TextoConfirmaciones textoConfirmacionSeleccionada;
	
	
	public Producto getProductoBusqueda() {
		return productoBusqueda;
	}

	public void setProductoBusqueda(Producto productoBusqueda) {
		this.productoBusqueda = productoBusqueda;
	}

	public DescIndSitua getEventoBusqueda() {
		return eventoBusqueda;
	}

	public void setEventoBusqueda(DescIndSitua eventoBusqueda) {
		this.eventoBusqueda = eventoBusqueda;
	}

	public Contrapartida getContrapaBusq() {
		return contrapaBusq;
	}

	public void setContrapaBusq(Contrapartida contrapaBusq) {
		this.contrapaBusq = contrapaBusq;
	}

	public String getIdContrapartida() {
		return idContrapartida;
	}

	public void setIdContrapartida(String idContrapartida) {
		this.idContrapartida = idContrapartida;
	}

		public String getIdProductoSel() {
		return idProductoSel;
	}

	public void setIdProductoSel(String idProductoSel) {
		this.idProductoSel = idProductoSel;
	}

	public String getIdEventoSel() {
		return idEventoSel;
	}

	public void setIdEventoSel(String idEventoSel) {
		this.idEventoSel = idEventoSel;
	}

//	public ModeloConfirmacion getModelo() {
//		return modelo;
//	}
//
//	public void setModelo(ModeloConfirmacion modelo) {
//		this.modelo = modelo;
//	}

	public String getIdContrapartidaEdit() {
		return idContrapartidaEdit;
	}

	public void setIdContrapartidaEdit(String idContrapartidaEdit) {
		this.idContrapartidaEdit = idContrapartidaEdit;
	}

	public String getGrupoSubyacente() {
		return grupoSubyacente;
	}

	public void setGrupoSubyacente(String grupoSubyacente) {
		this.grupoSubyacente = grupoSubyacente;
	}

	public DescripcionIdiomaTipCambio getIdioma() {
		return idioma;
	}

	public void setIdioma(DescripcionIdiomaTipCambio idioma) {
		this.idioma = idioma;
	}

	public List<TextoConfirmaciones> getListaTextoConfirm() {
		return listaTextoConfirm;
	}

	public void setListaTextoConfirm(List<TextoConfirmaciones> listaTextoConfirm) {
		this.listaTextoConfirm = listaTextoConfirm;
	}

	public TextoConfirmaciones getTextoConfirmacionSeleccionada() {
		return textoConfirmacionSeleccionada;
	}

	public void setTextoConfirmacionSeleccionada(
			TextoConfirmaciones textoConfirmacionSeleccionada) {
		this.textoConfirmacionSeleccionada = textoConfirmacionSeleccionada;
	}
	
	
	
	
}
