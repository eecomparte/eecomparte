package com.atosorigin.deri.parametrizacion.contrapartida.action;

import java.io.Serializable;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import org.jboss.seam.ScopeType;
import org.jboss.seam.annotations.In;
import org.jboss.seam.annotations.Name;
import org.jboss.seam.annotations.Out;
import org.jboss.seam.annotations.Scope;
import org.jboss.seam.international.StatusMessage.Severity;

import com.atosorigin.common.action.PaginatedListAction;
import com.atosorigin.common.action.PaginationData;
import com.atosorigin.common.formvalidator.FormValidator;
import com.atosorigin.deri.contrapartida.business.AnonimizacionBo;
import com.atosorigin.deri.contrapartida.business.ContrapartidaBo;
import com.atosorigin.deri.model.contrapartida.Contrapartida;
import com.atosorigin.deri.model.gestionoperaciones.HistoricoOperacion;
import com.atosorigin.deri.parametrizacion.contrapartida.screen.AnonimizacionesPantalla;
import com.atosorigin.deri.util.MessageBoxAction;
import com.atosorigin.deri.util.MsgBoxAction;

@Name("anonimizarAction")
@Scope(ScopeType.CONVERSATION)
@FormValidator
public class AnonimizarAction extends PaginatedListAction implements Serializable{

	private static final long serialVersionUID = 5256181260334479539L;

	private Boolean primeraEjecucionInit = null;
	
	@In("#{anonimizacionBo}")
	protected AnonimizacionBo anonimizacionBo;
	
	@In("#{contrapartidaBo}")
	protected ContrapartidaBo contrapartidaBo;
	
	@In(create=true)
	protected AnonimizacionesPantalla anonimizacionesPantalla;

	/** Inyeccion del componente necesario para mostrar mensajes de decisión al usuario */
	@In(create = true)
	private MsgBoxAction msgBoxAction;

	@Out(required = false, value = "anonimizarMessageBoxAction")
	private MessageBoxAction msgboxPanelAnonimizar;

	@In(required=true,value="idContrapartidaAnonimizar")
	private String idContrapartida; 

	@Override
	public List<HistoricoOperacion> getDataTableList() { 
		return anonimizacionesPantalla.getListaVistaAnonimizar();
	}

	@Override
	public void setDataTableList(List<?> dataTableList) {
		anonimizacionesPantalla.setListaVistaAnonimizar((List<HistoricoOperacion>) dataTableList);
	}
	
	@Override
	public void refrescarListaExcel() { 
		setExportExcel(false);
		cargarLista(idContrapartida,paginationData.getPaginationDataForExcel());
	}

	@Override
	protected void refreshListInternal() {
		setExportExcel(false);
		cargarLista(idContrapartida,paginationData);

	}
		
	public void init(){
		if (primeraEjecucionInit == null) {
			primeraEjecucionInit=true;
		}
		else{
			primeraEjecucionInit = false;
		}
		
		if(null==msgboxPanelAnonimizar){
			msgboxPanelAnonimizar = new MessageBoxAction();
		}
		
		if(primeraEjecucionInit){
			cargarLista(idContrapartida,paginationData);
		}
	}
	
	private void cargarLista(String idContrapartida, PaginationData pData){
		if(null!=idContrapartida && idContrapartida.trim().length()>0){
			Contrapartida contrapartida = contrapartidaBo.cargarContrapartida(idContrapartida.toUpperCase());
			if (null!=contrapartida){
				anonimizacionesPantalla.setContrapartida(contrapartida);
				anonimizacionesPantalla.setListaVistaAnonimizar(anonimizacionBo.obtenerHistoricoContrapartida(contrapartida, pData));
			}
		}
	}
	
	public Boolean getPrimeraEjecucionInit() {
		return primeraEjecucionInit;
	}

	public void setPrimeraEjecucionInit(Boolean primeraEjecucionInit) {
		this.primeraEjecucionInit = primeraEjecucionInit;
	}
	
	public void voidFunction(){
		msgBoxAction.voidFunction();
	}
	
	public void salirAnonimizar(){
		log.info("Se ha cancelado la anonimización.");
	}
	
	public void clickAnonimizar(){
		if(!validarFechas()){
			//No supera la validación, se requiere aceptación del usuario.
			iniciarPopUpAnonimizar();
		}
		else{
			//Supera la validación, se procede a anonimizar.
			anonimizar();
		}
	}
	
	/**
	 * Inicia el PopUp de confirmación de anonimización.
	 */
	private void iniciarPopUpAnonimizar(){
		msgboxPanelAnonimizar.init("anonimizar.popup.texto", "anonimizarAction.anonimizar()", "anonimizarAction.salirAnonimizar()", "messageBoxPanelAnonimizar");
	}

	/**
	 * Verifica si es necesario mostrar una advertencia para que el usuario decida si hay que anonimizar o cancelar la anonimización.
	 * 
	 * @return TRUE si la validación es correcta. FALSE si se requiere aprobación del usuario mediante PopUp.
	 */
	private boolean validarFechas(){
		boolean retorn = true;
		
		for(HistoricoOperacion histOpe : anonimizacionesPantalla.getListaVistaAnonimizar()){
			if(retorn && histOpe.getFechaCancelacion()!=null){
				retorn = hanPasado10Anos(histOpe.getFechaCancelacion(), new Date());
			}
			
			if(retorn){
				if(histOpe.getFechaVencimiento()==null){
					retorn = false;
				}
				else{
					retorn = hanPasado10Anos(histOpe.getFechaVencimiento(), new Date());
				}
			}
			
			if(!retorn){
				return retorn;
			}
		}
		return retorn;
	}
	
	/**
	 * Verifica que dadas 2 fechas, han pasado 10 años de diferencia.
	 * Se comparan años, meses y dias. Se ignoran el resto.
	 * 
	 * @param fecha1 Fecha de inicio.
	 * @param fecha2 Fech de fin.
	 * 
	 * @return TRUE si han pasado como mínimo 10 años. FALSE en caso contrario.
	 */
	private boolean hanPasado10Anos(Date fecha1,Date fecha2){
		boolean resultado = true;
		
		Calendar cal1 = Calendar.getInstance();
		cal1.setTime(fecha1);
		
		Calendar cal2 = Calendar.getInstance();
		cal2.setTime(fecha2);
		
		log.info("Se comparan las fechas:  " + cal1.get(Calendar.DAY_OF_MONTH) + "-" + cal1.get(Calendar.MONTH) + "-" + cal1.get(Calendar.YEAR) + " y " + cal2.get(Calendar.DAY_OF_MONTH) + "-" + cal2.get(Calendar.MONTH) + "-" + cal2.get(Calendar.YEAR));
		
		int anos = cal2.get(Calendar.YEAR)-cal1.get(Calendar.YEAR);
		if(anos>10){
			log.info("Mas de 10 años. Validacion correcta.");
		}
		else if(anos<10){
			log.info("Menos de 10 años. Validacion incorrecta.");
			resultado = false;
		}
		else{
			log.info("Está justo en 10 años, hay que mirar los meses.");
			int meses = cal2.get(Calendar.MONTH)-cal1.get(Calendar.MONTH);
			if(meses>0){
				log.info("Validacion de meses correcta.");
			}
			else if(meses<0){
				log.info("Validacion de meses incorrecta.");
				resultado = false;
			}
			else{
				log.info("Esta en el mismo año y el mismo mes, hay que mirar el dia."); 
				int dia = cal2.get(Calendar.DAY_OF_MONTH)-cal1.get(Calendar.DAY_OF_MONTH);
				if(dia>=0){
					log.info("Validación el dia correcta."); 
				}
				else{
					log.info("Validación el dia incorrecta."); 
					resultado = false;
				}
			}
		}
		return resultado;
	}
	
	public void anonimizar(){
		if(null!=idContrapartida && idContrapartida.trim().length()>0){
			int filasActualizadas = anonimizacionBo.anonimizarContrapartida(idContrapartida);
			if(filasActualizadas==0){
				//No se actualizó ningún registro, mostrar error.
				log.info("No se actualizó ningún registro para la contrapartida "+idContrapartida);
				statusMessages.add(Severity.INFO, "No se ha procesado la petición de anonimización correctamete.");
			}
			else if(filasActualizadas==1){
				//Se actualizó un registro.
				log.info("Se actualizó la contrapartida "+idContrapartida);
				statusMessages.add(Severity.INFO, "Se ha procesado la petición de anonimización correctamete.");
			}
			else{
				//No debería llegar aquí, mostrar error.
				log.info("Se ha obtenido un resultado inesperado al actualizar la contrapartida "+idContrapartida);
			}
		}
	}
}
