package com.atosorigin.deri.parametrizacion.contrapartida.action;

import java.util.List;

import org.jboss.seam.ScopeType;
import org.jboss.seam.annotations.In;
import org.jboss.seam.annotations.Name;
import org.jboss.seam.annotations.Out;
import org.jboss.seam.annotations.Scope;
import org.jboss.seam.international.StatusMessage.Severity;

import com.atosorigin.common.action.ModoPantalla;
import com.atosorigin.common.action.PaginatedListAction;
import com.atosorigin.common.constantes.Constantes;
import com.atosorigin.common.formvalidator.FormValidator;
import com.atosorigin.deri.contrapartida.business.ContactoContrapartidaBo;
import com.atosorigin.deri.model.contrapartida.Contrapartida;
import com.atosorigin.deri.model.liquidaciones.ReferenciaConfirmacion;
import com.atosorigin.deri.parametrizacion.contrapartida.screen.ContactoContrapartidaPantalla;

/**
 * Clase que actúa de action listener para el caso de uso de mantenimiento de plazos.
 */
@Name("contactoContrapartidaAction")
@Scope(ScopeType.CONVERSATION)
@FormValidator
public class ContactoContrapartidaAction extends PaginatedListAction{

	/**
	 * 
	 */
	private static final long serialVersionUID = 7152557091336890274L;


	/**
	 * Inyección del bean de Spring "plazoBo" que contiene los métodos de negocio
	 * para el caso de uso mantenimiento de plazos.
	 */
	@In("#{contactoContrapartidaBo}")
	protected ContactoContrapartidaBo contactoContrapartidaBo;


	/**
	 * Inyección del screen bean que contiene los datos de pantalla del caso de uso
	 * mantenimiento de plazos.
	 */
	@In(create=true)
	protected ContactoContrapartidaPantalla contactoContrapartidaPantalla;
	
	@In
	protected String contrapa;
	
	@Out(required=false)
	private ReferenciaConfirmacion referenciaConfirmacionEdit;
	
	public void init(){
		contactoContrapartidaPantalla.setContrapa(contrapa);
		buscar();
	}
	
	public boolean guardarValidator(){
		if (modoPantalla.equals(ModoPantalla.CREACION)){			
			return crearValidator();
		}
		return true;
	}
	
	public String guardar() {
		if (modoPantalla.equals(ModoPantalla.CREACION)){			
			return crear();
		}else if (modoPantalla.equals(ModoPantalla.EDICION)){				
			return modificar();
		}
		return "";
	}


	/**
	 * Actualiza la lista del grid de plazos
	 * 
	 */
	public void buscar() {
		paginationData.reset();
		refrescarLista();
		setPrimerAcceso(false);		
	}
	

		
	//Métodos necesarios para pantallas con grids.
	//Es necesario implementar estos métodos abstractos de PaginatedListAction
	@Override
	public List<ReferenciaConfirmacion> getDataTableList() {
		return contactoContrapartidaPantalla.getContactoList();
	}

	@Override
	@SuppressWarnings("unchecked")
	public void setDataTableList(List<?> dataTableList) {
		contactoContrapartidaPantalla.setContactoList((List<ReferenciaConfirmacion>)dataTableList);
	}

	@Override
	protected void refreshListInternal() {
		setExportExcel(false);
		List<ReferenciaConfirmacion> ql = (List<ReferenciaConfirmacion>)contactoContrapartidaBo.busqueda(contactoContrapartidaPantalla.getContrapa(), contactoContrapartidaPantalla.getFuncion(), contactoContrapartidaPantalla.getDepartamento(), paginationData);
		contactoContrapartidaPantalla.setContactoList(ql);
	}


	/**
	 * Prepara para entrar en el modo inspección de un plazo.
	 * 
	 */
	public void ver() {
		setModoPantalla(ModoPantalla.INSPECCION);
		referenciaConfirmacionEdit = contactoContrapartidaPantalla.getContacto();
	}
	
	/**
	 * Prepara para entrar en el modo edición de un plazo.
	 * 
	 */
	public void editar() {
		setModoPantalla(ModoPantalla.EDICION);
		referenciaConfirmacionEdit = contactoContrapartidaPantalla.getContacto();
	}

	/**
	 * Prepara para entrar en el modo creación de un plazo.
	 * 
	 */
	public void nuevo() {
		setModoPantalla(ModoPantalla.CREACION);
		referenciaConfirmacionEdit = new ReferenciaConfirmacion();
		contactoContrapartidaPantalla.setContacto(new ReferenciaConfirmacion());
		Contrapartida contrapartida = new Contrapartida();
		contrapartida.setId(contrapa);
		referenciaConfirmacionEdit.setContrapartida(contrapartida);
		contactoContrapartidaPantalla.setContacto(referenciaConfirmacionEdit);

	}
	
	/**
	 * Valida el plazo antes de insertarlo en la base de datos.
	 * 
	 */
	public boolean crearValidator() {

		ReferenciaConfirmacion contactoForm = this.referenciaConfirmacionEdit;
		long plazos = contactoContrapartidaBo.getObtenerContactoPorNombre(contactoForm.getContrapartida().getId(), contactoForm.getNombre());
		if (plazos > 0){
			statusMessages.addToControl("id", Severity.ERROR, "contacto.error.nombreyaexiste", Constantes.DEFAULT_MESSAGE_TEMPLATE);
			return false;
		}
		return true;
	}	
	
	/**
	 * Graba el plazo en la base de datos.
	 * 
	 */
	public String crear() {
		contactoContrapartidaBo.alta(this.referenciaConfirmacionEdit);
		//plazoBo.alta(plazoPantalla.getPlazo());		
		refrescarLista();
		return "success";
	}
	
	/**
	 * Verifica la existencia de un indice con el plazo a borrar.
	 * 
	 */
	public boolean borrarValidator() {
		ReferenciaConfirmacion contacto = this.contactoContrapartidaPantalla.getContacto();
		long confirmaciones = contactoContrapartidaBo.obtenerConfirmacionesReferenciadas(contacto.getId());
		if (confirmaciones > 0){
			statusMessages.addToControl("id", Severity.ERROR, "contacto.error.bajanopermitida", Constantes.DEFAULT_MESSAGE_TEMPLATE);
			return false;
		}		
		return true;
	}	
	/**
	 * Borra un plazo.
	 * 
	 */
	public void borrar() {
		contactoContrapartidaBo.borrar(contactoContrapartidaPantalla.getContacto());		
		refrescarLista();
		
	}

	/**
	 * Modifica un plazo.
	 * 
	 */
	public String modificar() {
		contactoContrapartidaBo.modificacion(this.referenciaConfirmacionEdit);	
		refrescarLista();
		return "success";		
	}
	
	@Override
	public void refrescarListaExcel() { 
		setExportExcel(true);
		contactoContrapartidaPantalla.setContactoList(contactoContrapartidaBo.busqueda(contactoContrapartidaPantalla.getContrapa(), contactoContrapartidaPantalla.getFuncion(), contactoContrapartidaPantalla.getDepartamento(), paginationData.getPaginationDataForExcel()));	
	}

	public String getContrapa() {
		return contrapa;
	}

	public void setContrapa(String contrapa) {
		this.contrapa = contrapa;
	}
	
	public boolean tieneConfirmacionesReferenciadas() {
		ReferenciaConfirmacion contacto = this.contactoContrapartidaPantalla.getContacto();
		long confirmaciones = contactoContrapartidaBo.obtenerConfirmacionesReferenciadas(contacto.getId());
		if (confirmaciones > 0){
			return true;
		}		
		return false;
	}	

}
