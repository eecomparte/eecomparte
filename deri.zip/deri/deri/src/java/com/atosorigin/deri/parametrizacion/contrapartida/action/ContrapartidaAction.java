package com.atosorigin.deri.parametrizacion.contrapartida.action;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;

import org.drools.util.StringUtils;
import org.jboss.seam.ScopeType;
import org.jboss.seam.annotations.In;
import org.jboss.seam.annotations.Name;
import org.jboss.seam.annotations.Out;
import org.jboss.seam.annotations.Scope;
import org.jboss.seam.core.Conversation;
import org.jboss.seam.core.ResourceBundle;
import org.jboss.seam.international.StatusMessage.Severity;
import org.jboss.seam.security.Credentials;

import com.ConstantesFD;
import com.atosorigin.common.action.ModoPantalla;
import com.atosorigin.common.action.PaginatedListAction;
import com.atosorigin.common.constantes.Constantes;
import com.atosorigin.common.formvalidator.FormValidator;
import com.atosorigin.common.utils.GenericUtils;
import com.atosorigin.deri.contrapartida.business.ContrapartidaBo;
import com.atosorigin.deri.contrapartida.mantagrupcontrapartida.business.MantAgrupContrapartidaBo;
import com.atosorigin.deri.grupobancario.business.GrupoBancarioBo;
import com.atosorigin.deri.model.contrapartida.Contrapartida;
import com.atosorigin.deri.model.contrapartida.GrupoBancario;
import com.atosorigin.deri.model.contrapartida.GrupoContrapartida;
import com.atosorigin.deri.model.contrapartida.TipoContrapartida;
import com.atosorigin.deri.model.contrapartida.UnidadNegocio;
import com.atosorigin.deri.model.gestionemir.CabeceraEmir;
import com.atosorigin.deri.parametrizacion.contrapartida.screen.ContrapartidaPantalla;
import com.atosorigin.deri.util.MessageBoxAction;
import com.atosorigin.deri.util.MsgBoxAction;

@Name("contrapartidaAction")
@Scope(ScopeType.CONVERSATION)
@FormValidator
public class ContrapartidaAction extends PaginatedListAction{

	@In(create=true)
	protected ContrapartidaPantalla contrapartidaPantalla;
	
	@In("#{grupoBancarioBo}")
	protected GrupoBancarioBo grupoBancarioBo;
	
	@In Credentials credentials;
	
	/**
	 * Inyección del bean de Spring "contrapartidaBo" que contiene los métodos de negocio
	 * 
	 */
	@In("#{contrapartidaBo}")
	protected ContrapartidaBo contrapartidaBo;
	
	@In("#{mantAgrupContrapartidaBo}")
	protected MantAgrupContrapartidaBo mantAgrupContrapartidaBo;
	
	@Out(required=false)
	private String contrapa;
	
	@In(create = true)
	MsgBoxAction msgBoxAction;
	
	@Out(required = false, value = "contrapartidaMessageBoxAction")
	private MessageBoxAction messageBoxContrapartidaAction;
	
	private Boolean primeraEjecucionInit=null;
	
	public void nuevo(){
		Contrapartida con = new Contrapartida();
		this.setEsEntidad(false);
		contrapartidaPantalla.setUnidadNegocio(new UnidadNegocio());
		con.setGrupoBancario(new GrupoBancario());
		con.setTipoContrapartida(new TipoContrapartida());
		
		con.setProyecto(Constantes.NOMBRE_PROYECTO_DERI);
		contrapartidaPantalla.setResidencia(false);
		contrapartidaPantalla.setTratEspecial(false);
		contrapartidaPantalla.setContrapartidaSel(con);
		contrapartidaPantalla.setIndColateralizada(false);
		contrapartidaPantalla.setIndFirmaManualForzada(false);
		
		contrapartidaPantalla.setIndIntraGrup(false);
		contrapartidaPantalla.setIndOfex(false);
		
		contrapartidaPantalla.getContrapartidaSel().setIndRepoOtc("O");
		//cargamos los valores del grupo bancario
		cargarDatosGrupoBancario();
		setModoPantalla(ModoPantalla.CREACION);
	}
	
	public void editar(){
		contrapartidaPantalla.setContrapartidaSel(contrapartidaPantalla.getContrapartidaSelection());
		//cargamos los valores del grupo bancario
		cargarDatosGrupoBancario();
		cargarUnidadNegocio(contrapartidaPantalla.getContrapartidaSelection());
		contrapartidaPantalla.setResidencia(GenericUtils.nvl(GenericUtils.SNBoolean(contrapartidaPantalla.getContrapartidaSelection().getIndicadorResidencia()),false));
		contrapartidaPantalla.setTratEspecial(GenericUtils.nvl(GenericUtils.SNBoolean(contrapartidaPantalla.getContrapartidaSelection().getIndTrataEspecial()),false));
		contrapartidaPantalla.setIndColateralizada(GenericUtils.nvl(GenericUtils.SNBoolean(contrapartidaPantalla.getContrapartidaSelection().getIndColateralizada()),false));
		contrapartidaPantalla.setIndFirmaManualForzada(GenericUtils.nvl(GenericUtils.SNBoolean(contrapartidaPantalla.getContrapartidaSelection().getIndFirmaManualForzada()),false));
		contrapartidaPantalla.setIndIntraGrup(GenericUtils.nvl(GenericUtils.SNBoolean(contrapartidaPantalla.getContrapartidaSelection().getIndIntraGrup()),false));
		contrapartidaPantalla.setIndOfex(GenericUtils.nvl(GenericUtils.SNBoolean(contrapartidaPantalla.getContrapartidaSelection().getIndOfex()),false));
		
		if (GenericUtils.isNullOrBlank(contrapartidaPantalla.getContrapartidaSel().getIndRepoOtc())){
			contrapartidaPantalla.getContrapartidaSel().setIndRepoOtc("O");
		}
		esEntidadFinaciera();
		setModoPantalla(ModoPantalla.EDICION);
	}

	public void mantContactos(){
		contrapartidaPantalla.setContrapartidaSel(contrapartidaPantalla.getContrapartidaSelection());
		//cargamos los valores del grupo bancario
		//cargarDatosGrupoBancario();
		//cargarUnidadNegocio(contrapartidaPantalla.getContrapartidaSelection());
		
		contrapartidaPantalla.setResidencia(GenericUtils.nvl(GenericUtils.SNBoolean(contrapartidaPantalla.getContrapartidaSelection().getIndicadorResidencia()),false));
		contrapartidaPantalla.setTratEspecial(GenericUtils.nvl(GenericUtils.SNBoolean(contrapartidaPantalla.getContrapartidaSelection().getIndTrataEspecial()),false));
		contrapartidaPantalla.setIndColateralizada(GenericUtils.nvl(GenericUtils.SNBoolean(contrapartidaPantalla.getContrapartidaSelection().getIndColateralizada()),false));
		contrapartidaPantalla.setIndFirmaManualForzada(GenericUtils.nvl(GenericUtils.SNBoolean(contrapartidaPantalla.getContrapartidaSelection().getIndFirmaManualForzada()),false));
		contrapartidaPantalla.setIndIntraGrup(GenericUtils.nvl(GenericUtils.SNBoolean(contrapartidaPantalla.getContrapartidaSelection().getIndIntraGrup()),false));
		contrapartidaPantalla.setIndOfex(GenericUtils.nvl(GenericUtils.SNBoolean(contrapartidaPantalla.getContrapartidaSelection().getIndOfex()),false));
		contrapa = contrapartidaPantalla.getContrapartidaSelection().getId();
		esEntidadFinaciera();
		setModoPantalla(ModoPantalla.EDICION);
	}
	
	/**
	 * Carga la unidad de negocio asociada al grupo contrapartida de la contrapartida seleccionada
	 * En el caso de que la contrapartida pertenezca a varios grupos, deberá mostrarse el mensajes:
	 * No se puede recuperar la unidad de Negocio porque esta contrapartida pertenece a más de una Agrupación. Si desea actualizar los datos contacte con Mantenimiento
	 * y no permitir al usuario modificar la Contrapartida
	 * @param contrapartida
	 */
	public void cargarUnidadNegocio(Contrapartida contrapartida){
		if (!GenericUtils.isNullOrBlank(contrapartida)){
			Set<GrupoContrapartida> grupoContrapartidas = contrapartida.getGrupoContrapartidas();
			if (!grupoContrapartidas.isEmpty()){
				if (grupoContrapartidas.size()==1){
					contrapartidaPantalla.setUnidadNegocio(contrapartidaBo.cargarUnidadNegocio(grupoContrapartidas.iterator().next().getId().getAgrupacionContrapartida().getId().toString()));						
				}else{
					statusMessages.add(Severity.INFO, "#{messages['contrapartida.error.unidadNegocio']}");					
				}
			}
		}
	}
	
	public void ver(){
		contrapartidaPantalla.setContrapartidaSel(contrapartidaPantalla.getContrapartidaSelection());
			
		//cargamos los valores del grupo bancario
		cargarDatosGrupoBancario();
		
		//SMM Correcion
		contrapartidaPantalla.setResidencia(GenericUtils.nvl(GenericUtils.SNBoolean(contrapartidaPantalla.getContrapartidaSelection().getIndicadorResidencia()),false));
		contrapartidaPantalla.setTratEspecial(GenericUtils.nvl(GenericUtils.SNBoolean(contrapartidaPantalla.getContrapartidaSelection().getIndTrataEspecial()),false));
		contrapartidaPantalla.setIndColateralizada(GenericUtils.nvl(GenericUtils.SNBoolean(contrapartidaPantalla.getContrapartidaSelection().getIndColateralizada()),false));
		contrapartidaPantalla.setIndFirmaManualForzada(GenericUtils.nvl(GenericUtils.SNBoolean(contrapartidaPantalla.getContrapartidaSelection().getIndFirmaManualForzada()),false));
		contrapartidaPantalla.setIndIntraGrup(GenericUtils.nvl(GenericUtils.SNBoolean(contrapartidaPantalla.getContrapartidaSelection().getIndIntraGrup()),false));
		contrapartidaPantalla.setIndOfex(GenericUtils.nvl(GenericUtils.SNBoolean(contrapartidaPantalla.getContrapartidaSelection().getIndOfex()),false));
		
		cargarUnidadNegocio(contrapartidaPantalla.getContrapartidaSelection());
		setModoPantalla(ModoPantalla.INSPECCION);
	}

	public String guardar(){
		//SMM : inc 757, la unidad de negocio es opcional
		String unNegAgrupContrapa = null;
		String negocioContrapa = null;
		
		if (!GenericUtils.isNullOrBlank(contrapartidaPantalla.getUnidadNegocio())){
			negocioContrapa = contrapartidaPantalla.getUnidadNegocio().getCodigo();
			unNegAgrupContrapa = contrapartidaBo.obtenerUnidadNegocioAgrcontr("AGRCONTR", "AGRCONTR", negocioContrapa);
		}
		if(contrapartidaPantalla.isTratEspecial()){
			contrapartidaPantalla.getContrapartidaSel().setIndTrataEspecial("S");
		}else{
			contrapartidaPantalla.getContrapartidaSel().setIndTrataEspecial("N");
		}
		if(contrapartidaPantalla.isResidencia()){
			contrapartidaPantalla.getContrapartidaSel().setIndicadorResidencia("S");
		}else{
			contrapartidaPantalla.getContrapartidaSel().setIndicadorResidencia("N");
		}

		if(contrapartidaPantalla.isIndColateralizada()){
			contrapartidaPantalla.getContrapartidaSel().setIndColateralizada("S");
		}else{
			contrapartidaPantalla.getContrapartidaSel().setIndColateralizada("N");
		}

		if(contrapartidaPantalla.isIndFirmaManualForzada()){
			contrapartidaPantalla.getContrapartidaSel().setIndFirmaManualForzada("S");
			contrapartidaPantalla.getContrapartidaSel().setIndBsOnl(ConstantesFD.VALIDACION_FIRMANTES_CONTRAPANOFD);
		}else{
			contrapartidaPantalla.getContrapartidaSel().setIndFirmaManualForzada("N");
		}

		if(contrapartidaPantalla.isIndIntraGrup()){
			contrapartidaPantalla.getContrapartidaSel().setIndIntraGrup("S");
		}else{
			contrapartidaPantalla.getContrapartidaSel().setIndIntraGrup("N");
		}
		
		if(contrapartidaPantalla.isIndOfex()){
			contrapartidaPantalla.getContrapartidaSel().setIndOfex("S");
		}else{
			contrapartidaPantalla.getContrapartidaSel().setIndOfex("N");
		}
		
		
		
		contrapartidaPantalla.getContrapartidaSel().setGrupoBancario(grupoBancarioBo.cargar(contrapartidaPantalla.getIdGBSelected()));  
		contrapartidaBo.guardar(contrapartidaPantalla.getContrapartidaSel(),negocioContrapa ,unNegAgrupContrapa, credentials.getUsername());
		contrapartidaPantalla.setUnidadNegocio(null);
		contrapartidaBo.recargar(contrapartidaPantalla.getContrapartidaSel());
		refrescarLista();
		return Constantes.SUCCESS;
	}
	
	public void salirDetalle(){
		contrapartidaPantalla.setUnidadNegocio(null);
	}
	
	public boolean guardarValidator(){
		if(getModoPantalla().equals(ModoPantalla.CREACION)){
			if(contrapartidaBo.cargar(contrapartidaPantalla.getContrapartidaSel().getId()) != null){
				statusMessages.addToControl("codigo", Severity.ERROR, "#{messages['contrapartida.error.contrapartidaYaExiste']}");
				return false;
			}
		}
		GrupoBancario grupo = grupoBancarioBo.cargar(contrapartidaPantalla.getIdGBSelected());
		if(GenericUtils.isNullOrBlank(grupo)){
			statusMessages.addToControl("codigo", Severity.ERROR, "#{messages['contrapartida.error.grupoBancario']}");
			return false;
		}
		if(!GenericUtils.isNullOrBlank(contrapartidaPantalla.getContrapartidaSel().getTelefono())){
			try{
				Long.parseLong(contrapartidaPantalla.getContrapartidaSel().getTelefono());
			}catch(NumberFormatException e){
				statusMessages.addToControl("telefono", Severity.ERROR, "#{messages['contrapartida.error.telefono']}");
				return false;
			}
		}
		if(!GenericUtils.isNullOrBlank(contrapartidaPantalla.getContrapartidaSel().getFax())){
			try{
				Long.parseLong(contrapartidaPantalla.getContrapartidaSel().getFax());
			}catch(NumberFormatException e){
				statusMessages.addToControl("fax", Severity.ERROR, "#{messages['contrapartida.error.fax']}");
				return false;
			}
		}
		if(!GenericUtils.isNullOrBlank(contrapartidaPantalla.getContrapartidaSel().getNumeroPersona())){
			if (contrapartidaBo.verificarNumPersona(contrapartidaPantalla.getContrapartidaSel().getId(), contrapartidaPantalla.getContrapartidaSel().getNumeroPersona())){
				statusMessages.addToControl("numPersona", Severity.ERROR, "#{messages['contrapartida.error.numPersonaYaExiste']}");
				return false;
			}
			
		}
		
		
		return true;
	}
	
	public void borrar(){
		contrapartidaBo.borrar(contrapartidaPantalla.getContrapartidaSel());
		refrescarLista();
	}
	
	
	@Override
	public List<?> getDataTableList() {
		return contrapartidaPantalla.getContrapartidaList();
	}

	public void buscar(){
		paginationData.reset();
		refrescarLista();
		if(contrapartidaPantalla.getContrapartidaList().size() == 0){
			statusMessages.add(Severity.INFO, "#{messages['contrapartida.lista.vacia']}");
		}
		setPrimerAcceso(false);
	}
	
	@Override
	protected void refreshListInternal() {
		setExportExcel(false);
		String idContrapa = null;
		if(!GenericUtils.isNullOrBlank(contrapartidaPantalla.getTipoContSelec())){
			idContrapa = contrapartidaPantalla.getTipoContSelec().getId();
		}
		List<Contrapartida> ql = new ArrayList<Contrapartida>();
		if(contrapartidaPantalla.isColateralizadaBuscar()){
			ql = (List<Contrapartida>) contrapartidaBo.buscarContrapartidas(idContrapa, contrapartidaPantalla.getDescripcion(),
					contrapartidaPantalla.getCodigo(), contrapartidaPantalla.getGrupoBancarioObt(),Constantes.APLICACION_COLAT, paginationData);
		}else{
			ql = (List<Contrapartida>) contrapartidaBo.buscarContrapartidas(idContrapa, contrapartidaPantalla.getDescripcion(),
					contrapartidaPantalla.getCodigo(), contrapartidaPantalla.getGrupoBancarioObt(), paginationData); 
		}
		
		contrapartidaPantalla.setContrapartidaList(ql);
		
	}

	@Override
	public void refrescarListaExcel() {
		setExportExcel(true);
		String idContrapa = null;
		if(!GenericUtils.isNullOrBlank(contrapartidaPantalla.getTipoContSelec())){
			idContrapa = contrapartidaPantalla.getTipoContSelec().getId();
		}
		
		List<Contrapartida> ql = new ArrayList<Contrapartida>();
		if(contrapartidaPantalla.isColateralizadaBuscar()){
			ql = (List<Contrapartida>) contrapartidaBo.buscarContrapartidas(idContrapa, contrapartidaPantalla.getDescripcion(),
					contrapartidaPantalla.getCodigo(), contrapartidaPantalla.getGrupoBancarioObt(),Constantes.APLICACION_COLAT, paginationData.getPaginationDataForExcel());
		}else{
			ql = (List<Contrapartida>) contrapartidaBo.buscarContrapartidas(idContrapa, contrapartidaPantalla.getDescripcion(),
					contrapartidaPantalla.getCodigo(), contrapartidaPantalla.getGrupoBancarioObt(), paginationData.getPaginationDataForExcel()); 
		}
		
		contrapartidaPantalla.setContrapartidaList(ql);
		
	}
	
	private void cargarDatosGrupoBancario() {
		GrupoBancario gb = contrapartidaPantalla.getContrapartidaSel().getGrupoBancario();
		contrapartidaPantalla.setIdGBSelected(gb.getId());
		contrapartidaPantalla.setDescGBSelected(gb.getDescripcion());
	}
	
	/**
	 * EOB metodo para comprobar que la seleccion es Entidades Financieres
	 */
	public boolean esEntidad = false;
	
	public boolean isEsEntidad() {
		return esEntidad;
	}

	public void setEsEntidad(boolean esEntidad) {
		this.esEntidad = esEntidad;
	}

	public boolean esEntidadFinaciera(){
		
		if  (("C").equals(contrapartidaPantalla.getContrapartidaSel().getTipoContrapartida().getId())){
			esEntidad = true;
		}else{
			esEntidad = false;
		}
		return esEntidad;
	}

	@SuppressWarnings("unchecked")
	@Override
	public void setDataTableList(List<?> dataTableList) {
		contrapartidaPantalla.setContrapartidaList((List<Contrapartida>)dataTableList);
	}
	
	public void salir(){
		Conversation conversacion = Conversation.instance();
		//Volvemos a la anterior conversación
		if(conversacion.isNested()){
			conversacion.redirectToParent();
		} else {
			redirectToURL("/home.seam");
			conversacion.endAndRedirect();
		}
	}

	public MantAgrupContrapartidaBo getMantAgrupContrapartidaBo() {
		return mantAgrupContrapartidaBo;
	}

	public void setMantAgrupContrapartidaBo(
			MantAgrupContrapartidaBo mantAgrupContrapartidaBo) {
		this.mantAgrupContrapartidaBo = mantAgrupContrapartidaBo;
	}

	public GrupoBancarioBo getGrupoBancarioBo() {
		return grupoBancarioBo;
	}

	public void setGrupoBancarioBo(GrupoBancarioBo grupoBancarioBo) {
		this.grupoBancarioBo = grupoBancarioBo;
	}

	public ContrapartidaBo getContrapartidaBo() {
		return contrapartidaBo;
	}

	public void setContrapartidaBo(ContrapartidaBo contrapartidaBo) {
		this.contrapartidaBo = contrapartidaBo;
	}
	
	public void init(){
		primeraEjecucionInit=null;
		
		if(null==messageBoxContrapartidaAction){
			messageBoxContrapartidaAction = new MessageBoxAction();
		}
	}
	
	public void initDetalle(){
		if (primeraEjecucionInit == null) {
			primeraEjecucionInit=true;
		} 
		else{
			primeraEjecucionInit = false;
		}
		
		if(null==messageBoxContrapartidaAction){
			messageBoxContrapartidaAction = new MessageBoxAction();
		}
		
		if(primeraEjecucionInit){
			if(null!=contrapartidaPantalla.getContrapartidaSel() && null!=contrapartidaPantalla.getContrapartidaSel().getId() && !StringUtils.isEmpty(contrapartidaPantalla.getContrapartidaSel().getId().trim())){
				String contrapartida = contrapartidaPantalla.getContrapartidaSel().getId();
				if (!GenericUtils.isNullOrBlank(contrapartida)){
					 Contrapartida contrapObtenida2 = contrapartidaBo.cargarContrapartida(contrapartida.toUpperCase());	
					if (!GenericUtils.isNullOrBlank(contrapObtenida2) && !GenericUtils.isNullOrBlank(contrapObtenida2.getIndBloqueo()) && "S".equalsIgnoreCase(contrapObtenida2.getIndBloqueo())){
						iniciarPopUpContrapartidaBloqueada();
					}
				}
			}
		}
	}
	
	/**
	 * Mostrar PopUp cuando una contrapartida está bloqueada (no bloqueante)
	 */
	public void onVerificarContrapartidaBloqueada() {
		String contrapartida = contrapartidaPantalla.getCodigo();
		if (!GenericUtils.isNullOrBlank(contrapartida)){
			 Contrapartida contrapObtenida2 = contrapartidaBo.cargarContrapartida(contrapartida.toUpperCase());	
			if (null!=contrapObtenida2 && !GenericUtils.isNullOrBlank(contrapObtenida2.getIndBloqueo()) && "S".equalsIgnoreCase(contrapObtenida2.getIndBloqueo())){
				iniciarPopUpContrapartidaBloqueada();
			}
		}
	}
	
	private void iniciarPopUpContrapartidaBloqueada(){
		messageBoxContrapartidaAction.init(ResourceBundle.instance().getString("contrapartida.messages.contrapartida.bloqueada.texto"), "contrapartidaAction.voidFunction()", null,"messageBoxPanelContrapa");
	}

	public void voidFunction(){
		msgBoxAction.voidFunction();
	}

	public String getRowClasses(){
    	StringBuilder builder = new StringBuilder();
    	int i=0;
    	
    	Contrapartida contrapartidaObtenida = null;
    	for(Contrapartida contrapartidaActual : contrapartidaPantalla.getContrapartidaList()){
    		if(i>0){
				builder.append(",");
			}
    		
    		if(null!=contrapartidaActual){
    				contrapartidaObtenida = contrapartidaActual;
    		}
    		
    		if(i%2==0){
    			if(null!=contrapartidaObtenida && !GenericUtils.isNullOrBlank(contrapartidaObtenida.getIndBloqueo()) && "S".equalsIgnoreCase(contrapartidaObtenida.getIndBloqueo())){
    				builder.append("oddRowRed");
    			}
    			else{
    				builder.append("oddRow");
    			}
    		}
    		else{
    			if(null!=contrapartidaObtenida && !GenericUtils.isNullOrBlank(contrapartidaObtenida.getIndBloqueo()) && "S".equalsIgnoreCase(contrapartidaObtenida.getIndBloqueo())){
    				builder.append("evenRowRed");
    			}
    			else{
    				builder.append("evenRow");
    			}
    		}
    		i++;
    		contrapartidaObtenida = null;
    	}
    	
    	return builder.toString();
    }
	
}