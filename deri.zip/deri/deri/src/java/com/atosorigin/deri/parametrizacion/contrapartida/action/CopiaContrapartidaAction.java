package com.atosorigin.deri.parametrizacion.contrapartida.action;

import java.util.Date;
import java.util.List;

import org.jboss.seam.ScopeType;
import org.jboss.seam.annotations.Factory;
import org.jboss.seam.annotations.In;
import org.jboss.seam.annotations.Out;
import org.jboss.seam.annotations.Name;

import org.jboss.seam.annotations.Scope;
import org.jboss.seam.core.Conversation;
import org.jboss.seam.core.ResourceBundle;
import org.jboss.seam.international.StatusMessage.Severity;

import com.atosorigin.common.action.GenericAction;
import com.atosorigin.common.action.ModoPantalla;
import com.atosorigin.common.action.PaginatedListAction;
import com.atosorigin.common.action.PaginationData;
import com.atosorigin.common.constantes.Constantes;
import com.atosorigin.common.formvalidator.FormValidator;
import com.atosorigin.common.utils.GenericUtils;
import com.atosorigin.deri.common.parametrosPantalla.ParametrosOutAgenda;
import com.atosorigin.deri.contrapartida.business.ContrapartidaBo;
import com.atosorigin.deri.contrapartida.docscontrapartida.business.DocsContrapartidaBo;
import com.atosorigin.deri.contrapartida.manttipostocumento.business.MantTiposDocumentoBo;
import com.atosorigin.deri.model.adminoper.DescripcionEntidadOperacion;
import com.atosorigin.deri.model.contrapartida.Contrapartida;
import com.atosorigin.deri.model.contrapartida.DocsContrapartida;
import com.atosorigin.deri.model.contrapartida.DocsContrapartidaId;
import com.atosorigin.deri.model.contrapartida.EstadoDocumentoContrapartida;
import com.atosorigin.deri.model.contrapartida.TipoContrapartida;
import com.atosorigin.deri.model.contrapartida.TiposDocumento;
import com.atosorigin.deri.model.gestionoperaciones.Operacion;
import com.atosorigin.deri.parametrizacion.contrapartida.screen.CopiaContrapartidaPantalla;

import com.atosorigin.deri.util.MessageBoxAction;
import com.atosorigin.deri.util.MsgBoxAction;

/**
 * Clase action listener para el caso de uso de documentos por contrapartida.
 */
@Name("copiaContrapartidaAction")
@Scope(ScopeType.CONVERSATION)
@FormValidator
public class CopiaContrapartidaAction extends GenericAction {

	/**
	 * Inyección del bean de Spring "docsContrapartidaBo" que contiene los métodos de negocio
	 * para el caso de uso documentos por contrapartida.
	 */
//	@In("#{copiaContrapartidaBo}")
//	protected DocsContrapartidaBo docsContrapartidaBo;

	/**
	 * Inyección del bean de Spring "contrapartidaBo" que contiene los métodos de negocio
	 * para el caso de uso contrapartidas.
	 */
	@In("#{contrapartidaBo}")
	protected ContrapartidaBo contrapartidaBo;
	
	/**
	 * Inyección del screen bean que contiene los datos de pantalla del caso de uso
	 * documentos por contrapartida.
	 */
	@In(create=true)
	protected CopiaContrapartidaPantalla copiaContrapartidaPantalla;

	/** Contrapartida seleccionada en la pantalla de mantenimiento de contrapartidas */
	@In(required=false)
    protected Contrapartida contrapartidaSelection;
	
	/** Variable para establecer si se llega a la pantalla de documentos por contrapartida
	 * desde mantenimiento de contrapartidas o desde agenda */
	private String modo;
	
	/**
	 * Inyección datos provenientes de Agenda
	 */
	@In(required = false, value="#{parametrosOutAgenda}")
	protected ParametrosOutAgenda parametrosOutAgenda;
	
	@In(create = true)
	MsgBoxAction msgBoxAction;
	
	@Out(required = false, value = "copiaContrapartidaMessageBoxAction")
	private MessageBoxAction messageBoxCopiaContrapartidaAction;
	
	/** Actualiza la lista del grid de documentos por contrapartida */
	public void buscar() {
		this.setModo(Constantes.CADENA_VACIA); /** Limpiamos el modo al pulsar buscar */
		setPrimerAcceso(false);
	}
	
	
	public void salir(){
		Conversation conversacion = Conversation.instance();
		//Volvemos a la anterior conversación
		if(conversacion.isNested()){
			conversacion.redirectToParent();
		} else {
				redirectToURL("/home.seam");
			}
			conversacion.endAndRedirect();
		}
	public void comprobarContrato() {
		if ( copiaContrapartidaPantalla.getDocContrapartida().getId()!=null && 
				copiaContrapartidaPantalla.getDocContrapartida().getId().getTiposDocumento()!=null &&
				!"CMOF".equals(copiaContrapartidaPantalla.getDocContrapartida().getId().getTiposDocumento().getId()) && 
				GenericUtils.isNullOrBlank(copiaContrapartidaPantalla.getDocContrapartida().getId().getContrato()) ){
			copiaContrapartidaPantalla.getDocContrapartida().getId().setContrato(copiaContrapartidaPantalla.getDocContrapartida().getId().getTiposDocumento().getId());
		}
	}

	
	/** Método encargado de realizar las validaciones para el alta y edición de
	 * documentos por contrapartida. Comprueba que la contrapartida y el tipo documento a asociar
	 * existen, compara las fechas de cancelación y/o firma con la fecha de negociación y si es un alta
	 * comprueba que no exista ya un registro con el mismo id */
	public Boolean guardarValidator(){
		
		return true;
	}

	/** Graba el documento por contrapartida en la base de datos. */
	public String guardar() {
		
		return Constantes.CONSTANTE_SUCCESS;
	}
	
	/** Prepara para cargar el grid de la pantalla según se acceda desde Mantenimiento de
	 * contrapartidas o desde la pantalla de Agenda */
	public void preCargarPantalla(String modo, String codevent, String estadoev, Date fechatraIni, Date fechatraFin){
		
		if (modo.equalsIgnoreCase(Constantes.MODO_MC)){ /** Viene desde mantenimiento de contrapartida */
				this.copiaContrapartidaPantalla.setVieneMantContrapa(true);
				this.copiaContrapartidaPantalla.setVieneAgenda(false);
				this.copiaContrapartidaPantalla.getContrapaBusq().setId(contrapartidaSelection.getId());
				// Salvador venimos de Contrapa
				this.copiaContrapartidaPantalla.getContrapaBusq().setDescCorta(contrapartidaBo.cargar(contrapartidaSelection.getId()).getDescCorta());				
				setPrimerAcceso(false);
	}
	}
	
	/**
	 * Recoge los valores (boolean) de los checkboxes de pantalla (Requerido, IndicadorAnexo y FirmaAnexo)
	 * y el campo de texto "obligatorio", y los transforma a los valores a persistir en bbdd (S, N) para la 
	 * entity DocsContrapartida.
	 * @param docsContrapartida Entity a persistir en bbdd (ya sea en alta o en edición)
	 * @return DocsContrapartida con los valores de Requerido, IndicadorAnexo y FirmaAnexo adaptados,
	 */
	private DocsContrapartida formToBean(DocsContrapartida docsContrapartida){
		
		DocsContrapartida docsContrapaModif = docsContrapartida;
		
		/** Requerido */
		if (copiaContrapartidaPantalla.getEsRequerido()){
			docsContrapaModif.setDocRequerido(Constantes.CONSTANTE_SI);
		} else {
			docsContrapaModif.setDocRequerido(Constantes.CONSTANTE_NO);
		}
		
		/** Firma Anexo */
		if (copiaContrapartidaPantalla.getFirmaAnexo()){
			docsContrapaModif.setFirmaAnexo(Constantes.CONSTANTE_SI);
		} else {
			docsContrapaModif.setFirmaAnexo(Constantes.CONSTANTE_NO);
		}
		
		/** Indicador Anexo */
		if (copiaContrapartidaPantalla.getIndicadorAnexo()){
			docsContrapaModif.setIndicadorAnexo(Constantes.CONSTANTE_SI);
		} else {
			docsContrapaModif.setIndicadorAnexo(Constantes.CONSTANTE_NO);
		}
		
		/** Obligatorio */
		if (!GenericUtils.isNullOrBlank(copiaContrapartidaPantalla.getObligatorio()) && copiaContrapartidaPantalla.getObligatorio().equalsIgnoreCase(ResourceBundle.instance().getString("docsContrapartida.obligatorio.si"))){
			docsContrapaModif.getId().getTiposDocumento().setObligatorio(Constantes.CONSTANTE_SI);
		} else {
			docsContrapaModif.getId().getTiposDocumento().setObligatorio(Constantes.CONSTANTE_NO);
		}
		
		return docsContrapaModif;
	}
	
	
	/**
	 * Busca el código de Contrapartida informada. Si no existe, vuelve a buscarla pero con un codigo que empiece
	 * por el nombre introducido. Si encuentra una y sólo una, la informa.
	 * Si no la encuentra, o encuentra más de una, se busca el codigo introducido como descripción
	 * exacta de alguna contrapartida. Si encuentra una y sólo una, la informa.
	 * Si no, muestra mensaje de advertencia al usuario.
	 * @param idContrapa Id de la contrapartida, valor informado por el usuario.
	 * @return true si encuentra una y solo una contrapartida, false en caso contrario
	 */
	private boolean validaContrapaExiste(String idContrapa) {
		
		boolean existeContrapa = true;
		List<Contrapartida> contrapaEncontradas = null;
		
		if(GenericUtils.isNullOrBlank(this.contrapartidaBo.cargar(idContrapa))){
			contrapaEncontradas = this.contrapartidaBo.buscarContrapartidas(null, null, idContrapa.concat(Constantes.CONSTANTE_PERCENT), null, null);
			if(GenericUtils.isNullOrBlank(contrapaEncontradas) || contrapaEncontradas.isEmpty() || 
					contrapaEncontradas.size() > 1){
				contrapaEncontradas = this.contrapartidaBo.buscarContrapartidas(null, idContrapa, null, null, null);
				if(GenericUtils.isNullOrBlank(contrapaEncontradas) || contrapaEncontradas.isEmpty()){
					// Si no la encuentra, emite el mensaje: 'Contrapartida no Definida'
					existeContrapa = false;
					statusMessages.addToControl("idContrapa", Severity.ERROR, "#{messages['docsContrapartida.error.contrapartida.noexiste']}");
				} else if (contrapaEncontradas.size() > 1){
					// Si encuentra más de una, emite: 'Descripción Insuficiente para Decidir el Dato'
					existeContrapa = false;
					statusMessages.addToControl("idContrapa", Severity.ERROR, "#{messages['docsContrapartida.error.nodefinido']}");
				} else { 
					copiaContrapartidaPantalla.getDocContrapartida().getId().setContrapartida(contrapaEncontradas.get(0));
				}
			} else {
				copiaContrapartidaPantalla.getDocContrapartida().getId().setContrapartida(contrapaEncontradas.get(0));
			}
		}
		return existeContrapa;
	}
	
	public boolean cambiarValidator(){
		return validaContrapaExiste(copiaContrapartidaPantalla.getContrapaBusq().getId());
	}
	
	public void cambiar(){
//		pkg_contrapa
//		FUNCTION CAMBIO_CONTRAPARTIDA(PCONTRAPA_ORIG VARCHAR2, PCONTRAPA_DEST VARCHAR2, PMSG_OUT OUT VARCHAR2) RETURN NUMBER
//		
		StringBuffer errorCode = new StringBuffer();
		if (contrapartidaBo.callCambioContrapartida(copiaContrapartidaPantalla.getContrapaBusq(),copiaContrapartidaPantalla.getContrapartidaDestino(),errorCode)){
			statusMessages.add(Severity.INFO, "#{messages['copiaContrapartida.copiaCorrecta']");
		}else{
			statusMessages.addFromResourceBundle(Severity.ERROR,"copiaContrapartida.copiaError", errorCode);
		}
	}
	
	public void recargarContrapartida(){
		 
		if (!GenericUtils.isNullOrBlank(copiaContrapartidaPantalla.getContrapaBusq())){
			String idContrapa =copiaContrapartidaPantalla.getContrapaBusq().getId();
			if (!GenericUtils.isNullOrBlank(idContrapa)){
				Contrapartida contrapa = contrapartidaBo.cargar(idContrapa);
				if (!GenericUtils.isNullOrBlank(contrapa)){
					copiaContrapartidaPantalla.getContrapaBusq().setDescCorta(contrapa.getDescCorta());
				}
			}
		}
		
	}

	public String getModo() {
		return modo;
	}

	public void setModo(String modo) {
		this.modo = modo;
	}

	public void init(){
		if(null==messageBoxCopiaContrapartidaAction){
			messageBoxCopiaContrapartidaAction = new MessageBoxAction();
		}
	}
	
	public void voidFunction(){
		msgBoxAction.voidFunction();
	}
	
	/**
	 * Mostrar PopUp cuando una contrapartida está bloqueada (no bloqueante)
	 */
	public void onVerificarContrapartidaBloqueada() {
		String idContrapa =copiaContrapartidaPantalla.getContrapaBusq().getId();
		Contrapartida contrapObtenida2;
		if (!GenericUtils.isNullOrBlank(idContrapa)){
			contrapObtenida2 = contrapartidaBo.cargarContrapartida(idContrapa.toUpperCase());	
			if (null!=contrapObtenida2 && !GenericUtils.isNullOrBlank(contrapObtenida2.getIndBloqueo()) && "S".equalsIgnoreCase(contrapObtenida2.getIndBloqueo())){
				messageBoxCopiaContrapartidaAction.init(ResourceBundle.instance().getString("copiaContrapartida.messages.contrapartida.bloqueada.texto"), "liquidacionesAction.voidFunction()",null,"messageBoxPanelContrapa");
			}
		}
		
		recargarContrapartida();
	}

}
