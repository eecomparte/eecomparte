package com.atosorigin.deri.parametrizacion.contrapartida.screen;

import java.util.List;

import org.jboss.seam.ScopeType;
import org.jboss.seam.annotations.Name;
import org.jboss.seam.annotations.Scope;
import org.jboss.seam.annotations.datamodel.DataModel;

import com.atosorigin.deri.model.contrapartida.Contrapartida;
import com.atosorigin.deri.model.gestionoperaciones.HistoricoOperacion;

@Name("anonimizacionesPantalla")
@Scope(ScopeType.CONVERSATION)
public class AnonimizacionesPantalla {

	@DataModel(value="listaOpeVistaAnonimizar")
	protected List<HistoricoOperacion> listaVistaAnonimizar;
	
	private Contrapartida contrapartida;

	public Contrapartida getContrapartida() {
		return contrapartida;
	}

	public void setContrapartida(Contrapartida contrapartida) {
		this.contrapartida = contrapartida;
	}

	public List<HistoricoOperacion> getListaVistaAnonimizar() {
		return listaVistaAnonimizar;
	}

	public void setListaVistaAnonimizar(List<HistoricoOperacion> listaVistaAnonimizar) {
		this.listaVistaAnonimizar = listaVistaAnonimizar;
	}
	
	
	
}
