package com.atosorigin.deri.parametrizacion.contrapartida.screen;

import java.util.List;

import org.jboss.seam.ScopeType;
import org.jboss.seam.annotations.Name;
import org.jboss.seam.annotations.Scope;
import org.jboss.seam.annotations.datamodel.DataModel;
import org.jboss.seam.annotations.datamodel.DataModelSelection;

import com.atosorigin.deri.model.liquidaciones.ReferenciaConfirmacion;


/**
 *  Contiene los datos de pantalla necesarios para el caso de uso mantenimiento de plazos.
 */
@Name("contactoContrapartidaPantalla")
@Scope(ScopeType.CONVERSATION)
public class ContactoContrapartidaPantalla {

	/** Contrapa. Criterio de búsqueda de contactos. */
	protected String contrapa;
	
	
	/** Nombre. Criterio de búsqueda de contactos.  */
	protected String nombre;
	protected String funcion;
	protected String departamento;
	
	/** Lista de datos para el grid. */
	@DataModel(value ="listaDtContactos")
	protected List<ReferenciaConfirmacion> contactoList;
	
	@DataModelSelection(value ="listaDtContactos")
	protected ReferenciaConfirmacion contacto;
	
	public String getContrapa() {
		return contrapa;
	}

	public void setContrapa(String contrapa) {
		this.contrapa = contrapa;
	}
	
	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public List<ReferenciaConfirmacion> getContactoList() {
		return contactoList;
	}

	public void setContactoList(List<ReferenciaConfirmacion> contactoList) {
		this.contactoList = contactoList;				
	}

	public ReferenciaConfirmacion getContacto() {
		return contacto;
	}

	public void setContacto(ReferenciaConfirmacion contacto) {
		this.contacto = contacto;
	}

	public String getFuncion() {
		return funcion;
	}

	public void setFuncion(String funcion) {
		this.funcion = funcion;
	}

	public String getDepartamento() {
		return departamento;
	}

	public void setDepartamento(String departamento) {
		this.departamento = departamento;
	}


	
}
