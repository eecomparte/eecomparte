package com.atosorigin.deri.parametrizacion.contrapartida.screen;

import java.util.List;

import org.jboss.seam.ScopeType;
import org.jboss.seam.annotations.Name;
import org.jboss.seam.annotations.Out;
import org.jboss.seam.annotations.Scope;
import org.jboss.seam.annotations.datamodel.DataModel;
import org.jboss.seam.annotations.datamodel.DataModelSelection;

import com.atosorigin.deri.model.contrapartida.CodigoPais;
import com.atosorigin.deri.model.contrapartida.Contrapartida;
import com.atosorigin.deri.model.contrapartida.GrupoBancario;
import com.atosorigin.deri.model.contrapartida.TipoContrapartida;
import com.atosorigin.deri.model.contrapartida.UnidadNegocio;


/**
 *  Contiene los datos de pantalla necesarios para el caso de uso mantenimiento de contrapartidas.
 */
@Name("contrapartidaPantalla")
@Scope(ScopeType.CONVERSATION)
public class ContrapartidaPantalla {
	
	/** Lista de datos para el grid. */
	@DataModel(value ="listaDtContrapratidas")
	protected List<Contrapartida> contrapartidaList;
	
	/** Usuario seleccionado en el grid */
	@DataModelSelection(value ="listaDtContrapratidas")
    protected Contrapartida contrapartidaSelection;
	
	
	@Out(required=false)
	protected Contrapartida contrapartidaSel;
	
	protected CodigoPais pais; 
	protected GrupoBancario grupoBancarioObt;
	protected TipoContrapartida tipoContSelec;
	protected TipoContrapartida tipoContSelecAux;
	protected UnidadNegocio unidadNegocio;
	protected String descripcion;
	protected String codigo;
	protected String idGBSelected;
	protected String descGBSelected;
	
	protected boolean tratEspecial;
	
	protected boolean residencia;
	protected boolean indColateralizada;
	protected boolean colateralizadaBuscar;
	
	protected boolean indFirmaManualForzada;
	protected boolean indIntraGrup;
	protected boolean indOfex;
	
	public ContrapartidaPantalla(){
		super();
		this.grupoBancarioObt = new GrupoBancario();
	}
	
	public List<Contrapartida> getContrapartidaList() {
		return contrapartidaList;
	}

	public void setContrapartidaList(List<Contrapartida> contrapartidaList) {
		this.contrapartidaList = contrapartidaList;
	}

	public Contrapartida getContrapartidaSelection() {
		return contrapartidaSelection;
	}

	public void setContrapartidaSelection(Contrapartida contrapartidaSelection) {
		this.contrapartidaSelection = contrapartidaSelection;
	}

	
	public TipoContrapartida getTipoContSelec() {
		return tipoContSelec;
	}

	public void setTipoContSelec(TipoContrapartida tipoContSelec) {
		this.tipoContSelec = tipoContSelec;
	}

	public String getDescripcion() {
		return descripcion;
	}

	public void setDescripcion(String descripcion) {
		this.descripcion = descripcion;
	}

	public String getCodigo() {
		return codigo;
	}

	public void setCodigo(String codigo) {
		this.codigo = codigo;
	}

	public GrupoBancario getGrupoBancarioObt() {
		return grupoBancarioObt;
	}

	public void setGrupoBancarioObt(GrupoBancario grupoBancarioObt) {
		this.grupoBancarioObt = grupoBancarioObt;
	}

	public Contrapartida getContrapartidaSel() {
		return contrapartidaSel;
	}

	public void setContrapartidaSel(Contrapartida contrapartidaSel) {
		this.contrapartidaSel = contrapartidaSel;
	}

	public CodigoPais getPais() {
		return pais;
	}

	public void setPais(CodigoPais pais) {
		this.pais = pais;
	}

	public UnidadNegocio getUnidadNegocio() {
		return unidadNegocio;
	}

	public void setUnidadNegocio(UnidadNegocio unidadNegocio) {
		this.unidadNegocio = unidadNegocio;
	}

	public boolean isTratEspecial() {
		return tratEspecial;
	}

	public void setTratEspecial(boolean tratEspecial) {
		this.tratEspecial = tratEspecial;
	}

	public boolean isResidencia() {
		return residencia;
	}

	public void setResidencia(boolean residencia) {
		this.residencia = residencia;
	}

	public TipoContrapartida getTipoContSelecAux() {
		return tipoContSelecAux;
	}

	public void setTipoContSelecAux(TipoContrapartida tipoContSelecAux) {
		this.tipoContSelecAux = tipoContSelecAux;
	}

	public String getIdGBSelected() {
		return idGBSelected;
	}

	public void setIdGBSelected(String idGBSelected) {
		this.idGBSelected = idGBSelected;
	}

	public String getDescGBSelected() {
		return descGBSelected;
	}

	public void setDescGBSelected(String descGBSelected) {
		this.descGBSelected = descGBSelected;
	}

	public boolean isIndColateralizada() {
		return indColateralizada;
	}

	public void setIndColateralizada(boolean indColateralizada) {
		this.indColateralizada = indColateralizada;
	}

	public boolean isColateralizadaBuscar() {
		return colateralizadaBuscar;
	}

	public void setColateralizadaBuscar(boolean colateralizadaBuscar) {
		this.colateralizadaBuscar = colateralizadaBuscar;
	}

	public boolean isIndFirmaManualForzada() {
		return indFirmaManualForzada;
	}

	public void setIndFirmaManualForzada(boolean indFirmaManualForzada) {
		this.indFirmaManualForzada = indFirmaManualForzada;
	}

	public boolean isIndIntraGrup() {
		return indIntraGrup;
	}

	public void setIndIntraGrup(boolean indIntraGrup) {
		this.indIntraGrup = indIntraGrup;
	}

	public boolean isIndOfex() {
		return indOfex;
	}

	public void setIndOfex(boolean indOfex) {
		this.indOfex = indOfex;
	}
	
}