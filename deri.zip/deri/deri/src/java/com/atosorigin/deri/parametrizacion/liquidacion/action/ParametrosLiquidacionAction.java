package com.atosorigin.deri.parametrizacion.liquidacion.action;

import java.util.List;

import org.jboss.seam.ScopeType;
import org.jboss.seam.annotations.Factory;
import org.jboss.seam.annotations.In;
import org.jboss.seam.annotations.Name;
import org.jboss.seam.annotations.Out;
import org.jboss.seam.annotations.Scope;
import org.jboss.seam.core.Conversation;
import org.jboss.seam.core.ResourceBundle;
import org.jboss.seam.international.Messages;
import org.jboss.seam.international.StatusMessage.Severity;

import com.atosorigin.common.action.ModoPantalla;
import com.atosorigin.common.action.PaginatedListAction;
import com.atosorigin.common.auditdata.AuditData;
import com.atosorigin.common.constantes.Constantes;
import com.atosorigin.common.formvalidator.FormValidator;
import com.atosorigin.common.utils.GenericUtils;
import com.atosorigin.deri.contrapartida.business.ContrapartidaBo;
import com.atosorigin.deri.model.contrapartida.Contrapartida;
import com.atosorigin.deri.model.contrapartida.DocsContrapartida;
import com.atosorigin.deri.model.parametrizacion.ParamCobroPago;
import com.atosorigin.deri.model.parametrizacion.ParamCobroPagoId;
import com.atosorigin.deri.model.parametrizacion.ParamSwift;
import com.atosorigin.deri.model.parametrizacion.ParamSwiftId;
import com.atosorigin.deri.parametrizacion.liquidacion.screen.ParametrosLiquidacionPantalla;
import com.atosorigin.deri.parametrizacion.parametrosliquidacion.business.ParametrosLiquidacionBo;
import com.atosorigin.deri.util.MessageBoxAction;
import com.atosorigin.deri.util.MsgBoxAction;



@Name("parametrosLiquidacionAction")
@Scope(ScopeType.CONVERSATION)
@FormValidator
public class ParametrosLiquidacionAction extends PaginatedListAction {

	
	@In(create=true)
	protected ParametrosLiquidacionPantalla parametrosLiquidacionPantalla;
	
	@In(value="#{parametrosLiquidacionBo}")
	protected ParametrosLiquidacionBo parametrosLiquidacionBo;
	
	@In(value="#{contrapartidaBo}")
	protected ContrapartidaBo contrapartidaBo; 	
	
	protected boolean pasaValidacion = false;
	
//	protected boolean entidadBloq = false;
	
	protected boolean oficinaBloq = false;
	
	protected boolean banCliente = false;
	
	protected StringBuilder mensajeConfirmacion = new StringBuilder();

	private Boolean primeraEjecucionInit=null;
	
	@In(create = true)
	MsgBoxAction msgBoxAction;
	
	@Out(required = false, value = "parametrosLiquidacionMessageBoxAction")
	private MessageBoxAction messageBoxparametrosLiquidacionAction;
	
	//Métodos de la pantalla
	
	public void proyectoColat(){
		this.parametrosLiquidacionPantalla.setProyecto(Constantes.NOMBRE_PROYECTO_COLAT);
	}

	public void proyectoDeri(){
		this.parametrosLiquidacionPantalla.setProyecto(Constantes.NOMBRE_PROYECTO_DERI);
	}

	
	public void buscar(){
		if (GenericUtils.isNullOrBlank(this.parametrosLiquidacionPantalla.getProyecto()) && primerAcceso){
			proyectoDeri();
		}
		setPrimerAcceso(false);
		paginationData.reset();
		refrescarLista();
	}

	public boolean validacionAlta(){
		boolean retorno=true;
		ParamCobroPago params = parametrosLiquidacionBo.cargar(parametrosLiquidacionPantalla.getParamCobroPagoSelec());
		if(!GenericUtils.isNullOrBlank(params)){
			if(Constantes.CONSTANTE_CLIENTE.equals(parametrosLiquidacionPantalla.getParamCobroPagoSelec().getId().getTipoDestino())){
				statusMessages.add(Severity.ERROR, "#{messages['parametroLiquidacion.error.cobroPagoYaExiste']}");
				retorno = false;
			}else{
				retorno = false;
				statusMessages.add(Severity.ERROR, "#{messages['parametroLiquidacion.error.swiftYaExiste']}");
			}
		}
		return retorno;
	}
	
	/**
	 * Comprueba si los campos de texto están rellenos correlativamente 
	 * @return
	 */
	public boolean compruebaCorrelativos(String texto1, String texto2, String texto3, String texto4, String texto5, String texto6){
		//Si son nulos, indica que no son del campo de observaciones. 
		boolean retorno = true;
		if(GenericUtils.isNullOrBlank(texto5) && GenericUtils.isNullOrBlank(texto6)){
			if((!GenericUtils.isNullOrBlank(texto1)) && (GenericUtils.isNullOrBlank(texto2)) && (!GenericUtils.isNullOrBlank(texto3) || !GenericUtils.isNullOrBlank(texto4)|| !GenericUtils.isNullOrBlank(texto5)|| !GenericUtils.isNullOrBlank(texto6))){
				retorno = false;
			}
			if((!GenericUtils.isNullOrBlank(texto1)) && (!GenericUtils.isNullOrBlank(texto2)) && 
					(GenericUtils.isNullOrBlank(texto3)) && (!GenericUtils.isNullOrBlank(texto4) || !GenericUtils.isNullOrBlank(texto5)|| !GenericUtils.isNullOrBlank(texto6))){
				
				retorno = false;
			}
			if((!GenericUtils.isNullOrBlank(texto1)) && (!GenericUtils.isNullOrBlank(texto2)) && 
					(!GenericUtils.isNullOrBlank(texto3)) && (GenericUtils.isNullOrBlank(texto4)) && ( !GenericUtils.isNullOrBlank(texto5)|| !GenericUtils.isNullOrBlank(texto6))){
				
				retorno = false;
			}
		}else{
			//tan solo tenemos que controlar los 4 primeros campos y obiamos el caso de que escriban el campo 1, el campo 2 y el campo 3...
			if((!GenericUtils.isNullOrBlank(texto1)) && (GenericUtils.isNullOrBlank(texto2)) && (!GenericUtils.isNullOrBlank(texto3) || !GenericUtils.isNullOrBlank(texto4))){
				retorno = false;
			}
			if((!GenericUtils.isNullOrBlank(texto1)) && (!GenericUtils.isNullOrBlank(texto2)) && 
					(GenericUtils.isNullOrBlank(texto3) && !GenericUtils.isNullOrBlank(texto4))){
				retorno = false;
			}
		}
		if(!retorno){
			pasaValidacion = false;
		}
		return retorno;
	}
	
	public void contrapaCambiada(){
		banCliente = false;
		String idContrapa = parametrosLiquidacionPantalla.getParamCobroPagoSelec().getId().getContrapartida();
		if(!GenericUtils.isNullOrBlank(idContrapa)){
			Contrapartida c = contrapartidaBo.cargar(idContrapa);
			if(!GenericUtils.isNullOrBlank(c)){
				if(!GenericUtils.isNullOrBlank(c.getGrupoBancario().getId())){
					if("CLIENTES".equals(c.getGrupoBancario().getId()) && !Constantes.CONSTANTE_CLIENTE.equals(parametrosLiquidacionPantalla.getParamCobroPagoSelec().getId().getTipoDestino())){
						banCliente = true;
						if(GenericUtils.isNullOrBlank(parametrosLiquidacionPantalla.getParamCobroPagoSelec().getParamSwift())){
							parametrosLiquidacionPantalla.getParamCobroPagoSelec().setParamSwift(new ParamSwift());
						}
						parametrosLiquidacionPantalla.getParamCobroPagoSelec().getParamSwift().setBeneficiarioLinea1(c.getDescLarga());
						parametrosLiquidacionPantalla.getParamCobroPagoSelec().getParamSwift().setBeneficiarioLinea2(c.getDireccion());
						parametrosLiquidacionPantalla.getParamCobroPagoSelec().getParamSwift().setBeneficiarioLinea3(c.getCiudad());
						parametrosLiquidacionPantalla.getParamCobroPagoSelec().getParamSwift().setBeneficiarioLinea4(c.getPais());
					}
				}
			}else if (idContrapa!=null){
				statusMessages.add(Severity.ERROR, "#{messages['parametrosLiquidacion.error.contrapartida']}");
			}
		}
	}
	
	
	public boolean validaLineasByCodigo(String codigo, String linea1, String linea2, String linea3, String linea4){
		boolean retorno = true;
		if(!GenericUtils.isNullOrBlank(codigo)){
			if(!GenericUtils.isNullOrBlank(linea1) || !GenericUtils.isNullOrBlank(linea2) || !GenericUtils.isNullOrBlank(linea3) || !GenericUtils.isNullOrBlank(linea4)){
				retorno = false;
			}
		}
		return retorno;
	}
	
	public boolean validaContrapa(String idContrapa){
		if(!GenericUtils.isNullOrBlank(idContrapa)){
			Contrapartida c = contrapartidaBo.cargar(idContrapa);
				if(GenericUtils.isNullOrBlank(c)){
					return false;	
				}else{
					return true;
				}
			}else{
				return false;
			}
	}
	
	public boolean validaTID(){
		boolean retorno = true;
		ParamSwift pSwift = parametrosLiquidacionPantalla.getParamCobroPagoSelec().getParamSwift();
		if(GenericUtils.isNullOrBlank(pSwift.getTidDestino()) && (GenericUtils.isNullOrBlank(pSwift.getBancoBeneficiario()) || 
				GenericUtils.isNullOrBlank(pSwift.getBancoDelBenefLinea1()) || GenericUtils.isNullOrBlank(pSwift.getBancoDelBenefLinea2())
				||GenericUtils.isNullOrBlank(pSwift.getBancoDelBenefLinea3())|| GenericUtils.isNullOrBlank(pSwift.getBancoDelBenefLinea4()))){
			retorno = false;
		}
		return retorno;
	}
	
	/**
	 * Si el check de la cuenta está informado, el resto de campos de la cuenta 
		(entidad, grupo, oficina, nº cuenta) deben estar informados. 
		Si no lo están, mostrar el mensaje de error Parametro.error.CheckInformado
		
		Si la cuenta está informada, el resto de campos de la cuenta 
		(entidad, grupo, oficina, check) deben estar informados. 
		Si no lo están, mostrar el mensaje de error Parametro.error.CuentaInformada
		
		Si el grupo está informado, el resto de campos de la cuenta 
		(entidad, oficina, cuenta, check) deben estar informados. 
		Si no lo están, mostrar el mensaje de error Parametro.error.GrupoInformado
		
		Si la oficina está informada, el resto de campos de la cuenta 
		(entidad, grupo, cuenta, check) deben estar informados. 
		
		Si no lo están, mostrar el mensaje de error Parametro.error.OficinaInformada
		Si la entidad está informada, el resto de campos de la cuenta 
		(grupo, oficina, cuenta, check) deben estar informados. 
		Si no lo están, mostrar el mensaje de error Parametro.error.EntidadInformada
	 * @return
	 */
	public boolean validaTipoCliente(ParamCobroPago param){
		boolean retorno = true;
		if(!GenericUtils.isNullOrBlank(param.getCheck()) || !GenericUtils.isNullOrBlank(param.getGrupoContable()) || !GenericUtils.isNullOrBlank(param.getOficina())
				|| !GenericUtils.isNullOrBlank(param.getId().getEntidad()) || !GenericUtils.isNullOrBlank(param.getCuenta())){
			if(!GenericUtils.isNullOrBlank(param.getCuenta()) && (GenericUtils.isNullOrBlank(param.getCheck()) || GenericUtils.isNullOrBlank(param.getGrupoContable())
				||GenericUtils.isNullOrBlank(param.getOficina()) || GenericUtils.isNullOrBlank(param.getId().getEntidad()))){
				statusMessages.add(Severity.ERROR, "#{messages['parametrosLiquidacion.error.cuentaInformada']}");
				retorno = false;
			}else if(!GenericUtils.isNullOrBlank(param.getCheck()) && (GenericUtils.isNullOrBlank(param.getCuenta()) || GenericUtils.isNullOrBlank(param.getGrupoContable())
					||GenericUtils.isNullOrBlank(param.getOficina()) || GenericUtils.isNullOrBlank(param.getId().getEntidad()))){
					statusMessages.add(Severity.ERROR, "#{messages['parametrosLiquidacion.error.checkInformado']}");
					retorno = false;
			}else if(!GenericUtils.isNullOrBlank(param.getGrupoContable()) && (GenericUtils.isNullOrBlank(param.getCuenta()) || GenericUtils.isNullOrBlank(param.getCheck())
					||GenericUtils.isNullOrBlank(param.getOficina()) || GenericUtils.isNullOrBlank(param.getId().getEntidad()))){
				statusMessages.add(Severity.ERROR, "#{messages['parametrosLiquidacion.error.grupoInformado']}");
				retorno = false;
			}else if(!GenericUtils.isNullOrBlank(param.getOficina()) && (GenericUtils.isNullOrBlank(param.getCuenta()) || GenericUtils.isNullOrBlank(param.getCheck())
					||GenericUtils.isNullOrBlank(param.getGrupoContable()) || GenericUtils.isNullOrBlank(param.getId().getEntidad()))){
				statusMessages.add(Severity.ERROR, "#{messages['parametrosLiquidacion.error.oficinaInformada']}");
				retorno = false;
			}else if(!GenericUtils.isNullOrBlank(param.getId().getEntidad()) && (GenericUtils.isNullOrBlank(param.getCuenta()) || GenericUtils.isNullOrBlank(param.getCheck())
					||GenericUtils.isNullOrBlank(param.getGrupoContable()) || GenericUtils.isNullOrBlank(param.getOficina()))){
				statusMessages.add(Severity.ERROR, "#{messages['parametrosLiquidacion.error.entidadInformada']}");
				retorno = false;
			}
		}
		return retorno;
		
	}
	public boolean existenLiquidacionesValidadas(){
		
		try {
			if (!"CLIENTE".equalsIgnoreCase(parametrosLiquidacionPantalla.getParamCobroPagoSelec().getId().getTipoDestino())){
				return false;
			}
		} catch (Exception e) {
			return false;
		}
		
		return parametrosLiquidacionBo.existenLiquidacionesValidadas(parametrosLiquidacionPantalla.getParamCobroPagoSelec());
	}
	
	public void validaciones(){
		pasaValidacion = true;
		mensajeConfirmacion = new StringBuilder();
		if(ModoPantalla.CREACION.equals(getModoPantalla())){
			if(!validacionAlta()){
				pasaValidacion=false;
			}
			if(!validacionModificacion()){
				pasaValidacion=false;
			}
		}else{
			if(!validacionModificacion()){
				pasaValidacion=false;
			}
		}
		if(pasaValidacion){
			ParamCobroPago param = parametrosLiquidacionPantalla.getParamCobroPagoSelec();
			String aviso = Messages.instance().get("parametrosLiquidacion.confirmacion.continuar");
			
//			String aviso ="#{messages['parametrosLiquidacion.confirmacion.continuar']}";
		
			if(Constantes.DIVISA_EUR.equals(param.getId().getDivisa())){
				if(param.getCuenta().length() > 5 && GenericUtils.isNumeric(param.getCuenta())){
					aviso = Messages.instance().get("parametrosLiquidacion.mensaje.cuentaMayor") + ", " + aviso;
				}
			}else{
				if(param.getCuenta().length() < 5 && GenericUtils.isNumeric(param.getCuenta())){
					aviso =Messages.instance().get("parametrosLiquidacion.mensaje.cuentaMenor") + ", " + aviso;
				}
			}
			if (existenLiquidacionesValidadas()){
				aviso =Messages.instance().get("parametrosLiquidacion.mensaje.LiquidacionesValidadas") + ", " + aviso;
			}
			mensajeConfirmacion.append(aviso);
		}
	}
	
	public boolean validacionModificacion(){
		boolean retorno = true;
		ParamCobroPago param = parametrosLiquidacionPantalla.getParamCobroPagoSelec();
		if(Constantes.CONSTANTE_SWIFT.equals(param.getId().getTipoDestino()) && "P".equals(param.getId().getTipoOperacion())){
			if(!compruebaCorrelativos(param.getParamSwift().getIntermediarioLinea1(), param.getParamSwift().getIntermediarioLinea2(), param.getParamSwift().getIntermediarioLinea3(), param.getParamSwift().getIntermediarioLinea4(), null, null)){
				statusMessages.add(Severity.ERROR, "#{messages['parametrosLiquidacion.error.textosNoCorrelativos']}");
				retorno = false;
				
			}else if(!compruebaCorrelativos(param.getParamSwift().getBancoDelBenefLinea1(), param.getParamSwift().getBancoDelBenefLinea2(), param.getParamSwift().getBancoDelBenefLinea3(), param.getParamSwift().getBancoDelBenefLinea4(), null, null)){
				statusMessages.add(Severity.ERROR, "#{messages['parametrosLiquidacion.error.textosNoCorrelativos']}");
				retorno = false;
			}else if(!compruebaCorrelativos(param.getParamSwift().getBeneficiarioLinea1(), param.getParamSwift().getBeneficiarioLinea2(), param.getParamSwift().getBeneficiarioLinea3(), param.getParamSwift().getBeneficiarioLinea4(), null, null)){
				statusMessages.add(Severity.ERROR, "#{messages['parametrosLiquidacion.error.textosNoCorrelativos']}");
				retorno = false;
			}else if(!compruebaCorrelativos(param.getParamSwift().getObservacionesLinea1(), param.getParamSwift().getObservacionesLinea2(), param.getParamSwift().getObservacionesLinea3(), param.getParamSwift().getObservacionesLinea4(), param.getParamSwift().getObservacionesLinea5(), param.getParamSwift().getObservacionesLinea6())){
				statusMessages.add(Severity.ERROR, "#{messages['parametrosLiquidacion.error.textosNoCorrelativos']}");
				retorno = false;
			}
			
			if (!validaContrapa(parametrosLiquidacionPantalla.getParamCobroPagoSelec().getId().getContrapartida())){
				statusMessages.add(Severity.ERROR, "#{messages['parametrosLiquidacion.error.contrapartida']}");
				retorno = false;
			}

			
			if(!validaLineasByCodigo(param.getParamSwift().getCodigoIntermediario(), param.getParamSwift().getIntermediarioLinea1(), param.getParamSwift().getIntermediarioLinea2(), param.getParamSwift().getIntermediarioLinea3(), param.getParamSwift().getIntermediarioLinea4())){
				statusMessages.add(Severity.ERROR, "#{messages['parametrosLiquidacion.error.errorCodigoTexto']}");
				retorno = false;
			}else if(!validaLineasByCodigo(param.getParamSwift().getBancoBeneficiario(), param.getParamSwift().getBeneficiarioLinea1(), param.getParamSwift().getBeneficiarioLinea2(), param.getParamSwift().getBeneficiarioLinea3(), param.getParamSwift().getBeneficiarioLinea4())){
				statusMessages.add(Severity.ERROR, "#{messages['parametrosLiquidacion.error.errorCodigoTexto']}");
				retorno = false;
			}else if(!validaLineasByCodigo(param.getParamSwift().getBancoDelBeneficiario(), param.getParamSwift().getBancoDelBenefLinea1(), param.getParamSwift().getBancoDelBenefLinea2(), param.getParamSwift().getBancoDelBenefLinea3(), param.getParamSwift().getBancoDelBenefLinea4())	){
				statusMessages.add(Severity.ERROR, "#{messages['parametrosLiquidacion.error.errorCodigoTexto']}");
				retorno = false;
			}else if(!validaTID()){
				
				statusMessages.add(Severity.ERROR, "#{messages['parametrosLiquidacion.error.obligatoriosSwift']}");
				retorno = false;
			}
			
		}
		
		if(Constantes.CONSTANTE_SWIFT.equals(param.getId().getTipoDestino()) &&(banCliente || param.getId().getDivisa().equals(Constantes.DIVISA_EUR))){
			
			mensajeConfirmacion.append(ResourceBundle.instance().getString("parametrosLiquidacion.error.divisasContrapartidas"));
		}
		if("50".equals(param.getGrupoContable()) && param.getOficina() == 901){
			
			statusMessages.add(Severity.ERROR, "#{messages['parametrosLiquidacion.error.grupoContableErroneo']}");
			retorno = false;
		}
		if(Constantes.CONSTANTE_CLIENTE.equals(param.getId().getTipoDestino())){
			if(!validaTipoCliente(param)){

				retorno = false;
			}
		}
		if(!Constantes.DIVISA_EUR.equals(param.getId().getDivisa())){
			if("50".equals(param.getGrupoContable())){
				statusMessages.add(Severity.ERROR, "#{messages['parametrosLiquidacion.mensaje.grupoContableErroneo']}");
				retorno = false;
				
			}
		}
		return retorno;
	}
	
	public void editar(){
		
		parametrosLiquidacionPantalla.setParamCobroPagoSelec(parametrosLiquidacionBo.cargar(parametrosLiquidacionPantalla.getParamCobroPagoSelected()));
		if(Constantes.CONSTANTE_SWIFT.equals(parametrosLiquidacionPantalla.getParamCobroPagoSelec().getId().getTipoDestino()) || Constantes.CONSTANTE_TARGET.equals(parametrosLiquidacionPantalla.getParamCobroPagoSelec().getId().getTipoDestino())){
			parametrosLiquidacionPantalla.setPagoSwiftTarget(true);
//			ParamSwift paramSwift = parametrosLiquidacionBo.obtenerParametroSwift(parametrosLiquidacionPantalla.getParamCobroPagoSelec());
			if(GenericUtils.isNullOrBlank(parametrosLiquidacionPantalla.getParamCobroPagoSelec().getParamSwift())){
				
				ParamSwiftId id = new ParamSwiftId(	parametrosLiquidacionPantalla.getParamCobroPagoSelec());
//						Constantes.NOMBRE_PROYECTO_DERI,
//						parametrosLiquidacionPantalla.getParamCobroPagoSelec().getId().getProducto(),
//						parametrosLiquidacionPantalla.getParamCobroPagoSelec().getId().getTipoOperacion(),
//						parametrosLiquidacionPantalla.getParamCobroPagoSelec().getId().getDivisa(),
//						parametrosLiquidacionPantalla.getParamCobroPagoSelec().getId().getContrapartida(),
//						parametrosLiquidacionPantalla.getParamCobroPagoSelec().getId().getTipoDestino());
				
				parametrosLiquidacionPantalla.getParamCobroPagoSelec().setParamSwift(new ParamSwift(id));
			
			
			}
		}else{
			parametrosLiquidacionPantalla.setPagoSwiftTarget(false);
		}
		
		
		setPrimerAcceso(false);
		
		setModoPantalla(ModoPantalla.EDICION);
	}
	
	public String guardar(){
		if(ModoPantalla.CREACION.equals(getModoPantalla())){
//			parametrosLiquidacionPantalla.getParamCobroPagoSelec().getId().setTipoOperacion(tipoOperacion)
			parametrosLiquidacionBo.altaParametros(parametrosLiquidacionPantalla.getParamCobroPagoSelec(), parametrosLiquidacionPantalla.getParamCobroPagoSelec().getParamSwift());
		}if(ModoPantalla.EDICION.equals(getModoPantalla())){
			parametrosLiquidacionBo.modificarParametros(parametrosLiquidacionPantalla.getParamCobroPagoSelec());
		}
		refrescarLista();
		pasaValidacion=false;
		salir2();
		return "";//Constantes.CONSTANTE_SUCCESS;
	}
	
	
	public void salir2(){
		Conversation conversacion = Conversation.instance();
		//Volvemos a la anterior conversación
		if(conversacion.isNested()){
			conversacion.redirectToParent();
		} else {
			redirectToURL("/home.seam");
			conversacion.endAndRedirect();
		}
	}
	public void ver(){
		parametrosLiquidacionPantalla.setParamCobroPagoSelec(parametrosLiquidacionBo.cargar(parametrosLiquidacionPantalla.getParamCobroPagoSelected()));
		if(Constantes.CONSTANTE_SWIFT.equals(parametrosLiquidacionPantalla.getParamCobroPagoSelec().getId().getTipoDestino()) || Constantes.CONSTANTE_TARGET.equals(parametrosLiquidacionPantalla.getParamCobroPagoSelec().getId().getTipoDestino())){
			parametrosLiquidacionPantalla.setPagoSwiftTarget(true);
		}else{
			parametrosLiquidacionPantalla.setPagoSwiftTarget(false);
		}
		
		
		setPrimerAcceso(false);
		
		setModoPantalla(ModoPantalla.INSPECCION);
	}
	
	public void nuevo(){
		String projecte;
		if (GenericUtils.isNullOrBlank(this.parametrosLiquidacionPantalla.getProyecto())){
			projecte = Constantes.NOMBRE_PROYECTO_DERI;
		}else{
			projecte =this.parametrosLiquidacionPantalla.getProyecto();
		}
		
		
		ParamCobroPagoId paramId = new ParamCobroPagoId();
		paramId.setTipoDestino(parametrosLiquidacionPantalla.getTipoPago()); 
		paramId.setProyecto(projecte);
//		paramId.setProyecto(Constantes.NOMBRE_PROYECTO_DERI);
		ParamCobroPago param = new ParamCobroPago(paramId);
		param.setAuditData(new AuditData());
		
		if(Constantes.CONSTANTE_SWIFT.equals(parametrosLiquidacionPantalla.getTipoPago()) || Constantes.CONSTANTE_TARGET.equals(parametrosLiquidacionPantalla.getTipoPago())){
			parametrosLiquidacionPantalla.setPagoSwiftTarget(true);
			param.setParamSwift(new ParamSwift());
			param.getParamSwift().setAuditData(new AuditData());

//			param.setOficina(new Short("901"));
//			param.getId().setEntidad(new Short("0081"));
//			
//			setEntidadBloq(true);
//			setOficinaBloq(true);
			
			
		}else{
			parametrosLiquidacionPantalla.setPagoSwiftTarget(false);
//SMM 1212
//			setEntidadBloq(false);
			setOficinaBloq(false);
		}
		
		parametrosLiquidacionPantalla.setParamCobroPagoSelec(param);
		setPrimerAcceso(false);
		setModoPantalla(ModoPantalla.CREACION);
		
		
	}
	
	
	public void borrar(){
		parametrosLiquidacionBo.bajaParametro(parametrosLiquidacionPantalla.getParamCobroPagoSelected());
		refrescarLista();
	}
	
	
	public String obtenerDescTipoOper(String idTipoOper){
		return parametrosLiquidacionBo.obtenerDescripcionTipoOperacion(idTipoOper);
	}
	
	public String obtenerDescContrapa(String idContrapa){
		return parametrosLiquidacionBo.obtenerDescContrapa(idContrapa);
	}
	
	
	public String obtenerDescripcionTipoDestino(String tipoDest){
		return parametrosLiquidacionBo.obtenerDescripcionTipoDestino(tipoDest);
	}
	
	
	//Métodos de la interfaz
	
	@Override
	protected void refreshListInternal() {
		exportExcel = false;
		String producto = null;
		String contrapartida = parametrosLiquidacionPantalla.getIdContrapartida();
		String divisa = null;
		String tipooperacion = null;
		String tipodestino = null;
		String projecte;
		String entidad =  parametrosLiquidacionPantalla.getEntidad();
		
		if(!GenericUtils.isNullOrBlank(parametrosLiquidacionPantalla.getProdBusqueda())){
			producto = parametrosLiquidacionPantalla.getProdBusqueda().getId();
		}
		
		if(!GenericUtils.isNullOrBlank(parametrosLiquidacionPantalla.getDivisaBusqueda())){
			divisa = parametrosLiquidacionPantalla.getDivisaBusqueda().getId();
		}
		if(!GenericUtils.isNullOrBlank(parametrosLiquidacionPantalla.getTipoOperacion())){
			tipooperacion = parametrosLiquidacionPantalla.getTipoOperacion().getCodigo();
		}
		if(!GenericUtils.isNullOrBlank(parametrosLiquidacionPantalla.getDescTipoDestino())){
			tipodestino = parametrosLiquidacionPantalla.getDescTipoDestino().getCodigo();
		}
		
		if (GenericUtils.isNullOrBlank(this.parametrosLiquidacionPantalla.getProyecto())){
			projecte = Constantes.NOMBRE_PROYECTO_DERI;
		}else{
			projecte =this.parametrosLiquidacionPantalla.getProyecto();
		}
		
		List<ParamCobroPago> ql = parametrosLiquidacionBo.buscarParametros(producto, contrapartida, divisa, tipooperacion, tipodestino, entidad, projecte, paginationData);
		parametrosLiquidacionPantalla.setListaParamCobroPago(ql);

	}

	@Override
	public List<?> getDataTableList() {
		return parametrosLiquidacionPantalla.getListaParamCobroPago();
	}
	
	@Override
	public void refrescarListaExcel() {
		exportExcel=true;
		String producto = null;
		String contrapartida = parametrosLiquidacionPantalla.getIdContrapartida();
		String divisa = null;
		String tipooperacion = null;
		String tipodestino = null;
		String projecte;
		String entidad =  parametrosLiquidacionPantalla.getEntidad();
		
		if(!GenericUtils.isNullOrBlank(parametrosLiquidacionPantalla.getProdBusqueda())){
			producto = parametrosLiquidacionPantalla.getProdBusqueda().getId();
		}
		
		if(!GenericUtils.isNullOrBlank(parametrosLiquidacionPantalla.getDivisaBusqueda())){
			divisa = parametrosLiquidacionPantalla.getDivisaBusqueda().getId();
		}
		if(!GenericUtils.isNullOrBlank(parametrosLiquidacionPantalla.getTipoOperacion())){
			tipooperacion = parametrosLiquidacionPantalla.getTipoOperacion().getCodigo();
		}
		if(!GenericUtils.isNullOrBlank(parametrosLiquidacionPantalla.getDescTipoDestino())){
			tipodestino = parametrosLiquidacionPantalla.getDescTipoDestino().getCodigo();
		}
		
		if (GenericUtils.isNullOrBlank(this.parametrosLiquidacionPantalla.getProyecto())){
			projecte = Constantes.NOMBRE_PROYECTO_DERI;
		}else{
			projecte =this.parametrosLiquidacionPantalla.getProyecto();
		}
		
		List<ParamCobroPago> ql = parametrosLiquidacionBo.buscarParametros(producto, contrapartida, divisa, tipooperacion, tipodestino, entidad, projecte, paginationData.getPaginationDataForExcel());
		parametrosLiquidacionPantalla.setListaParamCobroPago(ql);

	}

	@Override
	public void setDataTableList(List<?> dataTableList) {
		parametrosLiquidacionPantalla.setListaParamCobroPago((List<ParamCobroPago>)dataTableList);
	}
	
	public void salir(){
		Conversation conversacion = Conversation.instance();
		//Volvemos a la anterior conversación
		if(conversacion.isNested()){
			conversacion.redirectToParent();
		} else {
			redirectToURL("/home.seam");
			conversacion.endAndRedirect();
		}
	}

	
	
	//Getters y setters
	
	public ParametrosLiquidacionPantalla getParametrosLiquidacionPantalla() {
		return parametrosLiquidacionPantalla;
	}

	public void setParametrosLiquidacionPantalla(
			ParametrosLiquidacionPantalla parametrosLiquidacionPantalla) {
		this.parametrosLiquidacionPantalla = parametrosLiquidacionPantalla;
	}

	public ParametrosLiquidacionBo getParametrosLiquidacionBo() {
		return parametrosLiquidacionBo;
	}

	public void setParametrosLiquidacionBo(
			ParametrosLiquidacionBo parametrosLiquidacionBo) {
		this.parametrosLiquidacionBo = parametrosLiquidacionBo;
	}

	public boolean isPasaValidacion() {
		return pasaValidacion;
	}

	public void setPasaValidacion(boolean pasaValidacion) {
		this.pasaValidacion = pasaValidacion;
	}

//	public boolean isEntidadBloq() {
//		return entidadBloq;
//	}
//
//	public void setEntidadBloq(boolean entidadBloq) {
//		this.entidadBloq = entidadBloq;
//	}

	public boolean isOficinaBloq() {
		return oficinaBloq;
	}

	public void setOficinaBloq(boolean oficinaBloq) {
		this.oficinaBloq = oficinaBloq;
	}

	public ContrapartidaBo getContrapartidaBo() {
		return contrapartidaBo;
	}

	public void setContrapartidaBo(ContrapartidaBo contrapartidaBo) {
		this.contrapartidaBo = contrapartidaBo;
	}

	public boolean isBanCliente() {
		return banCliente;
	}

	public void setBanCliente(boolean banCliente) {
		this.banCliente = banCliente;
	}

	public StringBuilder getMensajeConfirmacion() {
		return mensajeConfirmacion;
	}

	public void setMensajeConfirmacion(StringBuilder mensajeConfirmacion) {
		this.mensajeConfirmacion = mensajeConfirmacion;
	}

	@Factory("LlistaEntidadParametrosLiq")
	public List<String> listaDescripcionEntidadOperacions() {
		return parametrosLiquidacionBo.getDescripcionEntidadOperacion(this.getModoPantalla());
	}

	public void init(){
		primeraEjecucionInit=null;
		
		if(null==messageBoxparametrosLiquidacionAction){
			messageBoxparametrosLiquidacionAction = new MessageBoxAction();
		}
	}
	
	public void initDetalle(){
		if (primeraEjecucionInit == null) {
			primeraEjecucionInit=true;
		} 
		else{
			primeraEjecucionInit = false;
		}
		
		if(null==messageBoxparametrosLiquidacionAction){
			messageBoxparametrosLiquidacionAction = new MessageBoxAction();
		}
		
		if(primeraEjecucionInit){
			if(null!=parametrosLiquidacionPantalla.getParamCobroPagoSelec() && null!=parametrosLiquidacionPantalla.getParamCobroPagoSelec().getId() && null!=parametrosLiquidacionPantalla.getParamCobroPagoSelec().getId().getContrapartida()){
				String idContrapartida = parametrosLiquidacionPantalla.getParamCobroPagoSelec().getId().getContrapartida();
				if(null!=idContrapartida && idContrapartida.trim().length()>0){
					Contrapartida contrapartida = parametrosLiquidacionBo.cargarContrapartida(idContrapartida.toUpperCase());
					if (!GenericUtils.isNullOrBlank(contrapartida) && !GenericUtils.isNullOrBlank(contrapartida.getIndBloqueo()) && "S".equalsIgnoreCase(contrapartida.getIndBloqueo())){
						messageBoxparametrosLiquidacionAction.init(ResourceBundle.instance().getString("parametrosLiquidacion.messages.contrapartida.bloqueada.texto"), "parametrosLiquidacionAction.voidFunction()", null,"messageBoxPanelContrapa");
					}
				}
			}
		}
	}

	public void voidFunction(){
		msgBoxAction.voidFunction();
	}
	
	/**
	 * Mostrar PopUp cuando una contrapartida está bloqueada (no bloqueante)
	 */
	public void onVerificarContrapartidaBloqueada() {
		String contrapartida = parametrosLiquidacionPantalla.getIdContrapartida();
		if (!GenericUtils.isNullOrBlank(contrapartida)){
			 Contrapartida contrapObtenida2 = parametrosLiquidacionBo.cargarContrapartida(contrapartida.toUpperCase());	
			if (!GenericUtils.isNullOrBlank(contrapObtenida2) && !GenericUtils.isNullOrBlank(contrapObtenida2.getIndBloqueo()) && "S".equalsIgnoreCase(contrapObtenida2.getIndBloqueo())){
				messageBoxparametrosLiquidacionAction.init(ResourceBundle.instance().getString("parametrosLiquidacion.messages.contrapartida.bloqueada.texto"), "parametrosLiquidacionAction.voidFunction()", null,"messageBoxPanelContrapa");
			}
		}
	}
	public void onVerificarContrapartidaBloqueadaNueva() {
		String contrapartida = parametrosLiquidacionPantalla.getParamCobroPagoSelec().getId().getContrapartida();
		if (!GenericUtils.isNullOrBlank(contrapartida)){
			 Contrapartida contrapObtenida2 = parametrosLiquidacionBo.cargarContrapartida(contrapartida.toUpperCase());	
			if (null!=contrapObtenida2 && !GenericUtils.isNullOrBlank(contrapObtenida2.getIndBloqueo()) && "S".equalsIgnoreCase(contrapObtenida2.getIndBloqueo())){
				messageBoxparametrosLiquidacionAction.init(ResourceBundle.instance().getString("parametrosLiquidacion.messages.contrapartida.bloqueada.texto"), "parametrosLiquidacionAction.voidFunction()", null,"messageBoxPanelContrapa");
			}
		}
		contrapaCambiada();
	}
	
	public String getRowClasses(){
		StringBuilder builder = new StringBuilder();
		int i=0;
		for (ParamCobroPago parCobPag : parametrosLiquidacionPantalla.getListaParamCobroPago()) {
			Contrapartida contrapartida = null;
			if(null!=parCobPag && null!=parCobPag.getId()){
				String idContrapartida = parCobPag.getId().getContrapartida();
				contrapartida = parametrosLiquidacionBo.cargarContrapartida(idContrapartida.toUpperCase());	
			}

			if(i>0){
				builder.append(",");
			}
			
			if(i%2==0){
				if(null!=contrapartida && !GenericUtils.isNullOrBlank(contrapartida.getIndBloqueo()) && "S".equalsIgnoreCase(contrapartida.getIndBloqueo())){
					builder.append("oddRowRed");
				}
				else{
					builder.append("oddRow");
				}
			}
			else{
				if(null!=contrapartida && !GenericUtils.isNullOrBlank(contrapartida.getIndBloqueo()) && "S".equalsIgnoreCase(contrapartida.getIndBloqueo())){
					builder.append("evenRowRed");
				}
				else{
					builder.append("evenRow");
				}
			}
			i++;
			contrapartida = null;
		}
		return builder.toString();
	}

}
