package com.atosorigin.deri.parametrizacion.liquidacion.screen;

import java.util.List;

import org.jboss.seam.ScopeType;
import org.jboss.seam.annotations.Name;
import org.jboss.seam.annotations.Out;
import org.jboss.seam.annotations.Scope;
import org.jboss.seam.annotations.datamodel.DataModel;
import org.jboss.seam.annotations.datamodel.DataModelSelection;

import com.atosorigin.common.constantes.Constantes;
import com.atosorigin.deri.model.catalogo.Producto;
import com.atosorigin.deri.model.parametrizacion.DescripcionGruposContables;
import com.atosorigin.deri.model.parametrizacion.DescripcionTipoDestino;
import com.atosorigin.deri.model.parametrizacion.Divisa;
import com.atosorigin.deri.model.parametrizacion.ParamCobroPago;
import com.atosorigin.deri.model.parametrizacion.TipoOperacion;


@Name("parametrosLiquidacionPantalla")
@Scope(ScopeType.CONVERSATION)
public class ParametrosLiquidacionPantalla {
	
	protected Producto prodBusqueda;
	
	protected String proyecto;
	
	protected String idContrapartida;
	
	protected String entidad;
	
	protected String entidadEdit;
	
	protected DescripcionGruposContables grupo;
	
	protected Divisa divisaBusqueda;
	
	
	protected TipoOperacion tipoOperacion;
	
	
	protected DescripcionTipoDestino descTipoDestino;
	
	protected boolean pagoSwiftTarget;
	
	protected String tipoPago = Constantes.CONSTANTE_SWIFT;
	
	@DataModel(value="listaDtParamCobroPago")
	protected List<ParamCobroPago> listaParamCobroPago;
	
	@DataModelSelection(value="listaDtParamCobroPago")
	@Out(value="paramCobroPagoSelected", required = false)
	protected ParamCobroPago paramCobroPagoSelected;
	
	protected ParamCobroPago paramCobroPagoSelec;
	

	public Producto getProdBusqueda() {
		return prodBusqueda;
	}

	public void setProdBusqueda(Producto prodBusqueda) {
		this.prodBusqueda = prodBusqueda;
	}

	public String getIdContrapartida() {
		return idContrapartida;
	}

	public void setIdContrapartida(String idContrapartida) {
		this.idContrapartida = idContrapartida;
	}

	public Divisa getDivisaBusqueda() {
		return divisaBusqueda;
	}

	public void setDivisaBusqueda(Divisa divisaBusqueda) {
		this.divisaBusqueda = divisaBusqueda;
	}

	public TipoOperacion getTipoOperacion() {
		return tipoOperacion;
	}

	public void setTipoOperacion(TipoOperacion tipoOperacion) {
		this.tipoOperacion = tipoOperacion;
	}

	public DescripcionTipoDestino getDescTipoDestino() {
		return descTipoDestino;
	}

	public void setDescTipoDestino(DescripcionTipoDestino descTipoDestino) {
		this.descTipoDestino = descTipoDestino;
	}

	public List<ParamCobroPago> getListaParamCobroPago() {
		return listaParamCobroPago;
	}

	public void setListaParamCobroPago(List<ParamCobroPago> listaParamCobroPago) {
		this.listaParamCobroPago = listaParamCobroPago;
	}

	public ParamCobroPago getParamCobroPagoSelected() {
		return paramCobroPagoSelected;
	}

	public void setParamCobroPagoSelected(ParamCobroPago paramCobroPagoSelected) {
		this.paramCobroPagoSelected = paramCobroPagoSelected;
	}

	public ParamCobroPago getParamCobroPagoSelec() {
		return paramCobroPagoSelec;
	}

	public void setParamCobroPagoSelec(ParamCobroPago paramCobroPagoSelec) {
		this.paramCobroPagoSelec = paramCobroPagoSelec;
	}

	public String getTipoPago() {
		return tipoPago;
	}

	public void setTipoPago(String tipoPago) {
		this.tipoPago = tipoPago;
	}

	public DescripcionGruposContables getGrupo() {
		return grupo;
	}

	public void setGrupo(DescripcionGruposContables grupo) {
		this.grupo = grupo;
	}

	public String getEntidadEdit() {
		return entidadEdit;
	}

	public void setEntidadEdit(String entidadEdit) {
		this.entidadEdit = entidadEdit;
	}

	public boolean isPagoSwiftTarget() {
		return pagoSwiftTarget;
	}

	public void setPagoSwiftTarget(boolean pagoSwiftTarget) {
		this.pagoSwiftTarget = pagoSwiftTarget;
	}

	public String getEntidad() {
		return entidad;
	}

	public void setEntidad(String entidad) {
		this.entidad = entidad;
	}

	public String getProyecto() {
		return proyecto;
	}

	public void setProyecto(String proyecto) {
		this.proyecto = proyecto;
	}

}
