package com.atosorigin.deri.parametrizacion.screen;

import java.sql.Date;

import org.jboss.seam.ScopeType;
import org.jboss.seam.annotations.Name;
import org.jboss.seam.annotations.Scope;

import com.atosorigin.deri.model.parametrizacion.SuscripcionId;
import com.atosorigin.deri.model.parametrizacion.TipoEnvio;


@Name("altaSuscripcion")
@Scope(ScopeType.CONVERSATION)

public class AltaSuscripcion implements java.io.Serializable {
	
	protected SuscripcionId id;
	protected String descripcion;
	protected TipoEnvio tipoEnvio;
	protected Date fechaAlta;
	
	
	
	public SuscripcionId getId() {
		return id;
	}
	public void setId(SuscripcionId id) {
		this.id = id;
	}
	public String getDescripcion() {
		return descripcion;
	}
	public void setDescripcion(String descripcion) {
		this.descripcion = descripcion;
	}
	public TipoEnvio getTipoEnvio() {
		return tipoEnvio;
	}
	public void setTipoEnvio(TipoEnvio tipoEnvio) {
		this.tipoEnvio = tipoEnvio;
	}
	public Date getFechaAlta() {
		return fechaAlta;
	}
	public void setFechaAlta(Date fechaAlta) {
		this.fechaAlta = fechaAlta;
	}
	
	
	

}
