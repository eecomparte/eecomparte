package com.atosorigin.deri.parametrizacion.screen;

import java.util.Date;
import java.util.List;

import org.jboss.seam.ScopeType;
import org.jboss.seam.annotations.Name;
import org.jboss.seam.annotations.Out;
import org.jboss.seam.annotations.Scope;
import org.jboss.seam.annotations.datamodel.DataModel;
import org.jboss.seam.annotations.datamodel.DataModelSelection;

import com.atosorigin.deri.model.contrapartida.Contrapartida;
import com.atosorigin.deri.model.parametrizacion.Suscripcion;
import com.atosorigin.deri.model.parametrizacion.SuscripcionId;


@Name("suscripcionPantalla")
@Scope(ScopeType.CONVERSATION)
public class SuscripcionPantalla {

	@Out(required=false)
	protected String idContrapartida;
	protected String descripcionContra;
	/** suscripcion. Criterio de búsqueda de suscripcion.  */
	@Out(value="suscripcion", required=false)
	protected Suscripcion suscripcion;
	
	/** Lista de datos para el grid. */
	@DataModel(value="listaDtSuscripcion")
	protected List<Suscripcion> suscripcionList;
	
	/** Suscripcion seleccionada en el grid */
	@DataModelSelection(value="listaDtSuscripcion")
    @Out(value="suscripcionSelec", required=false)
    protected Suscripcion suscripcionSelec;
	
	protected Date diaAlta;

	/** Lista de datos para el grid de contrapartida. */
	@DataModel(value="listaDtContrapartida")
	protected List<Contrapartida> contrapartidaList;
	
	/** Contrapartida seleccionada en el grid */
	@DataModelSelection(value="listaDtContrapartida")
    @Out(value="contrapartidaSelec", required=false)
    protected Contrapartida contrapartidaSelec;
	
	/**
	 * Id de la suscripción a modificar 
	 */
	protected SuscripcionId suscripcionId;
	
	public Suscripcion getSuscripcion() {
		return suscripcion;
	}


	public void setSuscripcion(Suscripcion suscripcion) {
		this.suscripcion = suscripcion;
	}


	public List<Suscripcion> getSuscripcionList() {
		return suscripcionList;
	}


	public void setSuscripcionList(List<Suscripcion> suscripcionList) {
		this.suscripcionList = suscripcionList;
	}


	public Suscripcion getSuscripcionSelec() {
		return suscripcionSelec;
	}


	public void setSuscripcionSelec(Suscripcion suscripcionSelec) {
		this.suscripcionSelec = suscripcionSelec;
	}


	public Date getDiaAlta() {
		return diaAlta;
	}


	public void setDiaAlta(Date diaAlta) {
		this.diaAlta = diaAlta;
	}


	public String getDescripcionContra() {
		return descripcionContra;
	}


	public void setDescripcionContra(String descripcionContra) {
		this.descripcionContra = descripcionContra;
	}


	public List<Contrapartida> getContrapartidaList() {
		return contrapartidaList;
	}


	public void setContrapartidaList(List<Contrapartida> contrapartidaList) {
		this.contrapartidaList = contrapartidaList;
	}


	public String getIdContrapartida() {
		return idContrapartida;
	}


	public void setIdContrapartida(String idContrapartida) {
		this.idContrapartida = idContrapartida;
	}


	public Contrapartida getContrapartidaSelec() {
		return contrapartidaSelec;
	}


	public void setContrapartidaSelec(Contrapartida contrapartidaSelec) {
		this.contrapartidaSelec = contrapartidaSelec;
	}


	public SuscripcionId getSuscripcionId() {
		return suscripcionId;
	}


	public void setSuscripcionId(SuscripcionId suscripcionId) {
		this.suscripcionId = suscripcionId;
	}

	
}
