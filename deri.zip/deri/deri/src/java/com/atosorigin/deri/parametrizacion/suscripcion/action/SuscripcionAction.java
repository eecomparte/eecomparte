package com.atosorigin.deri.parametrizacion.suscripcion.action;

import java.util.Date;
import java.util.List;

import org.jboss.seam.ScopeType;
import org.jboss.seam.annotations.In;
import org.jboss.seam.annotations.Name;
import org.jboss.seam.annotations.Out;
import org.jboss.seam.annotations.Scope;
import org.jboss.seam.international.StatusMessage.Severity;

import com.atosorigin.common.action.ModoPantalla;
import com.atosorigin.common.action.PaginatedListAction;
import com.atosorigin.common.constantes.Constantes;
import com.atosorigin.common.formvalidator.FormValidator;
import com.atosorigin.common.utils.GenericUtils;
import com.atosorigin.deri.model.contrapartida.Contrapartida;
import com.atosorigin.deri.model.gestionoperaciones.ListaSuscripciones;
import com.atosorigin.deri.model.parametrizacion.Suscripcion;
import com.atosorigin.deri.model.parametrizacion.SuscripcionId;
import com.atosorigin.deri.model.parametrizacion.TipoEnvio;
import com.atosorigin.deri.parametrizacion.screen.SuscripcionPantalla;
import com.atosorigin.deri.parametrizacion.suscripcion.business.SuscripcionBo;
import com.atosorigin.deri.util.MessageBoxAction;
import com.atosorigin.deri.util.MsgBoxAction;

@Name("suscripcionAction")
@Scope(ScopeType.CONVERSATION)
@FormValidator
public class SuscripcionAction extends PaginatedListAction {

	
	@In("#{suscripcionBo}")
	protected SuscripcionBo suscripcionBo;

	@In(create=true)
	protected SuscripcionPantalla suscripcionPantalla;
	
	@In(create = true)
	MsgBoxAction msgBoxAction;
	
	@Out(required = false, value = "suscripcionMessageBoxAction")
	private MessageBoxAction messageBoxSuscripcionAction;
	
	/**
	 * Actualiza la lista del grid de suscripciones
	 * 
	 */
	public void buscar() {
		paginationData.reset();
		//SMM HPQC BUG ID=13
		setPrimerAcceso(false);
		refrescarLista();
	}
/*	SMM Al buscador se le llama desde BuscadorContrapartidaAction	
	public void buscarContrapartidas() {
		paginationData.reset();
		refrescarListaContrapartidas();
	}

	private void refrescarListaContrapartidas() {
		List<Contrapartida> ql = (List<Contrapartida>)suscripcionBo.buscarContrapartidas(suscripcionPantalla.getDescripcionContra(),paginationData);
		suscripcionPantalla.setContrapartidaList(ql);
		
	}
*/
	/**
	 * Prepara para entrar en el modo edición de un persona.
	 * 
	 */
	public void editar() {
		suscripcionPantalla.setSuscripcion(suscripcionBo.cargar(suscripcionPantalla.getSuscripcionSelec().getId()));
		if(suscripcionPantalla.getSuscripcion().getFechaAlta() == null){
			suscripcionPantalla.setDiaAlta(new Date());
		}else{
			suscripcionPantalla.setDiaAlta(suscripcionPantalla.getSuscripcion().getFechaAlta());
		}
		//Rellena el identificador de la suscripción a modificar
		SuscripcionId suscripcionId = new SuscripcionId();
		suscripcionId.setContrapartida(suscripcionPantalla.getSuscripcionSelec().getId().getContrapartida());
		suscripcionId.setIndicadorSuscripcion(suscripcionPantalla.getSuscripcionSelec().getId().getIndicadorSuscripcion());		
		suscripcionPantalla.setSuscripcionId(suscripcionId);
		setModoPantalla(ModoPantalla.EDICION);
	}

	/**
	 * Prepara para entrar en el modo inspección de una suscripción.
	 * 
	 */
	public void ver() {
		Suscripcion suscripcion = suscripcionBo.cargar(suscripcionPantalla.getSuscripcionSelec().getId());
		suscripcionPantalla.setSuscripcion(suscripcion);
		
		//suscripcionPantalla.setDiaAlta(suscripcionPantalla.getSuscripcion().getFechaAlta());

		setModoPantalla(ModoPantalla.INSPECCION);
	}

	/**
	 * Prepara para entrar en el modo creación de una suscripción.
	 * 
	 */
	public void nuevo() {
		
		TipoEnvio tipoEnvio = new TipoEnvio();
		tipoEnvio.setCodigo(Constantes.TIPOENVIO_R);
		tipoEnvio.setDescripcion(Constantes.TIPOENVIO_R_DESC);
		String bsnic = "BSNIC";
		
		suscripcionPantalla.setSuscripcion(new Suscripcion(new SuscripcionId(new String(), Constantes.SUSCRIPCIONID_IND),bsnic,null,null,null,tipoEnvio,new Date(),null,null));

		suscripcionPantalla.setDiaAlta(new Date());
		
		setModoPantalla(ModoPantalla.CREACION);
	}

	/**
	 * Borra una suscripcion.
	 * 
	 */
	public void borrar() {
		suscripcionBo.borrar(suscripcionPantalla.getSuscripcionSelec());
		suscripcionBo.recargar(suscripcionPantalla.getSuscripcionSelec());
		refrescarLista();
	}

	/**
	 * Verifica la no existencia de una suscripción para la contrapartida seleccionada
	 * 
	 * @return true si no hay errores de validación, false en caso contrario. 
	 */
	public boolean guardarValidator() {
		//BUG HPQC
		Suscripcion suscripcion = suscripcionPantalla.getSuscripcion();

		//Si es una modificación unicamente de Ind.Activo no debe consultar la existencia de una suscripcion
		if (this.modoPantalla.equals(ModoPantalla.CREACION) 
		|| (this.modoPantalla.equals(ModoPantalla.EDICION)
				&& (!suscripcion.getId().getContrapartida().equals(suscripcionPantalla.getSuscripcionId().getContrapartida())))){

			Suscripcion suscripcionExistente = suscripcionBo.cargar(suscripcion.getId());
			
			if (!GenericUtils.isNullOrBlank(suscripcionExistente)){
				statusMessages.addToControl("contrapartida", Severity.ERROR, "suscripcion.error.suscripcionYaExiste", Constantes.DEFAULT_MESSAGE_TEMPLATE);
				//SMM: inc 269 no es necesario refrescar la lista 
				//refrescarLista();
				return false;
			}
		}
//		if (!GenericUtils.isNullOrBlank(suscripcion.getId().getContrapartida())){
//			List<Suscripcion> suscripcionList = suscripcionBo.buscarSuscripciones(suscripcion.getId().getContrapartida().getId(), paginationData);
//			if (!GenericUtils.isNullOrBlank(suscripcionList) && suscripcionList.isEmpty()){
//				statusMessages.addToControl("contrapartida", Severity.ERROR, "suscripcion.error.contrapartidaInexiste", Constantes.DEFAULT_MESSAGE_TEMPLATE);
//				return false;				
//			}
//		}		
		return true;
	}

	/**
	 * Graba la suscripcion en la base de datos.
	 * 
	 */
	public String guardar() {
		Suscripcion suscripcion = suscripcionPantalla.getSuscripcion();
		if(ModoPantalla.CREACION.equals(this.getModoPantalla())){
			suscripcion.setFechaAlta(suscripcionPantalla.getDiaAlta());
			suscripcionBo.guardar(suscripcion);
		} else if(ModoPantalla.EDICION.equals(this.getModoPantalla())){
			suscripcionBo.actualizarSuscripcion(suscripcion, suscripcionPantalla.getSuscripcionId());
			suscripcionPantalla.setSuscripcionId(null);			
		}		
		refrescarLista();
		return Constantes.CONSTANTE_SUCCESS;
	}
	
	@Override
	public List<?> getDataTableList() {
		return suscripcionPantalla.getSuscripcionList();
	}

	@Override
	@SuppressWarnings("unchecked")
	public void setDataTableList(List<?> dataTableList) {
		suscripcionPantalla.setSuscripcionList((List<Suscripcion>)dataTableList);
		
	}
	
	@Override
	protected void refreshListInternal() {
		setExportExcel(false);
		List<Suscripcion> ql = (List<Suscripcion>)suscripcionBo.buscarSuscripciones(suscripcionPantalla.getIdContrapartida(), paginationData);
		suscripcionPantalla.setSuscripcionList(ql);
		
	}

	@Override
	public void refrescarListaExcel() {
		setExportExcel(true);
		List<Suscripcion> ql = (List<Suscripcion>)suscripcionBo.buscarSuscripciones(suscripcionPantalla.getIdContrapartida(), paginationData.getPaginationDataForExcel());
		suscripcionPantalla.setSuscripcionList(ql);
		
	}

	public void init(){
		primeraEjecucionInit = null;
		
		if(null==messageBoxSuscripcionAction){
			messageBoxSuscripcionAction = new MessageBoxAction();
		}
	}
	
	private Boolean primeraEjecucionInit=null;
	public void initDetalle(){
		if (primeraEjecucionInit == null) {
			primeraEjecucionInit=true;
		} 
		else{
			primeraEjecucionInit = false;
		}
		
		if(null==messageBoxSuscripcionAction){
			messageBoxSuscripcionAction = new MessageBoxAction();
		}
		
		if(primeraEjecucionInit){
			if(null!=suscripcionPantalla.getSuscripcion() && null!=suscripcionPantalla.getSuscripcion().getId() && null!=suscripcionPantalla.getSuscripcion().getId().getContrapartida()){
				String idContrapartida = suscripcionPantalla.getSuscripcion().getId().getContrapartida();
				if(null!=idContrapartida && idContrapartida.trim().length()>0){
					Contrapartida contrapartida = suscripcionBo.cargarContrapartida(idContrapartida.toUpperCase());	
					if (null!=contrapartida && !GenericUtils.isNullOrBlank(contrapartida.getIndBloqueo()) && "S".equalsIgnoreCase(contrapartida.getIndBloqueo())){
						messageBoxSuscripcionAction.init("suscripcion.messages.contrapartida.bloqueada.texto", "suscripcionAction.voidFunction()", null,"messageBoxPanelContrapa");
					}
				}
			}
		}
	}

	public void voidFunction(){
		msgBoxAction.voidFunction();
	}
	
	/**
	 * Mostrar PopUp cuando una contrapartida está bloqueada (no bloqueante)
	 */
	public void onVerificarContrapartidaBloqueada() {
		String contrapartida = suscripcionPantalla.getIdContrapartida();
		if (!GenericUtils.isNullOrBlank(contrapartida)){
			 Contrapartida contrapObtenida2 = suscripcionBo.cargarContrapartida(contrapartida.toUpperCase());	
			if (null!=contrapObtenida2 && !GenericUtils.isNullOrBlank(contrapObtenida2.getIndBloqueo()) && "S".equalsIgnoreCase(contrapObtenida2.getIndBloqueo())){
				messageBoxSuscripcionAction.init("suscripcion.messages.contrapartida.bloqueada.texto", "suscripcionAction.voidFunction()", null,"messageBoxPanelContrapa");
			}
		}
	}
	
	public void onVerificarContrapartidaBloqueadaNueva() {
		String contrapartida = suscripcionPantalla.getSuscripcion().getId().getContrapartida();
		if (!GenericUtils.isNullOrBlank(contrapartida)){
			 Contrapartida contrapObtenida2 = suscripcionBo.cargarContrapartida(contrapartida.toUpperCase());	
			if (null!=contrapObtenida2 && !GenericUtils.isNullOrBlank(contrapObtenida2.getIndBloqueo()) && "S".equalsIgnoreCase(contrapObtenida2.getIndBloqueo())){
				messageBoxSuscripcionAction.init("suscripcion.messages.contrapartida.bloqueada.texto", "suscripcionAction.voidFunction()", null,"messageBoxPanelContrapa");
			}
		}
	}

	public String getRowClasses(){
		StringBuilder builder = new StringBuilder();
		int i=0;
		for (Suscripcion sus : suscripcionPantalla.getSuscripcionList()) {
			Contrapartida contrapartida = null;

			String idContrapartida = sus.getId().getContrapartida();
			 
			if(i>0){
				builder.append(",");
			}
			
			contrapartida = (Contrapartida) suscripcionBo.cargarContrapartida(idContrapartida.toUpperCase());
			
			if(i%2==0){
				if(null!=contrapartida && !GenericUtils.isNullOrBlank(contrapartida.getIndBloqueo()) && "S".equalsIgnoreCase(contrapartida.getIndBloqueo())){
					builder.append("oddRowRed");
				}
				else{
					builder.append("oddRow");
				}
			}
			else{
				if(null!=contrapartida && !GenericUtils.isNullOrBlank(contrapartida.getIndBloqueo()) && "S".equalsIgnoreCase(contrapartida.getIndBloqueo())){
					builder.append("evenRowRed");
				}
				else{
					builder.append("evenRow");
				}
			}
			i++;
			contrapartida = null;
		}
		return builder.toString();
	}
	
}
