package com.atosorigin.deri.parametroInforme.action;

import java.util.List;

import org.jboss.seam.ScopeType;
import org.jboss.seam.annotations.In;
import org.jboss.seam.annotations.Name;
import org.jboss.seam.annotations.Scope;
import org.jboss.seam.international.StatusMessage.Severity;

import com.atosorigin.common.action.ModoPantalla;
import com.atosorigin.common.action.PaginatedListAction;
import com.atosorigin.common.constantes.Constantes;
import com.atosorigin.common.formvalidator.FormValidator;
import com.atosorigin.common.utils.GenericUtils;
import com.atosorigin.deri.appListados.parametros.business.ParametroBo;
import com.atosorigin.deri.model.appListados.Parametro;
import com.atosorigin.deri.model.appListados.ParametroId;
import com.atosorigin.deri.parametroInforme.screen.ParametroPantalla;

/**
 * Clase action listener para el caso de uso de parámetros de informe.
 */
@Name("parametroAction")
@Scope(ScopeType.CONVERSATION)
@FormValidator
public class ParametroAction extends PaginatedListAction {

	/**
	 * Inyección del bean de Spring "parametroBo" que contiene los métodos de
	 * negocio para el caso de uso parámetros de informe.
	 */
	@In("#{parametroBo}")
	protected ParametroBo parametroBo;

	/**
	 * Inyección del screen bean que contiene los datos de pantalla del caso de
	 * uso parámetros de informe
	 */
	@In(create = true)
	protected ParametroPantalla parametroPantalla;

	/** Actualiza la lista del grid de parámetros informe */
	public void buscar() {
		paginationData.reset();
		/** Limpiamos la información de paginación */
		refrescarLista();
		setPrimerAcceso(false);
	}

	/**
	 * Actualiza la lista del grid de parámetros informe y vuelve a la pantalla
	 * de búsqueda
	 */
	public void salirDetalle() {
		paginationData.reset();
		/** Limpiamos la información de paginación */
		if (this.modoPantalla.equals(ModoPantalla.EDICION)) {
			refrescarLista();
		}
	}

	@Override
	protected void refreshListInternal() {

		this.setExportExcel(false);
		String tipoPara = Constantes.CADENA_VACIA;
		String codigoPara = Constantes.CADENA_VACIA;

		/**
		 * Cargamos los valores seleccionados en los criterios de búsqueda para
		 * realizar la consulta
		 */
		if (!GenericUtils.isNullOrBlank(this.parametroPantalla.getCodigoBusq())) {
			codigoPara = this.parametroPantalla.getCodigoBusq();
		}

		if (!GenericUtils.isNullOrBlank(this.parametroPantalla
				.getTipoParamBusq())) {
			tipoPara = this.parametroPantalla.getTipoParamBusq();
		}

		List<Parametro> listaParametros = (List<Parametro>) parametroBo
				.buscarParametros(codigoPara, tipoPara, paginationData);
		parametroPantalla.setParametrosList(listaParametros);
	}

	@Override
	public void refrescarListaExcel() {

		this.setExportExcel(true);
		String tipoPara = Constantes.CADENA_VACIA;
		String codigoPara = Constantes.CADENA_VACIA;

		/**
		 * Cargamos los valores seleccionados en los criterios de búsqueda para
		 * realizar la consulta
		 */
		if (!GenericUtils.isNullOrBlank(this.parametroPantalla.getCodigoBusq())) {
			codigoPara = this.parametroPantalla.getCodigoBusq();
		}

		if (!GenericUtils.isNullOrBlank(this.parametroPantalla
				.getTipoParamBusq())) {
			tipoPara = this.parametroPantalla.getTipoParamBusq();
		}

		List<Parametro> listaParametros = (List<Parametro>) parametroBo
				.buscarParametros(codigoPara, tipoPara, paginationData
						.getPaginationDataForExcel());
		parametroPantalla.setParametrosList(listaParametros);
	}

	/** Prepara para entrar en el modo edición de un parámetro de informe. */
	public void editar() {
		(this.parametroPantalla.getParametroIdSelec()).setCodigo(this.parametroPantalla.getParametroSelec().getId().getCodigo());
		(this.parametroPantalla.getParametroIdSelec()).setProyecto(Constantes.NOMBRE_PROYECTO_DERI);
		(this.parametroPantalla.getParametroIdSelec()).setNombre(this.parametroPantalla.getParametroSelec().getId().getNombre());
		(this.parametroPantalla.getParametroIdSelec()).setTipo(this.parametroPantalla.getParametroSelec().getId().getTipo());
		parametroPantalla.setParametro(this.parametroPantalla.getParametroSelec());
		parametroPantalla.setParametroIdSelec(this.parametroPantalla.getParametroIdSelec());
		this.setModoPantalla(ModoPantalla.EDICION);
	}

	/** Prepara para entrar en el modo inspección de un parámetro informe. */
	public void ver() {
		parametroPantalla.setParametro(parametroPantalla.getParametroSelec());
		this.setModoPantalla(ModoPantalla.INSPECCION);
	}

	/**
	 * Valida que no se pueda dar de alta un registro con la misma PK que uno que ya
	 * exista en la bbdd
	 * @return
	 */
	public boolean guardarValidator(){
		
		boolean esCorrecto = true;
		Parametro paramExistente = null;
		boolean existe = false;
		
		if(ModoPantalla.CREACION.equals(this.getModoPantalla())){
			
			// Comprobamos que no exista un registro en bbdd con la misma pk
			paramExistente = parametroBo.cargar(parametroPantalla.getParametro().getId());
			
			/*
			 * Si no hay registro con la misma PK Comprobamos si ya existe un
			 * parámetro con el mismo Codigo y Proyecto que el informado y
			 * diferente Tipo. Si ya existe, se mostrará mensaje de error
			 */
			if (GenericUtils.isNullOrBlank(paramExistente)){
				existe = parametroBo.comprobarParametroExiste(
						parametroPantalla.getParametro().getId().getCodigo(),
						parametroPantalla.getParametro().getId().getTipo());
			}
			
		} else if(ModoPantalla.EDICION.equals(this.getModoPantalla())){
			// Primero comprobamos si se ha cambiado el nombre para realizar o no la validación
			if(!parametroPantalla.getParametroIdSelec().getNombre().equalsIgnoreCase(parametroPantalla.getParametro().getId().getNombre())){
				paramExistente = parametroBo.cargar(parametroPantalla.getParametro().getId());
			}
		}
		
		if (!GenericUtils.isNullOrBlank(paramExistente) || existe){
			statusMessages.add(Severity.ERROR, "#{messages['parametro.error.yaexiste']}");
			esCorrecto = false;
		}
		
		return esCorrecto;
	}
	
	/** Graba el parámetro de informe en la base de datos. */
	public String guardar() {
		
		if(ModoPantalla.CREACION.equals(this.getModoPantalla())){
			parametroBo.guardar(parametroPantalla.getParametro());
		} else if(ModoPantalla.EDICION.equals(this.getModoPantalla())){
			parametroBo.actualizarParametro(parametroPantalla.getParametro(), parametroPantalla.getParametroIdSelec());
			parametroBo.recargar(parametroPantalla.getParametro());
		}
		refrescarLista();
		return Constantes.CONSTANTE_SUCCESS;
	}

	/** Borra un parámetro de informe. */
	public void borrar() {
		parametroBo.borrar(parametroPantalla.getParametroSelec());
		refrescarLista();
	}

	/** Prepara para entrar en el modo creación de un parámetro de informe. */
	public void nuevo() {
		parametroPantalla.setParametro(new Parametro(new ParametroId(Constantes.NOMBRE_PROYECTO_DERI,null,null,null), null));
		this.setModoPantalla(ModoPantalla.CREACION);
	}

	@Override
	public List<?> getDataTableList() {
		return parametroPantalla.getParametrosList();
	}

	@SuppressWarnings("unchecked")
	@Override
	public void setDataTableList(List<?> dataTableList) {
		parametroPantalla.setParametrosList((List<Parametro>) dataTableList);
	}

}
