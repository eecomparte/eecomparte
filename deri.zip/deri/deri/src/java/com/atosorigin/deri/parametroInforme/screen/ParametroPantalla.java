package com.atosorigin.deri.parametroInforme.screen;

import java.util.ArrayList;
import java.util.List;

import org.jboss.seam.ScopeType;
import org.jboss.seam.annotations.Name;
import org.jboss.seam.annotations.Out;
import org.jboss.seam.annotations.Scope;
import org.jboss.seam.annotations.datamodel.DataModel;
import org.jboss.seam.annotations.datamodel.DataModelSelection;

import com.atosorigin.common.constantes.Constantes;
import com.atosorigin.deri.model.appListados.Parametro;
import com.atosorigin.deri.model.appListados.ParametroId;

/**
 * Contiene los datos de pantalla necesarios para el caso de uso documentos por
 * contrapartida.
 */
@Name("parametroPantalla")
@Scope(ScopeType.CONVERSATION)
public class ParametroPantalla {

	/** Lista de datos para el grid. */
	@DataModel(value = "listaDtParametros")
	protected List<Parametro> parametrosList;

	/** Parametro seleccionado en el grid */
	@DataModelSelection(value = "listaDtParametros")
	@Out(value = "parametroSelec", required = false)
	protected Parametro parametroSelec;

	@Out(value = "parametro", required = false)
	protected Parametro parametro;

	/** Necesario para el update de parametros de informe */
	protected ParametroId parametroIdSelec;
	
	/** Criterios de búsqueda */
	protected List<String> listaValores;
	protected String codigoBusq;
	protected String tipoParamBusq;

	public ParametroPantalla() {
		this.parametroIdSelec = new ParametroId();
		this.listaValores = new ArrayList<String>();
		this.listaValores.add(Constantes.PARAM_TIPO_CHAR_DESC);
		this.listaValores.add(Constantes.PARAM_TIPO_DATE_DESC);
		this.listaValores.add(Constantes.PARAM_TIPO_NUMBER_DESC);
	}
	
	public List<Parametro> getParametrosList() {
		return parametrosList;
	}

	public Parametro getParametroSelec() {
		return parametroSelec;
	}

	public Parametro getParametro() {
		return parametro;
	}

	public String getTipoParamBusq() {
		return tipoParamBusq;
	}

	public void setParametrosList(List<Parametro> parametrosList) {
		this.parametrosList = parametrosList;
	}

	public void setParametroSelec(Parametro parametroSelec) {
		this.parametroSelec = parametroSelec;
	}

	public void setParametro(Parametro parametro) {
		this.parametro = parametro;
	}

	public void setTipoParamBusq(String tipoParamBusq) {
		this.tipoParamBusq = tipoParamBusq;
	}

	public List<String> getListaValores() {
		return listaValores;
	}

	public void setListaValores(List<String> listaValores) {
		this.listaValores = listaValores;
	}

	public String getCodigoBusq() {
		return codigoBusq;
	}

	public void setCodigoBusq(String codigoBusq) {
		this.codigoBusq = codigoBusq;
	}

	public ParametroId getParametroIdSelec() {
		return parametroIdSelec;
	}

	public void setParametroIdSelec(ParametroId parametroIdSelec) {
		this.parametroIdSelec = parametroIdSelec;
	}
}
