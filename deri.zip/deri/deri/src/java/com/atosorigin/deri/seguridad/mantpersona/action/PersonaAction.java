package com.atosorigin.deri.seguridad.mantpersona.action;

import java.util.List;

import org.jboss.seam.ScopeType;
import org.jboss.seam.annotations.In;
import org.jboss.seam.annotations.Name;
import org.jboss.seam.annotations.Scope;

import com.atosorigin.common.action.PaginatedListAction;
import com.atosorigin.common.formvalidator.FormValidator;
import com.atosorigin.deri.model.seguridad.TbPersona;
import com.atosorigin.deri.seguridad.mantpersona.business.PersonaBo;
import com.atosorigin.deri.seguridad.mantpersona.screen.PersonaPantalla;

/**
 * Clase que actúa de action listener para el caso de uso de mantenimiento de usuarios.
 */
@Name("personaAction")
@Scope(ScopeType.CONVERSATION)
@FormValidator
public class PersonaAction extends PaginatedListAction{

	/**
	 * Inyección del bean de Spring "usuarioBo" que contiene los métodos de negocio
	 * para el caso de uso mantenimiento de usuarios.
	 */
	@In("#{personaBo}")
	protected PersonaBo personaBo;


	/**
	 * Inyección del screen bean que contiene los datos de pantalla del caso de uso
	 * mantenimiento de usuarios.
	 */
	@In(create=true)
	protected PersonaPantalla personaPantalla;

	/**
	 * Actualiza la lista del grid de usuarios
	 * 
	 */
	public void buscar() {
		refrescarLista();
		statusMessages.add("#{messages['status.busqueda.completada']}");
	}

	/**
	 * Prepara para entrar en el modo edición de un persona.
	 * 
	 */
	public void editar() {
		personaPantalla.setPersona(personaBo.cargar(personaPantalla.getPersona().getNif()));
		statusMessages.add("#{messages['status.edicion']}");
	}

	/**
	 * Prepara para entrar en el modo inspección de un persona.
	 * 
	 */
	public void ver() {
		personaPantalla.setPersona(personaBo.cargar(personaPantalla.getPersona().getNif()));
		statusMessages.add("#{messages['status.inspeccion']}");
	}

	/**
	 * Prepara para entrar en el modo creación de un persona.
	 * 
	 */
	public void nuevo() {
		personaPantalla.setPersona(new TbPersona());
		statusMessages.add("#{messages['status.creacion']}");
	}

	
	/**
	 * Borra un persona.
	 * 
	 */
	public void borrar() {
		personaBo.borrar(personaPantalla.getPersona());
		statusMessages.add("#{messages['status.borrado']}");
		refrescarLista();
	}


	/**
	 * Método de validación de formulario previo a la acción guardar.
	 * El interceptor seam FormValidator lo ejecutará antes del método "guardar".
	 * 
	 * @return true si no hay errores de validación, false en caso contrario.
	 */
	public boolean guardarValidator() {
		return true;
	}
	
	/**
	 * Graba el persona en la base de datos.
	 * 
	 */
	public String guardar() {
		personaBo.guardar(personaPantalla.getPersona());
		statusMessages.add("#{messages['status.actualizado.correcto']}");
		refrescarLista();
		return "success";
	}
	

		
	//Métodos necesarios para pantallas con grids.
	//Es necesario implementar estos métodos abstractos de PaginatedListAction

	@Override
	public List<TbPersona> getDataTableList() {
		return personaPantalla.getPersonaList();
	}

	@Override
	@SuppressWarnings("unchecked")
	public void setDataTableList(List<?> dataTableList) {
		personaPantalla.setPersonaList((List<TbPersona>)dataTableList);
	}

	@Override
	protected void refreshListInternal() {

		List ql = (List)personaBo.buscarPersonas(personaPantalla.getNif(), personaPantalla.getNombreReal(),  paginationData);
		personaPantalla.setPersonaList(ql);
	}

	@Override
	public void refrescarListaExcel() {
		// TODO Auto-generated method stub
		List ql = (List)personaBo.buscarPersonas(personaPantalla.getNif(), personaPantalla.getNombreReal(),  paginationData.getPaginationDataForExcel());
	}	
	

	
}
