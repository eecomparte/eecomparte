package com.atosorigin.deri.seguridad.mantpersona.screen;

import java.util.List;

import org.jboss.seam.ScopeType;
import org.jboss.seam.annotations.Name;
import org.jboss.seam.annotations.Out;
import org.jboss.seam.annotations.Scope;
import org.jboss.seam.annotations.datamodel.DataModel;
import org.jboss.seam.annotations.datamodel.DataModelSelection;

import com.atosorigin.deri.model.seguridad.TbPersona;


// TODO: Auto-generated Javadoc
/**
 *  Contiene los datos de pantalla necesarios para el caso de uso mantenimiento de usuarios.
 */
@Name("personaPantalla")
@Scope(ScopeType.CONVERSATION)
public class PersonaPantalla {

	/** Fecha nacimiento inicial. Criterio de búsqueda de usuarios. */
	protected String nif;
	
	/** Fecha nacimiento final. Criterio de búsqueda de usuarios.  */
	protected String nombreReal;
	
	
	
	/** Lista de datos para el grid. */
	@DataModel(value ="listaDtPersonas")
	protected List<TbPersona> personaList;
	
	/** Usuario seleccionado en el grid */
	@DataModelSelection(value ="listaDtPersonas")
    @Out(required=false)
    protected TbPersona persona;

	
	/** Número de resultados totales para los criterios de búsqueda.. */
	protected Long numFilas = 0L;
	

	/**
	 * Obtiene la Lista de datos para el grid.
	 * 
	 * @return la lista de usuarios que mostrará el grid de resultados de la búsqueda.
	 */
	public List<TbPersona> getUsuarioList() {
		return personaList;
	}

	/**
	 * Establece la Lista de datos para el grid.
	 * 
	 * @param usuarioList la lista de usuarios del grid.
	 */
	public void setPersonaList(List<TbPersona> personaList) {
		this.personaList = personaList;
	}

	public String getNif() {
		return nif;
	}

	public void setNif(String nif) {
		this.nif = nif;
	}

	public String getNombreReal() {
		return nombreReal;
	}

	public void setNombreReal(String nombreReal) {
		this.nombreReal = nombreReal;
	}

	public List<TbPersona> getPersonaList() {
		return personaList;
	}

	public TbPersona getPersona() {
		return persona;
	}

	public void setPersona(TbPersona persona) {
		this.persona = persona;
	}

	public Long getNumFilas() {
		return numFilas;
	}

	public void setNumFilas(Long numFilas) {
		this.numFilas = numFilas;
	}


}
