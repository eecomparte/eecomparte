package com.atosorigin.deri.seguridad.mantusuario.action;

import java.util.List;
import java.util.Random;

import org.jboss.seam.ScopeType;
import org.jboss.seam.annotations.Factory;
import org.jboss.seam.annotations.In;
import org.jboss.seam.annotations.Name;
import org.jboss.seam.annotations.Scope;
import org.jboss.seam.international.StatusMessage.Severity;

import com.atosorigin.common.action.ModoPantalla;
import com.atosorigin.common.action.PaginatedListAction;
import com.atosorigin.common.formvalidator.FormValidator;
import com.atosorigin.deri.model.seguridad.Usuario;
import com.atosorigin.deri.seguridad.mantusuario.business.UsuarioBo;
import com.atosorigin.deri.seguridad.mantusuario.screen.MantUsuarioPantalla;

@Name("mantUsuarioAction")
@Scope(ScopeType.CONVERSATION)
@FormValidator
public class MantUsuarioAction extends PaginatedListAction{

	@In(value="#{usuarioBo}")
	protected UsuarioBo usuarioBo;
	
	@In(create=true)
	protected MantUsuarioPantalla mantUsuarioPantalla;
	
	private Boolean mostarPanelPass = false;
	
	@Override
	public List<?> getDataTableList() {
		return mantUsuarioPantalla.getListaUsuarios();
	}
	
	/**
	 * Prepara para entrar en el modo edici�n de un usuario.
	 * 
	 */
	public void editar() {
		//mantUsuarioPantalla.setUsuarioSeleccionado(usuarioBo.cargar(mantUsuarioPantalla.getUsuarioSeleccionado().getId()));
		mantUsuarioPantalla.copiaSeleccionado();
		setModoPantalla(ModoPantalla.EDICION);
	}
	
	public void ver() {
		mantUsuarioPantalla.copiaSeleccionado();
		setModoPantalla(ModoPantalla.INSPECCION);
	}
	
	public void nuevo(){
		
		Usuario nuevo = new Usuario();
		//nuevo.setPerfil(0);
		nuevo.setEstadoBloqueo(false);
		mantUsuarioPantalla.setUsuarioSeleccionado(nuevo);
		
		//SMM 04/01/2010 
//		this.generaNewPassword();
		setModoPantalla(ModoPantalla.CREACION);
	}
	
	public void borrar(){
		mantUsuarioPantalla.copiaSeleccionado();
		usuarioBo.borrar(mantUsuarioPantalla.getUsuarioSeleccionado());
		mantUsuarioPantalla.setListaUsuarios(null);
		
	}
	
	/**
	 * Se realiza una comprobación por si el usuario introduce espacios y solo espacios en el sistema.
	 * @return
	 */
	public boolean guardarValidator(){
		boolean ret = true;
		if(!getModoPantalla().equals(ModoPantalla.INSPECCION)){
			
			if(mantUsuarioPantalla.getUsuarioSeleccionado().getId().getCodigo().trim().equals("")){	
			statusMessages.addFromResourceBundle(Severity.ERROR, "usuario.campoObligatorio","Codigo ");
			ret = false;
			}
			if(mantUsuarioPantalla.getUsuarioSeleccionado().getNombre().trim().equals("")){	
				statusMessages.addFromResourceBundle(Severity.ERROR, "usuario.campoObligatorio","Nombre ");
				ret = false;
			}
			if(mantUsuarioPantalla.getUsuarioSeleccionado().getPrimerApellido().trim().equals("")){	
				statusMessages.addFromResourceBundle(Severity.ERROR, "usuario.campoObligatorio","Primer Apellido ");
				ret = false;
			}
			if(mantUsuarioPantalla.getUsuarioSeleccionado().getDni().trim().equals("")){	
				statusMessages.addFromResourceBundle(Severity.ERROR, "usuario.campoObligatorio","NIF ");
				ret = false;
			}
		
		
		}
		
			return ret;
	}
	
	public String guardar(){
		if(mantUsuarioPantalla.getUsuarioSeleccionado().getPerfil()==null){
			statusMessages.addToControl("perfil", Severity.ERROR, "#{messages['usuario.error.perfilNoNulo']}");
			return "failure";
		}
		if(getModoPantalla().equals(ModoPantalla.CREACION)){
			this.generaNewPassword();
			if(usuarioBo.cargar(mantUsuarioPantalla.getUsuarioSeleccionado().getId()) != null){
				statusMessages.addToControl("codigo", Severity.ERROR, "#{messages['usuario.error.usuarioYaExiste']}");
				return "failure";
			}
		}
		
		Usuario usuario = mantUsuarioPantalla.getUsuarioSeleccionado();
		usuarioBo.guardar(usuario);
		mostarPanelPass = false;
		refrescarLista();

		return "success";
	}

	@Factory("listaDtUsuariosDeri")
	@SuppressWarnings("unchecked")
	@Override
	public void refreshListInternal() {
		setExportExcel(false);
		List ql = (List)usuarioBo.buscarUsuariosProyDeri(paginationData);
		mantUsuarioPantalla.setListaUsuarios(ql);
		setPrimerAcceso(false);
	}

	@Override
	public void refrescarListaExcel() {
		setExportExcel(true);
		mantUsuarioPantalla.setListaUsuarios(usuarioBo.buscarUsuariosProyDeri(paginationData.getPaginationDataForExcel()));
		
	}

	@SuppressWarnings("unchecked")
	@Override
	public void setDataTableList(List<?> dataTableList) {
		mantUsuarioPantalla.setListaUsuarios((List<Usuario>)dataTableList);
		
	}

	public void generaNewPassword(){
		this.mostarPanelPass = true;
		Random r = new Random();
		Integer pass = r.nextInt(99999998);
		pass++;
		//SMM 04/01/2009 Pwd igual al identificador
		//mantUsuarioPantalla.setPasswordNoEncript(pass.toString());
		
		if(mantUsuarioPantalla.getUsuarioSeleccionado() == null){
		//	mantUsuarioPantalla.getUsuarioSeleccionado().setPassword(usuarioBo.encriptarPassword(pass.toString(), null));
			mantUsuarioPantalla.setPasswordNoEncript("12345");
			mantUsuarioPantalla.getUsuarioSeleccionado().setPassword(usuarioBo.encriptarPassword("12345", null));
		}else{
			
			String codigoUser = mantUsuarioPantalla.getUsuarioSeleccionado().getId().getCodigo();
			
//			mantUsuarioPantalla.getUsuarioSeleccionado().setPassword(usuarioBo.encriptarPassword(pass.toString(), mantUsuarioPantalla.getUsuarioSeleccionado()));
			if (codigoUser != null){ 
				
				//Si el nombre de usuario tiene más de 8 caracteres hay que limitarlo a 8
				//que es la longitud del campo en la base de datos
				if (codigoUser.length() > 8){
					codigoUser = codigoUser.substring(0,8);
				} 
				
				mantUsuarioPantalla.setPasswordNoEncript(codigoUser);
				mantUsuarioPantalla.getUsuarioSeleccionado().setPassword(usuarioBo.encriptarPassword(codigoUser, mantUsuarioPantalla.getUsuarioSeleccionado()));
			}else{
				mantUsuarioPantalla.setPasswordNoEncript("12345");
				mantUsuarioPantalla.getUsuarioSeleccionado().setPassword(usuarioBo.encriptarPassword("12345", null));	
			}
		}
	}

	public void bloqueoDesbloqueo(){
		if(mantUsuarioPantalla.getUsuarioSeleccionado() != null){
			if(mantUsuarioPantalla.getUsuarioSeleccionado().getEstadoBloqueo() != null){
				mantUsuarioPantalla.getUsuarioSeleccionado().setEstadoBloqueo(!mantUsuarioPantalla.getUsuarioSeleccionado().getEstadoBloqueo());
			}
			else{
				mantUsuarioPantalla.getUsuarioSeleccionado().setEstadoBloqueo(false);
			}
		}
	}
	
	public UsuarioBo getUsuarioBo() {
		return usuarioBo;
	}



	public void setUsuarioBo(UsuarioBo usuarioBo) {
		this.usuarioBo = usuarioBo;
	}



	public MantUsuarioPantalla getMantUsuarioPantalla() {
		return mantUsuarioPantalla;
	}



	public void setMantUsuarioPantalla(MantUsuarioPantalla mantUsuarioPantalla) {
		this.mantUsuarioPantalla = mantUsuarioPantalla;
	}

	public Boolean getMostarPanelPass() {
		return mostarPanelPass;
	}

	public void setMostarPanelPass(Boolean mostarPanelPass) {
		this.mostarPanelPass = mostarPanelPass;
	}

	

	
}