package com.atosorigin.deri.seguridad.mantusuario.screen;

import java.util.List;

import org.jboss.seam.ScopeType;
import org.jboss.seam.annotations.Name;
import org.jboss.seam.annotations.Out;
import org.jboss.seam.annotations.Scope;
import org.jboss.seam.annotations.datamodel.DataModel;
import org.jboss.seam.annotations.datamodel.DataModelSelection;

import com.atosorigin.deri.model.seguridad.Usuario;


@Name("mantUsuarioPantalla")
@Scope(ScopeType.CONVERSATION)
public class MantUsuarioPantalla {
	
	
	protected String passwordNoEncript;

	@DataModel(value="listaDtUsuariosDeri")
	protected List<Usuario> listaUsuarios;
	
	@DataModelSelection(value="listaDtUsuariosDeri")
	protected Usuario usuario;
	
	
	@Out(required=false)
	protected Usuario usuarioSeleccionado;

	protected String desBloqueo;

	
	

	public List<Usuario> getListaUsuarios() {
		
		return listaUsuarios;
	}

	public void setListaUsuarios(List<Usuario> listaUsuarios) {
		this.listaUsuarios = listaUsuarios;
	}

	public Usuario getUsuarioSeleccionado() {
		return usuarioSeleccionado;
	}

	public void setUsuarioSeleccionado(Usuario usuarioSeleccionado) {
		this.usuarioSeleccionado = usuarioSeleccionado;
	}

	public String getPasswordNoEncript() {
		return passwordNoEncript;
	}

	public void setPasswordNoEncript(String passwordNoEncript) {
		this.passwordNoEncript = passwordNoEncript;
	}

	public String getDesBloqueo() {
		return desBloqueo;
	}

	public void setDesBloqueo(String desBloqueo) {
		this.desBloqueo = desBloqueo;
	}
	public void copiaSeleccionado(){
		usuarioSeleccionado = usuario;
	}

}
