package com.atosorigin.deri.seguridad.mantusuario.screen;

import java.util.Date;
import java.util.List;

import org.hibernate.validator.Past;
import org.jboss.seam.ScopeType;
import org.jboss.seam.annotations.Name;
import org.jboss.seam.annotations.Out;
import org.jboss.seam.annotations.Scope;
import org.jboss.seam.annotations.datamodel.DataModel;
import org.jboss.seam.annotations.datamodel.DataModelSelection;

import com.atosorigin.deri.model.seguridad.TbPersona;
import com.atosorigin.deri.model.seguridad.TbUsuario;
import com.atosorigin.deri.model.seguridad.Usuario;


// TODO: Auto-generated Javadoc
/**
 *  Contiene los datos de pantalla necesarios para el caso de uso mantenimiento de usuarios.
 */
@Name("usuarioPantalla")
@Scope(ScopeType.CONVERSATION)
public class UsuarioPantalla {

	/** Fecha nacimiento inicial. Criterio de búsqueda de usuarios. */
	protected Date fechaNacimientoInicial;
	
	/** Fecha nacimiento final. Criterio de búsqueda de usuarios.  */
	protected Date fechaNacimientoFinal;
	
	/** Persona real a la que pertenece el usuario. Criterio de búsqueda de usuarios.  */
	protected TbPersona personaSelect;
	
	
	/** Lista de datos para el grid. */
	@DataModel(value ="listaDtUsuarios")
	protected List<TbUsuario> usuarioList;
	
	/** Usuario seleccionado en el grid */
	@DataModelSelection(value ="listaDtUsuarios")
	@Out(value="usuarioSeleccionado", required=false)
    protected TbUsuario usuarioSeleccionado;

    @Out(value="usuario", required=false)
	protected Usuario usuario;

	

	/**
	 * Obtiene la Lista de datos para el grid.
	 * 
	 * @return la lista de usuarios que mostrará el grid de resultados de la búsqueda.
	 */
	public List<TbUsuario> getUsuarioList() {
		return usuarioList;
	}

	/**
	 * Establece la Lista de datos para el grid.
	 * 
	 * @param usuarioList la lista de usuarios del grid.
	 */
	public void setUsuarioList(List<TbUsuario> usuarioList) {
		this.usuarioList = usuarioList;
//		numFilas1 = ((List)usuarioList).getNumFilas();
	}


	/**
	 * Obtiene la Lista de datos para el grid.
	 * 
	 * @return usuario
	 */
	public Usuario getUsuario() {
		return usuario;
	}

	/**
	 * Establece el usuario con el que trabajar.
	 * 
	 * @param usuario el usuario
	 */
	public void setUsuario(Usuario usuario) {
		this.usuario = usuario;
	}


	/**
	 * Obtiene la persona del usuario.
	 * 
	 * @return the persona select
	 */
	public TbPersona getPersonaSelect() {
		return personaSelect;
	}

	/**
	 * Establece la persona del usuario seleccionada.
	 * 
	 * @param personaSelect La persona del usuario.
	 */
	public void setPersonaSelect(TbPersona personaSelect) {
		this.personaSelect = personaSelect;
	}

	
	/**
	 * Gets the fecha nacimiento inicial.
	 * 
	 * @return the fecha nacimiento inicial
	 */
	@Past
	public Date getFechaNacimientoInicial() {
		return fechaNacimientoInicial;
	}
	
	/**
	 * Establece la fecha de nacimiento inicial.
	 * 
	 * @param fechaNacimientoInicial La fecha de nacimiento inicial
	 */
	public void setFechaNacimientoInicial(Date fechaNacimientoInicial) {
		this.fechaNacimientoInicial = fechaNacimientoInicial;
	}
	
	/**
	 * Gets the fecha nacimiento final.
	 * 
	 * @return the fecha nacimiento final.
	 */
	@Past
	public Date getFechaNacimientoFinal() {
		return fechaNacimientoFinal;
	}
	
	/**
	 * Establece la fecha de nacimiento Final.
	 * 
	 * @param fechaNacimientoFinal La fecha de nacimiento final.
	 */
	public void setFechaNacimientoFinal(Date fechaNacimientoFinal) {
		this.fechaNacimientoFinal = fechaNacimientoFinal;
	}
	
	public TbUsuario getUsuarioSeleccionado() {
		return usuarioSeleccionado;
	}

	public void setUsuarioSeleccionado(TbUsuario usuarioSeleccionado) {
		this.usuarioSeleccionado = usuarioSeleccionado;
	}


	
}
