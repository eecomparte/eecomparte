package com.atosorigin.deri.seguridad.pantalla.action;

import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.jboss.seam.ScopeType;
import org.jboss.seam.annotations.In;
import org.jboss.seam.annotations.Name;
import org.jboss.seam.annotations.Scope;

import com.atosorigin.common.action.ModoPantalla;
import com.atosorigin.common.action.PaginatedListAction;
import com.atosorigin.common.formvalidator.FormValidator;
import com.atosorigin.deri.common.authentication.PantallasNivelesCache;
import com.atosorigin.deri.model.seguridad.NivelPrivilegio;
import com.atosorigin.deri.model.seguridad.Pantalla;
import com.atosorigin.deri.seguridad.pantalla.business.PantallaBo;
import com.atosorigin.deri.seguridad.pantalla.screen.PantallaPantalla;

/**
 * Clase que actúa de action listener para el caso de uso de mantenimiento de usuarios.
 */
@Name("pantallaAction")
@Scope(ScopeType.CONVERSATION)
@FormValidator
public class PantallaAction extends PaginatedListAction{

	/**
	 * Inyección del bean de Spring "usuarioBo" que contiene los métodos de negocio
	 * para el caso de uso mantenimiento de usuarios.
	 */
	@In("#{pantallaBo}")
	protected PantallaBo pantallaBo;

	
	@In("pantallasNivelesCache")
	protected PantallasNivelesCache pantallasNivelesCache;
	
	/**
	 * Inyección del screen bean que contiene los datos de pantalla del caso de uso
	 * mantenimiento de usuarios.
	 */
	@In(create=true)
	protected PantallaPantalla pantallaPantalla;

	/**
	 * Actualiza la lista del grid de usuarios
	 * 
	 */
	public void buscar() {
		paginationData.reset();
		refrescarLista();
//		statusMessages.add("#{messages['status.busqueda.completada']}");
	}

	/**
	 * Prepara para entrar en el modo edición de un persona.
	 * 
	 */
	public void editar() {
		pantallaPantalla.setPantalla(pantallaBo.cargar(pantallaPantalla.getPantalla().getId()));
//		statusMessages.add("#{messages['status.edicion']}");
		setModoPantalla(ModoPantalla.EDICION);
	}

	/**
	 * Prepara para entrar en el modo inspección de un persona.
	 * 
	 */
	public void ver() {
		pantallaPantalla.setPantalla(pantallaBo.cargar(pantallaPantalla.getPantalla().getId()));
//		statusMessages.add("#{messages['status.inspeccion']}");
		setModoPantalla(ModoPantalla.INSPECCION);
	}

	/**
	 * Prepara para entrar en el modo creación de un persona.
	 * 
	 */
	public void nuevo() {
		pantallaPantalla.setPantalla(new Pantalla());
//		statusMessages.add("#{messages['status.creacion']}");
		setModoPantalla(ModoPantalla.CREACION);
	}

	
	/**
	 * Borra un persona.
	 * 
	 */
	public void borrar() {
		//Actualizamos la cache de pantallasNiveles.
		pantallasNivelesCache.actualizarPantallaBorrar(pantallaPantalla.getPantalla());
		pantallaBo.borrar(pantallaPantalla.getPantalla());
//		statusMessages.add("#{messages['status.borrado']}");
		refrescarLista();
	}


	/**
	 * Método de validación de formulario previo a la acción guardar.
	 * El interceptor seam FormValidator lo ejecutará antes del método "guardar".
	 * 
	 * @return true si no hay errores de validación, false en caso contrario.
	 */
	public boolean guardarValidator() {
		return true;
	}
	
	/**
	 * Graba el persona en la base de datos.
	 * 
	 */
	public String guardar() {
		Pantalla pantalla = pantallaPantalla.getPantalla();
		//Esto lo hacemos en el guardar
		pantalla.checkPrivilegios();
		
		updatePrivilegios(pantalla);
		pantallaBo.guardar(pantalla);
		//Actualizamos la cache de pantallasNiveles.
		pantallasNivelesCache.actualizarPantalla(pantalla);
		
//		statusMessages.add("#{messages['status.actualizado.correcto']}");
		refrescarLista();
		return "success";
	}

	private void updatePrivilegios(Pantalla pantalla) {
		// No guardamos los niveles de privilegios que están a 0
		Set<NivelPrivilegio> privilegios = pantalla.getPrivilegios();
		
		// Añadimos todos los privilegios de pantalla
		privilegios.add(pantalla.getPrivilegioAlta());
		privilegios.add(pantalla.getPrivilegioBaja());
		privilegios.add(pantalla.getPrivilegioModificacion());
		privilegios.add(pantalla.getPrivilegioConsulta());
		privilegios.add(pantalla.getPrivilegioImpresion());
		
		Set<NivelPrivilegio> privilegiosToRemove = new HashSet<NivelPrivilegio>();
		for (NivelPrivilegio nivelPrivilegio : privilegios) {
			if(nivelPrivilegio.getNivel() == 0) {
				// Eliminamos los privilegios con nivel 0
				privilegiosToRemove.add(nivelPrivilegio);
			}
		}
		privilegios.removeAll(privilegiosToRemove);
	}
	

		
	//Métodos necesarios para pantallas con grids.
	//Es necesario implementar estos métodos abstractos de PaginatedListAction

	@Override
	public List<Pantalla> getDataTableList() {
		return pantallaPantalla.getPantallaList();
	}

	@Override
	@SuppressWarnings("unchecked")
	public void setDataTableList(List<?> dataTableList) {
		pantallaPantalla.setPantallaList((List<Pantalla>)dataTableList);
	}

	@Override
	protected void refreshListInternal() {
		setExportExcel(false);
		List ql = (List)pantallaBo.buscarPantallas(paginationData);
		pantallaPantalla.setPantallaList(ql);
		setPrimerAcceso(false);
	}

	@Override
	public void refrescarListaExcel() {
		setExportExcel(true);
		// TODO Auto-generated method stub
		List ql = (List)pantallaBo.buscarPantallas(paginationData.getPaginationDataForExcel());
		pantallaPantalla.setPantallaList(ql);
	}	
	
	@Override
	public void salir() {
		if(pantallaPantalla.getPantalla()!=null &&
				pantallaPantalla.getPantalla().getId()!=null){
			pantallaBo.recargar(pantallaPantalla.getPantalla());
		}
	}
	
}
