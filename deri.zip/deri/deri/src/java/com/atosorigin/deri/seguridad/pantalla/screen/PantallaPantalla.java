package com.atosorigin.deri.seguridad.pantalla.screen;

import java.util.List;

import org.jboss.seam.ScopeType;
import org.jboss.seam.annotations.Name;
import org.jboss.seam.annotations.Out;
import org.jboss.seam.annotations.Scope;
import org.jboss.seam.annotations.datamodel.DataModel;
import org.jboss.seam.annotations.datamodel.DataModelSelection;

import com.atosorigin.deri.model.seguridad.Pantalla;


// TODO: Auto-generated Javadoc
/**
 *  Contiene los datos de pantalla necesarios para el caso de uso mantenimiento de usuarios.
 */
@Name("pantallaPantalla")
@Scope(ScopeType.CONVERSATION)
public class PantallaPantalla {

	/** Lista de datos para el grid. */
	@DataModel(value ="listaDtPantallas")
	protected List<Pantalla> pantallaList;
	
	/** Usuario seleccionado en el grid */
	@DataModelSelection(value ="listaDtPantallas")
    @Out(required=false)
    protected Pantalla pantalla;

	
	protected Boolean checkboxAlta = false;
	protected Boolean checkboxBaja = false;
	protected Boolean checkboxConsulta = false;
	protected Boolean checkboxModificacion = false;
	protected Boolean checkboxImpresion = false;

	
	/** Número de resultados totales para los criterios de búsqueda.. */
	protected Long numFilas = 0L;
	

	/**
	 * Obtiene la Lista de datos para el grid.
	 * 
	 * @return la lista de usuarios que mostrará el grid de resultados de la búsqueda.
	 */
	public List<Pantalla> getPantallaList() {
		return pantallaList;
	}

	/**
	 * Establece la Lista de datos para el grid.
	 * 
	 * @param usuarioList la lista de usuarios del grid.
	 */
	public void setPantallaList(List<Pantalla> pantallaList) {
		this.pantallaList = pantallaList;
	}
	
	/**
	 * Setea los valores de los checkbox en pantalla a partir del nivel
	 * de privilegio que hay en la base de datos.
	 */
	public void setPantallaCheckBoxes() {
		resetCheckboxes();
		if(pantalla != null){
			if(pantalla.getPrivilegioAlta() != null && pantalla.getPrivilegioAlta().getNivel() != 0) {
				this.checkboxAlta = true;
			}
			if(pantalla.getPrivilegioBaja() != null && pantalla.getPrivilegioBaja().getNivel() != 0) {
				this.checkboxBaja = true;
			}
			if(pantalla.getPrivilegioConsulta() != null && pantalla.getPrivilegioConsulta().getNivel() != 0) {
				this.checkboxConsulta = true;
			}
			if(pantalla.getPrivilegioModificacion() != null && pantalla.getPrivilegioModificacion().getNivel() != 0) {
				this.checkboxModificacion = true;
			}
			if(pantalla.getPrivilegioImpresion() != null && pantalla.getPrivilegioImpresion().getNivel() != 0) {
				this.checkboxImpresion = true;
			}
		}
	}

	private void resetCheckboxes() {
		this.checkboxAlta=false;
		this.checkboxBaja=false;
		this.checkboxConsulta=false;
		this.checkboxModificacion=false;
		this.checkboxImpresion=false;
	}

	public Pantalla getPantalla() {
		return pantalla;
	}

	public void setPantalla(Pantalla pantalla) {
		this.pantalla = pantalla;
		setPantallaCheckBoxes();
	}

	public Long getNumFilas() {
		return numFilas;
	}

	public void setNumFilas(Long numFilas) {
		this.numFilas = numFilas;
	}

	public Boolean getCheckboxAlta() {
		return checkboxAlta;
	}

	public void setCheckboxAlta(Boolean checkboxAlta) {
		this.checkboxAlta = checkboxAlta;
		if(!this.checkboxAlta) {
			pantalla.getPrivilegioAlta().setNivel(0);
		}
	}

	public Boolean getCheckboxBaja() {
		return checkboxBaja;
	}

	public void setCheckboxBaja(Boolean checkboxBaja) {
		this.checkboxBaja = checkboxBaja;
		if(!this.checkboxBaja) {
			pantalla.getPrivilegioBaja().setNivel(0);
		}
	}

	public Boolean getCheckboxConsulta() {
		return checkboxConsulta;
	}

	public void setCheckboxConsulta(Boolean checkboxConsulta) {
		this.checkboxConsulta = checkboxConsulta;
		if(!this.checkboxConsulta) {
			pantalla.getPrivilegioConsulta().setNivel(0);
		}
	}

	public Boolean getCheckboxModificacion() {
		return checkboxModificacion;
	}

	public void setCheckboxModificacion(Boolean checkboxModificacion) {
		this.checkboxModificacion = checkboxModificacion;
		if(!this.checkboxModificacion) {
			pantalla.getPrivilegioModificacion().setNivel(0);
		}
	}

	public Boolean getCheckboxImpresion() {
		return checkboxImpresion;
	}

	public void setCheckboxImpresion(Boolean checkboxImpresion) {
		this.checkboxImpresion = checkboxImpresion;
		if(!this.checkboxImpresion) {
			pantalla.getPrivilegioImpresion().setNivel(0);
		}
	}
}
