package com.atosorigin.deri.seguridad.perfil.action;

import java.util.List;

import org.jboss.seam.ScopeType;
import org.jboss.seam.annotations.In;
import org.jboss.seam.annotations.Name;
import org.jboss.seam.annotations.Out;
import org.jboss.seam.annotations.Scope;

import com.atosorigin.common.action.PaginatedListAction;
import com.atosorigin.common.utils.GenericUtils;
import com.atosorigin.deri.model.seguridad.Pantalla;
import com.atosorigin.deri.model.seguridad.ProhibicionPerfil;
import com.atosorigin.deri.model.seguridad.ProhibicionPerfilId;
import com.atosorigin.deri.model.seguridad.Usuario;
import com.atosorigin.deri.seguridad.mantusuario.business.UsuarioBo;
import com.atosorigin.deri.seguridad.perfil.business.PerfilBo;
import com.atosorigin.deri.seguridad.perfil.screen.PerfilPantalla;



@Name("perfilAction")
@Scope(ScopeType.CONVERSATION)
public class PerfilAction extends PaginatedListAction{

	@In(create=true)
	private PerfilPantalla perfilPantalla;
	
	
	@In("#{perfilBo}")
	private PerfilBo perfilBo;
	
	@In("#{usuarioBo}")
	private UsuarioBo usuarioBo;
	
	@In(required=false)
	private Usuario usuarioSeleccionado;
	
	@In(required=false, scope=ScopeType.CONVERSATION)
	@Out(required=false)
	private Usuario usuarioPerfil;

	
	public void refrescarPantalla(){
		if(perfilPantalla.getPerfilSel() != null || perfilPantalla.getNumUsuarios() != null){
			
			cargaListas(perfilPantalla.getPerfilSel());
			perfilPantalla.setNumUsuarios(usuarioBo.numeroUsuariosPerfil(perfilPantalla.getPerfilSel()));
			
		}
	}
	public void preCargarPantallaUsuarios(){		
		//SMM Bug 
		//assert usuarioSeleccionado!=null:"el usuario seleccionado no puede ser nulo";
		/*
		 * SMM  Si es nulo el usuario seleccionado estaremos en Modo Alta de Usuario (perfil = 0)
		 * 		Sino será Modo Edición
		 */
		Integer perfil;
		if (GenericUtils.isNullOrBlank(usuarioSeleccionado) 
				|| GenericUtils.isNullOrBlank(usuarioSeleccionado.getPerfil())){
			perfil = 0;
		}else{
			perfil = usuarioSeleccionado.getPerfil();
		}		
		perfilPantalla.setPerfilSel(perfil);
		cargaListas(perfil);
		perfilPantalla.setNumUsuarios(usuarioBo.numeroUsuariosPerfil(0));
		refrescarPantalla();
		usuarioPerfil = usuarioSeleccionado;
	}
	public void preCargarPantalla(){
		cargaListas(0);
		perfilPantalla.setNumUsuarios(usuarioBo.numeroUsuariosPerfil(0));
	}
	
	public void cargaListas(Integer perfil){
		perfilPantalla.setListaPantallasPerm(perfilBo.buscarPermitidas(perfil, "P", paginationData));
		perfilPantalla.setListaInformesPerm(perfilBo.buscarPermitidas(perfil, "I", paginationData));
		perfilPantalla.setListaPantallasProhib(perfilBo.buscarNoPermitidas(Long.valueOf(perfil.toString()), "P", paginationData));
		perfilPantalla.setListaInformesProhib(perfilBo.buscarNoPermitidas(Long.valueOf(perfil.toString()), "I", paginationData));
		
		perfilPantalla.getListaPantallasPerm().addAll(perfilBo.buscarNoPermitidas(Long.valueOf(perfil.toString()), "P", paginationData));
		perfilPantalla.getListaInformesPerm().addAll(perfilBo.buscarNoPermitidas(Long.valueOf(perfil.toString()), "I", paginationData));
		
	}

	
	public PerfilPantalla getPerfilPantalla() {
		return perfilPantalla;
	}


	public void setPerfilPantalla(PerfilPantalla perfilPantalla) {
		this.perfilPantalla = perfilPantalla;
	}


	public PerfilBo getPerfilBo() {
		return perfilBo;
	}

	public void guardaPantallas(List<Pantalla> pantProAnteriores, List<Pantalla> pantsPro, boolean guardar){
		boolean existe;
		Pantalla pantProAnterior = null;
		Pantalla pantPro = null;
		ProhibicionPerfil proPer =null;
		ProhibicionPerfilId proPerId =null;
		for(int i = 0; i<pantProAnteriores.size(); i++){
			pantProAnterior = pantProAnteriores.get(i);
			existe = false;
			for(int j = 0 ; j<pantsPro.size(); j++){
				pantPro = pantsPro.get(j);
				if(pantProAnterior.getId().getCodigo().equals(pantPro.getId().getCodigo())
						&& pantProAnterior.getId().getProyecto().equals(pantPro.getId().getProyecto())
						&& pantProAnterior.getId().getTipoEjecutable().equals(pantPro.getId().getTipoEjecutable())){
					existe = true;
					break;
				}
			}
			if(!existe){
				proPer = new ProhibicionPerfil();
				proPerId = new ProhibicionPerfilId();
				proPerId.setPantalla(pantProAnterior);
				proPerId.setPerfil(perfilPantalla.getPerfilSel());
				proPer.setId(proPerId);
				
				if(!guardar){
					proPer = perfilBo.cargar(proPerId);
					if(proPer != null){
						perfilBo.borrar(proPer);
					}
				}else{
					perfilBo.guardar(proPer);
				}
			}
		}
	}

	public void guardar(){
		if(usuarioPerfil==null){
			List<Pantalla> pantProAnteriores = perfilBo.buscarNoPermitidas(Long.valueOf(perfilPantalla.getPerfilSel()), "P", paginationData);
			List<Pantalla> infoProAnteriores = perfilBo.buscarNoPermitidas(Long.valueOf(perfilPantalla.getPerfilSel()), "I", paginationData);
			
			
			guardaPantallas(pantProAnteriores, perfilPantalla.getListaPantallasProhib(), false);
			guardaPantallas(perfilPantalla.getListaPantallasProhib(), pantProAnteriores, true);
			
			guardaPantallas(infoProAnteriores, perfilPantalla.getListaInformesProhib(), false);
			guardaPantallas(perfilPantalla.getListaInformesProhib(), infoProAnteriores, true);
		}else{
			usuarioPerfil.setPerfil(perfilPantalla.getPerfilSel());
		}
		
	}

	public void setPerfilBo(PerfilBo perfilBo) {
		this.perfilBo = perfilBo;
	}
	@Override
	public List<?> getDataTableList() {
		return perfilPantalla.getListaUsuarios(); 
	}
	/**
	 *Creamos esté método para saber cuando se usa el botón Uusarios de la página de perfiles
	 *para en ese caso resetear previamente los datos de paginación. 
	 */
	public void refresh(){
		paginationData.reset();
		this.refrescarLista();
	}
	
	@Override
	protected void refreshListInternal() {
		setPrimerAcceso(false);
		List<Usuario> ql = (List<Usuario>)usuarioBo.usuariosPerfil(perfilPantalla.getPerfilSel(), paginationData);
		perfilPantalla.setListaUsuarios(ql);
			
	}
	@Override
	public void refrescarListaExcel() {
		// TODO Auto-generated method stub
		
	}
	@Override
	public void setDataTableList(List<?> dataTableList) {
		perfilPantalla.setListaUsuarios((List<Usuario>)dataTableList);
		
	}
	public UsuarioBo getUsuarioBo() {
		return usuarioBo;
	}
	public void setUsuarioBo(UsuarioBo usuarioBo) {
		this.usuarioBo = usuarioBo;
	}
	
}
