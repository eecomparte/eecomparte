package com.atosorigin.deri.seguridad.perfil.screen;

import java.util.ArrayList;
import java.util.List;

import org.jboss.seam.ScopeType;
import org.jboss.seam.annotations.Name;
import org.jboss.seam.annotations.Out;
import org.jboss.seam.annotations.Scope;
import org.jboss.seam.annotations.datamodel.DataModel;
import org.jboss.seam.annotations.datamodel.DataModelSelection;

import com.atosorigin.deri.model.seguridad.Pantalla;
import com.atosorigin.deri.model.seguridad.Usuario;


@Name("perfilPantalla")
@Scope(ScopeType.CONVERSATION)
public class PerfilPantalla {

	
	private Integer perfilSel;
	
	private Long numUsuarios;
	
	private List<Pantalla> listaPantallasPerm = new ArrayList<Pantalla>();
	
	private List<Pantalla> listaPantallasProhib = new ArrayList<Pantalla>();
	
	private List<Pantalla> listaInformesPerm = new ArrayList<Pantalla>();
	
	private List<Pantalla> listaInformesProhib = new ArrayList<Pantalla>();
	
	
	@DataModel(value="listaDtUsuariosPerfil")
	protected List<Usuario> listaUsuarios;
	
	@DataModelSelection(value="listaDtUsuariosPerfil")
	@Out(required=false)
	protected Usuario usuarioSeleccionado;
	
	
	public Integer getPerfilSel() {
		return perfilSel;
	}

	public void setPerfilSel(Integer perfilSel) {
		this.perfilSel = perfilSel;
	}
	
	public List<Pantalla> getListaPantallasPerm() {
		return listaPantallasPerm;
	}

	public void setListaPantallasPerm(List<Pantalla> listaPantallasPerm) {
		this.listaPantallasPerm = listaPantallasPerm;
	}

	public List<Pantalla> getListaPantallasProhib() {
		return listaPantallasProhib;
	}

	public void setListaPantallasProhib(List<Pantalla> listaPantallasProhib) {
		this.listaPantallasProhib = listaPantallasProhib;
	}

	public List<Pantalla> getListaInformesPerm() {
		return listaInformesPerm;
	}

	public void setListaInformesPerm(List<Pantalla> listaInformesPerm) {
		this.listaInformesPerm = listaInformesPerm;
	}

	public List<Pantalla> getListaInformesProhib() {
		return listaInformesProhib;
	}

	public void setListaInformesProhib(List<Pantalla> listaInformesProhib) {
		this.listaInformesProhib = listaInformesProhib;
	}

	public Long getNumUsuarios() {
		return numUsuarios;
	}

	public void setNumUsuarios(Long numUsuarios) {
		this.numUsuarios = numUsuarios;
	}

	public List<Usuario> getListaUsuarios() {
		return listaUsuarios;
	}

	public void setListaUsuarios(List<Usuario> listaUsuarios) {
		this.listaUsuarios = listaUsuarios;
	}

	public Usuario getUsuarioSeleccionado() {
		return usuarioSeleccionado;
	}

	public void setUsuarioSeleccionado(Usuario usuarioSeleccionado) {
		this.usuarioSeleccionado = usuarioSeleccionado;
	}
}
