package com.atosorigin.deri.swift.gestionswift.action;

import java.util.List;

import org.jboss.seam.ScopeType;
import org.jboss.seam.annotations.In;
import org.jboss.seam.annotations.Name;
import org.jboss.seam.annotations.Out;
import org.jboss.seam.annotations.Scope;

import com.atosorigin.common.action.ModoPantalla;
import com.atosorigin.common.action.PaginatedListAction;
import com.atosorigin.common.formvalidator.FormValidator;
import com.atosorigin.common.utils.GenericUtils;
import com.atosorigin.deri.model.contrapartida.Contrapartida;
import com.atosorigin.deri.model.swift.CamposSwift;
import com.atosorigin.deri.model.swift.CamposSwiftId;
import com.atosorigin.deri.model.swift.MensajeSwift;
import com.atosorigin.deri.swift.gestionswift.business.SwiftBo;
import com.atosorigin.deri.swift.gestionswift.screen.CamposSwiftPantalla;
import com.atosorigin.deri.util.MessageBoxAction;
import com.atosorigin.deri.util.MsgBoxAction;

/**
 * Clase que actúa de action listener para el caso de uso de gestion de swift.
 */
@Name("camposSwiftAction")
@Scope(ScopeType.CONVERSATION)
@FormValidator
public class CamposSwiftAction extends PaginatedListAction{

	/**
	 * Inyección del bean de Spring "swiftBo" que contiene los métodos de negocio
	 * para el caso de uso Gestion de Swift.
	 */
	@In("#{swiftBo}")
	protected SwiftBo swiftBo;
	
	/**
	 * Inyección del screen bean que contiene los datos de pantalla del caso de uso
	 * Gestion de Swift.
	 */
	@In(create=true)
	protected CamposSwiftPantalla camposSwiftPantalla;

	/** Mensaje swift  seleccionado en la pantalla de gestion de mensajes swift */
	@In(required=false,  value="mensajeSwiftSelect")
	protected MensajeSwift mensajeSwift;
	
	List<String> listaCampos; 
	
	private Boolean primeraEjecucionInit=null;
	
	@Out(required = false, value = "camposSwiftMessageBoxAction")
	private MessageBoxAction msgboxPanelCamposSwiftContrapaBloq;
	
	@In(create = true)
	private MsgBoxAction msgBoxAction;
	
	public MensajeSwift getMensajeSwift() {
		return mensajeSwift;
	}

	public void setMensajeSwift(MensajeSwift mensajeSwift) {
		this.mensajeSwift = mensajeSwift;
	}
	/**Campo swift  seleccionado en la pantalla de gestion de mensajes swift */
	

	/**
	 * Actualiza la lista del grid de tipos de documentos.
	 * 
	 */
	public void buscar() {
		paginationData.reset();
		refrescarLista();	
		setPrimerAcceso(false);
	}

	@Override
	public List<?> getDataTableList() {
		return camposSwiftPantalla.getCamposSwiftList();
	}

	@SuppressWarnings("unchecked")
	@Override
	protected void refreshListInternal() {
		this.setExportExcel(false);
		List<CamposSwift> ms =swiftBo.buscarCamposSwift(mensajeSwift, paginationData);
		camposSwiftPantalla.setCamposSwiftList(ms);
	}

	@Override
	public void refrescarListaExcel() {
		this.setExportExcel(true);
		List<CamposSwift> ms =swiftBo.buscarCamposSwift(mensajeSwift, paginationData.getPaginationDataForExcel());
		camposSwiftPantalla.setCamposSwiftList(ms);
	}

	@Override
	@SuppressWarnings("unchecked")
	public void setDataTableList(List<?> dataTableList) {
		camposSwiftPantalla.setCamposSwiftList((List<CamposSwift>)dataTableList);
		
	}
	public void editar(){
		camposSwiftPantalla.setCamposSwift(camposSwiftPantalla.getCamposSwiftSelect());
		setModoPantalla(ModoPantalla.EDICION);
	}
	
	public void ver(){
		camposSwiftPantalla.setCamposSwift(camposSwiftPantalla.getCamposSwiftSelect());
		setModoPantalla(ModoPantalla.INSPECCION);
	}
	public void nuevo(){
		CamposSwift camposSwift = new CamposSwift();
		CamposSwiftId camposSwiftId = new CamposSwiftId();

		camposSwift.setId(camposSwiftId);
		camposSwift.getId().setMensaje(mensajeSwift);
		
		camposSwiftPantalla.setCamposSwift(camposSwift);
		
		listaCampos = swiftBo.obtenerCamposSelect(mensajeSwift.getId().getNumeroMT());
		
		setModoPantalla(ModoPantalla.CREACION);
	}
	public String guardar(){
		if (modoPantalla.equals(ModoPantalla.CREACION)){			
			return crear();
		}else if (modoPantalla.equals(ModoPantalla.EDICION)){				
			return modificar();
		}
		return "";
	}
	/**
	 * Da de alta un campo swift
	 * 
	 * @return
	 */
	public String crear() {
		swiftBo.alta(camposSwiftPantalla.getCamposSwift());
		refrescarLista();
		return "success";
	}
	public String modificar() {
		swiftBo.alta(camposSwiftPantalla.getCamposSwift());		
		refrescarLista();
		return "success";
	}
	public void borrar() {
		swiftBo.borrar(camposSwiftPantalla.getCamposSwiftSelect());		
		refrescarLista();
		
	}

	public List<String> getListaCampos() {
		return listaCampos;
	}

	public void setListaCampos(List<String> listaCampos) {
		this.listaCampos = listaCampos;
	}

	public void initCamposSwift(){
		
		if(null==msgboxPanelCamposSwiftContrapaBloq) msgboxPanelCamposSwiftContrapaBloq = new MessageBoxAction();
		
		if (primeraEjecucionInit == null) {
			primeraEjecucionInit=true;
		} 
		else{
			primeraEjecucionInit = false;
		}
		
		if(primeraEjecucionInit && null!=camposSwiftPantalla.getCamposSwiftSelect() && null!=camposSwiftPantalla.getCamposSwiftSelect().getId() && null!=camposSwiftPantalla.getCamposSwiftSelect().getId().getMensaje() && null!=camposSwiftPantalla.getCamposSwiftSelect().getId().getMensaje().getbDDestino()){
			
			String idContrapartida = camposSwiftPantalla.getCamposSwiftSelect().getId().getMensaje().getbDDestino();
			if (!GenericUtils.isNullOrBlank(idContrapartida)){
				 Contrapartida contrapObtenida2 = swiftBo.cargarContrapartida(idContrapartida.toUpperCase());	
				if (null!=contrapObtenida2 && !GenericUtils.isNullOrBlank(contrapObtenida2.getIndBloqueo()) && "S".equalsIgnoreCase(contrapObtenida2.getIndBloqueo())){
					msgboxPanelCamposSwiftContrapaBloq.init("mensajeswift.messages.contrapartida.bloqueada.texto", "camposSwiftAction.voidFunction()", null, "messageBoxPanelContrapa");
				}
			}
		}
	}
	
	public void voidFunction(){
		msgBoxAction.voidFunction();
	}
}
