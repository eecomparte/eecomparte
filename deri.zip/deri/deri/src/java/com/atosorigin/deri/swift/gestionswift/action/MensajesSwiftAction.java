package com.atosorigin.deri.swift.gestionswift.action;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import javax.print.attribute.HashAttributeSet;

import org.jboss.seam.ScopeType;
import org.jboss.seam.annotations.In;
import org.jboss.seam.annotations.Name;
import org.jboss.seam.annotations.Out;
import org.jboss.seam.annotations.Scope;
import org.jboss.seam.annotations.datamodel.DataModel;
import org.jboss.seam.annotations.datamodel.DataModelSelection;
import org.jboss.seam.core.Conversation;
import org.jboss.seam.core.ResourceBundle;
import org.jboss.seam.international.StatusMessage.Severity;
import org.jboss.seam.security.Identity;

import com.atosorigin.common.action.ModoPantalla;
import com.atosorigin.common.action.PaginatedListAction;
import com.atosorigin.common.auditdata.AuditData;
import com.atosorigin.common.constantes.Constantes;
import com.atosorigin.common.formvalidator.FormValidator;
import com.atosorigin.common.utils.GenericUtils;
import com.atosorigin.deri.model.adminoper.GenericRange;
import com.atosorigin.deri.model.agenda.EventoAgenda;
import com.atosorigin.deri.model.gestionoperaciones.VistaOperacion;
import com.atosorigin.deri.model.swift.CamposSwift;
import com.atosorigin.deri.model.swift.CamposSwiftId;
import com.atosorigin.deri.model.swift.MensajeSwift;
import com.atosorigin.deri.model.swift.MensajeSwiftId;
import com.atosorigin.deri.swift.gestionswift.business.SwiftBo;
import com.atosorigin.deri.swift.gestionswift.screen.GestionSwiftFilterPantalla;
import com.atosorigin.deri.swift.gestionswift.screen.GestionSwiftPantalla;
import com.atosorigin.deri.util.ErrorMessage;
import com.atosorigin.deri.util.MsgBoxAction;
import com.atosorigin.deri.util.ErrorMessage.TypeError;

/**
 * Clase que actúa de action listener para el caso de uso de mantenimiento de tipos de documentos.
 */
@Name("mensajesSwiftAction")
@Scope(ScopeType.CONVERSATION)
@FormValidator
public class MensajesSwiftAction extends PaginatedListAction{

	/**
	 * Inyección del bean de Spring "swiftBo" que contiene los métodos de negocio
	 * para el caso de uso Gestion de Swift.
	 */
	@In("#{swiftBo}")
	protected SwiftBo swiftBo;
	
	/**
	 * Inyección del screen bean que contiene los datos de pantalla del caso de uso
	 * Gestion de Swift.
	 */
	@In(create=true)
	protected GestionSwiftPantalla gestionSwiftPantalla;
	protected GestionSwiftFilterPantalla gestionSwiftFilterPantalla;

	// INICIO Integración con Agenda

	@In(required=false)
	private EventoAgenda eventoSelectAgenda; 

	@In(required=false)
	private String modo; 

	private int maxSelected;
	private HashSet<MensajeSwift> listasSeleccionadas = new HashSet<MensajeSwift>();

	
	private Boolean masivo;
	
	@In(create = true)
	MsgBoxAction msgBoxAction;
	

	
	
	
	
	// FIN

	/**
	 * Actualiza la lista del grid de tipos de documentos.
	 * 
	 */
	public void buscar() {
		paginationData.reset();
		deSelectAll();
		refrescarLista();	
		setPrimerAcceso(false);
	}

	@Override
	public List<?> getDataTableList() {
		// TODO Auto-generated method stub
		return gestionSwiftPantalla.getMensajeSwiftList();
	}

	
	public void proyectoColat(){
		this.gestionSwiftPantalla.setProyecto(Constantes.NOMBRE_PROYECTO_COLAT);
	}

	public void proyectoDeri(){
		this.gestionSwiftPantalla.setProyecto(Constantes.NOMBRE_PROYECTO_DERI);
	}
	
	public void init() {

		if (GenericUtils.isNullOrBlank(this.gestionSwiftPantalla.getProyecto()) && primerAcceso){
			proyectoDeri();
		}
		if (Constantes.MODO_AGE.equals(modo) && primerAcceso) {
			paginationData.reset();
			refrescarLista();
		}
		//setPrimerAcceso(false);
	}
	/**
	 * parametors de busqueda
	 */
	Date fechaContratacion = null;
	Date fechaEnvio = null;
	String descripcionEstadoswift = Constantes.CADENA_VACIA;
	String tipoSwift =Constantes.CADENA_VACIA;
	Long nOperacion =null;
	
	@Override
	protected void refreshListInternal() {
		Date fechaContratacion = null;
		Date fechaEnvio = null;
		String descripcionEstadoswift = Constantes.CADENA_VACIA;
		String tipoSwift =Constantes.CADENA_VACIA;
		Long nOperacion =null;
		String projecte;
		
		if (Constantes.MODO_AGE.equals(modo)) {
			
			gestionSwiftPantalla.setDescripcionEstadosSwift(swiftBo.obtenerDescripcionEstadosSwift("PV"));
//			final MensajeSwift mSwift = new MensajeSwift();
//			mSwift.setId(new MensajeSwiftId());
//
//			// TODO Inicializar mSwift con los datos provinientes de Agenda
//			// Agenda inyecta además eventoSelectAgenda (+ info: eventoSelectAgenda.getCodigoEvento() )
//			
//			mSwift.setEstadoSwift(estadoSwift);
//			final List<MensajeSwift> ms = swiftBo.buscarMensajesSwiftAgenda(
//					mSwift, paginationData);
//
//			gestionSwiftPantalla.setMensajeSwiftList(ms);

//			return;
		}


		
		setExportExcel(false);
		
		/** Cargamos los valores seleccionados en los criterios de búsqueda para realizar la consulta*/
		if (!GenericUtils.isNullOrBlank(this.gestionSwiftPantalla.getFechaContratacion())){
			fechaContratacion = this.gestionSwiftPantalla.getFechaContratacion();
		}
		
		if (!GenericUtils.isNullOrBlank(this.gestionSwiftPantalla.getFechaEnvio())){
			fechaEnvio = this.gestionSwiftPantalla.getFechaEnvio();
		}

		if (!GenericUtils.isNullOrBlank(this.gestionSwiftPantalla.getDescripcionEstadosSwift()) && !GenericUtils.isNullOrBlank(descripcionEstadoswift = this.gestionSwiftPantalla.getDescripcionEstadosSwift().getCodigo())){
			descripcionEstadoswift = this.gestionSwiftPantalla.getDescripcionEstadosSwift().getCodigo();
		}
		if (!GenericUtils.isNullOrBlank(this.gestionSwiftPantalla.getMantenimientoMensajes()) && !GenericUtils.isNullOrBlank(tipoSwift = this.gestionSwiftPantalla.getMantenimientoMensajes().getDescripcion())){
			tipoSwift = this.gestionSwiftPantalla.getMantenimientoMensajes().getDescripcion();
		}
		
		if (!GenericUtils.isNullOrBlank(this.gestionSwiftPantalla.getOperacionid()) && !GenericUtils.isNullOrBlank(nOperacion = this.gestionSwiftPantalla.getOperacionid() )){
			nOperacion = this.gestionSwiftPantalla.getOperacionid();
		}
		
		if (GenericUtils.isNullOrBlank(this.gestionSwiftPantalla.getProyecto())){
			projecte = Constantes.NOMBRE_PROYECTO_DERI;
		}else{
			projecte =this.gestionSwiftPantalla.getProyecto();
		}
		
		/*
		MensajeSwift mensajeSwift = new MensajeSwift();
		MensajeSwiftId mensajeSwiftId = gestionSwiftPantalla.getMensajeSwiftId();
		mensajeSwift.setId(mensajeSwiftId);
		*/
		List<MensajeSwift> ms = swiftBo.buscarMensajesSwift(fechaContratacion,fechaEnvio,descripcionEstadoswift,tipoSwift, nOperacion, projecte, paginationData);
		
		gestionSwiftPantalla.setMensajeSwiftList(ms);
		
	}

	@Override
	public void refrescarListaExcel() {
		String projecte;
		setExportExcel(true);
		 List<MensajeSwift> list = gestionSwiftPantalla.getMensajeSwiftList();
			if(list==null){
				list = new ArrayList<MensajeSwift>();
				gestionSwiftPantalla.setMensajeSwiftList(list);
			}
			list.clear();
			if (!GenericUtils.isNullOrBlank(this.gestionSwiftPantalla.getFechaContratacion())){
				fechaContratacion = this.gestionSwiftPantalla.getFechaContratacion();
			}
			
			if (!GenericUtils.isNullOrBlank(this.gestionSwiftPantalla.getFechaEnvio())){
				fechaEnvio = this.gestionSwiftPantalla.getFechaEnvio();
			}

			if (!GenericUtils.isNullOrBlank(this.gestionSwiftPantalla.getDescripcionEstadosSwift()) && !GenericUtils.isNullOrBlank(descripcionEstadoswift = this.gestionSwiftPantalla.getDescripcionEstadosSwift().getCodigo())){
				descripcionEstadoswift = this.gestionSwiftPantalla.getDescripcionEstadosSwift().getCodigo();
			}
			if (!GenericUtils.isNullOrBlank(this.gestionSwiftPantalla.getMantenimientoMensajes()) && !GenericUtils.isNullOrBlank(tipoSwift = this.gestionSwiftPantalla.getMantenimientoMensajes().getDescripcion())){
				tipoSwift = this.gestionSwiftPantalla.getMantenimientoMensajes().getDescripcion();
			}
			
			if (!GenericUtils.isNullOrBlank(this.gestionSwiftPantalla.getOperacionid()) && !GenericUtils.isNullOrBlank(nOperacion = this.gestionSwiftPantalla.getOperacionid() )){
				nOperacion = this.gestionSwiftPantalla.getOperacionid();
			}
			
			if (GenericUtils.isNullOrBlank(this.gestionSwiftPantalla.getProyecto())){
				projecte = Constantes.NOMBRE_PROYECTO_DERI;
			}else{
				projecte =this.gestionSwiftPantalla.getProyecto();
			}
			
			list.addAll((List<MensajeSwift>)swiftBo
					.buscarMensajesSwift(fechaContratacion,
							fechaEnvio,
							descripcionEstadoswift,
							tipoSwift,
							nOperacion, 
							projecte,
							paginationData.getPaginationDataForExcel()));
		
	}

	@Override
	@SuppressWarnings("unchecked")
	public void setDataTableList(List<?> dataTableList) {
		gestionSwiftPantalla.setMensajeSwiftList((List<MensajeSwift>)dataTableList);
		
	}
	/** Prepara para entrar en el modo creación de un mensaje swift. */
	public void nuevo() {
		//gestionSwiftPantalla.setMensajeSwift();
		//.setDocContrapartida(new DocsContrapartida(new DocsContrapartidaId(new Contrapartida(), new TiposDocumento()),new TipoContrapartida(),null,null,null,new EstadoDocumentoContrapartida(),Constantes.CONSTANTE_NO,null,null,null,null,null));
		this.setModoPantalla(ModoPantalla.CREACION);
	}

	public void CambiarEstado(String nuevoEstado){
		if (getMasivo()){
			CambiarEstadoMasivo(nuevoEstado);
		}else{
			
		
		// El mensaje seleccionado en el action link
		MensajeSwift mSwift =   gestionSwiftPantalla.getMensajeSwift();
		
		String projecte;
		if (GenericUtils.isNullOrBlank(this.gestionSwiftPantalla.getProyecto())){
			projecte = Constantes.NOMBRE_PROYECTO_DERI;
		}else{
			projecte =this.gestionSwiftPantalla.getProyecto();
		}

		if ( ! swiftBo.verificarMt202(mSwift,projecte) ) {
			// Los 202 no se pueden autorizar ni desautorizar
			statusMessages.addToControl("erroractivacion", Severity.ERROR, "#{messages['gestionswift.error.mt202']");
		} else {

			if (Constantes.VALIDADO.equals(nuevoEstado) ){
				 swiftBo.autoriza(mSwift);
			} else {
				swiftBo.desautoriza(mSwift);		
			}
			 gestionSwiftPantalla.setMensajeSwift(mSwift);
			//refrescarLista();
		}
		
		}
	}
	
	
	public void CambiarEstadoMasivo(String nuevoEstado){
		int validados = 0;
		SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
		gestionSwiftPantalla.getListaErrores().clear();
		String projecte;
		if (GenericUtils.isNullOrBlank(this.gestionSwiftPantalla.getProyecto())){
			projecte = Constantes.NOMBRE_PROYECTO_DERI;
		}else{
			projecte =this.gestionSwiftPantalla.getProyecto();
		}
		for (MensajeSwift mSwift : listasSeleccionadas) {

			if ( ! swiftBo.verificarMt202(mSwift,projecte) ) {
				// Los 202 no se pueden autorizar ni desautorizar
				String mensaje = ResourceBundle.instance().getString("gestionswift.error.mt202");
				ErrorMessage error = new ErrorMessage(TypeError.ERROR, String.valueOf(mSwift.getId().getOperacion()), 
						sdf.format(mSwift.getId().getFechaContratacion()), mensaje);
				gestionSwiftPantalla.getListaErrores().add(error);
				
				
			} else if (mSwift.getEstadoSwift()!=null && "EN".equalsIgnoreCase(mSwift.getEstadoSwift().getCodigo())){
				//Error El Estado es incorrecto
				String mensaje = ResourceBundle.instance().getString("gestionswift.error.estadoEN");
				ErrorMessage error = new ErrorMessage(TypeError.ERROR, String.valueOf(mSwift.getId().getOperacion()), 
						sdf.format(mSwift.getId().getFechaContratacion()), mensaje);
				gestionSwiftPantalla.getListaErrores().add(error);
			} else {

				if (Constantes.VALIDADO.equals(nuevoEstado) ){
					 swiftBo.autoriza(mSwift);
					 validados++;
				} else {
					swiftBo.desautoriza(mSwift);
					validados++;
				}
			}

		}
		if (gestionSwiftPantalla.getListaErrores()!=null && gestionSwiftPantalla.getListaErrores().size() != 0){
//			msgBoxAction.setMostrarMensaje(true);
			msgBoxAction.mostrarMsg("#{mensajesSwiftAction.voidFunction()}", "#{mensajesSwiftAction.voidFunction()}", "");
			String mensaje = validados + " " + ResourceBundle.instance().getString("gestionswift.registros.autorizados");
			statusMessages.add(Severity.INFO, mensaje);			
		}else{
			msgBoxAction.noMostrarMensaje();
			String mensaje = validados + " " + ResourceBundle.instance().getString("gestionswift.registros.autorizados");
			statusMessages.add(Severity.INFO, mensaje);
			buscar();
		}
		
	
		
	}

	public void voidFunction(){
		msgBoxAction.noMostrarMensaje();
		gestionSwiftPantalla.getListaErrores().clear();
		deSelectAll();
		buscar();
	}
	
	
	public void salir(){
		Conversation conversacion = Conversation.instance();
		//Volvemos a la anterior conversación
		if(conversacion.isNested()){
			conversacion.redirectToParent();
		} else {
			redirectToURL("/home.seam");
			conversacion.endAndRedirect();
		}
	}

	public void borrar() {
		swiftBo.borrarMensajeSwift(gestionSwiftPantalla.getMensajeSwiftSelect());		
		refrescarLista();
		
	}
	
	public void anular(){
		MensajeSwift mensajeSwift = gestionSwiftPantalla.getMensajeSwiftSelect();
//		List<CamposSwift> msOld =swiftBo.buscarCamposSwift(mensajeSwift, paginationData);
		
		Date fechaMis = swiftBo.getFechaSistema();
		
		Long idMensa = swiftBo.obtenerNuevoContadorSwift(fechaMis,Constantes.CONCEPTO_CONTADOR_SWIFT);
		
		AuditData audit = new AuditData();
		
		audit.setFechaUltimaModi(fechaMis);
		audit.setUsuarioUltimaModi(Identity.instance().getCredentials().getUsername());
		
		MensajeSwiftId nuevoSwiftId =new MensajeSwiftId(fechaMis, mensajeSwift.getId().getProyecto(), mensajeSwift.getId().getFechaContratacion(), 
				mensajeSwift.getId().getOperacion(), mensajeSwift.getId().getNumeroMT(), idMensa);
		
		
//		MensajeSwift mensajeSwiftCancel = new MensajeSwift(nuevoSwiftId, mensajeSwift.getTipoOperacion() , swiftBo.obtenerDescripcionEstadosSwift("PV"));
		MensajeSwift mensajeSwiftCancel = new MensajeSwift(nuevoSwiftId, mensajeSwift.getTipoOperacion(), 
				swiftBo.obtenerDescripcionEstadosSwift("PV"), mensajeSwift.getEntidad(), mensajeSwift.getOficina(), 
				mensajeSwift.getbDDestino(), mensajeSwift.getMiReferncia(), mensajeSwift.getMiReferncia(), mensajeSwift.getCdIdioma(), 
				fechaMis, null, mensajeSwift.getFechaValoracion(), mensajeSwift.getCodigoLiquidacion(),
				mensajeSwift.getFechaLiquidacion(), null); 
			
		mensajeSwiftCancel.setAuditData(audit);	

		Set<CamposSwift> camposSwiftCancelSet = new HashSet<CamposSwift>();
		
		String campo20 =null;
		if ("305".equals(mensajeSwift.getId().getNumeroMT())){

			for (CamposSwift camposSwift : mensajeSwift.getCamposSwifts()) {
				if ("20".equals(camposSwift.getId().getNumeroCampo())){
					campo20 =  	camposSwift.getContenido();
					break;
				}
			}
			
		}
		
		for (CamposSwift camposSwift : mensajeSwift.getCamposSwifts()) {
			
			CamposSwiftId idCampos = new CamposSwiftId(mensajeSwiftCancel, camposSwift.getId().getSegmento(), 
					camposSwift.getId().getNumeroRepeticiones(), camposSwift.getId().getNumeroCampo());
		
			CamposSwift camposSwiftCancel = new CamposSwift(idCampos,camposSwift.getContenido(),camposSwift.getNumeroOrden());
			
			if ("305".equals(mensajeSwift.getId().getNumeroMT())){
				if ("21".equals(camposSwift.getId().getNumeroCampo()) && campo20!=null){
					camposSwiftCancel.setContenido(campo20);
				}
				
				if ("22".equals(camposSwift.getId().getNumeroCampo())){
					Integer i = camposSwift.getContenido().indexOf("/");
					if (i!=null && i!=0){
						camposSwiftCancel.setContenido("CANCEL" + camposSwift.getContenido().substring(i)); 	
					}
					
				}
			}

			if ("306".equals(mensajeSwift.getId().getNumeroMT())){
				if ("22A".equals(camposSwift.getId().getNumeroCampo())){
					camposSwiftCancel.setContenido("CANC");
				}
			}
			
			camposSwiftCancel.setAuditData(audit);
			camposSwiftCancelSet.add(camposSwiftCancel);
		}
		
		mensajeSwiftCancel.setCamposSwifts(camposSwiftCancelSet);
		swiftBo.guardarCabecera(mensajeSwiftCancel);
		swiftBo.guardarCampos(camposSwiftCancelSet);	
		swiftBo.flush(null);
		refrescarLista();
	
	}
	
	/** Prepara para entrar en el la pantalla de busqueda de campos swqift a 
	 * partir del mensaje swift selecccionado.
	 **/

	/**
	 * Prepara para entrar en el modo edición de un mensaje swift.
	 * 
	 */
	
	
	@Out
	public Boolean getSelectedRow() {
		if (gestionSwiftPantalla.getMensajeSwiftSelect()!= null && listasSeleccionadas != null) {
			return contains(gestionSwiftPantalla.getMensajeSwiftSelect());
		} else {
			return false;
		}
	}

	public void setSelectedRow(Boolean selected) {
		if (selected) {
			listasSeleccionadas.add((MensajeSwift) gestionSwiftPantalla.getMensajeSwiftSelect());
		} else {
			listasSeleccionadas.remove((MensajeSwift) gestionSwiftPantalla.getMensajeSwiftSelect());
		}
	}
	
	public boolean contains(MensajeSwift voSelected){
		boolean ret = false;
		for (MensajeSwift vo : listasSeleccionadas) {
			if(vo.equals(voSelected)){
				ret = true;
				break;
			}
		} 
		return ret; 
	}
	
	public void seleccionarLista(){ }

	public void selectAll() {
		
		int tmpMaxResults = paginationData.getMaxResults();
		int tmpFirstResult = paginationData.getFirstResult();
		paginationData.setMaxResults(501);
		paginationData.setFirstResult(0);
		
		List<MensajeSwift> mensajeList = recuperarTodos();
		int iteraciones = mensajeList.size();
		if(mensajeList.size() > 500){
			statusMessages.add(Severity.INFO, "#{messages['mantoper.seleccionados.primeros.cincuenta']}");
			iteraciones = 500;
			tmpFirstResult=0;
			maxSelected = 499;
		} else {
			maxSelected = mensajeList.size()-1;
		}
		listasSeleccionadas.clear(); 
		for(int i = 0; i<iteraciones; i++){
			listasSeleccionadas.add(mensajeList.get(i));
		}
		paginationData.setMaxResults(tmpMaxResults);
		paginationData.setFirstResult(tmpFirstResult);
		
	}

	public void deSelectAll() {
		listasSeleccionadas.clear();  //.removeAll(listaOperacionesList);
		maxSelected = 0;
	}

	
	
	protected List<MensajeSwift> recuperarTodos() {

		Date fechaContratacion = null;
		Date fechaEnvio = null;
		String descripcionEstadoswift = Constantes.CADENA_VACIA;
		String tipoSwift =Constantes.CADENA_VACIA;
		Long nOperacion =null;
		String projecte;
		
		if (Constantes.MODO_AGE.equals(modo)) {
			
			gestionSwiftPantalla.setDescripcionEstadosSwift(swiftBo.obtenerDescripcionEstadosSwift("PV"));
		}


		
		setExportExcel(false);
		
		/** Cargamos los valores seleccionados en los criterios de búsqueda para realizar la consulta*/
		if (!GenericUtils.isNullOrBlank(this.gestionSwiftPantalla.getFechaContratacion())){
			fechaContratacion = this.gestionSwiftPantalla.getFechaContratacion();
		}
		
		if (!GenericUtils.isNullOrBlank(this.gestionSwiftPantalla.getFechaEnvio())){
			fechaEnvio = this.gestionSwiftPantalla.getFechaEnvio();
		}

		if (!GenericUtils.isNullOrBlank(this.gestionSwiftPantalla.getDescripcionEstadosSwift()) && !GenericUtils.isNullOrBlank(descripcionEstadoswift = this.gestionSwiftPantalla.getDescripcionEstadosSwift().getCodigo())){
			descripcionEstadoswift = this.gestionSwiftPantalla.getDescripcionEstadosSwift().getCodigo();
		}
		if (!GenericUtils.isNullOrBlank(this.gestionSwiftPantalla.getMantenimientoMensajes()) && !GenericUtils.isNullOrBlank(tipoSwift = this.gestionSwiftPantalla.getMantenimientoMensajes().getDescripcion())){
			tipoSwift = this.gestionSwiftPantalla.getMantenimientoMensajes().getDescripcion();
		}
		
		if (!GenericUtils.isNullOrBlank(this.gestionSwiftPantalla.getOperacionid()) && !GenericUtils.isNullOrBlank(nOperacion = this.gestionSwiftPantalla.getOperacionid() )){
			nOperacion = this.gestionSwiftPantalla.getOperacionid();
		}
		
		if (GenericUtils.isNullOrBlank(this.gestionSwiftPantalla.getProyecto())){
			projecte = Constantes.NOMBRE_PROYECTO_DERI;
		}else{
			projecte =this.gestionSwiftPantalla.getProyecto();
		}

		List<MensajeSwift> ms = swiftBo.buscarMensajesSwift(fechaContratacion,fechaEnvio,descripcionEstadoswift,tipoSwift, nOperacion, projecte, paginationData);
		
		return ms;
		
	}

	public int getMaxSelected() {
		return maxSelected;
	}

	public void setMaxSelected(int maxSelected) {
		this.maxSelected = maxSelected;
	}

	public HashSet<MensajeSwift> getListasSeleccionadas() {
		return listasSeleccionadas;
	}

	public void setListasSeleccionadas(HashSet<MensajeSwift> listasSeleccionadas) {
		this.listasSeleccionadas = listasSeleccionadas;
	}

	public Boolean getMasivo() {
		return masivo;
	}

	public void setMasivo(Boolean masivo) {
		this.masivo = masivo;
	}	
	
	public MsgBoxAction getMsgBoxAction() {
		return msgBoxAction;
	}

	public void setMsgBoxAction(MsgBoxAction msgBoxAction) {
		this.msgBoxAction = msgBoxAction;
	}


	
}
