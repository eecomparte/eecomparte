package com.atosorigin.deri.swift.gestionswift.action;

import java.util.List;

import org.jboss.seam.ScopeType;
import org.jboss.seam.annotations.In;
import org.jboss.seam.annotations.Name;
import org.jboss.seam.annotations.Out;
import org.jboss.seam.annotations.Scope;

import com.atosorigin.common.action.PaginatedListAction;
import com.atosorigin.common.formvalidator.FormValidator;
import com.atosorigin.deri.swift.gestionswift.business.SwiftBo;
import com.atosorigin.deri.swift.gestionswift.screen.GestionSwiftFilterPantalla;
import com.atosorigin.deri.swift.gestionswift.screen.GestionSwiftPantalla;

/**
 * Clase que actúa de action listener para el caso de uso de mantenimiento de tipos de documentos.
 */
@Name("mensajesSwiftFilterAction")
@Scope(ScopeType.CONVERSATION)
@FormValidator
public class MensajesSwiftFilterAction extends PaginatedListAction{

	/**
	 * Inyección del bean de Spring "swiftBo" que contiene los métodos de negocio
	 * para el caso de uso Gestion de Swift.
	 */
	@In("#{swiftBo}")
	protected SwiftBo swiftBo;
	
	/**
	 * Inyección del screen bean que contiene los datos de pantalla del caso de uso
	 * Gestion de Swift.
	 */
	@In(create=true)
	protected GestionSwiftFilterPantalla gestionSwiftFilterPantalla;

	
	@In(value="proyectoMensajeSwift" , required = false, create=true)
	protected String proyectoMensajeSwift;
	
	/**
	 * Actualiza la lista del grid de tipos de documentos.
	 * 
	 */
	public void buscar() {
		paginationData.reset();
		refrescarLista();	
		setPrimerAcceso(false);
	}

	@Override
	public List<?> getDataTableList() {
		
		return gestionSwiftFilterPantalla.getMensajeSwiftList();
	}

	@Override
	protected void refreshListInternal() {
		List<Object[]> ms = (List<Object[]>)swiftBo.obtenerOperaciones(gestionSwiftFilterPantalla.getFechaContratacion(), proyectoMensajeSwift,paginationData);
		
		gestionSwiftFilterPantalla.setMensajeSwiftList(ms);
		
	}

	@Override
	public void refrescarListaExcel() {
		// TODO Auto-generated method stub
		
	}

	@Override
	@SuppressWarnings("unchecked")
	public void setDataTableList(List<?> dataTableList) {
		gestionSwiftFilterPantalla.setMensajeSwiftList((List<Object[]>)dataTableList);
		
	}
	
	public void seleccionarFiltroSwift(){
		gestionSwiftFilterPantalla.initSwiftFilter();
	}

	/**
	 * Prepara para entrar en el modo edición de un mensaje swift.
	 * 
	 */
	
	
}
