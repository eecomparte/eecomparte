package com.atosorigin.deri.swift.gestionswift.screen;

import java.util.List;

import org.jboss.seam.ScopeType;
import org.jboss.seam.annotations.Name;
import org.jboss.seam.annotations.Out;
import org.jboss.seam.annotations.Scope;
import org.jboss.seam.annotations.datamodel.DataModel;
import org.jboss.seam.annotations.datamodel.DataModelSelection;

import com.atosorigin.deri.model.swift.CamposSwift;


/**
 *  Contiene los datos de pantalla necesarios para el caso de uso gestion de swift
 */
@Name("camposSwiftPantalla")
@Scope(ScopeType.CONVERSATION)
public class CamposSwiftPantalla {


	
	
	
	/** operacionid. Criterio de búsqueda de mensajes swift   */

	/** Lista de datos para el grid. */
	@DataModel(value ="listaCamposSwift")
	protected List<CamposSwift> camposSwiftList;
		
	public List<CamposSwift> getCamposSwiftList() {
		return camposSwiftList;
	}

	public void setCamposSwiftList(List<CamposSwift> camposSwiftList) {
		this.camposSwiftList = camposSwiftList;
	}

	/** Campos Swift seleccionado en el grid */
	@DataModelSelection(value ="listaCamposSwift")
    @Out(required=false)
    protected CamposSwift camposSwiftSelect;
   
	@Out(required=false)
	protected CamposSwift camposSwift;
	
	
	public CamposSwift getCamposSwiftSelect() {
		return camposSwiftSelect;
	}

	public void setCamposSwiftSelect(CamposSwift camposSwiftSelect) {
		this.camposSwiftSelect = camposSwiftSelect;
	}

	public CamposSwift getCamposSwift() {
		return camposSwift;
	}

	public void setCamposSwift(CamposSwift camposSwift) {
		this.camposSwift = camposSwift;
	}

	
	
}
