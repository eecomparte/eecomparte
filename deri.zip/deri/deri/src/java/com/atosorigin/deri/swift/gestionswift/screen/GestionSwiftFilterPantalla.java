package com.atosorigin.deri.swift.gestionswift.screen;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.jboss.seam.ScopeType;
import org.jboss.seam.annotations.Name;
import org.jboss.seam.annotations.Out;
import org.jboss.seam.annotations.Scope;
import org.jboss.seam.annotations.datamodel.DataModel;
import org.jboss.seam.annotations.datamodel.DataModelSelection;

import com.atosorigin.deri.model.swift.MensajeSwiftId;
import com.atosorigin.deri.util.ErrorMessage;


/**
 *  Contiene los datos de pantalla necesarios para el caso de uso mantenimiento de tipos de documentos
 */
@Name("gestionSwiftFilterPantalla")
@Scope(ScopeType.CONVERSATION)
public class GestionSwiftFilterPantalla {


	
	@Out(required=false)
	MensajeSwiftId mensajeSwiftId;
	GestionSwiftPantalla gestionSwiftPantalla;
	
	/** operacionid. Criterio de búsqueda de mensajes swift   */

	/** Lista de datos para el grid. */
	@DataModel(value ="listaMensajesFilterSwift")
	protected List<Object[]> mensajeSwiftList;
	
	
	/** Mensaje Swift seleccionado en el grid */
	@DataModelSelection(value ="listaMensajesFilterSwift")
    @Out(required=false)
    private Object[] mensajeSwiftOperacionAndDateFilter;
    
	
	private Date fechaContratacion;
	
    public Date getFechaContratacion() {
		return fechaContratacion;
	}

	public void setFechaContratacion(Date fechaContratacion) {
		this.fechaContratacion = fechaContratacion;
	}

	public Object[] getMensajeSwiftOperacionAndDateFilter() {
		return mensajeSwiftOperacionAndDateFilter;
	}

	public void setMensajeSwiftOperacionAndDateFilter(
			Object[] mensajeSwiftOperacionAndDateFilter) {
		this.mensajeSwiftOperacionAndDateFilter = mensajeSwiftOperacionAndDateFilter;
		initSwiftFilter();
	}

	public void initSwiftFilter() {
		Date fechaContratacion = getFechaContratacionFilter(mensajeSwiftOperacionAndDateFilter);
		Long operacionid = getOperacionIdFilter(mensajeSwiftOperacionAndDateFilter);
		
		mensajeSwiftId = new MensajeSwiftId();
		mensajeSwiftId.setFechaContratacion(fechaContratacion);
		mensajeSwiftId.setOperacion(operacionid);
		
		//gestionSwiftPantalla.setFechaContratacion(fechaContratacion);
		
	}

	private Long getOperacionIdFilter(
			Object[] mensajeSwiftOperacionAndDateFilter) {
		return (Long) mensajeSwiftOperacionAndDateFilter[1];
	}

	private Date getFechaContratacionFilter(
			Object[] mensajeSwiftOperacionAndDateFilter) {
		return (Date) mensajeSwiftOperacionAndDateFilter[0];
	}


	public List<Object[]> getMensajeSwiftList() {
		return mensajeSwiftList;
	}

	public void setMensajeSwiftList(List<Object[]> mensajeSwiftList) {
		this.mensajeSwiftList = mensajeSwiftList;
	}

	
}
