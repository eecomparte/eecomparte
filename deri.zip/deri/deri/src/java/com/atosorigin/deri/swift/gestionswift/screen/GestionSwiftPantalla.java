package com.atosorigin.deri.swift.gestionswift.screen;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.jboss.seam.ScopeType;
import org.jboss.seam.annotations.Create;
import org.jboss.seam.annotations.In;
import org.jboss.seam.annotations.Name;
import org.jboss.seam.annotations.Out;
import org.jboss.seam.annotations.Scope;
import org.jboss.seam.annotations.datamodel.DataModel;
import org.jboss.seam.annotations.datamodel.DataModelSelection;

import com.atosorigin.deri.model.swift.DescripcionEstadosSwift;
import com.atosorigin.deri.model.swift.MantenimientoMensajes;
import com.atosorigin.deri.model.swift.MensajeSwift;
import com.atosorigin.deri.model.swift.MensajeSwiftId;
import com.atosorigin.deri.util.ErrorMessage;


/**
 *  Contiene los datos de pantalla necesarios para el caso de uso mantenimiento de tipos de documentos
 */
@Name("gestionSwiftPantalla")
@Scope(ScopeType.CONVERSATION)
public class GestionSwiftPantalla {
	
	@Out(value="proyectoMensajeSwift" , required=false)
	private String proyecto;
	
	/** Criterios de búsqueda */
	protected DescripcionEstadosSwift descripcionEstadosSwift;
	protected MantenimientoMensajes mantenimientoMensajes;
	
	
	public MantenimientoMensajes getMantenimientoMensajes() {
		return mantenimientoMensajes;
	}

	public void setMantenimientoMensajes(MantenimientoMensajes mantenimientoMensajes) {
		this.mantenimientoMensajes = mantenimientoMensajes;
	}

	/** operacionid. Criterio de búsqueda de mensajes swift   */
	protected Long operacionid;
	public Long getOperacionid() {
		return operacionid;
	}

	public void setOperacionid(Long operacionid) {
		this.operacionid = operacionid;
	}

	protected Date fechaContratacion;	
	
	public Date getFechaContratacion() {
		return fechaContratacion;
	}

	public void setFechaContratacion(Date fechaContratacion) {
		this.fechaContratacion = fechaContratacion;
	}

	/**  Criterio de búsqueda de mensajes swift   */
	protected Date fechaEnvio;	
	
	public Date getFechaEnvio() {
		return fechaEnvio;
	}

	public void setFechaEnvio(Date fechaEnvio) {
		this.fechaEnvio = fechaEnvio;
	}
	/*
	protected String estadoSwift;

	public String getEstadoSwift() {
		return estadoSwift;
	}
	
	

	public void setEstadoSwift(String estadoSwift) {
		this.estadoSwift = estadoSwift;
	}
	*/
	protected String tipoSwift;

	public String getTipoSwift() {
		return tipoSwift;
	}

	public void setTipoSwift(String tipoSwift) {
		this.tipoSwift = tipoSwift;
	}

	/** Lista de datos para el grid. */
	@DataModel(value ="listaMensajesSwift")
	protected List<MensajeSwift> mensajeSwiftList;
	
	
	/** Mensaje Swift seleccionado en el grid */
	@DataModelSelection(value ="listaMensajesSwift")
    @Out(value="mensajeSwiftSelect" , required=false)
	protected MensajeSwift mensajeSwiftSelect;

	@Out(value="mensajeSwift", required=false)
	protected MensajeSwift mensajeSwift;
	
	@DataModel(value = "listaErrores")
//	@Out(value = "mensajesSwift.listaErrores", required=false)
	private List<ErrorMessage> listaErrores = new ArrayList<ErrorMessage>();	
	
	
	public MensajeSwift getMensajeSwift() {
		return mensajeSwift;
	}

	public void setMensajeSwift(MensajeSwift mensajeSwift) {
		this.mensajeSwift = mensajeSwift;
	}

	@In(required=false)
	protected MensajeSwiftId mensajeSwiftId;
	
	
	@In(required=false)
	@Out(required=false)
    protected MensajeSwift mensajeSwiftFilter;

	
	
	@Create
	public void initialize(){
		mensajeSwiftFilter=new MensajeSwift();
		MensajeSwiftId mensajeSwiftId = new MensajeSwiftId();
		mensajeSwiftFilter.setId(mensajeSwiftId);
	}
	
	public MensajeSwift getMensajeSwiftFilter() {
		return mensajeSwiftFilter;
	}

	public void setMensajeSwiftFilter(MensajeSwift mensajeSwiftFilter) {
		this.mensajeSwiftFilter = mensajeSwiftFilter;
	}

	public DescripcionEstadosSwift getDescripcionEstadosSwift() {
		return descripcionEstadosSwift;
	}

	public void setDescripcionEstadosSwift(
			DescripcionEstadosSwift descripcionEstadosSwift) {
		this.descripcionEstadosSwift = descripcionEstadosSwift;
	}

	public List<MensajeSwift> getMensajeSwiftList() {
		return mensajeSwiftList;
	}

	public void setMensajeSwiftList(List<MensajeSwift> mensajeSwiftList) {
		this.mensajeSwiftList = mensajeSwiftList;
	}

	public MensajeSwift getMensajeSwiftSelect() {
		return mensajeSwiftSelect;
	}
	
	public void setMensajeSwiftSelect(MensajeSwift mensajeSwiftSelect) {
		this.mensajeSwiftSelect = mensajeSwiftSelect;
	}
	public MensajeSwiftId getMensajeSwiftId() {
		return mensajeSwiftId;
	}
	
	public void setMensajeSwiftId(MensajeSwiftId mensajeSwiftId) {
		this.mensajeSwiftId = mensajeSwiftId;
	}
	
	public List<ErrorMessage> getListaErrores() {
		return listaErrores;
	}

	public void setListaErrores(List<ErrorMessage> listaErrores) {
		this.listaErrores = listaErrores;
	}

	public String getProyecto() {
		return proyecto;
	}

	public void setProyecto(String proyecto) {
		this.proyecto = proyecto;
	}

	
	
}
