package com.atosorigin.deri.util;

import java.io.FileInputStream;
import java.io.InputStream;
import java.net.URL;
import java.util.Map.Entry;
import java.util.Properties;
import java.util.Set;

import org.apache.commons.beanutils.BeanUtilsBean;
import org.jboss.seam.annotations.Name;


public class AutoConfigure {

	public static void configure(Object component) {
		Properties props = new Properties();
		try {
			
			InputStream is = AutoConfigure.class.getResourceAsStream("/CASFILTER.properties");
			props.load(is);
			is.close();
			Name name = component.getClass().getAnnotation(Name.class);
			if (name == null) {
				return;
			}
			String pref = name.value();
			
			Set<Entry<Object, Object>> propiedades = props.entrySet();
			for (Entry<Object, Object> propiedad : propiedades) {
				if (!propiedad.getKey().toString().startsWith(pref)) {
					continue;
				}
				
				String propName = propiedad.getKey().toString();
				String propVal = propiedad.getValue().toString();
				
				BeanUtilsBean.getInstance().setProperty(component, propName.replace(pref + ".", ""), propVal);
				
			}
			
			
		} catch (Exception e) {
			throw new RuntimeException("Excepcion configurando componente", e);
		}
	}
	
}
