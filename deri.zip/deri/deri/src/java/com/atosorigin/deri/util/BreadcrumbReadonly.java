package com.atosorigin.deri.util;

import java.util.List;

import org.jboss.seam.ScopeType;
import org.jboss.seam.annotations.Name;
import org.jboss.seam.annotations.Scope;
import org.jboss.seam.core.ConversationEntry;
import org.jboss.seam.core.Manager;

import com.atosorigin.common.action.GenericAction;


@Name("breadcrumbReadonly")
@Scope(ScopeType.CONVERSATION)
public class BreadcrumbReadonly extends GenericAction  {
	public Boolean isBreadcrumbEnabled(ConversationEntry entry){
//FLM: Da igual consulta que no ,BoletasStates boletaState		
//		if(boletaState==null || BoletasStates.CONSULTA_BOLETA==boletaState){
//			return false;
//		}
		List<String> currentConversationIdStack = Manager.instance().getCurrentConversationIdStack();
		if(currentConversationIdStack.size()>1){
			String lastId = currentConversationIdStack.get(0);
			if(entry.getId().equals(lastId)){
				return false;
			}
		}
		return true;
	}
}
