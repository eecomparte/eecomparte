package com.atosorigin.deri.util;

import javax.servlet.FilterConfig;
import javax.servlet.ServletException;

import org.jboss.seam.ScopeType;
import org.jboss.seam.annotations.Create;
import org.jboss.seam.annotations.Name;
import org.jboss.seam.annotations.Scope;
import org.jboss.seam.annotations.Startup;
import org.jboss.seam.annotations.intercept.BypassInterceptors;
import org.jboss.seam.annotations.web.Filter;
@Startup
@Scope(ScopeType.APPLICATION)
@Name("deri.authenticationFilter")
@BypassInterceptors
@Filter(within={"deri.proxyValidationFilter"})

public class ConfigurableCasFilter extends org.jasig.cas.client.authentication.AuthenticationFilter {
	
	private String appId;
	private String disabled="false";

	public String getDisabled() {
		return disabled;
	}

	public void setDisabled(String disabled) {
		this.disabled = disabled;
	}

	//Variables de la clase que inicia el seam desde el archivo de propiedades
	private String casServerLoginUrlFilter;
	private String serverNameFilter;
	
	@Create
	public void create() {
		AutoConfigure.configure(this);
	}
	
	@Override
	public void init() {
		if(!"true".equals(disabled)){
			//Especificamos el CasServerLoginUrl y serverName para la inicialización del filtro
			super.setCasServerLoginUrl(casServerLoginUrlFilter);
			super.setServerName(serverNameFilter);

			super.init();
		}		

	}

	@Override
	protected void initInternal(FilterConfig arg0) throws ServletException {
		//Continuamos con la inicialización del CAS
		super.initInternal(arg0);
	}

	public String getCasServerLoginUrlFilter() {
		return casServerLoginUrlFilter;
	}

	public void setCasServerLoginUrlFilter(String casServerLoginUrlFilter) {
		this.casServerLoginUrlFilter = casServerLoginUrlFilter;
	}

	public String getServerNameFilter() {
		return serverNameFilter;
	}

	public void setServerNameFilter(String serverNameFilter) {
		this.serverNameFilter = serverNameFilter;
	}
}
