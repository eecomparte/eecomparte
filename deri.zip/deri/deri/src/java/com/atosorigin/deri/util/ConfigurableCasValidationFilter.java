package com.atosorigin.deri.util;

import java.util.HashMap;

import javax.servlet.FilterConfig;
import javax.servlet.ServletException;

import org.jboss.seam.ScopeType;
import org.jboss.seam.annotations.Create;
import org.jboss.seam.annotations.Name;
import org.jboss.seam.annotations.Scope;
import org.jboss.seam.annotations.Startup;
import org.jboss.seam.annotations.intercept.BypassInterceptors;
import org.jboss.seam.annotations.intercept.PostConstruct;
import org.jboss.seam.annotations.web.Filter;
import org.jboss.seam.web.FilterConfigWrapper;
@Startup
@Scope(ScopeType.APPLICATION)
@Name("deri.proxyValidationFilter")
@BypassInterceptors
@Filter(within = { "org.jboss.seam.web.rewriteFilter" })
public class ConfigurableCasValidationFilter extends org.jasig.cas.client.validation.Cas20ProxyReceivingTicketValidationFilter {
	
	private String appId;
	private String disabled="false";

	//Variables de la clase que inicia el seam desde el archivo de propiedades
	private String serverNameFilter;
	private String casServerUrlPrefixFilter; //Este parametro es necesario que se encuentre en el initParams del FilterConfig
	private String proxyReceptorUrlFilter;
	private String proxyCallbackUrlFilter;
	private String proxyGrantingTicketStorageClassFilter;
	
	public String getProxyReceptorUrlFilter() {
		return proxyReceptorUrlFilter;
	}

	public void setProxyReceptorUrlFilter(String proxyReceptorUrlFilter) {
		this.proxyReceptorUrlFilter = proxyReceptorUrlFilter;
	}

	public String getProxyCallbackUrlFilter() {
		return proxyCallbackUrlFilter;
	}

	public void setProxyCallbackUrlFilter(String proxyCallbackUrlFilter) {
		this.proxyCallbackUrlFilter = proxyCallbackUrlFilter;
	}

	public String getProxyGrantingTicketStorageClassFilter() {
		return proxyGrantingTicketStorageClassFilter;
	}

	public void setProxyGrantingTicketStorageClassFilter(
			String proxyGrantingTicketStorageClassFilter) {
		this.proxyGrantingTicketStorageClassFilter = proxyGrantingTicketStorageClassFilter;
	}

	@Override
	public void init() {
		//if(!"true".equals(disabled)){
			//Especificamos el serverName para la inicialización del filtro
			super.setServerName(serverNameFilter);
			super.init();
		//}
	}
	
	@Create
	public void create() {
		AutoConfigure.configure(this);
	}
	
	@Override
	protected void initInternal(FilterConfig arg0) throws ServletException {
		
		
		
		
		if(!"true".equals(disabled)){
			//FilterConfig es de sólo lectura, utilizamos un wrapper para poder introducir nuevos parámetros iniciales de configuración.
			//Introducimos el parametro necesario para la inicialización del TickerValidator	
			HashMap<String, String> params = new HashMap<String, String>();
			params.put("casServerUrlPrefix", casServerUrlPrefixFilter);
			params.put("serverName",serverNameFilter);
			params.put("proxyReceptorUrl",proxyReceptorUrlFilter);
			params.put("proxyCallbackUrl",proxyCallbackUrlFilter);
			params.put("proxyGrantingTicketStorageClass",proxyGrantingTicketStorageClassFilter);

			//Wrapper del filterConfig original para poder gestionar los parametros iniciales del CAS
			FilterConfigWrapper fwc = new FilterConfigWrapper(arg0, params);
			
			//Continuamos con la inicialización del CAS
			super.initInternal(fwc);
		}
	}
	
	public String getCasServerUrlPrefixFilter() {
		return casServerUrlPrefixFilter;
	}
	
	public void setCasServerUrlPrefixFilter(String casServerUrlPrefixFilter) {
		this.casServerUrlPrefixFilter = casServerUrlPrefixFilter;
	}
	
	public String getServerNameFilter() {
		return serverNameFilter;
	}
	
	public void setServerNameFilter(String serverNameFilter) {
		this.serverNameFilter = serverNameFilter;
	}
}
