package com.atosorigin.deri.util;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;

import org.jboss.seam.ScopeType;
import org.jboss.seam.annotations.Name;
import org.jboss.seam.annotations.Scope;
import org.jboss.seam.annotations.Startup;
import org.jboss.seam.annotations.intercept.BypassInterceptors;
import org.jboss.seam.annotations.web.Filter;
import org.jboss.seam.web.FilterConfigWrapper;

import com.planetj.servlet.filter.compression.CompressingFilter;
@Startup
@Scope(ScopeType.APPLICATION)
@Name("deri.gzipFilter")
@BypassInterceptors
@Filter(within="org.jboss.seam.servlet.SeamFilter")
public class ConfigurableGzipFilter extends CompressingFilter{
	

private String disabled;

@Override
public void init(FilterConfig config) throws ServletException {
    if(!"true".equals(disabled)){
		Map<String, String> parameters = new HashMap<String, String>();
		parameters.put("filterClass", super.getClass().getName());
		parameters.put("name", "GZIP Filter");
		super.init(new FilterConfigWrapper(config, parameters ));
    }
}

@Override
public void doFilter(ServletRequest request, ServletResponse response,
		FilterChain fc) throws ServletException, IOException {
	boolean matches = false;
	if(request instanceof HttpServletRequest){
		HttpServletRequest httpServletRequest = (HttpServletRequest) request;
		matches = httpServletRequest.getRequestURI().matches(".*\\.seam.*");
	}
    if(!"true".equals(disabled) && matches){
    	super.doFilter(request, response, fc);
    }
    else{
    	fc.doFilter(request, response);
    }
}

public String getDisabled() {
	return disabled;
}

public void setDisabled(String disabled) {
	this.disabled = disabled;
}

}
