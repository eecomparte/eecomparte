package com.atosorigin.deri.util;

public class ConfiguracionDeri {
	private String entorno;
	private String version;
	private String versionColat;
	private String pdfs;
	private String texts;
	private String pdfedition;
	private String viewpdf;
	private String viewwspdf;
	private String userId;
	private String pathForms;
	private String pathEjecutable;
	private String execMode;
	private String dirListados;
	private String pdfSubstitutionFont;
	private String tablaProfit;
	private String webProfit;
	private String color;
	
	public String getPdfSubstitutionFont() {
		return pdfSubstitutionFont;
	}

	public void setPdfSubstitutionFont(String pdfSubstitutionFont) {
		this.pdfSubstitutionFont = pdfSubstitutionFont;
	}

	public String getPdfs() {
		return pdfs;
	}
	
	public void setPdfs(String pdfs) {
		this.pdfs = pdfs;
	}
	
	public String getTexts() {
		return texts;
	}
	
	public void setTexts(String texts) {
		this.texts = texts;
	}
	public String getVersion() {
		return version;
	}
	
	public void setVersion(String version) {
		this.version = version;
	}
	public String getVersionColat() {
		return versionColat;
	}
	
	public void setVersionColat(String versionColat) {
		this.versionColat = versionColat;
	}	
	public String getEntorno() {
		return entorno;
	}
	
	public void setEntorno(String entorno) {
		this.entorno = entorno;
	}
	
	public String getPdfedition() {
		return pdfedition;
	}
	
	public void setPdfedition(String pdfedition) {
		this.pdfedition = pdfedition;
	}

	public String getViewpdf() {
		return viewpdf;
	}

	public void setViewpdf(String viewpdf) {
		this.viewpdf = viewpdf;
	}

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public String getPathForms() {
		return pathForms;
	}

	public void setPathForms(String pathForms) {
		this.pathForms = pathForms;
	}

	public String getPathEjecutable() {
		return pathEjecutable;
	}

	public void setPathEjecutable(String pathEjecutable) {
		this.pathEjecutable = pathEjecutable;
	}

	public String getExecMode() {
		return execMode;
	}

	public void setExecMode(String execMode) {
		this.execMode = execMode;
	}

	public String getDirListados() {
		return dirListados;
	}

	public void setDirListados(String dirListados) {
		this.dirListados = dirListados;
	}

	public String getViewwspdf() {
		return viewwspdf;
	}

	public void setViewwspdf(String viewwspdf) {
		this.viewwspdf = viewwspdf;
	}

	public String getTablaProfit() {
		return tablaProfit;
	}

	public void setTablaProfit(String tablaProfit) {
		this.tablaProfit = tablaProfit;
	}

	public String getWebProfit() {
		return webProfit;
	}

	public void setWebProfit(String webProfit) {
		this.webProfit = webProfit;
	}

	public String getColor() {
		return color;
	}

	public void setColor(String color) {
		this.color = color;
	}
}
