package com.atosorigin.deri.util;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceException;

import org.jboss.seam.ScopeType;
import org.jboss.seam.annotations.AutoCreate;
import org.jboss.seam.annotations.In;
import org.jboss.seam.annotations.Name;
import org.jboss.seam.annotations.Scope;

import com.atosorigin.deri.model.contrapartida.AbstractContrapartida;
import com.atosorigin.deri.model.contrapartida.Contrapartida;
import com.atosorigin.deri.model.contrapartida.ContrapartidaLookup;
import com.atosorigin.deri.model.contrapartida.UnidadNegocioContrapa;

@Name("contrapartidaUtil")
@Scope(ScopeType.CONVERSATION)
@AutoCreate
public class ContrapartidaUtil {

	@In(value = "EntityUtil", create = true)
	private EntityUtil entityUtil;
	@In
	private EntityManager entityManager;
	
	
	//FLM: Para que no falle en PRE, da problemas con el dblink y las union
	public AbstractContrapartida find(String id){
		AbstractContrapartida result=null;
		try {
			result=entityManager.find(Contrapartida.class, id);
			if (result==null)
				result=entityManager.find(ContrapartidaLookup.class, id);
			if (result==null)
				return entityManager.find(UnidadNegocioContrapa.class, id);
			else 
				return result;
		} catch (PersistenceException e) {
			try {
				result=entityManager.find(ContrapartidaLookup.class, id);
				if (result==null)
					return entityManager.find(UnidadNegocioContrapa.class, id);
				else 
					return result;
				
			} catch (PersistenceException e1) {
				try {
					return entityManager.find(UnidadNegocioContrapa.class, id);
				} catch (PersistenceException e2) {
					return null;				
				}
			}			
		}
	}
	
	
	public boolean isInstanceOfContrapartida(AbstractContrapartida abstractContrapartida){
		if(!entityUtil.checkEntityExists(abstractContrapartida)){
			return false;
		}
		AbstractContrapartida tmp = entityUtil.unwrapProxy(abstractContrapartida, AbstractContrapartida.class);
		if(tmp==null){
			return false;
		}
		return tmp instanceof Contrapartida;
	}
	public Contrapartida castAsContrapartida(AbstractContrapartida abstractContrapartida){
		if(!isInstanceOfContrapartida(abstractContrapartida)){
			throw new ClassCastException();
		}
		return (Contrapartida) entityUtil.unwrapProxy(abstractContrapartida, AbstractContrapartida.class);
		
	}
}
