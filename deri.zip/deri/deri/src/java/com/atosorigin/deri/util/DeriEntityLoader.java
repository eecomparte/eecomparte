package com.atosorigin.deri.util;

import javax.persistence.EntityManager;

import org.jboss.seam.ScopeType;
import org.jboss.seam.annotations.Name;
import org.jboss.seam.annotations.Scope;
import org.jboss.seam.framework.EntityIdentifier;
import org.jboss.seam.framework.Identifier;
import org.jboss.seam.ui.JpaEntityLoader;

@Name("org.jboss.seam.ui.entityLoader")
@Scope(ScopeType.APPLICATION)
public class DeriEntityLoader extends JpaEntityLoader {
	public static class CustomEntityIdentifier extends EntityIdentifier {

		public CustomEntityIdentifier(Object entity, EntityManager entityManager) {
			super(entity, entityManager);
		}

		@Override
		public Object find(EntityManager entityManager) {
			Object result = super.find(entityManager);


			return EntityUtil.unwrapProxy(entityManager, result, Object.class);
		}
	}

	@Override
	protected Identifier createIdentifier(Object entity) {
		return new CustomEntityIdentifier(entity, getPersistenceContext());
	}
}

