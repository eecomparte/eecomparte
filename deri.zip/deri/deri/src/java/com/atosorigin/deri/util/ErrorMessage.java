package com.atosorigin.deri.util;

import com.atosorigin.deri.model.gestionoperaciones.HistoricoOperacion;

public class ErrorMessage implements java.io.Serializable {
	
	public enum TypeError {WARNING("WARNING",new Integer(0)), ERROR("ERROR",new Integer(1));
	private String literal;
	private Integer sortNumber;
	private TypeError(String literal, Integer sortNumber) {
		this.literal = literal;
		this.sortNumber = sortNumber;
	}
	public String getLiteral() {
		return literal;
	}
	public void setLiteral(String literal) {
		this.literal = literal;
	}
	public Integer getSortNumber() {
		return sortNumber;
	}
	public void setSortNumber(Integer sortNumber) {
		this.sortNumber = sortNumber;
	}
	
}	
	
	private static final long serialVersionUID = -5095328306281662363L;
	private TypeError typeError;
	private String nCorrela;
	private String fechaOpe;
	private String message;
	private HistoricoOperacion ho;
	private String typeErrorStr;
	
	public ErrorMessage(){
		super();
	}
	
	public ErrorMessage(String nCorrela, String fechaOpe, String message) {
		super();
		this.nCorrela = nCorrela;
		this.fechaOpe = fechaOpe;
		this.message = message;
	}

	public ErrorMessage(TypeError typeError, String nCorrela, String fechaOpe, String message) {
		super();
		this.typeError = typeError;
		this.nCorrela = nCorrela;
		this.fechaOpe = fechaOpe;
		this.message = message;
		this.typeErrorStr = typeError.getLiteral();
	}
	public ErrorMessage(TypeError typeError, String nCorrela, String fechaOpe, String message, HistoricoOperacion ho) {
		super();
		this.typeError = typeError;
		this.nCorrela = nCorrela;
		this.fechaOpe = fechaOpe;
		this.message = message;
		this.ho = ho;
		this.typeErrorStr = typeError.getLiteral();
	}

	public String getnCorrela() {
		return nCorrela;
	}
	public void setnCorrela(String nCorrela) {
		this.nCorrela = nCorrela;
	}
	public String getFechaOpe() {
		return fechaOpe;
	}
	public void setFechaOpe(String fechaOpe) {
		this.fechaOpe = fechaOpe;
	}
	public String getMessage() {
		return message;
	}
	public void setMessage(String message) {
		this.message = message;
	}

	public TypeError getTypeError() {
		return typeError;
	}

	public void setTypeError(TypeError typeError) {
		this.typeError = typeError;
		this.typeErrorStr = typeError.getLiteral();
	}

	public HistoricoOperacion getHo() {
		return ho;
	}

	public void setHo(HistoricoOperacion ho) {
		this.ho = ho;
	}

	public String getTypeErrorStr() {
		return typeErrorStr;
	}

	public void setTypeErrorStr(String typeErrorStr) {
		this.typeErrorStr = typeErrorStr;
	}

}