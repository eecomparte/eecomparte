package com.atosorigin.deri.util;

import java.util.List;

import javax.faces.application.FacesMessage;

import org.jboss.seam.ScopeType;
import org.jboss.seam.annotations.AutoCreate;
import org.jboss.seam.annotations.In;
import org.jboss.seam.annotations.Name;
import org.jboss.seam.annotations.Scope;
import org.jboss.seam.faces.FacesMessages;

import com.atosorigin.common.statusmessages.StatusMessagesHelper;


@Name("errorMessageBoxAction")
@Scope(ScopeType.CONVERSATION)
@AutoCreate
public class ErrorMessageBoxAction extends MessageBoxAction {
	
	@In(create=true)
	private StatusMessagesHelper statusMessagesHelper;

	private String reRender;
	private String onComplete;
	private Boolean ready;
	private Boolean acceptPending=false;
	public Boolean getAcceptPending() {
		if(acceptPending){
			return true;
		}
		currentMessages = FacesMessages.instance().getCurrentMessages();
		acceptPending = currentMessages.size()>0;
		return acceptPending;
	}
	public void setAcceptPending(Boolean acceptPending) {
		this.acceptPending = acceptPending;
	}
	private List<FacesMessage> currentMessages;
	public String getReRender() {
		if ("".equalsIgnoreCase(reRender))
			return null;
		return reRender;
	}
	public void setReRender(String reRender) {
		
		this.reRender = reRender;
	}
	public String getOnComplete() {
		if ("".equalsIgnoreCase(onComplete))
			return null;		
		return onComplete;
	}
	public void setOnComplete(String onComplete) {
		this.onComplete = onComplete;
	}
	@Override
	public Boolean getReady() {
		if(acceptPending){
			return true;
		}
		if(ready==null){
			try {
			currentMessages = FacesMessages.instance().getCurrentMessages();
			ready = currentMessages.size()>0;
			} catch (Exception e) {
				return true;
			}
			if(ready ){
				statusMessagesHelper.obtenerEtiquetasMensajes();
				acceptPending =true;
				//ready=false;
				return true;
			}
			else{
				ready=null;
			}
		}
		return ready;
		
	}
	@Override
	public Object executeYes() {
		ready=null;
		acceptPending = false;
		return super.executeYes();
	}
}
