package com.atosorigin.deri.util;

import org.jboss.seam.annotations.intercept.AroundInvoke;
import org.jboss.seam.annotations.intercept.Interceptor;
import org.jboss.seam.contexts.Contexts;
import org.jboss.seam.intercept.AbstractInterceptor;
import org.jboss.seam.intercept.InvocationContext;
import org.jboss.seam.transaction.TransactionInterceptor;

@Interceptor(stateless=true, around={TransactionInterceptor.class})
public class ExceptionInterceptor extends AbstractInterceptor {

    @AroundInvoke

	public Object aroundInvoke(InvocationContext invocation) throws Exception {
	      try
	      {
	         return invocation.proceed();
	      }
	      catch (Exception e)
	      {
	    	  Boolean redirecting = (Boolean) Contexts.getConversationContext().get("redirecting");
	    	  if(redirecting!=null && redirecting){
	    		  Contexts.getConversationContext().set("redirecting",false);
	    		  throw new RedirectException(e);
	    	  }
	         throw e;
	      }
	}

	public boolean isInterceptorEnabled() {
	      return true;
	}

}
