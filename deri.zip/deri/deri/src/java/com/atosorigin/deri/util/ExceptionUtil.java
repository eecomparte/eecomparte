package com.atosorigin.deri.util;

import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import java.util.Stack;

import org.jboss.seam.ScopeType;
import org.jboss.seam.annotations.AutoCreate;
import org.jboss.seam.annotations.In;
import org.jboss.seam.annotations.Name;
import org.jboss.seam.annotations.Out;
import org.jboss.seam.annotations.Scope;
import org.jboss.seam.contexts.Contexts;
import org.jboss.seam.core.Conversation;

@Name("exceptionUtil")
@Scope(ScopeType.CONVERSATION)
@AutoCreate
public class ExceptionUtil implements java.io.Serializable {
	
	
	@Out(required=false)
	private Boolean redirecting=false;
	static class ExceptionWrapper{
		private Class<? extends Throwable> throwableClass;
		private Date when;
		public Date getWhen() {
			return when;
		}
		public ExceptionWrapper(Throwable throwable) {
			super();
			this.throwableClass = throwable.getClass();
			this.when = new Date();
		}
	}
	private Map<Class<? extends Throwable>, Stack<ExceptionWrapper>> exceptionMap = new HashMap<Class<? extends Throwable>, Stack<ExceptionWrapper>>();
	@In(value="org.jboss.seam.handledException",required=false)
	private Throwable exception;
	public static String extractMessage(Throwable exc){
		if(exc.getLocalizedMessage()!=null){
			return exc.getLocalizedMessage();
		}
		if(exc.getCause()!=null){
		return extractMessage(exc.getCause());
		}
		return extractStackInfo(exc);
	}

	private static String extractStackInfo(Throwable exc) {
		StringBuilder sb = new StringBuilder();
		StackTraceElement[] stackTrace = exc.getStackTrace();
		if(stackTrace.length>0){
			sb.append(" Excepcion ");
			sb.append(exc.toString());
			sb.append(", clase ");
			sb.append(stackTrace[0].getClassName());
			sb.append(", método ");
			sb.append(stackTrace[0].getMethodName());
			sb.append(", línea ");
			sb.append(stackTrace[0].getLineNumber());
		}
		return sb.toString();
	}
	
	public String getMessage(){
		if(exceptionMap.containsKey(exception.getClass())){
			ExceptionWrapper top = exceptionMap.get(exception.getClass()).peek();
			if(top.getWhen().getTime()-new Date().getTime()<500){
    		  Contexts.getConversationContext().set("redirectingToViewId",Conversation.instance().getViewId());
			  redirecting=true;
			}
		}
		else{
			Stack<ExceptionWrapper> stack = new Stack<ExceptionWrapper>();
			stack.push(new ExceptionWrapper(exception));
			exceptionMap.put(exception.getClass(), stack);
		}
		return extractMessage(exception);
	}
	
}
