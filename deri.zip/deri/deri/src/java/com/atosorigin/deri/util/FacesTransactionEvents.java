package com.atosorigin.deri.util;

import org.jboss.seam.annotations.Install;
import org.jboss.seam.annotations.Name;
import org.jboss.seam.annotations.Observer;
import org.jboss.seam.annotations.intercept.BypassInterceptors;
import org.jboss.seam.international.StatusMessages;
import org.jboss.seam.transaction.Transaction;

/**
 * Clase para deshabilitar el mensaje de "Transacción fallida".
 * 
 * @see <a
 *      href="http://seamframework.org/Community/HowToHideTransactionFailedMessage">http://seamframework.org/Community/HowToHideTransactionFailedMessage</a>
 * @author alejandro.torras@atosorigin.com
 */
@Name("org.jboss.seam.transaction.facesTransactionEvents")
@Install(precedence = Install.APPLICATION, classDependencies = "javax.faces.context.FacesContext")
@BypassInterceptors
public class FacesTransactionEvents extends
		org.jboss.seam.transaction.FacesTransactionEvents {

	@Observer(Transaction.TRANSACTION_FAILED)
	public void addTransactionFailedMessage(int status) {

		if (isTransactionFailedMessageEnabled()) {

			StatusMessages.instance().addFromResourceBundleOrDefault(
					getTransactionFailedMessageSeverity(),
					getTransactionFailedMessageKey(),
					getTransactionFailedMessage());
		}

		// Una vez aquí se habilita nuevamente...
		setTransactionFailedMessageEnabled(true);
	}
}
