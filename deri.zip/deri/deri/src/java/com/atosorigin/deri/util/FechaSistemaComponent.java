package com.atosorigin.deri.util;

import java.util.Date;

import javax.persistence.EntityManager;

import org.jboss.seam.ScopeType;
import org.jboss.seam.annotations.AutoCreate;
import org.jboss.seam.annotations.Create;
import org.jboss.seam.annotations.In;
import org.jboss.seam.annotations.Name;
import org.jboss.seam.annotations.Out;
import org.jboss.seam.annotations.Scope;

import com.atosorigin.common.constantes.Constantes;

@Name("fechaSistemaComponent")
@Scope(ScopeType.CONVERSATION)
@AutoCreate
public class FechaSistemaComponent implements java.io.Serializable{

	@In
	private EntityManager entityManager;
	
	@Out(scope=ScopeType.CONVERSATION)
	private Date fechaSistema;
	@Create
	public void create(){
		fechaSistema =  (Date) entityManager.createQuery("select fechaSistema from ControlDeri c where proyecto =:proyecto")
		.setParameter("proyecto", Constantes.NOMBRE_PROYECTO_DERI)
		.getSingleResult();
	}
	
	

}
