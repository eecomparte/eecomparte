package com.atosorigin.deri.util;

import java.text.ParseException;
import java.text.SimpleDateFormat;

import org.jboss.seam.ScopeType;
import org.jboss.seam.annotations.AutoCreate;
import org.jboss.seam.annotations.Name;
import org.jboss.seam.annotations.Scope;

import com.atosorigin.common.utils.GenericUtils;

@Name("formatUtil")
@Scope(ScopeType.EVENT)
@AutoCreate

public class FormatUtil {
	
	private String defaultDateFormat="dd/MM/yyyy";
	public String getDefaultDateFormat() {
		return defaultDateFormat;
	}
	public void setDefaultDateFormat(String defaultDateFormat) {
		this.defaultDateFormat = defaultDateFormat;
	}
	public String getFormattedDate(String format, java.sql.Date date){
		if(date != null) {
			SimpleDateFormat sdf = new SimpleDateFormat(format);
			return sdf.format(date);
		}
		return null;
	}
	public String getFormattedDate(java.sql.Date date){
		return getFormattedDate(defaultDateFormat, date);
	}

	public String getFormattedDate(String format, java.util.Date date){
		if(date != null) {
			SimpleDateFormat sdf = new SimpleDateFormat(format);
			return sdf.format(date);
		}
		return null;
	}
	public String getFormattedDate(java.util.Date date){
		return getFormattedDate(defaultDateFormat, date);
	}
	
	public java.util.Date getDate(String format, String date) {
		if(!GenericUtils.isNullOrBlank(date)) {
			SimpleDateFormat sdf = new SimpleDateFormat(format);
			try {
				return sdf.parse(date);
			} catch (ParseException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				return null;
			}
		}
		return null;
	}
	public java.util.Date getDate(String date) {
		return getDate(defaultDateFormat,date);
	}
	
	public java.util.Date getUtilDate(java.sql.Date date) {
		if(date != null) {
			return new java.util.Date(date.getTime());
		}
		return null;
	}
	public java.sql.Date getSQLDate(java.util.Date date) {
		if(date != null) {
			return new java.sql.Date(date.getTime());
		}
		return null;
	}
}
