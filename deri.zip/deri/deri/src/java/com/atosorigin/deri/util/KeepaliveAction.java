package com.atosorigin.deri.util;

import java.util.Collection;

import org.jboss.seam.ScopeType;
import org.jboss.seam.annotations.In;
import org.jboss.seam.annotations.Scope;
import org.jboss.seam.core.ConversationStack;

import com.atosorigin.common.action.GenericAction;
import com.atosorigin.common.utils.GenericUtils;

//@Name("keepaliveAction")
@Scope(ScopeType.CONVERSATION)
public class KeepaliveAction extends GenericAction {

	private static final long serialVersionUID = 1L;

	@In(value = "conversationStack", required = false)
	Collection<?> conversationStack;

	/**
	 * <i>Keepalive</i> para mantener viva la sesión.<br />
	 * Es llamado por el <code>&lt;a:poll&gt;</code> de
	 * <code>layout/template.xhtml</code>.
	 */
	public void keepalive() {
		log.debug("keepalive()");
	}

	/**
	 * Comprueba si se ha de mostrar la flecha del <i>BreadCrumb</i>.
	 * 
	 * @return <code>false</code> en el caso que la {@link ConversationStack} de
	 *         la sesión esté vacía o que el primer elemento pasado por
	 *         parámetro sea el primero de la {@link ConversationStack}.
	 */
	public boolean isBulletRendered(Object entry) {

		return !(GenericUtils.isNullOrEmpty(conversationStack) || conversationStack
				.iterator().next().equals(entry));
	}
}
