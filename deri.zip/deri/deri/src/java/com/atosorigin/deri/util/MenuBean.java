package com.atosorigin.deri.util;

import java.util.List;

import org.jboss.seam.ScopeType;
import org.jboss.seam.annotations.AutoCreate;
import org.jboss.seam.annotations.In;
import org.jboss.seam.annotations.Logger;
import org.jboss.seam.annotations.Name;
import org.jboss.seam.annotations.Observer;
import org.jboss.seam.annotations.Scope;
import org.jboss.seam.contexts.Contexts;
import org.jboss.seam.core.Conversation;
import org.jboss.seam.core.Expressions;
import org.jboss.seam.log.Log;

import com.atosorigin.deri.util.business.MenusBeanBo;
/**
* Este componente Seam permite cerrar conversaciones anidadas desde el menu. Por ejemplo, en vez de:

		<s:link 
			view="/pages/kondor/lanzamientoIntegracion.xhtml"

	escribiremos:

		<s:link 
			action="#{menuBean.clickAndKillLastConversation('/pages/kondor/lanzamientoIntegracion.xhtml')
					}"

	además, hay casos en locs que queremos llamar a una action despues de la view:

		<s:link 
			view="/pages/kondor/lanzamientoIntegracion.xhtml"
			action="#{lanzamientoIntegracionAction.newFormInstance}"

	entonces deberemos invocar al componente asi:

		<s:link 
			action="#{menuBean.clickAndKillLastConversation('/pages/kondor/lanzamientoIntegracion.xhtml',
															'#{lanzamientoIntegracionAction.newFormInstance}'
															)
					}"

	
*/

@Name("menuBean")
@Scope(ScopeType.SESSION)
@AutoCreate
public class MenuBean implements java.io.Serializable {
	@Logger Log log;
	
	@In("#{menusBeanBo}")
	protected MenusBeanBo menusBeanBo;
	
	private String timeAgenda;
	private String statusAgenda;
	private String murex;
	private String kondor;
	private Boolean kondorRojo = false;
	private Boolean murexRojo = false;

	/**
	 * Este método permite cerrar conversaciones anidadas , opcionalmente ejecutando una acción de inicialización para la ista 
	 * @param viewId, la vista que se renderizará
	 * @param action accion opcional que se ejecutará despues de iniciar la conversacion iniciada por la vista
	 * @return
	 */
    public String clickAndKillLastConversation(final String viewId, String action) {
        log.debug("clickAndKillLastConversation : clicked on " + viewId);
        while(Conversation.instance().isNested()){
        	Conversation nested =Conversation.instance();
        	Conversation.instance().pop();
        	nested.end(true);
        }
    	Conversation.instance().end(true);
        if(action!=null){
            Contexts.getSessionContext().set("actionPending", action);
        }
        return viewId;
    }
    public String clickAndKillLastConversation(final String viewId) {
    	return clickAndKillLastConversation(viewId,null);
    }
    @Observer("org.jboss.seam.beginConversation")
    public void checkConversationStart(){
        String convID = Conversation.instance().getId();
   		if(log.isDebugEnabled()){
   			log.debug("Entra a la conversacion {0}",  convID);
   		}
    	String actionPending = (String) Contexts.getSessionContext().get("actionPending");
    	if(actionPending!=null && !"".equals(actionPending)){
    		if(log.isDebugEnabled()){
    			log.debug("Ejecuta actionPending:{0} para la conversacion {1}", actionPending, convID);
    		}
        	Expressions.instance().createMethodExpression(actionPending).invoke();
        	actionPending=null;
        	Contexts.getSessionContext().remove("actionPending");
    	}
    }
    @Observer("org.jboss.seam.endConversation")
    public void checkCOnversationEnd(){
		if(log.isDebugEnabled()){
			String convID = Conversation.instance().getId();
			log.debug("Sale de la conversacion {0}",  convID);
		}
    }

    public boolean statusAg(){
    	statusAgenda();
    	kondorMurex();
    	return true;
    }
    public void statusAgenda(){
    	List<String> status = menusBeanBo.estadoAgenda();
    	setTimeAgenda(status.get(0));
		setStatusAgenda(status.get(1));
//    	return menusBeanBo.estadoAgenda();
    
    }
    
    public void kondorMurex(){
//    	Cuando el tiempo transcurrido entre desde la primera integración hasta el 
//    	momento supere los 10 minutos el contador se pondrá en rojo, por ejemplo
    	
    	List<String> status = menusBeanBo.kondorMurex();
    	setMurex("Murex: " + status.get(0));
		setKondor("Proxy: " + status.get(1));
		if ("ROJO".equalsIgnoreCase(status.get(2))){
			setMurexRojo(true);	
		}else{
			setMurexRojo(false);
		}
		if ("ROJO".equalsIgnoreCase(status.get(3))){
			setKondorRojo(true);	
		}else{
			setKondorRojo(false);
		}
		
    }
    
	public String getTimeAgenda() {
//		statusAgenda();
		return timeAgenda;
	}
	public void setTimeAgenda(String timeAgenda) {
		this.timeAgenda = timeAgenda;
	}

	public String getStatusAgenda() {
		return statusAgenda;
	}
	public void setStatusAgenda(String statusAgenda) {
		this.statusAgenda = statusAgenda;
	}
	public String getMurex() {
		return murex;
	}
	public void setMurex(String murex) {
		this.murex = murex;
	}
	public String getKondor() {
		return kondor;
	}
	public void setKondor(String kondor) {
		this.kondor = kondor;
	}
	public Boolean getKondorRojo() {
		return kondorRojo;
	}
	public void setKondorRojo(Boolean kondorRojo) {
		this.kondorRojo = kondorRojo;
	}
	public Boolean getMurexRojo() {
		return murexRojo;
	}
	public void setMurexRojo(Boolean murexRojo) {
		this.murexRojo = murexRojo;
	}

    
}