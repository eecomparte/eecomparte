package com.atosorigin.deri.util;

import java.util.Stack;

import org.jboss.seam.core.Expressions;
import org.jboss.seam.international.Messages;

public class MessageBoxAction {

	private class MessageInvocation{
		public MessageInvocation(String message, String yesMethodExpression,
				String noMethodExpression) {
			this(message, yesMethodExpression, noMethodExpression, null);
		}
		public MessageInvocation(String message, String yesMethodExpression,
				String noMethodExpression,String reRender) {
			super();
			this.yesMethodExpression = yesMethodExpression;
			this.noMethodExpression = noMethodExpression;
			this.message = message;
			this.ready = true;
			this.reRender=reRender;
		}
		private String yesMethodExpression;
		private String noMethodExpression;
		private String message;
		private Boolean ready;
		private String reRender=null;
	
	}
	private String reRender=null;
	public Boolean getReady() {
		if(invocationStack.isEmpty()){
			return false;
		}
		return invocationStack.peek().ready;
	}
	public String getMessage() {
		if(invocationStack.isEmpty()){
			return "";
		}
		return invocationStack.peek().message;
	}
	public String getReRender(){
		if(invocationStack.isEmpty()){
			return reRender;
		}
		String tmp = invocationStack.peek().reRender;
		if(tmp==null){
			return reRender;
		}
		return tmp;
	}
	public String getYesMethodExpression() {
		if(invocationStack.isEmpty()){
			return "";
		}
		return invocationStack.peek().yesMethodExpression;
	}
	public String getNoMethodExpression() {
		if(invocationStack.isEmpty()){
			return "";
		}
		return invocationStack.peek().noMethodExpression;
	}
	
	
	
	private Stack<MessageInvocation> invocationStack = new Stack<MessageInvocation>();
	
	public void init(String message, String yesMethodExpression, String noMethodExpression) {
		this.reRender=null;
		invocationStack.push(new MessageInvocation(Messages.instance().get(message),yesMethodExpression, noMethodExpression));
	}
	public void init(String message, String yesMethodExpression, String noMethodExpression,String reRender) {
		this.reRender=null;
		invocationStack.push(new MessageInvocation(Messages.instance().get(message),yesMethodExpression, noMethodExpression,reRender));
	}

	//FLM: Igual que el init, pero el message ya es un string
	public void initString(String message, String yesMethodExpression, String noMethodExpression) {
		this.reRender=null;
		invocationStack.push(new MessageInvocation(message,yesMethodExpression, noMethodExpression));
	}
	public void initString(String message, String yesMethodExpression, String noMethodExpression, String reRender) {
		this.reRender=null;
		invocationStack.push(new MessageInvocation(message,yesMethodExpression, noMethodExpression,reRender));
	}

	
	public Object executeYes(){
		if(invocationStack.isEmpty()){
			return null;
		}
		MessageInvocation top = invocationStack.pop();
		reRender=top.reRender;

		if (top.yesMethodExpression != null && !"".equals(top.yesMethodExpression)) {
			Object invoke = Expressions.instance().createMethodExpression(
					"#{" + top.yesMethodExpression + "}").invoke();
			return invoke;
		}
		return null;
	}
	public Object executeNo(){
		if(invocationStack.isEmpty()){
			return null;
		}
		MessageInvocation top = invocationStack.pop();
		reRender=top.reRender;
		if(top.noMethodExpression!=null && !"".equals(top.noMethodExpression)){
			Object invoke = Expressions.instance().createMethodExpression("#{" + top.noMethodExpression+ "}").invoke();
			return invoke;
		}
		return null;
	}
}
