package com.atosorigin.deri.util;

import org.jboss.seam.ScopeType;
import org.jboss.seam.annotations.Name;
import org.jboss.seam.annotations.Scope;
import org.jboss.seam.core.Expressions;

import com.atosorigin.common.action.GenericAction;
import com.atosorigin.common.utils.GenericUtils;

@Name("msgBoxAction")
@Scope(ScopeType.CONVERSATION)
public class MsgBoxAction extends GenericAction  {
	
	private static final long serialVersionUID = 1L;

	private boolean mostrarMensaje = false;
	protected String funcionSi; // {#CampanyasAction.Do()}
	protected String funcionNo;
	protected String funcionSalir;
	protected String mensaje;
	protected boolean voidFunction = false;
	private boolean forceNoMostrarMensaje = false;
	protected String onCompleteSi = null;
	protected String onCompleteNo = null;
	protected String onCompleteSalir = null;
	protected String reRenderSi = null;
	protected String reRenderNo = null;
	protected String reRenderSalir = null;
	protected String messageSi = null;
	protected String messageNo = null;
	protected String messageSalir = null;
	
	
	public String getFuncionSi() {
		return funcionSi;
	}

	public void setFuncionSi(String funcionSi) {
		this.funcionSi = funcionSi;
	}

	public String getFuncionSalir() {
		return funcionSalir;
	}

	public void setFuncionSalir(String funcionSalir) {
		this.funcionSalir = funcionSalir;
	}

	
	public String getFuncionNo() {
		return funcionNo;
	}

	public void setFuncionNo(String funcionNo) {
		this.funcionNo = funcionNo;
	}

	public String getMensaje() {
		return mensaje;
	}

	public void setMensaje(String mensaje) {
		this.mensaje = mensaje;
	}

	public void setMostrarMensaje(boolean mostrarMensaje) {
		this.mostrarMensaje = mostrarMensaje;
	}

	public boolean isMostrarMensaje() {
		return mostrarMensaje;
	}

	public void mostrarMsg(String funcionSi, String funcionNo,
			String onCompleteSi, String onCompleteNo, String reRenderSi,
			String reRenderNo, String mensaje) {

		mostrarMsg(funcionSi, funcionNo, mensaje);

		setOnCompleteSi(onCompleteSi);
		setOnCompleteNo(onCompleteNo);
		setReRenderSi(reRenderSi);
		setReRenderNo(reRenderNo);
	}
	
	public void mostrarMsg(String funcionSi, String funcionNo, String mensaje) {
		this.funcionSi = funcionSi;
		this.funcionNo = funcionNo;
		this.mensaje = mensaje;
		this.mostrarMensaje = true;
	}

	public void mostrarMsg(String funcionSi, String funcionNo, String funcionSalir, String mensaje) {
		this.funcionSi = funcionSi;
		this.funcionNo = funcionNo;
		this.funcionSalir = funcionSalir;
		this.mensaje = mensaje;
		this.mostrarMensaje = true;
	}
	  
	public void mostrarMsg(String funcionSi, String funcionNo, String funcionSalir,  
						   String messageSi, String messageNo, String messageSalir,
						   String reRenderSi,String reRenderNo,String reRenderSalir, String mensaje
							   ) {
			mostrarMsg(funcionSi, funcionNo, funcionSalir, mensaje);	
			setMessageSi(messageSi);
			setMessageNo(messageNo);
			setMessageSalir(messageSalir);
			setReRenderSi(reRenderSi);
			setReRenderNo(reRenderNo);
			setReRenderSalir(reRenderSalir);
		}
	public void mostrarMsg(String funcionSi, String funcionNo, String mensaje, boolean voidFunction) {
		mostrarMsg(funcionSi, funcionNo, mensaje);
		this.voidFunction = voidFunction;
	}

	public void execNo() {
		if(funcionNo != null) {
			Expressions.instance().createMethodExpression(funcionNo).invoke();
			this.mostrarMensaje = false;
		}
	}

	public void execSi() {
		if(funcionSi != null) {
			Expressions.instance().createMethodExpression(funcionSi).invoke();
			this.mostrarMensaje = false;
		}
	}
	public void execSalir() {
		if(funcionSalir != null) {
			Expressions.instance().createMethodExpression(funcionSalir).invoke();
			this.mostrarMensaje = false;
		}
	}

	/**
	 * Nos permite controlar el flujo de pantallas
	 * @param mostrarMensje: recibe si quiere que se borre o noel panel
	 */
	public String execSiConditional(Boolean mostrarMensaje){
		String ret = null;
		if(funcionSi != null) {
			Object obj = Expressions.instance().createMethodExpression(funcionSi).invoke();
			if(obj!=null) ret=obj.toString();
			if(!forceNoMostrarMensaje){
				this.mostrarMensaje = mostrarMensaje;
				forceNoMostrarMensaje = false;
			}
		}
		return ret;
	}
	
	public void noMostrarMensaje(){
		this.mostrarMensaje = false;
		this.forceNoMostrarMensaje = true;
	}
	
	public boolean isVoidFunction() {
		return voidFunction;
	}

	public void setVoidFunction(boolean voidFunction) {
		this.voidFunction = voidFunction;
	}
	
	public void voidFunction(){
		this.mostrarMensaje = false;
		}

	public boolean isForceNoMostrarMensaje() {
		return forceNoMostrarMensaje;
	}

	public void setForceNoMostrarMensaje(boolean forceNoMostrarMensaje) {
		this.forceNoMostrarMensaje = forceNoMostrarMensaje;
	}

	public String getReRenderSi() {
		return reRenderSi;
	}

	public void setReRenderSi(String reRenderSi) {

		if (GenericUtils.isNullOrBlank(reRenderSi)) {
			this.reRenderSi = "msgboxPanel";
		} else {
			this.reRenderSi = "msgboxPanel," + reRenderSi;
		}
	}

	public String getReRenderNo() {
		return reRenderNo;
	}

	public void setReRenderNo(String reRenderNo) {

		if (GenericUtils.isNullOrBlank(reRenderNo)) {
			this.reRenderNo = "msgboxPanel";
		} else {
			this.reRenderNo = "msgboxPanel," + reRenderNo;
		}
	}

	public void setReRenderSalir(String reRenderSalir) {

		if (GenericUtils.isNullOrBlank(reRenderSalir)) {
			this.reRenderSalir = "msgboxPanel";
		} else {
			this.reRenderSalir = "msgboxPanel," + reRenderSalir;
		}
	}
	
	public String getOnCompleteSi() {
		return onCompleteSi;
	}

	public void setOnCompleteSi(String onCompleteSi) {

		if (GenericUtils.isNullOrBlank(onCompleteSi)) {
			this.onCompleteSi = "$('msgboxPanel').component.hide();return false;";
		} else {
			this.onCompleteSi = onCompleteSi
					+ ";$('msgboxPanel').component.hide();return false;";
		}
	}

	public String getOnCompleteSalir() {
		return onCompleteSalir;
	}

	public void setOnCompleteSalir(String onCompleteSalir) {

		if (GenericUtils.isNullOrBlank(onCompleteSalir)) {
			this.onCompleteSalir = "$('msgboxPanel').component.hide();return false;";
		} else {
			this.onCompleteSalir = onCompleteSalir
					+ ";$('msgboxPanel').component.hide();return false;";
		}
	}
	public String getOnCompleteNo() {
		return onCompleteNo;
	}

	public void setOnCompleteNo(String onCompleteNo) {

		if (GenericUtils.isNullOrBlank(onCompleteNo)) {
			this.onCompleteNo = "$('msgboxPanel').component.hide();return false;";
		} else {
			this.onCompleteNo = onCompleteNo
					+ "$('msgboxPanel').component.hide();return false;";
		}
	}

	public String getMessageSi() {
		return messageSi;
	}

	public void setMessageSi(String messageSi) {
		this.messageSi = messageSi;
	}

	public String getMessageNo() {
		return messageNo;
	}

	public void setMessageNo(String messageNo) {
		this.messageNo = messageNo;
	}

	public String getMessageSalir() {
		return messageSalir;
	}

	public void setMessageSalir(String messageSalir) {
		this.messageSalir = messageSalir;
	}
}
