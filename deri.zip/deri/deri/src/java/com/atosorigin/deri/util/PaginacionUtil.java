package com.atosorigin.deri.util;

import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import org.apache.commons.beanutils.BeanUtils;

import com.atosorigin.common.action.PaginationData;


public class PaginacionUtil {
	

	public static  <E> List<E> paginaSublist(Class<E>  clazz, List<E> list, final PaginationData paginationData) {
		int toIndex = paginationData.getFirstResult()+ paginationData.getMaxResults();
		if(toIndex>list.size()){
			toIndex=list.size();			
		}
		
		List<E> subList = list.subList(paginationData.getFirstResult(), toIndex);
		Collections.sort(subList, new Comparator<E>() {

			public int compare(E o1, E o2) {
				try {
					if (paginationData.getOrderKey() != null
							&& !paginationData.getOrderKey().equals("")) {
						E value1 = (E) BeanUtils.getProperty(o1,
								paginationData.getOrderKey());
						E value2 = (E) BeanUtils.getProperty(o2,
								paginationData.getOrderKey());
						return ((Comparable) value1)
								.compareTo((Comparable) value2);
					}
				} catch (Exception e) {
				}
				return 0;
			}
		});
		return subList;
	}

}
