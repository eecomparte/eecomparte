package com.atosorigin.deri.util;

import java.io.IOException;

import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.jboss.seam.ScopeType;
import org.jboss.seam.annotations.Name;
import org.jboss.seam.annotations.Scope;
import org.jboss.seam.annotations.Startup;
import org.jboss.seam.annotations.intercept.BypassInterceptors;
import org.jboss.seam.annotations.web.Filter;

/**
 * Filtro sencillo para consultar el estado de la aplicación.<br />
 * 
 * Actualmente lo que hace es devolver un código 200 (SC_OK).</br />
 * 
 * HPQC 1781 :: DERI - Implementación página de prueba (sin SSO) para el
 * balanceador.
 * 
 * @author alejandro.torras@atosorigin.com
 * @see HttpServletResponse#SC_OK
 */
@Startup
@Scope(ScopeType.APPLICATION)
@Name("deri.statusFilter")
@BypassInterceptors
@Filter(around = "org.jboss.seam.servlet.SeamFilter")
public class StatusFilter implements javax.servlet.Filter {

	public static final String URI = "/StatusFilter";

	public static final String PARAMETER_NAME = "statusCode";

	public void destroy() {
		// No hace nada
	}

	public void doFilter(ServletRequest req, ServletResponse resp,
			FilterChain fChain) throws IOException, ServletException {

		final HttpServletRequest hsrq = (HttpServletRequest) req;

		if (!hsrq.getRequestURI().endsWith(URI)) {

			fChain.doFilter(req, resp);

			return;
		}

		if (req.getParameter(PARAMETER_NAME) == null)
			((HttpServletResponse) resp).setStatus(HttpServletResponse.SC_OK);
	}

	public void init(FilterConfig arg0) throws ServletException {
		// no hace nada
	}

}
