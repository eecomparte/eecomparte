package com.atosorigin.deri.util;

import java.io.File;
import java.io.IOException;
import java.io.PrintWriter;
import java.text.SimpleDateFormat;
import java.util.Date;

public class ThreadDebugger extends Thread {

	private volatile long periodo;
	private volatile PrintWriter pw;
	private volatile long veces;
	private Thread watchedThread;

	public ThreadDebugger(Thread watchedThread, long msPeriodo)
			throws IOException {

		this(watchedThread, msPeriodo, Integer.MAX_VALUE);
	}

	public ThreadDebugger(Thread watchedThread, long msPeriodo, long msTtl)
			throws IOException {

		super();

		this.watchedThread = watchedThread;
		this.periodo = msPeriodo;
		this.veces = msTtl / msPeriodo;

		setPriority(MAX_PRIORITY);

		final File file = new File("/tmp/ThreadDebugger-" + toString() + "-"
				+ watchedThread.toString() + ".log");

		file.delete();
		file.createNewFile();

		pw = new PrintWriter(file);

		start();
	}

	public void parar() {
		veces = 0;
	}

	public boolean isParado() {
		return veces <= 0;
	}

	public synchronized void print() {

		Exception ex = new ThreadDumpException(watchedThread);
		ex.printStackTrace(pw);
		pw.flush();

		// Permitir GC
		ex = null;
	}

	@Override
	public void run() {

		try {
			for (; !isParado(); veces--) {

				print();

				// esperar
				try {
					Thread.sleep(periodo);
				} catch (InterruptedException e) {
					e.printStackTrace();
				}
			}
		} finally {
			if (pw != null)
				pw.close();

			parar();

			// Permitir GC
			watchedThread = null;
			pw = null;
		}
	}
}

class ThreadDumpException extends RuntimeException {

	private static final long serialVersionUID = 1L;

	private final SimpleDateFormat sdf = new SimpleDateFormat("HH:mm:ss.SSS");

	private final Thread watchedThread;

	public ThreadDumpException(Thread watchedThread) {
		this.watchedThread = watchedThread;
		setStackTrace(watchedThread.getStackTrace());
	}

	@Override
	public String toString() {
		return new StringBuilder().append(sdf.format(new Date())).append(" - ")
				.append(watchedThread.toString()).toString();
	}
}
