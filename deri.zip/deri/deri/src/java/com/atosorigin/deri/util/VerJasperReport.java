package com.atosorigin.deri.util;

import java.io.IOException;
import java.io.InputStream;
import java.sql.Connection;
import java.text.SimpleDateFormat;
import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import java.util.Properties;

import javax.faces.context.FacesContext;
import javax.naming.Context;
import javax.naming.InitialContext;
import javax.servlet.ServletContext;
import javax.sql.DataSource;

import net.sf.jasperreports.engine.JasperCompileManager;
import net.sf.jasperreports.engine.JasperExportManager;
import net.sf.jasperreports.engine.JasperFillManager;
import net.sf.jasperreports.engine.JasperPrint;
import net.sf.jasperreports.engine.JasperReport;
import net.sf.jasperreports.engine.type.WhenNoDataTypeEnum;
import net.sf.jasperreports.engine.util.JRLoader;

import org.jboss.seam.ScopeType;
import org.jboss.seam.annotations.AutoCreate;
import org.jboss.seam.annotations.Name;
import org.jboss.seam.annotations.Scope;
import org.jboss.seam.core.Manager;
import org.jboss.seam.document.ByteArrayDocumentData;
import org.jboss.seam.document.DocumentData;
import org.jboss.seam.document.DocumentStore;
import org.jboss.seam.document.DocumentData.DocumentType;
import org.jboss.seam.navigation.Pages;

import com.atosorigin.common.constantes.Constantes;
import com.atosorigin.common.utils.GenericUtils;
import com.atosorigin.deri.model.appListados.Informe;
import com.atosorigin.deri.model.seguridad.Pantalla;
import com.atosorigin.deri.model.seguridad.PantallaId;
import com.atosorigin.deri.seguridad.pantalla.business.PantallaBo;

@Name("verJasperReport")
@Scope(ScopeType.CONVERSATION)
@AutoCreate
public class VerJasperReport {
	private Informe informe;
	
	private String reporte;
	private String username;
	private String producto;
	private Date fechaReg;
	private String idContrapartida;
	private String descContrapartida;
	private String direccion;
	private String personaContacto;

	
	public VerJasperReport(String reporte, String username, String producto,
			Date fechaReg, String idContrapartida, String descContrapartida,
			String direccion, String personaContacto) {
		super();
		this.reporte = reporte;
		this.username = username;
		this.producto = producto;
		this.fechaReg = fechaReg;
		this.idContrapartida = idContrapartida;
		this.descContrapartida = descContrapartida;
		this.direccion = direccion;
		this.personaContacto = personaContacto;
	}

	public void verPDF() {
		/*
		 parámetros reporte y array de params para cualquier report¿?
		 */
		JasperReport jasperReport;
		JasperReport jasperSubReport;
	    JasperPrint jasperPrint;
	    JasperReport jasperSubyacentes=null;
	    
//	    System.setProperty("java.awt.headless", "true");
	    
	    
	    try {
	    	
//		JasperCompileManager.compileReportToFile("D:\\workspace\\deri_web\\WebContent\\reports\\C2751404.jrxml", "D:\\workspace\\deri_web\\WebContent\\reports\\C2751404.jasper");
//		JasperCompileManager.compileReportToFile("D:\\workspace\\deri_web\\WebContent\\reports\\C8751404.jrxml", "D:\\workspace\\deri_web\\WebContent\\reports\\C8751404.jasper");
//		
	    	/*JasperCompileManager.compileReportToFile("D:\\workspace_COLAT\\deri_web\\WebContent\\reports\\C2000007.jrxml", "D:\\workspace_COLAT\\deri_web\\WebContent\\reports\\C2000007.jasper");
	    	JasperCompileManager.compileReportToFile("D:\\workspace_COLAT\\deri_web\\WebContent\\reports\\C2751055.jrxml", "D:\\workspace_COLAT\\deri_web\\WebContent\\reports\\C2751055.jasper");
	    	JasperCompileManager.compileReportToFile("D:\\workspace_COLAT\\deri_web\\WebContent\\reports\\C2751201.jrxml", "D:\\workspace_COLAT\\deri_web\\WebContent\\reports\\C2751201.jasper");
	    	JasperCompileManager.compileReportToFile("D:\\workspace_COLAT\\deri_web\\WebContent\\reports\\C2751204.jrxml", "D:\\workspace_COLAT\\deri_web\\WebContent\\reports\\C2751204.jasper");
	    	JasperCompileManager.compileReportToFile("D:\\workspace_COLAT\\deri_web\\WebContent\\reports\\C2751205.jrxml", "D:\\workspace_COLAT\\deri_web\\WebContent\\reports\\C2751205.jasper");
	    	JasperCompileManager.compileReportToFile("D:\\workspace_COLAT\\deri_web\\WebContent\\reports\\C2751214.jrxml", "D:\\workspace_COLAT\\deri_web\\WebContent\\reports\\C2751214.jasper");
	    	JasperCompileManager.compileReportToFile("D:\\workspace_COLAT\\deri_web\\WebContent\\reports\\C2750204.jrxml", "D:\\workspace_COLAT\\deri_web\\WebContent\\reports\\C2750204.jasper");
	    	JasperCompileManager.compileReportToFile("D:\\workspace_COLAT\\deri_web\\WebContent\\reports\\C2751401.jrxml", "D:\\workspace_COLAT\\deri_web\\WebContent\\reports\\C2751401.jasper");
	    	JasperCompileManager.compileReportToFile("D:\\workspace_COLAT\\deri_web\\WebContent\\reports\\C2751402.jrxml", "D:\\workspace_COLAT\\deri_web\\WebContent\\reports\\C2751402.jasper");
	    	JasperCompileManager.compileReportToFile("D:\\workspace_COLAT\\deri_web\\WebContent\\reports\\C2751403.jrxml", "D:\\workspace_COLAT\\deri_web\\WebContent\\reports\\C2751403.jasper");
	    	JasperCompileManager.compileReportToFile("D:\\workspace_COLAT\\deri_web\\WebContent\\reports\\C2751404.jrxml", "D:\\workspace_COLAT\\deri_web\\WebContent\\reports\\C2751404.jasper");
	    	JasperCompileManager.compileReportToFile("D:\\workspace_COLAT\\deri_web\\WebContent\\reports\\C2751410.jrxml", "D:\\workspace_COLAT\\deri_web\\WebContent\\reports\\C2751410.jasper");
	    	JasperCompileManager.compileReportToFile("D:\\workspace_COLAT\\deri_web\\WebContent\\reports\\C2751419.jrxml", "D:\\workspace_COLAT\\deri_web\\WebContent\\reports\\C2751419.jasper");

	    	JasperCompileManager.compileReportToFile("D:\\workspace_COLAT\\deri_web\\WebContent\\reports\\C8000007.jrxml", "D:\\workspace_COLAT\\deri_web\\WebContent\\reports\\C8000007.jasper");
	    	JasperCompileManager.compileReportToFile("D:\\workspace_COLAT\\deri_web\\WebContent\\reports\\C8751055.jrxml", "D:\\workspace_COLAT\\deri_web\\WebContent\\reports\\C8751055.jasper");
	    	JasperCompileManager.compileReportToFile("D:\\workspace_COLAT\\deri_web\\WebContent\\reports\\C8751201.jrxml", "D:\\workspace_COLAT\\deri_web\\WebContent\\reports\\C8751201.jasper");
	    	JasperCompileManager.compileReportToFile("D:\\workspace_COLAT\\deri_web\\WebContent\\reports\\C8751204.jrxml", "D:\\workspace_COLAT\\deri_web\\WebContent\\reports\\C8751204.jasper");
	    	JasperCompileManager.compileReportToFile("D:\\workspace_COLAT\\deri_web\\WebContent\\reports\\C8750204.jrxml", "D:\\workspace_COLAT\\deri_web\\WebContent\\reports\\C8750204.jasper");
	    	JasperCompileManager.compileReportToFile("D:\\workspace_COLAT\\deri_web\\WebContent\\reports\\C8751205.jrxml", "D:\\workspace_COLAT\\deri_web\\WebContent\\reports\\C8751205.jasper");
	    	JasperCompileManager.compileReportToFile("D:\\workspace_COLAT\\deri_web\\WebContent\\reports\\C8751214.jrxml", "D:\\workspace_COLAT\\deri_web\\WebContent\\reports\\C8751214.jasper");
	    	JasperCompileManager.compileReportToFile("D:\\workspace_COLAT\\deri_web\\WebContent\\reports\\C8751401.jrxml", "D:\\workspace_COLAT\\deri_web\\WebContent\\reports\\C8751401.jasper");
	    	JasperCompileManager.compileReportToFile("D:\\workspace_COLAT\\deri_web\\WebContent\\reports\\C8751402.jrxml", "D:\\workspace_COLAT\\deri_web\\WebContent\\reports\\C8751402.jasper");
	    	JasperCompileManager.compileReportToFile("D:\\workspace_COLAT\\deri_web\\WebContent\\reports\\C8751403.jrxml", "D:\\workspace_COLAT\\deri_web\\WebContent\\reports\\C8751403.jasper");
	    	JasperCompileManager.compileReportToFile("D:\\workspace_COLAT\\deri_web\\WebContent\\reports\\C8751404.jrxml", "D:\\workspace_COLAT\\deri_web\\WebContent\\reports\\C8751404.jasper");
	    	JasperCompileManager.compileReportToFile("D:\\workspace_COLAT\\deri_web\\WebContent\\reports\\C8751410.jrxml", "D:\\workspace_COLAT\\deri_web\\WebContent\\reports\\C8751410.jasper");
	    	JasperCompileManager.compileReportToFile("D:\\workspace_COLAT\\deri_web\\WebContent\\reports\\C8751419.jrxml", "D:\\workspace_COLAT\\deri_web\\WebContent\\reports\\C8751419.jasper");

	    	JasperCompileManager.compileReportToFile("D:\\workspace_COLAT\\deri_web\\WebContent\\reports\\Cabecera_Circul.jrxml", "D:\\workspace_COLAT\\deri_web\\WebContent\\reports\\Cabecera_Circul.jasper");
	    	JasperCompileManager.compileReportToFile("D:\\workspace_COLAT\\deri_web\\WebContent\\reports\\DERICAST.jrxml", "D:\\workspace_COLAT\\deri_web\\WebContent\\reports\\DERICAST.jasper");
	    	JasperCompileManager.compileReportToFile("D:\\workspace_COLAT\\deri_web\\WebContent\\reports\\DERIINGL.jrxml", "D:\\workspace_COLAT\\deri_web\\WebContent\\reports\\DERIINGL.jasper");
	    	JasperCompileManager.compileReportToFile("D:\\workspace_COLAT\\deri_web\\WebContent\\reports\\Subyacentes_751204.jrxml", "D:\\workspace_COLAT\\deri_web\\WebContent\\reports\\Subyacentes_751204.jasper");
	    	JasperCompileManager.compileReportToFile("D:\\workspace_COLAT\\deri_web\\WebContent\\reports\\Subyacentes_751401.jrxml", "D:\\workspace_COLAT\\deri_web\\WebContent\\reports\\Subyacentes_751401.jasper");
	    	JasperCompileManager.compileReportToFile("D:\\workspace_COLAT\\deri_web\\WebContent\\reports\\Supuestos_751201.jrxml", "D:\\workspace_COLAT\\deri_web\\WebContent\\reports\\Supuestos_751201.jasper");
	    	JasperCompileManager.compileReportToFile("D:\\workspace_COLAT\\deri_web\\WebContent\\reports\\Cab_Cartas_Circul.jrxml", "D:\\workspace_COLAT\\deri_web\\WebContent\\reports\\Cab_Cartas_Circul.jasper");
	    	JasperCompileManager.compileReportToFile("D:\\workspace_COLAT\\deri_web\\WebContent\\reports\\Cabecera_Visib.jrxml", "D:\\workspace_COLAT\\deri_web\\WebContent\\reports\\Cabecera_Visib.jasper");
*/
	    	String path="reports/";
	    	String reportPath="";
	    	String reportHeaderPath="";
	    	
	    	//Los informes  751205, 751206, 751207,751208,751209 se ejecutan todos con el report 751205.
	    	//Modificamos el report para que encuentre el que es
	    	String[] r1205ES = {"C8751205","C8751206","C8751207","C8751208","C8751209"};
	    	String[] r1205EN = {"C2751205","C2751206","C2751207","C2751208","C2751209"};
	    	if(Arrays.asList(r1205ES).contains(reporte)){
	    		reporte="C8751205";
	    	}else if(Arrays.asList(r1205EN).contains(reporte)){
	    		reporte="C2751205";
	    	}

    		reportPath=path+reporte+".jasper";

    		if(GenericUtils.in(reporte,"C2000007","C8000007","C2751205","C8751205","C2000007","C8000007","C2751201","C8751201","C2751204","C2750204","C8751204","C8750204",
    				"C2751055","C8751055","C2751214","C8751214","C2751401","C8751401",
	    			"C2751402","C8751402","C2751403","C8751403","C2751404","C8751404",
	    			"C2751410","C8751410","C2751419","C8751419")){
	    		
	    		reportHeaderPath=path+"Cabecera_Circul.jasper";
	    	}else if(reporte.equals("DERICAST") || reporte.equals("DERIINGL")){
	    		reportHeaderPath=path+"Cab_Cartas_Circul.jasper";
	    	}
	    	
	    	ServletContext servletContext = (ServletContext) FacesContext.getCurrentInstance().getExternalContext().getContext();
	    	jasperReport = (JasperReport)JRLoader.loadObject (getClass().getClassLoader().getResourceAsStream(reportPath));
	    	jasperSubReport = (JasperReport)JRLoader.loadObject (getClass().getClassLoader().getResourceAsStream(reportHeaderPath));
	    	if(reporte.equals("C2751204") || reporte.equals("C8751204")){
	    		String reportSubyacentePath=path+"Subyacentes_751204.jasper";
	    		jasperSubyacentes = (JasperReport)JRLoader.loadObject (getClass().getClassLoader().getResourceAsStream(reportSubyacentePath));
		    	jasperSubyacentes.setWhenNoDataType(WhenNoDataTypeEnum.ALL_SECTIONS_NO_DETAIL);
	    	}else if(reporte.equals("C2751401") || reporte.equals("C8751401")){
	    		String reportSubyacentePath=path+"Subyacentes_751401.jasper";
	    		jasperSubyacentes = (JasperReport)JRLoader.loadObject (getClass().getClassLoader().getResourceAsStream(reportSubyacentePath));
		    	jasperSubyacentes.setWhenNoDataType(WhenNoDataTypeEnum.ALL_SECTIONS_NO_DETAIL);
	    	}else if(reporte.equals("C2751201") || reporte.equals("C8751201")){
	    		String reportSubyacentePath=path+"Supuestos_751201.jasper";
	    		jasperSubyacentes = (JasperReport)JRLoader.loadObject (getClass().getClassLoader().getResourceAsStream(reportSubyacentePath));
		    	jasperSubyacentes.setWhenNoDataType(WhenNoDataTypeEnum.ALL_SECTIONS_NO_DETAIL);
	    	}
	    																	 
	    	jasperSubReport.setWhenNoDataType(WhenNoDataTypeEnum.ALL_SECTIONS_NO_DETAIL);
	    	jasperReport.setWhenNoDataType(WhenNoDataTypeEnum.ALL_SECTIONS_NO_DETAIL);
	    	
	    	Map<String, Object> params = new HashMap<String, Object>();
	    	
	    	SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
	    	params.put("P_CONTRAPA",idContrapartida);
	    	params.put("P_DESCONT",descContrapartida);
	    	params.put("P_DIRECCION",direccion);
	    	params.put("P_FECHAREG", sdf.format(fechaReg));
	    	params.put("P_PERSCONT", personaContacto);
	    	//params.put("P_USUARIO",username);
	    	if(null!=producto)
	    		params.put("P_PRODUCTO",producto);
	    	params.put("P_ROOT",getClass().getClassLoader().getResource("reports/").toString());
	    	params.put("SUBREPORT_DIR",jasperSubReport);
	    	if(reporte.equals("C2751204") || reporte.equals("C8751204") || 
	    			reporte.equals("C2751401") || reporte.equals("C8751401"))
		    	params.put("SUBYACENTE_DIR",jasperSubyacentes);

	    	if(reporte.equals("C2751201") || reporte.equals("C8751201"))
		    	params.put("SUPUESTOS_DIR",jasperSubyacentes);

	    	
	    	Connection result = null;
			Context initialContext = new InitialContext();
			
			Properties p = new Properties();
			InputStream stream = Thread.currentThread().getContextClassLoader().getResourceAsStream("database.properties");
			p.load(stream);
			stream.close();
			String databaseName = p.getProperty("datasource.name");

//	    	  DataSource datasource = (DataSource)initialContext.lookup("java:/jboss/deri_webDatasource");
//	    	  DataSource datasource = (DataSource)initialContext.lookup("java:/jboss/deriMex_webDatasource");
			 

			if ( initialContext != null){
				DataSource datasource = (DataSource)initialContext.lookup("java:/jboss/"+databaseName);
				if (datasource != null) {
					result = datasource.getConnection();
				}
			}
			if (result==null){
				return ;
			}
	    	    
	    	jasperPrint = JasperFillManager.fillReport(jasperReport, params, result);
	     
	    	if (!result.isClosed()){
	    		result.close();
	    	}
			
			//https://community.jboss.org/thread/159258

	    	redirectExport(JasperExportManager.exportReportToPdf(jasperPrint));
	    }
	    catch (Exception e)
	    {
	      e.printStackTrace();
	      return;
	    }
		
	}


	private void redirectExport(byte[] data){

		String viewId = Pages.getViewId(FacesContext.getCurrentInstance());

		String baseName = Pages.getCurrentBaseName();
		DocumentType documType = new DocumentType("pdf", "application/pdf");
		DocumentData documentData = new ByteArrayDocumentData(baseName,documType, data);
		documentData.setDisposition("attachment");
		documentData.setFilename(baseName + ".pdf");

		String id = DocumentStore.instance().newId();

		String url = DocumentStore.instance().preferredUrlForContent(baseName,
				documType.getExtension(), id);

		url = Manager.instance().encodeConversationId(url, viewId);

		DocumentStore.instance().saveData(id, documentData);

		try {
			FacesContext.getCurrentInstance().getExternalContext().redirect(url);
			FacesContext.getCurrentInstance().responseComplete();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	public void cargaDatosInforme(PantallaBo pantallaBo) {
		if (informe == null) {
			if (reporte != null) {
				final Pantalla pantalla = pantallaBo.cargar(new PantallaId(
						Constantes.NOMBRE_PROYECTO_DERI,
						Pantalla.TIPO_EJECUTABLE_INFORME, reporte));

				informe = new Informe();
				informe.setDescripcion(pantalla.getDescripcion());
				return;
			} else {
			}
		}
	}

	public Informe getInforme() {
		return informe;
	}

	public void setInforme(Informe informe) {
		this.informe = informe;
	}

}
