package com.atosorigin.seam.jsf;


import java.math.BigDecimal;

import javax.faces.component.UIComponent;
import javax.faces.context.FacesContext;
import javax.faces.convert.NumberConverter;

import org.jboss.seam.annotations.Name;
import org.jboss.seam.annotations.faces.Converter;
import org.jboss.seam.annotations.intercept.BypassInterceptors;

@Name("customBigDecimalConverter")
@BypassInterceptors
@Converter
public class CustomBigDecimalConverter extends NumberConverter {

	public CustomBigDecimalConverter() {
		// TODO Auto-generated constructor stub
		setType("currency");
		setCurrencySymbol("");
		setPattern("#,##0.00;-#,##0.00");
		setMaxFractionDigits(2);
		setMinFractionDigits(2);
	}
	
	public CustomBigDecimalConverter(int numDecimales) {
		// TODO Auto-generated constructor stub
		setType("currency");
		setCurrencySymbol("");
		if (numDecimales==8){
			setPattern("#,##0.00000000;-#,##0.00000000");	
		}else if (numDecimales==4){
			setPattern("#,##0.0000;-#,##0.0000");
		}else{
			setPattern("#,##0.00;-#,##0.00");	
		}
		
		setMaxFractionDigits(numDecimales);
		setMinFractionDigits(numDecimales);
//		setMaxIntegerDigits(maxIntegerDigits);
//		setMaxIntegerDigits(maxIntegerDigits);
	}
	
	 public Object getAsObject(FacesContext context, UIComponent component, String input) {
		 Object value = super.getAsObject(context, component, input); 
		    if (value instanceof Long){
		    	return BigDecimal.valueOf((Long) value);
		    }
		    if (value instanceof Double){
		    	return BigDecimal.valueOf((Double) value);
		    }
		   return value;
		 }
	 @Override
	public String getAsString(FacesContext context, UIComponent component,
			Object value) {
		// TODO Auto-generated method stub
		return super.getAsString(context, component, value);
	}
	 
	public static CustomBigDecimalConverter getInstance(int numDecimales){
		return new CustomBigDecimalConverter(numDecimales);
	}
}
