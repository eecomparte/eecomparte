package com.atosorigin.seam.jsf;


import java.math.BigDecimal;

import javax.faces.component.UIComponent;
import javax.faces.context.FacesContext;
import javax.faces.convert.NumberConverter;

import org.jboss.seam.annotations.Name;
import org.jboss.seam.annotations.faces.Converter;
import org.jboss.seam.annotations.intercept.BypassInterceptors;

@Name("customNumberConverter")
@BypassInterceptors
@Converter
public class CustomNumberConverter extends NumberConverter {

	public CustomNumberConverter() {
		// TODO Auto-generated constructor stub
		setType("number");
		setCurrencySymbol("");
		setMaxFractionDigits(2);
		setMinFractionDigits(2);
	}
	
	public CustomNumberConverter(int numDecimales) {
		// TODO Auto-generated constructor stub
		setType("number");
		setCurrencySymbol("");
		setMaxFractionDigits(numDecimales);
		setMinFractionDigits(numDecimales);
//		setMaxIntegerDigits(maxIntegerDigits);
//		setMaxIntegerDigits(maxIntegerDigits);
	}
	
	 public Object getAsObject(FacesContext context, UIComponent component, String input) {
		 Object value = super.getAsObject(context, component, input); 
		    if (value instanceof Long){
		    	return BigDecimal.valueOf((Long) value);
		    }
		    if (value instanceof Double){
		    	return BigDecimal.valueOf((Double) value);
		    }
		   return value;
		 }
	 @Override
	public String getAsString(FacesContext context, UIComponent component,
			Object value) {
		// TODO Auto-generated method stub
		return super.getAsString(context, component, value);
	}
	 
	public static CustomNumberConverter getInstance(int numDecimales){
		return new CustomNumberConverter(numDecimales);
	}
}
