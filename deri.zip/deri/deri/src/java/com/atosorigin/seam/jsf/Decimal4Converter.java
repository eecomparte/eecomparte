package com.atosorigin.seam.jsf;

import org.jboss.seam.annotations.Name;
import org.jboss.seam.annotations.faces.Converter;
import org.jboss.seam.annotations.intercept.BypassInterceptors;

@Name("decimal4Converter")
@BypassInterceptors
@Converter
public class Decimal4Converter extends CustomBigDecimalConverter {

	public Decimal4Converter() {
		super(4);
	}
}
