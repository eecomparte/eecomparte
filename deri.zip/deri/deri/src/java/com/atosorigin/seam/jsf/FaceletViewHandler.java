package com.atosorigin.seam.jsf;

import java.io.IOException;

import javax.faces.FacesException;
import javax.faces.application.ViewHandler;
import javax.faces.component.UIViewRoot;
import javax.faces.context.FacesContext;

import org.jboss.seam.core.Events;

public class FaceletViewHandler extends com.sun.facelets.FaceletViewHandler {

	public FaceletViewHandler(ViewHandler parent) {
		super(parent);
	}

	@Override
	protected void buildView(FacesContext context, UIViewRoot viewToRender)
			throws IOException, FacesException {
		// TODO Auto-generated method stub
		super.buildView(context, viewToRender);
		
		Events.instance().raiseEvent("com.atosorigin.seam.jsf.viewBuilt." + org.jboss.seam.core.Conversation.instance().getId(), viewToRender);
}
}
