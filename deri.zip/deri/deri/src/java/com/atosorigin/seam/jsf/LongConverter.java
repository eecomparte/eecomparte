package com.atosorigin.seam.jsf;

import javax.faces.component.UIComponent;
import javax.faces.context.FacesContext;
import javax.faces.convert.NumberConverter;

import org.jboss.seam.annotations.Name;
import org.jboss.seam.annotations.faces.Converter;
import org.jboss.seam.annotations.intercept.BypassInterceptors;

@Name("longConverter")
@BypassInterceptors
@Converter
public class LongConverter extends NumberConverter {

	public LongConverter() {

		setType("number");
		setCurrencySymbol("");
		setGroupingUsed(false);
		setMaxFractionDigits(0);
		setMinFractionDigits(0);
	}

	public Object getAsObject(FacesContext context, UIComponent component, String input) {

		final Object value = super.getAsObject(context, component, input);

		if (value instanceof Long)
			return value;

		if (value instanceof Number)
			return ((Number) value).longValue();

		if (value instanceof String)
			return new Long((String) value);

		return value;
	}

	@Override
	public String getAsString(FacesContext context, UIComponent component, Object value) {
		// TODO Auto-generated method stub
		return super.getAsString(context, component, value);
	}
}
