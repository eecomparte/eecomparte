package com.atosorigin.seam.jsf;

import org.jboss.seam.annotations.Name;
import org.jboss.seam.annotations.faces.Converter;
import org.jboss.seam.annotations.intercept.BypassInterceptors;

@Name("percentageConverter")
@BypassInterceptors
@Converter
public class PercentageConverter extends CustomBigDecimalConverter {

	public PercentageConverter() {
		super(8);
	}
}
