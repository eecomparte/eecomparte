/**
 * FaultInfo.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.bancsabadell.xmlns.proteo.SharedResources.ErrorSchema;

public class FaultInfo  extends org.apache.axis.AxisFault  implements java.io.Serializable {
    private com.bancsabadell.xmlns.proteo.SharedResources.Header.HeaderResponse headerResponse;

    private com.bancsabadell.xmlns.proteo.SharedResources.ErrorSchema.FaultDetail commonFault;

    private com.bancsabadell.xmlns.proteo.SharedResources.ErrorSchema.FaultDetail nativeFault;

    public FaultInfo() {
    }

    public FaultInfo(
           com.bancsabadell.xmlns.proteo.SharedResources.Header.HeaderResponse headerResponse,
           com.bancsabadell.xmlns.proteo.SharedResources.ErrorSchema.FaultDetail commonFault,
           com.bancsabadell.xmlns.proteo.SharedResources.ErrorSchema.FaultDetail nativeFault) {
        this.headerResponse = headerResponse;
        this.commonFault = commonFault;
        this.nativeFault = nativeFault;
    }


    /**
     * Gets the headerResponse value for this FaultInfo.
     * 
     * @return headerResponse
     */
    public com.bancsabadell.xmlns.proteo.SharedResources.Header.HeaderResponse getHeaderResponse() {
        return headerResponse;
    }


    /**
     * Sets the headerResponse value for this FaultInfo.
     * 
     * @param headerResponse
     */
    public void setHeaderResponse(com.bancsabadell.xmlns.proteo.SharedResources.Header.HeaderResponse headerResponse) {
        this.headerResponse = headerResponse;
    }


    /**
     * Gets the commonFault value for this FaultInfo.
     * 
     * @return commonFault
     */
    public com.bancsabadell.xmlns.proteo.SharedResources.ErrorSchema.FaultDetail getCommonFault() {
        return commonFault;
    }


    /**
     * Sets the commonFault value for this FaultInfo.
     * 
     * @param commonFault
     */
    public void setCommonFault(com.bancsabadell.xmlns.proteo.SharedResources.ErrorSchema.FaultDetail commonFault) {
        this.commonFault = commonFault;
    }


    /**
     * Gets the nativeFault value for this FaultInfo.
     * 
     * @return nativeFault
     */
    public com.bancsabadell.xmlns.proteo.SharedResources.ErrorSchema.FaultDetail getNativeFault() {
        return nativeFault;
    }


    /**
     * Sets the nativeFault value for this FaultInfo.
     * 
     * @param nativeFault
     */
    public void setNativeFault(com.bancsabadell.xmlns.proteo.SharedResources.ErrorSchema.FaultDetail nativeFault) {
        this.nativeFault = nativeFault;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof FaultInfo)) return false;
        FaultInfo other = (FaultInfo) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            ((this.headerResponse==null && other.getHeaderResponse()==null) || 
             (this.headerResponse!=null &&
              this.headerResponse.equals(other.getHeaderResponse()))) &&
            ((this.commonFault==null && other.getCommonFault()==null) || 
             (this.commonFault!=null &&
              this.commonFault.equals(other.getCommonFault()))) &&
            ((this.nativeFault==null && other.getNativeFault()==null) || 
             (this.nativeFault!=null &&
              this.nativeFault.equals(other.getNativeFault())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getHeaderResponse() != null) {
            _hashCode += getHeaderResponse().hashCode();
        }
        if (getCommonFault() != null) {
            _hashCode += getCommonFault().hashCode();
        }
        if (getNativeFault() != null) {
            _hashCode += getNativeFault().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(FaultInfo.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://xmlns.bancsabadell.com/proteo/SharedResources/ErrorSchema", ">FaultInfo"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("headerResponse");
        elemField.setXmlName(new javax.xml.namespace.QName("http://xmlns.bancsabadell.com/proteo/SharedResources/Header", "HeaderResponse"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://xmlns.bancsabadell.com/proteo/SharedResources/Header", ">HeaderResponse"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("commonFault");
        elemField.setXmlName(new javax.xml.namespace.QName("http://xmlns.bancsabadell.com/proteo/SharedResources/ErrorSchema", "CommonFault"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://xmlns.bancsabadell.com/proteo/SharedResources/ErrorSchema", "FaultDetail"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("nativeFault");
        elemField.setXmlName(new javax.xml.namespace.QName("http://xmlns.bancsabadell.com/proteo/SharedResources/ErrorSchema", "NativeFault"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://xmlns.bancsabadell.com/proteo/SharedResources/ErrorSchema", "FaultDetail"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }


    /**
     * Writes the exception data to the faultDetails
     */
    public void writeDetails(javax.xml.namespace.QName qname, org.apache.axis.encoding.SerializationContext context) throws java.io.IOException {
        context.serialize(qname, null, this);
    }
}
