/**
 * HeaderRequest.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.bancsabadell.xmlns.proteo.SharedResources.Header;

public class HeaderRequest  implements java.io.Serializable {
    private java.lang.String trackingId;

    private java.lang.Integer step;

    private java.lang.String applicationId;

    private java.lang.String language;

    private com.bancsabadell.xmlns.proteo.SharedResources.Header.HeaderRequestHostRequest hostRequest;

    public HeaderRequest() {
    }

    public HeaderRequest(
           java.lang.String trackingId,
           java.lang.Integer step,
           java.lang.String applicationId,
           java.lang.String language,
           com.bancsabadell.xmlns.proteo.SharedResources.Header.HeaderRequestHostRequest hostRequest) {
           this.trackingId = trackingId;
           this.step = step;
           this.applicationId = applicationId;
           this.language = language;
           this.hostRequest = hostRequest;
    }


    /**
     * Gets the trackingId value for this HeaderRequest.
     * 
     * @return trackingId
     */
    public java.lang.String getTrackingId() {
        return trackingId;
    }


    /**
     * Sets the trackingId value for this HeaderRequest.
     * 
     * @param trackingId
     */
    public void setTrackingId(java.lang.String trackingId) {
        this.trackingId = trackingId;
    }


    /**
     * Gets the step value for this HeaderRequest.
     * 
     * @return step
     */
    public java.lang.Integer getStep() {
        return step;
    }


    /**
     * Sets the step value for this HeaderRequest.
     * 
     * @param step
     */
    public void setStep(java.lang.Integer step) {
        this.step = step;
    }


    /**
     * Gets the applicationId value for this HeaderRequest.
     * 
     * @return applicationId
     */
    public java.lang.String getApplicationId() {
        return applicationId;
    }


    /**
     * Sets the applicationId value for this HeaderRequest.
     * 
     * @param applicationId
     */
    public void setApplicationId(java.lang.String applicationId) {
        this.applicationId = applicationId;
    }


    /**
     * Gets the language value for this HeaderRequest.
     * 
     * @return language
     */
    public java.lang.String getLanguage() {
        return language;
    }


    /**
     * Sets the language value for this HeaderRequest.
     * 
     * @param language
     */
    public void setLanguage(java.lang.String language) {
        this.language = language;
    }


    /**
     * Gets the hostRequest value for this HeaderRequest.
     * 
     * @return hostRequest
     */
    public com.bancsabadell.xmlns.proteo.SharedResources.Header.HeaderRequestHostRequest getHostRequest() {
        return hostRequest;
    }


    /**
     * Sets the hostRequest value for this HeaderRequest.
     * 
     * @param hostRequest
     */
    public void setHostRequest(com.bancsabadell.xmlns.proteo.SharedResources.Header.HeaderRequestHostRequest hostRequest) {
        this.hostRequest = hostRequest;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof HeaderRequest)) return false;
        HeaderRequest other = (HeaderRequest) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            ((this.trackingId==null && other.getTrackingId()==null) || 
             (this.trackingId!=null &&
              this.trackingId.equals(other.getTrackingId()))) &&
            ((this.step==null && other.getStep()==null) || 
             (this.step!=null &&
              this.step.equals(other.getStep()))) &&
            ((this.applicationId==null && other.getApplicationId()==null) || 
             (this.applicationId!=null &&
              this.applicationId.equals(other.getApplicationId()))) &&
            ((this.language==null && other.getLanguage()==null) || 
             (this.language!=null &&
              this.language.equals(other.getLanguage()))) &&
            ((this.hostRequest==null && other.getHostRequest()==null) || 
             (this.hostRequest!=null &&
              this.hostRequest.equals(other.getHostRequest())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getTrackingId() != null) {
            _hashCode += getTrackingId().hashCode();
        }
        if (getStep() != null) {
            _hashCode += getStep().hashCode();
        }
        if (getApplicationId() != null) {
            _hashCode += getApplicationId().hashCode();
        }
        if (getLanguage() != null) {
            _hashCode += getLanguage().hashCode();
        }
        if (getHostRequest() != null) {
            _hashCode += getHostRequest().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(HeaderRequest.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://xmlns.bancsabadell.com/proteo/SharedResources/Header", ">HeaderRequest"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("trackingId");
        elemField.setXmlName(new javax.xml.namespace.QName("http://xmlns.bancsabadell.com/proteo/SharedResources/Header", "trackingId"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("step");
        elemField.setXmlName(new javax.xml.namespace.QName("http://xmlns.bancsabadell.com/proteo/SharedResources/Header", "step"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("applicationId");
        elemField.setXmlName(new javax.xml.namespace.QName("http://xmlns.bancsabadell.com/proteo/SharedResources/Header", "applicationId"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("language");
        elemField.setXmlName(new javax.xml.namespace.QName("http://xmlns.bancsabadell.com/proteo/SharedResources/Header", "language"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("hostRequest");
        elemField.setXmlName(new javax.xml.namespace.QName("http://xmlns.bancsabadell.com/proteo/SharedResources/Header", "HostRequest"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://xmlns.bancsabadell.com/proteo/SharedResources/Header", ">>HeaderRequest>HostRequest"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
