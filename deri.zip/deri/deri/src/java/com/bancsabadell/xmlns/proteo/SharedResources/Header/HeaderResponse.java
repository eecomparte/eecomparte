/**
 * HeaderResponse.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.bancsabadell.xmlns.proteo.SharedResources.Header;

public class HeaderResponse  implements java.io.Serializable {
    private java.lang.String trackingId;

    private java.lang.Integer step;

    private java.lang.Integer status;

    private com.bancsabadell.xmlns.proteo.SharedResources.Header.HeaderResponseHostResponse hostResponse;

    private com.bancsabadell.xmlns.proteo.SharedResources.Header.HeaderProperty[] headerProperties;

    public HeaderResponse() {
    }

    public HeaderResponse(
           java.lang.String trackingId,
           java.lang.Integer step,
           java.lang.Integer status,
           com.bancsabadell.xmlns.proteo.SharedResources.Header.HeaderResponseHostResponse hostResponse,
           com.bancsabadell.xmlns.proteo.SharedResources.Header.HeaderProperty[] headerProperties) {
           this.trackingId = trackingId;
           this.step = step;
           this.status = status;
           this.hostResponse = hostResponse;
           this.headerProperties = headerProperties;
    }


    /**
     * Gets the trackingId value for this HeaderResponse.
     * 
     * @return trackingId
     */
    public java.lang.String getTrackingId() {
        return trackingId;
    }


    /**
     * Sets the trackingId value for this HeaderResponse.
     * 
     * @param trackingId
     */
    public void setTrackingId(java.lang.String trackingId) {
        this.trackingId = trackingId;
    }


    /**
     * Gets the step value for this HeaderResponse.
     * 
     * @return step
     */
    public java.lang.Integer getStep() {
        return step;
    }


    /**
     * Sets the step value for this HeaderResponse.
     * 
     * @param step
     */
    public void setStep(java.lang.Integer step) {
        this.step = step;
    }


    /**
     * Gets the status value for this HeaderResponse.
     * 
     * @return status
     */
    public java.lang.Integer getStatus() {
        return status;
    }


    /**
     * Sets the status value for this HeaderResponse.
     * 
     * @param status
     */
    public void setStatus(java.lang.Integer status) {
        this.status = status;
    }


    /**
     * Gets the hostResponse value for this HeaderResponse.
     * 
     * @return hostResponse
     */
    public com.bancsabadell.xmlns.proteo.SharedResources.Header.HeaderResponseHostResponse getHostResponse() {
        return hostResponse;
    }


    /**
     * Sets the hostResponse value for this HeaderResponse.
     * 
     * @param hostResponse
     */
    public void setHostResponse(com.bancsabadell.xmlns.proteo.SharedResources.Header.HeaderResponseHostResponse hostResponse) {
        this.hostResponse = hostResponse;
    }


    /**
     * Gets the headerProperties value for this HeaderResponse.
     * 
     * @return headerProperties
     */
    public com.bancsabadell.xmlns.proteo.SharedResources.Header.HeaderProperty[] getHeaderProperties() {
        return headerProperties;
    }


    /**
     * Sets the headerProperties value for this HeaderResponse.
     * 
     * @param headerProperties
     */
    public void setHeaderProperties(com.bancsabadell.xmlns.proteo.SharedResources.Header.HeaderProperty[] headerProperties) {
        this.headerProperties = headerProperties;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof HeaderResponse)) return false;
        HeaderResponse other = (HeaderResponse) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            ((this.trackingId==null && other.getTrackingId()==null) || 
             (this.trackingId!=null &&
              this.trackingId.equals(other.getTrackingId()))) &&
            ((this.step==null && other.getStep()==null) || 
             (this.step!=null &&
              this.step.equals(other.getStep()))) &&
            ((this.status==null && other.getStatus()==null) || 
             (this.status!=null &&
              this.status.equals(other.getStatus()))) &&
            ((this.hostResponse==null && other.getHostResponse()==null) || 
             (this.hostResponse!=null &&
              this.hostResponse.equals(other.getHostResponse()))) &&
            ((this.headerProperties==null && other.getHeaderProperties()==null) || 
             (this.headerProperties!=null &&
              java.util.Arrays.equals(this.headerProperties, other.getHeaderProperties())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getTrackingId() != null) {
            _hashCode += getTrackingId().hashCode();
        }
        if (getStep() != null) {
            _hashCode += getStep().hashCode();
        }
        if (getStatus() != null) {
            _hashCode += getStatus().hashCode();
        }
        if (getHostResponse() != null) {
            _hashCode += getHostResponse().hashCode();
        }
        if (getHeaderProperties() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getHeaderProperties());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getHeaderProperties(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(HeaderResponse.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://xmlns.bancsabadell.com/proteo/SharedResources/Header", ">HeaderResponse"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("trackingId");
        elemField.setXmlName(new javax.xml.namespace.QName("http://xmlns.bancsabadell.com/proteo/SharedResources/Header", "trackingId"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("step");
        elemField.setXmlName(new javax.xml.namespace.QName("http://xmlns.bancsabadell.com/proteo/SharedResources/Header", "step"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("status");
        elemField.setXmlName(new javax.xml.namespace.QName("http://xmlns.bancsabadell.com/proteo/SharedResources/Header", "status"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("hostResponse");
        elemField.setXmlName(new javax.xml.namespace.QName("http://xmlns.bancsabadell.com/proteo/SharedResources/Header", "HostResponse"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://xmlns.bancsabadell.com/proteo/SharedResources/Header", ">>HeaderResponse>HostResponse"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("headerProperties");
        elemField.setXmlName(new javax.xml.namespace.QName("http://xmlns.bancsabadell.com/proteo/SharedResources/Header", "HeaderProperties"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://xmlns.bancsabadell.com/proteo/SharedResources/Header", "HeaderProperty"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        elemField.setItemQName(new javax.xml.namespace.QName("http://xmlns.bancsabadell.com/proteo/SharedResources/Header", "HeaderProperty"));
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
