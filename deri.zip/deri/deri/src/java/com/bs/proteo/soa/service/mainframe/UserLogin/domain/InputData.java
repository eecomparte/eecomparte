/**
 * InputData.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.bs.proteo.soa.service.mainframe.UserLogin.domain;

public class InputData  implements java.io.Serializable {
    private java.lang.String username;

    private java.lang.String password;

    private java.lang.String center;

    private java.lang.String enterprise;

    private java.lang.String postid;

    public InputData() {
    }

    public InputData(
           java.lang.String username,
           java.lang.String password,
           java.lang.String center,
           java.lang.String enterprise,
           java.lang.String postid) {
           this.username = username;
           this.password = password;
           this.center = center;
           this.enterprise = enterprise;
           this.postid = postid;
    }


    /**
     * Gets the username value for this InputData.
     * 
     * @return username
     */
    public java.lang.String getUsername() {
        return username;
    }


    /**
     * Sets the username value for this InputData.
     * 
     * @param username
     */
    public void setUsername(java.lang.String username) {
        this.username = username;
    }


    /**
     * Gets the password value for this InputData.
     * 
     * @return password
     */
    public java.lang.String getPassword() {
        return password;
    }


    /**
     * Sets the password value for this InputData.
     * 
     * @param password
     */
    public void setPassword(java.lang.String password) {
        this.password = password;
    }


    /**
     * Gets the center value for this InputData.
     * 
     * @return center
     */
    public java.lang.String getCenter() {
        return center;
    }


    /**
     * Sets the center value for this InputData.
     * 
     * @param center
     */
    public void setCenter(java.lang.String center) {
        this.center = center;
    }


    /**
     * Gets the enterprise value for this InputData.
     * 
     * @return enterprise
     */
    public java.lang.String getEnterprise() {
        return enterprise;
    }


    /**
     * Sets the enterprise value for this InputData.
     * 
     * @param enterprise
     */
    public void setEnterprise(java.lang.String enterprise) {
        this.enterprise = enterprise;
    }


    /**
     * Gets the postid value for this InputData.
     * 
     * @return postid
     */
    public java.lang.String getPostid() {
        return postid;
    }


    /**
     * Sets the postid value for this InputData.
     * 
     * @param postid
     */
    public void setPostid(java.lang.String postid) {
        this.postid = postid;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof InputData)) return false;
        InputData other = (InputData) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            ((this.username==null && other.getUsername()==null) || 
             (this.username!=null &&
              this.username.equals(other.getUsername()))) &&
            ((this.password==null && other.getPassword()==null) || 
             (this.password!=null &&
              this.password.equals(other.getPassword()))) &&
            ((this.center==null && other.getCenter()==null) || 
             (this.center!=null &&
              this.center.equals(other.getCenter()))) &&
            ((this.enterprise==null && other.getEnterprise()==null) || 
             (this.enterprise!=null &&
              this.enterprise.equals(other.getEnterprise()))) &&
            ((this.postid==null && other.getPostid()==null) || 
             (this.postid!=null &&
              this.postid.equals(other.getPostid())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getUsername() != null) {
            _hashCode += getUsername().hashCode();
        }
        if (getPassword() != null) {
            _hashCode += getPassword().hashCode();
        }
        if (getCenter() != null) {
            _hashCode += getCenter().hashCode();
        }
        if (getEnterprise() != null) {
            _hashCode += getEnterprise().hashCode();
        }
        if (getPostid() != null) {
            _hashCode += getPostid().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(InputData.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://proteo.bs.com/soa/service/mainframe/UserLogin/domain", ">InputData"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("username");
        elemField.setXmlName(new javax.xml.namespace.QName("http://proteo.bs.com/soa/service/mainframe/UserLogin/domain", "username"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("password");
        elemField.setXmlName(new javax.xml.namespace.QName("http://proteo.bs.com/soa/service/mainframe/UserLogin/domain", "password"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("center");
        elemField.setXmlName(new javax.xml.namespace.QName("http://proteo.bs.com/soa/service/mainframe/UserLogin/domain", "center"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("enterprise");
        elemField.setXmlName(new javax.xml.namespace.QName("http://proteo.bs.com/soa/service/mainframe/UserLogin/domain", "enterprise"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("postid");
        elemField.setXmlName(new javax.xml.namespace.QName("http://proteo.bs.com/soa/service/mainframe/UserLogin/domain", "postid"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
