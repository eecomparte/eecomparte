/**
 * Operation1Request.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.bs.proteo.soa.service.mainframe.UserLogin.domain.message;

public class Operation1Request  implements java.io.Serializable {
    private com.bancsabadell.xmlns.proteo.SharedResources.Header.HeaderRequest headerRequest;

    private com.bs.proteo.soa.service.mainframe.UserLogin.domain.InputData inputData;

    public Operation1Request() {
    }

    public Operation1Request(
           com.bancsabadell.xmlns.proteo.SharedResources.Header.HeaderRequest headerRequest,
           com.bs.proteo.soa.service.mainframe.UserLogin.domain.InputData inputData) {
           this.headerRequest = headerRequest;
           this.inputData = inputData;
    }


    /**
     * Gets the headerRequest value for this Operation1Request.
     * 
     * @return headerRequest
     */
    public com.bancsabadell.xmlns.proteo.SharedResources.Header.HeaderRequest getHeaderRequest() {
        return headerRequest;
    }


    /**
     * Sets the headerRequest value for this Operation1Request.
     * 
     * @param headerRequest
     */
    public void setHeaderRequest(com.bancsabadell.xmlns.proteo.SharedResources.Header.HeaderRequest headerRequest) {
        this.headerRequest = headerRequest;
    }


    /**
     * Gets the inputData value for this Operation1Request.
     * 
     * @return inputData
     */
    public com.bs.proteo.soa.service.mainframe.UserLogin.domain.InputData getInputData() {
        return inputData;
    }


    /**
     * Sets the inputData value for this Operation1Request.
     * 
     * @param inputData
     */
    public void setInputData(com.bs.proteo.soa.service.mainframe.UserLogin.domain.InputData inputData) {
        this.inputData = inputData;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof Operation1Request)) return false;
        Operation1Request other = (Operation1Request) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            ((this.headerRequest==null && other.getHeaderRequest()==null) || 
             (this.headerRequest!=null &&
              this.headerRequest.equals(other.getHeaderRequest()))) &&
            ((this.inputData==null && other.getInputData()==null) || 
             (this.inputData!=null &&
              this.inputData.equals(other.getInputData())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getHeaderRequest() != null) {
            _hashCode += getHeaderRequest().hashCode();
        }
        if (getInputData() != null) {
            _hashCode += getInputData().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(Operation1Request.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://proteo.bs.com/soa/service/mainframe/UserLogin/domain/message", ">operation1Request"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("headerRequest");
        elemField.setXmlName(new javax.xml.namespace.QName("http://xmlns.bancsabadell.com/proteo/SharedResources/Header", "HeaderRequest"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://xmlns.bancsabadell.com/proteo/SharedResources/Header", ">HeaderRequest"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("inputData");
        elemField.setXmlName(new javax.xml.namespace.QName("http://proteo.bs.com/soa/service/mainframe/UserLogin/domain", "InputData"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://proteo.bs.com/soa/service/mainframe/UserLogin/domain", ">InputData"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
