/**
 * Operation1Response.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.bs.proteo.soa.service.mainframe.UserLogin.domain.message;

public class Operation1Response  implements java.io.Serializable {
    private com.bancsabadell.xmlns.proteo.SharedResources.Header.HeaderResponse headerResponse;

    private com.bs.proteo.soa.service.mainframe.UserLogin.domain.OutputData outputData;

    public Operation1Response() {
    }

    public Operation1Response(
           com.bancsabadell.xmlns.proteo.SharedResources.Header.HeaderResponse headerResponse,
           com.bs.proteo.soa.service.mainframe.UserLogin.domain.OutputData outputData) {
           this.headerResponse = headerResponse;
           this.outputData = outputData;
    }


    /**
     * Gets the headerResponse value for this Operation1Response.
     * 
     * @return headerResponse
     */
    public com.bancsabadell.xmlns.proteo.SharedResources.Header.HeaderResponse getHeaderResponse() {
        return headerResponse;
    }


    /**
     * Sets the headerResponse value for this Operation1Response.
     * 
     * @param headerResponse
     */
    public void setHeaderResponse(com.bancsabadell.xmlns.proteo.SharedResources.Header.HeaderResponse headerResponse) {
        this.headerResponse = headerResponse;
    }


    /**
     * Gets the outputData value for this Operation1Response.
     * 
     * @return outputData
     */
    public com.bs.proteo.soa.service.mainframe.UserLogin.domain.OutputData getOutputData() {
        return outputData;
    }


    /**
     * Sets the outputData value for this Operation1Response.
     * 
     * @param outputData
     */
    public void setOutputData(com.bs.proteo.soa.service.mainframe.UserLogin.domain.OutputData outputData) {
        this.outputData = outputData;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof Operation1Response)) return false;
        Operation1Response other = (Operation1Response) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            ((this.headerResponse==null && other.getHeaderResponse()==null) || 
             (this.headerResponse!=null &&
              this.headerResponse.equals(other.getHeaderResponse()))) &&
            ((this.outputData==null && other.getOutputData()==null) || 
             (this.outputData!=null &&
              this.outputData.equals(other.getOutputData())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getHeaderResponse() != null) {
            _hashCode += getHeaderResponse().hashCode();
        }
        if (getOutputData() != null) {
            _hashCode += getOutputData().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(Operation1Response.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://proteo.bs.com/soa/service/mainframe/UserLogin/domain/message", ">operation1Response"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("headerResponse");
        elemField.setXmlName(new javax.xml.namespace.QName("http://xmlns.bancsabadell.com/proteo/SharedResources/Header", "HeaderResponse"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://xmlns.bancsabadell.com/proteo/SharedResources/Header", ">HeaderResponse"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("outputData");
        elemField.setXmlName(new javax.xml.namespace.QName("http://proteo.bs.com/soa/service/mainframe/UserLogin/domain", "OutputData"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://proteo.bs.com/soa/service/mainframe/UserLogin/domain", ">OutputData"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
