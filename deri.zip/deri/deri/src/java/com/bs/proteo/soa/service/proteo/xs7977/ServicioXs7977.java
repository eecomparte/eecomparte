package com.bs.proteo.soa.service.proteo.xs7977;

import java.math.BigDecimal;
import java.math.BigInteger;
import java.rmi.RemoteException;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Map;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.jboss.seam.security.Identity;

import com.atosorigin.deri.dao.liquidaciones.LiquidacionesDao;
import com.atosorigin.deri.liquidaciones.business.LiquidacionesBo;
import com.atosorigin.deri.model.contrapartida.Contrapartida;
import com.atosorigin.deri.model.liquidaciones.Liquidacion;
import com.atosorigin.deri.model.liquidaciones.Swift;
import com.bancsabadell.xmlns.proteo.SharedResources.ErrorSchema.FaultInfo;
import com.bancsabadell.xmlns.proteo.SharedResources.Header.HeaderRequest;
import com.bancsabadell.xmlns.proteo.SharedResources.Header.HeaderRequestHostRequest;
import com.bs.proteo.soa.service.proteo.xs7977.Xs7977ServiceProxy;
import com.bs.proteo.soa.service.proteo.xs7977.xs7977.domain.C57ABancoCuenta;
import com.bs.proteo.soa.service.proteo.xs7977.xs7977.domain.C58BeneficiarioCobertura;
import com.bs.proteo.soa.service.proteo.xs7977.xs7977.domain.P52BancoEmisor;
import com.bs.proteo.soa.service.proteo.xs7977.xs7977.domain.P57BancoBeneficiario;
import com.bs.proteo.soa.service.proteo.xs7977.xs7977.domain.Xs7377D;
import com.bs.proteo.soa.service.proteo.xs7977.xs7977.domain.Xs7377Ia;
import com.bs.proteo.soa.service.proteo.xs7977.xs7977.domain.Xs7977IEpa;
import com.bs.proteo.soa.service.proteo.xs7977.xs7977.domain.Xs7977InputData;
import com.bs.proteo.soa.service.proteo.xs7977.xs7977.domain.message.Xs7977Request;
import com.bs.proteo.soa.service.proteo.xs7977.xs7977.domain.message.Xs7977Response;

public class ServicioXs7977 {

	private String endPointXs7977;
	private String endPointLogin;
	private String endPointGrantTicket;
	private String username;
	private String password;
	
	private String endPointLoginOB;
	private String endPointLogout;
	private String endPointQuery;
	private String endPointTest;
	
	private String proxyGrantingTicket;
			
	private Log log = LogFactory.getLog(ServicioXs7977.class);
	
	public Xs7977Response liquidarXs7977 (Liquidacion liquidacion, Map<String,String> parametros, String referencia, Contrapartida contrapa, String sessionid, LiquidacionesBo liquidacionesBo, Date[] fechas) throws Exception, RemoteException{
		
		Xs7977ServiceProxy proxy = new Xs7977ServiceProxy(parametros.get("PROXY"));
		
		HeaderRequest headerRequest = new HeaderRequest();
	    headerRequest.setApplicationId(parametros.get("APPID"));
	    headerRequest.setLanguage(parametros.get("LANGUAGE"));//TODO idioma esperan ES o les da igual 08,13,01
	    headerRequest.setStep(1);
	    headerRequest.setTrackingId(parametros.get("TRACKID"));
	    
		HeaderRequestHostRequest hostRequest = new HeaderRequestHostRequest();
		hostRequest.setAuthorizationId("");
		hostRequest.setSessionId(sessionid);
		headerRequest.setHostRequest(hostRequest);
		
		/**Initialize IEpa **/
		Xs7977IEpa xsIEpa = new Xs7977IEpa(); 
		xsIEpa = inicializarIePACOLAT(liquidacion, parametros, referencia, contrapa, liquidacionesBo, fechas);
		
		showParametersConsole(xsIEpa);
		
		Xs7977InputData inputData = new Xs7977InputData(xsIEpa);

		Xs7977Request request = new Xs7977Request(headerRequest, inputData);
		try {
			
			Xs7977Response resposta = proxy.xs7977(request);
			return resposta;
			
		} catch (FaultInfo e) {
			log.error(e);
			e.printStackTrace();
			throw  e;	
		} catch (RemoteException e) {
			log.error(e);
			e.printStackTrace();
			throw  e;
		} catch (Exception e) {
			log.error(e);
			e.printStackTrace();
			throw  e;
		}
	}
	
	private void showParametersConsole(Xs7977IEpa xsIEpa) {
		System.out.println("------------ ENTRADA ------------");
		System.out.println("REFERENCIA: " + xsIEpa.getReferencia());
		System.out.println("NUMSECPAG: " + xsIEpa.getNumsecpag());
		System.out.println("ENTIDAD: " + xsIEpa.getEntidad());	
		System.out.println("CENTRO: " + xsIEpa.getCentro());	
		System.out.println("REFERCON: " + xsIEpa.getRefercon());	
		System.out.println("TIPOASIG: " + xsIEpa.getTipoasig());	
		System.out.println("TIPOOPCI: " + xsIEpa.getTipoopci());	
		System.out.println("MODOASIG: " + xsIEpa.getModoasig());	
		System.out.println("CODITRAN: " + xsIEpa.getCoditran());	
		System.out.println("TRATCONT: " + xsIEpa.getTratcont());	
		System.out.println("TRATSWIFT: " + xsIEpa.getTratswift());	
		System.out.println("CODICOMP: " + xsIEpa.getCodicomp());	
		System.out.println("MENSWIFT: " + xsIEpa.getMenswift());	
		System.out.println("INDOURBEN: " + xsIEpa.getIndourben());	
		System.out.println("DIVSIAEMIS: " + xsIEpa.getDivisaEmis());	
		System.out.println("DIVICLIE: " + xsIEpa.getDiviclie());	
		System.out.println("CPAISDES: " + xsIEpa.getCpaisdes());	
		System.out.println("IMPOOPER: " + xsIEpa.getImpooper());	
		System.out.println("FVALOR: " + xsIEpa.getFvalor());	
		System.out.println("INDIBAN: " + xsIEpa.getIndiban());	
		System.out.println("IMPORTEORIGEN: " + xsIEpa.getImporteorigen());	
		System.out.println("TIPBENFI: " + xsIEpa.getTipbenefi());	
		System.out.println("CCCOFIO: " + xsIEpa.getCccOfiO());	
		System.out.println("CCCCTAO: " + xsIEpa.getCccCtaO());	
		System.out.println("NIFORD: " + xsIEpa.getNiford());	
		System.out.println("PAISRESORD: " + xsIEpa.getPaisresord());	
		System.out.println("FECHAVTO: " + xsIEpa.getFechaVto());	
		System.out.println("INFORECPRI: " + xsIEpa.getInforecPri()[0]);			
		System.out.println("DIVSIAG: " + xsIEpa.getDivisag());	
		System.out.println("BICDESTINO: " + xsIEpa.getBicdestino());	
		System.out.println("MT202RECEPTOR: " + xsIEpa.getMt202Receptor());	
		System.out.println("C56: " + xsIEpa.getPaisresord());	
		System.out.println("NOMPROGR: " + xsIEpa.getNomprogr());	
		System.out.println("CODUSUARIO: " + xsIEpa.getCodusuario());	
		System.out.println("CODTERMINA: " + xsIEpa.getCodtermina());	
		System.out.println("XS7377D DIVISA: " + xsIEpa.getXs7377D()[0].getDivisa());		
		System.out.println("XS7377IA NOMORDEN: " + xsIEpa.getXs7377Ia().getNombreOrden());	
		System.out.println("XS7377IA DIRORDEN: " + xsIEpa.getXs7377Ia().getDireccionOrden());	
		System.out.println("XS7377IA POBORDEN: " + xsIEpa.getXs7377Ia().getPoblOrden());	
     	System.out.println("P52 BICEMISO: " + xsIEpa.getP52BancoEmisor().getBicemiso());	
		System.out.println("C57 CODIPART: " + xsIEpa.getC57ABancoCuenta().getCodipart());	
		System.out.println("C57 CCDSWIFT: " + xsIEpa.getC57ABancoCuenta().getCcdSwift());		
		System.out.println("C58 CODIPART: " + xsIEpa.getC58BeneficiarioCobertura().getCodipart());
		System.out.println("C58 BICBEN: " + xsIEpa.getC58BeneficiarioCobertura().getBicBen());	
		System.out.println("CUENTABEN: " + xsIEpa.getCuentaben());
		System.out.println("NOMBREBEN: " + xsIEpa.getNombreben());
		System.out.println("DIRBEN: " + xsIEpa.getDirBen());
		System.out.println("POBBEN: " + xsIEpa.getPobBen());
		System.out.println("PAISBEN: " + xsIEpa.getPaisben());

	}

	public String login(String username2, String passTicket, String sessionId2) {
		// TODO Auto-generated method stub
		return null;
	}
	
	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}


	public String getEndPointLogin() {
		return endPointLogin;
	}

	public void setEndPointLogin(String endPointLogin) {
		this.endPointLogin = endPointLogin;
	}

	public String getProxyGrantingTicket() {
		return proxyGrantingTicket;
	}

	public void setProxyGrantingTicket(String proxyGrantingTicket) {
		this.proxyGrantingTicket = proxyGrantingTicket;
	}

	public void setEndPointGrantTicket(String endPointGrantTicket) {
		this.endPointGrantTicket = endPointGrantTicket;
	}

	public String getEndPointGrantTicket() {
		return endPointGrantTicket;
	}

	public String getEndPointXs7977() {
		return endPointXs7977;
	}

	public void setEndPointXs7977(String endPointXs7977) {
		this.endPointXs7977 = endPointXs7977;
	}

	public String getEndPointLoginOB() {
		return endPointLoginOB;
	}

	public void setEndPointLoginOB(String endPointLoginOB) {
		this.endPointLoginOB = endPointLoginOB;
	}

	public String getEndPointLogout() {
		return endPointLogout;
	}

	public void setEndPointLogout(String endPointLogout) {
		this.endPointLogout = endPointLogout;
	}

	public String getEndPointQuery() {
		return endPointQuery;
	}

	public void setEndPointQuery(String endPointQuery) {
		this.endPointQuery = endPointQuery;
	}

	public String getEndPointTest() {
		return endPointTest;
	}

	public void setEndPointTest(String endPointTest) {
		this.endPointTest = endPointTest;
	}
	
	private Xs7977IEpa inicializarIePACOLAT(Liquidacion liquidacion, Map<String, String> parametros, String referencia, Contrapartida contrapa, LiquidacionesBo liquidacionesBo, Date[] fechas) throws ParseException {
		
		Xs7977IEpa epa = new Xs7977IEpa();
		Swift swift = liquidacion.getSwift();
		
		epa.setReferencia(referencia);
		epa.setNumsecpag(BigInteger.valueOf(Long.valueOf(parametros.get("NUMSECPAG"))));
		epa.setEntidad(parametros.get("ENTIDAD"));
		epa.setCentro(parametros.get("CENTRO"));
		epa.setRefercon(parametros.get("APPID")+String.valueOf(liquidacion.getNcorrela())+formatearFecha(liquidacion.getFechaope(),"MMddyyyy")+formatearFecha(liquidacion.getFechaliq(),"MMddyyyy")+"0000"); 
		epa.setTipoasig(parametros.get("TIPOASIG"));
		epa.setTipoopci(parametros.get("TIPOOPCI"));
		epa.setModoasig(parametros.get("MODOASIG"));
		epa.setCoditran(parametros.get("CODITRAN"));
		epa.setTratcont(parametros.get("TRATCONT"));
		epa.setTratswift(parametros.get("TRATSWIFT"));
		epa.setTratbanc(parametros.get("TRATBANC"));
		
		if (contrapa.getTipoContrapartida().getId().equals("C")){
			epa.setTipbenefi("P");
			epa.setMenswift("MT103");
			epa.setIndourben("SHA"); // 02/10
		} else {
			epa.setTipbenefi("B");
			epa.setMenswift("MT202");
		}
		
		if(liquidacion.getDivisali().equals("EUR")){
			if(contrapa.getCodigoPais().getIdSW().equals("ES")){
				epa.setCodicomp("TGR");
			} else epa.setCodicomp("TG2");
		} else {
			epa.setCodicomp("COR");
		}
	
		epa.setDivisaEmis(swift.getCodivisa()); 
		epa.setDiviclie(swift.getCodivisa());
		epa.setCpaisdes(contrapa.getCodigoPais().getIdSW());
		
		epa.setImpooper(liquidacion.getImportel().setScale(2, BigDecimal.ROUND_HALF_EVEN));

		epa.setFvalor(formatearFecha(liquidacion.getFechaliq(), "yyyyMMdd"));
		
		Date today = fechas[0];
		Date fechamis1 = fechas[1];
		Date fechamis2 = fechas[2];
		
		if(swift.getCodivisa().equals("EUR") || swift.getCodivisa().equals("GBP") || swift.getCodivisa().equals("USD") || swift.getCodivisa().equals("BRL")){
			if(liquidacion.getFechaliq().before(today)){
				epa.setFvalor(formatearFecha(today, "yyyyMMdd"));
			}
		} else if(swift.getCodivisa().equals("JPY")){
			if(fechamis2.before(today)){
				epa.setFvalor(formatearFecha(fechamis2, "yyyyMMdd"));
			}
		} else {
			if(liquidacion.getFechaliq().before(fechamis1) || liquidacion.getFechaliq().equals(fechamis1)){
				epa.setFvalor(formatearFecha(fechamis1, "yyyyMMdd"));
			}
		}
		
		// 02/10
		if (epa.getTipbenefi().equals("P")) {
			epa.setCuentaben(swift.getBbenecta()!=null?swift.getBbenecta():"");
			epa.setNombreben(swift.getBbenefl1()!=null?swift.getBbenefl1():"");
			epa.setDirBen(swift.getBbenefl2()!=null?swift.getBbenefl2():"");
			epa.setPobBen(swift.getBbenefl3()!=null?swift.getBbenefl3():"");
			epa.setPaisben(swift.getBbenefl4()!=null?swift.getBbenefl4().substring(0,2):"");			
		}
		
		epa.setIndiban(parametros.get("INDIBAN"));
		epa.setImporteorigen(BigDecimal.valueOf(Long.valueOf(parametros.get("IMPORIGEN"))));

		epa.setCccOfiO(parametros.get("CCCOFIO"));
		epa.setCccCtaO(parametros.get("CCCCTAO"));
		epa.setNiford(parametros.get("NIFORD"));
		epa.setPaisresord(parametros.get("PAISRESORD"));
		String[] inforecpri = {swift.getObservl1()!=null?swift.getObservl1():""}; //String[] inforecpri = {"FFC TO DEUTGB2L"};
		epa.setInforecPri(inforecpri);
		epa.setDivisag("0");
		epa.setP53ACorresp(swift.getBdbenel1());
		epa.setP56AIntermed(swift.getIntercod());
		epa.setC56PartyInter(swift.getIntercta());
		epa.setNomprogr(parametros.get("NOMPROGR"));
		epa.setCodusuario(Identity.instance().getCredentials().getUsername());
		epa.setCodtermina(parametros.get("CODTERMINA"));

		/** Xs7377D: divisa, BigDecimal importe71F*/
		Xs7377D XsD = new Xs7377D("0",null);
		Xs7377D[] arrayXs7377D = {XsD};
		epa.setXs7377D(arrayXs7377D);
		
		/**Xs7377Ia String, String, String */
		Xs7377Ia XsIa = new Xs7377Ia(parametros.get("NOMORDEN"),parametros.get("DIRORDEN"),parametros.get("POBORDEN")); 
		epa.setXs7377Ia(XsIa);
		
		P52BancoEmisor p52 = new P52BancoEmisor();
		if (liquidacion.getEntioper() == 81 ){
			p52.setBicemiso("BSABESBBXXX");
		} else 	p52.setBicemiso("BSABESBBSBP");
		
		epa.setP52BancoEmisor(p52);
		
		/** P57BancoBeneficiario: codipart, bicben*/
		P57BancoBeneficiario p57 = new P57BancoBeneficiario(null, null, null, null, null, null); 
		/** C57ABancoCuenta: codipart, ccdSwift*/
		C57ABancoCuenta c57 = new C57ABancoCuenta(null, null);
		if (epa.getTipbenefi().equals("P")) {
			epa.setBicdestino(swift.getTiddesti());
			p57.setCodipart(swift.getBdbencta()!=null?swift.getBdbencta():"");
			p57.setBicBen(swift.getBdbencod()!=null?swift.getBdbencod():"");
		} else {
			epa.setMt202Receptor(swift.getTiddesti());
			c57.setCodipart(swift.getBdbencta()!=null?swift.getBdbencta():"");
			c57.setCcdSwift(swift.getBdbencod()!=null?swift.getBdbencod():"");
		}
		epa.setP57BancoBeneficiario(p57);
		epa.setC57ABancoCuenta(c57);
		
		/** C58BeneficiarioCobertura: codipart,bicBen,banBen,dirBan,pobBan,paiBan */
		C58BeneficiarioCobertura c58 = new C58BeneficiarioCobertura(null,null,null,null,null,null);
		if(epa.getTipbenefi().equals("B")){
			c58.setCodipart(swift.getBbenecta()!=null?swift.getBbenecta():"");
			c58.setBicBen(swift.getBbenecod()!=null?swift.getBbenecod():"");
		}
		
		epa.setC58BeneficiarioCobertura(c58);
		
		return epa;
	}
	
	/*
	 * Si fecha = null entonces fecha = fecha actual
	 */
	public String formatearFecha (Date fecha, String formato){
		DateFormat dateFormat = new SimpleDateFormat(formato);
		if (fecha == null){
			fecha = new Date();
		}
		return dateFormat.format(fecha);
	}

}
