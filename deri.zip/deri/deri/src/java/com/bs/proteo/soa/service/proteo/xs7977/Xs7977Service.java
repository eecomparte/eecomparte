/**
 * Xs7977Service.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.bs.proteo.soa.service.proteo.xs7977;

public interface Xs7977Service extends java.rmi.Remote {
    public com.bs.proteo.soa.service.proteo.xs7977.xs7977.domain.message.Xs7977Response xs7977(com.bs.proteo.soa.service.proteo.xs7977.xs7977.domain.message.Xs7977Request request) throws java.rmi.RemoteException, com.bancsabadell.xmlns.proteo.SharedResources.ErrorSchema.FaultInfo;
}
