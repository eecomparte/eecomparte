package com.bs.proteo.soa.service.proteo.xs7977;

public class Xs7977ServiceProxy implements com.bs.proteo.soa.service.proteo.xs7977.Xs7977Service {
  private String _endpoint = null;
  private com.bs.proteo.soa.service.proteo.xs7977.Xs7977Service xs7977Service = null;
  
  public Xs7977ServiceProxy() {
    _initXs7977ServiceProxy();
  }
  
  public Xs7977ServiceProxy(String endpoint) {
    _endpoint = endpoint;
    _initXs7977ServiceProxy();
  }
  
  private void _initXs7977ServiceProxy() {
    try {
      xs7977Service = (new com.bs.proteo.soa.service.proteo.xs7977.Xs7977ServiceSoapBindingLocator()).getXs7977Service();
      if (xs7977Service != null) {
        if (_endpoint != null)
          ((javax.xml.rpc.Stub)xs7977Service)._setProperty("javax.xml.rpc.service.endpoint.address", _endpoint);
        else
          _endpoint = (String)((javax.xml.rpc.Stub)xs7977Service)._getProperty("javax.xml.rpc.service.endpoint.address");
      }
      
    }
    catch (javax.xml.rpc.ServiceException serviceException) {}
  }
  
  public String getEndpoint() {
    return _endpoint;
  }
  
  public void setEndpoint(String endpoint) {
    _endpoint = endpoint;
    if (xs7977Service != null)
      ((javax.xml.rpc.Stub)xs7977Service)._setProperty("javax.xml.rpc.service.endpoint.address", _endpoint);
    
  }
  
  public com.bs.proteo.soa.service.proteo.xs7977.Xs7977Service getXs7977Service() {
    if (xs7977Service == null)
      _initXs7977ServiceProxy();
    return xs7977Service;
  }
  
  public com.bs.proteo.soa.service.proteo.xs7977.xs7977.domain.message.Xs7977Response xs7977(com.bs.proteo.soa.service.proteo.xs7977.xs7977.domain.message.Xs7977Request request) throws java.rmi.RemoteException, com.bancsabadell.xmlns.proteo.SharedResources.ErrorSchema.FaultInfo{
    if (xs7977Service == null)
      _initXs7977ServiceProxy();
    return xs7977Service.xs7977(request);
  }
  
  
}