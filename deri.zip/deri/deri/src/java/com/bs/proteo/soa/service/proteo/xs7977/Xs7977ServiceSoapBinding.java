/**
 * Xs7977ServiceSoapBinding.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.bs.proteo.soa.service.proteo.xs7977;

public interface Xs7977ServiceSoapBinding extends javax.xml.rpc.Service {
    public java.lang.String getXs7977ServiceAddress();

    public com.bs.proteo.soa.service.proteo.xs7977.Xs7977Service getXs7977Service() throws javax.xml.rpc.ServiceException;

    public com.bs.proteo.soa.service.proteo.xs7977.Xs7977Service getXs7977Service(java.net.URL portAddress) throws javax.xml.rpc.ServiceException;
}
