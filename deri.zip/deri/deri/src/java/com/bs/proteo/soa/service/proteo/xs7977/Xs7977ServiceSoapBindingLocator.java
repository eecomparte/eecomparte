/**
 * Xs7977ServiceSoapBindingLocator.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.bs.proteo.soa.service.proteo.xs7977;

public class Xs7977ServiceSoapBindingLocator extends org.apache.axis.client.Service implements com.bs.proteo.soa.service.proteo.xs7977.Xs7977ServiceSoapBinding {

    public Xs7977ServiceSoapBindingLocator() {
    }


    public Xs7977ServiceSoapBindingLocator(org.apache.axis.EngineConfiguration config) {
        super(config);
    }

    public Xs7977ServiceSoapBindingLocator(java.lang.String wsdlLoc, javax.xml.namespace.QName sName) throws javax.xml.rpc.ServiceException {
        super(wsdlLoc, sName);
    }

    // Use to get a proxy class for Xs7977Service
    private java.lang.String Xs7977Service_address = "http://172.18.48.82:9015/soa/service/proteo/xs7977/Xs7977Service";

    public java.lang.String getXs7977ServiceAddress() {
        return Xs7977Service_address;
    }

    // The WSDD service name defaults to the port name.
    private java.lang.String Xs7977ServiceWSDDServiceName = "Xs7977Service";

    public java.lang.String getXs7977ServiceWSDDServiceName() {
        return Xs7977ServiceWSDDServiceName;
    }

    public void setXs7977ServiceWSDDServiceName(java.lang.String name) {
        Xs7977ServiceWSDDServiceName = name;
    }

    public com.bs.proteo.soa.service.proteo.xs7977.Xs7977Service getXs7977Service() throws javax.xml.rpc.ServiceException {
       java.net.URL endpoint;
        try {
            endpoint = new java.net.URL(Xs7977Service_address);
        }
        catch (java.net.MalformedURLException e) {
            throw new javax.xml.rpc.ServiceException(e);
        }
        return getXs7977Service(endpoint);
    }

    public com.bs.proteo.soa.service.proteo.xs7977.Xs7977Service getXs7977Service(java.net.URL portAddress) throws javax.xml.rpc.ServiceException {
        try {
            com.bs.proteo.soa.service.proteo.xs7977.Xs7977ServiceStub _stub = new com.bs.proteo.soa.service.proteo.xs7977.Xs7977ServiceStub(portAddress, this);
            _stub.setPortName(getXs7977ServiceWSDDServiceName());
            return _stub;
        }
        catch (org.apache.axis.AxisFault e) {
            return null;
        }
    }

    public void setXs7977ServiceEndpointAddress(java.lang.String address) {
        Xs7977Service_address = address;
    }

    /**
     * For the given interface, get the stub implementation.
     * If this service has no port for the given interface,
     * then ServiceException is thrown.
     */
    public java.rmi.Remote getPort(Class serviceEndpointInterface) throws javax.xml.rpc.ServiceException {
        try {
            if (com.bs.proteo.soa.service.proteo.xs7977.Xs7977Service.class.isAssignableFrom(serviceEndpointInterface)) {
                com.bs.proteo.soa.service.proteo.xs7977.Xs7977ServiceStub _stub = new com.bs.proteo.soa.service.proteo.xs7977.Xs7977ServiceStub(new java.net.URL(Xs7977Service_address), this);
                _stub.setPortName(getXs7977ServiceWSDDServiceName());
                return _stub;
            }
        }
        catch (java.lang.Throwable t) {
            throw new javax.xml.rpc.ServiceException(t);
        }
        throw new javax.xml.rpc.ServiceException("There is no stub implementation for the interface:  " + (serviceEndpointInterface == null ? "null" : serviceEndpointInterface.getName()));
    }

    /**
     * For the given interface, get the stub implementation.
     * If this service has no port for the given interface,
     * then ServiceException is thrown.
     */
    public java.rmi.Remote getPort(javax.xml.namespace.QName portName, Class serviceEndpointInterface) throws javax.xml.rpc.ServiceException {
        if (portName == null) {
            return getPort(serviceEndpointInterface);
        }
        java.lang.String inputPortName = portName.getLocalPart();
        if ("Xs7977Service".equals(inputPortName)) {
            return getXs7977Service();
        }
        else  {
            java.rmi.Remote _stub = getPort(serviceEndpointInterface);
            ((org.apache.axis.client.Stub) _stub).setPortName(portName);
            return _stub;
        }
    }

    public javax.xml.namespace.QName getServiceName() {
        return new javax.xml.namespace.QName("http://proteo.bs.com/soa/service/proteo/xs7977/", "Xs7977ServiceSoapBinding");
    }

    private java.util.HashSet ports = null;

    public java.util.Iterator getPorts() {
        if (ports == null) {
            ports = new java.util.HashSet();
            ports.add(new javax.xml.namespace.QName("http://proteo.bs.com/soa/service/proteo/xs7977/", "Xs7977Service"));
        }
        return ports.iterator();
    }

    /**
    * Set the endpoint address for the specified port name.
    */
    public void setEndpointAddress(java.lang.String portName, java.lang.String address) throws javax.xml.rpc.ServiceException {
        
if ("Xs7977Service".equals(portName)) {
            setXs7977ServiceEndpointAddress(address);
        }
        else 
{ // Unknown Port Name
            throw new javax.xml.rpc.ServiceException(" Cannot set Endpoint Address for Unknown Port" + portName);
        }
    }

    /**
    * Set the endpoint address for the specified port name.
    */
    public void setEndpointAddress(javax.xml.namespace.QName portName, java.lang.String address) throws javax.xml.rpc.ServiceException {
        setEndpointAddress(portName.getLocalPart(), address);
    }

}
