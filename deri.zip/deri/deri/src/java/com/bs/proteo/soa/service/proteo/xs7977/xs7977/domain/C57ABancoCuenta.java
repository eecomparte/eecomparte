/**
 * C57ABancoCuenta.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.bs.proteo.soa.service.proteo.xs7977.xs7977.domain;

public class C57ABancoCuenta  implements java.io.Serializable {
    private java.lang.String codipart;

    private java.lang.String ccdSwift;

    public C57ABancoCuenta() {
    }

    public C57ABancoCuenta(
           java.lang.String codipart,
           java.lang.String ccdSwift) {
           this.codipart = codipart;
           this.ccdSwift = ccdSwift;
    }


    /**
     * Gets the codipart value for this C57ABancoCuenta.
     * 
     * @return codipart
     */
    public java.lang.String getCodipart() {
        return codipart;
    }


    /**
     * Sets the codipart value for this C57ABancoCuenta.
     * 
     * @param codipart
     */
    public void setCodipart(java.lang.String codipart) {
        this.codipart = codipart;
    }


    /**
     * Gets the ccdSwift value for this C57ABancoCuenta.
     * 
     * @return ccdSwift
     */
    public java.lang.String getCcdSwift() {
        return ccdSwift;
    }


    /**
     * Sets the ccdSwift value for this C57ABancoCuenta.
     * 
     * @param ccdSwift
     */
    public void setCcdSwift(java.lang.String ccdSwift) {
        this.ccdSwift = ccdSwift;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof C57ABancoCuenta)) return false;
        C57ABancoCuenta other = (C57ABancoCuenta) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            ((this.codipart==null && other.getCodipart()==null) || 
             (this.codipart!=null &&
              this.codipart.equals(other.getCodipart()))) &&
            ((this.ccdSwift==null && other.getCcdSwift()==null) || 
             (this.ccdSwift!=null &&
              this.ccdSwift.equals(other.getCcdSwift())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getCodipart() != null) {
            _hashCode += getCodipart().hashCode();
        }
        if (getCcdSwift() != null) {
            _hashCode += getCcdSwift().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(C57ABancoCuenta.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://proteo.bs.com/soa/service/proteo/xs7977/xs7977/domain/", "c57ABancoCuenta"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("codipart");
        elemField.setXmlName(new javax.xml.namespace.QName("http://proteo.bs.com/soa/service/proteo/xs7977/xs7977/domain/", "codipart"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("ccdSwift");
        elemField.setXmlName(new javax.xml.namespace.QName("http://proteo.bs.com/soa/service/proteo/xs7977/xs7977/domain/", "ccdSwift"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
