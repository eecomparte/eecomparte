/**
 * P52BancoEmisor.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.bs.proteo.soa.service.proteo.xs7977.xs7977.domain;

public class P52BancoEmisor  implements java.io.Serializable {
    private java.lang.String bicemiso;

    private java.lang.String nombbemi;

    private java.lang.String direbemi;

    private java.lang.String poblbemi;

    private java.lang.String paisbemi;

    public P52BancoEmisor() {
    }

    public P52BancoEmisor(
           java.lang.String bicemiso,
           java.lang.String nombbemi,
           java.lang.String direbemi,
           java.lang.String poblbemi,
           java.lang.String paisbemi) {
           this.bicemiso = bicemiso;
           this.nombbemi = nombbemi;
           this.direbemi = direbemi;
           this.poblbemi = poblbemi;
           this.paisbemi = paisbemi;
    }


    /**
     * Gets the bicemiso value for this P52BancoEmisor.
     * 
     * @return bicemiso
     */
    public java.lang.String getBicemiso() {
        return bicemiso;
    }


    /**
     * Sets the bicemiso value for this P52BancoEmisor.
     * 
     * @param bicemiso
     */
    public void setBicemiso(java.lang.String bicemiso) {
        this.bicemiso = bicemiso;
    }


    /**
     * Gets the nombbemi value for this P52BancoEmisor.
     * 
     * @return nombbemi
     */
    public java.lang.String getNombbemi() {
        return nombbemi;
    }


    /**
     * Sets the nombbemi value for this P52BancoEmisor.
     * 
     * @param nombbemi
     */
    public void setNombbemi(java.lang.String nombbemi) {
        this.nombbemi = nombbemi;
    }


    /**
     * Gets the direbemi value for this P52BancoEmisor.
     * 
     * @return direbemi
     */
    public java.lang.String getDirebemi() {
        return direbemi;
    }


    /**
     * Sets the direbemi value for this P52BancoEmisor.
     * 
     * @param direbemi
     */
    public void setDirebemi(java.lang.String direbemi) {
        this.direbemi = direbemi;
    }


    /**
     * Gets the poblbemi value for this P52BancoEmisor.
     * 
     * @return poblbemi
     */
    public java.lang.String getPoblbemi() {
        return poblbemi;
    }


    /**
     * Sets the poblbemi value for this P52BancoEmisor.
     * 
     * @param poblbemi
     */
    public void setPoblbemi(java.lang.String poblbemi) {
        this.poblbemi = poblbemi;
    }


    /**
     * Gets the paisbemi value for this P52BancoEmisor.
     * 
     * @return paisbemi
     */
    public java.lang.String getPaisbemi() {
        return paisbemi;
    }


    /**
     * Sets the paisbemi value for this P52BancoEmisor.
     * 
     * @param paisbemi
     */
    public void setPaisbemi(java.lang.String paisbemi) {
        this.paisbemi = paisbemi;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof P52BancoEmisor)) return false;
        P52BancoEmisor other = (P52BancoEmisor) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            ((this.bicemiso==null && other.getBicemiso()==null) || 
             (this.bicemiso!=null &&
              this.bicemiso.equals(other.getBicemiso()))) &&
            ((this.nombbemi==null && other.getNombbemi()==null) || 
             (this.nombbemi!=null &&
              this.nombbemi.equals(other.getNombbemi()))) &&
            ((this.direbemi==null && other.getDirebemi()==null) || 
             (this.direbemi!=null &&
              this.direbemi.equals(other.getDirebemi()))) &&
            ((this.poblbemi==null && other.getPoblbemi()==null) || 
             (this.poblbemi!=null &&
              this.poblbemi.equals(other.getPoblbemi()))) &&
            ((this.paisbemi==null && other.getPaisbemi()==null) || 
             (this.paisbemi!=null &&
              this.paisbemi.equals(other.getPaisbemi())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getBicemiso() != null) {
            _hashCode += getBicemiso().hashCode();
        }
        if (getNombbemi() != null) {
            _hashCode += getNombbemi().hashCode();
        }
        if (getDirebemi() != null) {
            _hashCode += getDirebemi().hashCode();
        }
        if (getPoblbemi() != null) {
            _hashCode += getPoblbemi().hashCode();
        }
        if (getPaisbemi() != null) {
            _hashCode += getPaisbemi().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(P52BancoEmisor.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://proteo.bs.com/soa/service/proteo/xs7977/xs7977/domain/", "p52BancoEmisor"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("bicemiso");
        elemField.setXmlName(new javax.xml.namespace.QName("http://proteo.bs.com/soa/service/proteo/xs7977/xs7977/domain/", "bicemiso"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("nombbemi");
        elemField.setXmlName(new javax.xml.namespace.QName("http://proteo.bs.com/soa/service/proteo/xs7977/xs7977/domain/", "nombbemi"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("direbemi");
        elemField.setXmlName(new javax.xml.namespace.QName("http://proteo.bs.com/soa/service/proteo/xs7977/xs7977/domain/", "direbemi"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("poblbemi");
        elemField.setXmlName(new javax.xml.namespace.QName("http://proteo.bs.com/soa/service/proteo/xs7977/xs7977/domain/", "poblbemi"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("paisbemi");
        elemField.setXmlName(new javax.xml.namespace.QName("http://proteo.bs.com/soa/service/proteo/xs7977/xs7977/domain/", "paisbemi"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
