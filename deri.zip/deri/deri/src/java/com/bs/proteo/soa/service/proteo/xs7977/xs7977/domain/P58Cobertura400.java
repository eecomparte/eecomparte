/**
 * P58Cobertura400.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.bs.proteo.soa.service.proteo.xs7977.xs7977.domain;

public class P58Cobertura400  implements java.io.Serializable {
    private java.lang.String codipart;

    private java.lang.String bicBen;

    private java.lang.String banBen;

    private java.lang.String dirBan;

    private java.lang.String pobBan;

    private java.lang.String paiBan;

    public P58Cobertura400() {
    }

    public P58Cobertura400(
           java.lang.String codipart,
           java.lang.String bicBen,
           java.lang.String banBen,
           java.lang.String dirBan,
           java.lang.String pobBan,
           java.lang.String paiBan) {
           this.codipart = codipart;
           this.bicBen = bicBen;
           this.banBen = banBen;
           this.dirBan = dirBan;
           this.pobBan = pobBan;
           this.paiBan = paiBan;
    }


    /**
     * Gets the codipart value for this P58Cobertura400.
     * 
     * @return codipart
     */
    public java.lang.String getCodipart() {
        return codipart;
    }


    /**
     * Sets the codipart value for this P58Cobertura400.
     * 
     * @param codipart
     */
    public void setCodipart(java.lang.String codipart) {
        this.codipart = codipart;
    }


    /**
     * Gets the bicBen value for this P58Cobertura400.
     * 
     * @return bicBen
     */
    public java.lang.String getBicBen() {
        return bicBen;
    }


    /**
     * Sets the bicBen value for this P58Cobertura400.
     * 
     * @param bicBen
     */
    public void setBicBen(java.lang.String bicBen) {
        this.bicBen = bicBen;
    }


    /**
     * Gets the banBen value for this P58Cobertura400.
     * 
     * @return banBen
     */
    public java.lang.String getBanBen() {
        return banBen;
    }


    /**
     * Sets the banBen value for this P58Cobertura400.
     * 
     * @param banBen
     */
    public void setBanBen(java.lang.String banBen) {
        this.banBen = banBen;
    }


    /**
     * Gets the dirBan value for this P58Cobertura400.
     * 
     * @return dirBan
     */
    public java.lang.String getDirBan() {
        return dirBan;
    }


    /**
     * Sets the dirBan value for this P58Cobertura400.
     * 
     * @param dirBan
     */
    public void setDirBan(java.lang.String dirBan) {
        this.dirBan = dirBan;
    }


    /**
     * Gets the pobBan value for this P58Cobertura400.
     * 
     * @return pobBan
     */
    public java.lang.String getPobBan() {
        return pobBan;
    }


    /**
     * Sets the pobBan value for this P58Cobertura400.
     * 
     * @param pobBan
     */
    public void setPobBan(java.lang.String pobBan) {
        this.pobBan = pobBan;
    }


    /**
     * Gets the paiBan value for this P58Cobertura400.
     * 
     * @return paiBan
     */
    public java.lang.String getPaiBan() {
        return paiBan;
    }


    /**
     * Sets the paiBan value for this P58Cobertura400.
     * 
     * @param paiBan
     */
    public void setPaiBan(java.lang.String paiBan) {
        this.paiBan = paiBan;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof P58Cobertura400)) return false;
        P58Cobertura400 other = (P58Cobertura400) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            ((this.codipart==null && other.getCodipart()==null) || 
             (this.codipart!=null &&
              this.codipart.equals(other.getCodipart()))) &&
            ((this.bicBen==null && other.getBicBen()==null) || 
             (this.bicBen!=null &&
              this.bicBen.equals(other.getBicBen()))) &&
            ((this.banBen==null && other.getBanBen()==null) || 
             (this.banBen!=null &&
              this.banBen.equals(other.getBanBen()))) &&
            ((this.dirBan==null && other.getDirBan()==null) || 
             (this.dirBan!=null &&
              this.dirBan.equals(other.getDirBan()))) &&
            ((this.pobBan==null && other.getPobBan()==null) || 
             (this.pobBan!=null &&
              this.pobBan.equals(other.getPobBan()))) &&
            ((this.paiBan==null && other.getPaiBan()==null) || 
             (this.paiBan!=null &&
              this.paiBan.equals(other.getPaiBan())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getCodipart() != null) {
            _hashCode += getCodipart().hashCode();
        }
        if (getBicBen() != null) {
            _hashCode += getBicBen().hashCode();
        }
        if (getBanBen() != null) {
            _hashCode += getBanBen().hashCode();
        }
        if (getDirBan() != null) {
            _hashCode += getDirBan().hashCode();
        }
        if (getPobBan() != null) {
            _hashCode += getPobBan().hashCode();
        }
        if (getPaiBan() != null) {
            _hashCode += getPaiBan().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(P58Cobertura400.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://proteo.bs.com/soa/service/proteo/xs7977/xs7977/domain/", "p58Cobertura400"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("codipart");
        elemField.setXmlName(new javax.xml.namespace.QName("http://proteo.bs.com/soa/service/proteo/xs7977/xs7977/domain/", "codipart"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("bicBen");
        elemField.setXmlName(new javax.xml.namespace.QName("http://proteo.bs.com/soa/service/proteo/xs7977/xs7977/domain/", "bicBen"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("banBen");
        elemField.setXmlName(new javax.xml.namespace.QName("http://proteo.bs.com/soa/service/proteo/xs7977/xs7977/domain/", "banBen"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("dirBan");
        elemField.setXmlName(new javax.xml.namespace.QName("http://proteo.bs.com/soa/service/proteo/xs7977/xs7977/domain/", "dirBan"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("pobBan");
        elemField.setXmlName(new javax.xml.namespace.QName("http://proteo.bs.com/soa/service/proteo/xs7977/xs7977/domain/", "pobBan"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("paiBan");
        elemField.setXmlName(new javax.xml.namespace.QName("http://proteo.bs.com/soa/service/proteo/xs7977/xs7977/domain/", "paiBan"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
