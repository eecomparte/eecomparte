/**
 * Xs7377A.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.bs.proteo.soa.service.proteo.xs7977.xs7977.domain;

public class Xs7377A  implements java.io.Serializable {
    private java.lang.String codeword23E;

    private java.lang.String literal23E;

    public Xs7377A() {
    }

    public Xs7377A(
           java.lang.String codeword23E,
           java.lang.String literal23E) {
           this.codeword23E = codeword23E;
           this.literal23E = literal23E;
    }


    /**
     * Gets the codeword23E value for this Xs7377A.
     * 
     * @return codeword23E
     */
    public java.lang.String getCodeword23E() {
        return codeword23E;
    }


    /**
     * Sets the codeword23E value for this Xs7377A.
     * 
     * @param codeword23E
     */
    public void setCodeword23E(java.lang.String codeword23E) {
        this.codeword23E = codeword23E;
    }


    /**
     * Gets the literal23E value for this Xs7377A.
     * 
     * @return literal23E
     */
    public java.lang.String getLiteral23E() {
        return literal23E;
    }


    /**
     * Sets the literal23E value for this Xs7377A.
     * 
     * @param literal23E
     */
    public void setLiteral23E(java.lang.String literal23E) {
        this.literal23E = literal23E;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof Xs7377A)) return false;
        Xs7377A other = (Xs7377A) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            ((this.codeword23E==null && other.getCodeword23E()==null) || 
             (this.codeword23E!=null &&
              this.codeword23E.equals(other.getCodeword23E()))) &&
            ((this.literal23E==null && other.getLiteral23E()==null) || 
             (this.literal23E!=null &&
              this.literal23E.equals(other.getLiteral23E())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getCodeword23E() != null) {
            _hashCode += getCodeword23E().hashCode();
        }
        if (getLiteral23E() != null) {
            _hashCode += getLiteral23E().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(Xs7377A.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://proteo.bs.com/soa/service/proteo/xs7977/xs7977/domain/", "xs7377A"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("codeword23E");
        elemField.setXmlName(new javax.xml.namespace.QName("http://proteo.bs.com/soa/service/proteo/xs7977/xs7977/domain/", "codeword23E"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("literal23E");
        elemField.setXmlName(new javax.xml.namespace.QName("http://proteo.bs.com/soa/service/proteo/xs7977/xs7977/domain/", "literal23E"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
