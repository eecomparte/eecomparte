/**
 * Xs7377Ia.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.bs.proteo.soa.service.proteo.xs7977.xs7977.domain;

public class Xs7377Ia  implements java.io.Serializable {
    private java.lang.String nombreOrden;

    private java.lang.String direccionOrden;

    private java.lang.String poblOrden;

    public Xs7377Ia() {
    }

    public Xs7377Ia(
           java.lang.String nombreOrden,
           java.lang.String direccionOrden,
           java.lang.String poblOrden) {
           this.nombreOrden = nombreOrden;
           this.direccionOrden = direccionOrden;
           this.poblOrden = poblOrden;
    }


    /**
     * Gets the nombreOrden value for this Xs7377Ia.
     * 
     * @return nombreOrden
     */
    public java.lang.String getNombreOrden() {
        return nombreOrden;
    }


    /**
     * Sets the nombreOrden value for this Xs7377Ia.
     * 
     * @param nombreOrden
     */
    public void setNombreOrden(java.lang.String nombreOrden) {
        this.nombreOrden = nombreOrden;
    }


    /**
     * Gets the direccionOrden value for this Xs7377Ia.
     * 
     * @return direccionOrden
     */
    public java.lang.String getDireccionOrden() {
        return direccionOrden;
    }


    /**
     * Sets the direccionOrden value for this Xs7377Ia.
     * 
     * @param direccionOrden
     */
    public void setDireccionOrden(java.lang.String direccionOrden) {
        this.direccionOrden = direccionOrden;
    }


    /**
     * Gets the poblOrden value for this Xs7377Ia.
     * 
     * @return poblOrden
     */
    public java.lang.String getPoblOrden() {
        return poblOrden;
    }


    /**
     * Sets the poblOrden value for this Xs7377Ia.
     * 
     * @param poblOrden
     */
    public void setPoblOrden(java.lang.String poblOrden) {
        this.poblOrden = poblOrden;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof Xs7377Ia)) return false;
        Xs7377Ia other = (Xs7377Ia) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            ((this.nombreOrden==null && other.getNombreOrden()==null) || 
             (this.nombreOrden!=null &&
              this.nombreOrden.equals(other.getNombreOrden()))) &&
            ((this.direccionOrden==null && other.getDireccionOrden()==null) || 
             (this.direccionOrden!=null &&
              this.direccionOrden.equals(other.getDireccionOrden()))) &&
            ((this.poblOrden==null && other.getPoblOrden()==null) || 
             (this.poblOrden!=null &&
              this.poblOrden.equals(other.getPoblOrden())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getNombreOrden() != null) {
            _hashCode += getNombreOrden().hashCode();
        }
        if (getDireccionOrden() != null) {
            _hashCode += getDireccionOrden().hashCode();
        }
        if (getPoblOrden() != null) {
            _hashCode += getPoblOrden().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(Xs7377Ia.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://proteo.bs.com/soa/service/proteo/xs7977/xs7977/domain/", "xs7377Ia"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("nombreOrden");
        elemField.setXmlName(new javax.xml.namespace.QName("http://proteo.bs.com/soa/service/proteo/xs7977/xs7977/domain/", "nombreOrden"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("direccionOrden");
        elemField.setXmlName(new javax.xml.namespace.QName("http://proteo.bs.com/soa/service/proteo/xs7977/xs7977/domain/", "direccionOrden"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("poblOrden");
        elemField.setXmlName(new javax.xml.namespace.QName("http://proteo.bs.com/soa/service/proteo/xs7977/xs7977/domain/", "poblOrden"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
