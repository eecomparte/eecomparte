/**
 * Xs7977IEpa.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.bs.proteo.soa.service.proteo.xs7977.xs7977.domain;

public class Xs7977IEpa  implements java.io.Serializable {
    private java.lang.String referencia;

    private java.math.BigInteger numsecpag;

    private java.lang.String entidad;

    private java.lang.String centro;

    private java.lang.String refercon;

    private java.lang.String tipoasig;

    private java.lang.String tipoopci;

    private java.lang.String modoasig;

    private java.lang.String tipoent;

    private java.lang.String coditran;

    private java.lang.String tratcont;

    private java.lang.String tratswift;

    private java.lang.String tratbanc;

    private java.lang.String codicomp;

    private java.lang.String menswift;

    private java.lang.String divisaEmis;

    private java.lang.String diviclie;

    private java.lang.String cpaisdes;

    private java.lang.String cpaisfon;

    private java.math.BigDecimal impooper;

    private java.lang.String fvalor;

    private java.lang.String indiban;

    private java.lang.String tipent;

    private java.lang.String campo21;

    private java.lang.String divisaorigen;

    private java.math.BigDecimal importeorigen;

    private java.lang.String cambio;

    private java.math.BigDecimal cambio36;

    private java.math.BigInteger fechaVto;

    private java.lang.String descripVto1;

    private java.lang.String tipbenefi;

    private java.lang.String cuentaben;

    private java.lang.String beibene;

    private java.lang.String nombreben;

    private java.lang.String dirBen;

    private java.lang.String pobBen;

    private java.lang.String paisben;

    private java.lang.String ctacord;

    private java.lang.String cccOfiO;

    private java.lang.String cccCtaO;

    private java.lang.String niford;

    private com.bs.proteo.soa.service.proteo.xs7977.xs7977.domain.Xs7377Ia xs7377Ia;

    private java.lang.String paisresord;

    private java.lang.String devoaut;

    private java.lang.String step2;

    private java.lang.String codrefdev;

    private java.lang.String fecopeori01;

    private java.lang.String motivdev;

    private java.lang.String motdevoltxt;

    private java.lang.String[] infoemis;

    private java.lang.String[] inforecPri;

    private java.lang.String[] inforecCob;

    private java.lang.String codimotp;

    private java.lang.String indourben;

    private java.lang.String divisag;

    private java.math.BigDecimal importe71F1;

    private com.bs.proteo.soa.service.proteo.xs7977.xs7977.domain.Xs7377D[] xs7377D;

    private java.lang.String[] gastd71B;

    private java.lang.String[] gastosa73;

    private java.lang.String[] regrep77B;

    private com.bs.proteo.soa.service.proteo.xs7977.xs7977.domain.Xs7377A[] xs7377A;

    private java.lang.String campo23B;

    private java.lang.String bicdestino;

    private com.bs.proteo.soa.service.proteo.xs7977.xs7977.domain.P52BancoEmisor p52BancoEmisor;

    private com.bs.proteo.soa.service.proteo.xs7977.xs7977.domain.P57BancoBeneficiario p57BancoBeneficiario;

    private com.bs.proteo.soa.service.proteo.xs7977.xs7977.domain.P58Cobertura400 p58Cobertura400;

    private java.lang.String p53ACorresp;

    private java.lang.String p54ACorresr;

    private java.lang.String p56AIntermed;

    private java.lang.String mt202Receptor;

    private java.lang.String c54ACorresp;

    private java.lang.String c56PartyInter;

    private java.lang.String c56ABicIntermediario;

    private com.bs.proteo.soa.service.proteo.xs7977.xs7977.domain.C57ABancoCuenta c57ABancoCuenta;

    private com.bs.proteo.soa.service.proteo.xs7977.xs7977.domain.C58BeneficiarioCobertura c58BeneficiarioCobertura;

    private java.lang.String oficsnce;

    private java.lang.String nomprogr;

    private java.lang.String codusuario;

    private java.lang.String codtermina;

    private java.lang.String refBen;

    private java.lang.String refOrd;

    private java.lang.String indSepa;

    private java.lang.String adic1;

    private java.lang.String adic2;

    private java.lang.String adic3;

    private java.lang.String adic4;

    private java.lang.String adic5;

    private java.lang.String adic6;

    public Xs7977IEpa() {
    }

    public Xs7977IEpa(
           java.lang.String referencia,
           java.math.BigInteger numsecpag,
           java.lang.String entidad,
           java.lang.String centro,
           java.lang.String refercon,
           java.lang.String tipoasig,
           java.lang.String tipoopci,
           java.lang.String modoasig,
           java.lang.String tipoent,
           java.lang.String coditran,
           java.lang.String tratcont,
           java.lang.String tratswift,
           java.lang.String tratbanc,
           java.lang.String codicomp,
           java.lang.String menswift,
           java.lang.String divisaEmis,
           java.lang.String diviclie,
           java.lang.String cpaisdes,
           java.lang.String cpaisfon,
           java.math.BigDecimal impooper,
           java.lang.String fvalor,
           java.lang.String indiban,
           java.lang.String tipent,
           java.lang.String campo21,
           java.lang.String divisaorigen,
           java.math.BigDecimal importeorigen,
           java.lang.String cambio,
           java.math.BigDecimal cambio36,
           java.math.BigInteger fechaVto,
           java.lang.String descripVto1,
           java.lang.String tipbenefi,
           java.lang.String cuentaben,
           java.lang.String beibene,
           java.lang.String nombreben,
           java.lang.String dirBen,
           java.lang.String pobBen,
           java.lang.String paisben,
           java.lang.String ctacord,
           java.lang.String cccOfiO,
           java.lang.String cccCtaO,
           java.lang.String niford,
           com.bs.proteo.soa.service.proteo.xs7977.xs7977.domain.Xs7377Ia xs7377Ia,
           java.lang.String paisresord,
           java.lang.String devoaut,
           java.lang.String step2,
           java.lang.String codrefdev,
           java.lang.String fecopeori01,
           java.lang.String motivdev,
           java.lang.String motdevoltxt,
           java.lang.String[] infoemis,
           java.lang.String[] inforecPri,
           java.lang.String[] inforecCob,
           java.lang.String codimotp,
           java.lang.String indourben,
           java.lang.String divisag,
           java.math.BigDecimal importe71F1,
           com.bs.proteo.soa.service.proteo.xs7977.xs7977.domain.Xs7377D[] xs7377D,
           java.lang.String[] gastd71B,
           java.lang.String[] gastosa73,
           java.lang.String[] regrep77B,
           com.bs.proteo.soa.service.proteo.xs7977.xs7977.domain.Xs7377A[] xs7377A,
           java.lang.String campo23B,
           java.lang.String bicdestino,
           com.bs.proteo.soa.service.proteo.xs7977.xs7977.domain.P52BancoEmisor p52BancoEmisor,
           com.bs.proteo.soa.service.proteo.xs7977.xs7977.domain.P57BancoBeneficiario p57BancoBeneficiario,
           com.bs.proteo.soa.service.proteo.xs7977.xs7977.domain.P58Cobertura400 p58Cobertura400,
           java.lang.String p53ACorresp,
           java.lang.String p54ACorresr,
           java.lang.String p56AIntermed,
           java.lang.String mt202Receptor,
           java.lang.String c54ACorresp,
           java.lang.String c56PartyInter,
           java.lang.String c56ABicIntermediario,
           com.bs.proteo.soa.service.proteo.xs7977.xs7977.domain.C57ABancoCuenta c57ABancoCuenta,
           com.bs.proteo.soa.service.proteo.xs7977.xs7977.domain.C58BeneficiarioCobertura c58BeneficiarioCobertura,
           java.lang.String oficsnce,
           java.lang.String nomprogr,
           java.lang.String codusuario,
           java.lang.String codtermina,
           java.lang.String refBen,
           java.lang.String refOrd,
           java.lang.String indSepa,
           java.lang.String adic1,
           java.lang.String adic2,
           java.lang.String adic3,
           java.lang.String adic4,
           java.lang.String adic5,
           java.lang.String adic6) {
           this.referencia = referencia;
           this.numsecpag = numsecpag;
           this.entidad = entidad;
           this.centro = centro;
           this.refercon = refercon;
           this.tipoasig = tipoasig;
           this.tipoopci = tipoopci;
           this.modoasig = modoasig;
           this.tipoent = tipoent;
           this.coditran = coditran;
           this.tratcont = tratcont;
           this.tratswift = tratswift;
           this.tratbanc = tratbanc;
           this.codicomp = codicomp;
           this.menswift = menswift;
           this.divisaEmis = divisaEmis;
           this.diviclie = diviclie;
           this.cpaisdes = cpaisdes;
           this.cpaisfon = cpaisfon;
           this.impooper = impooper;
           this.fvalor = fvalor;
           this.indiban = indiban;
           this.tipent = tipent;
           this.campo21 = campo21;
           this.divisaorigen = divisaorigen;
           this.importeorigen = importeorigen;
           this.cambio = cambio;
           this.cambio36 = cambio36;
           this.fechaVto = fechaVto;
           this.descripVto1 = descripVto1;
           this.tipbenefi = tipbenefi;
           this.cuentaben = cuentaben;
           this.beibene = beibene;
           this.nombreben = nombreben;
           this.dirBen = dirBen;
           this.pobBen = pobBen;
           this.paisben = paisben;
           this.ctacord = ctacord;
           this.cccOfiO = cccOfiO;
           this.cccCtaO = cccCtaO;
           this.niford = niford;
           this.xs7377Ia = xs7377Ia;
           this.paisresord = paisresord;
           this.devoaut = devoaut;
           this.step2 = step2;
           this.codrefdev = codrefdev;
           this.fecopeori01 = fecopeori01;
           this.motivdev = motivdev;
           this.motdevoltxt = motdevoltxt;
           this.infoemis = infoemis;
           this.inforecPri = inforecPri;
           this.inforecCob = inforecCob;
           this.codimotp = codimotp;
           this.indourben = indourben;
           this.divisag = divisag;
           this.importe71F1 = importe71F1;
           this.xs7377D = xs7377D;
           this.gastd71B = gastd71B;
           this.gastosa73 = gastosa73;
           this.regrep77B = regrep77B;
           this.xs7377A = xs7377A;
           this.campo23B = campo23B;
           this.bicdestino = bicdestino;
           this.p52BancoEmisor = p52BancoEmisor;
           this.p57BancoBeneficiario = p57BancoBeneficiario;
           this.p58Cobertura400 = p58Cobertura400;
           this.p53ACorresp = p53ACorresp;
           this.p54ACorresr = p54ACorresr;
           this.p56AIntermed = p56AIntermed;
           this.mt202Receptor = mt202Receptor;
           this.c54ACorresp = c54ACorresp;
           this.c56PartyInter = c56PartyInter;
           this.c56ABicIntermediario = c56ABicIntermediario;
           this.c57ABancoCuenta = c57ABancoCuenta;
           this.c58BeneficiarioCobertura = c58BeneficiarioCobertura;
           this.oficsnce = oficsnce;
           this.nomprogr = nomprogr;
           this.codusuario = codusuario;
           this.codtermina = codtermina;
           this.refBen = refBen;
           this.refOrd = refOrd;
           this.indSepa = indSepa;
           this.adic1 = adic1;
           this.adic2 = adic2;
           this.adic3 = adic3;
           this.adic4 = adic4;
           this.adic5 = adic5;
           this.adic6 = adic6;
    }


    /**
     * Gets the referencia value for this Xs7977IEpa.
     * 
     * @return referencia
     */
    public java.lang.String getReferencia() {
        return referencia;
    }


    /**
     * Sets the referencia value for this Xs7977IEpa.
     * 
     * @param referencia
     */
    public void setReferencia(java.lang.String referencia) {
        this.referencia = referencia;
    }


    /**
     * Gets the numsecpag value for this Xs7977IEpa.
     * 
     * @return numsecpag
     */
    public java.math.BigInteger getNumsecpag() {
        return numsecpag;
    }


    /**
     * Sets the numsecpag value for this Xs7977IEpa.
     * 
     * @param numsecpag
     */
    public void setNumsecpag(java.math.BigInteger numsecpag) {
        this.numsecpag = numsecpag;
    }


    /**
     * Gets the entidad value for this Xs7977IEpa.
     * 
     * @return entidad
     */
    public java.lang.String getEntidad() {
        return entidad;
    }


    /**
     * Sets the entidad value for this Xs7977IEpa.
     * 
     * @param entidad
     */
    public void setEntidad(java.lang.String entidad) {
        this.entidad = entidad;
    }


    /**
     * Gets the centro value for this Xs7977IEpa.
     * 
     * @return centro
     */
    public java.lang.String getCentro() {
        return centro;
    }


    /**
     * Sets the centro value for this Xs7977IEpa.
     * 
     * @param centro
     */
    public void setCentro(java.lang.String centro) {
        this.centro = centro;
    }


    /**
     * Gets the refercon value for this Xs7977IEpa.
     * 
     * @return refercon
     */
    public java.lang.String getRefercon() {
        return refercon;
    }


    /**
     * Sets the refercon value for this Xs7977IEpa.
     * 
     * @param refercon
     */
    public void setRefercon(java.lang.String refercon) {
        this.refercon = refercon;
    }


    /**
     * Gets the tipoasig value for this Xs7977IEpa.
     * 
     * @return tipoasig
     */
    public java.lang.String getTipoasig() {
        return tipoasig;
    }


    /**
     * Sets the tipoasig value for this Xs7977IEpa.
     * 
     * @param tipoasig
     */
    public void setTipoasig(java.lang.String tipoasig) {
        this.tipoasig = tipoasig;
    }


    /**
     * Gets the tipoopci value for this Xs7977IEpa.
     * 
     * @return tipoopci
     */
    public java.lang.String getTipoopci() {
        return tipoopci;
    }


    /**
     * Sets the tipoopci value for this Xs7977IEpa.
     * 
     * @param tipoopci
     */
    public void setTipoopci(java.lang.String tipoopci) {
        this.tipoopci = tipoopci;
    }


    /**
     * Gets the modoasig value for this Xs7977IEpa.
     * 
     * @return modoasig
     */
    public java.lang.String getModoasig() {
        return modoasig;
    }


    /**
     * Sets the modoasig value for this Xs7977IEpa.
     * 
     * @param modoasig
     */
    public void setModoasig(java.lang.String modoasig) {
        this.modoasig = modoasig;
    }


    /**
     * Gets the tipoent value for this Xs7977IEpa.
     * 
     * @return tipoent
     */
    public java.lang.String getTipoent() {
        return tipoent;
    }


    /**
     * Sets the tipoent value for this Xs7977IEpa.
     * 
     * @param tipoent
     */
    public void setTipoent(java.lang.String tipoent) {
        this.tipoent = tipoent;
    }


    /**
     * Gets the coditran value for this Xs7977IEpa.
     * 
     * @return coditran
     */
    public java.lang.String getCoditran() {
        return coditran;
    }


    /**
     * Sets the coditran value for this Xs7977IEpa.
     * 
     * @param coditran
     */
    public void setCoditran(java.lang.String coditran) {
        this.coditran = coditran;
    }


    /**
     * Gets the tratcont value for this Xs7977IEpa.
     * 
     * @return tratcont
     */
    public java.lang.String getTratcont() {
        return tratcont;
    }


    /**
     * Sets the tratcont value for this Xs7977IEpa.
     * 
     * @param tratcont
     */
    public void setTratcont(java.lang.String tratcont) {
        this.tratcont = tratcont;
    }


    /**
     * Gets the tratswift value for this Xs7977IEpa.
     * 
     * @return tratswift
     */
    public java.lang.String getTratswift() {
        return tratswift;
    }


    /**
     * Sets the tratswift value for this Xs7977IEpa.
     * 
     * @param tratswift
     */
    public void setTratswift(java.lang.String tratswift) {
        this.tratswift = tratswift;
    }


    /**
     * Gets the tratbanc value for this Xs7977IEpa.
     * 
     * @return tratbanc
     */
    public java.lang.String getTratbanc() {
        return tratbanc;
    }


    /**
     * Sets the tratbanc value for this Xs7977IEpa.
     * 
     * @param tratbanc
     */
    public void setTratbanc(java.lang.String tratbanc) {
        this.tratbanc = tratbanc;
    }


    /**
     * Gets the codicomp value for this Xs7977IEpa.
     * 
     * @return codicomp
     */
    public java.lang.String getCodicomp() {
        return codicomp;
    }


    /**
     * Sets the codicomp value for this Xs7977IEpa.
     * 
     * @param codicomp
     */
    public void setCodicomp(java.lang.String codicomp) {
        this.codicomp = codicomp;
    }


    /**
     * Gets the menswift value for this Xs7977IEpa.
     * 
     * @return menswift
     */
    public java.lang.String getMenswift() {
        return menswift;
    }


    /**
     * Sets the menswift value for this Xs7977IEpa.
     * 
     * @param menswift
     */
    public void setMenswift(java.lang.String menswift) {
        this.menswift = menswift;
    }


    /**
     * Gets the divisaEmis value for this Xs7977IEpa.
     * 
     * @return divisaEmis
     */
    public java.lang.String getDivisaEmis() {
        return divisaEmis;
    }


    /**
     * Sets the divisaEmis value for this Xs7977IEpa.
     * 
     * @param divisaEmis
     */
    public void setDivisaEmis(java.lang.String divisaEmis) {
        this.divisaEmis = divisaEmis;
    }


    /**
     * Gets the diviclie value for this Xs7977IEpa.
     * 
     * @return diviclie
     */
    public java.lang.String getDiviclie() {
        return diviclie;
    }


    /**
     * Sets the diviclie value for this Xs7977IEpa.
     * 
     * @param diviclie
     */
    public void setDiviclie(java.lang.String diviclie) {
        this.diviclie = diviclie;
    }


    /**
     * Gets the cpaisdes value for this Xs7977IEpa.
     * 
     * @return cpaisdes
     */
    public java.lang.String getCpaisdes() {
        return cpaisdes;
    }


    /**
     * Sets the cpaisdes value for this Xs7977IEpa.
     * 
     * @param cpaisdes
     */
    public void setCpaisdes(java.lang.String cpaisdes) {
        this.cpaisdes = cpaisdes;
    }


    /**
     * Gets the cpaisfon value for this Xs7977IEpa.
     * 
     * @return cpaisfon
     */
    public java.lang.String getCpaisfon() {
        return cpaisfon;
    }


    /**
     * Sets the cpaisfon value for this Xs7977IEpa.
     * 
     * @param cpaisfon
     */
    public void setCpaisfon(java.lang.String cpaisfon) {
        this.cpaisfon = cpaisfon;
    }


    /**
     * Gets the impooper value for this Xs7977IEpa.
     * 
     * @return impooper
     */
    public java.math.BigDecimal getImpooper() {
        return impooper;
    }


    /**
     * Sets the impooper value for this Xs7977IEpa.
     * 
     * @param impooper
     */
    public void setImpooper(java.math.BigDecimal impooper) {
        this.impooper = impooper;
    }


    /**
     * Gets the fvalor value for this Xs7977IEpa.
     * 
     * @return fvalor
     */
    public java.lang.String getFvalor() {
        return fvalor;
    }


    /**
     * Sets the fvalor value for this Xs7977IEpa.
     * 
     * @param fvalor
     */
    public void setFvalor(java.lang.String fvalor) {
        this.fvalor = fvalor;
    }


    /**
     * Gets the indiban value for this Xs7977IEpa.
     * 
     * @return indiban
     */
    public java.lang.String getIndiban() {
        return indiban;
    }


    /**
     * Sets the indiban value for this Xs7977IEpa.
     * 
     * @param indiban
     */
    public void setIndiban(java.lang.String indiban) {
        this.indiban = indiban;
    }


    /**
     * Gets the tipent value for this Xs7977IEpa.
     * 
     * @return tipent
     */
    public java.lang.String getTipent() {
        return tipent;
    }


    /**
     * Sets the tipent value for this Xs7977IEpa.
     * 
     * @param tipent
     */
    public void setTipent(java.lang.String tipent) {
        this.tipent = tipent;
    }


    /**
     * Gets the campo21 value for this Xs7977IEpa.
     * 
     * @return campo21
     */
    public java.lang.String getCampo21() {
        return campo21;
    }


    /**
     * Sets the campo21 value for this Xs7977IEpa.
     * 
     * @param campo21
     */
    public void setCampo21(java.lang.String campo21) {
        this.campo21 = campo21;
    }


    /**
     * Gets the divisaorigen value for this Xs7977IEpa.
     * 
     * @return divisaorigen
     */
    public java.lang.String getDivisaorigen() {
        return divisaorigen;
    }


    /**
     * Sets the divisaorigen value for this Xs7977IEpa.
     * 
     * @param divisaorigen
     */
    public void setDivisaorigen(java.lang.String divisaorigen) {
        this.divisaorigen = divisaorigen;
    }


    /**
     * Gets the importeorigen value for this Xs7977IEpa.
     * 
     * @return importeorigen
     */
    public java.math.BigDecimal getImporteorigen() {
        return importeorigen;
    }


    /**
     * Sets the importeorigen value for this Xs7977IEpa.
     * 
     * @param importeorigen
     */
    public void setImporteorigen(java.math.BigDecimal importeorigen) {
        this.importeorigen = importeorigen;
    }


    /**
     * Gets the cambio value for this Xs7977IEpa.
     * 
     * @return cambio
     */
    public java.lang.String getCambio() {
        return cambio;
    }


    /**
     * Sets the cambio value for this Xs7977IEpa.
     * 
     * @param cambio
     */
    public void setCambio(java.lang.String cambio) {
        this.cambio = cambio;
    }


    /**
     * Gets the cambio36 value for this Xs7977IEpa.
     * 
     * @return cambio36
     */
    public java.math.BigDecimal getCambio36() {
        return cambio36;
    }


    /**
     * Sets the cambio36 value for this Xs7977IEpa.
     * 
     * @param cambio36
     */
    public void setCambio36(java.math.BigDecimal cambio36) {
        this.cambio36 = cambio36;
    }


    /**
     * Gets the fechaVto value for this Xs7977IEpa.
     * 
     * @return fechaVto
     */
    public java.math.BigInteger getFechaVto() {
        return fechaVto;
    }


    /**
     * Sets the fechaVto value for this Xs7977IEpa.
     * 
     * @param fechaVto
     */
    public void setFechaVto(java.math.BigInteger fechaVto) {
        this.fechaVto = fechaVto;
    }


    /**
     * Gets the descripVto1 value for this Xs7977IEpa.
     * 
     * @return descripVto1
     */
    public java.lang.String getDescripVto1() {
        return descripVto1;
    }


    /**
     * Sets the descripVto1 value for this Xs7977IEpa.
     * 
     * @param descripVto1
     */
    public void setDescripVto1(java.lang.String descripVto1) {
        this.descripVto1 = descripVto1;
    }


    /**
     * Gets the tipbenefi value for this Xs7977IEpa.
     * 
     * @return tipbenefi
     */
    public java.lang.String getTipbenefi() {
        return tipbenefi;
    }


    /**
     * Sets the tipbenefi value for this Xs7977IEpa.
     * 
     * @param tipbenefi
     */
    public void setTipbenefi(java.lang.String tipbenefi) {
        this.tipbenefi = tipbenefi;
    }


    /**
     * Gets the cuentaben value for this Xs7977IEpa.
     * 
     * @return cuentaben
     */
    public java.lang.String getCuentaben() {
        return cuentaben;
    }


    /**
     * Sets the cuentaben value for this Xs7977IEpa.
     * 
     * @param cuentaben
     */
    public void setCuentaben(java.lang.String cuentaben) {
        this.cuentaben = cuentaben;
    }


    /**
     * Gets the beibene value for this Xs7977IEpa.
     * 
     * @return beibene
     */
    public java.lang.String getBeibene() {
        return beibene;
    }


    /**
     * Sets the beibene value for this Xs7977IEpa.
     * 
     * @param beibene
     */
    public void setBeibene(java.lang.String beibene) {
        this.beibene = beibene;
    }


    /**
     * Gets the nombreben value for this Xs7977IEpa.
     * 
     * @return nombreben
     */
    public java.lang.String getNombreben() {
        return nombreben;
    }


    /**
     * Sets the nombreben value for this Xs7977IEpa.
     * 
     * @param nombreben
     */
    public void setNombreben(java.lang.String nombreben) {
        this.nombreben = nombreben;
    }


    /**
     * Gets the dirBen value for this Xs7977IEpa.
     * 
     * @return dirBen
     */
    public java.lang.String getDirBen() {
        return dirBen;
    }


    /**
     * Sets the dirBen value for this Xs7977IEpa.
     * 
     * @param dirBen
     */
    public void setDirBen(java.lang.String dirBen) {
        this.dirBen = dirBen;
    }


    /**
     * Gets the pobBen value for this Xs7977IEpa.
     * 
     * @return pobBen
     */
    public java.lang.String getPobBen() {
        return pobBen;
    }


    /**
     * Sets the pobBen value for this Xs7977IEpa.
     * 
     * @param pobBen
     */
    public void setPobBen(java.lang.String pobBen) {
        this.pobBen = pobBen;
    }


    /**
     * Gets the paisben value for this Xs7977IEpa.
     * 
     * @return paisben
     */
    public java.lang.String getPaisben() {
        return paisben;
    }


    /**
     * Sets the paisben value for this Xs7977IEpa.
     * 
     * @param paisben
     */
    public void setPaisben(java.lang.String paisben) {
        this.paisben = paisben;
    }


    /**
     * Gets the ctacord value for this Xs7977IEpa.
     * 
     * @return ctacord
     */
    public java.lang.String getCtacord() {
        return ctacord;
    }


    /**
     * Sets the ctacord value for this Xs7977IEpa.
     * 
     * @param ctacord
     */
    public void setCtacord(java.lang.String ctacord) {
        this.ctacord = ctacord;
    }


    /**
     * Gets the cccOfiO value for this Xs7977IEpa.
     * 
     * @return cccOfiO
     */
    public java.lang.String getCccOfiO() {
        return cccOfiO;
    }


    /**
     * Sets the cccOfiO value for this Xs7977IEpa.
     * 
     * @param cccOfiO
     */
    public void setCccOfiO(java.lang.String cccOfiO) {
        this.cccOfiO = cccOfiO;
    }


    /**
     * Gets the cccCtaO value for this Xs7977IEpa.
     * 
     * @return cccCtaO
     */
    public java.lang.String getCccCtaO() {
        return cccCtaO;
    }


    /**
     * Sets the cccCtaO value for this Xs7977IEpa.
     * 
     * @param cccCtaO
     */
    public void setCccCtaO(java.lang.String cccCtaO) {
        this.cccCtaO = cccCtaO;
    }


    /**
     * Gets the niford value for this Xs7977IEpa.
     * 
     * @return niford
     */
    public java.lang.String getNiford() {
        return niford;
    }


    /**
     * Sets the niford value for this Xs7977IEpa.
     * 
     * @param niford
     */
    public void setNiford(java.lang.String niford) {
        this.niford = niford;
    }


    /**
     * Gets the xs7377Ia value for this Xs7977IEpa.
     * 
     * @return xs7377Ia
     */
    public com.bs.proteo.soa.service.proteo.xs7977.xs7977.domain.Xs7377Ia getXs7377Ia() {
        return xs7377Ia;
    }


    /**
     * Sets the xs7377Ia value for this Xs7977IEpa.
     * 
     * @param xs7377Ia
     */
    public void setXs7377Ia(com.bs.proteo.soa.service.proteo.xs7977.xs7977.domain.Xs7377Ia xs7377Ia) {
        this.xs7377Ia = xs7377Ia;
    }


    /**
     * Gets the paisresord value for this Xs7977IEpa.
     * 
     * @return paisresord
     */
    public java.lang.String getPaisresord() {
        return paisresord;
    }


    /**
     * Sets the paisresord value for this Xs7977IEpa.
     * 
     * @param paisresord
     */
    public void setPaisresord(java.lang.String paisresord) {
        this.paisresord = paisresord;
    }


    /**
     * Gets the devoaut value for this Xs7977IEpa.
     * 
     * @return devoaut
     */
    public java.lang.String getDevoaut() {
        return devoaut;
    }


    /**
     * Sets the devoaut value for this Xs7977IEpa.
     * 
     * @param devoaut
     */
    public void setDevoaut(java.lang.String devoaut) {
        this.devoaut = devoaut;
    }


    /**
     * Gets the step2 value for this Xs7977IEpa.
     * 
     * @return step2
     */
    public java.lang.String getStep2() {
        return step2;
    }


    /**
     * Sets the step2 value for this Xs7977IEpa.
     * 
     * @param step2
     */
    public void setStep2(java.lang.String step2) {
        this.step2 = step2;
    }


    /**
     * Gets the codrefdev value for this Xs7977IEpa.
     * 
     * @return codrefdev
     */
    public java.lang.String getCodrefdev() {
        return codrefdev;
    }


    /**
     * Sets the codrefdev value for this Xs7977IEpa.
     * 
     * @param codrefdev
     */
    public void setCodrefdev(java.lang.String codrefdev) {
        this.codrefdev = codrefdev;
    }


    /**
     * Gets the fecopeori01 value for this Xs7977IEpa.
     * 
     * @return fecopeori01
     */
    public java.lang.String getFecopeori01() {
        return fecopeori01;
    }


    /**
     * Sets the fecopeori01 value for this Xs7977IEpa.
     * 
     * @param fecopeori01
     */
    public void setFecopeori01(java.lang.String fecopeori01) {
        this.fecopeori01 = fecopeori01;
    }


    /**
     * Gets the motivdev value for this Xs7977IEpa.
     * 
     * @return motivdev
     */
    public java.lang.String getMotivdev() {
        return motivdev;
    }


    /**
     * Sets the motivdev value for this Xs7977IEpa.
     * 
     * @param motivdev
     */
    public void setMotivdev(java.lang.String motivdev) {
        this.motivdev = motivdev;
    }


    /**
     * Gets the motdevoltxt value for this Xs7977IEpa.
     * 
     * @return motdevoltxt
     */
    public java.lang.String getMotdevoltxt() {
        return motdevoltxt;
    }


    /**
     * Sets the motdevoltxt value for this Xs7977IEpa.
     * 
     * @param motdevoltxt
     */
    public void setMotdevoltxt(java.lang.String motdevoltxt) {
        this.motdevoltxt = motdevoltxt;
    }


    /**
     * Gets the infoemis value for this Xs7977IEpa.
     * 
     * @return infoemis
     */
    public java.lang.String[] getInfoemis() {
        return infoemis;
    }


    /**
     * Sets the infoemis value for this Xs7977IEpa.
     * 
     * @param infoemis
     */
    public void setInfoemis(java.lang.String[] infoemis) {
        this.infoemis = infoemis;
    }

    public java.lang.String getInfoemis(int i) {
        return this.infoemis[i];
    }

    public void setInfoemis(int i, java.lang.String _value) {
        this.infoemis[i] = _value;
    }


    /**
     * Gets the inforecPri value for this Xs7977IEpa.
     * 
     * @return inforecPri
     */
    public java.lang.String[] getInforecPri() {
        return inforecPri;
    }


    /**
     * Sets the inforecPri value for this Xs7977IEpa.
     * 
     * @param inforecPri
     */
    public void setInforecPri(java.lang.String[] inforecPri) {
        this.inforecPri = inforecPri;
    }

    public java.lang.String getInforecPri(int i) {
        return this.inforecPri[i];
    }

    public void setInforecPri(int i, java.lang.String _value) {
        this.inforecPri[i] = _value;
    }


    /**
     * Gets the inforecCob value for this Xs7977IEpa.
     * 
     * @return inforecCob
     */
    public java.lang.String[] getInforecCob() {
        return inforecCob;
    }


    /**
     * Sets the inforecCob value for this Xs7977IEpa.
     * 
     * @param inforecCob
     */
    public void setInforecCob(java.lang.String[] inforecCob) {
        this.inforecCob = inforecCob;
    }

    public java.lang.String getInforecCob(int i) {
        return this.inforecCob[i];
    }

    public void setInforecCob(int i, java.lang.String _value) {
        this.inforecCob[i] = _value;
    }


    /**
     * Gets the codimotp value for this Xs7977IEpa.
     * 
     * @return codimotp
     */
    public java.lang.String getCodimotp() {
        return codimotp;
    }


    /**
     * Sets the codimotp value for this Xs7977IEpa.
     * 
     * @param codimotp
     */
    public void setCodimotp(java.lang.String codimotp) {
        this.codimotp = codimotp;
    }


    /**
     * Gets the indourben value for this Xs7977IEpa.
     * 
     * @return indourben
     */
    public java.lang.String getIndourben() {
        return indourben;
    }


    /**
     * Sets the indourben value for this Xs7977IEpa.
     * 
     * @param indourben
     */
    public void setIndourben(java.lang.String indourben) {
        this.indourben = indourben;
    }


    /**
     * Gets the divisag value for this Xs7977IEpa.
     * 
     * @return divisag
     */
    public java.lang.String getDivisag() {
        return divisag;
    }


    /**
     * Sets the divisag value for this Xs7977IEpa.
     * 
     * @param divisag
     */
    public void setDivisag(java.lang.String divisag) {
        this.divisag = divisag;
    }


    /**
     * Gets the importe71F1 value for this Xs7977IEpa.
     * 
     * @return importe71F1
     */
    public java.math.BigDecimal getImporte71F1() {
        return importe71F1;
    }


    /**
     * Sets the importe71F1 value for this Xs7977IEpa.
     * 
     * @param importe71F1
     */
    public void setImporte71F1(java.math.BigDecimal importe71F1) {
        this.importe71F1 = importe71F1;
    }


    /**
     * Gets the xs7377D value for this Xs7977IEpa.
     * 
     * @return xs7377D
     */
    public com.bs.proteo.soa.service.proteo.xs7977.xs7977.domain.Xs7377D[] getXs7377D() {
        return xs7377D;
    }


    /**
     * Sets the xs7377D value for this Xs7977IEpa.
     * 
     * @param xs7377D
     */
    public void setXs7377D(com.bs.proteo.soa.service.proteo.xs7977.xs7977.domain.Xs7377D[] xs7377D) {
        this.xs7377D = xs7377D;
    }

    public com.bs.proteo.soa.service.proteo.xs7977.xs7977.domain.Xs7377D getXs7377D(int i) {
        return this.xs7377D[i];
    }

    public void setXs7377D(int i, com.bs.proteo.soa.service.proteo.xs7977.xs7977.domain.Xs7377D _value) {
        this.xs7377D[i] = _value;
    }


    /**
     * Gets the gastd71B value for this Xs7977IEpa.
     * 
     * @return gastd71B
     */
    public java.lang.String[] getGastd71B() {
        return gastd71B;
    }


    /**
     * Sets the gastd71B value for this Xs7977IEpa.
     * 
     * @param gastd71B
     */
    public void setGastd71B(java.lang.String[] gastd71B) {
        this.gastd71B = gastd71B;
    }

    public java.lang.String getGastd71B(int i) {
        return this.gastd71B[i];
    }

    public void setGastd71B(int i, java.lang.String _value) {
        this.gastd71B[i] = _value;
    }


    /**
     * Gets the gastosa73 value for this Xs7977IEpa.
     * 
     * @return gastosa73
     */
    public java.lang.String[] getGastosa73() {
        return gastosa73;
    }


    /**
     * Sets the gastosa73 value for this Xs7977IEpa.
     * 
     * @param gastosa73
     */
    public void setGastosa73(java.lang.String[] gastosa73) {
        this.gastosa73 = gastosa73;
    }

    public java.lang.String getGastosa73(int i) {
        return this.gastosa73[i];
    }

    public void setGastosa73(int i, java.lang.String _value) {
        this.gastosa73[i] = _value;
    }


    /**
     * Gets the regrep77B value for this Xs7977IEpa.
     * 
     * @return regrep77B
     */
    public java.lang.String[] getRegrep77B() {
        return regrep77B;
    }


    /**
     * Sets the regrep77B value for this Xs7977IEpa.
     * 
     * @param regrep77B
     */
    public void setRegrep77B(java.lang.String[] regrep77B) {
        this.regrep77B = regrep77B;
    }

    public java.lang.String getRegrep77B(int i) {
        return this.regrep77B[i];
    }

    public void setRegrep77B(int i, java.lang.String _value) {
        this.regrep77B[i] = _value;
    }


    /**
     * Gets the xs7377A value for this Xs7977IEpa.
     * 
     * @return xs7377A
     */
    public com.bs.proteo.soa.service.proteo.xs7977.xs7977.domain.Xs7377A[] getXs7377A() {
        return xs7377A;
    }


    /**
     * Sets the xs7377A value for this Xs7977IEpa.
     * 
     * @param xs7377A
     */
    public void setXs7377A(com.bs.proteo.soa.service.proteo.xs7977.xs7977.domain.Xs7377A[] xs7377A) {
        this.xs7377A = xs7377A;
    }

    public com.bs.proteo.soa.service.proteo.xs7977.xs7977.domain.Xs7377A getXs7377A(int i) {
        return this.xs7377A[i];
    }

    public void setXs7377A(int i, com.bs.proteo.soa.service.proteo.xs7977.xs7977.domain.Xs7377A _value) {
        this.xs7377A[i] = _value;
    }


    /**
     * Gets the campo23B value for this Xs7977IEpa.
     * 
     * @return campo23B
     */
    public java.lang.String getCampo23B() {
        return campo23B;
    }


    /**
     * Sets the campo23B value for this Xs7977IEpa.
     * 
     * @param campo23B
     */
    public void setCampo23B(java.lang.String campo23B) {
        this.campo23B = campo23B;
    }


    /**
     * Gets the bicdestino value for this Xs7977IEpa.
     * 
     * @return bicdestino
     */
    public java.lang.String getBicdestino() {
        return bicdestino;
    }


    /**
     * Sets the bicdestino value for this Xs7977IEpa.
     * 
     * @param bicdestino
     */
    public void setBicdestino(java.lang.String bicdestino) {
        this.bicdestino = bicdestino;
    }


    /**
     * Gets the p52BancoEmisor value for this Xs7977IEpa.
     * 
     * @return p52BancoEmisor
     */
    public com.bs.proteo.soa.service.proteo.xs7977.xs7977.domain.P52BancoEmisor getP52BancoEmisor() {
        return p52BancoEmisor;
    }


    /**
     * Sets the p52BancoEmisor value for this Xs7977IEpa.
     * 
     * @param p52BancoEmisor
     */
    public void setP52BancoEmisor(com.bs.proteo.soa.service.proteo.xs7977.xs7977.domain.P52BancoEmisor p52BancoEmisor) {
        this.p52BancoEmisor = p52BancoEmisor;
    }


    /**
     * Gets the p57BancoBeneficiario value for this Xs7977IEpa.
     * 
     * @return p57BancoBeneficiario
     */
    public com.bs.proteo.soa.service.proteo.xs7977.xs7977.domain.P57BancoBeneficiario getP57BancoBeneficiario() {
        return p57BancoBeneficiario;
    }


    /**
     * Sets the p57BancoBeneficiario value for this Xs7977IEpa.
     * 
     * @param p57BancoBeneficiario
     */
    public void setP57BancoBeneficiario(com.bs.proteo.soa.service.proteo.xs7977.xs7977.domain.P57BancoBeneficiario p57BancoBeneficiario) {
        this.p57BancoBeneficiario = p57BancoBeneficiario;
    }


    /**
     * Gets the p58Cobertura400 value for this Xs7977IEpa.
     * 
     * @return p58Cobertura400
     */
    public com.bs.proteo.soa.service.proteo.xs7977.xs7977.domain.P58Cobertura400 getP58Cobertura400() {
        return p58Cobertura400;
    }


    /**
     * Sets the p58Cobertura400 value for this Xs7977IEpa.
     * 
     * @param p58Cobertura400
     */
    public void setP58Cobertura400(com.bs.proteo.soa.service.proteo.xs7977.xs7977.domain.P58Cobertura400 p58Cobertura400) {
        this.p58Cobertura400 = p58Cobertura400;
    }


    /**
     * Gets the p53ACorresp value for this Xs7977IEpa.
     * 
     * @return p53ACorresp
     */
    public java.lang.String getP53ACorresp() {
        return p53ACorresp;
    }


    /**
     * Sets the p53ACorresp value for this Xs7977IEpa.
     * 
     * @param p53ACorresp
     */
    public void setP53ACorresp(java.lang.String p53ACorresp) {
        this.p53ACorresp = p53ACorresp;
    }


    /**
     * Gets the p54ACorresr value for this Xs7977IEpa.
     * 
     * @return p54ACorresr
     */
    public java.lang.String getP54ACorresr() {
        return p54ACorresr;
    }


    /**
     * Sets the p54ACorresr value for this Xs7977IEpa.
     * 
     * @param p54ACorresr
     */
    public void setP54ACorresr(java.lang.String p54ACorresr) {
        this.p54ACorresr = p54ACorresr;
    }


    /**
     * Gets the p56AIntermed value for this Xs7977IEpa.
     * 
     * @return p56AIntermed
     */
    public java.lang.String getP56AIntermed() {
        return p56AIntermed;
    }


    /**
     * Sets the p56AIntermed value for this Xs7977IEpa.
     * 
     * @param p56AIntermed
     */
    public void setP56AIntermed(java.lang.String p56AIntermed) {
        this.p56AIntermed = p56AIntermed;
    }


    /**
     * Gets the mt202Receptor value for this Xs7977IEpa.
     * 
     * @return mt202Receptor
     */
    public java.lang.String getMt202Receptor() {
        return mt202Receptor;
    }


    /**
     * Sets the mt202Receptor value for this Xs7977IEpa.
     * 
     * @param mt202Receptor
     */
    public void setMt202Receptor(java.lang.String mt202Receptor) {
        this.mt202Receptor = mt202Receptor;
    }


    /**
     * Gets the c54ACorresp value for this Xs7977IEpa.
     * 
     * @return c54ACorresp
     */
    public java.lang.String getC54ACorresp() {
        return c54ACorresp;
    }


    /**
     * Sets the c54ACorresp value for this Xs7977IEpa.
     * 
     * @param c54ACorresp
     */
    public void setC54ACorresp(java.lang.String c54ACorresp) {
        this.c54ACorresp = c54ACorresp;
    }


    /**
     * Gets the c56PartyInter value for this Xs7977IEpa.
     * 
     * @return c56PartyInter
     */
    public java.lang.String getC56PartyInter() {
        return c56PartyInter;
    }


    /**
     * Sets the c56PartyInter value for this Xs7977IEpa.
     * 
     * @param c56PartyInter
     */
    public void setC56PartyInter(java.lang.String c56PartyInter) {
        this.c56PartyInter = c56PartyInter;
    }


    /**
     * Gets the c56ABicIntermediario value for this Xs7977IEpa.
     * 
     * @return c56ABicIntermediario
     */
    public java.lang.String getC56ABicIntermediario() {
        return c56ABicIntermediario;
    }


    /**
     * Sets the c56ABicIntermediario value for this Xs7977IEpa.
     * 
     * @param c56ABicIntermediario
     */
    public void setC56ABicIntermediario(java.lang.String c56ABicIntermediario) {
        this.c56ABicIntermediario = c56ABicIntermediario;
    }


    /**
     * Gets the c57ABancoCuenta value for this Xs7977IEpa.
     * 
     * @return c57ABancoCuenta
     */
    public com.bs.proteo.soa.service.proteo.xs7977.xs7977.domain.C57ABancoCuenta getC57ABancoCuenta() {
        return c57ABancoCuenta;
    }


    /**
     * Sets the c57ABancoCuenta value for this Xs7977IEpa.
     * 
     * @param c57ABancoCuenta
     */
    public void setC57ABancoCuenta(com.bs.proteo.soa.service.proteo.xs7977.xs7977.domain.C57ABancoCuenta c57ABancoCuenta) {
        this.c57ABancoCuenta = c57ABancoCuenta;
    }


    /**
     * Gets the c58BeneficiarioCobertura value for this Xs7977IEpa.
     * 
     * @return c58BeneficiarioCobertura
     */
    public com.bs.proteo.soa.service.proteo.xs7977.xs7977.domain.C58BeneficiarioCobertura getC58BeneficiarioCobertura() {
        return c58BeneficiarioCobertura;
    }


    /**
     * Sets the c58BeneficiarioCobertura value for this Xs7977IEpa.
     * 
     * @param c58BeneficiarioCobertura
     */
    public void setC58BeneficiarioCobertura(com.bs.proteo.soa.service.proteo.xs7977.xs7977.domain.C58BeneficiarioCobertura c58BeneficiarioCobertura) {
        this.c58BeneficiarioCobertura = c58BeneficiarioCobertura;
    }


    /**
     * Gets the oficsnce value for this Xs7977IEpa.
     * 
     * @return oficsnce
     */
    public java.lang.String getOficsnce() {
        return oficsnce;
    }


    /**
     * Sets the oficsnce value for this Xs7977IEpa.
     * 
     * @param oficsnce
     */
    public void setOficsnce(java.lang.String oficsnce) {
        this.oficsnce = oficsnce;
    }


    /**
     * Gets the nomprogr value for this Xs7977IEpa.
     * 
     * @return nomprogr
     */
    public java.lang.String getNomprogr() {
        return nomprogr;
    }


    /**
     * Sets the nomprogr value for this Xs7977IEpa.
     * 
     * @param nomprogr
     */
    public void setNomprogr(java.lang.String nomprogr) {
        this.nomprogr = nomprogr;
    }


    /**
     * Gets the codusuario value for this Xs7977IEpa.
     * 
     * @return codusuario
     */
    public java.lang.String getCodusuario() {
        return codusuario;
    }


    /**
     * Sets the codusuario value for this Xs7977IEpa.
     * 
     * @param codusuario
     */
    public void setCodusuario(java.lang.String codusuario) {
        this.codusuario = codusuario;
    }


    /**
     * Gets the codtermina value for this Xs7977IEpa.
     * 
     * @return codtermina
     */
    public java.lang.String getCodtermina() {
        return codtermina;
    }


    /**
     * Sets the codtermina value for this Xs7977IEpa.
     * 
     * @param codtermina
     */
    public void setCodtermina(java.lang.String codtermina) {
        this.codtermina = codtermina;
    }


    /**
     * Gets the refBen value for this Xs7977IEpa.
     * 
     * @return refBen
     */
    public java.lang.String getRefBen() {
        return refBen;
    }


    /**
     * Sets the refBen value for this Xs7977IEpa.
     * 
     * @param refBen
     */
    public void setRefBen(java.lang.String refBen) {
        this.refBen = refBen;
    }


    /**
     * Gets the refOrd value for this Xs7977IEpa.
     * 
     * @return refOrd
     */
    public java.lang.String getRefOrd() {
        return refOrd;
    }


    /**
     * Sets the refOrd value for this Xs7977IEpa.
     * 
     * @param refOrd
     */
    public void setRefOrd(java.lang.String refOrd) {
        this.refOrd = refOrd;
    }


    /**
     * Gets the indSepa value for this Xs7977IEpa.
     * 
     * @return indSepa
     */
    public java.lang.String getIndSepa() {
        return indSepa;
    }


    /**
     * Sets the indSepa value for this Xs7977IEpa.
     * 
     * @param indSepa
     */
    public void setIndSepa(java.lang.String indSepa) {
        this.indSepa = indSepa;
    }


    /**
     * Gets the adic1 value for this Xs7977IEpa.
     * 
     * @return adic1
     */
    public java.lang.String getAdic1() {
        return adic1;
    }


    /**
     * Sets the adic1 value for this Xs7977IEpa.
     * 
     * @param adic1
     */
    public void setAdic1(java.lang.String adic1) {
        this.adic1 = adic1;
    }


    /**
     * Gets the adic2 value for this Xs7977IEpa.
     * 
     * @return adic2
     */
    public java.lang.String getAdic2() {
        return adic2;
    }


    /**
     * Sets the adic2 value for this Xs7977IEpa.
     * 
     * @param adic2
     */
    public void setAdic2(java.lang.String adic2) {
        this.adic2 = adic2;
    }


    /**
     * Gets the adic3 value for this Xs7977IEpa.
     * 
     * @return adic3
     */
    public java.lang.String getAdic3() {
        return adic3;
    }


    /**
     * Sets the adic3 value for this Xs7977IEpa.
     * 
     * @param adic3
     */
    public void setAdic3(java.lang.String adic3) {
        this.adic3 = adic3;
    }


    /**
     * Gets the adic4 value for this Xs7977IEpa.
     * 
     * @return adic4
     */
    public java.lang.String getAdic4() {
        return adic4;
    }


    /**
     * Sets the adic4 value for this Xs7977IEpa.
     * 
     * @param adic4
     */
    public void setAdic4(java.lang.String adic4) {
        this.adic4 = adic4;
    }


    /**
     * Gets the adic5 value for this Xs7977IEpa.
     * 
     * @return adic5
     */
    public java.lang.String getAdic5() {
        return adic5;
    }


    /**
     * Sets the adic5 value for this Xs7977IEpa.
     * 
     * @param adic5
     */
    public void setAdic5(java.lang.String adic5) {
        this.adic5 = adic5;
    }


    /**
     * Gets the adic6 value for this Xs7977IEpa.
     * 
     * @return adic6
     */
    public java.lang.String getAdic6() {
        return adic6;
    }


    /**
     * Sets the adic6 value for this Xs7977IEpa.
     * 
     * @param adic6
     */
    public void setAdic6(java.lang.String adic6) {
        this.adic6 = adic6;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof Xs7977IEpa)) return false;
        Xs7977IEpa other = (Xs7977IEpa) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            ((this.referencia==null && other.getReferencia()==null) || 
             (this.referencia!=null &&
              this.referencia.equals(other.getReferencia()))) &&
            ((this.numsecpag==null && other.getNumsecpag()==null) || 
             (this.numsecpag!=null &&
              this.numsecpag.equals(other.getNumsecpag()))) &&
            ((this.entidad==null && other.getEntidad()==null) || 
             (this.entidad!=null &&
              this.entidad.equals(other.getEntidad()))) &&
            ((this.centro==null && other.getCentro()==null) || 
             (this.centro!=null &&
              this.centro.equals(other.getCentro()))) &&
            ((this.refercon==null && other.getRefercon()==null) || 
             (this.refercon!=null &&
              this.refercon.equals(other.getRefercon()))) &&
            ((this.tipoasig==null && other.getTipoasig()==null) || 
             (this.tipoasig!=null &&
              this.tipoasig.equals(other.getTipoasig()))) &&
            ((this.tipoopci==null && other.getTipoopci()==null) || 
             (this.tipoopci!=null &&
              this.tipoopci.equals(other.getTipoopci()))) &&
            ((this.modoasig==null && other.getModoasig()==null) || 
             (this.modoasig!=null &&
              this.modoasig.equals(other.getModoasig()))) &&
            ((this.tipoent==null && other.getTipoent()==null) || 
             (this.tipoent!=null &&
              this.tipoent.equals(other.getTipoent()))) &&
            ((this.coditran==null && other.getCoditran()==null) || 
             (this.coditran!=null &&
              this.coditran.equals(other.getCoditran()))) &&
            ((this.tratcont==null && other.getTratcont()==null) || 
             (this.tratcont!=null &&
              this.tratcont.equals(other.getTratcont()))) &&
            ((this.tratswift==null && other.getTratswift()==null) || 
             (this.tratswift!=null &&
              this.tratswift.equals(other.getTratswift()))) &&
            ((this.tratbanc==null && other.getTratbanc()==null) || 
             (this.tratbanc!=null &&
              this.tratbanc.equals(other.getTratbanc()))) &&
            ((this.codicomp==null && other.getCodicomp()==null) || 
             (this.codicomp!=null &&
              this.codicomp.equals(other.getCodicomp()))) &&
            ((this.menswift==null && other.getMenswift()==null) || 
             (this.menswift!=null &&
              this.menswift.equals(other.getMenswift()))) &&
            ((this.divisaEmis==null && other.getDivisaEmis()==null) || 
             (this.divisaEmis!=null &&
              this.divisaEmis.equals(other.getDivisaEmis()))) &&
            ((this.diviclie==null && other.getDiviclie()==null) || 
             (this.diviclie!=null &&
              this.diviclie.equals(other.getDiviclie()))) &&
            ((this.cpaisdes==null && other.getCpaisdes()==null) || 
             (this.cpaisdes!=null &&
              this.cpaisdes.equals(other.getCpaisdes()))) &&
            ((this.cpaisfon==null && other.getCpaisfon()==null) || 
             (this.cpaisfon!=null &&
              this.cpaisfon.equals(other.getCpaisfon()))) &&
            ((this.impooper==null && other.getImpooper()==null) || 
             (this.impooper!=null &&
              this.impooper.equals(other.getImpooper()))) &&
            ((this.fvalor==null && other.getFvalor()==null) || 
             (this.fvalor!=null &&
              this.fvalor.equals(other.getFvalor()))) &&
            ((this.indiban==null && other.getIndiban()==null) || 
             (this.indiban!=null &&
              this.indiban.equals(other.getIndiban()))) &&
            ((this.tipent==null && other.getTipent()==null) || 
             (this.tipent!=null &&
              this.tipent.equals(other.getTipent()))) &&
            ((this.campo21==null && other.getCampo21()==null) || 
             (this.campo21!=null &&
              this.campo21.equals(other.getCampo21()))) &&
            ((this.divisaorigen==null && other.getDivisaorigen()==null) || 
             (this.divisaorigen!=null &&
              this.divisaorigen.equals(other.getDivisaorigen()))) &&
            ((this.importeorigen==null && other.getImporteorigen()==null) || 
             (this.importeorigen!=null &&
              this.importeorigen.equals(other.getImporteorigen()))) &&
            ((this.cambio==null && other.getCambio()==null) || 
             (this.cambio!=null &&
              this.cambio.equals(other.getCambio()))) &&
            ((this.cambio36==null && other.getCambio36()==null) || 
             (this.cambio36!=null &&
              this.cambio36.equals(other.getCambio36()))) &&
            ((this.fechaVto==null && other.getFechaVto()==null) || 
             (this.fechaVto!=null &&
              this.fechaVto.equals(other.getFechaVto()))) &&
            ((this.descripVto1==null && other.getDescripVto1()==null) || 
             (this.descripVto1!=null &&
              this.descripVto1.equals(other.getDescripVto1()))) &&
            ((this.tipbenefi==null && other.getTipbenefi()==null) || 
             (this.tipbenefi!=null &&
              this.tipbenefi.equals(other.getTipbenefi()))) &&
            ((this.cuentaben==null && other.getCuentaben()==null) || 
             (this.cuentaben!=null &&
              this.cuentaben.equals(other.getCuentaben()))) &&
            ((this.beibene==null && other.getBeibene()==null) || 
             (this.beibene!=null &&
              this.beibene.equals(other.getBeibene()))) &&
            ((this.nombreben==null && other.getNombreben()==null) || 
             (this.nombreben!=null &&
              this.nombreben.equals(other.getNombreben()))) &&
            ((this.dirBen==null && other.getDirBen()==null) || 
             (this.dirBen!=null &&
              this.dirBen.equals(other.getDirBen()))) &&
            ((this.pobBen==null && other.getPobBen()==null) || 
             (this.pobBen!=null &&
              this.pobBen.equals(other.getPobBen()))) &&
            ((this.paisben==null && other.getPaisben()==null) || 
             (this.paisben!=null &&
              this.paisben.equals(other.getPaisben()))) &&
            ((this.ctacord==null && other.getCtacord()==null) || 
             (this.ctacord!=null &&
              this.ctacord.equals(other.getCtacord()))) &&
            ((this.cccOfiO==null && other.getCccOfiO()==null) || 
             (this.cccOfiO!=null &&
              this.cccOfiO.equals(other.getCccOfiO()))) &&
            ((this.cccCtaO==null && other.getCccCtaO()==null) || 
             (this.cccCtaO!=null &&
              this.cccCtaO.equals(other.getCccCtaO()))) &&
            ((this.niford==null && other.getNiford()==null) || 
             (this.niford!=null &&
              this.niford.equals(other.getNiford()))) &&
            ((this.xs7377Ia==null && other.getXs7377Ia()==null) || 
             (this.xs7377Ia!=null &&
              this.xs7377Ia.equals(other.getXs7377Ia()))) &&
            ((this.paisresord==null && other.getPaisresord()==null) || 
             (this.paisresord!=null &&
              this.paisresord.equals(other.getPaisresord()))) &&
            ((this.devoaut==null && other.getDevoaut()==null) || 
             (this.devoaut!=null &&
              this.devoaut.equals(other.getDevoaut()))) &&
            ((this.step2==null && other.getStep2()==null) || 
             (this.step2!=null &&
              this.step2.equals(other.getStep2()))) &&
            ((this.codrefdev==null && other.getCodrefdev()==null) || 
             (this.codrefdev!=null &&
              this.codrefdev.equals(other.getCodrefdev()))) &&
            ((this.fecopeori01==null && other.getFecopeori01()==null) || 
             (this.fecopeori01!=null &&
              this.fecopeori01.equals(other.getFecopeori01()))) &&
            ((this.motivdev==null && other.getMotivdev()==null) || 
             (this.motivdev!=null &&
              this.motivdev.equals(other.getMotivdev()))) &&
            ((this.motdevoltxt==null && other.getMotdevoltxt()==null) || 
             (this.motdevoltxt!=null &&
              this.motdevoltxt.equals(other.getMotdevoltxt()))) &&
            ((this.infoemis==null && other.getInfoemis()==null) || 
             (this.infoemis!=null &&
              java.util.Arrays.equals(this.infoemis, other.getInfoemis()))) &&
            ((this.inforecPri==null && other.getInforecPri()==null) || 
             (this.inforecPri!=null &&
              java.util.Arrays.equals(this.inforecPri, other.getInforecPri()))) &&
            ((this.inforecCob==null && other.getInforecCob()==null) || 
             (this.inforecCob!=null &&
              java.util.Arrays.equals(this.inforecCob, other.getInforecCob()))) &&
            ((this.codimotp==null && other.getCodimotp()==null) || 
             (this.codimotp!=null &&
              this.codimotp.equals(other.getCodimotp()))) &&
            ((this.indourben==null && other.getIndourben()==null) || 
             (this.indourben!=null &&
              this.indourben.equals(other.getIndourben()))) &&
            ((this.divisag==null && other.getDivisag()==null) || 
             (this.divisag!=null &&
              this.divisag.equals(other.getDivisag()))) &&
            ((this.importe71F1==null && other.getImporte71F1()==null) || 
             (this.importe71F1!=null &&
              this.importe71F1.equals(other.getImporte71F1()))) &&
            ((this.xs7377D==null && other.getXs7377D()==null) || 
             (this.xs7377D!=null &&
              java.util.Arrays.equals(this.xs7377D, other.getXs7377D()))) &&
            ((this.gastd71B==null && other.getGastd71B()==null) || 
             (this.gastd71B!=null &&
              java.util.Arrays.equals(this.gastd71B, other.getGastd71B()))) &&
            ((this.gastosa73==null && other.getGastosa73()==null) || 
             (this.gastosa73!=null &&
              java.util.Arrays.equals(this.gastosa73, other.getGastosa73()))) &&
            ((this.regrep77B==null && other.getRegrep77B()==null) || 
             (this.regrep77B!=null &&
              java.util.Arrays.equals(this.regrep77B, other.getRegrep77B()))) &&
            ((this.xs7377A==null && other.getXs7377A()==null) || 
             (this.xs7377A!=null &&
              java.util.Arrays.equals(this.xs7377A, other.getXs7377A()))) &&
            ((this.campo23B==null && other.getCampo23B()==null) || 
             (this.campo23B!=null &&
              this.campo23B.equals(other.getCampo23B()))) &&
            ((this.bicdestino==null && other.getBicdestino()==null) || 
             (this.bicdestino!=null &&
              this.bicdestino.equals(other.getBicdestino()))) &&
            ((this.p52BancoEmisor==null && other.getP52BancoEmisor()==null) || 
             (this.p52BancoEmisor!=null &&
              this.p52BancoEmisor.equals(other.getP52BancoEmisor()))) &&
            ((this.p57BancoBeneficiario==null && other.getP57BancoBeneficiario()==null) || 
             (this.p57BancoBeneficiario!=null &&
              this.p57BancoBeneficiario.equals(other.getP57BancoBeneficiario()))) &&
            ((this.p58Cobertura400==null && other.getP58Cobertura400()==null) || 
             (this.p58Cobertura400!=null &&
              this.p58Cobertura400.equals(other.getP58Cobertura400()))) &&
            ((this.p53ACorresp==null && other.getP53ACorresp()==null) || 
             (this.p53ACorresp!=null &&
              this.p53ACorresp.equals(other.getP53ACorresp()))) &&
            ((this.p54ACorresr==null && other.getP54ACorresr()==null) || 
             (this.p54ACorresr!=null &&
              this.p54ACorresr.equals(other.getP54ACorresr()))) &&
            ((this.p56AIntermed==null && other.getP56AIntermed()==null) || 
             (this.p56AIntermed!=null &&
              this.p56AIntermed.equals(other.getP56AIntermed()))) &&
            ((this.mt202Receptor==null && other.getMt202Receptor()==null) || 
             (this.mt202Receptor!=null &&
              this.mt202Receptor.equals(other.getMt202Receptor()))) &&
            ((this.c54ACorresp==null && other.getC54ACorresp()==null) || 
             (this.c54ACorresp!=null &&
              this.c54ACorresp.equals(other.getC54ACorresp()))) &&
            ((this.c56PartyInter==null && other.getC56PartyInter()==null) || 
             (this.c56PartyInter!=null &&
              this.c56PartyInter.equals(other.getC56PartyInter()))) &&
            ((this.c56ABicIntermediario==null && other.getC56ABicIntermediario()==null) || 
             (this.c56ABicIntermediario!=null &&
              this.c56ABicIntermediario.equals(other.getC56ABicIntermediario()))) &&
            ((this.c57ABancoCuenta==null && other.getC57ABancoCuenta()==null) || 
             (this.c57ABancoCuenta!=null &&
              this.c57ABancoCuenta.equals(other.getC57ABancoCuenta()))) &&
            ((this.c58BeneficiarioCobertura==null && other.getC58BeneficiarioCobertura()==null) || 
             (this.c58BeneficiarioCobertura!=null &&
              this.c58BeneficiarioCobertura.equals(other.getC58BeneficiarioCobertura()))) &&
            ((this.oficsnce==null && other.getOficsnce()==null) || 
             (this.oficsnce!=null &&
              this.oficsnce.equals(other.getOficsnce()))) &&
            ((this.nomprogr==null && other.getNomprogr()==null) || 
             (this.nomprogr!=null &&
              this.nomprogr.equals(other.getNomprogr()))) &&
            ((this.codusuario==null && other.getCodusuario()==null) || 
             (this.codusuario!=null &&
              this.codusuario.equals(other.getCodusuario()))) &&
            ((this.codtermina==null && other.getCodtermina()==null) || 
             (this.codtermina!=null &&
              this.codtermina.equals(other.getCodtermina()))) &&
            ((this.refBen==null && other.getRefBen()==null) || 
             (this.refBen!=null &&
              this.refBen.equals(other.getRefBen()))) &&
            ((this.refOrd==null && other.getRefOrd()==null) || 
             (this.refOrd!=null &&
              this.refOrd.equals(other.getRefOrd()))) &&
            ((this.indSepa==null && other.getIndSepa()==null) || 
             (this.indSepa!=null &&
              this.indSepa.equals(other.getIndSepa()))) &&
            ((this.adic1==null && other.getAdic1()==null) || 
             (this.adic1!=null &&
              this.adic1.equals(other.getAdic1()))) &&
            ((this.adic2==null && other.getAdic2()==null) || 
             (this.adic2!=null &&
              this.adic2.equals(other.getAdic2()))) &&
            ((this.adic3==null && other.getAdic3()==null) || 
             (this.adic3!=null &&
              this.adic3.equals(other.getAdic3()))) &&
            ((this.adic4==null && other.getAdic4()==null) || 
             (this.adic4!=null &&
              this.adic4.equals(other.getAdic4()))) &&
            ((this.adic5==null && other.getAdic5()==null) || 
             (this.adic5!=null &&
              this.adic5.equals(other.getAdic5()))) &&
            ((this.adic6==null && other.getAdic6()==null) || 
             (this.adic6!=null &&
              this.adic6.equals(other.getAdic6())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getReferencia() != null) {
            _hashCode += getReferencia().hashCode();
        }
        if (getNumsecpag() != null) {
            _hashCode += getNumsecpag().hashCode();
        }
        if (getEntidad() != null) {
            _hashCode += getEntidad().hashCode();
        }
        if (getCentro() != null) {
            _hashCode += getCentro().hashCode();
        }
        if (getRefercon() != null) {
            _hashCode += getRefercon().hashCode();
        }
        if (getTipoasig() != null) {
            _hashCode += getTipoasig().hashCode();
        }
        if (getTipoopci() != null) {
            _hashCode += getTipoopci().hashCode();
        }
        if (getModoasig() != null) {
            _hashCode += getModoasig().hashCode();
        }
        if (getTipoent() != null) {
            _hashCode += getTipoent().hashCode();
        }
        if (getCoditran() != null) {
            _hashCode += getCoditran().hashCode();
        }
        if (getTratcont() != null) {
            _hashCode += getTratcont().hashCode();
        }
        if (getTratswift() != null) {
            _hashCode += getTratswift().hashCode();
        }
        if (getTratbanc() != null) {
            _hashCode += getTratbanc().hashCode();
        }
        if (getCodicomp() != null) {
            _hashCode += getCodicomp().hashCode();
        }
        if (getMenswift() != null) {
            _hashCode += getMenswift().hashCode();
        }
        if (getDivisaEmis() != null) {
            _hashCode += getDivisaEmis().hashCode();
        }
        if (getDiviclie() != null) {
            _hashCode += getDiviclie().hashCode();
        }
        if (getCpaisdes() != null) {
            _hashCode += getCpaisdes().hashCode();
        }
        if (getCpaisfon() != null) {
            _hashCode += getCpaisfon().hashCode();
        }
        if (getImpooper() != null) {
            _hashCode += getImpooper().hashCode();
        }
        if (getFvalor() != null) {
            _hashCode += getFvalor().hashCode();
        }
        if (getIndiban() != null) {
            _hashCode += getIndiban().hashCode();
        }
        if (getTipent() != null) {
            _hashCode += getTipent().hashCode();
        }
        if (getCampo21() != null) {
            _hashCode += getCampo21().hashCode();
        }
        if (getDivisaorigen() != null) {
            _hashCode += getDivisaorigen().hashCode();
        }
        if (getImporteorigen() != null) {
            _hashCode += getImporteorigen().hashCode();
        }
        if (getCambio() != null) {
            _hashCode += getCambio().hashCode();
        }
        if (getCambio36() != null) {
            _hashCode += getCambio36().hashCode();
        }
        if (getFechaVto() != null) {
            _hashCode += getFechaVto().hashCode();
        }
        if (getDescripVto1() != null) {
            _hashCode += getDescripVto1().hashCode();
        }
        if (getTipbenefi() != null) {
            _hashCode += getTipbenefi().hashCode();
        }
        if (getCuentaben() != null) {
            _hashCode += getCuentaben().hashCode();
        }
        if (getBeibene() != null) {
            _hashCode += getBeibene().hashCode();
        }
        if (getNombreben() != null) {
            _hashCode += getNombreben().hashCode();
        }
        if (getDirBen() != null) {
            _hashCode += getDirBen().hashCode();
        }
        if (getPobBen() != null) {
            _hashCode += getPobBen().hashCode();
        }
        if (getPaisben() != null) {
            _hashCode += getPaisben().hashCode();
        }
        if (getCtacord() != null) {
            _hashCode += getCtacord().hashCode();
        }
        if (getCccOfiO() != null) {
            _hashCode += getCccOfiO().hashCode();
        }
        if (getCccCtaO() != null) {
            _hashCode += getCccCtaO().hashCode();
        }
        if (getNiford() != null) {
            _hashCode += getNiford().hashCode();
        }
        if (getXs7377Ia() != null) {
            _hashCode += getXs7377Ia().hashCode();
        }
        if (getPaisresord() != null) {
            _hashCode += getPaisresord().hashCode();
        }
        if (getDevoaut() != null) {
            _hashCode += getDevoaut().hashCode();
        }
        if (getStep2() != null) {
            _hashCode += getStep2().hashCode();
        }
        if (getCodrefdev() != null) {
            _hashCode += getCodrefdev().hashCode();
        }
        if (getFecopeori01() != null) {
            _hashCode += getFecopeori01().hashCode();
        }
        if (getMotivdev() != null) {
            _hashCode += getMotivdev().hashCode();
        }
        if (getMotdevoltxt() != null) {
            _hashCode += getMotdevoltxt().hashCode();
        }
        if (getInfoemis() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getInfoemis());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getInfoemis(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        if (getInforecPri() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getInforecPri());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getInforecPri(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        if (getInforecCob() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getInforecCob());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getInforecCob(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        if (getCodimotp() != null) {
            _hashCode += getCodimotp().hashCode();
        }
        if (getIndourben() != null) {
            _hashCode += getIndourben().hashCode();
        }
        if (getDivisag() != null) {
            _hashCode += getDivisag().hashCode();
        }
        if (getImporte71F1() != null) {
            _hashCode += getImporte71F1().hashCode();
        }
        if (getXs7377D() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getXs7377D());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getXs7377D(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        if (getGastd71B() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getGastd71B());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getGastd71B(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        if (getGastosa73() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getGastosa73());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getGastosa73(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        if (getRegrep77B() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getRegrep77B());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getRegrep77B(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        if (getXs7377A() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getXs7377A());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getXs7377A(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        if (getCampo23B() != null) {
            _hashCode += getCampo23B().hashCode();
        }
        if (getBicdestino() != null) {
            _hashCode += getBicdestino().hashCode();
        }
        if (getP52BancoEmisor() != null) {
            _hashCode += getP52BancoEmisor().hashCode();
        }
        if (getP57BancoBeneficiario() != null) {
            _hashCode += getP57BancoBeneficiario().hashCode();
        }
        if (getP58Cobertura400() != null) {
            _hashCode += getP58Cobertura400().hashCode();
        }
        if (getP53ACorresp() != null) {
            _hashCode += getP53ACorresp().hashCode();
        }
        if (getP54ACorresr() != null) {
            _hashCode += getP54ACorresr().hashCode();
        }
        if (getP56AIntermed() != null) {
            _hashCode += getP56AIntermed().hashCode();
        }
        if (getMt202Receptor() != null) {
            _hashCode += getMt202Receptor().hashCode();
        }
        if (getC54ACorresp() != null) {
            _hashCode += getC54ACorresp().hashCode();
        }
        if (getC56PartyInter() != null) {
            _hashCode += getC56PartyInter().hashCode();
        }
        if (getC56ABicIntermediario() != null) {
            _hashCode += getC56ABicIntermediario().hashCode();
        }
        if (getC57ABancoCuenta() != null) {
            _hashCode += getC57ABancoCuenta().hashCode();
        }
        if (getC58BeneficiarioCobertura() != null) {
            _hashCode += getC58BeneficiarioCobertura().hashCode();
        }
        if (getOficsnce() != null) {
            _hashCode += getOficsnce().hashCode();
        }
        if (getNomprogr() != null) {
            _hashCode += getNomprogr().hashCode();
        }
        if (getCodusuario() != null) {
            _hashCode += getCodusuario().hashCode();
        }
        if (getCodtermina() != null) {
            _hashCode += getCodtermina().hashCode();
        }
        if (getRefBen() != null) {
            _hashCode += getRefBen().hashCode();
        }
        if (getRefOrd() != null) {
            _hashCode += getRefOrd().hashCode();
        }
        if (getIndSepa() != null) {
            _hashCode += getIndSepa().hashCode();
        }
        if (getAdic1() != null) {
            _hashCode += getAdic1().hashCode();
        }
        if (getAdic2() != null) {
            _hashCode += getAdic2().hashCode();
        }
        if (getAdic3() != null) {
            _hashCode += getAdic3().hashCode();
        }
        if (getAdic4() != null) {
            _hashCode += getAdic4().hashCode();
        }
        if (getAdic5() != null) {
            _hashCode += getAdic5().hashCode();
        }
        if (getAdic6() != null) {
            _hashCode += getAdic6().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(Xs7977IEpa.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://proteo.bs.com/soa/service/proteo/xs7977/xs7977/domain/", "xs7977IEpa"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("referencia");
        elemField.setXmlName(new javax.xml.namespace.QName("http://proteo.bs.com/soa/service/proteo/xs7977/xs7977/domain/", "referencia"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("numsecpag");
        elemField.setXmlName(new javax.xml.namespace.QName("http://proteo.bs.com/soa/service/proteo/xs7977/xs7977/domain/", "numsecpag"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "integer"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("entidad");
        elemField.setXmlName(new javax.xml.namespace.QName("http://proteo.bs.com/soa/service/proteo/xs7977/xs7977/domain/", "entidad"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("centro");
        elemField.setXmlName(new javax.xml.namespace.QName("http://proteo.bs.com/soa/service/proteo/xs7977/xs7977/domain/", "centro"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("refercon");
        elemField.setXmlName(new javax.xml.namespace.QName("http://proteo.bs.com/soa/service/proteo/xs7977/xs7977/domain/", "refercon"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("tipoasig");
        elemField.setXmlName(new javax.xml.namespace.QName("http://proteo.bs.com/soa/service/proteo/xs7977/xs7977/domain/", "tipoasig"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("tipoopci");
        elemField.setXmlName(new javax.xml.namespace.QName("http://proteo.bs.com/soa/service/proteo/xs7977/xs7977/domain/", "tipoopci"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("modoasig");
        elemField.setXmlName(new javax.xml.namespace.QName("http://proteo.bs.com/soa/service/proteo/xs7977/xs7977/domain/", "modoasig"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("tipoent");
        elemField.setXmlName(new javax.xml.namespace.QName("http://proteo.bs.com/soa/service/proteo/xs7977/xs7977/domain/", "tipoent"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("coditran");
        elemField.setXmlName(new javax.xml.namespace.QName("http://proteo.bs.com/soa/service/proteo/xs7977/xs7977/domain/", "coditran"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("tratcont");
        elemField.setXmlName(new javax.xml.namespace.QName("http://proteo.bs.com/soa/service/proteo/xs7977/xs7977/domain/", "tratcont"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("tratswift");
        elemField.setXmlName(new javax.xml.namespace.QName("http://proteo.bs.com/soa/service/proteo/xs7977/xs7977/domain/", "tratswift"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("tratbanc");
        elemField.setXmlName(new javax.xml.namespace.QName("http://proteo.bs.com/soa/service/proteo/xs7977/xs7977/domain/", "tratbanc"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("codicomp");
        elemField.setXmlName(new javax.xml.namespace.QName("http://proteo.bs.com/soa/service/proteo/xs7977/xs7977/domain/", "codicomp"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("menswift");
        elemField.setXmlName(new javax.xml.namespace.QName("http://proteo.bs.com/soa/service/proteo/xs7977/xs7977/domain/", "menswift"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("divisaEmis");
        elemField.setXmlName(new javax.xml.namespace.QName("http://proteo.bs.com/soa/service/proteo/xs7977/xs7977/domain/", "divisaEmis"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("diviclie");
        elemField.setXmlName(new javax.xml.namespace.QName("http://proteo.bs.com/soa/service/proteo/xs7977/xs7977/domain/", "diviclie"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("cpaisdes");
        elemField.setXmlName(new javax.xml.namespace.QName("http://proteo.bs.com/soa/service/proteo/xs7977/xs7977/domain/", "cpaisdes"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("cpaisfon");
        elemField.setXmlName(new javax.xml.namespace.QName("http://proteo.bs.com/soa/service/proteo/xs7977/xs7977/domain/", "cpaisfon"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("impooper");
        elemField.setXmlName(new javax.xml.namespace.QName("http://proteo.bs.com/soa/service/proteo/xs7977/xs7977/domain/", "impooper"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "decimal"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("fvalor");
        elemField.setXmlName(new javax.xml.namespace.QName("http://proteo.bs.com/soa/service/proteo/xs7977/xs7977/domain/", "fvalor"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("indiban");
        elemField.setXmlName(new javax.xml.namespace.QName("http://proteo.bs.com/soa/service/proteo/xs7977/xs7977/domain/", "indiban"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("tipent");
        elemField.setXmlName(new javax.xml.namespace.QName("http://proteo.bs.com/soa/service/proteo/xs7977/xs7977/domain/", "tipent"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("campo21");
        elemField.setXmlName(new javax.xml.namespace.QName("http://proteo.bs.com/soa/service/proteo/xs7977/xs7977/domain/", "campo21"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("divisaorigen");
        elemField.setXmlName(new javax.xml.namespace.QName("http://proteo.bs.com/soa/service/proteo/xs7977/xs7977/domain/", "divisaorigen"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("importeorigen");
        elemField.setXmlName(new javax.xml.namespace.QName("http://proteo.bs.com/soa/service/proteo/xs7977/xs7977/domain/", "importeorigen"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "decimal"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("cambio");
        elemField.setXmlName(new javax.xml.namespace.QName("http://proteo.bs.com/soa/service/proteo/xs7977/xs7977/domain/", "cambio"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("cambio36");
        elemField.setXmlName(new javax.xml.namespace.QName("http://proteo.bs.com/soa/service/proteo/xs7977/xs7977/domain/", "cambio36"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "decimal"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("fechaVto");
        elemField.setXmlName(new javax.xml.namespace.QName("http://proteo.bs.com/soa/service/proteo/xs7977/xs7977/domain/", "fechaVto"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "integer"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("descripVto1");
        elemField.setXmlName(new javax.xml.namespace.QName("http://proteo.bs.com/soa/service/proteo/xs7977/xs7977/domain/", "descripVto1"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("tipbenefi");
        elemField.setXmlName(new javax.xml.namespace.QName("http://proteo.bs.com/soa/service/proteo/xs7977/xs7977/domain/", "tipbenefi"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("cuentaben");
        elemField.setXmlName(new javax.xml.namespace.QName("http://proteo.bs.com/soa/service/proteo/xs7977/xs7977/domain/", "cuentaben"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("beibene");
        elemField.setXmlName(new javax.xml.namespace.QName("http://proteo.bs.com/soa/service/proteo/xs7977/xs7977/domain/", "beibene"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("nombreben");
        elemField.setXmlName(new javax.xml.namespace.QName("http://proteo.bs.com/soa/service/proteo/xs7977/xs7977/domain/", "nombreben"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("dirBen");
        elemField.setXmlName(new javax.xml.namespace.QName("http://proteo.bs.com/soa/service/proteo/xs7977/xs7977/domain/", "dirBen"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("pobBen");
        elemField.setXmlName(new javax.xml.namespace.QName("http://proteo.bs.com/soa/service/proteo/xs7977/xs7977/domain/", "pobBen"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("paisben");
        elemField.setXmlName(new javax.xml.namespace.QName("http://proteo.bs.com/soa/service/proteo/xs7977/xs7977/domain/", "paisben"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("ctacord");
        elemField.setXmlName(new javax.xml.namespace.QName("http://proteo.bs.com/soa/service/proteo/xs7977/xs7977/domain/", "ctacord"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("cccOfiO");
        elemField.setXmlName(new javax.xml.namespace.QName("http://proteo.bs.com/soa/service/proteo/xs7977/xs7977/domain/", "cccOfiO"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("cccCtaO");
        elemField.setXmlName(new javax.xml.namespace.QName("http://proteo.bs.com/soa/service/proteo/xs7977/xs7977/domain/", "cccCtaO"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("niford");
        elemField.setXmlName(new javax.xml.namespace.QName("http://proteo.bs.com/soa/service/proteo/xs7977/xs7977/domain/", "niford"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("xs7377Ia");
        elemField.setXmlName(new javax.xml.namespace.QName("http://proteo.bs.com/soa/service/proteo/xs7977/xs7977/domain/", "xs7377Ia"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://proteo.bs.com/soa/service/proteo/xs7977/xs7977/domain/", "xs7377Ia"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("paisresord");
        elemField.setXmlName(new javax.xml.namespace.QName("http://proteo.bs.com/soa/service/proteo/xs7977/xs7977/domain/", "paisresord"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("devoaut");
        elemField.setXmlName(new javax.xml.namespace.QName("http://proteo.bs.com/soa/service/proteo/xs7977/xs7977/domain/", "devoaut"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("step2");
        elemField.setXmlName(new javax.xml.namespace.QName("http://proteo.bs.com/soa/service/proteo/xs7977/xs7977/domain/", "step2"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("codrefdev");
        elemField.setXmlName(new javax.xml.namespace.QName("http://proteo.bs.com/soa/service/proteo/xs7977/xs7977/domain/", "codrefdev"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("fecopeori01");
        elemField.setXmlName(new javax.xml.namespace.QName("http://proteo.bs.com/soa/service/proteo/xs7977/xs7977/domain/", "fecopeori01"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("motivdev");
        elemField.setXmlName(new javax.xml.namespace.QName("http://proteo.bs.com/soa/service/proteo/xs7977/xs7977/domain/", "motivdev"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("motdevoltxt");
        elemField.setXmlName(new javax.xml.namespace.QName("http://proteo.bs.com/soa/service/proteo/xs7977/xs7977/domain/", "motdevoltxt"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("infoemis");
        elemField.setXmlName(new javax.xml.namespace.QName("http://proteo.bs.com/soa/service/proteo/xs7977/xs7977/domain/", "infoemis"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://proteo.bs.com/soa/service/proteo/xs7977/xs7977/domain/", ">xs7977IEpa>infoemis"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("inforecPri");
        elemField.setXmlName(new javax.xml.namespace.QName("http://proteo.bs.com/soa/service/proteo/xs7977/xs7977/domain/", "inforecPri"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://proteo.bs.com/soa/service/proteo/xs7977/xs7977/domain/", ">xs7977IEpa>inforecPri"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("inforecCob");
        elemField.setXmlName(new javax.xml.namespace.QName("http://proteo.bs.com/soa/service/proteo/xs7977/xs7977/domain/", "inforecCob"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://proteo.bs.com/soa/service/proteo/xs7977/xs7977/domain/", ">xs7977IEpa>inforecCob"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("codimotp");
        elemField.setXmlName(new javax.xml.namespace.QName("http://proteo.bs.com/soa/service/proteo/xs7977/xs7977/domain/", "codimotp"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("indourben");
        elemField.setXmlName(new javax.xml.namespace.QName("http://proteo.bs.com/soa/service/proteo/xs7977/xs7977/domain/", "indourben"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("divisag");
        elemField.setXmlName(new javax.xml.namespace.QName("http://proteo.bs.com/soa/service/proteo/xs7977/xs7977/domain/", "divisag"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("importe71F1");
        elemField.setXmlName(new javax.xml.namespace.QName("http://proteo.bs.com/soa/service/proteo/xs7977/xs7977/domain/", "importe71F1"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "decimal"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("xs7377D");
        elemField.setXmlName(new javax.xml.namespace.QName("http://proteo.bs.com/soa/service/proteo/xs7977/xs7977/domain/", "xs7377D"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://proteo.bs.com/soa/service/proteo/xs7977/xs7977/domain/", "xs7377D"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("gastd71B");
        elemField.setXmlName(new javax.xml.namespace.QName("http://proteo.bs.com/soa/service/proteo/xs7977/xs7977/domain/", "gastd71B"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://proteo.bs.com/soa/service/proteo/xs7977/xs7977/domain/", ">xs7977IEpa>gastd71B"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("gastosa73");
        elemField.setXmlName(new javax.xml.namespace.QName("http://proteo.bs.com/soa/service/proteo/xs7977/xs7977/domain/", "gastosa73"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://proteo.bs.com/soa/service/proteo/xs7977/xs7977/domain/", ">xs7977IEpa>gastosa73"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("regrep77B");
        elemField.setXmlName(new javax.xml.namespace.QName("http://proteo.bs.com/soa/service/proteo/xs7977/xs7977/domain/", "regrep77B"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://proteo.bs.com/soa/service/proteo/xs7977/xs7977/domain/", ">xs7977IEpa>regrep77B"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("xs7377A");
        elemField.setXmlName(new javax.xml.namespace.QName("http://proteo.bs.com/soa/service/proteo/xs7977/xs7977/domain/", "xs7377A"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://proteo.bs.com/soa/service/proteo/xs7977/xs7977/domain/", "xs7377A"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("campo23B");
        elemField.setXmlName(new javax.xml.namespace.QName("http://proteo.bs.com/soa/service/proteo/xs7977/xs7977/domain/", "campo23B"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("bicdestino");
        elemField.setXmlName(new javax.xml.namespace.QName("http://proteo.bs.com/soa/service/proteo/xs7977/xs7977/domain/", "bicdestino"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("p52BancoEmisor");
        elemField.setXmlName(new javax.xml.namespace.QName("http://proteo.bs.com/soa/service/proteo/xs7977/xs7977/domain/", "p52BancoEmisor"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://proteo.bs.com/soa/service/proteo/xs7977/xs7977/domain/", "p52BancoEmisor"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("p57BancoBeneficiario");
        elemField.setXmlName(new javax.xml.namespace.QName("http://proteo.bs.com/soa/service/proteo/xs7977/xs7977/domain/", "p57BancoBeneficiario"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://proteo.bs.com/soa/service/proteo/xs7977/xs7977/domain/", "p57BancoBeneficiario"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("p58Cobertura400");
        elemField.setXmlName(new javax.xml.namespace.QName("http://proteo.bs.com/soa/service/proteo/xs7977/xs7977/domain/", "p58Cobertura400"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://proteo.bs.com/soa/service/proteo/xs7977/xs7977/domain/", "p58Cobertura400"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("p53ACorresp");
        elemField.setXmlName(new javax.xml.namespace.QName("http://proteo.bs.com/soa/service/proteo/xs7977/xs7977/domain/", "p53ACorresp"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("p54ACorresr");
        elemField.setXmlName(new javax.xml.namespace.QName("http://proteo.bs.com/soa/service/proteo/xs7977/xs7977/domain/", "p54ACorresr"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("p56AIntermed");
        elemField.setXmlName(new javax.xml.namespace.QName("http://proteo.bs.com/soa/service/proteo/xs7977/xs7977/domain/", "p56AIntermed"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("mt202Receptor");
        elemField.setXmlName(new javax.xml.namespace.QName("http://proteo.bs.com/soa/service/proteo/xs7977/xs7977/domain/", "mt202Receptor"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("c54ACorresp");
        elemField.setXmlName(new javax.xml.namespace.QName("http://proteo.bs.com/soa/service/proteo/xs7977/xs7977/domain/", "c54ACorresp"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("c56PartyInter");
        elemField.setXmlName(new javax.xml.namespace.QName("http://proteo.bs.com/soa/service/proteo/xs7977/xs7977/domain/", "c56PartyInter"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("c56ABicIntermediario");
        elemField.setXmlName(new javax.xml.namespace.QName("http://proteo.bs.com/soa/service/proteo/xs7977/xs7977/domain/", "c56ABicIntermediario"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("c57ABancoCuenta");
        elemField.setXmlName(new javax.xml.namespace.QName("http://proteo.bs.com/soa/service/proteo/xs7977/xs7977/domain/", "c57ABancoCuenta"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://proteo.bs.com/soa/service/proteo/xs7977/xs7977/domain/", "c57ABancoCuenta"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("c58BeneficiarioCobertura");
        elemField.setXmlName(new javax.xml.namespace.QName("http://proteo.bs.com/soa/service/proteo/xs7977/xs7977/domain/", "c58BeneficiarioCobertura"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://proteo.bs.com/soa/service/proteo/xs7977/xs7977/domain/", "c58BeneficiarioCobertura"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("oficsnce");
        elemField.setXmlName(new javax.xml.namespace.QName("http://proteo.bs.com/soa/service/proteo/xs7977/xs7977/domain/", "oficsnce"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("nomprogr");
        elemField.setXmlName(new javax.xml.namespace.QName("http://proteo.bs.com/soa/service/proteo/xs7977/xs7977/domain/", "nomprogr"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("codusuario");
        elemField.setXmlName(new javax.xml.namespace.QName("http://proteo.bs.com/soa/service/proteo/xs7977/xs7977/domain/", "codusuario"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("codtermina");
        elemField.setXmlName(new javax.xml.namespace.QName("http://proteo.bs.com/soa/service/proteo/xs7977/xs7977/domain/", "codtermina"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("refBen");
        elemField.setXmlName(new javax.xml.namespace.QName("http://proteo.bs.com/soa/service/proteo/xs7977/xs7977/domain/", "refBen"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("refOrd");
        elemField.setXmlName(new javax.xml.namespace.QName("http://proteo.bs.com/soa/service/proteo/xs7977/xs7977/domain/", "refOrd"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("indSepa");
        elemField.setXmlName(new javax.xml.namespace.QName("http://proteo.bs.com/soa/service/proteo/xs7977/xs7977/domain/", "indSepa"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("adic1");
        elemField.setXmlName(new javax.xml.namespace.QName("http://proteo.bs.com/soa/service/proteo/xs7977/xs7977/domain/", "adic1"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("adic2");
        elemField.setXmlName(new javax.xml.namespace.QName("http://proteo.bs.com/soa/service/proteo/xs7977/xs7977/domain/", "adic2"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("adic3");
        elemField.setXmlName(new javax.xml.namespace.QName("http://proteo.bs.com/soa/service/proteo/xs7977/xs7977/domain/", "adic3"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("adic4");
        elemField.setXmlName(new javax.xml.namespace.QName("http://proteo.bs.com/soa/service/proteo/xs7977/xs7977/domain/", "adic4"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("adic5");
        elemField.setXmlName(new javax.xml.namespace.QName("http://proteo.bs.com/soa/service/proteo/xs7977/xs7977/domain/", "adic5"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("adic6");
        elemField.setXmlName(new javax.xml.namespace.QName("http://proteo.bs.com/soa/service/proteo/xs7977/xs7977/domain/", "adic6"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
