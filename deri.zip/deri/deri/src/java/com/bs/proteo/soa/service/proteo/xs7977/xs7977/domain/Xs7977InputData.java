/**
 * Xs7977InputData.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.bs.proteo.soa.service.proteo.xs7977.xs7977.domain;

public class Xs7977InputData  implements java.io.Serializable {
    private com.bs.proteo.soa.service.proteo.xs7977.xs7977.domain.Xs7977IEpa xs7977IEpa;

    public Xs7977InputData() {
    }

    public Xs7977InputData(
           com.bs.proteo.soa.service.proteo.xs7977.xs7977.domain.Xs7977IEpa xs7977IEpa) {
           this.xs7977IEpa = xs7977IEpa;
    }


    /**
     * Gets the xs7977IEpa value for this Xs7977InputData.
     * 
     * @return xs7977IEpa
     */
    public com.bs.proteo.soa.service.proteo.xs7977.xs7977.domain.Xs7977IEpa getXs7977IEpa() {
        return xs7977IEpa;
    }


    /**
     * Sets the xs7977IEpa value for this Xs7977InputData.
     * 
     * @param xs7977IEpa
     */
    public void setXs7977IEpa(com.bs.proteo.soa.service.proteo.xs7977.xs7977.domain.Xs7977IEpa xs7977IEpa) {
        this.xs7977IEpa = xs7977IEpa;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof Xs7977InputData)) return false;
        Xs7977InputData other = (Xs7977InputData) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            ((this.xs7977IEpa==null && other.getXs7977IEpa()==null) || 
             (this.xs7977IEpa!=null &&
              this.xs7977IEpa.equals(other.getXs7977IEpa())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getXs7977IEpa() != null) {
            _hashCode += getXs7977IEpa().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(Xs7977InputData.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://proteo.bs.com/soa/service/proteo/xs7977/xs7977/domain/", "xs7977InputData"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("xs7977IEpa");
        elemField.setXmlName(new javax.xml.namespace.QName("http://proteo.bs.com/soa/service/proteo/xs7977/xs7977/domain/", "xs7977IEpa"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://proteo.bs.com/soa/service/proteo/xs7977/xs7977/domain/", "xs7977IEpa"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
