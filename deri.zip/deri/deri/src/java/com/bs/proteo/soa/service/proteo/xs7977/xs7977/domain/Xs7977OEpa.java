/**
 * Xs7977OEpa.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.bs.proteo.soa.service.proteo.xs7977.xs7977.domain;

public class Xs7977OEpa  implements java.io.Serializable {
    private java.lang.String estado;

    private java.lang.String txtresult;

    private java.lang.String codiasig;

    private java.lang.String menswift;

    private java.lang.String ctnosvos;

    private java.lang.String p53ACorresp;

    private java.lang.String p54ACorresr;

    private java.lang.String fvalor;

    private java.lang.String tipoNv;

    private java.lang.String codicomp;

    public Xs7977OEpa() {
    }

    public Xs7977OEpa(
           java.lang.String estado,
           java.lang.String txtresult,
           java.lang.String codiasig,
           java.lang.String menswift,
           java.lang.String ctnosvos,
           java.lang.String p53ACorresp,
           java.lang.String p54ACorresr,
           java.lang.String fvalor,
           java.lang.String tipoNv,
           java.lang.String codicomp) {
           this.estado = estado;
           this.txtresult = txtresult;
           this.codiasig = codiasig;
           this.menswift = menswift;
           this.ctnosvos = ctnosvos;
           this.p53ACorresp = p53ACorresp;
           this.p54ACorresr = p54ACorresr;
           this.fvalor = fvalor;
           this.tipoNv = tipoNv;
           this.codicomp = codicomp;
    }


    /**
     * Gets the estado value for this Xs7977OEpa.
     * 
     * @return estado
     */
    public java.lang.String getEstado() {
        return estado;
    }


    /**
     * Sets the estado value for this Xs7977OEpa.
     * 
     * @param estado
     */
    public void setEstado(java.lang.String estado) {
        this.estado = estado;
    }


    /**
     * Gets the txtresult value for this Xs7977OEpa.
     * 
     * @return txtresult
     */
    public java.lang.String getTxtresult() {
        return txtresult;
    }


    /**
     * Sets the txtresult value for this Xs7977OEpa.
     * 
     * @param txtresult
     */
    public void setTxtresult(java.lang.String txtresult) {
        this.txtresult = txtresult;
    }


    /**
     * Gets the codiasig value for this Xs7977OEpa.
     * 
     * @return codiasig
     */
    public java.lang.String getCodiasig() {
        return codiasig;
    }


    /**
     * Sets the codiasig value for this Xs7977OEpa.
     * 
     * @param codiasig
     */
    public void setCodiasig(java.lang.String codiasig) {
        this.codiasig = codiasig;
    }


    /**
     * Gets the menswift value for this Xs7977OEpa.
     * 
     * @return menswift
     */
    public java.lang.String getMenswift() {
        return menswift;
    }


    /**
     * Sets the menswift value for this Xs7977OEpa.
     * 
     * @param menswift
     */
    public void setMenswift(java.lang.String menswift) {
        this.menswift = menswift;
    }


    /**
     * Gets the ctnosvos value for this Xs7977OEpa.
     * 
     * @return ctnosvos
     */
    public java.lang.String getCtnosvos() {
        return ctnosvos;
    }


    /**
     * Sets the ctnosvos value for this Xs7977OEpa.
     * 
     * @param ctnosvos
     */
    public void setCtnosvos(java.lang.String ctnosvos) {
        this.ctnosvos = ctnosvos;
    }


    /**
     * Gets the p53ACorresp value for this Xs7977OEpa.
     * 
     * @return p53ACorresp
     */
    public java.lang.String getP53ACorresp() {
        return p53ACorresp;
    }


    /**
     * Sets the p53ACorresp value for this Xs7977OEpa.
     * 
     * @param p53ACorresp
     */
    public void setP53ACorresp(java.lang.String p53ACorresp) {
        this.p53ACorresp = p53ACorresp;
    }


    /**
     * Gets the p54ACorresr value for this Xs7977OEpa.
     * 
     * @return p54ACorresr
     */
    public java.lang.String getP54ACorresr() {
        return p54ACorresr;
    }


    /**
     * Sets the p54ACorresr value for this Xs7977OEpa.
     * 
     * @param p54ACorresr
     */
    public void setP54ACorresr(java.lang.String p54ACorresr) {
        this.p54ACorresr = p54ACorresr;
    }


    /**
     * Gets the fvalor value for this Xs7977OEpa.
     * 
     * @return fvalor
     */
    public java.lang.String getFvalor() {
        return fvalor;
    }


    /**
     * Sets the fvalor value for this Xs7977OEpa.
     * 
     * @param fvalor
     */
    public void setFvalor(java.lang.String fvalor) {
        this.fvalor = fvalor;
    }


    /**
     * Gets the tipoNv value for this Xs7977OEpa.
     * 
     * @return tipoNv
     */
    public java.lang.String getTipoNv() {
        return tipoNv;
    }


    /**
     * Sets the tipoNv value for this Xs7977OEpa.
     * 
     * @param tipoNv
     */
    public void setTipoNv(java.lang.String tipoNv) {
        this.tipoNv = tipoNv;
    }


    /**
     * Gets the codicomp value for this Xs7977OEpa.
     * 
     * @return codicomp
     */
    public java.lang.String getCodicomp() {
        return codicomp;
    }


    /**
     * Sets the codicomp value for this Xs7977OEpa.
     * 
     * @param codicomp
     */
    public void setCodicomp(java.lang.String codicomp) {
        this.codicomp = codicomp;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof Xs7977OEpa)) return false;
        Xs7977OEpa other = (Xs7977OEpa) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            ((this.estado==null && other.getEstado()==null) || 
             (this.estado!=null &&
              this.estado.equals(other.getEstado()))) &&
            ((this.txtresult==null && other.getTxtresult()==null) || 
             (this.txtresult!=null &&
              this.txtresult.equals(other.getTxtresult()))) &&
            ((this.codiasig==null && other.getCodiasig()==null) || 
             (this.codiasig!=null &&
              this.codiasig.equals(other.getCodiasig()))) &&
            ((this.menswift==null && other.getMenswift()==null) || 
             (this.menswift!=null &&
              this.menswift.equals(other.getMenswift()))) &&
            ((this.ctnosvos==null && other.getCtnosvos()==null) || 
             (this.ctnosvos!=null &&
              this.ctnosvos.equals(other.getCtnosvos()))) &&
            ((this.p53ACorresp==null && other.getP53ACorresp()==null) || 
             (this.p53ACorresp!=null &&
              this.p53ACorresp.equals(other.getP53ACorresp()))) &&
            ((this.p54ACorresr==null && other.getP54ACorresr()==null) || 
             (this.p54ACorresr!=null &&
              this.p54ACorresr.equals(other.getP54ACorresr()))) &&
            ((this.fvalor==null && other.getFvalor()==null) || 
             (this.fvalor!=null &&
              this.fvalor.equals(other.getFvalor()))) &&
            ((this.tipoNv==null && other.getTipoNv()==null) || 
             (this.tipoNv!=null &&
              this.tipoNv.equals(other.getTipoNv()))) &&
            ((this.codicomp==null && other.getCodicomp()==null) || 
             (this.codicomp!=null &&
              this.codicomp.equals(other.getCodicomp())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getEstado() != null) {
            _hashCode += getEstado().hashCode();
        }
        if (getTxtresult() != null) {
            _hashCode += getTxtresult().hashCode();
        }
        if (getCodiasig() != null) {
            _hashCode += getCodiasig().hashCode();
        }
        if (getMenswift() != null) {
            _hashCode += getMenswift().hashCode();
        }
        if (getCtnosvos() != null) {
            _hashCode += getCtnosvos().hashCode();
        }
        if (getP53ACorresp() != null) {
            _hashCode += getP53ACorresp().hashCode();
        }
        if (getP54ACorresr() != null) {
            _hashCode += getP54ACorresr().hashCode();
        }
        if (getFvalor() != null) {
            _hashCode += getFvalor().hashCode();
        }
        if (getTipoNv() != null) {
            _hashCode += getTipoNv().hashCode();
        }
        if (getCodicomp() != null) {
            _hashCode += getCodicomp().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(Xs7977OEpa.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://proteo.bs.com/soa/service/proteo/xs7977/xs7977/domain/", "xs7977OEpa"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("estado");
        elemField.setXmlName(new javax.xml.namespace.QName("http://proteo.bs.com/soa/service/proteo/xs7977/xs7977/domain/", "estado"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("txtresult");
        elemField.setXmlName(new javax.xml.namespace.QName("http://proteo.bs.com/soa/service/proteo/xs7977/xs7977/domain/", "txtresult"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("codiasig");
        elemField.setXmlName(new javax.xml.namespace.QName("http://proteo.bs.com/soa/service/proteo/xs7977/xs7977/domain/", "codiasig"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("menswift");
        elemField.setXmlName(new javax.xml.namespace.QName("http://proteo.bs.com/soa/service/proteo/xs7977/xs7977/domain/", "menswift"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("ctnosvos");
        elemField.setXmlName(new javax.xml.namespace.QName("http://proteo.bs.com/soa/service/proteo/xs7977/xs7977/domain/", "ctnosvos"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("p53ACorresp");
        elemField.setXmlName(new javax.xml.namespace.QName("http://proteo.bs.com/soa/service/proteo/xs7977/xs7977/domain/", "p53ACorresp"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("p54ACorresr");
        elemField.setXmlName(new javax.xml.namespace.QName("http://proteo.bs.com/soa/service/proteo/xs7977/xs7977/domain/", "p54ACorresr"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("fvalor");
        elemField.setXmlName(new javax.xml.namespace.QName("http://proteo.bs.com/soa/service/proteo/xs7977/xs7977/domain/", "fvalor"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("tipoNv");
        elemField.setXmlName(new javax.xml.namespace.QName("http://proteo.bs.com/soa/service/proteo/xs7977/xs7977/domain/", "tipoNv"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("codicomp");
        elemField.setXmlName(new javax.xml.namespace.QName("http://proteo.bs.com/soa/service/proteo/xs7977/xs7977/domain/", "codicomp"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
