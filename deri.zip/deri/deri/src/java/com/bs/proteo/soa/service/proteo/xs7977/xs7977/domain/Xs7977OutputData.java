/**
 * Xs7977OutputData.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.bs.proteo.soa.service.proteo.xs7977.xs7977.domain;

public class Xs7977OutputData  implements java.io.Serializable {
    private com.bs.proteo.soa.service.proteo.xs7977.xs7977.domain.Xs7977OEpa xs7977OEpa;

    public Xs7977OutputData() {
    }

    public Xs7977OutputData(
           com.bs.proteo.soa.service.proteo.xs7977.xs7977.domain.Xs7977OEpa xs7977OEpa) {
           this.xs7977OEpa = xs7977OEpa;
    }


    /**
     * Gets the xs7977OEpa value for this Xs7977OutputData.
     * 
     * @return xs7977OEpa
     */
    public com.bs.proteo.soa.service.proteo.xs7977.xs7977.domain.Xs7977OEpa getXs7977OEpa() {
        return xs7977OEpa;
    }


    /**
     * Sets the xs7977OEpa value for this Xs7977OutputData.
     * 
     * @param xs7977OEpa
     */
    public void setXs7977OEpa(com.bs.proteo.soa.service.proteo.xs7977.xs7977.domain.Xs7977OEpa xs7977OEpa) {
        this.xs7977OEpa = xs7977OEpa;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof Xs7977OutputData)) return false;
        Xs7977OutputData other = (Xs7977OutputData) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            ((this.xs7977OEpa==null && other.getXs7977OEpa()==null) || 
             (this.xs7977OEpa!=null &&
              this.xs7977OEpa.equals(other.getXs7977OEpa())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getXs7977OEpa() != null) {
            _hashCode += getXs7977OEpa().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(Xs7977OutputData.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://proteo.bs.com/soa/service/proteo/xs7977/xs7977/domain/", "xs7977OutputData"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("xs7977OEpa");
        elemField.setXmlName(new javax.xml.namespace.QName("http://proteo.bs.com/soa/service/proteo/xs7977/xs7977/domain/", "xs7977OEpa"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://proteo.bs.com/soa/service/proteo/xs7977/xs7977/domain/", "xs7977OEpa"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
