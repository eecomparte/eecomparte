package com.example.www.UserLogin_operation1;

import java.lang.reflect.Field;
import java.rmi.RemoteException;
import java.util.Map;
import java.util.Random;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.jasig.cas.client.util.AssertionHolder;
import org.jasig.cas.client.validation.Assertion;
import org.jboss.seam.annotations.In;
import org.jboss.seam.security.Identity;

import com.ConstantesFD;
import com.atos.firmaDigital.FirmaDigital;
import com.bancsabadell.xmlns.proteo.SharedResources.ErrorSchema.FaultInfo;
import com.bancsabadell.xmlns.proteo.SharedResources.Header.HeaderRequest;
import com.bancsabadell.xmlns.proteo.SharedResources.Header.HeaderRequestHostRequest;
import com.bs.cas.ws.AuthenticationFaultContainer;
import com.bs.cas.ws.AuthenticationServiceProxy;
import com.bs.proteo.soa.service.mainframe.UserLogin.domain.InputData;
import com.bs.proteo.soa.service.mainframe.UserLogin.domain.message.Operation1Request;
import com.bs.proteo.soa.service.mainframe.UserLogin.domain.message.Operation1Response;
import com.example.www.UserLogin_operation1.UserLoginServiceProxy;

public class ServicioLogin {
	
	private Log log = LogFactory.getLog(ServicioLogin.class);
	/*private String endPointLogin;
	private String endPointGrantTicket;*/
	private String username;
	private String password;
	
	private String proxyGrantingTicket = getTicket();
	
	//identificador de la sesión para el login
	private String sessionId;
	
	public String login(Map<String, String> parametrosLogin){
		//System.out.println("endPointLogin: -"+endPointLogin+"-");
		UserLoginServiceProxy proxy = new UserLoginServiceProxy(parametrosLogin.get("PROXY"));
		username = Identity.instance().getCredentials().getUsername();
		password = getPassTicket(proxyGrantingTicket, parametrosLogin.get("GRANTICKET"));
	    
		Operation1Request op = new Operation1Request();
	    HeaderRequest headerRequest = new HeaderRequest();
	    headerRequest.setApplicationId(parametrosLogin.get("APPID"));
	    headerRequest.setLanguage(parametrosLogin.get("LANGUAGE"));
	    headerRequest.setStep(1);
	    headerRequest.setTrackingId(parametrosLogin.get("TRACKID"));
	    HeaderRequestHostRequest hostRequest = new HeaderRequestHostRequest();
	    hostRequest.setAuthorizationId("");
	    hostRequest.setSessionId("");
	    headerRequest.setHostRequest(hostRequest);
	    
	    InputData inputData = new InputData();
	    inputData.setUsername(username);
	    inputData.setPassword(password);
	    inputData.setCenter(parametrosLogin.get("CENTER"));
	    inputData.setEnterprise(parametrosLogin.get("ENTERPRISE"));
	    
		op.setHeaderRequest(headerRequest);
		op.setInputData(inputData);

		try {
			//System.out.println("LLAMADA al webservice para obtener un identificador de sesión");
			//System.out.println("Login. username: "+username);
			Operation1Response response = proxy.operation1(op);
			//System.out.println("RESPUESTA login. Dni"+response.getOutputData().getDni());
			//System.out.println("RESPUESTA login. sessionId: "+response.getHeaderResponse().toString());
			sessionId = response.getHeaderResponse().getHostResponse().getSessionId();
		} catch (FaultInfo e) {
			e.printStackTrace();
			sessionId="-1";
		} catch (RemoteException e) {
			e.printStackTrace();
			sessionId="-2";
		}
		return sessionId;
	}
	
	public String getPassTicket(String proxyGrantingTicket, String endPointGrantTicket){
		
		//String endPointGrantTicket = getEndPointGrantTicket();
		
		AuthenticationServiceProxy aProxy = new AuthenticationServiceProxy(endPointGrantTicket);

		try {
			String ticket = aProxy.grantPassTicket(proxyGrantingTicket);
			return ticket;
		} catch (AuthenticationFaultContainer e) {
			e.printStackTrace();
		} catch (RemoteException e) {
			e.printStackTrace();
		}
		return "";
	}	
	
	private String getTicket(){
		Assertion assertion = AssertionHolder.getAssertion();
		java.security.Principal principal = assertion.getPrincipal();
	
		Field[] fields = principal.getClass().getDeclaredFields();
    	System.out.println("obtener el proxyGrantingTicket!!!!: ");
		for (Field field : fields) {
		    if (field.getName().equals("proxyGrantingTicket")) {
			    field.setAccessible(true);
		        try {
		        	String res = (String) field.get(principal);
		        	System.out.println("proxyGrantingTicket del CAS!!!!: "+res);
					return res;
				} catch (IllegalArgumentException e) {
					e.printStackTrace();
				} catch (IllegalAccessException e) {
					e.printStackTrace();
				}
		    }
		}
		return "";
	}
	
	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	/*public String getEndPointLogin() {
		return endPointLogin;
	}

	public void setEndPointLogin(String endPointLogin) {
		this.endPointLogin = endPointLogin;
	}*/

	public String getSessionId() {
		return sessionId;
	}

	public void setSessionId(String sessionId) {
		this.sessionId = sessionId;
	}

	public String getProxyGrantingTicket() {
		return proxyGrantingTicket;
	}

	public void setProxyGrantingTicket(String proxyGrantingTicket) {
		this.proxyGrantingTicket = proxyGrantingTicket;
	}

	/*public void setEndPointGrantTicket(String endPointGrantTicket) {
		this.endPointGrantTicket = endPointGrantTicket;
	}

	public String getEndPointGrantTicket() {
		return endPointGrantTicket;
	}*/
}
