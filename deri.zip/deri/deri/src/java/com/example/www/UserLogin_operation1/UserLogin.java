/**
 * UserLogin.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.example.www.UserLogin_operation1;

public interface UserLogin extends javax.xml.rpc.Service {
    public java.lang.String getUserLoginService_EPAddress();

    public com.example.www.UserLogin_operation1.UserLoginService getUserLoginService_EP() throws javax.xml.rpc.ServiceException;

    public com.example.www.UserLogin_operation1.UserLoginService getUserLoginService_EP(java.net.URL portAddress) throws javax.xml.rpc.ServiceException;
}
