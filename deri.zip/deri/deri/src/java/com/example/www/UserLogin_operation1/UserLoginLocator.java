/**
 * UserLoginLocator.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.example.www.UserLogin_operation1;

public class UserLoginLocator extends org.apache.axis.client.Service implements com.example.www.UserLogin_operation1.UserLogin {

    public UserLoginLocator() {
    }


    public UserLoginLocator(org.apache.axis.EngineConfiguration config) {
        super(config);
    }

    public UserLoginLocator(java.lang.String wsdlLoc, javax.xml.namespace.QName sName) throws javax.xml.rpc.ServiceException {
        super(wsdlLoc, sName);
    }

    // Use to get a proxy class for UserLoginService_EP
    private java.lang.String UserLoginService_EP_address = "http://172.18.48.82:9040/soa/service/mainframe/UserLoginservice";

    public java.lang.String getUserLoginService_EPAddress() {
        return UserLoginService_EP_address;
    }

    // The WSDD service name defaults to the port name.
    private java.lang.String UserLoginService_EPWSDDServiceName = "UserLoginService_EP";

    public java.lang.String getUserLoginService_EPWSDDServiceName() {
        return UserLoginService_EPWSDDServiceName;
    }

    public void setUserLoginService_EPWSDDServiceName(java.lang.String name) {
        UserLoginService_EPWSDDServiceName = name;
    }

    public com.example.www.UserLogin_operation1.UserLoginService getUserLoginService_EP() throws javax.xml.rpc.ServiceException {
       java.net.URL endpoint;
        try {
            endpoint = new java.net.URL(UserLoginService_EP_address);
        }
        catch (java.net.MalformedURLException e) {
            throw new javax.xml.rpc.ServiceException(e);
        }
        return getUserLoginService_EP(endpoint);
    }

    public com.example.www.UserLogin_operation1.UserLoginService getUserLoginService_EP(java.net.URL portAddress) throws javax.xml.rpc.ServiceException {
        try {
            com.example.www.UserLogin_operation1.UserLoginService_EPStub _stub = new com.example.www.UserLogin_operation1.UserLoginService_EPStub(portAddress, this);
            _stub.setPortName(getUserLoginService_EPWSDDServiceName());
            return _stub;
        }
        catch (org.apache.axis.AxisFault e) {
            return null;
        }
    }

    public void setUserLoginService_EPEndpointAddress(java.lang.String address) {
        UserLoginService_EP_address = address;
    }

    /**
     * For the given interface, get the stub implementation.
     * If this service has no port for the given interface,
     * then ServiceException is thrown.
     */
    public java.rmi.Remote getPort(Class serviceEndpointInterface) throws javax.xml.rpc.ServiceException {
        try {
            if (com.example.www.UserLogin_operation1.UserLoginService.class.isAssignableFrom(serviceEndpointInterface)) {
                com.example.www.UserLogin_operation1.UserLoginService_EPStub _stub = new com.example.www.UserLogin_operation1.UserLoginService_EPStub(new java.net.URL(UserLoginService_EP_address), this);
                _stub.setPortName(getUserLoginService_EPWSDDServiceName());
                return _stub;
            }
        }
        catch (java.lang.Throwable t) {
            throw new javax.xml.rpc.ServiceException(t);
        }
        throw new javax.xml.rpc.ServiceException("There is no stub implementation for the interface:  " + (serviceEndpointInterface == null ? "null" : serviceEndpointInterface.getName()));
    }

    /**
     * For the given interface, get the stub implementation.
     * If this service has no port for the given interface,
     * then ServiceException is thrown.
     */
    public java.rmi.Remote getPort(javax.xml.namespace.QName portName, Class serviceEndpointInterface) throws javax.xml.rpc.ServiceException {
        if (portName == null) {
            return getPort(serviceEndpointInterface);
        }
        java.lang.String inputPortName = portName.getLocalPart();
        if ("UserLoginService_EP".equals(inputPortName)) {
            return getUserLoginService_EP();
        }
        else  {
            java.rmi.Remote _stub = getPort(serviceEndpointInterface);
            ((org.apache.axis.client.Stub) _stub).setPortName(portName);
            return _stub;
        }
    }

    public javax.xml.namespace.QName getServiceName() {
        return new javax.xml.namespace.QName("http://www.example.com/UserLogin.operation1/", "UserLogin");
    }

    private java.util.HashSet ports = null;

    public java.util.Iterator getPorts() {
        if (ports == null) {
            ports = new java.util.HashSet();
            ports.add(new javax.xml.namespace.QName("http://www.example.com/UserLogin.operation1/", "UserLoginService_EP"));
        }
        return ports.iterator();
    }

    /**
    * Set the endpoint address for the specified port name.
    */
    public void setEndpointAddress(java.lang.String portName, java.lang.String address) throws javax.xml.rpc.ServiceException {
        
if ("UserLoginService_EP".equals(portName)) {
            setUserLoginService_EPEndpointAddress(address);
        }
        else 
{ // Unknown Port Name
            throw new javax.xml.rpc.ServiceException(" Cannot set Endpoint Address for Unknown Port" + portName);
        }
    }

    /**
    * Set the endpoint address for the specified port name.
    */
    public void setEndpointAddress(javax.xml.namespace.QName portName, java.lang.String address) throws javax.xml.rpc.ServiceException {
        setEndpointAddress(portName.getLocalPart(), address);
    }

}
