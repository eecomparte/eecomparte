NetBeans Profiler Server Pack 6.5 README

This server pack allows you to do remote profiling. First you need to
run the calibrate.bat/calibrate.sh/calibrate-(5|6).sh script located in the bin directory.
You can use profile.sh or profile.bat script located in the bin directory
instead of java command to run your application in profiling mode. 
Check the script for any additional modifications according to your 
system configuration.

